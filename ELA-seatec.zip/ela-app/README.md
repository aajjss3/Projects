# ELAApp

[![CircleCI](https://circleci.com/gh/seatec2/ela-app.svg?style=shield&circle-token=efd025e3beae496b360519b01548c956f71e11fd)](https://circleci.com/gh/seatec2/ela-app) 

## About

You can run `./mvnw spring-boot:run` from the root of the project to build and run the application locally.


## Swagger UI (springfox)

[swagger.io](https://swagger.io/tools/swagger-ui/) allows anyone — be it your development team or your end consumers — to visualize and interact with the API’s resources without having any of the implementation logic in place. It’s automatically generated from your OpenAPI (formerly known as Swagger) Specification, with the visual documentation making it easy for back end implementation and client side consumption.

 [ELA Swagger Link](https://apps-sandbox.seatec.com/ela/swagger-ui.html)
 
 [springfox website](http://springfox.github.io/springfox/)
 

## Actuator
 
 Currently the application runs on 8086.  It supports the spring actuator features such as:
 
 [http://127.0.0.1:8086/ela/actuator/health](http://127.0.0.1:8086/actuator/health)
 
 [http://127.0.0.1:8086/ela/actuator/info](http://127.0.0.1:8086/actuator/info)
 
 There are many features available with the actuator.  However for security reasons they are not enabled by default.
 
The actuator/info route has git and build information:
		
	When logged in from the browser, the build information is available at 
	http://127.0.0.1:8086/ela/actuator/info:
		
	{
        "app": {
            "name":"ELA-APP",
            "description":"Seatec Electrical Load Analysis Tool",
            "version":"0.0.1"
        },
        "git": {
            "branch":"master",
            "commit": {
                "id":"30873e8",
                "time":"20181101-113929"
            }
        },
        "build": {
            "artifact":"ela-app",
            "name":"ela-app",
            "time":"2018-11-01T20:07:40.592Z",
            "version":"0.0.1-SNAPSHOT",
            "group":"com.seatec.ela"
        }
	}
	

## Security

### KeyCloak

The application and API are protected by a [KeyCloak IDM](https://www.keycloak.org/)  solution deployed in AWS.  For local API development you can turn this off by adding `keycloak.enabled = false` to a loaded Spring Boot application.properties configuration file.
	  
## Product Work TODO:

 A Few Items TODO:
 
1. https and certificate
2. Security Guide best practices and proper sign-on
3. Authentication and Authorization Roles
4. Actuator use and security practices
5. security maven plugins to find security vulnerabilities
6. make sure mvn site report for license works
7. Database deploy/backup
8. database encryption?  file,db, in transit?
9. scanning of threats from ingested content (dangerous xls/xlsx files, etc)
10. access logs
11. change tracking (history tracking)
   
## Product Considerations:

1. Free Open Source Licensing (FOSS) Compliance
2. Encryption and Export Administration Regulations (EAR)
3. On Going Common Vulnerabilities and Exposures (CVE) plan
4. Vulnerability Reporting Process and Response plan
5. Review of any legal requirements for information privacy (depends upon countries involved)
6. Review of Site Security and Backup Practices
7. Register and update of SSL certificates
8. Site Redundancy and Availability plan
9. Site Dashboard and metrics



## Spring Boot Configuration

Useful Spring Boot infor here:	

[SPRING BOOT STARTERS](https://github.com/spring-projects/spring-boot/tree/master/spring-boot-project/spring-boot-starters)

[HOWTO ADOC](https://github.com/spring-projects/spring-boot/blob/master/spring-boot-project/spring-boot-docs/src/main/asciidoc/howto.adoc)
	
[AUTOCONFIGURE](https://github.com/spring-projects/spring-boot/tree/master/spring-boot-project/spring-boot-autoconfigure/src/main/java/org/springframework/boot/autoconfigure)
	
Related links:

[SPRING BOOT](https://github.com/spring-projects/spring-boot/)


It may be helpful to just do git clone of spring-boot.

	

## Dropbox shared files

There is a shared Dropbox folder called `ELA Source Docs` which contains the original ELA source files in Excel format.  

There is also a folder where backups of the postgres database are maintained to make it easy to migrate your local database when a schema or data change is made. 

