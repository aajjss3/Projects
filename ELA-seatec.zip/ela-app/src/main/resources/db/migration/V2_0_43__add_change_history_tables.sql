CREATE TABLE IF NOT EXISTS node_change_history
  (
     id                UUID NOT NULL,
     change_id         UUID NOT NULL,
     aircraft_id       BIGINT NOT NULL,
     ela_id            BIGINT NOT NULL,
     created           TIMESTAMP,
     updated           TIMESTAMP,
     version           INT4,
     name              VARCHAR(127),
     nominal_power     FLOAT8,
     bus_rating        FLOAT8,
     node_type         VARCHAR(20),
     requires_approval boolean,
     sheddable          boolean,
     voltage            FLOAT8,
     voltage_type       VARCHAR(15),
     description        VARCHAR(255),
     normal_tr          boolean,
     electrical_phase   VARCHAR(10),
CONSTRAINT node_change_history_pk PRIMARY KEY (id),
CONSTRAINT node_change_history_change_id_fk FOREIGN KEY (change_id) REFERENCES change,
CONSTRAINT node_change_history_aircraft_id_fk FOREIGN KEY (aircraft_id) REFERENCES aircraft,
CONSTRAINT node_change_history_ela_id_fk FOREIGN KEY (ela_id) REFERENCES ela
);

CREATE TABLE IF NOT EXISTS component_change_history
(
  id                    UUID NOT NULL,
  change_id             UUID NOT NULL,
  aircraft_id           BIGINT NOT NULL,
  ela_id                BIGINT NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  name                  VARCHAR(127),
  nominal_power         FLOAT8,
  ata                   VARCHAR(127),
  clipsed               boolean,
  elect_ident           VARCHAR(127),
  electrical_phase      VARCHAR(10),
  panel                 VARCHAR(127),
  sheddable             boolean,
  intermittent          boolean,
  connected_load_va     FLOAT8,
  connected_load_pf     FLOAT8,
CONSTRAINT component_change_history_pk PRIMARY KEY (id),
CONSTRAINT component_change_history_change_id_fk FOREIGN KEY (change_id) REFERENCES change,
CONSTRAINT component_change_history_aircraft_id_fk FOREIGN KEY (aircraft_id) REFERENCES aircraft,
CONSTRAINT component_change_history_ela_id_fk FOREIGN KEY (ela_id) REFERENCES ela
);

CREATE TABLE IF NOT EXISTS load_change_history
(
  id                    UUID NOT NULL,
  change_id             UUID NOT NULL,
  aircraft_id           BIGINT NOT NULL,
  ela_id                BIGINT NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  flight_phase          VARCHAR(127),
  operating_mode        VARCHAR(20),
  power_factor          FLOAT8,
  va                    FLOAT8,
CONSTRAINT load_change_history_pk PRIMARY KEY (id),
CONSTRAINT load_change_history_change_id_fk FOREIGN KEY (change_id) REFERENCES change,
CONSTRAINT load_change_history_aircraft_id_fk FOREIGN KEY (aircraft_id) REFERENCES aircraft,
CONSTRAINT load_change_history_ela_id_fk FOREIGN KEY (ela_id) REFERENCES ela
);