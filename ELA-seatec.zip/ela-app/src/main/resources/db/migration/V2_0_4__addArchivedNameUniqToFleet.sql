

ALTER TABLE IF EXISTS fleet ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;

ALTER TABLE fleet ADD CONSTRAINT unique_name_fleet UNIQUE (name);
