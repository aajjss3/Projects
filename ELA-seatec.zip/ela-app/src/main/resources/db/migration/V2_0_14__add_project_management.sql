alter table if exists project add column if not exists author varchar(127);

update project set author ='0' where author is null;

alter table if exists project alter column author set not null;
		
create table if not exists project_coauthor ( project_id uuid not null, coauthor varchar(127) );

create table if not exists project_comment ( id uuid not null,  created timestamp,  updated timestamp,  version int4,  author varchar(127),  display_name varchar(127), comment varchar(512),  project_id uuid not null, primary key (id) );
	
alter table if exists project_coauthor add constraint project_coauthor_project_fk foreign key (project_id) references project;

alter table if exists project_comment add constraint project_comment_project_fk  foreign key (project_id) references project;

