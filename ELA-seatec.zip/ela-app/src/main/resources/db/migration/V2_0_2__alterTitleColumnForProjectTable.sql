/* Engine: POSTGRESQL
* Version: 2.0.2
* Description: Per discussion with team, title field should never be empty (ie. not null)
*/

/*
* Structure
*/

ALTER TABLE project ALTER COLUMN title SET NOT NULL;

/*
* DATA
*/
