/* Engine: POSTGRESQL
* Version: 2.0.17
* Description: Business needs ability to create project with same title and number but diff revisions.
*
*/

-- targeting [project] table
DROP INDEX IF EXISTS title_idx;