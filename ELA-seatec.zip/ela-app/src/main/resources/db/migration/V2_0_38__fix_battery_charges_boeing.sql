/***** [757] fleet *****/

-- set battery to 'SINGLE_40AH'
UPDATE aircraft SET battery_charge='SINGLE_40AH'
WHERE aircraftshipno in ('5635','5636','5637','5638','5639',
'5640','5641','5642','5643','5644','5645','5646','5647','5648','5649',
'5650','5651','5652','5653','5654','5655','5656','5657',
'6801','6802','6803','6804','6805','6806','6807','6808','6809',
'6810','6811','6812','6813','6814','6815','6816','6817','6818','6819',
'6820','6821','6822','6823');

-- set battery to 'SINGLE_48AH'
UPDATE aircraft SET battery_charge='SINGLE_48AH'
WHERE aircraftshipno in ('649',
'650','651','652','653','654','655','658','659',
'660','661','662','663','664','665','666','667','668','669',
'670','671','672','673','674','675','676','678','679',
'680','681','682','683','684','685','686','687','688','689',
'690','691','692','693','694','695','696','697','698','699',
'6700','6701','6702','6703','6704','6705','6706','6707','6708','6709',
'6710','6711','6712','6713','6714','6715','6716','6717');

-- set battery to 'DUAL_40AH'
UPDATE aircraft SET battery_charge='DUAL_40AH'
WHERE aircraftshipno in ('5801','5802','5803','5804','5805',
'5806','5807','5808','5809',
'5810','5811','5812','5813','5814','5815','5816');



/***** [767-300ER] fleet *****/

-- set battery to 'SINGLE_48AH'
UPDATE aircraft SET battery_charge='SINGLE_48AH'
WHERE aircraftshipno in ('171','172','173','174','175',
'176','177','178','179',
'180','181','182','183','184','185','186','187','188','189',
'190','191','192','193','194','195','196','197','198','199',
'1200','1201',
'1401','1402',
'1501','1502','1503','1504','1505','1506',
'1521',
'1601','1602','1603','1604','1605','1606','1607','1608','1609',
'1610','1611','1612','1613',
'1701','1702','1703','1704','1705','1706','1707','1708');



/***** [767-400ER] fleet *****/

-- set battery to 'SINGLE_48AH'
UPDATE aircraft SET battery_charge='SINGLE_48AH'
WHERE aircraftshipno in ('1801','1802','1803','1804','1805',
'1806','1807','1808','1809',
'1810','1811','1812','1813','1814','1815','1816','1817','1818','1819',
'1820','1821');


/**** update cloned ships *****/
/* This script assumes non-cloned aircrafts contain valid (up to date) battery_charge values */
with matches as (
	select * from (
		select a.id as aid, e.id as ela_id, e.aircraft_id, e.name as ela_name, a.aircraftshipno, a.battery_charge,
		a.fleet_id, f.name as fleet_name, CAST(substring(e.name, '[^_]*$') AS BIGINT) as original_aircraft_id
		from ela e
		join aircraft a on a.id=e.aircraft_id
		join fleet f on f.id=a.fleet_id
		where e.name like 'Clone%'
		-- target boeing only (757 and 767 fleets)
		and (f.name like 'B757%' or f.name like 'B767%')
	) as matches
)
update aircraft
set battery_charge = results.original_battery
from (
	select m.aid as id, m.ela_id as ela_id,
	m.aircraftshipno as ship_nbr, a.aircraftshipno as cloned_ship_nbr,
	a.battery_charge as original_battery, m.battery_charge as cloned_battery,
	m.fleet_name
	from matches m
	join aircraft a on a.id = m.original_aircraft_id
) as results
where aircraft.id = results.id;

/* nice to know how many rows modified */
-- RETURNING aircraft.battery_charge as new_battery_charge;