/* Engine: POSTGRESQL
* Version: 2.0.25
* Description: Add battery_charge to aircraft table and populate the field for boeing aircrafts

*/

ALTER TABLE IF EXISTS aircraft ADD COLUMN IF NOT EXISTS battery_charge VARCHAR(31);

/* sql statments to update the aircraft.battery_charge */
update aircraft set battery_charge = 'SINGLE_48AH' where id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-900');
update aircraft set battery_charge = 'SINGLE_48AH' where id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-700');
update aircraft set battery_charge = 'DUAL_48AH' where (aircraftshipno != '3372' or aircraftshipno != '3373') and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-800');
update aircraft set battery_charge = 'SINGLE_48AH' where (aircraftshipno = '3772'  or aircraftshipno = '3773') and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-800');

update aircraft set battery_charge = 'SINGLE_48AH' where aircraftshipno like '6%'  and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-200');
update aircraft set battery_charge = 'SINGLE_40AH' where (aircraftshipno like '55%' or aircraftshipno like '56%') and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-200');
update aircraft set battery_charge = 'DUAL_48AH' where aircraftshipno like '58%' and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-300');

update aircraft set battery_charge = 'SINGLE_48AH' where id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B767-400');

