update project
set analysis = replace(analysis::text, '"SINGLE_53AH_54AH"', '"SINGLE_48AH"')::jsonb
where analysis::text like '%"SINGLE_53AH_54AH"%'
and analysis::text not like '%"SINGLE_48AH"%';
