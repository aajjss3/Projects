UPDATE aircraft SET fleet_id = f.id
FROM fleet f WHERE f.name = 'B737-900'
AND aircraftshipno IN (
'3876',
'3877',
'3878',
'3879',
'3880',
'3881',
'3882',
'3883',
'3884',
'3885',
'3886',
'3887',
'3888',
'3889',
'3890',
'3891',
'3892',
'3893',
'3894',
'3895'
);

DELETE from fleet where name = 'B737-900ETOPS';
