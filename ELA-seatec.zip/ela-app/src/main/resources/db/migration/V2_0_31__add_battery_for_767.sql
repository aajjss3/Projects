update aircraft set battery_charge = 'SINGLE_53AH_54AH' where id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and (f.name = 'B767-300' or f.name = 'B767-400'));
