create table if not exists change_comment (
  id            uuid not null,
  created       timestamp,
  updated       timestamp,
  version       int4,
  author        varchar(127),
  display_name  varchar(127),
  comment       varchar(512),
  change_id     uuid not null,
  CONSTRAINT change_comment_pkey PRIMARY KEY (id),
  CONSTRAINT change_comment_change_id_fk FOREIGN KEY(change_id) REFERENCES change
);



