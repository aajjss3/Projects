/* Engine: POSTGRESQL
* Version: 2.0.0
* Description: Add Change Group Bucket column to Fleet table and update existing records with corresponding data.
*/

/*
* Structure
*/
ALTER TABLE IF EXISTS fleet ADD COLUMN IF NOT EXISTS change_group_bucket VARCHAR(50);

ALTER TABLE change_group DROP CONSTRAINT IF EXISTS unique_name_project;
ALTER TABLE change_group ADD CONSTRAINT unique_name_project UNIQUE (name, project_id);

ALTER TABLE change_group ALTER COLUMN name SET NOT NULL;

ALTER TABLE aircraft_change_group DROP CONSTRAINT IF EXISTS unique_aircraft_changegroup;
ALTER TABLE aircraft_change_group ADD CONSTRAINT unique_aircraft_changegroup UNIQUE (aircraft_id, change_group_id);

/*
* DATA
*/

UPDATE fleet SET change_group_bucket = 'Airbus 1'
WHERE name LIKE 'A3%'
AND fleet_id IS NULL;

UPDATE fleet SET change_group_bucket = 'Airbus 2'
WHERE name LIKE 'A35%'
AND fleet_id IS NULL;

UPDATE fleet SET change_group_bucket = 'Boeing 1'
WHERE name LIKE 'B7%'
AND fleet_id IS NULL;

UPDATE fleet SET change_group_bucket = 'MD 1'
WHERE name LIKE 'MD%'
AND fleet_id IS NULL;

UPDATE fleet SET change_group_bucket = 'MD 1'
WHERE name LIKE 'A7%'
AND fleet_id IS NULL;

