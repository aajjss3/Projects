ALTER TABLE IF EXISTS load RENAME COLUMN val TO va;

ALTER TABLE IF EXISTS load ADD COLUMN IF NOT EXISTS power_factor DOUBLE PRECISION;

UPDATE load SET power_factor = 1.0;

UPDATE load AS l
SET va = l.va * c.nominal_power
FROM component AS c
WHERE c.id = l.component_id;

ALTER TABLE load ALTER COLUMN power_factor SET NOT NULL;

ALTER TABLE IF EXISTS load_change ADD COLUMN IF NOT EXISTS power_factor DOUBLE PRECISION;

UPDATE load_change SET power_factor = 1.0;

ALTER TABLE load_change RENAME COLUMN value TO va;

ALTER TABLE load_change ALTER COLUMN power_factor SET NOT NULL;

