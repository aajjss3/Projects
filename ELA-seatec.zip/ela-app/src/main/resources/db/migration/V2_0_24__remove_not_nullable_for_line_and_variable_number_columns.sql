/* Engine: POSTGRESQL
* Version: 2.0.24
* Description: DROP NOT NULL for linenumber and variablenumber columns on aircraft table.
*
*/

ALTER TABLE IF EXISTS aircraft ALTER COLUMN linenumber DROP NOT NULL;
ALTER TABLE IF EXISTS aircraft ALTER COLUMN variablenumber DROP NOT NULL;