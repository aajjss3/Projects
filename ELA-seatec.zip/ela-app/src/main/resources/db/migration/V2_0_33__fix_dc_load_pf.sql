
UPDATE load SET power_factor=1 WHERE id in (
  select l.id from component c
    inner join load l on l.component_id = c.id
  where c.electrical_phase = 'DC' and l.power_factor = 0
);

UPDATE load_change SET power_factor=1 WHERE id in (
  select lc.id from component_change cc 
    inner join load_change lc on lc.component_change_id = cc.id
  where cc.electrical_phase = 'DC' and lc.power_factor = 0
);


