

ALTER TABLE IF EXISTS aircraft ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;

ALTER TABLE aircraft ADD CONSTRAINT unique_shipno_aircraft UNIQUE (aircraftshipno);
