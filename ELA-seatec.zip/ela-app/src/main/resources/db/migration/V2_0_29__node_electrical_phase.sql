ALTER TABLE IF EXISTS node ADD COLUMN IF NOT EXISTS electrical_phase VARCHAR(255);

ALTER TABLE IF EXISTS node_change ADD COLUMN IF NOT EXISTS electrical_phase VARCHAR(255);

-- update based on component electrical phase where they exist
update node set electrical_phase = c.electrical_phase FROM component c where c.node_id = node.id and node.voltage_type = 'AC';
-- otherwise default to ACA
update node set electrical_phase = 'ACA' where node.voltage_type = 'AC' and electrical_phase is null;
