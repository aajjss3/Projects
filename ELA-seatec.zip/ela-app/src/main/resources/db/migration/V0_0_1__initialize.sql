/*
 * Engine: POSTGRESQL
 * Version: 0.0.1
 * Description: Initial database structure and data.
 */

/*
 * Structure
 */

CREATE TABLE fleet
  (
     id           BIGSERIAL NOT NULL,
     name         VARCHAR(255) NOT NULL,
     manufacturer VARCHAR(255) NOT NULL,
     fleet_id     BIGINT,
     CONSTRAINT fleet_pkey PRIMARY KEY (id),
CONSTRAINT fleet_fleet_id_fk FOREIGN KEY(fleet_id)REFERENCES fleet
);

CREATE TABLE aircraft
  (
     id                 BIGINT NOT NULL,
     fleet_id           BIGINT,
     aircraftshipno     VARCHAR(255) NOT NULL,
      serialnumber       VARCHAR(255) NOT NULL DEFAULT '',
      registrationnumber VARCHAR(255) NOT NULL DEFAULT '',
      linenumber         VARCHAR(255) NOT NULL DEFAULT '',
      variablenumber     VARCHAR(255) NOT NULL DEFAULT '',
      origworkbookcksum  VARCHAR(255),
      origworkbookname   VARCHAR(255),
CONSTRAINT aircraft_pkey PRIMARY KEY(id),
CONSTRAINT aircraft_fleet_id_fk FOREIGN KEY(fleet_id)REFERENCES fleet
);

CREATE sequence aircraft_id_seq start WITH 1 increment BY 1 no minvalue no maxvalue CACHE 1;

ALTER sequence aircraft_id_seq owned BY aircraft.id;

ALTER TABLE only aircraft ALTER COLUMN id SET DEFAULT nextval('public.aircraft_id_seq'::regclass);

CREATE TABLE ela
  (
     id           BIGSERIAL NOT NULL,
     aircraft_id  BIGINT NOT NULL,
     name         VARCHAR(255) NOT NULL,
     created_date TIMESTAMP NOT NULL,
     created_by   VARCHAR(255) NOT NULL,
     CONSTRAINT ela_pkey PRIMARY KEY (id),
CONSTRAINT ela_aircraft_id_fk FOREIGN KEY(aircraft_id)REFERENCES aircraft
);

CREATE TABLE efficiency_table
(
  id                    UUID NOT NULL,
  efficiency_type       VARCHAR(255),
  name                  VARCHAR(255) NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  CONSTRAINT            efficiency_table_pkey PRIMARY KEY(id)
);

CREATE TABLE node
  (
     id                  BIGSERIAL NOT NULL,
     name                VARCHAR(255) NOT NULL,
     voltage             DOUBLE PRECISION,
     nominal_power       DOUBLE PRECISION,
     display_order       BIGINT,
     conversion_formula  VARCHAR(255),
     node_id             BIGINT,
     ela_id              BIGINT,
     node_type           VARCHAR(255),
     requires_approval   BOOLEAN NOT NULL DEFAULT false,
     bus_rating          DOUBLE PRECISION,
     voltage_type        VARCHAR(15),
     sheddable           BOOLEAN NOT NULL DEFAULT false,
     efficiency_table_id UUID,
     CONSTRAINT node_pkey PRIMARY KEY (id),
CONSTRAINT node_node_id_fk FOREIGN KEY(node_id)REFERENCES node,
CONSTRAINT node_ela_id_fk FOREIGN KEY(ela_id)REFERENCES ela,
CONSTRAINT node_et_id_fk FOREIGN KEY(efficiency_table_id)REFERENCES efficiency_table
);

CREATE TABLE component
  (
     id               BIGSERIAL NOT NULL,
     name             VARCHAR(255),
     fin              VARCHAR(255),
     ata              VARCHAR(255),
     display_order    INTEGER,
     clipsed          BOOLEAN,
     sheddable        BOOLEAN,
     elect_ident      VARCHAR(255),
     panel            VARCHAR(255),
     node_id          BIGINT NOT NULL,
     nominal_power    NUMERIC NOT NULL,
     electrical_phase VARCHAR(255) NOT NULL,
     intermittent     BOOLEAN NOT NULL,
     CONSTRAINT component_pkey PRIMARY KEY (id),
CONSTRAINT component_node_id_fk FOREIGN KEY(node_id)REFERENCES node
);

CREATE TABLE load
  (
     id             BIGSERIAL NOT NULL,
     component_id   BIGINT NOT NULL,
     flight_phase   VARCHAR(255) NOT NULL,
     operating_mode VARCHAR(255),
     val            DOUBLE PRECISION,
     CONSTRAINT load_pkey PRIMARY KEY (id),
CONSTRAINT load_componnet_id_fk FOREIGN KEY(component_id)REFERENCES component
);

CREATE TABLE ela_formula
  (
     id                 BIGSERIAL NOT NULL,
     ela_id             BIGINT,
     formula            VARCHAR(255) NOT NULL,
     name               VARCHAR(255),
     display_order      INTEGER NOT NULL,
     validation_formula VARCHAR(255),
     category           BIGINT NOT NULL,
     CONSTRAINT node_formula_pkey PRIMARY KEY (id),
CONSTRAINT ela_formula_ela_id_fk FOREIGN KEY(ela_id)REFERENCES ela
);

CREATE TABLE project
  (
     id                      UUID NOT NULL,
     created                 TIMESTAMP,
     updated                 TIMESTAMP,
     retired                 TIMESTAMP,
     version                 INT4,
     approval_engineer       VARCHAR(127),
     approved                TIMESTAMP,
     check_engineer          VARCHAR(127),
     checked                 TIMESTAMP,
     description             VARCHAR(120),
     maintenance_description VARCHAR(120),
     number                  VARCHAR(20),
     revision_level          VARCHAR(20),
     started                 TIMESTAMP,
     submitted               TIMESTAMP,
     title                   VARCHAR(50),
PRIMARY KEY(id)
);

CREATE TABLE node_change
  (
     id                UUID NOT NULL,
     created           TIMESTAMP,
     updated           TIMESTAMP,
     version           INT4,
     name              VARCHAR(127),
     node_name         VARCHAR(127),
     nominal_power     FLOAT8,
     bus_rating        FLOAT8,
     fin               VARCHAR(127),
     node_type         VARCHAR(20),
     requires_approval BOOLEAN,
PRIMARY KEY(id)
);

CREATE TABLE component_change
(
  id                    UUID NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  name                  VARCHAR(127),
  node_name             VARCHAR(127),
  nominal_power         FLOAT8,
  ata                   VARCHAR(127),
  clipsed               BOOLEAN,
  elect_ident           VARCHAR(127),
  electrical_phase      VARCHAR(10),
  panel                 VARCHAR(127),
  sheddable             BOOLEAN,
PRIMARY KEY(id)
);

CREATE TABLE change_group
(
  id                    UUID NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  name                  VARCHAR(32),
  project_id            UUID NOT NULL,
PRIMARY KEY(id),
CONSTRAINT fkrci5oiifcfb55ce8vulfxvata FOREIGN KEY(project_id)REFERENCES PROJECT
);

CREATE TABLE load_change
(
  id                    UUID NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  component_name        VARCHAR(127),
  flight_phase          VARCHAR(127),
  operating_mode        VARCHAR(20),
  value                 FLOAT8,
  component_change_id   UUID NOT NULL,
PRIMARY KEY(id),
CONSTRAINT fkpkduqtfh5580n8o904ygjyqap FOREIGN KEY(component_change_id)REFERENCES component_change
);

CREATE TABLE aircraft_change_group
(
  id                    UUID NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  aircraft_id           INT8 NOT NULL,
  change_group_id       UUID NOT NULL,
PRIMARY KEY(id),
CONSTRAINT fkb5a8rxa7yjwdonayu4b5ekpoi FOREIGN KEY(aircraft_id)REFERENCES aircraft,
CONSTRAINT fk7ije1qe2m8422sff9fmkoolj FOREIGN KEY(change_group_id)REFERENCES change_group
);

CREATE TABLE change
(
  id                    UUID NOT NULL,
  created               TIMESTAMP,
  updated               TIMESTAMP,
  version               INT4,
  action                VARCHAR(15),
  changer               VARCHAR(127),
  component_elect_ident VARCHAR(127),
  node_name             VARCHAR(127),
  change_group_id       UUID NOT NULL,
  component_change_id   UUID,
  node_change_id        UUID,
PRIMARY KEY(id),
CONSTRAINT fkgoq0sdw6nm9qqgt0meqxh2oca FOREIGN KEY(change_group_id)REFERENCES change_group,
CONSTRAINT fk53whrhumoddqyf8ykrfeqy03d FOREIGN KEY(component_change_id)REFERENCES component_change,
CONSTRAINT fk4eoweeft5s51pbenkgr65jfa FOREIGN KEY(node_change_id)REFERENCES node_change
);

CREATE TABLE efficiency_table_efficiency_load
(
  id                    UUID NOT NULL,
  active_power          DOUBLE PRECISION,
  current               DOUBLE PRECISION NOT NULL,
  efficiency            DOUBLE PRECISION,
  expf                  DOUBLE PRECISION,
  power_factor          DOUBLE PRECISION,
CONSTRAINT efficiencytable_efficiencyload_pkey PRIMARY KEY(id, current),
CONSTRAINT fk2styxwcettdhtfbjq3l5trycd FOREIGN KEY(id)REFERENCES PUBLIC.efficiency_table(id)
);

/*
* Data
*/