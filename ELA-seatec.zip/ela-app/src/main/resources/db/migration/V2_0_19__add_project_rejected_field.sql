/* Engine: POSTGRESQL
* Version: 2.0.19
* Description: Add Project.rejected field.
*
*/


ALTER TABLE project ADD COLUMN IF NOT EXISTS rejected timestamp;