create index if not exists load_component_id_fk_idx on load (component_id) ;
create index if not exists component_node_id_fk_idx on component (node_id) ;
create index if not exists node_node_id_fk_idx on node (node_id) ;
create index if not exists node_ela_id_fk_idx on node (ela_id) ;
