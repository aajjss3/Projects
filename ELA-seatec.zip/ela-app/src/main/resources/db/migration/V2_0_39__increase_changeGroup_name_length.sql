ALTER TABLE IF EXISTS change_group ALTER COLUMN name TYPE varchar(127);

ALTER TABLE IF EXISTS change_group ADD UNIQUE (project_id, name);