ALTER TABLE IF EXISTS fleet RENAME change_group_bucket TO bus_structure_bucket;


