
ALTER TABLE IF EXISTS fleet ADD COLUMN IF NOT EXISTS etops boolean NOT NULL DEFAULT false;

UPDATE fleet set etops = true where name IN ('B767-300', 'B777-200ER', 'B757-300', 'B777-200LR', 'B767-400');
UPDATE fleet set bus_structure_bucket = 'Boeing ETOPS 1' where name IN ('B767-300', 'B777-200ER', 'B757-300', 'B777-200LR', 'B767-400');


INSERT INTO fleet (name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived, etops)
SELECT 'B737-900ETOPS', 'Boeing', f.id, 'Boeing ETOPS 1', 'B737-Node-Structure', false, true
FROM fleet f where f.name = 'B737' AND NOT EXISTS (SELECT 1 FROM fleet WHERE name = 'B737-900ETOPS');

INSERT INTO fleet (name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived, etops)
SELECT 'B757-200ETOPS', 'Boeing', f.id, 'Boeing ETOPS 1', 'B757-200-One-Node-Structure', false, true
FROM fleet f where f.name = 'B757' AND NOT EXISTS (SELECT 1 FROM fleet WHERE name = 'B757-200ETOPS');

UPDATE aircraft SET fleet_id = f.id
FROM fleet f WHERE f.name = 'B737-900ETOPS'
AND aircraftshipno IN (
'3876',
'3877',
'3878',
'3879',
'3880',
'3881',
'3882',
'3883',
'3884',
'3885',
'3886',
'3887',
'3888',
'3889',
'3890',
'3891',
'3892',
'3893',
'3894',
'3895'
);

UPDATE aircraft SET fleet_id = f.id
FROM fleet f WHERE f.name = 'B757-200ETOPS'
AND aircraftshipno IN (
'5635',
'5636',
'5637',
'5638',
'5639',
'5640',
'5641',
'5642',
'5643',
'5644',
'5645',
'5646',
'5647',
'5648',
'5649',
'6801',
'6802',
'6803',
'6804',
'6805',
'6806',
'6807',
'6808',
'6809',
'6810',
'6811',
'6812',
'6813',
'6814',
'6815',
'6816',
'6817',
'6818',
'6819',
'6820',
'6821',
'6822',
'6823'
);
