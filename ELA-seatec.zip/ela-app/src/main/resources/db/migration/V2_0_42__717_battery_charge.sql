update aircraft set battery_charge='SINGLE_75AH' where fleet_id in (select id from fleet where name = 'B717-200');
