ALTER TABLE component ALTER COLUMN nominal_power TYPE DOUBLE PRECISION;

DROP TABLE ela_formula;

ALTER TABLE node ALTER COLUMN display_order TYPE INTEGER;

ALTER TABLE node_structure ALTER COLUMN display_order TYPE INTEGER;
