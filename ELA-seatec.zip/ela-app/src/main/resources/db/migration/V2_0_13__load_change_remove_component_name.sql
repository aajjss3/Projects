ALTER TABLE load_change DROP COLUMN IF EXISTS component_name;
