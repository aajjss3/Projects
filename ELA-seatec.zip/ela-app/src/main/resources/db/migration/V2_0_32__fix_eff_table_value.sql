UPDATE efficiency_table_efficiency_load set active_power = 840 where id = '1f345933-72d8-432c-a30a-1e792386f2cb' and current = 30;
