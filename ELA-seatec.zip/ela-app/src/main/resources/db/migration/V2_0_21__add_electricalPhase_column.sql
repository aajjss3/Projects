/* Engine: POSTGRESQL
* Version: 2.0.21
* Description: Add node_structure.electrical_phase field.
*
*/

ALTER TABLE IF EXISTS node_structure ADD COLUMN IF NOT EXISTS electrical_phase VARCHAR(255) NOT NULL default 'NA';
UPDATE node_structure SET electrical_phase = COALESCE(voltage_type, 'NA');
UPDATE node_structure SET voltage_type = 'AC' where voltage_type in ('ACA', 'ACB', 'ACC');