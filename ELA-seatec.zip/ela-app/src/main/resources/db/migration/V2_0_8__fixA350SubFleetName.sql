UPDATE fleet SET name = 'A350-900' where name = 'A350-941'
