/* Engine: POSTGRESQL
* Version: 2.0.23
* Description: Add normal_tr column to nodeChange table.
*
*/

ALTER TABLE IF EXISTS node_change ADD COLUMN IF NOT EXISTS normal_tr boolean NOT NULL DEFAULT false;