/* Engine: POSTGRESQL
* Version: 2.0.26
* Description: Add analysis to project table
*/

ALTER TABLE IF EXISTS project ADD COLUMN IF NOT EXISTS analysis jsonb;


