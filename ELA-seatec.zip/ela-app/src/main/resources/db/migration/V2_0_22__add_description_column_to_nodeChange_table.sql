/* Engine: POSTGRESQL
* Version: 2.0.22
* Description: Add description column to nodeChange table.
*
*/

ALTER TABLE IF EXISTS node_change ADD COLUMN IF NOT EXISTS description VARCHAR(255);