

CREATE TABLE node_structure (
    id uuid NOT NULL,
    created timestamp without time zone,
    updated timestamp without time zone,
    version integer,
    bus_rating_amp character varying(255),
    bus_rating_va character varying(255),
    display_order bigint,
    node_name character varying(255) NOT NULL,
    node_type character varying(255),
    optional boolean,
    requires_approval boolean,
    sheddable boolean,
    structure_name character varying(255) NOT NULL,
    three_phase boolean,
    voltage double precision,
    voltage_type character varying(255),
    node_id uuid,
    CONSTRAINT node_structure_pkey PRIMARY KEY (id),
    CONSTRAINT node_structure_node_id_fk FOREIGN KEY (node_id) REFERENCES node_structure
);

