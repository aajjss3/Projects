package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.ComponentUtil;
import com.seatec.ela.app.util.NodeUtil;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** DefaultLoadSummaryCalculator calculates load summaries for nodes. */
public class DefaultLoadSummaryCalculator {
  private static Logger logger = LoggerFactory.getLogger(DefaultLoadSummaryCalculator.class);

  private static final DefaultAggregator LOAD_SUMMARY_AGGREGATOR = new DefaultAggregator();

  // suppress default constructor for noninstantiability
  private DefaultLoadSummaryCalculator() {
    throw new AssertionError();
  }

  /**
   * Calculate the load summaries for a node.
   *
   * <p>The load summaries will be calculated for all components of the node. - If the component has
   * an electrical phase of AC3, the load summaries will be split into ACA, ACB, ACC. - If a load
   * summary doesn't exist in the map for the specific LoadSummaryBucketKey , it'll be created. - If
   * the load summary already exists, then the load summaries will be aggregated.
   *
   * @param loadSummaryMap - map containing the load summaries
   * @param summaryType - the summary type of the load summaries
   * @param loadSummaryOptions - the load summary options
   * @param node - the node
   */
  public static void calculateLoadSummaries(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull LoadSummaryOptions loadSummaryOptions,
      @NotNull Node node) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");
    Objects.requireNonNull(node, "node must not be null");

    for (Component component : node.getComponents()) {

      ElectricalPhase electricalPhase = component.getElectricalPhase();
      logger.trace(
          "Component id: {} name: {} electricalPhase: {}",
          component.getId(),
          component.getName(),
          component.getElectricalPhase());

      switch (electricalPhase) {
        case DC:
        case AC:
        case ACA:
        case ACB:
        case ACC:
          calcNominalLoadSummaries(loadSummaryMap, summaryType, loadSummaryOptions, component);
          calcLoadSummaries(loadSummaryMap, summaryType, loadSummaryOptions, component);
          break;
        case AC3:
          calcNominalLoadSummariesPhaseSplit(
              loadSummaryMap, summaryType, loadSummaryOptions, component);
          calcLoadSummariesPhaseSplit(loadSummaryMap, summaryType, loadSummaryOptions, component);
          break;
        default:
          logger.info(
              "Summarized Loads NOT calculated for node: {} nodeType: {}, component: {}, electricalPhase: {}",
              NodeUtil.getNodeIdentifier(node),
              node.getNodeType(),
              component.getName(),
              electricalPhase);
          break;
      }
    }
  }

  static void calcNominalLoadSummaries(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component) {
    if (loadSummaryOptions.getIncludeNominalPower()) {
      // Nominal Power
      NominalPowerLoadSummaryCalculator.calcLoadSummary(loadSummaryMap, summaryType, component);

      // Connected Load
      ConnectedLoadLoadSummaryCalculator.calcLoadSummary(loadSummaryMap, summaryType, component);
    }
  }

  private static void calcLoadSummaries(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component) {

    for (Load load : component.getLoads()) {
      calcLoadSummary(loadSummaryMap, summaryType, loadSummaryOptions, component, load);
    }
  }

  private static void calcLoadSummary(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load) {
    SummarizedLoad loadSummary =
        LoadSummaryUtil.findOrCreateLoadSummary(loadSummaryMap, summaryType, component, load);
    LOAD_SUMMARY_AGGREGATOR.aggregateLoadSummary(loadSummary, loadSummaryOptions, component, load);
  }

  private static void calcNominalLoadSummariesPhaseSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component) {

    ComponentUtil.validateElectricalPhase(ElectricalPhase.AC3, component);

    if (loadSummaryOptions.getIncludeNominalPower()) {
      // Nominal Power
      NominalPowerLoadSummaryCalculator.calcLoadSummariesPhaseSplit(
          loadSummaryMap, summaryType, loadSummaryOptions, component);

      // Connected Load
      ConnectedLoadLoadSummaryCalculator.calcLoadSummariesPhaseSplit(
          loadSummaryMap, summaryType, loadSummaryOptions, component);
    }
  }

  private static void calcLoadSummariesPhaseSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component) {

    ComponentUtil.validateElectricalPhase(ElectricalPhase.AC3, component);

    for (Load load : component.getLoads()) {
      calcLoadSummariesPhaseSplit(loadSummaryMap, summaryType, loadSummaryOptions, component, load);
    }
  }

  private static void calcLoadSummariesPhaseSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load) {

    // AC3 - Split into ACA, ACB, ACC
    List<SummarizedLoad> loadSummaries =
        LoadSummaryUtil.findOrCreateLoadSummariesPhaseSplit(loadSummaryMap, summaryType, load);
    LOAD_SUMMARY_AGGREGATOR.aggregateLoadSummariesPhaseSplit(
        loadSummaries, loadSummaryOptions, component, load);

    // AC3 Aggregates
    if (loadSummaryOptions.getIncludeAggregateAC3Loads()) {
      calcLoadSummary(loadSummaryMap, summaryType, loadSummaryOptions, component, load);
    }
  }
}
