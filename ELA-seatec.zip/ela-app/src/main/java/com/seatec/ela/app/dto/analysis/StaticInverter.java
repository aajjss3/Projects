package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class StaticInverter implements Serializable {

  private static final long serialVersionUID = 1L;

  private double totalLoadInAmps;

  private double totalLoadInKVA;

  private AnalysisStatus status;

  private Double percentKVAUsed;

  private Double maxLoadInKVA;

  public AnalysisStatus getStatus() {
    return status;
  }

  public void setStatus(AnalysisStatus status) {
    this.status = status;
  }

  public double getTotalLoadInAmps() {
    return totalLoadInAmps;
  }

  public void setTotalLoadInAmps(double totalLoadInAmps) {
    this.totalLoadInAmps = totalLoadInAmps;
  }

  public double getTotalLoadInKVA() {
    return totalLoadInKVA;
  }

  public void setTotalLoadInKVA(double totalLoadInKVA) {
    this.totalLoadInKVA = totalLoadInKVA;
  }

  public Double getPercentKVAUsed() {
    return percentKVAUsed;
  }

  public void setPercentKVAUsed(Double percentKVAUsed) {
    this.percentKVAUsed = percentKVAUsed;
  }

  public Double getMaxLoadInKVA() {
    return maxLoadInKVA;
  }

  public void setMaxLoadInKVA(Double maxLoadInKVA) {
    this.maxLoadInKVA = maxLoadInKVA;
  }
}
