package com.seatec.ela.app.service.contract.project.change;

import com.seatec.ela.app.dto.project.change.ChangeCommentDTO;
import com.seatec.ela.app.model.project.change.ChangeComment;
import java.util.UUID;

/** Service for dealing with Project > ChangeGroup > Change > ChangeComment. */
public interface IChangeCommentService {
  ChangeComment create(
      ChangeCommentDTO changeCommentDTO,
      UUID projectId,
      UUID changeGroupId,
      UUID changeId,
      String userId);

  void deleteAllByChangeId(UUID projectId, UUID changeGroupId, UUID changeId);
}
