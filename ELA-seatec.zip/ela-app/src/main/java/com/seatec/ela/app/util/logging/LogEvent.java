package com.seatec.ela.app.util.logging;

import com.seatec.ela.app.dto.LogEventDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.stereotype.Component;

@Component
public class LogEvent {
  private static Logger log = LoggerFactory.getLogger(LogEvent.class);

  public static void log(LogEventDto logEventDto) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("source=[").append(logEventDto.getSource()).append("] ");
    stringBuilder.append("url=['").append(logEventDto.getUrl()).append("'] ");
    stringBuilder.append("message=['").append(logEventDto.getMessage()).append("']");

    if (logEventDto.getStatus().equals(Level.ERROR)) {
      log.error(stringBuilder.toString());
    } else if (logEventDto.getStatus().equals(Level.WARN)) {
      log.warn(stringBuilder.toString());
    } else {
      log.info(stringBuilder.toString());
    }
  }
}
