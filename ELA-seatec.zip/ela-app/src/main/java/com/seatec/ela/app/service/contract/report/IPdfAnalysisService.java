package com.seatec.ela.app.service.contract.report;

import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.util.List;

public interface IPdfAnalysisService {
  PdfPTable generateElaAnalysisSection(
      Long id, List<FlightPhaseDto> flightPhases, boolean isBoeing, boolean faaReport);

  PdfPTable generateProjectAnalysisSection(List<ChangeGroup> changeGroups);

  AnalysisStatus determineAircraftStatus(AnalysisStatus normal, AnalysisStatus degraded);

  PdfPCell setStatusIconAndLabel(AnalysisStatus status, Paragraph label);
}
