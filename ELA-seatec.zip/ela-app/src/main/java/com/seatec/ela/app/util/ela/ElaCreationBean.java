package com.seatec.ela.app.util.ela;

import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.structure.NodeStructure;
import java.util.List;
import java.util.Map;
import javax.validation.GroupSequence;
import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;

@Validated
public class ElaCreationBean {

  @NotNull(
      message = "{entityfield.null}",
      groups = {ValidateAll.class, AircraftValid1.class})
  Aircraft aircraft;

  @AssertFalse(
      message = "{entityfield.archived}",
      groups = {ValidateAll.class, AircraftValid2.class})
  Boolean aircraftArchived = true;

  @NotNull(
      message = "{entityfield.null}",
      groups = {ValidateAll.class, FleetValid1.class})
  Fleet fleet;

  @AssertFalse(
      message = "{entityfield.archived}",
      groups = {ValidateAll.class, FleetValid2.class})
  Boolean fleetArchived = true;

  @NotEmpty(
      message = "{entityfield.empty",
      groups = {ValidateAll.class, FleetValid3.class})
  String nodeStructureName;

  @NotEmpty(
      message = "{entityfield.empty}",
      groups = {ValidateAll.class, NodeStructureValid.class})
  List<NodeStructure> structureList;

  @AssertTrue(
      message = "{field.file.missing}",
      groups = {FilePresent.class})
  Boolean filePresent = false;

  Map<String, EfficiencyTable> efficiencyTableMap;

  @NotEmpty(
      message = "{field.required}",
      groups = {ValidateAll.class, ValidateClone.class})
  String elaName;

  @AssertTrue(
      message = "{clonefield.no.clone}",
      groups = {ValidateClone.class, ValidateClone1.class})
  boolean aircraftClone;

  @NotNull(
      message = "{clonefield.no.clone}",
      groups = {ValidateClone.class, ValidateClone2.class})
  Aircraft cloneAircraft;

  @AssertTrue(
      message = "{clonefield.structure.no.match}",
      groups = {ValidateClone.class, ValidateClone3.class})
  boolean aircraftNodeStructureMatch;

  @NotNull(
      message = "{clonefield.no.ela}",
      groups = {ValidateClone.class, ValidateClone4.class})
  Ela cloneEla;

  @AssertFalse(
      message = "{clonefield.cloaked}",
      groups = {ValidateClone.class, ValidateClone5.class})
  Boolean cloneCloaked = true;

  public interface AircraftValid1 {}

  public interface AircraftValid2 {}

  public interface FleetValid1 {}

  public interface FleetValid2 {}

  public interface FleetValid3 {}

  public interface NodeStructureValid {}

  public interface FilePresent {}

  public interface ValidateClone1 {}

  public interface ValidateClone2 {}

  public interface ValidateClone3 {}

  public interface ValidateClone4 {}

  public interface ValidateClone5 {}

  @GroupSequence({
    AircraftValid1.class,
    AircraftValid2.class,
    FleetValid1.class,
    FleetValid2.class,
    FleetValid3.class,
    NodeStructureValid.class
  })
  public interface ValidateAll {}

  @GroupSequence({
    ValidateClone1.class,
    ValidateClone2.class,
    ValidateClone3.class,
    ValidateClone4.class,
    ValidateClone5.class
  })
  public interface ValidateClone {}

  public Boolean getAircraftArchived() {
    return aircraftArchived;
  }

  public void setAircraftArchived(Boolean aircraftArchived) {
    this.aircraftArchived = aircraftArchived;
  }

  public Boolean getFleetArchived() {
    return fleetArchived;
  }

  public void setFleetArchived(Boolean fleetArchived) {
    this.fleetArchived = fleetArchived;
  }

  public String getNodeStructureName() {
    return nodeStructureName;
  }

  public void setNodeStructureName(String nodeStructureName) {
    this.nodeStructureName = nodeStructureName;
  }

  public List<NodeStructure> getStructureList() {
    return structureList;
  }

  public void setStructureList(List<NodeStructure> structureList) {
    this.structureList = structureList;
  }

  public Boolean getFilePresent() {
    return filePresent;
  }

  public void setFilePresent(Boolean filePresent) {
    this.filePresent = filePresent;
  }

  public Aircraft getAircraft() {
    return aircraft;
  }

  public void setAircraft(Aircraft aircraft) {
    this.aircraft = aircraft;
  }

  public Fleet getFleet() {
    return fleet;
  }

  public void setFleet(Fleet fleet) {
    this.fleet = fleet;
  }

  public Map<String, EfficiencyTable> getEfficiencyTableMap() {
    return efficiencyTableMap;
  }

  public void setEfficiencyTableMap(Map<String, EfficiencyTable> efficiencyTableMap) {
    this.efficiencyTableMap = efficiencyTableMap;
  }

  public String getElaName() {
    return elaName;
  }

  public void setElaName(String elaName) {
    this.elaName = elaName;
  }

  public boolean isAircraftClone() {
    return aircraftClone;
  }

  public void setAircraftClone(boolean aircraftClone) {
    this.aircraftClone = aircraftClone;
  }

  public Aircraft getCloneAircraft() {
    return cloneAircraft;
  }

  public void setCloneAircraft(Aircraft cloneAircraft) {
    this.cloneAircraft = cloneAircraft;
  }

  public boolean isAircraftNodeStructureMatch() {
    return aircraftNodeStructureMatch;
  }

  public void setAircraftNodeStructureMatch(boolean aircraftNodeStructureMatch) {
    this.aircraftNodeStructureMatch = aircraftNodeStructureMatch;
  }

  public Ela getCloneEla() {
    return cloneEla;
  }

  public void setCloneEla(Ela cloneEla) {
    this.cloneEla = cloneEla;
  }

  public Boolean getCloneCloaked() {
    return cloneCloaked;
  }

  public void setCloneCloaked(Boolean cloneCloaked) {
    this.cloneCloaked = cloneCloaked;
  }
}
