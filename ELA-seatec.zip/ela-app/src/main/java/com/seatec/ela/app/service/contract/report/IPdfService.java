package com.seatec.ela.app.service.contract.report;

import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.project.Project;
import java.io.ByteArrayOutputStream;

/** Service for dealing with Reporting Service. */
public interface IPdfService {
  ByteArrayOutputStream getElaPdf(Ela ela, boolean faaReport);

  ByteArrayOutputStream getProjectPdf(Project project);
}
