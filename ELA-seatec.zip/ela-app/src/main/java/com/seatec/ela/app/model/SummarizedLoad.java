package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.model.View.NodeSummaryView;
import com.seatec.ela.app.util.LoadUtil;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A single SummarizedLoad object contains the nodes aggregate load of essential and sheddable
 * loads, and the nodes aggregate load of only essential loads.
 *
 * @author asparago
 */
@JsonView(NodeSummaryView.class)
public class SummarizedLoad implements Serializable {

  public enum Units {
    KVA,
    AMPS
  }

  private static Logger logger = LoggerFactory.getLogger(SummarizedLoad.class);

  // contains the summed load in watts. contains both sheddable and essential loads
  private Double w = 0d;

  // contains the summed load in volt ampere reactive. contains both sheddable and essential loads
  private Double var = 0d;

  // analogous to the 'w' field above except it only has essential loads not sheddable loads. used
  // for the degraded analysis
  // (see LoadAnalysisService). Component.sheddable is used to determine if its loads are essential
  // or sheddable.
  // this field is not returned to the user, instead it's used in the LoadAnalysisService class to
  // populate an AnalysisLoad object.
  @JsonIgnore private Double wEssentialLoad = 0d;

  @JsonIgnore private Double varEssentialLoad = 0d;

  private String flightPhase;

  private String operatingMode;

  private ElectricalPhase electricalPhase;

  private SummaryType summaryType;

  // units the value is in, default units to KVA
  private Units units = Units.KVA;

  // if the node being summed is a Transformer type, then this field contains the summed load
  // without being adjusted by the efficiency power
  // factor (the 'w' field above contains the summed load under all conditions and if it's a
  // Transformer type then it's the summed load
  // adjusted by the efficiency power factor). if not a Transformer type, then this field is not
  // used.
  // contains both sheddable ane essential loads.
  private Double originalW = 0d;
  private Double originalVar = 0d;

  // analogous to the 'originalW'field above except it only contains essential loads not sheddable
  // loads. used for the degraded analysis
  // (see LoadAnalysisService). Component.sheddable is used to determine if its loads are essential
  // or sheddable.
  // this field is not returned to the user, instead it's used in the LoadAnalysisService class to
  // populate an AnalysisLoad object.
  @JsonIgnore private Double originalWEssentialLoad = 0d;

  @JsonIgnore private Double originalVarEssentialLoad = 0d;

  // set to true if this SummarizedLoad object contains the Phase Summary's max imbalance value
  private boolean isMaxImbalance = false;

  // set to true if this SummarizedLoad object contains the Phase Summary's max load value
  private boolean isMaxPhaseLoad = false;

  // if the Node being summed is a TRU transformer, then this will be temporary bucket that contains
  // an aggregate of the load's
  // values. The map key is the node id to use to lookup the adjusted load. the map value is the
  // aggregated load value to adjust.
  @JsonIgnore private Map<String, Double> truWs = new HashMap<>();

  // analogous to the 'truWs' field above except it only has essential loads not sheddable loads.
  // used for the degraded analysis
  // (see LoadAnalysisService)
  @JsonIgnore private Map<String, Double> truWsEssentialLoad = new HashMap<>();

  // if the Node being summed is a ATU transformer, then this will be temporary bucket that contains
  // an aggregate of the load's
  // values. The map key is the node id to use to lookup the adjusted load. the map value is the
  // aggregated load value to adjust.
  @JsonIgnore private Map<String, Double> atuWs = new HashMap<>();

  @JsonIgnore private Map<String, Double> atuVars = new HashMap<>();

  // analogous to the 'atuWs' field above except it only has essential loads not sheddable loads.
  // used for the degraded analysis
  // (see LoadAnalysisService)
  @JsonIgnore private Map<String, Double> atuWsEssentialLoad = new HashMap<>();

  @JsonIgnore private Map<String, Double> atuVarsEssentialLoad = new HashMap<>();

  @JsonIgnore private Map<String, UUID> nodeToEfficiencyTableMap = new HashMap<>();

  public SummarizedLoad(
      String flightPhase,
      String operatingMode,
      ElectricalPhase electricalPhase,
      SummaryType summaryType) {
    this.electricalPhase = electricalPhase;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.summaryType = summaryType;
  }

  public SummarizedLoad(
      String flightPhase,
      String operatingMode,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      Double w,
      Double var) {
    this.electricalPhase = electricalPhase;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.summaryType = summaryType;
    this.w = w;
    this.var = var;
  }

  public SummarizedLoad(
      String flightPhase,
      String operatingMode,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      boolean isMaxImbalance,
      boolean isMaxPhaseLoad,
      Double w,
      Double var) {
    this.electricalPhase = electricalPhase;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.summaryType = summaryType;
    this.isMaxImbalance = isMaxImbalance;
    this.isMaxPhaseLoad = isMaxPhaseLoad;
    this.w = w;
    this.var = var;
  }

  public SummarizedLoad(
      String flightPhase,
      String operatingMode,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      boolean isMaxImbalance,
      boolean isMaxPhaseLoad,
      Double w,
      Double var,
      Units units) {
    this.electricalPhase = electricalPhase;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.summaryType = summaryType;
    this.isMaxImbalance = isMaxImbalance;
    this.isMaxPhaseLoad = isMaxPhaseLoad;
    this.w = w;
    this.var = var;
    this.units = units;
  }

  public Double getW() {
    return w;
  }

  public Double getVar() {
    return var;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public String getOperatingMode() {
    return operatingMode;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public SummaryType getSummaryType() {
    return summaryType;
  }

  public void setW(Double w) {
    this.w = w;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public void setOperatingMode(String operatingMode) {
    this.operatingMode = operatingMode;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public void setSummaryType(SummaryType summaryType) {
    this.summaryType = summaryType;
  }

  public Map<String, Double> getTruWs() {
    return truWs;
  }

  public void setTruWs(Map<String, Double> truWs) {
    this.truWs = truWs;
  }

  public Map<String, Double> getAtuWs() {
    return atuWs;
  }

  public void setAtuWs(Map<String, Double> atuWs) {
    this.atuWs = atuWs;
  }

  public boolean isMaxImbalance() {
    return isMaxImbalance;
  }

  public void setMaxImbalance(boolean isMaxImbalance) {
    this.isMaxImbalance = isMaxImbalance;
  }

  public boolean isMaxPhaseLoad() {
    return isMaxPhaseLoad;
  }

  public void setMaxPhaseLoad(boolean isMaxPhaseLoad) {
    this.isMaxPhaseLoad = isMaxPhaseLoad;
  }

  public Units getUnits() {
    return units;
  }

  public void setUnits(Units units) {
    this.units = units;
  }

  public Double getOriginalW() {
    return originalW;
  }

  public void setOriginalW(Double originalW) {
    this.originalW = originalW;
  }

  public Double getwEssentialLoad() {
    return wEssentialLoad;
  }

  public void setwEssentialLoad(Double wEssentialLoad) {
    this.wEssentialLoad = wEssentialLoad;
  }

  public Double getVarEssentialLoad() {
    return varEssentialLoad;
  }

  public void setVarEssentialLoad(Double varEssentialLoad) {
    this.varEssentialLoad = varEssentialLoad;
  }

  public Double getOriginalWEssentialLoad() {
    return originalWEssentialLoad;
  }

  public void setOriginalWEssentialLoad(Double originalWEssentialLoad) {
    this.originalWEssentialLoad = originalWEssentialLoad;
  }

  public Map<String, Double> getTruWsEssentialLoad() {
    return truWsEssentialLoad;
  }

  public void setTruWsEssentialLoad(Map<String, Double> truWsEssentialLoad) {
    this.truWsEssentialLoad = truWsEssentialLoad;
  }

  public Map<String, Double> getAtuWsEssentialLoad() {
    return atuWsEssentialLoad;
  }

  public void setAtuWsEssentialLoad(Map<String, Double> atuWsEssentialLoad) {
    this.atuWsEssentialLoad = atuWsEssentialLoad;
  }

  public Map<String, Double> getAtuVars() {
    return atuVars;
  }

  public void setAtuVars(Map<String, Double> atuVars) {
    this.atuVars = atuVars;
  }

  public Map<String, Double> getAtuVarsEssentialLoad() {
    return atuVarsEssentialLoad;
  }

  public void setAtuVarsEssentialLoad(Map<String, Double> atuVarsEssentialLoad) {
    this.atuVarsEssentialLoad = atuVarsEssentialLoad;
  }

  public Map<String, UUID> getNodeToEfficiencyTableMap() {
    return nodeToEfficiencyTableMap;
  }

  public void setNodeToEfficiencyTableMap(Map<String, UUID> nodeToEfficiencyTableMap) {
    this.nodeToEfficiencyTableMap = nodeToEfficiencyTableMap;
  }

  public void aggregateAtuWs(String key, Double value) {
    if (value != null) {
      traceAggregateWithKey("ATU Ws", flightPhase, electricalPhase, summaryType, key, value);
      value = (atuWs.get(key) == null) ? value : atuWs.get(key) + value;
      atuWs.put(key, value);
    }
  }

  public void aggregateTruWs(String key, Double value) {
    if (value != null) {
      traceAggregateWithKey("TRU Ws", flightPhase, electricalPhase, summaryType, key, value);
      value = (truWs.get(key) == null) ? value : truWs.get(key) + value;
      truWs.put(key, value);
    }
  }

  public void aggregateW(Double value) {
    if (value != null) {
      traceAggregate("W", flightPhase, electricalPhase, summaryType, value);
      this.w += value;
    }
  }

  public void aggregateOriginalW(Double value) {
    if (value != null) {
      traceAggregate("Original W", flightPhase, electricalPhase, summaryType, value);
      this.originalW += value;
    }
  }

  public void aggregateAtuWsEssentialLoad(String key, Double value) {
    if (value != null) {
      traceAggregateWithKey(
          "ATU Essential Ws", flightPhase, electricalPhase, summaryType, key, value);
      value = (atuWsEssentialLoad.get(key) == null) ? value : atuWsEssentialLoad.get(key) + value;
      atuWsEssentialLoad.put(key, value);
    }
  }

  public void aggregateTruWsEssentialLoad(String key, Double value) {
    if (value != null) {
      traceAggregateWithKey(
          "TRU Essential Ws", flightPhase, electricalPhase, summaryType, key, value);
      value = (truWsEssentialLoad.get(key) == null) ? value : truWsEssentialLoad.get(key) + value;
      truWsEssentialLoad.put(key, value);
    }
  }

  public void aggregateWEssentialLoad(Double value) {
    if (value != null) {
      traceAggregate("Essential W", flightPhase, electricalPhase, summaryType, value);
      this.wEssentialLoad += value;
    }
  }

  public void aggregateOriginalWEssentialLoad(Double value) {
    if (value != null) {
      traceAggregate("Essential Original W", flightPhase, electricalPhase, summaryType, value);
      this.originalWEssentialLoad += value;
    }
  }

  public void aggregateAtuVars(String key, Double value) {
    if (value != null) {
      traceAggregateWithKey("ATU VARs", flightPhase, electricalPhase, summaryType, key, value);
      value = (atuVars.get(key) == null) ? value : atuVars.get(key) + value;
      atuVars.put(key, value);
    }
  }

  public void aggregateVar(Double value) {
    if (value != null) {
      traceAggregate("VAR", flightPhase, electricalPhase, summaryType, value);
      this.var += value;
    }
  }

  public void aggregateOriginalVar(Double value) {
    if (value != null) {
      traceAggregate("Original VAR", flightPhase, electricalPhase, summaryType, value);
      this.originalVar += value;
    }
  }

  public void aggregateAtuVarsEssentialLoad(String key, Double value) {
    if (value != null) {
      traceAggregate("ATU Essential VAR", flightPhase, electricalPhase, summaryType, value);
      value =
          (atuVarsEssentialLoad.get(key) == null) ? value : atuVarsEssentialLoad.get(key) + value;
      atuVarsEssentialLoad.put(key, value);
    }
  }

  public void aggregateVarEssentialLoad(Double value) {
    if (value != null) {
      traceAggregate("Essential VAR", flightPhase, electricalPhase, summaryType, value);
      this.varEssentialLoad += value;
    }
  }

  public void aggregateOriginalVarEssentialLoad(Double value) {
    if (value != null) {
      traceAggregate("Essential Original VAR", flightPhase, electricalPhase, summaryType, value);
      this.originalVarEssentialLoad += value;
    }
  }

  public Double getVa() {
    return LoadUtil.getVa(w, var);
  }

  public Double getPowerFactor() {
    return LoadUtil.getPowerFactor(w, var);
  }

  private void traceAggregate(
      String aggregateName,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      Double value) {
    if (logger.isTraceEnabled()) {
      logger.trace(
          "Aggregate {} {} {} {} {}",
          aggregateName,
          flightPhase,
          electricalPhase,
          summaryType,
          value);
    }
  }

  private void traceAggregateWithKey(
      String aggregateName,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      String key,
      Double value) {
    if (logger.isTraceEnabled()) {
      logger.trace(
          "Aggregate {} {} {} {} {} {}",
          aggregateName,
          flightPhase,
          electricalPhase,
          summaryType,
          key,
          value);
    }
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SummarizedLoad that = (SummarizedLoad) o;
    return isMaxImbalance == that.isMaxImbalance
        && isMaxPhaseLoad == that.isMaxPhaseLoad
        && Objects.equals(w, that.w)
        && Objects.equals(var, that.var)
        && Objects.equals(wEssentialLoad, that.wEssentialLoad)
        && Objects.equals(varEssentialLoad, that.varEssentialLoad)
        && Objects.equals(flightPhase, that.flightPhase)
        && Objects.equals(operatingMode, that.operatingMode)
        && electricalPhase == that.electricalPhase
        && summaryType == that.summaryType
        && units == that.units
        && Objects.equals(originalW, that.originalW)
        && Objects.equals(originalVar, that.originalVar)
        && Objects.equals(originalWEssentialLoad, that.originalWEssentialLoad)
        && Objects.equals(originalVarEssentialLoad, that.originalVarEssentialLoad)
        && Objects.equals(truWs, that.truWs)
        && Objects.equals(truWsEssentialLoad, that.truWsEssentialLoad)
        && Objects.equals(atuWs, that.atuWs)
        && Objects.equals(atuVars, that.atuVars)
        && Objects.equals(atuWsEssentialLoad, that.atuWsEssentialLoad)
        && Objects.equals(atuVarsEssentialLoad, that.atuVarsEssentialLoad)
        && Objects.equals(nodeToEfficiencyTableMap, that.nodeToEfficiencyTableMap);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        w,
        var,
        wEssentialLoad,
        varEssentialLoad,
        flightPhase,
        operatingMode,
        electricalPhase,
        summaryType,
        units,
        originalW,
        originalVar,
        originalWEssentialLoad,
        originalVarEssentialLoad,
        isMaxImbalance,
        isMaxPhaseLoad,
        truWs,
        truWsEssentialLoad,
        atuWs,
        atuVars,
        atuWsEssentialLoad,
        atuVarsEssentialLoad,
        nodeToEfficiencyTableMap);
  }
}
