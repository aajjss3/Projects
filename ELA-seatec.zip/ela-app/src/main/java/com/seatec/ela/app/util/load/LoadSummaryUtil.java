package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.enumeration.PseudoFlightPhase;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import javax.validation.constraints.NotNull;

class LoadSummaryUtil {
  static final double THREE_PHASE_SPLIT = 3d;

  // suppress default constructor for noninstantiability
  private LoadSummaryUtil() {
    throw new AssertionError();
  }

  static SummarizedLoad findOrCreateLoadSummary(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull Component component,
      @NotNull Load load) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(component, "component must not be null");
    Objects.requireNonNull(load, "load must not be null");

    ElectricalPhase electricalPhase = component.getElectricalPhase();
    String flightPhase = load.getFlightPhase();
    String operatingMode = load.getOperatingMode();

    return findOrCreateLoadSummary(
        loadSummaryMap, summaryType, electricalPhase, flightPhase, operatingMode, false, false);
  }

  static SummarizedLoad findOrCreateLoadSummary(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      ElectricalPhase electricalPhase,
      String flightPhase,
      String operatingMode,
      boolean isMaxImbalance,
      boolean isMaxPhaseLoad) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");

    LoadSummaryBucketKey key =
        new LoadSummaryBucketKey(
            summaryType,
            electricalPhase,
            flightPhase,
            operatingMode,
            isMaxImbalance,
            isMaxPhaseLoad);

    return loadSummaryMap.computeIfAbsent(
        key, k -> new SummarizedLoad(flightPhase, operatingMode, electricalPhase, summaryType));
  }

  static List<SummarizedLoad> findOrCreateLoadSummariesPhaseSplit(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull Load load) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(load, "load must not be null");

    String flightPhase = load.getFlightPhase();
    String operatingMode = load.getOperatingMode();

    return findOrCreateLoadSummariesPhaseSplit(
        loadSummaryMap, summaryType, flightPhase, operatingMode, false, false);
  }

  static List<SummarizedLoad> findOrCreateLoadSummariesPhaseSplit(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      String flightPhase,
      String operatingMode,
      boolean isMaxImbalance,
      boolean isMaxPhaseLoad) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");

    List<SummarizedLoad> loadSummaries = new ArrayList<>();

    Set<ElectricalPhase> splitPhases =
        EnumSet.of(ElectricalPhase.ACA, ElectricalPhase.ACB, ElectricalPhase.ACC);

    for (ElectricalPhase splitPhase : splitPhases) {
      SummarizedLoad loadSummarySplitPhase =
          findOrCreateLoadSummary(
              loadSummaryMap,
              summaryType,
              splitPhase,
              flightPhase,
              operatingMode,
              isMaxImbalance,
              isMaxPhaseLoad);
      loadSummaries.add(loadSummarySplitPhase);
    }

    return loadSummaries;
  }

  static SummarizedLoad findOrCreateLoadSummary(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      Component component,
      PseudoFlightPhase pseudoFlightPhase) {
    return findOrCreateLoadSummary(
        loadSummaryMap,
        summaryType,
        component.getElectricalPhase(),
        pseudoFlightPhase.toString(),
        null,
        false,
        false);
  }

  static List<SummarizedLoad> findOrCreateLoadSummariesPhaseSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      PseudoFlightPhase pseudoFlightPhase) {
    return findOrCreateLoadSummariesPhaseSplit(
        loadSummaryMap, summaryType, pseudoFlightPhase.toString(), null, false, false);
  }

  static void validateElectricalPhase(
      ElectricalPhase expectedElectricalPhase, SummarizedLoad loadSummary) {
    if (!expectedElectricalPhase.equals(loadSummary.getElectricalPhase())) {
      throw new IllegalArgumentException(
          String.format(
              "LoadSummary electrical phase: expected: %s, found: %s",
              expectedElectricalPhase, loadSummary.getElectricalPhase()));
    }
  }
}
