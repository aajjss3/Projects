package com.seatec.ela.app.aop.userevent;

import com.google.gson.Gson;
import com.seatec.ela.app.util.RequestUtil;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.CodeSignature;

/**
 * Logconfig configures which controllers have UserEvent logging and the basic logging content for
 * those events
 *
 * @see LogConfig
 * @see LogUserTrackConfig
 */
public class LogDetail {
  static final String INSTANT = "instant";
  static final String PRINCIPAL_USER_ID = "principalUserId";
  static final String USER_IP_ADDR = "userIpAddress";
  static final String REQUEST_URI = "requestUri";
  static final String REQUEST_METHOD = "requestMethod";
  static final String ERROR_MESSAGE = "error_message";
  static final String OUTPUT = "output";
  static final String PARAM_AUTHOR = "author";
  static final String PARAM_ID = "id";
  static final String PARAM_NAME = "name";
  static final String PARAM_TITLE = "title";
  static final String PARAM_AIRCRAFT_SHIPNO = "aircraftShipNo";
  static final String PARAM_AIRCRAFT_ID = "aircraftId";
  static final String PARAM_AIRCRAFT_CLONE_ID = "aircraftCloneId";

  /**
   * @param request the http request
   * @param config the LogUserTrtackConfig
   * @param joinPoint the JoinPoint
   * @param returnObject the Object returned from the joinPoint
   * @param errorMessage error Message from the joinPoint
   * @return detailed message for the log
   */
  public static String createDetail(
      HttpServletRequest request,
      LogUserTrackConfig config,
      ProceedingJoinPoint joinPoint,
      Object returnObject,
      String errorMessage) {
    LinkedHashMap<String, String> data = new LinkedHashMap<>();
    Object[] arguments = joinPoint.getArgs();
    data.put(INSTANT, Instant.now().toString());
    data.put(PRINCIPAL_USER_ID, RequestUtil.getUserIdFromRequest(request));
    data.put(USER_IP_ADDR, getClientIp(request));
    data.put(REQUEST_URI, request.getRequestURI());
    data.put(REQUEST_METHOD, request.getMethod());
    if (errorMessage != null) {
      data.put(ERROR_MESSAGE, errorMessage);
    }
    int index = 0;
    for (String paramName : findParamNames(config, joinPoint)) {
      if (index >= arguments.length) continue;
      Object parm = arguments[index];
      fillParameterData(data, paramName, parm);
      index++;
    }
    if (returnObject != null) {
      fillParameterData(data, OUTPUT, returnObject);
    }
    Gson gson = new Gson();
    return gson.toJson(data);
  }

  private static String[] findParamNames(LogUserTrackConfig config, ProceedingJoinPoint joinPoint) {
    String[] result = config.getParamNames();
    if (result == null) {
      CodeSignature codeSignature = (CodeSignature) joinPoint.getSignature();
      result = codeSignature.getParameterNames();
      for (int i = 0; i < result.length; i++) {
        result[i] = StringUtils.capitalize(result[i]);
      }
    }
    return result;
  }

  private static void fillParameterData(
      LinkedHashMap<String, String> data, String key, Object parm) {
    if (parm instanceof String) {
      data.put(key, (String) parm);
    } else if (parm instanceof Long) {
      data.put(key, ((Long) parm).toString());
    } else if (parm instanceof Boolean) {
      data.put(key, ((Boolean) parm).toString());
    } else if (parm instanceof UUID) {
      data.put(key, ((UUID) parm).toString());
    } else {
      if (parm instanceof UserTrackIdLong) {
        data.put(PARAM_ID, String.valueOf(((UserTrackIdLong) parm).getId()));
      }
      if (parm instanceof UserTrackIdUUID) {
        UUID uuidId = ((UserTrackIdUUID) parm).getId();
        if (uuidId != null) {
          data.put(PARAM_ID, ((UserTrackIdUUID) parm).getId().toString());
        } else {
          data.put(PARAM_ID, "null");
        }
      }
      if (parm instanceof UserTrackIdString) {
        data.put(PARAM_ID, ((UserTrackIdString) parm).getId());
      }
      if (parm instanceof UserTrackAuthor) {
        data.put(PARAM_AUTHOR, ((UserTrackAuthor) parm).getAuthor());
      }
      if (parm instanceof UserTrackTitle) {
        data.put(PARAM_TITLE, ((UserTrackTitle) parm).getTitle());
      }
      if (parm instanceof UserTrackName) {
        data.put(PARAM_NAME, ((UserTrackName) parm).getName());
      }
      if (parm instanceof UserTrackShipNo) {
        data.put(PARAM_AIRCRAFT_SHIPNO, ((UserTrackShipNo) parm).getAircraftShipNo());
      }
      if (parm instanceof UserTrackAircraftIdLong) {
        data.put(
            PARAM_AIRCRAFT_ID, String.valueOf(((UserTrackAircraftIdLong) parm).getAircraftId()));
      }
      if (parm instanceof UserTrackedCloneAircraftIdLong) {
        data.put(
            PARAM_AIRCRAFT_CLONE_ID,
            String.valueOf(((UserTrackedCloneAircraftIdLong) parm).getCloneAircraftId()));
      }
    }
  }

  private static String getClientIp(HttpServletRequest request) {
    String remoteAddr = "";
    if (request != null) {
      // Note: 'server.use-forward-headers=true' means stripping header so this case uses
      // RemoteAddress
      remoteAddr = request.getHeader("X-Forwarded-For");
      if (remoteAddr == null || "".equals(remoteAddr)) {
        remoteAddr = "RemoteAddress: " + request.getRemoteAddr();
      }
    }
    return remoteAddr;
  }
}
