package com.seatec.ela.app.exception;

import org.slf4j.event.Level;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception to throw when a Http Status BAD_REQUEST (400) is desired.
 *
 * @see CustomException for furthur documentation
 * @author alan
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BadRequestException extends CustomException {

  public BadRequestException(String message) {
    super(message);
  }

  public BadRequestException(String message, Level logLevel) {
    super(message, logLevel);
  }

  public BadRequestException(String message, Level logLevel, Exception rootCause) {
    super(message, logLevel, rootCause);
  }
}
