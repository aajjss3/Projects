package com.seatec.ela.app.util.csv;

/* example data:
PERM/INTER;C;S;BUSBAR;PHASE;LOAD;IDENT.;PANEL;ATA 100;D E S I G N A T I O N ;NOMINAL POWER;GROUND;START;ROLL;T/OFF;CLIMB;CRUISE;DESC;LAND;TAXI;MODIFIED;COMMENT
P; ; ;1IWPP; ;MAXI;4PU1;125VU;2432;TR1/CNTOR/SPLY;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;;
P; ; ;1IWPP; ;OPERATIONAL;4PU1;125VU;2432;TR1/CNTOR/SPLY;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;17.0;;
 */

import com.opencsv.bean.CsvBindByPosition;
import java.util.regex.Pattern;

public class AirbusCsv {
  static Pattern intermittentPattern = Pattern.compile("^I");
  static Pattern clipsedPattern = Pattern.compile("^C");
  static Pattern sheddablePattern = Pattern.compile("^S");
  static Pattern securityPattern = Pattern.compile("^(=|\\+|-|@).*");
  static Pattern numberPattern = Pattern.compile("(^[0-9,., ]*$)");
  static Pattern phasePattern = Pattern.compile("(^[A,B,C, ]*$)");
  static Pattern loadPattern = Pattern.compile("(MAXI|OPERATIONAL)");
  static Pattern maxiPattern = Pattern.compile("(MAXI)");
  static Pattern operationalPattern = Pattern.compile("(OPERATIONAL)");
  static Pattern headerPattern =
      Pattern.compile(
          "(PERM\\/INTER|C$|S$|BUSBAR|PHASE|LOAD|IDENT.|PANEL|ATA 100|"
              + "D E S I G N A T I O N|NOMINAL POWER|GROUND|START|ROLL|T/OFF|CLIMB|CRUISE|DESC|LAND|TAXI|MODIFIED|COMMENT).*");
  /*      "PERM/INTER", "C", "S", "BUSBAR", "PHASE", "LOAD", "IDENT.", "PANEL",
  "ATA 100","D E S I G N A T I O N", "NOMINAL POWER", "GROUND","START",
  "ROLL", "T/OFF", "CLIMB", "CRUISE", "DESC", "LAND","TAXI","MODIFIED", "COMMENT"}; */
  @CsvBindByPosition(position = 0)
  private String intermittent;

  @CsvBindByPosition(position = 1)
  private String clipsed;

  @CsvBindByPosition(position = 2)
  private String sheddable;

  @CsvBindByPosition(position = 3)
  private String busBar;

  @CsvBindByPosition(position = 4)
  private String phase;

  @CsvBindByPosition(position = 5)
  private String load;

  @CsvBindByPosition(position = 6)
  private String identifier;

  @CsvBindByPosition(position = 7)
  private String panel;

  @CsvBindByPosition(position = 8)
  private String atacode;

  @CsvBindByPosition(position = 9)
  private String designator;

  @CsvBindByPosition(position = 10)
  private String nominalPower;

  @CsvBindByPosition(position = 11)
  private String groundStage;

  @CsvBindByPosition(position = 12)
  private String startStage;

  @CsvBindByPosition(position = 13)
  private String rollStage;

  @CsvBindByPosition(position = 14)
  private String takeoffStage;

  @CsvBindByPosition(position = 15)
  private String climbStage;

  @CsvBindByPosition(position = 16)
  private String cruiseStage;

  @CsvBindByPosition(position = 17)
  private String descendStage;

  @CsvBindByPosition(position = 18)
  private String landStage;

  @CsvBindByPosition(position = 19)
  private String taxiStage;

  @CsvBindByPosition(position = 20)
  private String modified;

  @CsvBindByPosition(position = 21)
  private String comment;

  public String getIntermittent() {
    return intermittent;
  }

  public void setIntermittent(String intermittent) {
    this.intermittent = intermittent;
  }

  public String getClipsed() {
    return clipsed;
  }

  public void setClipsed(String clipsed) {
    this.clipsed = clipsed;
  }

  public String getSheddable() {
    return sheddable;
  }

  public void setSheddable(String sheddable) {
    this.sheddable = sheddable;
  }

  public String getBusBar() {
    return busBar;
  }

  public void setBusBar(String busBar) {
    this.busBar = busBar;
  }

  public String getPhase() {
    return phase;
  }

  public void setPhase(String phase) {
    this.phase = phase;
  }

  public String getLoad() {
    return load;
  }

  public void setLoad(String load) {
    this.load = load;
  }

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public String getAtacode() {
    return atacode;
  }

  public void setAtacode(String atacode) {
    this.atacode = atacode;
  }

  public String getDesignator() {
    return designator;
  }

  public void setDesignator(String designator) {
    this.designator = designator;
  }

  public String getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(String nominalPower) {
    this.nominalPower = nominalPower;
  }

  public String getGroundStage() {
    return groundStage;
  }

  public void setGroundStage(String groundStage) {
    this.groundStage = groundStage;
  }

  public String getStartStage() {
    return startStage;
  }

  public void setStartStage(String startStage) {
    this.startStage = startStage;
  }

  public String getRollStage() {
    return rollStage;
  }

  public void setRollStage(String rollStage) {
    this.rollStage = rollStage;
  }

  public String getTakeoffStage() {
    return takeoffStage;
  }

  public void setTakeoffStage(String takeoffStage) {
    this.takeoffStage = takeoffStage;
  }

  public String getClimbStage() {
    return climbStage;
  }

  public void setClimbStage(String climbStage) {
    this.climbStage = climbStage;
  }

  public String getCruiseStage() {
    return cruiseStage;
  }

  public void setCruiseStage(String cruiseStage) {
    this.cruiseStage = cruiseStage;
  }

  public String getDescendStage() {
    return descendStage;
  }

  public void setDescendStage(String descendStage) {
    this.descendStage = descendStage;
  }

  public String getLandStage() {
    return landStage;
  }

  public void setLandStage(String landStage) {
    this.landStage = landStage;
  }

  public String getTaxiStage() {
    return taxiStage;
  }

  public void setTaxiStage(String taxiStage) {
    this.taxiStage = taxiStage;
  }

  public String getModified() {
    return modified;
  }

  public void setModified(String modified) {
    this.modified = modified;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  // Valid Checks

  boolean isSecurityValid() {
    return (isFieldSecurityValid(intermittent)
        && isFieldSecurityValid(clipsed)
        && isFieldSecurityValid(sheddable)
        && isFieldSecurityValid(busBar)
        && isFieldSecurityValid(phase)
        && isFieldSecurityValid(load)
        && isFieldSecurityValid(identifier)
        && isFieldSecurityValid(panel)
        && isFieldSecurityValid(atacode)
        && isFieldSecurityValid(designator)
        && isFieldSecurityValid(nominalPower)
        && isFieldSecurityValid(groundStage)
        && isFieldSecurityValid(startStage)
        && isFieldSecurityValid(rollStage)
        && isFieldSecurityValid(takeoffStage)
        && isFieldSecurityValid(climbStage)
        && isFieldSecurityValid(cruiseStage)
        && isFieldSecurityValid(descendStage)
        && isFieldSecurityValid(landStage)
        && isFieldSecurityValid(taxiStage)
        && isFieldSecurityValid(modified)
        && isFieldSecurityValid(comment));
  }

  private boolean isFieldSecurityValid(String result) {
    return result == null || !securityPattern.matcher(result.trim()).matches();
  }

  boolean isNumbersValid() {
    return (isFieldNumberValid(nominalPower)
        && isFieldNumberValid(groundStage)
        && isFieldNumberValid(startStage)
        && isFieldNumberValid(rollStage)
        && isFieldNumberValid(takeoffStage)
        && isFieldNumberValid(climbStage)
        && isFieldNumberValid(cruiseStage)
        && isFieldNumberValid(descendStage)
        && isFieldNumberValid(landStage)
        && isFieldNumberValid(taxiStage));
  }

  private boolean isFieldNumberValid(String result) {
    return result != null && numberPattern.matcher(result).matches();
  }

  boolean isLoadValid() {
    return load != null && loadPattern.matcher(load).matches();
  }

  boolean isPhaseValid() {
    return phase != null && phasePattern.matcher(phase).matches();
  }

  boolean isValid() {
    return isNumbersValid() && isLoadValid() && isPhaseValid();
  }

  boolean isHeaderValid() {
    return isFieldHeaderValid(intermittent)
        && isFieldHeaderValid(clipsed)
        && isFieldHeaderValid(sheddable)
        && isFieldHeaderValid(busBar)
        && isFieldHeaderValid(phase)
        && isFieldHeaderValid(load)
        && isFieldHeaderValid(identifier)
        && isFieldHeaderValid(panel)
        && isFieldHeaderValid(atacode)
        && isFieldHeaderValid(designator)
        && isFieldHeaderValid(nominalPower)
        && isFieldHeaderValid(groundStage)
        && isFieldHeaderValid(startStage)
        && isFieldHeaderValid(rollStage)
        && isFieldHeaderValid(takeoffStage)
        && isFieldHeaderValid(climbStage)
        && isFieldHeaderValid(cruiseStage)
        && isFieldHeaderValid(descendStage)
        && isFieldHeaderValid(landStage)
        && isFieldHeaderValid(taxiStage)
        && isFieldHeaderValid(modified)
        && isFieldHeaderValid(comment);
  }

  private boolean isFieldHeaderValid(String result) {
    return result != null && headerPattern.matcher(result).matches();
  }

  boolean isIntermittent() {
    return intermittentPattern.matcher(intermittent).matches();
  }

  boolean isClipsed() {
    return clipsedPattern.matcher(intermittent).matches();
  }

  boolean isSheddable() {
    return sheddablePattern.matcher(intermittent).matches();
  }

  boolean isValidBusBar() {
    return sheddablePattern.matcher(intermittent).matches();
  }

  boolean isMaxi() {
    return load != null && maxiPattern.matcher(load).matches();
  }

  boolean isOperational() {
    return load != null && operationalPattern.matcher(load).matches();
  }
}
