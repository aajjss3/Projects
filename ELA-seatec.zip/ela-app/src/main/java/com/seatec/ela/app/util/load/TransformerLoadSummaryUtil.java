package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.Map;

class TransformerLoadSummaryUtil {

  static void calcLoadSummary(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable,
      ITransformerAggregator transformerAggregator) {

    ElectricalPhase electricalPhase = component.getElectricalPhase();

    String flightPhase = load.getFlightPhase();
    String operatingMode = load.getOperatingMode();

    SummarizedLoad loadSummary =
        LoadSummaryUtil.findOrCreateLoadSummary(
            loadSummaryMap, summaryType, electricalPhase, flightPhase, operatingMode, false, false);
    transformerAggregator.aggregateLoadSummary(
        loadSummary,
        loadSummaryOptions,
        component,
        load,
        rootTransformerNodeIdentifier,
        efficiencyTable);
  }
}
