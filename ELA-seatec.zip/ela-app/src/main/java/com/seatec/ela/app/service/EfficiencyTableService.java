package com.seatec.ela.app.service;

import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.repository.EfficiencyTableRepo;
import com.seatec.ela.app.service.contract.IEfficiencyTableService;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class EfficiencyTableService implements IEfficiencyTableService {

  private final EfficiencyTableRepo efficiencyTableRepo;

  @Autowired
  public EfficiencyTableService(EfficiencyTableRepo efficiencyTableRepo) {
    this.efficiencyTableRepo = efficiencyTableRepo;
  }

  @Cacheable("efficiencyTables")
  public List<EfficiencyTable> findAll() {
    return efficiencyTableRepo.findAll();
  }

  @Cacheable("efficiencyTablesAsMap")
  public Map<UUID, EfficiencyTable> findAllAsMap() {
    return efficiencyTableRepo.findAll().stream()
        .collect(Collectors.toMap(EfficiencyTable::getId, Function.identity()));
  }
}
