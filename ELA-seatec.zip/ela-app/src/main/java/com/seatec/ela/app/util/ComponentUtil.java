package com.seatec.ela.app.util;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;

public class ComponentUtil {

  // suppress default constructor for noninstantiability
  private ComponentUtil() {
    throw new AssertionError();
  }

  public static boolean isEssential(Component component) {
    return component.getSheddable() == null || !component.getSheddable();
  }

  private static boolean isConnectedLoadMissing(Component component) {
    return component.getConnectedLoadVa() == null || component.getConnectedLoadPf() == null;
  }

  public static double getConnectedLoadW(Component component) {
    return isConnectedLoadMissing(component)
        ? 0d
        : LoadUtil.getW(component.getConnectedLoadVa(), component.getConnectedLoadPf());
  }

  public static double getConnectedLoadVar(Component component) {
    return isConnectedLoadMissing(component)
        ? 0d
        : LoadUtil.getVar(component.getConnectedLoadVa(), component.getConnectedLoadPf());
  }

  public static void validateElectricalPhase(
      ElectricalPhase expectedElectricalPhase, Component component) {
    if (!expectedElectricalPhase.equals(component.getElectricalPhase())) {
      throw new IllegalArgumentException(
          String.format(
              "Component electrical phase: expected: %s, found: %s",
              expectedElectricalPhase, component.getElectricalPhase()));
    }
  }
}
