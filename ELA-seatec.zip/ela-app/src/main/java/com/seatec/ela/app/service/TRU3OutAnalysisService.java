package com.seatec.ela.app.service;

import com.seatec.ela.app.config.ClientConfig.Boeing;
import com.seatec.ela.app.dto.analysis.Analysis;
import com.seatec.ela.app.dto.analysis.TRU3OutAnalysis;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TRU3OutAnalysisService {

  private static final double BATTERY_CHARGE_RATING = 50d;
  private static final double NODE_VOLTAGE = 28d;
  private static final String BB = "BB";
  private static final String HB = "HB";
  private static final String SHB = "SHB";
  private String[] tru1tru2Nodes = {BB, HB, SHB};

  @Autowired private ElaRepository elaRepository;

  private static Logger logger = LoggerFactory.getLogger(TRU3OutAnalysisService.class);

  public void setTRU3OutAnalysis(Analysis analysis, List<Node> nodes, Long elaId) {

    try {
      // allLoads is a temp bucket (map) that contains the loads per node per flight phase
      // key is the flight phase. value is another map that contains the node name as the key and
      // the load in watts as the value
      Map<String, Map<String, Double>> allLoads = new HashMap<>();

      String aircraftShipNo = elaRepository.findById(elaId).get().getAircraft().getAircraftShipNo();

      for (int inx = 0; inx < tru1tru2Nodes.length; inx++) {
        String name = tru1tru2Nodes[inx];
        Node node =
            nodes.stream()
                .filter(n -> n.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElseThrow(
                    () ->
                        new NotFoundException(
                            "Unable to find a node with the name: '"
                                + name
                                + "', for aircraft ship no: "
                                + aircraftShipNo,
                            Level.ERROR));

        List<SummarizedLoad> loads =
            node.getSummarizedLoads().stream()
                .filter(
                    l ->
                        l.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN
                            && (l.getFlightPhase().equalsIgnoreCase(Boeing.CRUISE.toString())
                                || l.getFlightPhase().equalsIgnoreCase(Boeing.HOLD_LAND.toString())
                                || l.getFlightPhase()
                                    .equalsIgnoreCase(Boeing.TAKEOFF_CLIMB.toString())))
                .collect(Collectors.toList());

        if (loads.isEmpty()) {
          throw new NotFoundException(
              "Unable to find any summarized loads for either cruise, hold_land, or takeoff for the node with the name: '"
                  + name
                  + "', for aircraft ship no: "
                  + aircraftShipNo,
              Level.ERROR);
        }

        for (SummarizedLoad load : loads) {
          Map<String, Double> nodeLoads = allLoads.get(load.getFlightPhase());
          if (nodeLoads == null) {
            nodeLoads = new HashMap<String, Double>();
            allLoads.put(load.getFlightPhase(), nodeLoads);
          }
          nodeLoads.put(name, load.getW());
        }
      }

      // determine the largest total load and its flight phase
      double worseCaseBB = 0d;
      double worseCaseHB = 0d;
      double worseCaseSHB = 0d;
      String flightPhase = null;
      for (Map.Entry<String, Map<String, Double>> entry : allLoads.entrySet()) {
        Double nodeTotal = entry.getValue().values().stream().reduce(0.0d, Double::sum);
        if (nodeTotal >= worseCaseBB + worseCaseHB + worseCaseSHB) {
          worseCaseBB = entry.getValue().get(BB);
          worseCaseHB = entry.getValue().get(HB);
          worseCaseSHB = entry.getValue().get(SHB);
          flightPhase = entry.getKey();
        }
      }

      TRU3OutAnalysis tru3 = new TRU3OutAnalysis();
      tru3.setBatteryChargeRating(BATTERY_CHARGE_RATING);
      tru3.setBbLoadInAmps(LoadUtil.getAmps(worseCaseBB, NODE_VOLTAGE));
      tru3.setHbLoadInAmps(LoadUtil.getAmps(worseCaseHB, NODE_VOLTAGE));
      tru3.setShbLoadInAmps(LoadUtil.getAmps(worseCaseSHB, NODE_VOLTAGE));
      double totalLoadInAmps =
          LoadUtil.getAmps((worseCaseBB + worseCaseHB + worseCaseSHB), NODE_VOLTAGE);
      tru3.setTotalLoadInAmps(totalLoadInAmps);
      double rating = (totalLoadInAmps / BATTERY_CHARGE_RATING) * 100d;
      tru3.setRating(rating);
      tru3.setFlightPhase(flightPhase);

      AnalysisStatus status =
          ElaAnalysisService.determineStatus(
              rating, analysis.getThresholdUpperLimit(), analysis.getThresholdLowerLimit());
      tru3.setStatus(status);

      analysis.setDegradedStatus(
          ElaAnalysisService.getWorstCaseStatus(status, analysis.getDegradedStatus()));

      analysis.getDegradedAnalysis().setTru3OutAnalysis(tru3);

    } catch (Exception e) {
      logger.error(
          "Unable to determine the TRU3 Out analysis. See the stacktrace below for the reason: ",
          e);
    }
  }
}
