package com.seatec.ela.app.model.structure;

public enum VoltageType {
  AC3,
  AC,
  DC
}
