package com.seatec.ela.app.model.project.change;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.base.BaseEntity;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.validator.annotation.NodeOrComponentChange;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "change")
@NodeOrComponentChange
public class Change extends BaseEntity {

  @Enumerated(EnumType.STRING)
  @Column(length = 15)
  @NotNull(message = "{field.required}")
  private ActionType action;

  @Column(name = "node_name", length = 127)
  private String nodeName;

  @Column(name = "component_elect_ident", length = 127)
  private String componentElectIdent;

  @Column(length = 127)
  private String changer;

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "change_group_id", insertable = true, updatable = false, nullable = false)
  private ChangeGroup changeGroup;

  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "node_change_id", nullable = true)
  @Valid
  private NodeChange nodeChange;

  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinColumn(name = "component_change_id", nullable = true)
  @Valid
  private ComponentChange componentChange;

  @OneToMany(
      mappedBy = "change",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<ChangeComment> comments = new ArrayList<>();

  public ActionType getAction() {
    return action;
  }

  public void setAction(ActionType action) {
    this.action = action;
  }

  public String getNodeName() {
    return nodeName;
  }

  public void setNodeName(String nodeName) {
    this.nodeName = nodeName;
  }

  public String getComponentElectIdent() {
    return componentElectIdent;
  }

  public void setComponentElectIdent(String componentElectIdent) {
    this.componentElectIdent = componentElectIdent;
  }

  public NodeChange getNodeChange() {
    return nodeChange;
  }

  public void setNodeChange(NodeChange nodeChange) {
    this.nodeChange = nodeChange;
  }

  public ComponentChange getComponentChange() {
    return componentChange;
  }

  public void setComponentChange(ComponentChange componentChange) {
    this.componentChange = componentChange;
  }

  public ChangeGroup getChangeGroup() {
    return changeGroup;
  }

  public void setChangeGroup(ChangeGroup changeGroup) {
    this.changeGroup = changeGroup;
  }

  public String getChanger() {
    return changer;
  }

  public void setChanger(String changer) {
    this.changer = changer;
  }

  public List<ChangeComment> getComments() {
    return comments;
  }

  public void setComments(List<ChangeComment> comments) {
    this.comments = comments;
  }

  public void addComment(ChangeComment comment) {
    comments.add(comment);
    comment.setChange(this);
  }

  public void removeComment(ChangeComment comment) {
    comments.remove(comment);
    comment.setChange(null);
  }
}
