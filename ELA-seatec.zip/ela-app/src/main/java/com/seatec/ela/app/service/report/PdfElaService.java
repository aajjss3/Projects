package com.seatec.ela.app.service.report;

import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DATE_TIME_LONG;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DECIMAL_FORMAT_1_PLACE;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DECIMAL_FORMAT_2_PLACES;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DECIMAL_FORMAT_3_PLACES;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.ITALIC_FONT;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.PAGE_H2_FONT;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.createBaseTable;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import com.seatec.ela.app.model.*;
import com.seatec.ela.app.service.EfficiencyTableService;
import com.seatec.ela.app.service.NodeService;
import com.seatec.ela.app.service.contract.report.IPdfElaService;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.pdf.AlternatingBackground;
import com.seatec.ela.app.util.pdf.PdfFormatUtil;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Contains PDF Service helper methods for generating ELA and Project reports Includes theming,
 * styles, formatting, analysis, history, etc.
 */
@Service
public class PdfElaService implements IPdfElaService {
  private static final String AMPS_LABEL = "Amps";
  private static final String KVA_LABEL = "kVA";
  private static final String VA_LABEL = "VA";
  private static final String CONNECTED_LOAD = "ConnectedLoad";
  private static final String CONNECTED_LOAD_LABEL = "Connected Load";
  private static final String NOMINAL_POWER = "NominalPower";
  private static final String NOMINAL_CURRENT_LABEL = "Nominal Current";
  private static final String NOMINAL_POWER_LABEL = "Nominal Power";
  private static final String WATTS_LABEL = "W";
  private static final String FLIGHT_PHASE_TITLE = "FLIGHT PHASE";
  private static final String ELECTRICAL_PHASE_TITLE = "ELECTRICAL PHASE IMBALANCE";

  private static final String[] COMPONENT_COLUMNS = {
    "Elect ID", "Intermittent", "Clip", "Sheddable", "Panel", "ATA", "Designation"
  };

  @Autowired private PdfFormatUtil pdfFormatUtil;

  @Autowired private NodeService nodeService;

  @Autowired private EfficiencyTableService efficiencyTableService;

  @Autowired private PdfAnalysisService pdfAnalysisService;

  public PdfPTable generateCoverPageForEla(
      String shipNo, String reportName, String faaElaName, boolean faaReport) {
    PdfPTable pdfPTable = PdfFormatUtil.createCoverPageTable();

    Paragraph paragraph = new Paragraph();

    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Phrase("Aircraft Ship Number: " + shipNo, PAGE_H2_FONT));

    // created date
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Phrase("Created On: " + DATE_TIME_LONG.format(Instant.now()), ITALIC_FONT));

    // CFR disclaimer
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(new Chunk(Chunk.NEWLINE));
    paragraph.add(
        new Phrase(
            "The information provided in this analysis has been developed in compliance with CFRs 25.1165(b), 25.1309, and 25.1351 ",
            ITALIC_FONT));

    // title row
    if (faaReport) {
      PdfPCell title =
          pdfFormatUtil.getElaCoverPageCellWithParagraph(paragraph, faaElaName, reportName);
      pdfPTable.addCell(title);
    } else {
      PdfPCell title = pdfFormatUtil.getElaCoverPageCellWithParagraph(paragraph, null, reportName);
      pdfPTable.addCell(title);
    }

    return pdfPTable;
  }

  public PdfPTable generateShipInfo(Ela ela) {
    Aircraft aircraft = ela.getAircraft();
    int numColumns = 7;

    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable(numColumns);

    PdfPCell shipTitleCell = pdfFormatUtil.flightPhaseTableTitleRowCell("Details", numColumns);
    pdfPTable.addCell(shipTitleCell);

    // add header
    PdfPCell shipnoHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Ship Number", 8f);
    pdfPTable.addCell(shipnoHeader);

    PdfPCell modelHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Model", 8f);
    pdfPTable.addCell(modelHeader);

    PdfPCell registrationHeader =
        pdfFormatUtil.flightPhaseTableHeaderRowCell("Registration Number", 8f);
    pdfPTable.addCell(registrationHeader);

    PdfPCell serialNumberHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Serial Number", 8f);
    pdfPTable.addCell(serialNumberHeader);

    PdfPCell lineNumberHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Line Number", 8f);
    pdfPTable.addCell(lineNumberHeader);

    PdfPCell variableNumberHeader =
        pdfFormatUtil.flightPhaseTableHeaderRowCell("Variable Number", 8f);
    pdfPTable.addCell(variableNumberHeader);

    PdfPCell statusHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Status", 8f);
    pdfPTable.addCell(statusHeader);

    PdfPCell shipNoCell = PdfFormatUtil.createTextCell(new Phrase(aircraft.getAircraftShipNo()));
    shipNoCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(shipNoCell);

    PdfPCell modelCell = PdfFormatUtil.createTextCell(new Phrase(aircraft.getFleet().getName()));
    modelCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(modelCell);

    PdfPCell registrationCell =
        PdfFormatUtil.createTextCell(new Phrase(aircraft.getRegistrationNumber()));
    registrationCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(registrationCell);

    PdfPCell serialNumCell = PdfFormatUtil.createTextCell(new Phrase(aircraft.getSerialNumber()));
    serialNumCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(serialNumCell);

    PdfPCell lineNumCell = PdfFormatUtil.createTextCell(new Phrase(aircraft.getLineNumber()));
    lineNumCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(lineNumCell);

    PdfPCell VariableNumCell =
        PdfFormatUtil.createTextCell(new Phrase(aircraft.getVariableNumber()));
    VariableNumCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(VariableNumCell);

    PdfPCell statusCell = pdfAnalysisService.setAircraftStatusCell(ela.getId());
    statusCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(statusCell);

    return pdfPTable;
  }

  public void generateElaSummary(
      Document document,
      List<Node> nodesInLevel,
      List<Node> flatNodeList,
      List<String> operatingModes,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing) {
    for (Node nodeInLevel : nodesInLevel) {
      Optional<Node> nodeEntity =
          flatNodeList.stream().filter(fnl -> fnl.getId().equals(nodeInLevel.getId())).findFirst();

      if (nodeEntity.isPresent()) {
        Node node = nodeEntity.get();

        for (String operatingMode : operatingModes) {
          PdfPTable operatingModeTable = createBaseTable();

          switch (node.getNodeType()) {
            case BUS:
              createBusSummary(document, node, operatingMode, flightPhases, isBoeing);
              break;
            case GENERATOR:
              createGeneratorSummary(document, node, operatingMode, flightPhases, isBoeing);
              break;
            case ATU:
            case TRU:
              createTransformerSummary(document, node, operatingMode, flightPhases, isBoeing);
              break;
            case BATTERY:
            case APU:
            case STANDBY_GEN:
            case INVERTER:
              // append node name + node breadcrumb row
              operatingModeTable.addCell(getNodeHeaderTableRow(node, operatingMode));

              PdfPTable textTable =
                  PdfFormatUtil.createTextTable(
                      "The manufacturer does not allow modification of loads on emergency busbars, hot busbars or technical busbars supplied by emergency sources; therefore, no electrical load analysis is necessary. Reference methodology document for additional details.");
              operatingModeTable.addCell(textTable);

              operatingModeTable.addCell(PdfFormatUtil.createBlankRow(1));
              document.add(operatingModeTable);
              break;
          }

          // insert page break
          document.newPage();
        }

        // recursive call
        if (!node.getSubNodes().isEmpty()) {
          generateElaSummary(
              document, node.getSubNodes(), flatNodeList, operatingModes, flightPhases, isBoeing);
        }
      }
    }
  }

  public PdfPTable generateShipSummary(Ela ela) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();
    pdfPTable.setKeepTogether(false);

    List<FlightPhaseDto> flightPhases = ela.getAircraft().getFleet().getFlightPhases();
    List<String> operatingModes = ela.getAircraft().getFleet().getOperatingModes();

    // remove batterySupplied phases
    flightPhases = excludeBatterySuppliedFlightPhases(flightPhases);

    int numberOfColumnsInTable = flightPhases.size() + 1;

    // iterate thru operating modes
    for (String operatingMode : operatingModes) {
      // table
      PdfPTable operatingModeTable = PdfFormatUtil.createBaseTable(numberOfColumnsInTable);
      PdfPTable phaseBalanceTable = PdfFormatUtil.createBaseTable(4);
      PdfPTable phaseImbalanceTable = PdfFormatUtil.createBaseTable(2);

      // table > title
      PdfPCell titleRowCell = PdfFormatUtil.getBlankCell();
      titleRowCell.setColspan(numberOfColumnsInTable);
      titleRowCell.addElement(new Phrase(PdfFormatUtil.convertOperatingModeText(operatingMode)));
      operatingModeTable.addCell(titleRowCell);

      PdfPCell balanceTitleRowCell = PdfFormatUtil.getBlankCell();
      balanceTitleRowCell.setColspan(4);
      balanceTitleRowCell.addElement(new Phrase(FLIGHT_PHASE_TITLE));
      phaseBalanceTable.addCell(balanceTitleRowCell);

      PdfPCell imbalanceTitleRowCell = PdfFormatUtil.getBlankCell();
      imbalanceTitleRowCell.setColspan(2);
      imbalanceTitleRowCell.addElement(new Phrase(ELECTRICAL_PHASE_TITLE));
      phaseImbalanceTable.addCell(imbalanceTitleRowCell);

      // table > body
      List<Node> generatorNodes = getGenerators(ela);

      if (!generatorNodes.isEmpty()) {
        for (Node generatorNode : generatorNodes) {
          if (isDisplayNode(generatorNode)) {
            // first row of body (node name)
            PdfPCell phaseTitleCell =
                pdfFormatUtil.flightPhaseTableTitleRowCell(
                    concatNodeName(generatorNode), numberOfColumnsInTable);
            operatingModeTable.addCell(phaseTitleCell);

            // table > header
            operatingModeTable.addCell(PdfFormatUtil.getBlankCell()); // skip first column

            for (FlightPhaseDto flightPhase : flightPhases) {
              PdfPCell cell =
                  pdfFormatUtil.flightPhaseTableHeaderRowCell(
                      PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 8f);
              operatingModeTable.addCell(cell);
            }

            // percent used
            PdfPCell BodyRowPercentageUsedCell =
                pdfFormatUtil.flightPhaseTableBodyRowCell("Percent Used", false);
            operatingModeTable.addCell(BodyRowPercentageUsedCell);

            for (FlightPhaseDto flightPhase : flightPhases) {
              PdfPCell BodyRowCell =
                  pdfFormatUtil.flightPhaseTableBodyRowCell(
                      getSummarizedValueShipSummary(
                          generatorNode,
                          operatingMode,
                          flightPhase.getName(),
                          CalculationType.PERCENTAGE_USED),
                      false);
              operatingModeTable.addCell(BodyRowCell);
            }

            // kVA Remaining row
            PdfPCell BodyRowKvaRemainingCell =
                pdfFormatUtil.flightPhaseTableBodyRowCell("kVA Remaining", false);
            operatingModeTable.addCell(BodyRowKvaRemainingCell);

            for (FlightPhaseDto flightPhase : flightPhases) {
              PdfPCell BodyRowCell =
                  pdfFormatUtil.flightPhaseTableBodyRowCell(
                      getSummarizedValueShipSummary(
                          generatorNode,
                          operatingMode,
                          flightPhase.getName(),
                          CalculationType.KVA_AVAILABLE),
                      false);
              operatingModeTable.addCell(BodyRowCell);
            }
            // blank row
            addBlankRow(operatingModeTable, numberOfColumnsInTable);

            addElaFlightPhaseRows(phaseBalanceTable, 4, generatorNode, operatingMode, false);
            addBlankRow(phaseBalanceTable, 4);

            addElaElectricalPhaseRows(phaseImbalanceTable, 2, generatorNode, operatingMode, false);
            addBlankRow(phaseImbalanceTable, 2);
          }
        }
      }

      pdfPTable.addCell(operatingModeTable);
      pdfPTable.addCell(phaseBalanceTable);
      pdfPTable.addCell(phaseImbalanceTable);
    }

    return pdfPTable;
  }

  private void addBlankRow(PdfPTable pdfPtable, int numberOfColumnsInTable) {
    PdfPCell BodyRowLast3 = PdfFormatUtil.getBlankCell();
    BodyRowLast3.setColspan(numberOfColumnsInTable);
    BodyRowLast3.addElement(Chunk.NEWLINE);
    pdfPtable.addCell(BodyRowLast3);
  }

  private void createBusSummary(
      Document document,
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing) {
    boolean includeTotal = node.getVoltageType().equals(ElectricalPhase.AC3);

    if (node.getSummarizedLoads() != null && !node.getSummarizedLoads().isEmpty()) {
      PdfPTable pdfPTable = createBaseTable();

      // append node name + node breadcrumb row
      PdfPTable nodeHeaderRowTable = getNodeHeaderTableRow(node, operatingMode);
      pdfPTable.addCell(nodeHeaderRowTable);

      // append table header row (outside summary table for table row striping purposes)
      PdfPCell phaseTitleCell = getComponentSummaryHeaderRow(node);
      pdfPTable.addCell(phaseTitleCell);

      // create summary table
      PdfPTable elaSummaryTable =
          createElaSummaryTable(node, operatingMode, flightPhases, isBoeing, includeTotal);
      pdfPTable.addCell(elaSummaryTable);
      document.add(pdfPTable);
    }

    ElectricalPhase voltageType = node.getVoltageType();

    boolean isNotDcOrAcVoltageType =
        !voltageType.equals(ElectricalPhase.DC) && !voltageType.equals(ElectricalPhase.AC);
    boolean noComponents = node.getComponents().isEmpty();

    // 3 Phase
    if (isComponentInElectricalPhase(node, ElectricalPhase.AC3) && isNotDcOrAcVoltageType) {
      document.add(
          appendBusPhaseTable(node, operatingMode, flightPhases, ElectricalPhase.AC3, isBoeing));
    }

    // A Phase
    if (isComponentInElectricalPhase(node, ElectricalPhase.ACA) && isNotDcOrAcVoltageType) {
      document.add(
          appendBusPhaseTable(node, operatingMode, flightPhases, ElectricalPhase.ACA, isBoeing));
    }

    // B Phase
    if (isComponentInElectricalPhase(node, ElectricalPhase.ACB)
        && voltageType.equals(ElectricalPhase.AC3)) {
      document.add(
          appendBusPhaseTable(node, operatingMode, flightPhases, ElectricalPhase.ACB, isBoeing));
    }

    // C Phase
    if (isComponentInElectricalPhase(node, ElectricalPhase.ACC)
        && voltageType.equals(ElectricalPhase.AC3)) {
      document.add(
          appendBusPhaseTable(node, operatingMode, flightPhases, ElectricalPhase.ACC, isBoeing));
    }

    // No components
    if (noComponents) {
      document.add(PdfFormatUtil.createTextTable("No components currently exist on this bus."));
    }

    // DC Type
    if (voltageType.equals(ElectricalPhase.DC) && !noComponents) {
      String unitLabel = getUnitForDetailView(ElectricalPhase.DC);
      // header (excluded from striped table styling)
      PdfPTable pdfPTable = createBaseTable();
      PdfPCell phaseTitleCell =
          pdfFormatUtil.flightPhaseTableTitleRowCell(
              "Components (all units in " + unitLabel + ")", 1);
      pdfPTable.addCell(phaseTitleCell);
      document.add(pdfPTable);

      // create phase table
      document.add(
          createPhaseTable(
              node, operatingMode, flightPhases, ElectricalPhase.DC, unitLabel, isBoeing));
    }

    // AC Type
    if (voltageType.equals(ElectricalPhase.AC) && !noComponents) {
      ElectricalPhase electricalPhase = determineElectricalPhase(node.getSummarizedLoads());
      String unitLabel = getUnitForDetailView(electricalPhase);

      // header (excluded from striped table styling)
      PdfPTable pdfPTable = createBaseTable();
      PdfPCell phaseTitleCell =
          pdfFormatUtil.flightPhaseTableTitleRowCell(
              "Components (all units in " + unitLabel + ")", 1);
      pdfPTable.addCell(phaseTitleCell);
      document.add(pdfPTable);

      // create phase table
      document.add(
          createPhaseTable(
              node, operatingMode, flightPhases, electricalPhase, unitLabel, isBoeing));
    }
  }

  private PdfPTable appendBusPhaseTable(
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      ElectricalPhase electricalPhase,
      boolean isBoeing) {

    PdfPTable pdfPTable = createBaseTable();
    pdfPTable.setSplitLate(false);

    // get power type label
    String unitLabel = getUnitForDetailView(electricalPhase);

    PdfPCell phaseComponentRowTitleCell =
        pdfFormatUtil.flightPhaseTableTitleRowCell(
            String.format(
                "%s %s",
                getPhaseLetter(electricalPhase),
                "Phase Components (all units in " + unitLabel + ")"),
            1);

    phaseComponentRowTitleCell.setFixedHeight(30f);
    pdfPTable.addCell(phaseComponentRowTitleCell);

    // create phase table
    PdfPTable phaseACBTable =
        createPhaseTable(node, operatingMode, flightPhases, electricalPhase, unitLabel, isBoeing);
    pdfPTable.addCell(phaseACBTable);

    // blank row
    pdfPTable.addCell(PdfFormatUtil.createBlankRow(1));

    return pdfPTable;
  }

  private void appendElaPhaseSummaryTable(
      PdfPTable pdfPTable,
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      String powerType,
      ElectricalPhase electricalPhase,
      int numberOfColumnsInTable) {
    String phaseLetter = getPhaseLetter(electricalPhase);

    boolean isGenerator = isGenerator(node);

    if (isGenerator) {
      // phase row
      PdfPCell BodyRowPhaseALabelCell =
          pdfFormatUtil.flightPhaseTableBodyRowCellLabel("Phase " + phaseLetter, 9f);
      BodyRowPhaseALabelCell.setColspan(numberOfColumnsInTable);
      pdfPTable.addCell(BodyRowPhaseALabelCell);

      // Percentage Used row
      PdfPCell BodyRowPercentUsedLabelCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell("Percent Used", true);
      pdfPTable.addCell(BodyRowPercentUsedLabelCell);

      PdfPCell BodyRowPercentUsedPowerCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForNode(
                  node, operatingMode, powerType, electricalPhase, CalculationType.PERCENTAGE_USED),
              false);
      pdfPTable.addCell(BodyRowPercentUsedPowerCell);

      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell BodyRowCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                getSummarizedValueForNode(
                    node,
                    operatingMode,
                    flightPhase.getName(),
                    electricalPhase,
                    CalculationType.PERCENTAGE_USED),
                false);
        pdfPTable.addCell(BodyRowCell);
      }
    }

    // kVA Remaining row
    String label = isGenerator ? "kVA Remaining" : "Phase " + phaseLetter + " (all units in kVA)";
    PdfPCell BodyRowKvaRemainingLabelCell = pdfFormatUtil.flightPhaseTableBodyRowCell(label, true);
    pdfPTable.addCell(BodyRowKvaRemainingLabelCell);

    // power column
    PdfPCell BodyRowKvaPowerCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell(
            getSummarizedValueForNode(
                node,
                operatingMode,
                powerType,
                electricalPhase,
                isGenerator ? CalculationType.KVA_AVAILABLE : null),
            false);
    pdfPTable.addCell(BodyRowKvaPowerCell);

    // flight phases
    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell BodyRowCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForNode(
                  node,
                  operatingMode,
                  flightPhase.getName(),
                  electricalPhase,
                  isGenerator ? CalculationType.KVA_AVAILABLE : null),
              false);
      pdfPTable.addCell(BodyRowCell);
    }
  }

  private void addElaFlightPhaseRows(
      PdfPTable pdfPTable, int columns, Node node, String operatingMode, boolean isBoeing) {

    List<SummarizedLoad> maxPhaseLoads =
        getMaxPhaseLoads(node, operatingMode, SummaryType.COMPONENTS_AND_CHILDREN);
    if (!maxPhaseLoads.isEmpty()) {
      PdfPCell phaseTitleCell =
          pdfFormatUtil.flightPhaseTableTitleRowCell(
              concatNodeName(node)
                  + " Worst Flight Phase Load - ("
                  + DECIMAL_FORMAT_3_PLACES.format(
                      node.getNominalPower() / 3 / node.getInlineVoltage())
                  + " AMPS)",
              columns);
      pdfPTable.addCell(phaseTitleCell);

      // add header
      PdfPCell flightHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Worst Flight Phase", 8f);
      pdfPTable.addCell(flightHeader);

      PdfPCell phaseAHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Phase A", 8f);
      pdfPTable.addCell(phaseAHeader);

      PdfPCell phaseBHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Phase B", 8f);
      pdfPTable.addCell(phaseBHeader);

      PdfPCell phaseCHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Phase C", 8f);
      pdfPTable.addCell(phaseCHeader);

      PdfPCell worstPhaseCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              PdfFormatUtil.convertFlightPhaseText(maxPhaseLoads.get(0).getFlightPhase()), false);
      worstPhaseCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(worstPhaseCell);

      for (SummarizedLoad phaseLoad : maxPhaseLoads) {
        String phaseLetter = getPhaseLetter(phaseLoad.getElectricalPhase());
        PdfPCell phaseCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                DECIMAL_FORMAT_3_PLACES.format(phaseLoad.getVa() / node.getInlineVoltage()), false);
        phaseCell.setHorizontalAlignment(Element.ALIGN_LEFT);
        pdfPTable.addCell(phaseCell);
      }
    }
  }

  private void addElaElectricalPhaseRows(
      PdfPTable pdfPTable, int columns, Node node, String operatingMode, boolean isBoeing) {

    Optional<SummarizedLoad> imbalance =
        getMaxImbalanceLoad(node, operatingMode, SummaryType.COMPONENTS_AND_CHILDREN);
    if (imbalance.isPresent()) {
      PdfPCell phaseTitleCell =
          pdfFormatUtil.flightPhaseTableTitleRowCell(
              concatNodeName(node) + " Worst Case Flight Phase Imbalance - (3.5 KVA)", columns);
      pdfPTable.addCell(phaseTitleCell);

      // add header
      PdfPCell flightHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Flight Phase", 8f);
      pdfPTable.addCell(flightHeader);
      PdfPCell imbalanceHeader = pdfFormatUtil.flightPhaseTableHeaderRowCell("Imbalance", 8f);
      pdfPTable.addCell(imbalanceHeader);

      PdfPCell worstFlightCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              PdfFormatUtil.convertFlightPhaseText(imbalance.get().getFlightPhase()), false);
      worstFlightCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(worstFlightCell);

      PdfPCell imbalancedLoad =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              DECIMAL_FORMAT_3_PLACES.format(imbalance.get().getVa() / 1000), false);
      imbalancedLoad.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(imbalancedLoad);
    }
  }

  private PdfPTable createElaSummaryTable(
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing,
      boolean includeTotal) {
    int numberOfColumnsInTable = flightPhases.size() + 2;
    float flightPhaseColumnWidth = (numberOfColumnsInTable + 2) / 100f;
    float[] tableWidths = new float[numberOfColumnsInTable];

    tableWidths[0] = flightPhaseColumnWidth * 2;
    for (int i = 1; i < numberOfColumnsInTable; i++) {
      tableWidths[i] = flightPhaseColumnWidth;
    }

    PdfPTable pdfPTable = createBaseTable(numberOfColumnsInTable, tableWidths);
    pdfPTable.setSpacingAfter(15f);

    // add table row striping
    AlternatingBackground alternatingBackground = new AlternatingBackground();
    pdfPTable.setTableEvent(alternatingBackground);

    boolean isGenerator = isGenerator(node);

    // table > header row (1st column)
    pdfPTable.addCell(PdfFormatUtil.getBlankCell()); // skip first column

    // table > header row (2nd column)
    String powerTypeUnitAbbreviation = getUnitForSummaryView(node);
    String powerTypeColumnHeader = getPowerTypeLabelByUnit(isBoeing, powerTypeUnitAbbreviation);

    // add header row (power type column)
    PdfPCell headerRowLabelCell =
        pdfFormatUtil.flightPhaseTableHeaderRowCell(powerTypeColumnHeader, 8f);
    pdfPTable.addCell(headerRowLabelCell);

    // table > header row (3+ columns)
    for (FlightPhaseDto flightPhaseDto : flightPhases) {
      PdfPCell cell =
          pdfFormatUtil.flightPhaseTableHeaderRowCell(
              PdfFormatUtil.convertFlightPhaseText(flightPhaseDto.getName()), 8f);
      pdfPTable.addCell(cell);
    }

    ElectricalPhase voltageType = node.getVoltageType();
    String powerType = getPowerType(isBoeing);

    // TODO: the phase determination logic feels flawed (from UI)
    //  everything is checking against AC3 presence which is always true

    // phase A (hasAPhase)
    boolean hasAPhase = voltageType.equals(ElectricalPhase.AC3);
    if (hasAPhase) {
      appendElaPhaseSummaryTable(
          pdfPTable,
          node,
          operatingMode,
          flightPhases,
          powerType,
          ElectricalPhase.ACA,
          numberOfColumnsInTable);
    }

    // phase B (hasBPhase)
    boolean hasBPhase = voltageType.equals(ElectricalPhase.AC3);
    if (hasBPhase) {
      appendElaPhaseSummaryTable(
          pdfPTable,
          node,
          operatingMode,
          flightPhases,
          powerType,
          ElectricalPhase.ACB,
          numberOfColumnsInTable);
    }

    // phase C (hasCPhase)
    boolean hasCPhase = voltageType.equals(ElectricalPhase.AC3);
    if (hasCPhase) {
      appendElaPhaseSummaryTable(
          pdfPTable,
          node,
          operatingMode,
          flightPhases,
          powerType,
          ElectricalPhase.ACC,
          numberOfColumnsInTable);
    }

    // !hasAPhase && !hasBPhase && !hasCPhase
    if (!hasAPhase && !hasBPhase && !hasCPhase) {
      ElectricalPhase electricalPhase = determineElectricalPhase(node.getSummarizedLoads());

      if (isGenerator) {
        // phase row
        PdfPCell BodyRowPhaseLabelCell =
            pdfFormatUtil.flightPhaseTableBodyRowCellLabel("Totals", 9f);
        BodyRowPhaseLabelCell.setColspan(numberOfColumnsInTable);
        pdfPTable.addCell(BodyRowPhaseLabelCell);

        // include percent row for GENERATOR
        PdfPCell BodyRowPercentUsedLabelCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell("Percent Used", false);
        pdfPTable.addCell(BodyRowPercentUsedLabelCell);

        PdfPCell BodyRowPercentUsedCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                getSummarizedValueForNode(
                    node,
                    operatingMode,
                    powerType,
                    electricalPhase,
                    CalculationType.PERCENTAGE_USED),
                false);
        pdfPTable.addCell(BodyRowPercentUsedCell);

        for (FlightPhaseDto flightPhase : flightPhases) {
          PdfPCell BodyRowCell =
              pdfFormatUtil.flightPhaseTableBodyRowCell(
                  getSummarizedValueForNode(
                      node,
                      operatingMode,
                      flightPhase.getName(),
                      electricalPhase,
                      CalculationType.PERCENTAGE_USED),
                  false);
          pdfPTable.addCell(BodyRowCell);
        }
      }

      // kVA Remaining row
      PdfPCell BodyRowKvaRemainingCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              "Totals (all units in " + powerTypeUnitAbbreviation + ")", false);
      pdfPTable.addCell(BodyRowKvaRemainingCell);

      PdfPCell BodyRowKvaPowerCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForNode(
                  node,
                  operatingMode,
                  powerType,
                  electricalPhase,
                  isGenerator ? CalculationType.KVA_AVAILABLE : null),
              false);
      pdfPTable.addCell(BodyRowKvaPowerCell);

      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell BodyRowCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                getSummarizedValueForNode(
                    node,
                    operatingMode,
                    flightPhase.getName(),
                    electricalPhase,
                    isGenerator ? CalculationType.KVA_AVAILABLE : null),
                false);
        pdfPTable.addCell(BodyRowCell);
      }
    }

    if (includeTotal) {
      if (isGenerator) {
        // phase row
        PdfPCell BodyRowPhaseLabelCell =
            pdfFormatUtil.flightPhaseTableBodyRowCellLabel("Total", 9f);
        BodyRowPhaseLabelCell.setColspan(numberOfColumnsInTable);
        pdfPTable.addCell(BodyRowPhaseLabelCell);
      }

      // Percent Used row
      if (isGenerator) {
        PdfPCell BodyRowPercentUsedLabelCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell("Percent Used", true);
        pdfPTable.addCell(BodyRowPercentUsedLabelCell);

        PdfPCell BodyRowPercentUsedCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                getSummarizedValueForNode(
                    node,
                    operatingMode,
                    powerType,
                    ElectricalPhase.NA,
                    CalculationType.PERCENTAGE_USED),
                true);
        pdfPTable.addCell(BodyRowPercentUsedCell);

        for (FlightPhaseDto flightPhase : flightPhases) {
          PdfPCell BodyRowCell =
              pdfFormatUtil.flightPhaseTableBodyRowCell(
                  getSummarizedValueForNode(
                      node,
                      operatingMode,
                      flightPhase.getName(),
                      ElectricalPhase.NA,
                      CalculationType.PERCENTAGE_USED),
                  true);
          pdfPTable.addCell(BodyRowCell);
        }
      }

      // kVA Remaining row
      String kVAlabel = isGenerator ? KVA_LABEL : "Total kVA";
      PdfPCell BodyRowKvaRemainingCell = pdfFormatUtil.flightPhaseTableBodyRowCell(kVAlabel, true);
      pdfPTable.addCell(BodyRowKvaRemainingCell);

      PdfPCell BodyRowKvaPowerCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForNode(
                  node,
                  operatingMode,
                  powerType,
                  ElectricalPhase.NA,
                  isGenerator ? CalculationType.KVA_AVAILABLE : null),
              true);
      pdfPTable.addCell(BodyRowKvaPowerCell);

      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell BodyRowCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                getSummarizedValueForNode(
                    node,
                    operatingMode,
                    flightPhase.getName(),
                    ElectricalPhase.NA,
                    isGenerator ? CalculationType.KVA_AVAILABLE : null),
                true);
        pdfPTable.addCell(BodyRowCell);
      }
    }

    return pdfPTable;
  }

  private void createGeneratorSummary(
      Document document,
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing) {
    PdfPTable pdfPTable = createBaseTable();
    PdfPTable operatingModeTable = createBaseTable();

    // append node name row
    PdfPCell nodeHeaderRowCell = getNodeHeaderRow(node, operatingMode);
    pdfPTable.addCell(nodeHeaderRowCell);

    // append table header row (outside summary table for table row striping purposes)
    PdfPCell phaseTitleCell = getComponentSummaryHeaderRow(node);
    pdfPTable.addCell(phaseTitleCell);

    // remove batterySupplied phases
    flightPhases = excludeBatterySuppliedFlightPhases(flightPhases);

    // create phase table
    PdfPTable elaSummaryTable =
        createElaSummaryTable(node, operatingMode, flightPhases, isBoeing, true);
    operatingModeTable.addCell(elaSummaryTable);

    pdfPTable.addCell(operatingModeTable);

    document.add(pdfPTable);
  }

  private PdfPTable createPhaseTable(
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      ElectricalPhase electricalPhase,
      String unitLabel,
      boolean isBoeing) {

    int numberOfColumnsInTable = flightPhases.size() + COMPONENT_COLUMNS.length + 1;

    float flightPhaseColumnWidth = (numberOfColumnsInTable + 3) / 100f;
    float[] tableWidths = new float[numberOfColumnsInTable];

    int designationColumnIdx = 6;
    tableWidths[designationColumnIdx] = flightPhaseColumnWidth * 3;
    for (int i = 0; i < numberOfColumnsInTable; i++) {
      if (i != designationColumnIdx) {
        tableWidths[i] = flightPhaseColumnWidth;
      }
    }

    PdfPTable pdfPTable = createBaseTable(numberOfColumnsInTable, tableWidths);

    // add table row striping
    PdfPTableEvent alternateBackground = new AlternatingBackground();
    pdfPTable.setTableEvent(alternateBackground);

    // table > header row (component columns)
    for (String columnName : COMPONENT_COLUMNS) {
      PdfPCell cell = pdfFormatUtil.flightPhaseTableHeaderRowCell(columnName, 6f);
      pdfPTable.addCell(cell);
    }

    // table > header row (power column)
    String powerTypeLabel = getPowerTypeLabelByUnit(isBoeing, unitLabel);
    PdfPCell headerRowLabelCell = pdfFormatUtil.flightPhaseTableHeaderRowCell(powerTypeLabel, 6f);
    pdfPTable.addCell(headerRowLabelCell);

    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell cell =
          pdfFormatUtil.flightPhaseTableHeaderRowCell(
              PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 6f);
      pdfPTable.addCell(cell);
    }

    // table > body row (1st column)
    List<Component> components =
        node.getComponents().stream()
            .filter(component -> component.getElectricalPhase().equals(electricalPhase))
            .collect(Collectors.toList());

    for (Component component : components) {
      // elect Id
      PdfPCell electIdCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(component.getElectIdent(), false);
      pdfPTable.addCell(electIdCell);

      // intermittent
      PdfPCell intermittentCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(component.getIntermittent() ? "Y" : "N", false);
      pdfPTable.addCell(intermittentCell);

      // clip
      PdfPCell clipCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(component.getClipsed() ? "Y" : "N", false);
      pdfPTable.addCell(clipCell);

      // sheddable
      PdfPCell sheddableCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(component.getSheddable() ? "Y" : "N", false);
      pdfPTable.addCell(sheddableCell);

      // panel
      PdfPCell panelCell = pdfFormatUtil.flightPhaseTableBodyRowCell(component.getPanel(), false);
      pdfPTable.addCell(panelCell);

      // ata
      PdfPCell ataCell = pdfFormatUtil.flightPhaseTableBodyRowCell(component.getAta(), false);
      pdfPTable.addCell(ataCell);

      // name
      PdfPCell nameCell = pdfFormatUtil.flightPhaseTableBodyRowCell(component.getName(), false);
      pdfPTable.addCell(nameCell);

      if (isBoeing) {
        // connectedLoadVa

        // Component Load VA can be null, set default to 0
        PdfPCell connectedLoadVaCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                DECIMAL_FORMAT_1_PLACE.format(
                    component.getConnectedLoadVa() != null ? component.getConnectedLoadVa() : 0),
                false);
        pdfPTable.addCell(connectedLoadVaCell);
      } else {
        // nominalPower
        PdfPCell nominalPowerCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                DECIMAL_FORMAT_1_PLACE.format(
                    component.getNominalPower() != null ? component.getNominalPower() : 0),
                false);
        pdfPTable.addCell(nominalPowerCell);
      }

      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell flightPhaseCell =
            pdfFormatUtil.flightPhaseTableBodyRowCell(
                DECIMAL_FORMAT_1_PLACE.format(
                    getComponentValue(component, flightPhase.getName(), operatingMode)),
                false);
        pdfPTable.addCell(flightPhaseCell);
      }
    }

    boolean is3PhaseComponent = isComponentInElectricalPhase(node, ElectricalPhase.AC3);

    if (is3PhaseComponent
        && !electricalPhase.equals(ElectricalPhase.AC3)
        && !electricalPhase.equals(ElectricalPhase.AC)
        && !electricalPhase.equals(ElectricalPhase.DC)) {
      // blank cell columns
      PdfPCell blankCells = pdfFormatUtil.getSubTotalLabelCell("", 5);
      pdfPTable.addCell(blankCells);

      PdfPCell labelCell = pdfFormatUtil.getSubTotalLabelCell("3 Phase Components", 2);
      pdfPTable.addCell(labelCell);

      // power cell
      String powerType = getPowerType(isBoeing);
      PdfPCell powerCell =
          pdfFormatUtil.flightPhaseTableBodyRowCellBold(
              getSummarizedValueThird(node, powerType, ElectricalPhase.AC3, null));
      pdfPTable.addCell(powerCell);

      // flight phases
      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell flightPhaseCell =
            pdfFormatUtil.flightPhaseTableBodyRowCellBold(
                getSummarizedValueThird(
                    node, flightPhase.getName(), ElectricalPhase.AC3, operatingMode));
        pdfPTable.addCell(flightPhaseCell);
      }
    }

    if (!electricalPhase.equals(ElectricalPhase.AC3)
        && !electricalPhase.equals(ElectricalPhase.AC)) {
      // blank cell columns
      PdfPCell blankCells = PdfFormatUtil.getBlankCell();
      blankCells.setColspan(5);
      pdfPTable.addCell(blankCells);

      PdfPCell labelCell = pdfFormatUtil.getSubTotalLabelCell("Total", 2);
      pdfPTable.addCell(labelCell);

      // power cell
      PdfPCell powerCell =
          pdfFormatUtil.flightPhaseTableBodyRowCellBold(
              DECIMAL_FORMAT_1_PLACE.format(
                  getSummarizedValueForShip(
                      node,
                      null,
                      getPowerType(isBoeing),
                      electricalPhase,
                      SummaryType.COMPONENTS,
                      null)));
      pdfPTable.addCell(powerCell);

      // flight phases
      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell flightPhaseCell =
            pdfFormatUtil.flightPhaseTableBodyRowCellBold(
                DECIMAL_FORMAT_1_PLACE.format(
                    getSummarizedValueForShip(
                        node,
                        operatingMode,
                        flightPhase.getName(),
                        electricalPhase,
                        SummaryType.COMPONENTS,
                        null)));
        pdfPTable.addCell(flightPhaseCell);
      }
    }

    return pdfPTable;
  }

  private void createTransformerSummary(
      Document document,
      Node node,
      String operatingMode,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing) {

    // remove batterySupplied phases
    flightPhases = excludeBatterySuppliedFlightPhases(flightPhases);

    // Power Type settings
    String powerType = getPowerType(isBoeing);
    String powerTypeLabel = getPowerTypeLabelByNodeElectPhase(isBoeing, node.getElectricalPhase());

    int numberOfColumnsInTable = flightPhases.size() + 2;

    PdfPTable pdfPTable = createBaseTable();

    PdfPTable operatingModeTable = createBaseTable(numberOfColumnsInTable);

    // add table row striping
    AlternatingBackground alternatingBackground = new AlternatingBackground();
    operatingModeTable.setTableEvent(alternatingBackground);

    // append node name + node breadcrumb row
    PdfPTable nodeHeaderRowTable = getNodeHeaderTableRow(node, operatingMode);
    PdfPCell nodeHeaderRowCell = PdfFormatUtil.getBlankCell();
    nodeHeaderRowCell.setColspan(numberOfColumnsInTable);
    nodeHeaderRowCell.addElement(nodeHeaderRowTable);
    pdfPTable.addCell(nodeHeaderRowCell);

    // append table header row (outside summary table for table row striping purposes)
    PdfPCell phaseTitleCell = getComponentSummaryHeaderRow(node);
    phaseTitleCell.setColspan(numberOfColumnsInTable);
    pdfPTable.addCell(phaseTitleCell);

    // table > header row (1st column)
    operatingModeTable.addCell(PdfFormatUtil.getBlankCell());

    // table > header row (2nd column)
    PdfPCell headerRowPowerCell = pdfFormatUtil.flightPhaseTableHeaderRowCell(powerTypeLabel, 8f);
    operatingModeTable.addCell(headerRowPowerCell);

    // table > header row (flight phase columns)
    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell flightPhaseCell =
          pdfFormatUtil.flightPhaseTableHeaderRowCell(
              PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 8f);
      operatingModeTable.addCell(flightPhaseCell);
    }

    // percentage used row

    // table > body row (1st column)
    PdfPCell bodyRowPercentUsedNodeNameCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell("Percent Used", false);
    operatingModeTable.addCell(bodyRowPercentUsedNodeNameCell);

    // table > body row (2nd column)
    PdfPCell bodyRowPercentUsedPowerCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell(
            getSummarizedValueForTransformer(
                node, operatingMode, powerType, CalculationType.PERCENTAGE_USED, isBoeing),
            false);
    operatingModeTable.addCell(bodyRowPercentUsedPowerCell);

    // table > body row (flight phase columns)
    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell bodyRowFlightPhaseCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForTransformer(
                  node,
                  operatingMode,
                  flightPhase.getName(),
                  CalculationType.PERCENTAGE_USED,
                  isBoeing),
              false);
      operatingModeTable.addCell(bodyRowFlightPhaseCell);
    }

    // kva remaining row

    // table > body row (1st column)
    PdfPCell bodyRowAmpsRemainingCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell(AMPS_LABEL + " Remaining", false);
    operatingModeTable.addCell(bodyRowAmpsRemainingCell);

    // table > body row (2nd column)
    PdfPCell bodyRowPowerCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell(
            getSummarizedValueForTransformer(
                node, operatingMode, powerType, CalculationType.KVA_AVAILABLE, isBoeing),
            false);
    operatingModeTable.addCell(bodyRowPowerCell);

    // table > body row (flight phase columns)
    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell bodyRowFlightPhaseCell =
          pdfFormatUtil.flightPhaseTableBodyRowCell(
              getSummarizedValueForTransformer(
                  node,
                  operatingMode,
                  flightPhase.getName(),
                  CalculationType.KVA_AVAILABLE,
                  isBoeing),
              false);
      operatingModeTable.addCell(bodyRowFlightPhaseCell);
    }

    pdfPTable.addCell(operatingModeTable);

    document.add(pdfPTable);
  }

  private ElectricalPhase determineElectricalPhase(List<SummarizedLoad> summarizedLoads) {
    Optional<SummarizedLoad> summarizedLoad =
        summarizedLoads.stream()
            .filter(
                sload ->
                    !sload.isMaxImbalance()
                        && !sload.isMaxPhaseLoad()
                        && !sload.getFlightPhase().equals(NOMINAL_POWER))
            .findFirst();

    return summarizedLoad.isPresent()
        ? summarizedLoad.get().getElectricalPhase()
        : ElectricalPhase.NA;
  }

  private String getSummarizedValueThird(
      Node node, String flightPhase, ElectricalPhase electricalPhase, String operatingMode) {
    Double total =
        getSummarizedValueForNode(
            node, operatingMode, flightPhase, electricalPhase, SummaryType.COMPONENTS, null);
    return DECIMAL_FORMAT_1_PLACE.format(!total.isNaN() ? total / 3 : 0d);
  }

  private Double getComponentValue(Component component, String flightPhase, String operatingMode) {
    Optional<Load> load =
        component.getLoads().stream()
            .filter(
                c ->
                    c.getFlightPhase().equalsIgnoreCase(flightPhase)
                        && (operatingMode == null
                            ? c.getOperatingMode() == null
                            : c.getOperatingMode().equalsIgnoreCase(operatingMode)))
            .findFirst();

    return load.isPresent() ? load.get().getVa() : 0d;
  }

  private List<Node> getGenerators(Ela ela) {
    List<Node> matchingNodes = new ArrayList<>();

    List<Long> nodeIds =
        ela.getNodes().stream()
            .filter(n -> n.getNodeType().equals(NodeType.GENERATOR))
            .map(Node::getId)
            .collect(Collectors.toList());

    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, false);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    for (Long nodeId : nodeIds) {
      Optional<Node> matchingNode = nodeService.findById(nodeId, ela.getId(), loadSummaryRequest);

      matchingNode.ifPresent(matchingNodes::add);
    }

    return matchingNodes.stream()
        .sorted(Comparator.comparing(Node::getName))
        .collect(Collectors.toList());
  }

  private String getSummarizedValueShipSummary(
      Node node, String operatingMode, String flightPhase, CalculationType calculationType) {
    Double total;
    Double phaseA =
        getSummarizedValueForShip(
            node,
            operatingMode,
            flightPhase,
            ElectricalPhase.ACA,
            SummaryType.COMPONENTS_AND_CHILDREN,
            null);
    Double phaseB =
        getSummarizedValueForShip(
            node,
            operatingMode,
            flightPhase,
            ElectricalPhase.ACB,
            SummaryType.COMPONENTS_AND_CHILDREN,
            null);
    Double phaseC =
        getSummarizedValueForShip(
            node,
            operatingMode,
            flightPhase,
            ElectricalPhase.ACC,
            SummaryType.COMPONENTS_AND_CHILDREN,
            null);

    total = phaseA + phaseB + phaseC;

    Double busRating = node.getNominalPower() != null ? node.getNominalPower() : 115000d;

    if (calculationType.equals(CalculationType.KVA_AVAILABLE)) {
      Double remaining = (busRating - total) / 1000;
      return DECIMAL_FORMAT_3_PLACES.format(remaining);
    } else if (calculationType.equals(CalculationType.PERCENTAGE_USED)) {
      Double percentageUsed = total / busRating * 100;
      return String.format("%s%s", DECIMAL_FORMAT_1_PLACE.format(percentageUsed), "%");
    }

    return DECIMAL_FORMAT_2_PLACES.format(total);
  }

  private String getSummarizedValueForNode(
      Node node,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      CalculationType calculationType) {
    String opMode = isNonFlightPhase(flightPhase) ? null : operatingMode;
    Double total;
    boolean isGenerator = node.getNodeType().equals(NodeType.GENERATOR);

    if (electricalPhase.equals(ElectricalPhase.NA)) {
      Optional<SummarizedLoad> loadA =
          getSummarizedLoad(
              node, opMode, flightPhase, ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN);

      Optional<SummarizedLoad> loadB =
          getSummarizedLoad(
              node, opMode, flightPhase, ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN);

      Optional<SummarizedLoad> loadC =
          getSummarizedLoad(
              node, opMode, flightPhase, ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN);

      total = getTotalVa(loadA, loadB, loadC);
    } else {
      total =
          getSummarizedValueForNode(
              node,
              opMode,
              flightPhase,
              electricalPhase,
              SummaryType.COMPONENTS_AND_CHILDREN,
              isGenerator ? null : calculationType);
    }

    if (isGenerator) {
      Double nominalPower =
          electricalPhase.equals(ElectricalPhase.NA)
              ? node.getNominalPower()
              : node.getNominalPower() / 3;
      if (calculationType != null && calculationType.equals(CalculationType.PERCENTAGE_USED)) {
        Double percentageUsed = total / nominalPower * 100;
        return String.format("%s%s", DECIMAL_FORMAT_1_PLACE.format(percentageUsed), "%");
      } else if (calculationType != null && calculationType.equals(CalculationType.KVA_AVAILABLE)) {
        double vaAvailable = nominalPower - total;
        Double kvaAvailable = vaAvailable / 1000;
        return DECIMAL_FORMAT_3_PLACES.format(kvaAvailable);
      }
    } else {
      if (electricalPhase.equals(ElectricalPhase.DC)) {
        // convert to Amps
        return DECIMAL_FORMAT_2_PLACES.format(total / node.getVoltage());
      }

      if (calculationType != null && calculationType.equals(CalculationType.PERCENTAGE_USED)) {
        return String.format("%s%s", DECIMAL_FORMAT_1_PLACE.format(total), "%");
      } else {
        Double kval = total / 1000;
        return DECIMAL_FORMAT_3_PLACES.format(kval);
      }
    }

    return "0.00";
  }

  private Double getSummarizedValueForNode(
      Node node,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      CalculationType calculationType) {

    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return 0d;
    }

    Optional<SummarizedLoad> load =
        getSummarizedLoad(node, operatingMode, flightPhase, electricalPhase, summaryType);

    if (load.isPresent()) {
      if (calculationType != null) {
        Double busRating =
            node.getNominalPower() != null && node.getNominalPower().isNaN()
                ? node.getNominalPower()
                : 115d;
        Double va = load.get().getVa();

        if (calculationType.equals(CalculationType.KVA_AVAILABLE)) {
          return busRating - va;
        } else if (calculationType.equals(CalculationType.PERCENTAGE_USED)) {
          return va / busRating * 100;
        }
      } else {
        return load.get().getVa();
      }

      return 0d;

    } else if (summaryType.equals(SummaryType.COMPONENTS_AND_CHILDREN)) {
      return getSummarizedValueForNode(
          node,
          operatingMode,
          flightPhase,
          electricalPhase,
          SummaryType.COMPONENTS,
          calculationType);
    }

    return 0d;
  }

  private String getSummarizedValueForTransformer(
      Node node,
      String operatingMode,
      String flightPhase,
      CalculationType calculationType,
      boolean isBoeing) {
    Double incomingVoltage = node.getInlineVoltage().equals(0d) ? 1d : node.getInlineVoltage();
    String opMode = isNonFlightPhase(flightPhase) ? null : operatingMode;
    Double busRating = getTRBusRating(node);

    // Set default electricalPhase to "AC"
    // Set electricalPhase to "DC" if TRU
    // otherwise determine electricalPhase based on maxImbalance, maxPhaseLoad, and flightPhase
    ElectricalPhase electricalPhase = ElectricalPhase.AC;

    if (node.getNodeType().equals(NodeType.TRU)) {
      electricalPhase = ElectricalPhase.DC;
    } else if (!node.getSummarizedLoads().isEmpty()) {
      // grab first/default/any flightPhase by manufacturer
      FlightPhaseDto firstFlightPhase =
          isBoeing
              ? FlightPhase.getFlightPhases("boeing", false, "", false).get(0)
              : FlightPhase.getFlightPhases("airbus", false, "", false).get(0);

      Optional<SummarizedLoad> matchingLoad =
          node.getSummarizedLoads().stream()
              .filter(
                  f ->
                      !f.isMaxImbalance()
                          && !f.isMaxPhaseLoad()
                          && f.getFlightPhase().equalsIgnoreCase(firstFlightPhase.getName()))
              .findFirst();

      if (matchingLoad.isPresent()) {
        electricalPhase = matchingLoad.get().getElectricalPhase();
      }
    }

    Optional<SummarizedLoad> load =
        getSummarizedLoad(
            node, opMode, flightPhase, electricalPhase, SummaryType.COMPONENTS_AND_CHILDREN);

    if (load.isPresent()) {
      Double val = isNonFlightPhase(flightPhase) ? load.get().getVa() : load.get().getOriginalW();
      Double ampval = val / incomingVoltage;
      Double remaining = busRating - ampval;

      if (calculationType.equals(CalculationType.PERCENTAGE_USED)) {
        Double percentageUsed = ampval / busRating * 100;
        return String.format("%s%s", DECIMAL_FORMAT_1_PLACE.format(percentageUsed), "%");
      } else if (calculationType.equals(CalculationType.KVA_AVAILABLE)) {
        return DECIMAL_FORMAT_3_PLACES.format(remaining);
      } else {
        return DECIMAL_FORMAT_2_PLACES.format(ampval);
      }
    }

    return DECIMAL_FORMAT_2_PLACES.format(0d);
  }

  private Optional<SummarizedLoad> getMaxImbalanceLoad(
      Node node, String operatingMode, SummaryType summaryType) {

    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return Optional.empty();
    }

    return node.getSummarizedLoads().stream()
        .filter(
            sload ->
                sload.isMaxImbalance()
                    && sload.getSummaryType().equals(summaryType)
                    && (operatingMode == null
                        ? sload.getOperatingMode() == null
                        : sload.getOperatingMode().equals(operatingMode)))
        .findFirst();
  }

  private List<SummarizedLoad> getMaxPhaseLoads(
      Node node, String operatingMode, SummaryType summaryType) {

    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return new ArrayList();
    }
    return node.getSummarizedLoads().stream()
        .filter(
            sload ->
                sload.isMaxPhaseLoad()
                    && sload.getSummaryType().equals(summaryType)
                    && sload.getVar() != null
                    && (operatingMode == null
                        ? sload.getOperatingMode() == null
                        : sload.getOperatingMode().equals(operatingMode)))
        .sorted(Comparator.comparing(SummarizedLoad::getElectricalPhase))
        .collect(Collectors.toList());
  }

  private Optional<SummarizedLoad> getSummarizedLoad(
      Node node,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType summaryType) {

    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return Optional.empty();
    }

    return node.getSummarizedLoads().stream()
        .filter(
            sload ->
                !sload.isMaxImbalance()
                    && !sload.isMaxPhaseLoad()
                    && (!flightPhase.isEmpty()
                        && sload.getFlightPhase().equalsIgnoreCase(flightPhase))
                    && sload.getSummaryType().equals(summaryType)
                    && sload.getElectricalPhase().equals(electricalPhase)
                    && (operatingMode == null
                        ? sload.getOperatingMode() == null
                        : sload.getOperatingMode().equals(operatingMode)))
        .findFirst();
  }

  private Double getSummarizedValueForShip(
      Node node,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      CalculationType calculationType) {
    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return 0d;
    }

    Optional<SummarizedLoad> load =
        getSummarizedLoad(node, operatingMode, flightPhase, electricalPhase, summaryType);

    if (load.isPresent()) {
      if (calculationType != null) {
        Double val = load.get().getVa();

        if (!val.isNaN()) {
          if (calculationType.equals(CalculationType.PERCENTAGE_USED)) {
            return val;
          }
        } else {
          Double busRating = node.getNominalPower().isNaN() ? 115000d : node.getNominalPower();

          if (calculationType.equals(CalculationType.KVA_AVAILABLE)) {
            return busRating - load.get().getVa();
          } else if (calculationType.equals(CalculationType.PERCENTAGE_USED)) {
            return load.get().getVa() / busRating * 100;
          }
        }
      } else {
        return load.get().getVa();
      }

      return 0d;
    } else if (summaryType.equals(SummaryType.COMPONENTS_AND_CHILDREN)) {
      return this.getSummarizedValueForShip(
          node,
          operatingMode,
          flightPhase,
          electricalPhase,
          SummaryType.COMPONENTS,
          calculationType);
    }

    return 0d;
  }

  private double getTotalVa(
      Optional<SummarizedLoad> loadA,
      Optional<SummarizedLoad> loadB,
      Optional<SummarizedLoad> loadC) {
    Double totalW = 0.0;
    Double totalVAR = 0.0;

    if (loadA.isPresent()) {
      totalW += loadA.get().getW();
      totalVAR += loadA.get().getVar();
    }
    if (loadB.isPresent()) {
      totalW += loadB.get().getW();
      totalVAR += loadB.get().getVar();
    }
    if (loadC.isPresent()) {
      totalW += loadC.get().getW();
      totalVAR += loadC.get().getVar();
    }

    return Math.sqrt((totalW * totalW) + (totalVAR * totalVAR));
  }

  private Double getTRBusRating(Node node) {
    Double busRating = 0d;

    if (node.getNominalPower() == null || node.getNominalPower().isNaN()) {
      busRating = node.getNodeType().equals(NodeType.TRU) ? 200d : 5d;
    } else if (node.getNodeType().equals(NodeType.TRU)) {
      busRating = node.getNominalPower();
    } else if (node.getNodeType().equals(NodeType.ATU)) {
      // convert from VA to Amps
      Double inlineVoltageCalc = node.getInlineVoltage().equals(0d) ? 1d : node.getInlineVoltage();
      busRating = node.getNominalPower() / inlineVoltageCalc;
    }

    return busRating;
  }

  private boolean isDisplayNode(Node node) {
    if (node.getSummarizedLoads() == null || node.getSummarizedLoads().isEmpty()) {
      return false;
    }

    boolean hasValue = false;

    for (SummarizedLoad summarizedLoad : node.getSummarizedLoads()) {
      if (summarizedLoad.getVa() > 0d) {
        hasValue = true;
      }
    }

    return hasValue;
  }

  private boolean isComponentInElectricalPhase(Node node, ElectricalPhase electricalPhase) {
    return node.getComponents().stream()
        .anyMatch(component -> component.getElectricalPhase().equals(electricalPhase));
  }

  private String concatNodeName(Node node) {
    if (node.getParentNode() != null) {
      return String.format("%s > %s", concatNodeName(node.getParentNode()), node.getName());
    }

    return node.getName();
  }

  private String getPhaseLetter(ElectricalPhase electricalPhase) {
    return electricalPhase.equals(ElectricalPhase.ACA)
        ? "A"
        : electricalPhase.equals(ElectricalPhase.ACB)
            ? "B"
            : electricalPhase.equals(ElectricalPhase.ACC)
                ? "C"
                : electricalPhase.equals(ElectricalPhase.AC3) ? "3" : "";
  }

  private PdfPCell getComponentSummaryHeaderRow(Node node) {
    String title =
        (!isGenerator(node) ? "Components " : "") + "Summary (includes all sub-bus components)";
    return pdfFormatUtil.flightPhaseTableTitleRowCell(title, 1);
  }

  private PdfPCell getNodeHeaderRow(Node node, String operatingMode) {
    return pdfFormatUtil.nodeTitleRowCell(
        String.format(
            "%s (%s) (%s)",
            node.getName(),
            PdfFormatUtil.getNodeRatingVoltage(node),
            PdfFormatUtil.convertOperatingModeText(operatingMode)),
        1);
  }

  private PdfPTable getNodeHeaderTableRow(Node node, String operatingMode) {
    PdfPTable pdfPTable = createBaseTable(2);

    // node node column
    PdfPCell nodeNameCell =
        pdfFormatUtil.nodeTitleRowCell(
            String.format(
                "%s (%s) (%s)",
                node.getName(),
                PdfFormatUtil.getNodeRatingVoltage(node),
                PdfFormatUtil.convertOperatingModeText(operatingMode)),
            1);
    pdfPTable.addCell(nodeNameCell);

    // node breadcrumb column
    PdfPCell nodeBreadcrumbCell =
        pdfFormatUtil.nodeBreadcrumbRowCell("Location: " + concatNodeName(node), 1);
    pdfPTable.addCell(nodeBreadcrumbCell);

    return pdfPTable;
  }

  private List<FlightPhaseDto> excludeBatterySuppliedFlightPhases(
      List<FlightPhaseDto> flightPhaseDtos) {
    return flightPhaseDtos.stream()
        .filter(f -> !f.isBatterySupplied())
        .collect(Collectors.toList());
  }

  private static boolean isGenerator(Node node) {
    return node.getNodeType().equals(NodeType.GENERATOR);
  }

  private static boolean isNonFlightPhase(String flightPhase) {
    return flightPhase.equalsIgnoreCase(NOMINAL_POWER)
        || flightPhase.equalsIgnoreCase(CONNECTED_LOAD);
  }

  private static String getPowerType(boolean isBoeing) {
    return isBoeing ? CONNECTED_LOAD : NOMINAL_POWER;
  }

  private static String getPowerTypeLabelByNodeElectPhase(
      boolean isBoeing, ElectricalPhase electricalPhase) {
    return isBoeing
        ? CONNECTED_LOAD_LABEL
        : ElectricalPhase.DC.equals(electricalPhase) ? NOMINAL_POWER_LABEL : NOMINAL_CURRENT_LABEL;
  }

  private static String getPowerTypeLabelByUnit(boolean isBoeing, String unit) {
    return isBoeing
        ? CONNECTED_LOAD_LABEL
        : AMPS_LABEL.equalsIgnoreCase(unit) ? NOMINAL_CURRENT_LABEL : NOMINAL_POWER_LABEL;
  }

  /**
   * Determines what text to display in the Component Detail View based on Node Electrical Phase
   * value 'W' if DC 'VA' if single phase (AC, ACA, ACB, ACC) 'Amps' otherwise
   *
   * @param electricalPhase - ElectricalPhase Enum
   * @return String
   */
  private static String getUnitForDetailView(ElectricalPhase electricalPhase) {
    return ElectricalPhase.DC.equals(electricalPhase)
        ? WATTS_LABEL
        : ElectricalPhase.AC3.equals(electricalPhase)
                || ElectricalPhase.ACA.equals(electricalPhase)
                || ElectricalPhase.ACB.equals(electricalPhase)
                || ElectricalPhase.ACC.equals(electricalPhase)
                || ElectricalPhase.AC.equals(electricalPhase)
            ? VA_LABEL
            : AMPS_LABEL;
  }

  /**
   * Determines what text to display in the Component Summary View based on Node Summarized Load
   * value 'Amps' if DC 'kVA' if single phase (AC, ACA, ACB, ACC) 'W' otherwise
   *
   * @param node - Node Entity
   * @return String
   */
  private String getUnitForSummaryView(Node node) {
    Optional<SummarizedLoad> firstSummary =
        node.getSummarizedLoads().stream()
            .filter(
                s ->
                    !s.isMaxImbalance()
                        && !s.isMaxPhaseLoad()
                        && !s.getFlightPhase().equalsIgnoreCase(NOMINAL_POWER))
            .findFirst();

    ElectricalPhase electricalPhase =
        firstSummary.isPresent() ? firstSummary.get().getElectricalPhase() : ElectricalPhase.NA;

    if (ElectricalPhase.DC.equals(electricalPhase)) {
      return AMPS_LABEL;
    } else if (ElectricalPhase.ACA.equals(electricalPhase)
        || ElectricalPhase.ACB.equals(electricalPhase)
        || ElectricalPhase.ACC.equals(electricalPhase)
        || ElectricalPhase.AC.equals(electricalPhase)) {
      return KVA_LABEL;
    }

    return WATTS_LABEL;
  }
}
