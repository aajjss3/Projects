package com.seatec.ela.app.service;

import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AircraftService implements IAircraftService {
  @Autowired private AircraftRepository repository;

  @Autowired private FleetRepository fleetRepo;

  @Autowired private KeycloakService keycloakService;

  public Optional<Aircraft> findById(Long id) {
    return repository.findById(id);
  }

  public List<Aircraft> findByIdIn(List<Long> ids) {
    return repository.findByIdIn(ids);
  }

  @Override
  public List<Aircraft> findAll(String userId) {
    if (keycloakService.isUserAndInRole(userId, KeycloakRole.IT_ADMIN.getName())) {
      return repository.findAllByOrderByAircraftShipNoAsc();
    } else if (keycloakService.isUserAndInRole(userId, KeycloakRole.ENGINEERING_ADMIN.getName())) {
      return repository.findAllByCloakedFalseOrderByAircraftShipNoAsc();
    } else {
      return repository.findAllByCloakedFalseAndArchivedFalseOrderByAircraftShipNoAsc();
    }
  }

  @Override
  @Transactional
  public Aircraft create(Aircraft entity, Long fleetId) {
    entity.setId(null);
    return repository.save(addFleet(entity, fleetId));
  }

  @Override
  @Transactional
  public Aircraft update(Aircraft entity, Long aircraftId) {
    Aircraft aircraft =
        repository
            .findById(aircraftId)
            .orElseThrow(
                () -> new BadRequestException("Aircraft Resource id " + aircraftId + " not found"));

    aircraft.setLineNumber(entity.getLineNumber());
    aircraft.setSerialNumber(entity.getSerialNumber());
    aircraft.setRegistrationNumber(entity.getRegistrationNumber());
    aircraft.setVariableNumber(entity.getVariableNumber());
    aircraft.setBatteryCharge(entity.getBatteryCharge());
    aircraft.setArchived(entity.isArchived());
    if (aircraft.isArchived()) {
      removeAircraftFromProjects(aircraft);
    }
    return aircraft;
  }

  @Override
  public Aircraft findFirstByOrderByIdDesc() {
    return repository.findFirstByOrderByIdDesc();
  }

  @Override
  public List<Aircraft> findByAircraftShipNo(String aircraftShipNo, String userId) {
    if (keycloakService.isUserAndInRole(userId, KeycloakRole.IT_ADMIN.getName())) {
      return repository.findByAircraftShipNo(aircraftShipNo);
    } else if (keycloakService.isUserAndInRole(userId, KeycloakRole.ENGINEERING_ADMIN.getName())) {
      return repository.findByCloakedFalseAndAircraftShipNo(aircraftShipNo);
    } else {
      return repository.findByCloakedFalseAndArchivedFalseAndAircraftShipNo(aircraftShipNo);
    }
  }

  @Override
  @Transactional
  public void deleteById(Long id) {
    Aircraft aircraft =
        repository
            .findById(id)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to locate Aircraft (id: '" + id + "').", Level.ERROR));

    // cannot delete if ELA exists (per business)
    if (!aircraft.getElas().isEmpty()) {
      throw new ConflictException(
          "Aircraft '" + aircraft.getAircraftShipNo() + "' has an associated ELA. Cannot delete.",
          Level.ERROR);
    }

    // cannot delete if cloaked (per business)
    if (aircraft.isCloaked()) {
      throw new ConflictException(
          "Aircraft '" + aircraft.getAircraftShipNo() + "' is cloaked. Cannot delete.",
          Level.ERROR);
    }

    repository.deleteById(id);
  }

  @Override
  public List<Aircraft> findAllCloaked() {
    return repository.findAllByCloakedTrueOrderByAircraftShipNoAsc();
  }

  @Override
  public List<Aircraft> findCloakedByAircraftShipNoAsc(String aircraftShipNo) {
    return repository.findAllByCloakedTrueAndAircraftShipNo(aircraftShipNo);
  }

  @Override
  @Transactional
  public void cloak(Long aircraftId) {
    Aircraft aircraft =
        repository
            .findById(aircraftId)
            .orElseThrow(
                () -> new BadRequestException("Aircraft Resource id " + aircraftId + " not found"));
    aircraft.setCloaked(true);
    removeAircraftFromProjects(aircraft);
  }

  @Override
  @Transactional
  public void uncloak(Long aircraftId) {
    Aircraft aircraft =
        repository
            .findById(aircraftId)
            .orElseThrow(
                () -> new BadRequestException("Aircraft Resource id " + aircraftId + " not found"));
    aircraft.setCloaked(false);
  }

  private Aircraft addFleet(Aircraft entity, Long fleetId) {
    Fleet fleet =
        fleetRepo
            .findById(fleetId)
            .orElseThrow(
                () -> new BadRequestException("Fleet Resource id " + fleetId + " not found"));
    entity.setFleet(fleet);
    return entity;
  }

  private void removeAircraftFromProjects(Aircraft aircraft) {
    List<AircraftChangeGroup> acgList = new ArrayList<>(aircraft.getAircraftChangeGroups());
    for (AircraftChangeGroup acg : acgList) {
      if (acg.getChangeGroup() != null
          && acg.getChangeGroup().getProject() != null
          && acg.getChangeGroup().getProject().getApproved() != null) {
        continue; // Merged Projects retain the aircraft reference
      }
      if (acg.getChangeGroup() != null) {
        acg.getChangeGroup().removeAircraftChangeGroup(acg);
      }
      aircraft.removeAircraftChangeGroup(acg);
    }
  }
}
