package com.seatec.ela.app.config;

import static com.seatec.ela.app.util.enumeration.Utility.concatenate;

import org.keycloak.adapters.KeycloakConfigResolver;
import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.adapters.springsecurity.KeycloakConfiguration;
import org.keycloak.adapters.springsecurity.client.KeycloakClientRequestFactory;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.keycloak.adapters.springsecurity.config.KeycloakWebSecurityConfigurerAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

@KeycloakConfiguration
public class KeycloakSecurityConfig extends KeycloakWebSecurityConfigurerAdapter {

  @Value("${spring.profiles.active}")
  private String ACTIVE_PROFILE;

  private static final String[] BASE_NO_AUTH_PATHS =
      new String[] {"/actuator", "/actuator/*", "/health"};

  private static final String[] SWAGGER_PATHS =
      new String[] {
        "/v2/api-docs",
        "/configuration/**",
        "/swagger-resources",
        "/swagger-resources/**",
        "/configuration/security",
        "/swagger-ui.html",
        "/webjars/**"
      };

  /** Registers the KeycloakAuthenticationProvider with the authentication manager. */
  @Autowired
  public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
    auth.authenticationProvider(keycloakAuthenticationProvider());
  }

  /** Defines the session authentication strategy. */
  @Bean
  @Override
  protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
    return new RegisterSessionAuthenticationStrategy(new SessionRegistryImpl());
  }

  /** We require the user to be logged in for every single request */
  @Override
  protected void configure(HttpSecurity http) throws Exception {
    super.configure(http);

    String[] noAuthPaths = BASE_NO_AUTH_PATHS;

    // Only enable Swagger in non-prod
    if (ACTIVE_PROFILE.contains("enableSwagger")) {
      noAuthPaths = concatenate(BASE_NO_AUTH_PATHS, SWAGGER_PATHS);
    }

    http.csrf()
        .disable()
        .authorizeRequests()
        .antMatchers(noAuthPaths)
        .permitAll()
        .anyRequest()
        .authenticated();
  }

  @Bean
  @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
  public KeycloakRestTemplate keycloakRestTemplate() {
    return new KeycloakRestTemplate(new KeycloakClientRequestFactory());
  }

  /**
   * Let Spring Boot establish the keycloak config
   *
   * @return
   */
  @Bean
  public KeycloakConfigResolver KeycloakConfigResolver() {
    return new KeycloakSpringBootConfigResolver();
  }
}
