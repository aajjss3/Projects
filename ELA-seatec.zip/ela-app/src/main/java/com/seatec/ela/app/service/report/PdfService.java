package com.seatec.ela.app.service.report;

import com.lowagie.text.Chapter;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.exception.InternalServerErrorException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.service.EfficiencyTableService;
import com.seatec.ela.app.service.NodeService;
import com.seatec.ela.app.service.contract.IEfficiencyTableService;
import com.seatec.ela.app.service.contract.report.IPdfAnalysisService;
import com.seatec.ela.app.service.contract.report.IPdfElaService;
import com.seatec.ela.app.service.contract.report.IPdfHistoryService;
import com.seatec.ela.app.service.contract.report.IPdfProjectService;
import com.seatec.ela.app.service.contract.report.IPdfService;
import com.seatec.ela.app.util.NodeUtil;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.pdf.PageNumeration;
import com.seatec.ela.app.util.pdf.PdfFormatUtil;
import java.io.ByteArrayOutputStream;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Contains PDF Service helper methods for generating ELA and Project reports Includes theming,
 * styles, formatting, analysis, history, etc.
 */
@Service
public class PdfService implements IPdfService {

  // global fonts
  private static final String CHANGE_HISTORY_TITLE = "Revision History";
  private static final String EFFECTIVITY_SUMMARY_TITLE = "Effectivity Summary";
  private static final String PROJECT_ANALYSIS_TITLE = "Project Analysis";
  private static final String ELA_SUMMARY_TITLE = "ELA Summary";
  private static final String ELA_SHIP_SUMMARY_TITLE =
      "ELA Ship Summary (includes all sub-bus components)";
  private static final String AIRCRAFT_INFO_TITLE = "Aircraft Information";

  @Autowired private IPdfAnalysisService pdfAnalysisService;

  @Autowired private IPdfHistoryService pdfHistoryService;

  @Autowired private IPdfElaService pdfElaService;

  @Autowired private IPdfProjectService pdfProjectService;

  @Autowired private NodeService nodeService;

  @Autowired private IEfficiencyTableService efficiencyTableService;

  @Autowired private ClientConfig clientConfig;

  public void PdfService() {}

  public void PdfService(
      PdfAnalysisService pdfAnalysisService,
      IPdfHistoryService pdfHistoryService,
      PdfElaService pdfElaService,
      PdfProjectService pdfProjectService,
      EfficiencyTableService efficiencyTableService,
      ClientConfig clientConfig) {
    this.pdfAnalysisService = pdfAnalysisService;
    this.pdfHistoryService = pdfHistoryService;
    this.pdfElaService = pdfElaService;
    this.pdfProjectService = pdfProjectService;
    this.efficiencyTableService = efficiencyTableService;
    this.clientConfig = clientConfig;
  }

  /**
   * This method generates a ELA level PDF document. The PDF document contains 3 section: 1) Cover
   * Page - Ela level summary 2) Change History - Details for each change applied across all Change
   * Groups in a Project 3) Analysis - Full effectivity analysis for each aircraft within each
   * Change Group in a Project
   *
   * @param ela Ela Entity
   * @return ByteArrayOutputStream (pdf)
   */
  public ByteArrayOutputStream getElaPdf(Ela ela, boolean faaReport) {
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    Aircraft aircraft = ela.getAircraft();
    Fleet fleet = aircraft.getFleet();

    try (Document document = new Document(PageSize.A4.rotate())) {
      PdfWriter writer = PdfWriter.getInstance(document, output);
      String reportName = clientConfig.getElaReportName();
      if (faaReport) {
        PageNumeration pageNumerationEvent = new PageNumeration(clientConfig.getFaaElaReportName());
        writer.setPageEvent(pageNumerationEvent);
        reportName = clientConfig.getFaaElaReportName();
      } else {
        PageNumeration pageNumerationEvent = new PageNumeration(clientConfig.getElaReportName());
        writer.setPageEvent(pageNumerationEvent);
      }

      document.open();

      // set custom margins (default 36 user units on each side)
      document.setMargins(15, 15, 15, 15);

      // cover page section
      PdfPTable coverPageTable =
          pdfElaService.generateCoverPageForEla(
              aircraft.getAircraftShipNo(), reportName, clientConfig.getFaaElaName(), faaReport);
      document.add(coverPageTable);

      // aircraft information #1
      Chapter shipInfoChapter = PdfFormatUtil.generateChapter(AIRCRAFT_INFO_TITLE, 2);
      document.add(shipInfoChapter);
      PdfPTable shipInfoTable = pdfElaService.generateShipInfo(ela);
      document.add(shipInfoTable);

      // aircraft summary section
      Chapter elaShipSummaryChapter = PdfFormatUtil.generateChapter(ELA_SHIP_SUMMARY_TITLE, 2);
      document.add(elaShipSummaryChapter);
      PdfPTable shipSummaryTable = pdfElaService.generateShipSummary(ela);
      document.add(shipSummaryTable);

      // exclude Battery Supplied flight phases
      List<FlightPhaseDto> flightPhases =
          FlightPhase.getFlightPhases(
              fleet.getManufacturer(), fleet.isEtops(), fleet.getName(), true);
      boolean isBoeing = PdfFormatUtil.isBoeingAircraft(fleet.getManufacturer());

      // analysis section
      PdfPTable elaAnalysisSection =
          pdfAnalysisService.generateElaAnalysisSection(
              ela.getId(), flightPhases, isBoeing, faaReport);
      document.newPage();
      document.add(elaAnalysisSection);

      Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

      LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

      LoadSummaryRequest loadSummaryRequest =
          new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

      List<Node> topLevelNodes = nodeService.hydrateNodes(ela.getId(), loadSummaryRequest);

      // get the complete list of nodes. each node contains summarized loads
      List<Node> flatNodeList = NodeUtil.flattenNodeTrees(topLevelNodes);
      List<String> operatingModes = fleet.getOperatingModes();

      if (!faaReport) {
        Chapter elaSummaryChapter = PdfFormatUtil.generateChapter(ELA_SUMMARY_TITLE, 3);
        document.add(elaSummaryChapter);

        // append ELA Summary data (done this way to allow document.newPage() declaration)
        pdfElaService.generateElaSummary(
            document, ela.getNodes(), flatNodeList, operatingModes, flightPhases, isBoeing);
      }

      // project change history section
      PdfPTable changeHistorySection =
          pdfHistoryService.generateElaChangeHistory(aircraft.getAircraftShipNo());
      document.newPage();
      document.add(changeHistorySection);
    } catch (DocumentException de) {
      throw new InternalServerErrorException(
          String.format("Unable to generate report for ela '%s'.", ela.getId()), Level.ERROR, de);
    }

    return output;
  }

  /**
   * This method generates a Project level PDF document. The PDF document contains 3 section: 1)
   * Cover Page - project level summary and Signatures for a Project 2) Change History - Details for
   * each change applied across all Change Groups in a Project 3) Analysis - Full effectivity
   * analysis for each aircraft within each Change Group in a Project
   *
   * @param project Project Entity
   * @return ByteArrayOutputStream (pdf)
   */
  public ByteArrayOutputStream getProjectPdf(Project project) {
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    // get changeGroups (sort by name ASC)
    List<ChangeGroup> changeGroups =
        project.getChangeGroups().stream()
            .sorted(Comparator.comparing(ChangeGroup::getName))
            .collect(Collectors.toList());

    try (Document document = new Document()) {
      PdfWriter writer = PdfWriter.getInstance(document, output);
      PageNumeration pageNumerationEvent = new PageNumeration(clientConfig.getProjectReportName());
      writer.setPageEvent(pageNumerationEvent);

      document.open();

      // cover page section
      PdfPTable coverPageTable = pdfProjectService.generateCoverPageForProject(project);
      document.add(coverPageTable);

      // effectivity summary section
      Chapter effectivitySummaryChapter =
          PdfFormatUtil.generateChapter(EFFECTIVITY_SUMMARY_TITLE, 2);
      document.add(effectivitySummaryChapter);
      PdfPTable effectivityTable = pdfProjectService.generateEffectivitySummary(changeGroups);
      document.add(effectivityTable);

      // changes summary section
      Chapter changeHistoryChapter = PdfFormatUtil.generateChapter(CHANGE_HISTORY_TITLE, 3);
      document.add(changeHistoryChapter);

      // verify a change exists to display this section
      Optional<Change> change =
          changeGroups.stream().flatMap(cg -> cg.getChanges().stream()).findAny();

      PdfPTable changeHistorySection;

      if (change.isPresent()) {
        changeHistorySection =
            pdfHistoryService.generateProjectChangeHistory(
                changeGroups, project.getApproved() != null);
      } else {
        changeHistorySection = PdfFormatUtil.createTextTable("No changes found.");
      }

      document.add(changeHistorySection);

      // analysis section
      document.setPageSize(PageSize.A4.rotate()); // change to landscape layout
      Chapter projectAnalysisChapter = PdfFormatUtil.generateChapter(PROJECT_ANALYSIS_TITLE, 4);
      document.add(projectAnalysisChapter);
      PdfPTable projectAnalysisSection =
          pdfAnalysisService.generateProjectAnalysisSection(changeGroups);
      document.add(projectAnalysisSection);
    } catch (DocumentException de) {
      throw new InternalServerErrorException(
          "Unable to generate report for project '" + project.getTitle() + "'.", Level.ERROR, de);
    }

    return output;
  }
}
