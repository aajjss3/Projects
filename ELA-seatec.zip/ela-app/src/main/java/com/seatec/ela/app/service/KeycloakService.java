package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.KeycloakUserDto;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.service.contract.IKeycloakExternalService;
import com.seatec.ela.app.service.contract.IKeycloakService;
import com.seatec.ela.app.util.KeycloakDataConverter;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.apache.commons.lang3.RandomStringUtils;
import org.keycloak.representations.idm.CredentialRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class KeycloakService implements IKeycloakService {

  public static final String DEFAULT_ROLE = "user";
  public static final String UMA_PROTECTION_ROLE = "uma_protection";
  public static final String REALM_MANAGEMENT_CLIENT = "realm-management";
  private static final String VIEW_CLIENTS = "view-clients";
  private static final String VIEW_USERS = "view-users";
  private static final String MANAGE_USERS = "manage-users";

  @Autowired private IKeycloakExternalService keycloakExternalService;

  @Autowired private KeycloakDataConverter keycloakDataConverter;

  @Autowired private EmailExternalService emailService;

  @Value("${keycloak.resource}")
  private String keycloakClient;

  @Value("${keycloak-ui-client}")
  private String keycloakUIClient;

  public KeycloakService() {}

  public KeycloakService(
      String keycloakClient,
      String keycloakUIClient,
      IKeycloakExternalService keycloakExternalService,
      KeycloakDataConverter keycloakDataConverter,
      EmailExternalService emailExternalService) {
    this.keycloakClient = keycloakClient;
    this.keycloakUIClient = keycloakUIClient;
    this.keycloakExternalService = keycloakExternalService;
    this.keycloakDataConverter = keycloakDataConverter;
    this.emailService = emailExternalService;
  }

  public List<KeycloakUserDto> findUsersInRole(String roleName) {
    return keycloakExternalService.findAllUsers().stream()
        .map(keycloakDataConverter::convertToUserDto)
        .filter(u -> roleName.equals(u.getRole()))
        .collect(Collectors.toList());
  }

  public UserRepresentation findUser(String id) {
    return keycloakExternalService.findUser(id);
  }

  public List<UserRepresentation> findAllActiveUsers() {
    return findAllActiveUserRepresentations();
  }

  public void createUser(KeycloakUserDto user) {
    UserRepresentation newUser = new UserRepresentation();

    newUser.setFirstName(user.getFirstName());
    newUser.setLastName(user.getLastName());
    newUser.setEmail(user.getEmail());
    newUser.setUsername(user.getEmail());
    newUser.setEmailVerified(true);
    newUser.setEnabled(true);

    // Add Required Action
    newUser.setRequiredActions(Collections.singletonList("UPDATE_PASSWORD"));

    // set Credentials (temp password)
    CredentialRepresentation passwordCred = new CredentialRepresentation();
    passwordCred.setTemporary(true);
    passwordCred.setType(CredentialRepresentation.PASSWORD);
    String tempPassword = createTempPassword();
    passwordCred.setValue(tempPassword);
    newUser.setCredentials(Collections.singletonList(passwordCred));

    // verify role is valid/exists
    verifyRoleExists(user.getRole());

    newUser.setClientRoles(createClientRoles(user.getRole()));

    keycloakExternalService.createUser(newUser);
    emailService.sendUserLoginEmail(newUser, tempPassword);
  }

  public void updateUser(KeycloakUserDto user, String id) {
    UserRepresentation existingUser = keycloakExternalService.findUser(id);

    // does user exist
    if (existingUser == null) {
      throw new NotFoundException("Unable to locate User (" + id + ")", Level.ERROR);
    }

    // does role exist
    verifyRoleExists(user.getRole());

    // did the email address change
    if (!existingUser.getEmail().equalsIgnoreCase(user.getEmail())) {
      // disable existing user
      existingUser.setEnabled(false);
      keycloakExternalService.updateUser(existingUser);

      // create new account
      createUser(user);
    } else {
      existingUser.setFirstName(user.getFirstName());
      existingUser.setLastName(user.getLastName());
      existingUser.setEnabled(user.getEnabled());
      existingUser.setClientRoles(createClientRoles(user.getRole()));
      keycloakExternalService.updateUser(existingUser);
    }
  }

  public boolean isUserAndInRole(String id, String roleName) {
    return isUserInRole(roleName, keycloakExternalService.findUser(id));
  }

  /**
   * Checks the user's id is a valid GUID, the user exists, and the user has one of the roles passed
   * in.
   *
   * @param userId
   * @param validRoles
   * @return
   */
  public boolean isUserValidAndInRoles(String userId, List<String> validRoles) {
    try {
      UUID.fromString(userId);
      UserRepresentation user = findUser(userId);
      // get the users keycloak role
      String userRole = keycloakDataConverter.convertToUserDto(user).getRole();
      return validRoles.stream().anyMatch(role -> role.equalsIgnoreCase(userRole));
    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public List<String> findAllRoles() {
    return keycloakExternalService.findAllRoles();
  }

  private Map<String, List<String>> createClientRoles(String role) {
    Map<String, List<String>> clientRoles = new HashMap<>();
    clientRoles.put(keycloakClient, Arrays.asList(role, DEFAULT_ROLE));
    clientRoles.put(keycloakUIClient, Arrays.asList(role));
    if (role.equals(KeycloakRole.IT_ADMIN.getName())
        || role.equals(KeycloakRole.ENGINEERING_ADMIN.getName())) {
      clientRoles.put(
          REALM_MANAGEMENT_CLIENT, Arrays.asList(VIEW_USERS, MANAGE_USERS, VIEW_CLIENTS));
    } else if (role.equals(KeycloakRole.AUTHOR.getName())
        || role.equals(KeycloakRole.CHECKER.getName())
        || role.equals(KeycloakRole.APPROVER.getName())) {
      clientRoles.put(REALM_MANAGEMENT_CLIENT, Arrays.asList(VIEW_USERS, VIEW_CLIENTS));
    }
    return clientRoles;
  }

  private List<UserRepresentation> findAllActiveUserRepresentations() {
    return keycloakExternalService.findAllUsers().stream()
        .filter(user -> user.isEnabled())
        .collect(Collectors.toList());
  }

  private boolean isUserInRole(String roleName, UserRepresentation userRepresentation) {
    if (userRepresentation == null) {
      return false;
    }

    return roleName.equalsIgnoreCase(
        keycloakDataConverter.convertToUserDto(userRepresentation).getRole());
  }

  private String createTempPassword() {
    // password must have 1 upper, 1 lower, length 8, 1 special
    return (RandomStringUtils.random(16, true, true) + "a1B!");
  }

  private void verifyRoleExists(String roleName) {
    // verify role exists => throw exception if not found
    RoleRepresentation roleRepresentation = keycloakExternalService.getRoleByName(roleName);

    if (roleRepresentation == null) {
      throw new NotFoundException("Unable to locate Role (" + roleName + ")", Level.ERROR);
    }
  }
}
