package com.seatec.ela.app.dto.report;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class ProjectReportDTO implements Serializable {

  /**
   * If a serializable class doesn’t declare a serialVersionUID, the JVM will generate one
   * automatically at run-time. However, it is highly recommended that each class declares its
   * serialVersionUID as the generated one is compiler dependent and thus may result in unexpected
   * InvalidClassExceptions.
   */
  private static final long serialVersionUID = 1L;

  private List<ProjectReportChangeGroupDTO> projectReportChangeGroups = new ArrayList<>();

  private Instant created;

  public ProjectReportDTO() {
    created = Instant.now();
  }

  public List<ProjectReportChangeGroupDTO> getProjectReportChangeGroups() {
    return projectReportChangeGroups;
  }

  public void setProjectReportChangeGroups(
      List<ProjectReportChangeGroupDTO> projectReportChangeGroups) {
    this.projectReportChangeGroups = projectReportChangeGroups;
  }

  public void addProjectReportChangeGroup(ProjectReportChangeGroupDTO projectReportChangeGroups) {
    this.projectReportChangeGroups.add(projectReportChangeGroups);
  }

  public void removeProjectReportChangeGroup(
      ProjectReportChangeGroupDTO projectReportChangeGroups) {
    this.projectReportChangeGroups.remove(projectReportChangeGroups);
  }

  public Instant getCreated() {
    return created;
  }
}
