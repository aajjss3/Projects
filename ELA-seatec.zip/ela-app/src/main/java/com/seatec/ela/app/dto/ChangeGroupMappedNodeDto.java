package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackIdLong;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;

public class ChangeGroupMappedNodeDto implements UserTrackIdLong, UserTrackName {

  private Long id;

  private String name;

  private String fullName;

  private int displayOrder;

  private int level;

  private Boolean isGlobal;

  private Double voltage;

  private Double nominalPower;

  private NodeType nodeType;

  private boolean requiresApproval;

  private Double busRating;

  private boolean sheddable;

  private ElectricalPhase voltageType;

  private boolean normalTr;

  private String description;

  private ElectricalPhase electricalPhase;

  public ChangeGroupMappedNodeDto() {}

  public ChangeGroupMappedNodeDto(
      Long id, String name, String fullName, int displayOrder, int level) {
    this.id = id;
    this.name = name;
    this.fullName = fullName;
    this.displayOrder = displayOrder;
    this.level = level;
  }

  public ChangeGroupMappedNodeDto(
      Long id,
      String name,
      String fullName,
      int displayOrder,
      int level,
      Double voltage,
      Double nominalPower,
      NodeType nodeType,
      boolean requiresApproval,
      Double busRating,
      ElectricalPhase voltageType,
      boolean normalTr,
      boolean sheddable,
      String description,
      ElectricalPhase electricalPhase) {
    this.id = id;
    this.name = name;
    this.fullName = fullName;
    this.displayOrder = displayOrder;
    this.level = level;
    this.isGlobal = Boolean.FALSE;
    this.voltage = voltage;
    this.nominalPower = nominalPower;
    this.nodeType = nodeType;
    this.requiresApproval = requiresApproval;
    this.busRating = busRating;
    this.sheddable = sheddable;
    this.voltageType = voltageType;
    this.normalTr = normalTr;
    this.description = description;
    this.electricalPhase = electricalPhase;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getFullName() {
    return fullName;
  }

  public void setFullName(String fullName) {
    this.fullName = fullName;
  }

  public int getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(int displayOrder) {
    this.displayOrder = displayOrder;
  }

  public int getLevel() {
    return level;
  }

  public void setLevel(int level) {
    this.level = level;
  }

  public Boolean getIsGlobal() {
    return isGlobal;
  }

  public void setIsGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public Double getBusRating() {
    return busRating;
  }

  public void setBusRating(Double busRating) {
    this.busRating = busRating;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public ElectricalPhase getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(ElectricalPhase voltageType) {
    this.voltageType = voltageType;
  }

  public boolean isNormalTr() {
    return normalTr;
  }

  public void setNormalTr(boolean normalTr) {
    this.normalTr = normalTr;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }
}
