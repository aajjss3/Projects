package com.seatec.ela.app.dto.email;

import java.util.ArrayList;
import java.util.List;

public class ProjectChangeNotification {
  private String projectTitle;
  private String projectNumber;
  private String projectRevision;
  private List<String> recipients;
  private List<ProjectChange> projectChanges = new ArrayList<>();

  public ProjectChangeNotification(
      String projectTitle, String projectNumber, String projectRevision, List<String> recipients) {
    this.projectTitle = projectTitle;
    this.projectNumber = projectNumber;
    this.projectRevision = projectRevision;
    this.recipients = recipients;
  }

  public String getProjectTitle() {
    return projectTitle;
  }

  public void setProjectTitle(String projectTitle) {
    this.projectTitle = projectTitle;
  }

  public String getProjectNumber() {
    return projectNumber;
  }

  public void setProjectNumber(String projectNumber) {
    this.projectNumber = projectNumber;
  }

  public String getProjectRevision() {
    return projectRevision;
  }

  public void setProjectRevision(String projectRevision) {
    this.projectRevision = projectRevision;
  }

  public List<String> getRecipients() {
    return recipients;
  }

  public void setRecipients(List<String> recipients) {
    this.recipients = recipients;
  }

  public List<ProjectChange> getProjectChanges() {
    return projectChanges;
  }

  public void setProjectChanges(List<ProjectChange> projectChanges) {
    this.projectChanges = projectChanges;
  }

  public void addProjectChange(ProjectChange projectChange) {
    this.projectChanges.add(projectChange);
  }
}
