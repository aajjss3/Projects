package com.seatec.ela.app.util.enumeration;

public enum KeycloakRole {
  VIEWER("viewer"),
  AUTHOR("author"),
  CHECKER("checker"),
  APPROVER("approver"),
  ENGINEERING_ADMIN("engineering_admin"),
  IT_ADMIN("it_admin");

  private final String name;

  /** */
  KeycloakRole(final String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
