package com.seatec.ela.app.model.base;

import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

@MappedSuperclass
public class BaseNodeChange extends BaseChange {
  @Column(name = "bus_rating")
  private Double busRating;

  @Column(name = "sheddable")
  private boolean sheddable;

  // TRUs only - used to determine if included in Degraded Analysis
  @Column(name = "normal_tr")
  private boolean normalTr;

  @Column(name = "requires_approval")
  private boolean requiresApproval;

  @NotNull(message = "{field.required}")
  @Enumerated(EnumType.STRING)
  @Column(name = "node_type", length = 20)
  private NodeType nodeType;

  @NotNull(message = "{field.required}")
  @Column(name = "voltage")
  private Double voltage;

  @NotNull(message = "{field.required}")
  @Column(name = "voltage_type")
  @Enumerated(EnumType.STRING)
  private ElectricalPhase voltageType;

  @Enumerated(EnumType.STRING)
  @Column(name = "electrical_phase")
  private ElectricalPhase electricalPhase;

  @Column(name = "description")
  private String description;

  public Double getBusRating() {
    return busRating;
  }

  public void setBusRating(Double busRating) {
    this.busRating = busRating;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public boolean isNormalTr() {
    return normalTr;
  }

  public void setNormalTr(boolean normalTr) {
    this.normalTr = normalTr;
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public ElectricalPhase getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(ElectricalPhase voltageType) {
    this.voltageType = voltageType;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }
}
