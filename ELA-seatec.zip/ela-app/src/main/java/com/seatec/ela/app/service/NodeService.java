package com.seatec.ela.app.service;

import com.google.common.collect.ImmutableMap;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.service.contract.IEfficiencyTableService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.util.NodeUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NodeService implements INodeService {

  private final NodeRepository nodeRepository;

  private final ComponentRepository componentRepository;

  private final LoadRepository loadRepository;

  private final LoadSummaryService loadSummaryService;

  private final IEfficiencyTableService efficiencyTableService;

  @Autowired
  public NodeService(
      NodeRepository nodeRepository,
      ComponentRepository componentRepository,
      LoadRepository loadRepository,
      LoadSummaryService loadSummaryService,
      IEfficiencyTableService efficiencyTableService) {
    this.nodeRepository = nodeRepository;
    this.componentRepository = componentRepository;
    this.loadRepository = loadRepository;
    this.loadSummaryService = loadSummaryService;
    this.efficiencyTableService = efficiencyTableService;
  }

  @Override
  @Transactional(readOnly = true)
  @Cacheable(value = "hydrateEla", key = "#ela.id")
  public Ela hydrateEla(Ela ela) {
    Ela clone = ela.shallowCopy();

    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();
    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, false);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    clone.setNodes(hydrateNodes(ela.getId(), loadSummaryRequest));
    Collections.sort(clone.getNodes(), Comparator.comparing(Node::getDisplayOrder));
    return clone;
  }

  @Override
  @Transactional(readOnly = true)
  @Cacheable("hydrateNodes")
  public List<Node> hydrateNodes(Long elaId, LoadSummaryRequest loadSummaryRequest) {
    return hydrateNodes(null, elaId, loadSummaryRequest);
  }

  @Override
  @Transactional(readOnly = true)
  @Cacheable("hydrateNodes")
  public List<Node> hydrateNodes(
      List<Long> topLevelNodeIds, Long elaId, LoadSummaryRequest loadSummaryRequest) {

    List<Node> nodes = nodeRepository.getNodesInEla(elaId);
    Map<Node, List<Node>> nodeMap = NodeUtil.groupNodesByParent(nodes);

    List<Component> components = componentRepository.getComponentsInEla(elaId);
    Map<Node, List<Component>> componentMap = NodeUtil.groupComponentsByNode(components);

    List<Load> loads = loadRepository.getLoadsInEla(elaId);
    Map<Component, List<Load>> loadMap = NodeUtil.groupLoadsByComponent(loads);

    Map<Long, Node> nodesById =
        nodes.stream().collect(Collectors.toMap(Node::getId, Function.identity()));

    if (topLevelNodeIds == null) {
      topLevelNodeIds = NodeUtil.getTopLevelNodeIds(nodes);
    }

    List<Node> hydratedNodes = new ArrayList<>();
    topLevelNodeIds.forEach(
        nodeId -> {
          if (nodesById.containsKey(nodeId)) {
            Node node = nodesById.get(nodeId);
            Node hydratedNode =
                copyNodeTree(
                    node,
                    ImmutableMap.copyOf(nodeMap),
                    ImmutableMap.copyOf(componentMap),
                    ImmutableMap.copyOf(loadMap),
                    loadSummaryRequest);
            hydratedNodes.add(hydratedNode);
          }
        });

    return hydratedNodes;
  }

  @Override
  @Transactional(readOnly = true)
  @Cacheable("findByIdNodes")
  public Optional<Node> findById(Long id, Long elaId, LoadSummaryRequest loadSummaryRequest) {
    List<Node> nodes = hydrateNodes(Arrays.asList(id), elaId, loadSummaryRequest);
    return nodes.size() > 0 ? Optional.of(nodes.get(0)) : Optional.empty();
  }

  @Override
  public Node getNodeByName(List<Node> nodes, String nodeName) {
    return NodeUtil.getNodeByName(nodes, nodeName);
  }

  @Override
  public Map<Component, List<Load>> getLoadsByComponent(List<Load> loads) {
    return NodeUtil.groupLoadsByComponent(loads);
  }

  /**
   * Copy all nodes in the tree including their subNodes, components, and loads
   *
   * @param srcNode - the source node to be copied
   * @param nodeMap - a map of subNodes grouped by their parent nodes
   * @param componentMap - a map of components grouped by their nodes
   * @param loadMap - a map of loads grouped by their components
   * @param loadSummaryRequest - load summary request, if null then load summaries aren't calculated
   * @return a copy of the source node's tree including the subNodes, components, and loads
   */
  private Node copyNodeTree(
      @NotNull Node srcNode,
      @NotNull Map<Node, List<Node>> nodeMap,
      @NotNull Map<Node, List<Component>> componentMap,
      @NotNull Map<Component, List<Load>> loadMap,
      LoadSummaryRequest loadSummaryRequest) {

    Node copy = srcNode.shallowCopy();

    if (componentMap.containsKey(srcNode)) {
      copyComponents(copy, componentMap.get(srcNode), loadMap);
    }

    if (nodeMap.containsKey(srcNode)) {
      copySubNodes(copy, nodeMap.get(srcNode), nodeMap, componentMap, loadMap, loadSummaryRequest);
    }

    // calculate load summaries after the copy's subtree has been built
    if (loadSummaryRequest != null) {
      List<SummarizedLoad> summarizedLoads =
          loadSummaryService.retrieveLoadSummaries(copy, loadSummaryRequest);
      copy.setSummarizedLoads(summarizedLoads);
    }

    return copy;
  }

  /**
   * Copy the subNodes and add them to the destination parent node.
   *
   * @param dstParentNode - the destination parent node where the subNodes will be copied
   * @param srcSubNodes - the source subNodes to be copied and added to the destination parent node
   * @param nodeMap - a map of subNodes grouped by their parent nodes
   * @param componentMap - a map of components grouped by their nodes
   * @param loadMap - a map of loads grouped by their components
   * @param loadSummaryRequest - load summary request, if null then load summaries aren't calculated
   */
  private void copySubNodes(
      @NotNull Node dstParentNode,
      @NotNull List<Node> srcSubNodes,
      @NotNull Map<Node, List<Node>> nodeMap,
      @NotNull Map<Node, List<Component>> componentMap,
      @NotNull Map<Component, List<Load>> loadMap,
      LoadSummaryRequest loadSummaryRequest) {

    List<Node> copySubNodes =
        srcSubNodes.stream()
            .map(
                srcSubNode ->
                    copyNodeTree(srcSubNode, nodeMap, componentMap, loadMap, loadSummaryRequest))
            .sorted(Comparator.comparing(Node::getDisplayOrder))
            .collect(Collectors.toList());
    dstParentNode.setSubNodes(copySubNodes);
  }

  /**
   * Copy the source components and add them to the destination node.
   *
   * @param dstNode - the destination node where the components will be copied
   * @param srcComponents - the source components to be copied and added to the destination node
   * @param loadMap - a map of loads grouped by their components
   */
  private void copyComponents(
      @NotNull Node dstNode,
      @NotNull List<Component> srcComponents,
      @NotNull Map<Component, List<Load>> loadMap) {

    List<Component> copyComponents =
        srcComponents.stream()
            .map(
                srcComponent -> {
                  Component copy = srcComponent.shallowCopy();
                  if (loadMap.containsKey(srcComponent)) {
                    copyLoads(copy, loadMap.get(srcComponent));
                  }
                  copy.setNode(dstNode);
                  return copy;
                })
            .sorted(Comparator.comparing(Component::getDisplayOrder))
            .collect(Collectors.toList());
    dstNode.setComponents(copyComponents);
  }

  /**
   * Copy the source loads and add them to the destination component.
   *
   * @param dstComponent - the destination component where the loads will be copied
   * @param srcLoads - the src loads to be copied and added to the destination component
   */
  private void copyLoads(@NotNull Component dstComponent, @NotNull List<Load> srcLoads) {

    List<Load> copyLoads =
        srcLoads.stream()
            .map(
                srcLoad -> {
                  Load copy = srcLoad.shallowCopy();
                  copy.setComponent(dstComponent);
                  return copy;
                })
            .collect(Collectors.toList());
    dstComponent.setLoads(copyLoads);
  }
}
