package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.service.KeycloakService;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import com.seatec.ela.app.validator.annotation.ValidateEngineer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

public class ValidateEngineerValidator implements ConstraintValidator<ValidateEngineer, String> {

  private KeycloakRole keycloakRole;

  @Autowired private KeycloakService keycloakService;

  public ValidateEngineerValidator() {}

  public ValidateEngineerValidator(KeycloakService keycloakService) {
    this.keycloakService = keycloakService;
  }

  @Override
  public void initialize(ValidateEngineer constraintAnnotation) {
    this.keycloakRole = constraintAnnotation.keycloakRole();
  }

  @Override
  public boolean isValid(String engineer, ConstraintValidatorContext context) {
    if (engineer != null) {
      List<String> roles = getValidRoles(keycloakRole);
      return keycloakService.isUserValidAndInRoles(engineer, roles);
    }
    return true;
  }

  private List<String> getValidRoles(KeycloakRole role) {
    if (role != null) {
      switch (role) {
        case VIEWER:
          return Arrays.stream(KeycloakRole.values())
              .map(r -> r.getName())
              .collect(Collectors.toList());
        case AUTHOR:
          return Arrays.asList(
              KeycloakRole.AUTHOR.getName(),
              KeycloakRole.CHECKER.getName(),
              KeycloakRole.APPROVER.getName(),
              KeycloakRole.ENGINEERING_ADMIN.getName(),
              KeycloakRole.IT_ADMIN.getName());
        case CHECKER:
          return Arrays.asList(
              KeycloakRole.CHECKER.getName(),
              KeycloakRole.APPROVER.getName(),
              KeycloakRole.ENGINEERING_ADMIN.getName(),
              KeycloakRole.IT_ADMIN.getName());
        case APPROVER:
          return Arrays.asList(
              KeycloakRole.APPROVER.getName(),
              KeycloakRole.ENGINEERING_ADMIN.getName(),
              KeycloakRole.IT_ADMIN.getName());
        case ENGINEERING_ADMIN:
          return Arrays.asList(
              KeycloakRole.ENGINEERING_ADMIN.getName(), KeycloakRole.IT_ADMIN.getName());
        case IT_ADMIN:
          return Arrays.asList(KeycloakRole.IT_ADMIN.getName());
      }
    }
    return Collections.emptyList();
  }
}
