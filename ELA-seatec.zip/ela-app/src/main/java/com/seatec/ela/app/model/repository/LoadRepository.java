package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.Load;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LoadRepository extends CrudRepository<Load, Long> {

  @Query(
      nativeQuery = true,
      value =
          "WITH RECURSIVE nodetree AS "
              + "(SELECT id, name, voltage, nominal_power, display_order, node_id, ela_id, node_type, requires_approval, bus_rating, voltage_type, sheddable, description, efficiency_table_id, electrical_phase "
              + "FROM node n "
              + "WHERE node_id IS NULL AND ela_id = :elaId "
              + "UNION ALL "
              + "SELECT ni.id, ni.name, ni.voltage, ni.nominal_power, ni.display_order, ni.node_id, ni.ela_id, ni.node_type, ni.requires_approval, ni.bus_rating, ni.voltage_type, ni.sheddable, ni.description, ni.efficiency_table_id, ni.electrical_phase "
              + "FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id) "
              + ") "
              + "SELECT l.* FROM load l INNER JOIN component c ON l.component_id = c.id INNER JOIN nodetree nt ON nt.id = c.node_id")
  List<Load> getLoadsInEla(@Param("elaId") Long elaId);

  @Query(
      nativeQuery = true,
      value =
          "SELECT l.* FROM load l INNER JOIN component c ON l.component_id = c.id WHERE c.id IN :componentIds")
  List<Load> getLoadsInComponents(@Param("componentIds") List<Long> componentIds);
}
