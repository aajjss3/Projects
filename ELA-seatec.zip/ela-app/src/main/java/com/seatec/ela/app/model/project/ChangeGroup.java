package com.seatec.ela.app.model.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.base.BaseEntity;
import com.seatec.ela.app.model.project.change.Change;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

@Entity
@Table(
    name = "change_group",
    uniqueConstraints = {@UniqueConstraint(columnNames = {"project_id", "name"})})
public class ChangeGroup extends BaseEntity {

  @Column(length = 127)
  @NotBlank(message = "{field.required}")
  private String name;

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "project_id", updatable = false, nullable = false)
  private Project project;

  @OneToMany(
      fetch = FetchType.EAGER,
      mappedBy = "changeGroup",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();

  @OneToMany(
      mappedBy = "changeGroup",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<Change> changes = new ArrayList<>();

  public void addAircraftChangeGroup(AircraftChangeGroup aircraftChangeGroup) {
    aircraftChangeGroups.add(aircraftChangeGroup);
    aircraftChangeGroup.setChangeGroup(this);
  }

  public void removeAircraftChangeGroup(AircraftChangeGroup aircraftChangeGroup) {
    aircraftChangeGroups.remove(aircraftChangeGroup);
    aircraftChangeGroup.setChangeGroup(null);
  }

  public void addChange(Change change) {
    changes.add(change);
    change.setChangeGroup(this);
  }

  public void removeChange(Change change) {
    changes.remove(change);
    change.setChangeGroup(null);
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Project getProject() {
    return project;
  }

  public void setProject(Project project) {
    this.project = project;
  }

  public List<Change> getChanges() {
    return changes;
  }

  public void setChanges(List<Change> changes) {
    this.changes = changes;
  }

  public List<AircraftChangeGroup> getAircraftChangeGroups() {
    return aircraftChangeGroups;
  }

  public void setAircraftChangeGroups(List<AircraftChangeGroup> aircraftChangeGroups) {
    this.aircraftChangeGroups = aircraftChangeGroups;
  }
}
