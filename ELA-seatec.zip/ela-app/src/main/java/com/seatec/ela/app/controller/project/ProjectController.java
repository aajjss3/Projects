package com.seatec.ela.app.controller.project;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectCommentDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.ProjectWrapperDTO;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.service.contract.report.IPdfService;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.annotation.AircraftOrFleetExists;
import com.seatec.ela.app.validator.annotation.CoauthorValidation;
import com.seatec.ela.app.validator.annotation.IdExists;
import com.seatec.ela.app.validator.annotation.UnapprovedProject;
import com.seatec.ela.app.validator.filter.CreateProject;
import com.seatec.ela.app.validator.filter.UpdateProject;
import com.seatec.ela.app.validator.filter.ValidateProject;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/projects")
@Validated
public class ProjectController {

  @Autowired private IProjectService projectService;

  @Autowired private IPdfService pdfService;

  @GetMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public Optional<Project> getProjectById(@PathVariable("id") UUID id, HttpServletRequest request) {
    return projectService.findById(id, RequestUtil.getUserIdFromRequest(request));
  }

  /**
   * Return the Project data as a PDF with a content type of application/pdf. If input data
   * validation fails or an error occurs, then return the standard JSON response.
   *
   * @param projectId Unique identifier for a Project Entity
   * @return ResponseEntity<Resource>
   */
  @GetMapping("/{projectId}/report")
  public ResponseEntity<Resource> getProjectReport(
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      HttpServletRequest request) {

    Project project =
        projectService
            .findById(projectId, RequestUtil.getUserIdFromRequest(request))
            .orElseThrow(
                () ->
                    new NotFoundException(
                        String.format("Project (%s) not found.", projectId), Level.ERROR));

    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Disposition", "inline; filename=project-" + project.getTitle() + ".pdf");

    return ResponseEntity.ok()
        .headers(headers)
        .contentType(MediaType.APPLICATION_PDF)
        .body(new ByteArrayResource(pdfService.getProjectPdf(project).toByteArray()));
  }

  /**
   * Handles creating a new ProjectEntity (excludes statuses 'approved', 'checked', 'submitted',
   * 'retired')
   *
   * @param project Represents the new ProjectEntity and associated values
   * @return ProjectEntity
   */
  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public Project createProject(
      @Validated(value = {ValidateProject.class, CreateProject.class}) @RequestBody Project project,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    project.setAuthor(userId);
    return projectService.initialSave(project);
  }

  /**
   * Handles updating an existing ProjectEntity (excludes statuses 'approved', 'checked',
   * 'submitted', 'retired')
   *
   * @param project Represents the ProjectEntity and associated values
   * @param id Represents the ProjectEntity unique identifier (UUID)
   * @return void
   */
  @PutMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public void updateProject(
      @Validated(value = {ValidateProject.class, UpdateProject.class}) @RequestBody Project project,
      @UnapprovedProject @PathVariable("id") UUID id) {
    projectService.updateProject(project, id);
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public void deleteProjectById(
      @UnapprovedProject @PathVariable("id") UUID id, HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    projectService.deleteProject(id, userId);
  }

  /**
   * Retrieve all projects. Do not return a projects nested changeGroups. pagination is required
   *
   * @param page - page number starts at 1
   * @param size - number of projects to return in a request
   * @return a PaginationDTO which contains a collection of ProjectDTOs
   */
  @GetMapping()
  @ResponseStatus(HttpStatus.OK)
  public PaginationDTO<ProjectDTO> getProjects(
      @NotNull
          @Min(value = 1, message = "{field.value.min}")
          @RequestParam(value = "page", required = false)
          Integer page,
      @NotNull
          @Min(value = 1, message = "{field.value.min}")
          @RequestParam(value = "size", required = false)
          Integer size,
      HttpServletRequest request) {
    return projectService.getAllProjects(RequestUtil.getUserIdFromRequest(request), page, size);
  }

  /**
   * Retrieve a collection of projects created by a user that have not yet been approved. The user's
   * user id is located in the jwt token in the http header.
   *
   * @param page - if not null then use server side pagination. page number starts at 1
   * @param size - if not null then used server side pagination. number of projects to return in a
   *     request
   * @param sortField - name of the column/field to sort by. not required. will default to 'fleets'.
   * @param sortAscending - boolean indicating sort direction. not required. will default to 'ASC'.
   * @return a PaginationDTO which contains a collection of AssignedProjectDTOs
   */
  @GetMapping("myprojects")
  @ResponseStatus(HttpStatus.OK)
  public PaginationDTO<AssignedProjectDTO> getMyProjects(
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "page", required = false)
          Integer page,
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "size", required = false)
          Integer size,
      @Pattern(
              regexp =
                  "^(title|description|number|fleets|started|submitted|checked|approved|created)$",
              flags = Pattern.Flag.CASE_INSENSITIVE,
              message = "{field.allowed.values}")
          @RequestParam(value = "sortField", required = false, defaultValue = "created")
          String sortField,
      @RequestParam(value = "sortAscending", required = false, defaultValue = "true")
          boolean sortAscending,
      HttpServletRequest request) {
    return projectService.getMyProjects(
        RequestUtil.getUserIdFromRequest(request), page, size, sortField, sortAscending);
  }

  /**
   * Retrieve a collection of projects that are pending review by a user (either a checker or
   * approver). The user's user id is located in the jwt token in the http header. Pending review
   * projects are projects that have been submitted but have not already been checked or approved.
   *
   * @param page - if not null then use server side pagination. page number starts at 1
   * @param size - if not null then used server side pagination. number of projects to return in a
   *     request
   * @return a PaginationDTO which contains a collection of ProjectDTOs
   */
  @GetMapping("pendingreview")
  @ResponseStatus(HttpStatus.OK)
  public PaginationDTO<ProjectWrapperDTO> getPendingReviewProjects(
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "page", required = false)
          Integer page,
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "size", required = false)
          Integer size,
      HttpServletRequest request) {
    return projectService.getPendingReviewProjects(
        RequestUtil.getUserIdFromRequest(request), page, size);
  }

  /**
   * Project workflow: submit, check or approve a project.
   *
   * @param projectId - Unique Project Entity identifier
   * @param comment - Short summary of submission reason/purpose
   * @param request - User information related to request (auth)
   */
  @PatchMapping({"{projectId}/submit", "{projectId}/check", "{projectId}/approve"})
  @ResponseStatus(HttpStatus.OK)
  public void projectWorkflow(
      @IdExists(entity = Project.class, message = "project id does not exist")
          @UnapprovedProject
          @PathVariable("projectId")
          UUID projectId,
      @Validated @RequestBody ProjectCommentDTO comment,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    if (request.getServletPath().endsWith("submit")) {
      projectService.submitProject(projectId, userId, comment);
    } else if (request.getServletPath().endsWith("check")) {
      projectService.checkProject(projectId, userId, comment);
    } else if (request.getServletPath().endsWith("approve")) {
      projectService.approveProject(projectId, userId, comment);

      // perform after approval so db can persist everything
      projectService.saveProjectAnalysis(projectId);
    }
  }

  /**
   * Reject a project by either a check engineer or approval engineer
   *
   * @param projectId
   * @param comment
   * @param request
   */
  @PatchMapping({"{projectId}/approve/reject", "{projectId}/check/reject"})
  @ResponseStatus(HttpStatus.OK)
  public void rejectProject(
      @IdExists(entity = Project.class, message = "project id does not exist")
          @UnapprovedProject
          @PathVariable("projectId")
          UUID projectId,
      @Validated @RequestBody ProjectCommentDTO comment,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    if (request.getServletPath().contains("check")) {
      projectService.rejectProject(projectId, comment, userId, "checker");
    }
    if (request.getServletPath().contains("approve")) {
      projectService.rejectProject(projectId, comment, userId, "approver");
    }
  }

  /**
   * set the projects coauthors
   *
   * @param projectId
   * @param coauthors
   * @param request
   */
  @PutMapping("{projectId}/coauthors")
  @ResponseStatus(HttpStatus.OK)
  @CoauthorValidation
  public void setProjectCoauthors(
      @IdExists(entity = Project.class, message = "project id does not exist")
          @UnapprovedProject
          @PathVariable("projectId")
          UUID projectId,
      @RequestBody List<String> coauthors,
      HttpServletRequest request) {
    projectService.setProjectCoauthors(projectId, coauthors);
  }

  /**
   * return a collection of approved projects that match the filter parameters passed in. if no
   * parameters are passed in then return all approved projects. when more than one filter parameter
   * is passed in they are combined with an AND. All filter parameters are passed in as a single
   * value (not a collection or range of values).
   *
   * @param aircraftShipNo - exact match
   * @param fleetName - exact match
   * @param projectNumber - partial match
   * @param projectDescription - partial match
   * @param projectTitle - partial match
   * @param maintenanceDescription - partial match
   * @param isEntire - 'true' if the project being returned should include nested changeGroups.
   *     default is 'false',
   * @param page - if not null then use server side pagination. page number starts at 1
   * @param size - if not null then used server side pagination. number of projects to return in a
   *     request
   * @return
   */
  @GetMapping("approved")
  @ResponseStatus(HttpStatus.OK)
  @AircraftOrFleetExists(aircraft = 1, fleet = 2)
  public PaginationDTO<AssignedProjectDTO> getApprovedProjects(
      @RequestParam(value = "aircraft", required = false) String aircraftShipNo,
      @RequestParam(value = "fleet", required = false) String fleetName,
      @RequestParam(value = "number", required = false) String projectNumber,
      @RequestParam(value = "description", required = false) String projectDescription,
      @RequestParam(value = "title", required = false) String projectTitle,
      @RequestParam(value = "maintenance", required = false) String maintenanceDescription,
      @RequestParam(value = "isEntire", required = false, defaultValue = "false") boolean isEntire,
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "page", required = false)
          Integer page,
      @Min(value = 1, message = "{field.value.min}") @RequestParam(value = "size", required = false)
          Integer size,
      @Pattern(
              regexp = "^(title|description|number|fleets|approved|created)$",
              flags = Pattern.Flag.CASE_INSENSITIVE,
              message = "{field.allowed.values}")
          @RequestParam(value = "sortField", required = false, defaultValue = "approved")
          String sortField,
      @RequestParam(value = "sortAscending", required = false, defaultValue = "true")
          boolean sortAscending) {
    return projectService.getApprovedProjects(
        aircraftShipNo,
        fleetName,
        projectNumber,
        projectDescription,
        projectTitle,
        maintenanceDescription,
        isEntire,
        page,
        size,
        sortField,
        sortAscending);
  }
}
