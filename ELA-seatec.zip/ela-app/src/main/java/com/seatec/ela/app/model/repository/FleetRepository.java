package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.dto.FleetNameDTO;
import com.seatec.ela.app.model.Fleet;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FleetRepository extends CrudRepository<Fleet, Long> {
  List<Fleet> findByName(String name);

  List<Fleet> findByParentFleetNullOrderByName();

  @Query("SELECT f FROM Ela e join e.aircraft a join a.fleet f WHERE e.id = :elaId")
  Fleet findByElaId(Long elaId);

  @Query(
      "SELECT new com.seatec.ela.app.dto.FleetNameDTO(f.name, f.id, f.parentFleet.id) FROM Fleet f")
  List<FleetNameDTO> getFleetNames();
}
