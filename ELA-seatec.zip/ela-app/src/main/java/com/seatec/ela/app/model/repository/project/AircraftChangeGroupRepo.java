package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.model.project.AircraftChangeGroup;
import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AircraftChangeGroupRepo extends CrudRepository<AircraftChangeGroup, UUID> {
  List<AircraftChangeGroup> findAllByChangeGroupIdIn(List<UUID> changeGroupId);
}
