package com.seatec.ela.app.util;

import static java.util.stream.Collectors.groupingBy;

import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.constraints.NotNull;
import org.slf4j.event.Level;

public class NodeUtil {

  // suppress default constructor for noninstantiability
  private NodeUtil() {
    throw new AssertionError();
  }

  public static Map<Node, List<Node>> groupNodesByParent(@NotNull List<Node> nodes) {
    return nodes.stream()
        .filter(x -> x.getParentNode() != null)
        .collect(groupingBy(Node::getParentNode));
  }

  public static Map<Node, List<Component>> groupComponentsByNode(
      @NotNull List<Component> components) {
    return components.stream().collect(groupingBy(Component::getNode));
  }

  public static Map<Component, List<Load>> groupLoadsByComponent(@NotNull List<Load> loads) {
    return loads.stream().collect(groupingBy(Load::getComponent));
  }

  /**
   * Convert node trees into a flat list of all nodes from all trees.
   *
   * @param topLevelNodes - top level nodes of trees
   * @return a flat list of all nodes from all the trees
   */
  public static List<Node> flattenNodeTrees(@NotNull List<Node> topLevelNodes) {
    return (topLevelNodes == null)
        ? Collections.emptyList()
        : topLevelNodes.stream().flatMap(NodeUtil::flattenNodeTree).collect(Collectors.toList());
  }

  private static Stream<Node> flattenNodeTree(@NotNull Node node) {
    return Stream.concat(
        Stream.of(node), node.getSubNodes().stream().flatMap(NodeUtil::flattenNodeTree));
  }

  public static Node getNodeByName(List<Node> nodes, String nodeName) {
    return nodes.stream()
        .filter(n -> n.getName().equalsIgnoreCase(nodeName))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    String.format("Unable to locate Node '%s'", nodeName), Level.ERROR));
  }

  /**
   * Get nodes that don't have parents.
   *
   * @param nodes - a list of nodes
   * @return a list of nodes that don't have parents
   */
  public static Stream<Node> getTopLevelNodes(@NotNull List<Node> nodes) {
    return nodes.stream().filter(n -> n.getParentNode() == null);
  }

  /**
   * Get ids of nodes that don't have parents.
   *
   * @param nodes - a list of nodes
   * @return a list of ids of nodes that don't have parents
   */
  public static List<Long> getTopLevelNodeIds(@NotNull List<Node> nodes) {
    return getTopLevelNodes(nodes).map(Node::getId).collect(Collectors.toList());
  }

  /**
   * Get an identifier for the node. The identifier is the node's non-null id or the non-null name
   *
   * @param node - the node
   * @return - the identifier of the node
   */
  public static String getNodeIdentifier(@NotNull Node node) {
    Objects.requireNonNull(node, "node must not be null");
    return (node.getId() != null) ? node.getId().toString() : node.getName();
  }

  public static void validateNodeType(NodeType expectedNodeType, NodeType nodeType) {
    if (!expectedNodeType.equals(nodeType)) {
      throw new IllegalArgumentException(
          String.format("Node type: expected: %s, found: %s", expectedNodeType, nodeType));
    }
  }
}
