package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.ComponentUtil;
import java.util.List;

/** TruAggregator aggregates the loads for a component on a TRU node */
class TruAggregator implements ITransformerAggregator {

  public void aggregateLoadSummary(
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {
    if (loadSummaryOptions.getIncludeEssentialLoadAggregate()
        && ComponentUtil.isEssential(component)) {
      // Essential Only
      loadSummary.aggregateTruWsEssentialLoad(rootTransformerNodeIdentifier, load.getW());
    }
    // Essential and Sheddable
    loadSummary.aggregateTruWs(rootTransformerNodeIdentifier, load.getW());
    loadSummary
        .getNodeToEfficiencyTableMap()
        .put(rootTransformerNodeIdentifier, efficiencyTable.getId());
  }

  void aggregateLoadSummariesDCSplitNormal(
      SummarizedLoad loadSummaryDC, List<SummarizedLoad> loadSummariesDCSplit) {

    Double splitValue =
        (loadSummaryDC.getW() > 0d) ? loadSummaryDC.getW() / LoadSummaryUtil.THREE_PHASE_SPLIT : 0d;
    Double splitValueVar =
        (loadSummaryDC.getVar() > 0d)
            ? loadSummaryDC.getVar() / LoadSummaryUtil.THREE_PHASE_SPLIT
            : 0d;

    for (SummarizedLoad loadSummaryDCSplit : loadSummariesDCSplit) {
      loadSummaryDCSplit.aggregateW(splitValue);
      loadSummaryDCSplit.aggregateVar(splitValueVar);
    }
  }

  void aggregateLoadSummariesDCSplitDegraded(
      SummarizedLoad loadSummaryDC, List<SummarizedLoad> loadSummariesDCSplit) {

    Double splitValue =
        (loadSummaryDC.getwEssentialLoad() > 0d)
            ? loadSummaryDC.getwEssentialLoad() / LoadSummaryUtil.THREE_PHASE_SPLIT
            : 0d;
    Double splitValueVar =
        (loadSummaryDC.getVarEssentialLoad() > 0d)
            ? loadSummaryDC.getVarEssentialLoad() / LoadSummaryUtil.THREE_PHASE_SPLIT
            : 0d;

    for (SummarizedLoad loadSummaryDCSplit : loadSummariesDCSplit) {
      loadSummaryDCSplit.aggregateWEssentialLoad(splitValue);
      loadSummaryDCSplit.aggregateVarEssentialLoad(splitValueVar);
    }
  }
}
