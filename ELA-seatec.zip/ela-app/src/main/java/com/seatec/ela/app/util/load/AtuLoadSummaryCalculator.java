package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.NodeUtil;
import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** AtuLoadSummaryCalculator calculates load summaries for ATU nodes. */
public class AtuLoadSummaryCalculator {
  private static Logger logger = LoggerFactory.getLogger(AtuLoadSummaryCalculator.class);

  private static final AtuAggregator LOAD_SUMMARY_AGGREGATOR = new AtuAggregator();

  // suppress default constructor for noninstantiability
  private AtuLoadSummaryCalculator() {
    throw new AssertionError();
  }

  /**
   * Calculate the load summaries for an actual ATU node or a node treated as an ATU.
   *
   * <p>Note: When summing up loads - if a node is a transformer (node type of ATU or TRU), then all
   * child and grandchild nodes under it are considered transformers and will have the same
   * transformer type as the first ancestral transformer parent/grandparent in the node tree
   * (independent of the actual child node's nodeType which might not even be a transformer type)
   *
   * <p>Note: This code assumes that an ATU node does not have an AC3 load.
   *
   * @param loadSummaryMap - map containing the load summaries
   * @param summaryType - the summary type of the load summaries
   * @param loadSummaryOptions - the load summary options
   * @param node - the node
   * @param topMostAncestorTransformer - the first ancestral transformer parent/grandparent in the
   *     node tree
   */
  public static void calculateLoadSummaries(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull LoadSummaryOptions loadSummaryOptions,
      @NotNull Node node,
      Node topMostAncestorTransformer) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");
    Objects.requireNonNull(node, "node must not be null");

    /*
     * When summing up loads - if a node is a transformer (node type of ATU or TRU), then all child
     * and grandchild nodes under it are considered transformers and will have the same transformer
     * type as the first ancestral transformer parent/grandparent in the node tree (independent of the
     * actual child node's nodeType which might not even be a transformer type).
     */
    NodeType actingNodeType = node.getNodeType();
    EfficiencyTable actingEfficiencyTable = node.getEfficiencyTable();
    String rootTransformerNodeIdentifier = null;

    if (topMostAncestorTransformer != null) {
      actingNodeType = topMostAncestorTransformer.getNodeType();
      actingEfficiencyTable = topMostAncestorTransformer.getEfficiencyTable();
      rootTransformerNodeIdentifier = NodeUtil.getNodeIdentifier(topMostAncestorTransformer);
    }

    NodeUtil.validateNodeType(NodeType.ATU, actingNodeType);

    for (Component component : node.getComponents()) {

      DefaultLoadSummaryCalculator.calcNominalLoadSummaries(
          loadSummaryMap, summaryType, loadSummaryOptions, component);

      ElectricalPhase electricalPhase = component.getElectricalPhase();

      switch (electricalPhase) {
        case AC:
          // If the component's electricalPhase is originally AC, the loadSummaries get adjusted to
          // ACA.
          calcLoadSummariesAC(
              loadSummaryMap,
              summaryType,
              loadSummaryOptions,
              component,
              rootTransformerNodeIdentifier,
              actingEfficiencyTable);
          break;
        case DC:
        case ACA:
        case ACB:
        case ACC:
          calcLoadSummaries(
              loadSummaryMap,
              summaryType,
              loadSummaryOptions,
              component,
              rootTransformerNodeIdentifier,
              actingEfficiencyTable);
          break;
        default:
          // NOTE: This code assumes that a transformer node (ie ATU or TRU)
          // does not have an AC3 load. If it does, then this won't work.
          logger.info(
              "Summarized Loads NOT calculated for node: {} nodeType: {}, component: {}, electricalPhase: {}",
              NodeUtil.getNodeIdentifier(node),
              node.getNodeType(),
              component.getName(),
              electricalPhase);
          break;
      }
    }
  }

  private static void calcLoadSummariesAC(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {
    for (Load load : component.getLoads()) {
      String flightPhase = load.getFlightPhase();
      String operatingMode = load.getOperatingMode();

      SummarizedLoad loadSummary =
          LoadSummaryUtil.findOrCreateLoadSummary(
              loadSummaryMap,
              summaryType,
              ElectricalPhase.ACA,
              flightPhase,
              operatingMode,
              false,
              false);
      LOAD_SUMMARY_AGGREGATOR.aggregateLoadSummary(
          loadSummary,
          loadSummaryOptions,
          component,
          load,
          rootTransformerNodeIdentifier,
          efficiencyTable);
    }
  }

  private static void calcLoadSummaries(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {

    for (Load load : component.getLoads()) {
      TransformerLoadSummaryUtil.calcLoadSummary(
          loadSummaryMap,
          summaryType,
          loadSummaryOptions,
          component,
          load,
          rootTransformerNodeIdentifier,
          efficiencyTable,
          LOAD_SUMMARY_AGGREGATOR);
    }
  }
}
