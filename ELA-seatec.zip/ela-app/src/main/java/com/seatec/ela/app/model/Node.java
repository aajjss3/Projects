package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "node")
@JsonInclude(Include.NON_NULL)
public class Node implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @JsonView(View.BaseSummaryView.class)
  private Long id;

  @Column(name = "name", nullable = false)
  @JsonView(View.BaseSummaryView.class)
  private String name;

  @Column(name = "voltage")
  @JsonView(View.BaseSummaryView.class)
  private Double voltage;

  @Column(name = "nominal_power")
  @JsonView(View.BaseSummaryView.class)
  private Double nominalPower;

  @Column(name = "display_order")
  @JsonView(View.BaseSummaryView.class)
  private Integer displayOrder;

  @Enumerated(EnumType.STRING)
  @Column(name = "node_type")
  @JsonView(View.BaseSummaryView.class)
  private NodeType nodeType;

  @Column(name = "requires_approval")
  @JsonView(View.BaseSummaryView.class)
  private boolean requiresApproval;

  @Column(name = "bus_rating")
  @JsonView(View.BaseSummaryView.class)
  private Double busRating;

  @Column(name = "sheddable")
  @JsonView(View.BaseSummaryView.class)
  private boolean sheddable;

  @Column(name = "voltage_type")
  @Enumerated(EnumType.STRING)
  @JsonView(View.BaseSummaryView.class)
  private ElectricalPhase voltageType;

  @Enumerated(EnumType.STRING)
  @Column(name = "electrical_phase", nullable = false)
  @JsonView(View.BaseSummaryView.class)
  private ElectricalPhase electricalPhase;

  @Column(name = "normal_tr", nullable = false)
  @ColumnDefault("false")
  private boolean normalTr;

  @Column(name = "description")
  @JsonView(View.BaseSummaryView.class)
  private String description;

  @ManyToOne
  @JoinColumn(name = "node_id")
  @JsonIgnore
  private Node parentNode;

  @JsonInclude
  @Transient
  @JsonView(View.NodeSummaryView.class)
  private List<SummarizedLoad> summarizedLoads;

  @OneToMany(mappedBy = "parentNode", cascade = CascadeType.ALL)
  @JsonView(View.SummaryView.class)
  @OrderBy("displayOrder ASC")
  private List<Node> subNodes = new ArrayList<>();

  @ManyToOne
  @JoinColumn(name = "ela_id", nullable = true)
  @JsonIgnore
  private Ela ela;

  @OneToMany(mappedBy = "node", cascade = CascadeType.ALL)
  @OrderBy("displayOrder ASC")
  @JsonView({View.SummaryView.class, View.NodeSummaryView.class})
  private List<Component> components = new ArrayList<>();

  @ManyToOne
  @JoinColumn(name = "efficiency_table_id", nullable = true)
  @JsonIgnore
  private EfficiencyTable efficiencyTable;

  public Stream<Node> streamNodes() {
    return Stream.concat(Stream.of(this), subNodes.stream().flatMap(Node::streamNodes));
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Node getParentNode() {
    return parentNode;
  }

  public void setParentNode(Node parentNode) {
    this.parentNode = parentNode;
  }

  public List<Node> getSubNodes() {
    return subNodes;
  }

  public void setSubNodes(List<Node> subNodes) {
    this.subNodes = subNodes;
  }

  public void addSubNode(Node subNode) {
    this.subNodes.add(subNode);
    subNode.setParentNode(this);
  }

  public void removeNode(Node subNode) {
    this.subNodes.remove(subNode);
    subNode.setParentNode(this);
  }

  public Ela getEla() {
    return ela;
  }

  public void setEla(Ela ela) {
    this.ela = ela;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public List<Component> getComponents() {
    return components;
  }

  public void setComponents(List<Component> components) {
    this.components = components;
  }

  public void addComponent(Component component) {
    this.components.add(component);
    component.setNode(this);
  }

  public void removeComponent(Component component) {
    this.components.remove(component);
    component.setNode(this);
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public Double getBusRating() {
    return busRating;
  }

  public void setBusRating(Double busRating) {
    this.busRating = busRating;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public ElectricalPhase getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(ElectricalPhase voltageType) {
    this.voltageType = voltageType;
  }

  public boolean isNormalTr() {
    return normalTr;
  }

  public void setNormalTr(boolean normalTr) {
    this.normalTr = normalTr;
  }

  public List<SummarizedLoad> getSummarizedLoads() {
    return summarizedLoads;
  }

  public void setSummarizedLoads(List<SummarizedLoad> summarizedLoads) {
    this.summarizedLoads = summarizedLoads;
  }

  public EfficiencyTable getEfficiencyTable() {
    return efficiencyTable;
  }

  public void setEfficiencyTable(EfficiencyTable efficiencyTable) {
    this.efficiencyTable = efficiencyTable;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  /**
   * The ATU/TRU Inline voltage is determined by the voltage of any of its immediate children. All
   * other node types have the same inline and output voltage.
   *
   * @return the inline voltage, or 0 if ATU/TRU and no children are present
   */
  @JsonView(View.BaseSummaryView.class)
  public Double getInlineVoltage() {
    if ((getNodeType().equals(NodeType.TRU) || getNodeType().equals(NodeType.ATU))) {
      if (getSubNodes() != null && getSubNodes().size() > 0) {
        return getSubNodes().get(0).getVoltage();
      }
      return 0d;
    }
    return voltage;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Node node = (Node) o;
    return Objects.equals(id, node.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  public Node shallowCopy() {
    Node copy = new Node();
    copy.setEla(getEla());
    copy.setBusRating(getBusRating());
    copy.setRequiresApproval(isRequiresApproval());
    copy.setName(getName());
    copy.setDisplayOrder(getDisplayOrder());
    copy.setNodeType(getNodeType());
    copy.setNominalPower(getNominalPower());
    copy.setId(getId());
    copy.setVoltage(getVoltage());
    copy.setVoltageType(getVoltageType());
    copy.setSheddable(isSheddable());
    copy.setNormalTr(isNormalTr());
    copy.setEfficiencyTable(getEfficiencyTable());
    copy.setDescription(getDescription());
    copy.setElectricalPhase(getElectricalPhase());
    copy.setParentNode(getParentNode());
    return copy;
  }

  public Node cloneWithSubNodes() {
    Node newNode = new Node();
    newNode.setBusRating(getBusRating());
    newNode.setRequiresApproval(isRequiresApproval());
    newNode.setName(getName());
    newNode.setDisplayOrder(getDisplayOrder());
    newNode.setNodeType(getNodeType());
    newNode.setNominalPower(getNominalPower());
    newNode.setVoltage(getVoltage());
    newNode.setVoltageType(getVoltageType());
    newNode.setSheddable(isSheddable());
    newNode.setEfficiencyTable(getEfficiencyTable());
    newNode.setNormalTr(isNormalTr());
    newNode.setDescription(getDescription());
    newNode.setElectricalPhase(getElectricalPhase());
    for (Component component : this.getComponents()) {
      Component newComponent = component.clone();
      newNode.addComponent(newComponent);
    }
    for (Node sourceNode : this.getSubNodes()) {
      Node newChildNode = sourceNode.cloneWithSubNodes();
      newNode.addSubNode(newChildNode);
    }
    return newNode;
  }
}
