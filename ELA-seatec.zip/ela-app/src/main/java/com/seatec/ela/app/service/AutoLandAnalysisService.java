package com.seatec.ela.app.service;

import com.seatec.ela.app.config.ClientConfig.Boeing;
import com.seatec.ela.app.dto.AutoLandFleetConfigDto;
import com.seatec.ela.app.dto.LoadFiltersDto;
import com.seatec.ela.app.dto.SummarizedLoadFiltersDto;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysis;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysisNode;
import com.seatec.ela.app.dto.analysis.AutoLandCondition;
import com.seatec.ela.app.exception.NotAcceptableException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.StaticInverterCalculator;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.stereotype.Service;

@Service
public class AutoLandAnalysisService {
  private static Logger log = LoggerFactory.getLogger(AutoLandAnalysisService.class);

  private static final String FLEET_PREFIX_B757 = "B757";
  private static final String FLEET_PREFIX_B767 = "B767";

  // AutoLand Analysis Nodes
  private static final List<String> NODE_NAMES = Arrays.asList("HB06", "BB1S", "DSBY", "DCAL");

  // AutoLand Analysis Nodes for Static Inverter
  private static final List<String> NODE_NAMES_INVERTER_CALC_B757 = Arrays.asList("ACAL", "STYS");
  private static final List<String> NODE_NAMES_INVERTER_CALC_B767 = Arrays.asList("ACAL", "ASBY");

  // AutoLand Derated DC Voltage
  private static final Double DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_ONLY = 24.0d;
  private static final Double DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_CHARGER_B757 = 28.0d;
  // B767 uses 26V according to 767-SL-24-057
  private static final Double DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_CHARGER_B767 = 26.0d;

  // AutoLand Power Efficiency for Static Inverter
  private static final Double POWER_EFFICIENCY_INVERTER = 0.82d;

  // This is the name that gets returned for the Static Inverter calculations
  private static final String NODE_NAME_INVERTER = "INVERTER";

  private static final LoadFiltersDto LOAD_FILTERS =
      new LoadFiltersDto(Boeing.HOLD_LAND.toString(), OperatingMode.Boeing.LOAD.toString());

  private static final SummarizedLoadFiltersDto SUMMARIZED_LOAD_FILTERS_HB06 =
      new SummarizedLoadFiltersDto(
          Boeing.HOLD_LAND.toString(),
          OperatingMode.Boeing.LOAD.toString(),
          SummaryType.COMPONENTS_AND_CHILDREN,
          false,
          false);

  private static final AutoLandFleetConfigDto AUTOLAND_CONFIG_B757 =
      new AutoLandFleetConfigDto(
          FLEET_PREFIX_B757,
          NODE_NAMES,
          NODE_NAMES_INVERTER_CALC_B757,
          DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_CHARGER_B757,
          DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_ONLY,
          POWER_EFFICIENCY_INVERTER,
          NODE_NAME_INVERTER,
          LOAD_FILTERS,
          SUMMARIZED_LOAD_FILTERS_HB06);

  private static final AutoLandFleetConfigDto AUTOLAND_CONFIG_B767 =
      new AutoLandFleetConfigDto(
          FLEET_PREFIX_B767,
          NODE_NAMES,
          NODE_NAMES_INVERTER_CALC_B767,
          DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_CHARGER_B767,
          DERATED_DC_VOLTAGE_IN_VOLTS_BATTERY_ONLY,
          POWER_EFFICIENCY_INVERTER,
          NODE_NAME_INVERTER,
          LOAD_FILTERS,
          SUMMARIZED_LOAD_FILTERS_HB06);

  /**
   * Load a configuration for the AutoLand calculations based on the fleet.
   *
   * @param fleet - the fleet
   * @return an AutoLandConfiguration or null if one doesn't exist
   */
  public AutoLandFleetConfigDto loadFleetConfig(Fleet fleet) {
    AutoLandFleetConfigDto config = null;

    String fleetName = fleet.getName();
    if (fleetName.startsWith(AUTOLAND_CONFIG_B757.getFleetPrefix())) {
      config = AUTOLAND_CONFIG_B757;
    } else if (fleetName.startsWith(AUTOLAND_CONFIG_B767.getFleetPrefix())) {
      config = AUTOLAND_CONFIG_B767;
    } else {
      log.info("AutoLand configuration NOT found for {}", fleetName);
    }

    return config;
  }

  /**
   * Calculate the AutoLand Analysis for an ELA.
   *
   * <pre>
   *   This code assumes
   *   - All required nodes (as specified in the autoLandFleetConfig) are present.
   *   - All required nodes are fully hydrated with their components, loads,
   *     and summarized loads (of SummaryType.COMPONENTS_AND_CHILDREN).
   * </pre>
   *
   * @param ela - an Ela
   * @param nodes - nodes belonging to the Ela that are fully hydrated with their components and
   *     loads, and summarized loads.
   * @param autoLandFleetConfig - if null, then the result AutoLandCondition will be null.
   * @return - the AutoLandCondition for the Ela, or null if there is an error.
   */
  public AutoLandCondition calculate(
      Ela ela, List<Node> nodes, AutoLandFleetConfigDto autoLandFleetConfig) {
    AutoLandCondition autoLandCondition = null;

    Aircraft aircraft = ela.getAircraft();

    if (autoLandFleetConfig != null) {
      BatteryChargeType batteryChargeType = aircraft.getBatteryCharge();

      autoLandCondition = new AutoLandCondition();
      autoLandCondition.setBatteryCapacity(batteryChargeType);

      Map<String, Node> nodesByNameMap =
          nodes.stream().collect(Collectors.toMap(Node::getName, node -> node));

      // Battery Charger
      AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
      autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);

      // Battery Only
      AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
      autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

      try {
        calcTotalLoadsForAutoLandNodes(
            nodesByNameMap, analysisBatteryCharger, analysisBatteryOnly, autoLandFleetConfig);

        calcTotalLoadForStaticInverter(
            nodesByNameMap, analysisBatteryCharger, analysisBatteryOnly, autoLandFleetConfig);
      } catch (NotAcceptableException ex) {
        autoLandCondition = null;

        String errMsg =
            String.format(
                "AutoLand Analysis (battery) FAILED for ship %s because %s ",
                aircraft.getAircraftShipNo(), ex.getMessage());
        log.error(errMsg, ex);
      }
    }
    return autoLandCondition;
  }

  private void calcTotalLoadForStaticInverter(
      Map<String, Node> nodesByNameMap,
      AutoLandAnalysis analysisBatteryCharger,
      AutoLandAnalysis analysisBatteryOnly,
      AutoLandFleetConfigDto autoLandFleetConfig) {

    double wattsTotal = 0.0d;
    double varTotal = 0.0d;

    String nodeNameInverter = autoLandFleetConfig.getInverterNodeName();
    Node nodeInverter = nodesByNameMap.get(nodeNameInverter);

    if (nodeInverter == null) {
      throw new NotAcceptableException("Node NOT found: " + nodeNameInverter, Level.ERROR);
    }

    Double deratedDCVoltageInVoltsBatteryOnly =
        autoLandFleetConfig.getDeratedDCVoltageInVoltsBatteryOnly();
    analysisBatteryOnly.setDeratedDCVoltageInAmps(deratedDCVoltageInVoltsBatteryOnly);

    Double deratedDCVoltageInVoltsBatteryCharger =
        autoLandFleetConfig.getDeratedDCVoltageInVoltsBatteryCharger();
    analysisBatteryCharger.setDeratedDCVoltageInAmps(deratedDCVoltageInVoltsBatteryCharger);

    List<String> nodeNamesInverterCalculations =
        autoLandFleetConfig.getNodeNamesInverterCalculations();

    for (String nodeName : nodeNamesInverterCalculations) {

      Node matchingNode = nodesByNameMap.get(nodeName);

      if (matchingNode != null) {
        for (Component component : matchingNode.getComponents()) {

          List<Load> loads = filterLoads(component.getLoads(), autoLandFleetConfig);

          for (Load load : loads) {
            // For DC loads, you can directly add Amps.
            // For DC loads, there are no Vars.
            // For AC loads, you can NOT directly add Amps.
            // For AC loads, first sum Watts and sum Vars, then convert.
            wattsTotal += load.getW();
            varTotal += load.getVar();
          }
        }

      } else {
        throw new NotAcceptableException("Node NOT found: " + nodeName, Level.ERROR);
      }
    }

    Double voltAmperes = LoadUtil.getVa(wattsTotal, varTotal);
    Double powerFactor = LoadUtil.getPowerFactor(wattsTotal, varTotal);

    Double ampsBatteryCharger =
        StaticInverterCalculator.calcLoadInAmps(
            voltAmperes,
            powerFactor,
            deratedDCVoltageInVoltsBatteryCharger,
            autoLandFleetConfig.getPowerEfficiencyInverter());

    Double ampsBatteryOnly =
        StaticInverterCalculator.calcLoadInAmps(
            voltAmperes,
            powerFactor,
            deratedDCVoltageInVoltsBatteryOnly,
            autoLandFleetConfig.getPowerEfficiencyInverter());

    analysisBatteryCharger.addNode(new AutoLandAnalysisNode(nodeNameInverter, ampsBatteryCharger));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode(nodeNameInverter, ampsBatteryOnly));
  }

  private List<Load> filterLoads(List<Load> loads, AutoLandFleetConfigDto fleetConfig) {

    LoadFiltersDto loadFilters = fleetConfig.getLoadFilters();
    String flightPhase = loadFilters.getFlightPhase();
    String operatingMode = loadFilters.getOperatingMode();

    return loads.stream()
        .filter(
            load ->
                flightPhase.equals(load.getFlightPhase())
                    && operatingMode.equals(load.getOperatingMode()))
        .collect(Collectors.toList());
  }

  private void calcTotalLoadsForAutoLandNodes(
      Map<String, Node> nodesByNameMap,
      AutoLandAnalysis analysisBatteryCharger,
      AutoLandAnalysis analysisBatteryOnly,
      AutoLandFleetConfigDto autoLandFleetConfig) {

    List<String> nodeNames = autoLandFleetConfig.getNodeNames();

    for (String nodeName : nodeNames) {

      Node matchingNode = nodesByNameMap.get(nodeName);

      if (matchingNode != null) {
        // For HB06, get the summary of all loads from components AND children
        if ("HB06".equals(matchingNode.getName())) {
          List<SummarizedLoad> summarizedLoads =
              filterSummarizedLoads(
                  matchingNode.getSummarizedLoads(),
                  matchingNode.getElectricalPhase(),
                  autoLandFleetConfig);

          if (!summarizedLoads.isEmpty()) {
            SummarizedLoad summarizedLoad = summarizedLoads.get(0);

            double voltAmperes = summarizedLoad.getVa();

            double powerFactor = summarizedLoad.getPowerFactor();
            double inlineVoltage = matchingNode.getVoltage();

            double amps = LoadUtil.getAmps(voltAmperes, powerFactor, inlineVoltage);

            analysisBatteryCharger.addNode(new AutoLandAnalysisNode(nodeName, amps));
            analysisBatteryOnly.addNode(new AutoLandAnalysisNode(nodeName, amps));

          } else {
            throw new NotAcceptableException(
                "Summarized loads NOT found for Node: " + matchingNode.getName(), Level.ERROR);
          }

        } else {
          // For other nodes, get the summary of all loads from the components ONLY
          double wattsTotal = 0.0d;
          double varTotal = 0.0d;

          for (Component component : matchingNode.getComponents()) {

            List<Load> loads = filterLoads(component.getLoads(), autoLandFleetConfig);

            for (Load load : loads) {
              double voltAmperes = load.getVa();
              double powerFactor = load.getPowerFactor();
              wattsTotal += LoadUtil.getW(voltAmperes, powerFactor);
              varTotal += LoadUtil.getVar(voltAmperes, powerFactor);
            }
          }

          double voltAmperes = LoadUtil.getVa(wattsTotal, varTotal);
          double powerFactor = LoadUtil.getPowerFactor(wattsTotal, varTotal);
          double inlineVoltage = matchingNode.getVoltage();

          double amps = LoadUtil.getAmps(voltAmperes, powerFactor, inlineVoltage);

          analysisBatteryCharger.addNode(new AutoLandAnalysisNode(nodeName, amps));
          analysisBatteryOnly.addNode(new AutoLandAnalysisNode(nodeName, amps));
        }
      } else {
        throw new NotAcceptableException("Node NOT found: " + nodeName, Level.ERROR);
      }
    }
  }

  private List<SummarizedLoad> filterSummarizedLoads(
      List<SummarizedLoad> summarizedLoads,
      ElectricalPhase electricalPhase,
      AutoLandFleetConfigDto fleetConfig) {

    SummarizedLoadFiltersDto summarizedLoadFilters = fleetConfig.getSummarizedLoadFilters();
    String flightPhase = summarizedLoadFilters.getFlightPhase();
    String operatingMode = summarizedLoadFilters.getOperatingMode();
    SummaryType summaryType = summarizedLoadFilters.getSummaryType();
    boolean isMaxPhaseLoad = summarizedLoadFilters.isMaxPhaseLoad();
    boolean isMaxImbalance = summarizedLoadFilters.isMaxImbalance();

    return summarizedLoads.stream()
        .filter(
            summarizedLoad ->
                flightPhase.equals(summarizedLoad.getFlightPhase())
                    && operatingMode.equals(summarizedLoad.getOperatingMode())
                    && summaryType.equals(summarizedLoad.getSummaryType())
                    && isMaxPhaseLoad == summarizedLoad.isMaxPhaseLoad()
                    && isMaxImbalance == summarizedLoad.isMaxImbalance()
                    && electricalPhase == summarizedLoad.getElectricalPhase())
        .collect(Collectors.toList());
  }
}
