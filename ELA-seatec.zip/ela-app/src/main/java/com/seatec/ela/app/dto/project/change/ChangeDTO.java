package com.seatec.ela.app.dto.project.change;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.seatec.ela.app.dto.project.ComponentChangeDTO;
import com.seatec.ela.app.dto.project.NodeChangeDTO;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.UUID;

public class ChangeDTO implements UserTrackIdUUID {

  private UUID id;

  private ActionType action;

  private String nodeName;

  private String componentElectIdent;

  private String changer;

  private NodeChangeDTO nodeChange;

  private ComponentChangeDTO componentChange;

  public ActionType getAction() {
    return action;
  }

  public void setAction(ActionType action) {
    this.action = action;
  }

  public String getNodeName() {
    return nodeName;
  }

  public void setNodeName(String nodeName) {
    this.nodeName = nodeName;
  }

  public String getComponentElectIdent() {
    return componentElectIdent;
  }

  public void setComponentElectIdent(String componentElectIdent) {
    this.componentElectIdent = componentElectIdent;
  }

  public String getChanger() {
    return changer;
  }

  public void setChanger(String changer) {
    this.changer = changer;
  }

  public NodeChangeDTO getNodeChange() {
    return nodeChange;
  }

  public void setNodeChange(NodeChangeDTO nodeChange) {
    this.nodeChange = nodeChange;
  }

  public ComponentChangeDTO getComponentChange() {
    return componentChange;
  }

  public void setComponentChange(ComponentChangeDTO componentChange) {
    this.componentChange = componentChange;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }
}
