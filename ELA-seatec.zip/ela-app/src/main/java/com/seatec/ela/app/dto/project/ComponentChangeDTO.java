package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.model.ElectricalPhase;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ComponentChangeDTO implements UserTrackIdUUID, UserTrackName {

  private UUID id;

  private String name;

  private Double nominalPower;

  private String ata;

  private Integer displayOrder;

  private Boolean clipsed;

  private Boolean sheddable;

  private Boolean intermittent;

  private String electIdent;

  private String panel;

  private ElectricalPhase electricalPhase;

  private Double connectedLoadVa;

  private Double connectedLoadPf;

  private List<LoadChangeDTO> loadChanges = new ArrayList<LoadChangeDTO>();

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public String getAta() {
    return ata;
  }

  public void setAta(String ata) {
    this.ata = ata;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Boolean getClipsed() {
    return clipsed;
  }

  public void setClipsed(Boolean clipsed) {
    this.clipsed = clipsed;
  }

  public Boolean getSheddable() {
    return sheddable;
  }

  public void setSheddable(Boolean sheddable) {
    this.sheddable = sheddable;
  }

  public Boolean getIntermittent() {
    return intermittent;
  }

  public void setIntermittent(Boolean intermittent) {
    this.intermittent = intermittent;
  }

  public String getElectIdent() {
    return electIdent;
  }

  public void setElectIdent(String electIdent) {
    this.electIdent = electIdent;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public Double getConnectedLoadVa() {
    return connectedLoadVa;
  }

  public void setConnectedLoadVa(Double connectedLoadVa) {
    this.connectedLoadVa = connectedLoadVa;
  }

  public Double getConnectedLoadPf() {
    return connectedLoadPf;
  }

  public void setConnectedLoadPf(Double connectedLoadPf) {
    this.connectedLoadPf = connectedLoadPf;
  }

  public List<LoadChangeDTO> getLoadChanges() {
    return loadChanges;
  }

  public void setLoadChanges(List<LoadChangeDTO> loadChanges) {
    this.loadChanges = loadChanges;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }
}
