package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.util.jsonfilter.ValidNumberFilter;
import java.io.Serializable;

public class StandbyOperation implements Serializable {

  private static final long serialVersionUID = 1L;

  private double totalLoadInAmps; // used for all aircraft
  private BatteryChargeType batteryCapacity; // used for all aircraft
  private AnalysisStatus status; // used for all aircraft
  private AnalysisStatus batteryStatus;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double requiredBatteryLifeInMinutes; // used for all aircraft except B717
  // do not include this field when serializing to json if the value is not a valid number
  @JsonInclude(value = JsonInclude.Include.CUSTOM, valueFilter = ValidNumberFilter.class)
  private Double actualBatteryLifeInMinutes; // used for all aircraft except B717

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double percentAmpsUsed; // only used for B717 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double maxBatteryLoad; // only used for B717 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double ratCapacity; // only used for B777 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double ratAdjustedCapacity; // only used for B777 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double ratEfficiency; // only used for B777 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Double ratLoadInAmps; // only used for B777 aircraft

  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AnalysisStatus ratStatus; // only used for B777 aircraft

  public Double getRequiredBatteryLifeInMinutes() {
    return requiredBatteryLifeInMinutes;
  }

  public void setRequiredBatteryLifeInMinutes(Double requiredBatteryLifeInMinutes) {
    this.requiredBatteryLifeInMinutes = requiredBatteryLifeInMinutes;
  }

  public Double getActualBatteryLifeInMinutes() {
    return actualBatteryLifeInMinutes;
  }

  public void setActualBatteryLifeInMinutes(Double actualBatteryLifeInMinutes) {
    this.actualBatteryLifeInMinutes = actualBatteryLifeInMinutes;
  }

  public BatteryChargeType getBatteryCapacity() {
    return batteryCapacity;
  }

  public void setBatteryCapacity(BatteryChargeType batteryCapacity) {
    this.batteryCapacity = batteryCapacity;
  }

  public double getTotalLoadInAmps() {
    return totalLoadInAmps;
  }

  public void setTotalLoadInAmps(double totalLoadInAmps) {
    this.totalLoadInAmps = totalLoadInAmps;
  }

  public Double getPercentAmpsUsed() {
    return percentAmpsUsed;
  }

  public void setPercentAmpsUsed(Double percentAmpsUsed) {
    this.percentAmpsUsed = percentAmpsUsed;
  }

  public Double getMaxBatteryLoad() {
    return maxBatteryLoad;
  }

  public void setMaxBatteryLoad(Double maxBatteryLoad) {
    this.maxBatteryLoad = maxBatteryLoad;
  }

  public Double getRatCapacity() {
    return ratCapacity;
  }

  public void setRatCapacity(Double ratCapacity) {
    this.ratCapacity = ratCapacity;
  }

  public Double getRatEfficiency() {
    return ratEfficiency;
  }

  public void setRatEfficiency(Double ratEfficiency) {
    this.ratEfficiency = ratEfficiency;
  }

  public Double getRatLoadInAmps() {
    return ratLoadInAmps;
  }

  public void setStatus(AnalysisStatus status) {
    this.status = status;
  }

  public AnalysisStatus getBatteryStatus() {
    return batteryStatus;
  }

  public void setBatteryStatus(AnalysisStatus batteryStatus) {
    this.batteryStatus = batteryStatus;
  }

  public AnalysisStatus getRatStatus() {
    return ratStatus;
  }

  public void setRatStatus(AnalysisStatus ratStatus) {
    this.ratStatus = ratStatus;
  }

  public void setRatLoadInAmps(Double ratLoadInAmps) {
    this.ratLoadInAmps = ratLoadInAmps;
  }

  public AnalysisStatus getStatus() {
    return status;
  }

  public Double getRatAdjustedCapacity() {
    return ratAdjustedCapacity;
  }

  public void setRatAdjustedCapacity(Double ratAdjustedCapacity) {
    this.ratAdjustedCapacity = ratAdjustedCapacity;
  }
}
