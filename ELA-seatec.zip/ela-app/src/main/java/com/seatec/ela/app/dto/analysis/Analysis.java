package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class Analysis implements Serializable {

  /**
   * If a serializable class doesn’t declare a serialVersionUID, the JVM will generate one
   * automatically at run-time. However, it is highly recommended that each class declares its
   * serialVersionUID as the generated one is compiler dependent and thus may result in unexpected
   * InvalidClassExceptions.
   */
  private static final long serialVersionUID = 1L;

  private Double thresholdLowerLimit = 95.0d;
  private Double thresholdUpperLimit = 100.0d;

  private AnalysisType normalAnalysis = new AnalysisType();
  private AnalysisType degradedAnalysis = new AnalysisType();

  // standby operation battery analysis - currently only applies to Boeing aircraft
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private StandbyOperation standbyOperation;

  // contains the rolled up aggregate worst case status of all the AnalysisNodes for normal analysis
  private AnalysisStatus normalStatus;
  // contains the rolled up aggregate worst case status of all the AnalysisNodes for degraded
  // analysis
  private AnalysisStatus degradedStatus;

  public Double getThresholdLowerLimit() {
    return thresholdLowerLimit;
  }

  public void setThresholdLowerLimit(Double thresholdLowerLimit) {
    this.thresholdLowerLimit = thresholdLowerLimit;
  }

  public Double getThresholdUpperLimit() {
    return thresholdUpperLimit;
  }

  public void setThresholdUpperLimit(Double thresholdUpperLimit) {
    this.thresholdUpperLimit = thresholdUpperLimit;
  }

  public AnalysisType getNormalAnalysis() {
    return normalAnalysis;
  }

  public void setNormalAnalysis(AnalysisType normalAnalysis) {
    this.normalAnalysis = normalAnalysis;
  }

  public AnalysisType getDegradedAnalysis() {
    return degradedAnalysis;
  }

  public void setDegradedAnalysis(AnalysisType degradedAnalysis) {
    this.degradedAnalysis = degradedAnalysis;
  }

  public AnalysisStatus getNormalStatus() {
    return normalStatus;
  }

  public void setNormalStatus(AnalysisStatus normalStatus) {
    this.normalStatus = normalStatus;
  }

  public AnalysisStatus getDegradedStatus() {
    return degradedStatus;
  }

  public void setDegradedStatus(AnalysisStatus degradedStatus) {
    this.degradedStatus = degradedStatus;
  }

  public StandbyOperation getStandbyOperation() {
    return standbyOperation;
  }

  public void setStandbyOperation(StandbyOperation standbyOperation) {
    this.standbyOperation = standbyOperation;
  }
}
