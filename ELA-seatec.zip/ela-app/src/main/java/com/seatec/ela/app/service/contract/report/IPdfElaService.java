package com.seatec.ela.app.service.contract.report;

import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.Node;
import java.util.List;

/** Service for dealing with Reporting Service. */
public interface IPdfElaService {
  PdfPTable generateCoverPageForEla(
      String shipNo, String reportName, String faaName, boolean faaReport);

  void generateElaSummary(
      Document document,
      List<Node> nodesInLevel,
      List<Node> flatNodeList,
      List<String> operatingModes,
      List<FlightPhaseDto> flightPhases,
      boolean isBoeing);

  PdfPTable generateShipSummary(Ela ela);

  PdfPTable generateShipInfo(Ela ela);
}
