package com.seatec.ela.app.service.report;

import static com.seatec.ela.app.util.enumeration.BatteryChargeType.SINGLE_75AH;

import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.dto.analysis.*;
import com.seatec.ela.app.dto.analysis.AnalysisLoad.Units;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.service.ElaAnalysisService;
import com.seatec.ela.app.service.contract.report.IPdfAnalysisService;
import com.seatec.ela.app.service.project.ProjectAnalysisService;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.pdf.PdfFormatUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/** Perform the PDFTable and content generation for Project and ELA PDF service */
@Service
public class PdfAnalysisService implements IPdfAnalysisService {

  public static final String ELA_ANALYSIS_TITLE = "Analysis";

  // pseudo node types
  private static final String AUTO_LAND = "autoland";
  private static final String FUEL_JETTISON = "jettison";
  private static final String GENERATOR = "generator";
  private static final String TRU = "tru";
  private static final String ATU = "atu";
  private static final String BUS = "bus";
  private static final String STANDBY = "standby";
  private static final String STATIC_INVERTER = "static_inverter";
  private static final String HMG = "hmg";

  private static final String NORMAL_ANALYSIS_NAME = "Normal";
  private static final String DEGRADED_ANALYSIS_NAME = "Degraded";

  private static final Color PASS_COLOR = new Color(35, 154, 90);
  private static final Color WARN_COLOR = new Color(222, 206, 10);
  private static final Color FAIL_COLOR = new Color(145, 25, 51);

  @Autowired private ElaAnalysisService elaAnalysisService;

  @Autowired private ProjectAnalysisService projectAnalysisService;

  @Autowired private PdfFormatUtil pdfFormatUtil;

  /**
   * Main service for generating Project Analysis content in PDF
   *
   * @param changeGroups - List of change groups to iterate
   * @return PdfPTable
   */
  public PdfPTable generateProjectAnalysisSection(List<ChangeGroup> changeGroups) {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setSplitLate(false);

    for (ChangeGroup changeGroup : changeGroups) {
      // get analyses (sort by ship number ASC) => isSummary: false means includes Load Analysis
      List<ProjectAnalysis> changeGroupAnalyses =
          projectAnalysisService.getAnalysis(changeGroup.getId(), null, false).stream()
              .sorted(Comparator.comparing(ProjectAnalysis::getAircraftShipNo))
              .collect(Collectors.toList());

      Paragraph changeGroupTitle =
          new Paragraph("Change Group: " + changeGroup.getName(), PdfFormatUtil.createFont(1));
      AnalysisStatus changeGroupStatus = determineChangeGroupStatus(changeGroupAnalyses);
      PdfPCell changeGroupCell = setStatusIconAndLabel(changeGroupStatus, changeGroupTitle);
      pdfPTable.addCell(changeGroupCell);

      // get all aircrafts in change group
      List<Aircraft> aircrafts =
          changeGroup.getAircraftChangeGroups().stream()
              .map(AircraftChangeGroup::getAircraft)
              .collect(Collectors.toList());

      // iterate over aircrafts instead of analysis so we can capture flightPhases
      // key is getManufacturer()
      for (Aircraft aircraft : aircrafts) {
        ProjectAnalysis aircraftAnalysis =
            changeGroupAnalyses.stream()
                .filter(f -> f.getAircraftId().equals(aircraft.getId()))
                .findFirst()
                .orElseThrow(
                    () ->
                        new NotFoundException(
                            String.format(
                                "Aircraft %s is missing Analysis", aircraft.getAircraftShipNo()),
                            Level.ERROR));

        // get flight phases (exclude Battery Supplied)
        List<FlightPhaseDto> flightPhases =
            FlightPhase.getFlightPhases(
                aircraft.getFleet().getManufacturer(),
                aircraft.getFleet().isEtops(),
                aircraft.getFleet().getName(),
                true);
        Paragraph aircraftTitle =
            new Paragraph(
                "Aircraft: " + aircraftAnalysis.getAircraftShipNo(), PdfFormatUtil.createFont(2));
        AnalysisStatus aircraftStatus =
            determineAircraftStatus(
                aircraftAnalysis.getAnalysis().getNormalStatus(),
                aircraftAnalysis.getAnalysis().getDegradedStatus());

        PdfPCell aircraftCell = setStatusIconAndLabel(aircraftStatus, aircraftTitle);
        pdfPTable.addCell(aircraftCell);

        // Normal Analysis
        List<String> normalAnalysisNodes = new ArrayList<>(Arrays.asList(GENERATOR, TRU, ATU, BUS));

        // is auto land included
        if (aircraftAnalysis.getAnalysis().getNormalAnalysis().getAutoLandCondition() != null) {
          normalAnalysisNodes.add(AUTO_LAND);
        }

        for (String nodeType : normalAnalysisNodes) {
          AnalysisType analysis = getAnalysisType(aircraftAnalysis, NORMAL_ANALYSIS_NAME);

          PdfPCell analysisCell =
              getNodeAnalysisTableCell(
                  analysis, flightPhases, NORMAL_ANALYSIS_NAME, nodeType, null);
          pdfPTable.addCell(analysisCell);
        }

        // Degraded Analysis
        List<String> degradedAnalysisNodes = new ArrayList<>(Arrays.asList(GENERATOR, TRU));
        StandbyOperation standbyOperation = null;

        // determine if ship is boeing then
        // append standby operation if it isn't present
        if (PdfFormatUtil.isBoeingAircraft(aircraft.getFleet().getManufacturer())) {
          // is HMG analysis included
          if (!aircraftAnalysis.getAnalysis().getDegradedAnalysis().getHmgAnalysis().isEmpty()) {
            if (!degradedAnalysisNodes.contains(HMG)) {
              degradedAnalysisNodes.add(HMG);
            }
          }
          // is static inverter analysis included
          if (!aircraftAnalysis
              .getAnalysis()
              .getDegradedAnalysis()
              .getStaticInverterAnalysis()
              .isEmpty()) {
            if (!degradedAnalysisNodes.contains(STATIC_INVERTER)) {
              degradedAnalysisNodes.add(STATIC_INVERTER);
            }
          }

          // is fuel jettison included
          if (!aircraftAnalysis
              .getAnalysis()
              .getDegradedAnalysis()
              .getFuelJettisonGenerators()
              .isEmpty()) {
            if (!degradedAnalysisNodes.contains(FUEL_JETTISON)) {
              degradedAnalysisNodes.add(FUEL_JETTISON);
            }
          }

          // is standby analysis included
          if (!degradedAnalysisNodes.contains(STANDBY)) {
            degradedAnalysisNodes.add(STANDBY);
          }

          // bind analysis data
          standbyOperation = aircraftAnalysis.getAnalysis().getStandbyOperation();
        }

        for (String degradedAnalysisNode : degradedAnalysisNodes) {
          AnalysisType analysis = getAnalysisType(aircraftAnalysis, DEGRADED_ANALYSIS_NAME);

          PdfPCell analysisCell =
              getNodeAnalysisTableCell(
                  analysis,
                  flightPhases,
                  DEGRADED_ANALYSIS_NAME,
                  degradedAnalysisNode,
                  standbyOperation);
          pdfPTable.addCell(analysisCell);
        }
      }
    }

    return pdfPTable;
  }

  /**
   * Main service for generating Ela Analysis content in PDF
   *
   * @param id - Ela unique identifier
   * @param flightPhases - List of flight phases to iterate
   * @return
   */
  public PdfPTable generateElaAnalysisSection(
      Long id, List<FlightPhaseDto> flightPhases, boolean isBoeing, boolean faaReport) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();

    // section header
    PdfPCell sectionTitle = PdfFormatUtil.getBlankCell();
    sectionTitle.addElement(new Paragraph(ELA_ANALYSIS_TITLE, PdfFormatUtil.PAGE_H1_FONT));
    sectionTitle.setPaddingBottom(15f);
    pdfPTable.addCell(sectionTitle);

    Analysis analysis = elaAnalysisService.getAnalysis(id);

    // Normal Analysis
    AnalysisType normalAnalysis = analysis.getNormalAnalysis();
    List<String> normalAnalysisNodes =
        faaReport
            ? new ArrayList<>(Arrays.asList(GENERATOR))
            : new ArrayList<>(Arrays.asList(GENERATOR, TRU, ATU, BUS));

    // is auto land included (exclude from FAA report)
    if (!faaReport && normalAnalysis.getAutoLandCondition() != null) {
      normalAnalysisNodes.add(AUTO_LAND);
    }

    for (String analysisType : normalAnalysisNodes) {
      PdfPCell analysisCell =
          getNodeAnalysisTableCell(
              normalAnalysis, flightPhases, NORMAL_ANALYSIS_NAME, analysisType, null);
      pdfPTable.addCell(analysisCell);
    }

    // determine if ship is boeing then
    // append standby operation if it isn't present
    List<String> degradedAnalysisNodes =
        faaReport
            ? new ArrayList<>(Arrays.asList(GENERATOR))
            : new ArrayList<>(Arrays.asList(GENERATOR, TRU));

    // analyses to include
    StandbyOperation standbyOperation = null;

    if (isBoeing && !faaReport) {

      // is HMG analysis included
      if (!analysis.getDegradedAnalysis().getHmgAnalysis().isEmpty()) {
        if (!degradedAnalysisNodes.contains(HMG)) {
          degradedAnalysisNodes.add(HMG);
        }
      }

      // is static inverter analysis included
      if (!analysis.getDegradedAnalysis().getStaticInverterAnalysis().isEmpty()) {
        if (!degradedAnalysisNodes.contains(STATIC_INVERTER)) {
          degradedAnalysisNodes.add(STATIC_INVERTER);
        }
      }

      // is fuel jettison analysis included
      if (!analysis.getDegradedAnalysis().getFuelJettisonGenerators().isEmpty()) {
        if (!degradedAnalysisNodes.contains(FUEL_JETTISON)) {
          degradedAnalysisNodes.add(FUEL_JETTISON);
        }
      }

      // is standby analysis included
      if (!degradedAnalysisNodes.contains(STANDBY)) {
        degradedAnalysisNodes.add(STANDBY);
      }

      // bind analysis data
      standbyOperation = analysis.getStandbyOperation();
    }

    // Degraded Analysis
    AnalysisType degradedAnalysis = analysis.getDegradedAnalysis();
    for (String degradedAnalysisNode : degradedAnalysisNodes) {
      PdfPCell analysisCell =
          getNodeAnalysisTableCell(
              degradedAnalysis,
              flightPhases,
              DEGRADED_ANALYSIS_NAME,
              degradedAnalysisNode,
              standbyOperation);
      pdfPTable.addCell(analysisCell);
    }

    return pdfPTable;
  }

  /**
   * This method determines the AnalysisStatus based on comparing normal vs degraded AnalysisStatus
   *
   * @param normal - AnalysisStatus for normal conditions
   * @param degraded - AnalysisStatus for degraded conditions
   * @return AnalysisStatus - status of inputs passed in (ie. PASS, FAIL, WARN)
   */
  public AnalysisStatus determineAircraftStatus(AnalysisStatus normal, AnalysisStatus degraded) {
    List<AnalysisStatus> statuses = new ArrayList<>();
    statuses.add(normal);
    statuses.add(degraded);

    return getAnalysisStatus(statuses);
  }

  public PdfPCell setAircraftStatusCell(Long elaId) {
    Analysis analysis = elaAnalysisService.getAnalysis(elaId);
    AnalysisStatus aircraftStatus =
        determineAircraftStatus(analysis.getNormalStatus(), analysis.getDegradedStatus());
    if (analysis.getStandbyOperation() != null) {
      AnalysisStatus standbyStatus = analysis.getStandbyOperation().getStatus();
      aircraftStatus = determineAircraftStatus(aircraftStatus, standbyStatus);
    }
    Paragraph paragraphStatus = getStatusParagraph(aircraftStatus, 10f);
    PdfPCell iconCell = new PdfPCell(new Phrase(paragraphStatus));
    iconCell.setBorder(Rectangle.NO_BORDER);
    return iconCell;
  }

  /**
   * This method generates an inline image with text
   *
   * @param status - Object representing analysis status (ie. PASS, FAIL, WARN)
   * @param label - text to display next to icon
   * @return PdfPCell
   */
  public PdfPCell setStatusIconAndLabel(AnalysisStatus status, Paragraph label) {
    PdfPCell cell = new PdfPCell();
    PdfPTable rowTable = new PdfPTable(2);
    rowTable.setWidthPercentage(100f);

    Paragraph paragraphStatus = getStatusParagraph(status, 10f);

    // left column (title)
    PdfPCell rightCell = new PdfPCell(new Phrase(label));
    rightCell.setVerticalAlignment(Element.ALIGN_CENTER);
    rightCell.setBorder(Rectangle.NO_BORDER);
    rightCell.setPaddingLeft(5f);
    rowTable.addCell(rightCell);

    // right cell (label)
    PdfPCell iconCell = new PdfPCell(new Phrase(paragraphStatus));
    iconCell.setVerticalAlignment(Element.ALIGN_CENTER);
    iconCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    iconCell.setBorder(Rectangle.NO_BORDER);
    rowTable.addCell(iconCell);

    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPaddingBottom(10f);
    cell.addElement(rowTable);

    return cell;
  }

  private PdfPTable getAutoLandAnalysis(AutoLandCondition autoLandCondition) {
    PdfPTable pdfPTable = null;

    // is B737 fleet
    if (autoLandCondition.getTruAutoLandAnalysis() != null) {
      pdfPTable = getAutoLandAnalysisTru(autoLandCondition);
    } else {
      // B757/B757-ETOPS/B767
      pdfPTable = getAutoLandAnalysisBattery(autoLandCondition);
    }

    return pdfPTable;
  }

  private PdfPTable getAutoLandAnalysisTru(AutoLandCondition autoLandCondition) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();
    TRUsAutoLandAnalysisDTO truAutoLandAnalysisDTO = autoLandCondition.getTruAutoLandAnalysis();

    PdfPCell blankCell = PdfFormatUtil.getBlankCell();

    // TRU1 (DC Bus 1 + DC Standby Bus)
    PdfPCell cellTotalTRU1 =
        getAutoLandTruTotalCell(
            "TRU1 (DC Bus 1 + DC Standby Bus)", truAutoLandAnalysisDTO.getTru1().getTotalAmps());
    pdfPTable.addCell(cellTotalTRU1);

    PdfPCell cellCapacityTRU1 =
        getAutoLandTruCapacityCell("TRU1", truAutoLandAnalysisDTO.getTru1().getRating());
    pdfPTable.addCell(cellCapacityTRU1);

    pdfPTable.addCell(blankCell);

    // TRU2 (DC Bus 2)
    PdfPCell cellTotalTRU2 =
        getAutoLandTruTotalCell("TRU2 (DC Bus 2)", truAutoLandAnalysisDTO.getTru2().getTotalAmps());
    pdfPTable.addCell(cellTotalTRU2);

    PdfPCell cellCapacityTRU2 =
        getAutoLandTruCapacityCell("TRU2", truAutoLandAnalysisDTO.getTru2().getRating());
    pdfPTable.addCell(cellCapacityTRU2);

    pdfPTable.addCell(blankCell);

    // TRU3 (Battery Bus)
    PdfPCell cellTotalTRU3 =
        getAutoLandTruTotalCell(
            "TRU3 (Battery Bus)", truAutoLandAnalysisDTO.getTru3().getTotalAmps());
    pdfPTable.addCell(cellTotalTRU3);

    PdfPCell cellCapacityTRU3 =
        getAutoLandTruCapacityCell("TRU3", truAutoLandAnalysisDTO.getTru3().getRating());
    pdfPTable.addCell(cellCapacityTRU3);

    pdfPTable.addCell(blankCell);

    return pdfPTable;
  }

  private PdfPCell getAutoLandTruTotalCell(String label, double totalAmps) {
    String inverterTotal = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(totalAmps);

    PdfPCell inverterTotalCell =
        PdfFormatUtil.createTextCell(
            new Phrase(String.format("%s: %s %s", label, inverterTotal, Units.AMPS)));
    inverterTotalCell.setHorizontalAlignment(Element.ALIGN_LEFT);

    return inverterTotalCell;
  }

  private PdfPCell getAutoLandTruCapacityCell(String name, double ratingInAmps) {
    String capacity = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(ratingInAmps);

    PdfPCell cellCapacity =
        PdfFormatUtil.createTextCell(
            new Phrase(String.format("%s Capacity: %s %s", name, capacity, Units.AMPS)));
    cellCapacity.setHorizontalAlignment(Element.ALIGN_LEFT);

    return cellCapacity;
  }

  private PdfPTable getAutoLandAnalysisBattery(AutoLandCondition autoLandCondition) {
    int numCols = 6;
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable(numCols);
    pdfPTable.setWidthPercentage(100);

    String labelUnits = "AMPS";
    PdfPCell cellUnits = PdfFormatUtil.getBlankCell();
    cellUnits.addElement(new Phrase(labelUnits));

    PdfPCell blankRow = PdfFormatUtil.createBlankRow(numCols);

    String textTitle = "CENTER CHANNEL BUSES DURING HOLD & LAND (BATT CHGR DC OUTPUT)";
    PdfPCell cellTitle = PdfFormatUtil.getBlankCell();
    cellTitle.setColspan(numCols);
    cellTitle.addElement(new Phrase(textTitle));
    pdfPTable.addCell(cellTitle);

    pdfPTable.addCell(blankRow);

    PdfPCell blankCellTwo = PdfFormatUtil.getBlankCell();
    blankCellTwo.setColspan(2);
    pdfPTable.addCell(blankCellTwo);

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();

    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        convertAutoLandNodesToMap(analysisBatteryCharger);

    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        convertAutoLandNodesToMap(analysisBatteryOnly);

    String voltageBatteryCharger =
        PdfFormatUtil.DECIMAL_FORMAT_0_PLACE.format(
            analysisBatteryCharger.getDeratedDCVoltageInAmps());

    PdfPCell cellBatteryChargerTitle = PdfFormatUtil.getBlankCell();
    cellBatteryChargerTitle.addElement(
        new Phrase(String.format("%sV DC (BATT CHRGR)", voltageBatteryCharger)));
    cellBatteryChargerTitle.setColspan(2);
    pdfPTable.addCell(cellBatteryChargerTitle);

    String voltageBatteryOnly =
        PdfFormatUtil.DECIMAL_FORMAT_0_PLACE.format(
            analysisBatteryOnly.getDeratedDCVoltageInAmps());

    PdfPCell cellBatteryOnlyTitle = PdfFormatUtil.getBlankCell();
    cellBatteryOnlyTitle.setColspan(2);
    cellBatteryOnlyTitle.addElement(
        new Phrase(String.format("%sV DC (BATT ONLY)", voltageBatteryOnly)));
    pdfPTable.addCell(cellBatteryOnlyTitle);

    for (Map.Entry<String, AutoLandAnalysisNode> entry : mapNodesBatteryCharger.entrySet()) {
      String nodeName = entry.getKey();

      String nodeNameStr = (nodeName.equals("INVERTER")) ? "INVERTER EQUIV DC INPUT" : nodeName;

      PdfPCell cellNodeName = PdfFormatUtil.getBlankCell();
      cellNodeName.addElement(new Phrase(nodeNameStr));
      cellNodeName.setColspan(2);
      pdfPTable.addCell(cellNodeName);

      AutoLandAnalysisNode nodeBatteryCharger = entry.getValue();
      String totalLoadInAmpsBatteryCharger =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(nodeBatteryCharger.getTotalLoadInAmps());

      PdfPCell cellNodeBatteryCharger = PdfFormatUtil.getBlankCell();
      cellNodeBatteryCharger.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
      cellNodeBatteryCharger.addElement(new Phrase(totalLoadInAmpsBatteryCharger));
      pdfPTable.addCell(cellNodeBatteryCharger);

      pdfPTable.addCell(cellUnits);

      AutoLandAnalysisNode nodeBatteryOnly = mapNodesBatteryOnly.get(nodeName);
      String totalLoadInAmpsBatteryOnly =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(nodeBatteryOnly.getTotalLoadInAmps());

      PdfPCell cellNodeBatteryOnly = PdfFormatUtil.getBlankCell();
      cellNodeBatteryOnly.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
      cellNodeBatteryOnly.addElement(new Phrase(totalLoadInAmpsBatteryOnly));
      pdfPTable.addCell(cellNodeBatteryOnly);

      pdfPTable.addCell(cellUnits);
    }

    pdfPTable.addCell(blankRow);

    PdfPCell cellTitleTotal = PdfFormatUtil.getBlankCell();
    cellTitleTotal.addElement(new Phrase("Total"));
    cellTitleTotal.setColspan(2);
    pdfPTable.addCell(cellTitleTotal);

    String totalLoadInAmpsBatteryCharger =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(
            analysisBatteryCharger.getTotalLoadInAmpsSummary());

    PdfPCell cellTotalBatteryCharger = PdfFormatUtil.getBlankCell();
    cellTotalBatteryCharger.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
    cellTotalBatteryCharger.addElement(new Phrase(totalLoadInAmpsBatteryCharger));
    pdfPTable.addCell(cellTotalBatteryCharger);

    pdfPTable.addCell(cellUnits);

    String totalLoadInAmpsBatteryOnly =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(
            analysisBatteryOnly.getTotalLoadInAmpsSummary());

    PdfPCell cellTotalBatteryOnly = PdfFormatUtil.getBlankCell();
    cellTotalBatteryOnly.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
    cellTotalBatteryOnly.addElement(new Phrase(totalLoadInAmpsBatteryOnly));
    pdfPTable.addCell(cellTotalBatteryOnly);

    pdfPTable.addCell(cellUnits);

    pdfPTable.addCell(blankRow);

    List<PdfPCell> listCellsBatteryAnalysis = getBatteryAnalysis(autoLandCondition);
    for (PdfPCell cellBatteryAnalysis : listCellsBatteryAnalysis) {
      cellBatteryAnalysis.setColspan(numCols);
      pdfPTable.addCell(cellBatteryAnalysis);
    }

    pdfPTable.addCell(blankRow);

    String note =
        "NOTE: Battery drains when load is over 60 amps or if charger is INOP. "
            + "If the charger is INOP, the battery can supply the above Autoland load. "
            + "Autoland is limited to less than 5 minutes.";
    PdfPCell cellNote = PdfFormatUtil.getBlankCell();
    cellNote.setColspan(numCols);
    cellNote.addElement(new Phrase(note));
    pdfPTable.addCell(cellNote);

    return pdfPTable;
  }

  // Use a LinkedHashMap to preserve the list order.
  private Map<String, AutoLandAnalysisNode> convertAutoLandNodesToMap(AutoLandAnalysis analysis) {
    List<AutoLandAnalysisNode> listNodes = analysis.getNodes();
    return listNodes.stream()
        .collect(
            Collectors.toMap(
                AutoLandAnalysisNode::getName,
                node -> node,
                (u, v) -> {
                  throw new IllegalStateException(String.format("Duplicate key %s", u));
                },
                LinkedHashMap::new));
  }

  private List<PdfPCell> getBatteryAnalysis(IBatteryAnalysis batteryAnalysis) {

    List<PdfPCell> cells = new ArrayList<>();

    // battery capacity (replace _ with ' ')
    BatteryChargeType batteryChargeType = batteryAnalysis.getBatteryCapacity();
    String batteryCapacity = batteryChargeType.toString().replace("_", " ");

    PdfPCell batteryCapacityCell =
        PdfFormatUtil.createTextCell(new Phrase("Battery Capacity: " + batteryCapacity));
    batteryCapacityCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cells.add(batteryCapacityCell);

    // required battery life
    String requiredBatteryLifeLabel = "Required Battery Life";
    String requiredBatteryLife =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(
            batteryAnalysis.getRequiredBatteryLifeInMinutes());

    PdfPCell requiredBatteryLifeCell =
        PdfFormatUtil.createTextCell(
            new Phrase(
                String.format(
                    "%s: %s %s", requiredBatteryLifeLabel, requiredBatteryLife, "Minutes")));
    requiredBatteryLifeCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cells.add(requiredBatteryLifeCell);

    // total load (Amps)
    String totalLoad =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(batteryAnalysis.getTotalLoadInAmps());
    PdfPCell totalLoadCell =
        PdfFormatUtil.createTextCell(new Phrase("Total Load: " + totalLoad + " " + Units.AMPS));
    totalLoadCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cells.add(totalLoadCell);

    // battery life
    String batteryLifeLabel = "Battery Life";
    Double batteryLifeMinutes = batteryAnalysis.getActualBatteryLifeInMinutes();
    String batteryLife = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(batteryLifeMinutes);
    PdfPCell batteryLifeCell =
        PdfFormatUtil.createTextCell(
            new Phrase(String.format("%s: %s %s", batteryLifeLabel, batteryLife, "Minutes")));
    batteryLifeCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cells.add(batteryLifeCell);

    return cells;
  }

  /**
   * This method generates a PDF Table specifically for the ATU portion of Analysis
   *
   * @param analysisType - Object representing analysis types (ie. Normal, Degraded)
   * @param flightPhases - Aircraft flight phases is a collection of phases defined by the client
   * @return PdfPTable
   */
  private PdfPTable getAtuAnalysis(AnalysisType analysisType, List<FlightPhaseDto> flightPhases) {
    List<AnalysisNode> analysisNodes =
        analysisType.getAtuNodes().stream()
            .sorted(Comparator.comparing(AnalysisNode::getName))
            .collect(Collectors.toList());

    PdfPTable nodesAnalysisTable = PdfFormatUtil.createBaseTable();

    for (AnalysisNode analysisNode : analysisNodes) {
      List<AnalysisLoad> loads = analysisNode.getAnalysisLoads();
      Double rating = analysisNode.getRating();
      Units unit = findFirstNonZeroUnit(loads);
      PdfPTable nodeAnalysisTable = createDefaultNodeAnalysisTable(analysisNode, rating, unit);

      ElectricalPhase electricalPhase = findFirstNonZeroPhase(loads);

      // append load table(s) to node table
      nodeAnalysisTable.addCell(
          addPhaseTable(loads, flightPhases, rating, electricalPhase.toString()));

      // append node table to nodes table
      nodesAnalysisTable.addCell(nodeAnalysisTable);
    }

    return nodesAnalysisTable;
  }

  /**
   * This method generates a PDF Table specifically for the BUS portion of Analysis
   *
   * @param analysisType - Object representing analysis types (ie. Normal, Degraded)
   * @param flightPhases - Aircraft flight phases is a collection of phases defined by the client
   * @return PdfPTable
   */
  private PdfPTable getBusAnalysis(AnalysisType analysisType, List<FlightPhaseDto> flightPhases) {
    // nodes
    List<AnalysisNode> analysisNodes = analysisType.getBusNodes();

    // bus group "AC"
    List<AnalysisNode> acBuses =
        analysisNodes.stream()
            .filter(analysisNode -> !analysisNode.getVoltageType().equalsIgnoreCase("dc"))
            .sorted(Comparator.comparing(AnalysisNode::getName))
            .collect(Collectors.toList());

    PdfPTable nodesAnalysisTable = PdfFormatUtil.createBaseTable();

    // output "AC" group
    for (AnalysisNode analysisNode : acBuses) {
      List<AnalysisLoad> loads = analysisNode.getAnalysisLoads();
      Double rating = analysisNode.getRating();
      Units unit = findFirstNonZeroUnit(loads);
      PdfPTable nodeAnalysisTable = createDefaultNodeAnalysisTable(analysisNode, rating, unit);

      String voltageType = analysisNode.getVoltageType();

      if (voltageType.equalsIgnoreCase("ac")) {
        ElectricalPhase electricalPhase = findFirstNonZeroPhase(loads);
        // append loads table to node table
        nodeAnalysisTable.addCell(
            addPhaseTable(loads, flightPhases, rating, electricalPhase.toString()));

        // append node table to nodes table
        nodesAnalysisTable.addCell(nodeAnalysisTable);
      } else {
        String[] phases = new String[] {"aca", "acb", "acc"};

        for (String phase : phases) {
          PdfPTable phaseTable = addPhaseTable(loads, flightPhases, rating, phase);
          nodeAnalysisTable.addCell(phaseTable);
        }

        // append node table to nodes table
        nodesAnalysisTable.addCell(nodeAnalysisTable);
      }
    }

    // bus group "DC"
    List<AnalysisNode> dcBuses =
        analysisNodes.stream()
            .filter(analysisNode -> analysisNode.getVoltageType().equalsIgnoreCase("dc"))
            .sorted(Comparator.comparing(AnalysisNode::getName))
            .collect(Collectors.toList());

    // output "DC" group
    for (AnalysisNode analysisNode : dcBuses) {
      List<AnalysisLoad> loads = analysisNode.getAnalysisLoads();
      Double rating = analysisNode.getRating();
      Units unit = findFirstNonZeroUnit(loads);
      PdfPTable nodeAnalysisTable = createDefaultNodeAnalysisTable(analysisNode, rating, unit);

      ElectricalPhase electricalPhase = findFirstNonZeroPhase(loads);

      // append loads table to node table
      nodeAnalysisTable.addCell(
          addPhaseTable(loads, flightPhases, rating, electricalPhase.toString()));

      // append node table to nodes table
      nodesAnalysisTable.addCell(nodeAnalysisTable);
    }

    return nodesAnalysisTable;
  }

  /**
   * This method generates a PDF Table specifically for the Degraded > Fuel Jettison Analysis
   *
   * @param fuelJettisonGenerators - List containing all fuel generator analyses
   * @param flightPhases - Aircraft flight phases is a collection of phases defined by the client
   * @return PdfPTable
   */
  private PdfPTable getFuelJettisonAnalysis(
      List<FuelJettisonGenerator> fuelJettisonGenerators, List<FlightPhaseDto> flightPhases) {
    PdfPTable analysisTable = PdfFormatUtil.createBaseTable();
    // iterator over Generators (ex. "GEN 1", "GEN 2", etc.)
    for (FuelJettisonGenerator fuelJettisonGenerator : fuelJettisonGenerators) {
      // verify loads exist
      if (!fuelJettisonGenerator.getFuelJettisonLoads().isEmpty()) {
        // Generator Header (ex. "GEN R")
        PdfPTable generatorTable = createDefaultNodeAnalysisTable(fuelJettisonGenerator, Units.KVA);

        // "With" Fuel Jettison
        PdfPTable withFJTable =
            generateFuelJettisonTable(
                flightPhases,
                fuelJettisonGenerator.getFuelJettisonLoads(),
                fuelJettisonGenerator.getWithJettisonStatus(),
                true);
        generatorTable.addCell(withFJTable);

        // "Without" Fuel Jettison
        PdfPTable withoutFJTable =
            generateFuelJettisonTable(
                flightPhases,
                fuelJettisonGenerator.getFuelJettisonLoads(),
                fuelJettisonGenerator.getWithoutJettisonStatus(),
                false);
        generatorTable.addCell(withoutFJTable);

        analysisTable.addCell(generatorTable);
      }
    }

    return analysisTable;
  }

  /**
   * This method generates a PDF Table specifically for the GENERATOR portion of Analysis
   *
   * @param analysisType - Object representing analysis types (ie. Normal, Degraded)
   * @param flightPhases - Aircraft flight phases is a collection of phases defined by the client
   * @return PdfPTable
   */
  private PdfPTable getGeneratorAnalysis(
      AnalysisType analysisType, List<FlightPhaseDto> flightPhases) {
    // generators (sort by name ASC)
    List<AnalysisNode> analysisNodes =
        analysisType.getGeneratorNodes().stream()
            .sorted(Comparator.comparing(AnalysisNode::getName))
            .collect(Collectors.toList());

    PdfPTable nodesAnalysisTable = PdfFormatUtil.createBaseTable();

    // iterator over nodes (ex. "GEN 1", "GEN 2", etc.)
    for (AnalysisNode analysisNode : analysisNodes) {
      List<AnalysisLoad> loads = analysisNode.getAnalysisLoads();
      Double rating = analysisNode.getRating();
      Units unit = findFirstNonZeroUnit(loads);
      PdfPTable nodeAnalysisTable = createDefaultNodeAnalysisTable(analysisNode, rating, unit);

      // Phase A
      PdfPTable phaseATable = addPhaseTable(loads, flightPhases, rating / 3, "aca");
      nodeAnalysisTable.addCell(phaseATable);

      // Phase B
      PdfPTable phaseBTable = addPhaseTable(loads, flightPhases, rating / 3, "acb");
      nodeAnalysisTable.addCell(phaseBTable);

      // Phase C
      PdfPTable phaseCTable = addPhaseTable(loads, flightPhases, rating / 3, "acc");
      nodeAnalysisTable.addCell(phaseCTable);

      // append node table to nodes table
      nodesAnalysisTable.addCell(nodeAnalysisTable);
    }

    return nodesAnalysisTable;
  }

  /**
   * This method generates a PDF Table specifically for the TRU portion of Analysis
   *
   * @param analysisType - Object representing analysis types (ie. Normal, Degraded)
   * @param flightPhases - Aircraft flight phases is a collection of phases defined by the client
   * @return PdfPTable
   */
  private PdfPTable getTruAnalysis(
      AnalysisType analysisType, List<FlightPhaseDto> flightPhases, boolean isDegraded) {
    List<AnalysisNode> analysisNodes =
        analysisType.getTruNodes().stream()
            .sorted(Comparator.comparing(AnalysisNode::getName))
            .collect(Collectors.toList());

    PdfPTable nodesAnalysisTable = PdfFormatUtil.createBaseTable();

    for (AnalysisNode analysisNode : analysisNodes) {
      List<AnalysisLoad> loads = analysisNode.getAnalysisLoads();
      Double rating = analysisNode.getRating();
      Units unit = findFirstNonZeroUnit(loads);

      PdfPTable nodeAnalysisTable = createDefaultNodeAnalysisTable(analysisNode, rating, unit);

      // if degraded analysis then perform diff calculation
      // business rule: divide value (not result) by rating then multiply by 100
      if (isDegraded) {
        for (AnalysisLoad load : loads) {
          load.setResult((load.getValue() / rating) * 100d);
        }
      }

      // DC
      nodeAnalysisTable.addCell(
          addPhaseTable(loads, flightPhases, rating, isDegraded ? "total" : "dc"));

      // append node table to nodes table
      nodesAnalysisTable.addCell(nodeAnalysisTable);
    }

    return nodesAnalysisTable;
  }

  /**
   * Generates Standby Operation table specific to Boeing
   *
   * @param standbyOperation settings for
   * @return PdfPTable
   */
  private PdfPTable getStandbyOperationAnalysis(StandbyOperation standbyOperation) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();

    // battery capacity (replace _ with ' ')
    BatteryChargeType batteryChargeType = standbyOperation.getBatteryCapacity();
    String batteryCapacity = batteryChargeType.toString().replace("_", " ");
    boolean isSingle75Ah = SINGLE_75AH.equals(batteryChargeType);

    PdfPCell batteryCapacityCell =
        PdfFormatUtil.createTextCell(new Phrase("Battery Capacity: " + batteryCapacity));
    batteryCapacityCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(batteryCapacityCell);

    // required battery life
    // if Single_75AH battery then display different field values
    String requiredBatteryLifeLabel = isSingle75Ah ? "Percent Amps Used" : "Required Battery Life";
    String requiredBatteryLife =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(
            isSingle75Ah
                ? standbyOperation.getPercentAmpsUsed()
                : standbyOperation.getRequiredBatteryLifeInMinutes());

    PdfPCell requiredBatteryLifeCell =
        PdfFormatUtil.createTextCell(
            new Phrase(
                String.format(
                    "%s: %s %s", requiredBatteryLifeLabel, requiredBatteryLife, "Minutes")));
    requiredBatteryLifeCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(requiredBatteryLifeCell);

    // total load (Amps)
    String totalLoad =
        PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(standbyOperation.getTotalLoadInAmps());
    PdfPCell totalLoadCell =
        PdfFormatUtil.createTextCell(new Phrase("Total Load: " + totalLoad + " " + Units.AMPS));
    totalLoadCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(totalLoadCell);

    // battery life
    String batteryLifeLabel = isSingle75Ah ? "Max Battery Load" : "Battery Life";
    Double batteryLifeMinutes =
        isSingle75Ah
            ? 75d
            : standbyOperation.getActualBatteryLifeInMinutes() != null
                ? standbyOperation.getActualBatteryLifeInMinutes()
                : 0d;
    String batteryLife = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(batteryLifeMinutes);
    PdfPCell batteryLifeCell =
        PdfFormatUtil.createTextCell(
            new Phrase(String.format("%s: %s %s", batteryLifeLabel, batteryLife, "Minutes")));
    batteryLifeCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(batteryLifeCell);

    return pdfPTable;
  }

  private PdfPTable getStaticInverterAnalysis(List<StaticInverter> staticInverterAnalysis) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();

    for (StaticInverter staticInverter : staticInverterAnalysis) {
      // Inverter Input DC Current: Static Inverter total in Amps
      String totalLoadInAmpsLabel = "Inverter Input DC Current";
      String totalLoadInAmps =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(staticInverter.getTotalLoadInAmps());
      PdfPCell inverterInputDcCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", totalLoadInAmpsLabel, totalLoadInAmps, Units.AMPS)));
      inverterInputDcCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(inverterInputDcCell);

      // Inverter total in kVA
      String totalLoadInKvaLabel = "Inverter Total";
      String totalLoadInKva =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(staticInverter.getTotalLoadInKVA());
      PdfPCell inverterTotalCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", totalLoadInKvaLabel, totalLoadInKva, Units.KVA)));
      inverterTotalCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(inverterTotalCell);

      // Inverter Rating
      String inverterRatingLabel = "Inverter Rating";
      String inverterRating =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(staticInverter.getMaxLoadInKVA());
      PdfPCell inverterRatingCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", inverterRatingLabel, inverterRating, Units.KVA)));
      inverterRatingCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(inverterRatingCell);

      // add empty row for spacing between static inverter tables
      pdfPTable.addCell(PdfFormatUtil.createBlankRow(1));
    }

    return pdfPTable;
  }

  private PdfPTable getHMGAnalysis(List<HMGAnalysis> hmgAnalyses) {
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable();

    for (HMGAnalysis hmgAnalysis : hmgAnalyses) {

      // Total Load in Amps: (ex 30.850 Amps)
      String totalLoadInAmpsLabel = "DC Total Load";
      String totalLoadInAmps =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(hmgAnalysis.getDcTotalLoadAmps());
      PdfPCell hmgInputDcCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", totalLoadInAmpsLabel, totalLoadInAmps, Units.AMPS)));
      hmgInputDcCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(hmgInputDcCell);

      // DC Capacity in Amps: (ex 50 Amps)
      String capacityInAmpsLabel = "DC Capacity";
      String capacityInAmps =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(hmgAnalysis.getDcCapacityAmps());
      PdfPCell hmgCapacityDcCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", capacityInAmpsLabel, capacityInAmps, Units.AMPS)));
      hmgCapacityDcCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(hmgCapacityDcCell);

      // Total AC Load (expand to list, use total load vs capacity to determine status)

      // Total Load in kVA: (ex 3.983 kVA)
      String totalLoadInKvaLabel = "AC Total Load";
      String totalLoadInKva =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(hmgAnalysis.getAcTotalLoadKVA());
      PdfPCell hmgTotalCell =
          PdfFormatUtil.createTextCell(
              new Phrase(
                  String.format("%s: %s %s", totalLoadInKvaLabel, totalLoadInKva, Units.KVA)));
      hmgTotalCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(hmgTotalCell);

      // AC Capacity in kVA: (ex 5 kVA)
      String hmgRatingLabel = "AC Capacity";
      String hmgRating =
          PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(hmgAnalysis.getAcCapacityKVA());
      PdfPCell hmgRatingCell =
          PdfFormatUtil.createTextCell(
              new Phrase(String.format("%s: %s %s", hmgRatingLabel, hmgRating, Units.KVA)));
      hmgRatingCell.setHorizontalAlignment(Element.ALIGN_LEFT);
      pdfPTable.addCell(hmgRatingCell);

      // Phase A: kVA and PF (data)
      addHMGPhase(
          pdfPTable, hmgAnalysis, "Phase A", hmgAnalysis.getaPhaseKVA(), hmgAnalysis.getaPhasePf());
      // Phase B: kVA and PF (data)
      addHMGPhase(
          pdfPTable, hmgAnalysis, "Phase B", hmgAnalysis.getbPhaseKVA(), hmgAnalysis.getbPhasePf());
      // Phase C: kVA and PF (data)
      addHMGPhase(
          pdfPTable, hmgAnalysis, "Phase C", hmgAnalysis.getcPhaseKVA(), hmgAnalysis.getcPhasePf());
      // Average Phase Load: kVA and PF (data)
      addHMGPhase(
          pdfPTable,
          hmgAnalysis,
          "Average Phase Load",
          hmgAnalysis.getAvgPhaseKVA(),
          hmgAnalysis.getAvgPhasePf());

      // add empty row for spacing between static inverter tables
      pdfPTable.addCell(PdfFormatUtil.createBlankRow(1));
    }

    return pdfPTable;
  }

  private void addHMGPhase(
      PdfPTable pdfPTable, HMGAnalysis hmgAnalysis, String phaseName, double var, double pf) {
    String totalLoadInKva = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(var);
    String powerFactor = PdfFormatUtil.DECIMAL_FORMAT_2_PLACES.format(pf);
    PdfPCell hmgTotalCell =
        PdfFormatUtil.createTextCell(
            new Phrase(
                String.format(
                    "%s: %s %s / %s Power Factor",
                    phaseName, totalLoadInKva, Units.KVA, powerFactor)));
    hmgTotalCell.setHorizontalAlignment(Element.ALIGN_LEFT);
    pdfPTable.addCell(hmgTotalCell);
  }

  /**
   * This method determines the AnalysisStatus based on a collection of analysises passed in
   *
   * @param analyses - collection of alaysises to check
   * @return AnalysisStatus - status of inputs passed in (ie. PASS, FAIL, WARN)
   */
  private AnalysisStatus determineChangeGroupStatus(List<ProjectAnalysis> analyses) {
    // get all analysis
    List<Analysis> projectAnalyses =
        analyses.stream().map(ProjectAnalysis::getAnalysis).collect(Collectors.toList());

    // get normal analysis
    List<AnalysisStatus> analysisStatus =
        projectAnalyses.stream()
            .filter(distinctByKey(Analysis::getNormalStatus))
            .map(Analysis::getNormalStatus)
            .collect(Collectors.toList());

    // get degraded analysis
    List<AnalysisStatus> degradedAnalysisStatus =
        projectAnalyses.stream()
            .filter(distinctByKey(Analysis::getDegradedStatus))
            .map(Analysis::getDegradedStatus)
            .collect(Collectors.toList());

    analysisStatus.addAll(degradedAnalysisStatus);

    return getAnalysisStatus(analysisStatus);
  }

  /**
   * This method determines the AnalysisStatus based on collection of analysises passed in
   *
   * @param analysis - AnalysisType object to check against
   * @param nodeType - string representation of nodeType (ie. generator, tru, atu, bus)
   * @return AnalysisStatus - status of inputs passed in (ie. PASS, FAIL, WARN)
   */
  private AnalysisStatus determineNodeStatus(AnalysisType analysis, String nodeType) {
    List<AnalysisNode> analysisNodes;
    List<AnalysisStatus> uniqueStatuses;

    switch (nodeType) {
      case AUTO_LAND:
        return analysis.getAutoLandCondition().getStatus();
      case ATU:
        analysisNodes = analysis.getAtuNodes();
        break;
      case BUS:
        analysisNodes = analysis.getBusNodes();
        break;
      case FUEL_JETTISON:
        // get fuel jettison generators
        List<FuelJettisonGenerator> fuelJettisonGenerators = analysis.getFuelJettisonGenerators();

        // verify generator status exists
        checkForMissingFuelJettisonGeneratorStatuses(fuelJettisonGenerators);

        // get unique generator status list
        uniqueStatuses =
            fuelJettisonGenerators.stream()
                .filter(distinctByKey(FuelJettisonGenerator::getGeneratorStatus))
                .map(FuelJettisonGenerator::getGeneratorStatus)
                .collect(Collectors.toList());
        return getAnalysisStatus(uniqueStatuses);
      case GENERATOR:
        analysisNodes = analysis.getGeneratorNodes();
        break;
      case HMG:
        List<HMGAnalysis> hmgAnalyses = analysis.getHmgAnalysis();

        // verify generator status exists
        checkForMissingHMGStatuses(hmgAnalyses);

        List<AnalysisStatus> fullStatusList =
            hmgAnalyses.stream().map(HMGAnalysis::getAcStatus).collect(Collectors.toList());
        fullStatusList.addAll(
            hmgAnalyses.stream().map(HMGAnalysis::getDcStatus).collect(Collectors.toList()));
        // get unique generator status list
        uniqueStatuses = fullStatusList.stream().distinct().collect(Collectors.toList());

        return getAnalysisStatus(uniqueStatuses);
      case STATIC_INVERTER:
        // get static inverters
        List<StaticInverter> staticInverters = analysis.getStaticInverterAnalysis();

        // verify generator status exists
        checkForMissingStaticInverterStatuses(staticInverters);

        // get unique generator status list
        uniqueStatuses =
            staticInverters.stream()
                .filter(distinctByKey(StaticInverter::getStatus))
                .map(StaticInverter::getStatus)
                .collect(Collectors.toList());

        return getAnalysisStatus(uniqueStatuses);
      case TRU:
        analysisNodes = analysis.getTruNodes();
        break;
      default:
        throw new BadRequestException("Node Type not found: " + nodeType, Level.WARN);
    }

    // sometimes nodes are missing load[] AND status field which generates NPE.
    checkForMissingStatuses(analysisNodes);

    // only grab unique statuses
    uniqueStatuses =
        analysisNodes.stream()
            .filter(distinctByKey(AnalysisNode::getStatus))
            .map(AnalysisNode::getStatus)
            .collect(Collectors.toList());

    return getAnalysisStatus(uniqueStatuses);
  }

  /**
   * This method generates a PdfPTable based on parameters passed in
   *
   * @param analysisLoads - Collection of load data
   * @param flightPhases - Collection of flight phases
   * @param rating - Node total rating value
   * @param phase - ElectricalPhase type to filter against
   * @return PdfPTable
   */
  private PdfPTable addPhaseTable(
      List<AnalysisLoad> analysisLoads,
      List<FlightPhaseDto> flightPhases,
      Double rating,
      String phase) {

    if (analysisLoads.isEmpty()) {
      analysisLoads = setDefaultLoads(flightPhases, phase, Units.KVA);
    }

    List<AnalysisLoad> loads =
        analysisLoads.stream()
            .filter(analysisLoad -> analysisLoad.getElectricalPhase().equalsIgnoreCase(phase))
            .collect(Collectors.toList());

    int totalTableColumns = flightPhases.size() + 1;
    PdfPTable phaseTable = PdfFormatUtil.createBaseTable(totalTableColumns);
    phaseTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    phaseTable.setTotalWidth(100);

    // verify loads exist
    if (!loads.isEmpty()) {
      float totalWidth = phaseTable.getTotalWidth();
      float flightPhaseColumnWidth = totalTableColumns + 2 / totalWidth;
      float[] tableWidths = new float[totalTableColumns];

      tableWidths[0] = flightPhaseColumnWidth * 2;
      for (int i = 1; i < totalTableColumns; i++) {
        tableWidths[i] = flightPhaseColumnWidth;
      }

      phaseTable.setWidths(tableWidths);

      // TODO: TRUs contain all zero values which returns 'KVA' but it needs to be 'AMPS'
      Units unit = findFirstNonZeroUnit(loads);

      // do not show row text if phase is "DC"
      String phraseTitlePhrase = "";
      if (!phase.equalsIgnoreCase("dc") && !phase.equalsIgnoreCase("total")) {
        phraseTitlePhrase =
            String.format(
                "Phase %s - (%s %s)",
                phase.equalsIgnoreCase("aca") ? "A" : phase.equalsIgnoreCase("acb") ? "B" : "C",
                PdfFormatUtil.DECIMAL_FORMAT_0_PLACE.format(rating),
                unit);
        PdfPCell phaseTitleCell =
            pdfFormatUtil.flightPhaseTableTitleRowCell(phraseTitlePhrase, totalTableColumns);
        phaseTable.addCell(phaseTitleCell);
      }

      // set header row
      phaseTable.addCell(PdfFormatUtil.getBlankCell()); // skip first column

      for (FlightPhaseDto flightPhase : flightPhases) {
        PdfPCell flightPhaseCell =
            pdfFormatUtil.flightPhaseTableHeaderRowCell(
                PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 8f);
        phaseTable.addCell(flightPhaseCell);
      }

      List<String> percentUsed = new ArrayList<>();
      percentUsed.add("Percent Used");

      List<String> totalLoad = new ArrayList<>();
      totalLoad.add("Total Load (" + unit.toString() + ")");

      // populate load list
      for (FlightPhaseDto flightPhase : flightPhases) {
        Double percentUsedVal = 0d;
        Double totalLoadVal = 0d;

        for (AnalysisLoad load : loads) {
          if (flightPhase.getName().equalsIgnoreCase(load.getFlightPhase())) {
            percentUsedVal = load.getResult();
            totalLoadVal = load.getValue();
            break;
          }
        }

        // append value to cell
        percentUsed.add(PdfFormatUtil.DECIMAL_FORMAT_PERCENT.format(percentUsedVal));
        totalLoad.add(
            Units.KVA.equals(unit)
                ? PdfFormatUtil.DECIMAL_FORMAT_3_PLACE_NO_LEAD.format(totalLoadVal)
                : PdfFormatUtil.DECIMAL_FORMAT_1_PLACE_NO_LEAD.format(totalLoadVal));
      }

      // "Percent Used" row
      for (String columnValue : percentUsed) {
        phaseTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, false));
      }

      // "Total Load" row
      for (String columnValue : totalLoad) {
        phaseTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, false));
      }
    }

    phaseTable.setSpacingAfter(20f);

    return phaseTable;
  }

  private PdfPTable createDefaultNodeAnalysisTable(
      AnalysisNode analysisNode, Double rating, Units unit) {
    PdfPTable table = PdfFormatUtil.createBaseTable();

    Paragraph nodeTitleParagraph =
        new Paragraph(
            String.format(
                "%s (%s %s)",
                analysisNode.getName(), PdfFormatUtil.DECIMAL_FORMAT_0_PLACE.format(rating), unit));

    PdfPCell nodeTitleCell = setStatusIconAndLabel(analysisNode.getStatus(), nodeTitleParagraph);
    table.addCell(nodeTitleCell);

    return table;
  }

  private PdfPTable createDefaultNodeAnalysisTable(FuelJettisonGenerator node, Units unit) {
    PdfPTable table = PdfFormatUtil.createBaseTable();

    String rating = PdfFormatUtil.DECIMAL_FORMAT_0_PLACE.format(node.getRating());
    Paragraph nodeTitleParagraph =
        new Paragraph(String.format("%s (%s %s)", node.getGeneratorName(), rating, unit));

    PdfPCell nodeTitleCell = setStatusIconAndLabel(node.getGeneratorStatus(), nodeTitleParagraph);
    table.addCell(nodeTitleCell);

    return table;
  }

  private void checkForMissingFuelJettisonGeneratorStatuses(List<FuelJettisonGenerator> nodes) {
    nodes.forEach(
        (node) -> {
          if (node.getGeneratorStatus() == null) {
            node.setGeneratorStatus(AnalysisStatus.PASS);
          }
        });
  }

  private void checkForMissingStaticInverterStatuses(List<StaticInverter> nodes) {
    nodes.forEach(
        (node) -> {
          if (node.getStatus() == null) {
            node.setStatus(AnalysisStatus.PASS);
          }
        });
  }

  private void checkForMissingHMGStatuses(List<HMGAnalysis> nodes) {
    nodes.forEach(
        (node) -> {
          if (node.getAcStatus() == null) {
            node.setAcStatus(AnalysisStatus.PASS);
          }
          if (node.getDcStatus() == null) {
            node.setDcStatus(AnalysisStatus.PASS);
          }
        });
  }

  private void checkForMissingStatuses(List<AnalysisNode> nodes) {
    nodes.forEach(
        (node) -> {
          if (node.getStatus() == null) {
            node.setStatus(AnalysisStatus.PASS);
          }
        });
  }

  private PdfPCell getNodeAnalysisTableCell(
      AnalysisType analysis,
      List<FlightPhaseDto> flightPhases,
      String conditionType,
      String nodeType,
      StandbyOperation standbyOperation) {

    boolean isDegraded = DEGRADED_ANALYSIS_NAME.equalsIgnoreCase(conditionType);
    String nodeLabel;
    PdfPTable cellTable;

    switch (nodeType) {
      case AUTO_LAND:
        nodeLabel = "Autoland Operation";
        cellTable = getAutoLandAnalysis(analysis.getAutoLandCondition());
        break;
      case GENERATOR:
        nodeLabel = isDegraded ? "Loss of Generator" : "Generators";
        cellTable = getGeneratorAnalysis(analysis, flightPhases);
        break;
      case TRU:
        nodeLabel = isDegraded ? "Loss of TRU" : "TRUs";
        cellTable = getTruAnalysis(analysis, flightPhases, isDegraded);
        break;
      case ATU: // not a part of degraded analysis
        nodeLabel = "ATUs";
        cellTable = getAtuAnalysis(analysis, flightPhases);
        break;
      case FUEL_JETTISON:
        nodeLabel = "Fuel Jettison";
        cellTable = getFuelJettisonAnalysis(analysis.getFuelJettisonGenerators(), flightPhases);
        break;
      case HMG:
        nodeLabel = "HMG Generator";
        cellTable = getHMGAnalysis(analysis.getHmgAnalysis());
        break;
      case STATIC_INVERTER:
        nodeLabel = "Static Inverter";
        cellTable = getStaticInverterAnalysis(analysis.getStaticInverterAnalysis());
        break;
      case STANDBY:
        nodeLabel = "Standby Operation";
        cellTable = getStandbyOperationAnalysis(standbyOperation);
        break;
      default:
        nodeLabel = isDegraded ? "Loss of Bus" : "Buses";
        cellTable = getBusAnalysis(analysis, flightPhases);
        break;
    }

    // set default value (PASS)
    AnalysisStatus status = AnalysisStatus.PASS;
    if (STANDBY.equalsIgnoreCase(nodeType)) {
      if (standbyOperation != null) {
        status = standbyOperation.getStatus();
      }
    } else {
      status = determineNodeStatus(analysis, nodeType);
    }

    String headerText = String.format("%s Conditions - %s", conditionType, nodeLabel);

    PdfPCell defaultCell =
        setStatusIconAndLabel(status, new Paragraph(headerText, PdfFormatUtil.createFont(3)));
    defaultCell.addElement(cellTable);
    defaultCell.setPaddingBottom(10f);

    return defaultCell;
  }

  private PdfPTable generateFuelJettisonTable(
      List<FlightPhaseDto> flightPhases,
      List<FuelJettisonLoad> fuelJettisonLoads,
      AnalysisStatus status,
      boolean isWithJettison) {
    int totalTableColumns = flightPhases.size() + 1;
    Units unit = Units.KVA;

    // create table
    PdfPTable pdfPTable = PdfFormatUtil.createBaseTable(totalTableColumns);

    float totalWidth = pdfPTable.getTotalWidth();
    float flightPhaseColumnWidth = totalTableColumns + 2 / totalWidth;
    float[] tableWidths = new float[totalTableColumns];

    tableWidths[0] = flightPhaseColumnWidth * 2;
    for (int i = 1; i < totalTableColumns; i++) {
      tableWidths[i] = flightPhaseColumnWidth;
    }

    pdfPTable.setWidths(tableWidths);

    // header row
    String title = isWithJettison ? "With Fuel Jettison" : "Single Engine Single Generator";
    Paragraph nodeTitleParagraph = new Paragraph(title);
    PdfPCell titleRowWithStatus = setStatusIconAndLabel(status, nodeTitleParagraph);
    titleRowWithStatus.setColspan(totalTableColumns);
    pdfPTable.addCell(titleRowWithStatus);

    // (blue header with column titles)
    PdfPCell tableHeaderRow = pdfFormatUtil.createColoredBackgroundTableHeaderRow();
    tableHeaderRow.setColspan(totalTableColumns);
    pdfPTable.addCell(tableHeaderRow);

    // first cell is blank
    pdfPTable.addCell(PdfFormatUtil.getBlankCell());

    // append flight phase headers
    for (FlightPhaseDto flightPhase : flightPhases) {
      PdfPCell flightPhaseCell =
          pdfFormatUtil.flightPhaseTableHeaderRowCell(
              PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 8f);
      pdfPTable.addCell(flightPhaseCell);
    }

    List<String> percentUsed = new ArrayList<>();
    percentUsed.add("Percent Used");

    List<String> totalLoad = new ArrayList<>();
    totalLoad.add("Total Load (" + unit + ")");

    // populate load list
    for (FlightPhaseDto flightPhase : flightPhases) {
      Double percentUsedVal = 0d;
      Double totalLoadVal = 0d;

      // grab fuel jettison values
      for (FuelJettisonLoad fuelJettisonLoad : fuelJettisonLoads) {
        if (flightPhase.getName().equalsIgnoreCase(fuelJettisonLoad.getFlightPhase())) {
          percentUsedVal =
              isWithJettison
                  ? fuelJettisonLoad.getPercentageWithJettison()
                  : fuelJettisonLoad.getPercentageWithoutJettison();
          totalLoadVal =
              isWithJettison
                  ? fuelJettisonLoad.getLoadWithJettison()
                  : fuelJettisonLoad.getLoadWithoutJettison();
          break;
        }
      }

      // append value to cell
      percentUsed.add(PdfFormatUtil.DECIMAL_FORMAT_PERCENT.format(percentUsedVal));
      totalLoad.add(PdfFormatUtil.DECIMAL_FORMAT_3_PLACE_NO_LEAD.format(totalLoadVal));
    }

    // "Percent Used" row
    for (String columnValue : percentUsed) {
      pdfPTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, false));
    }

    // "Total Load" row
    for (String columnValue : totalLoad) {
      pdfPTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, false));
    }

    return pdfPTable;
  }

  private ElectricalPhase findFirstNonZeroPhase(List<AnalysisLoad> loads) {
    if (loads.isEmpty()) {
      return ElectricalPhase.NA;
    }

    return ElectricalPhase.valueOf(loads.get(0).getElectricalPhase());
  }

  private Units findFirstNonZeroUnit(List<AnalysisLoad> loads) {
    if (loads.isEmpty()) {
      return Units.KVA;
    }

    List<AnalysisLoad> nonZeroLoads =
        loads.stream()
            .filter(analysisLoad -> analysisLoad.getValue() > 0)
            .collect(Collectors.toList());

    return !nonZeroLoads.isEmpty() ? nonZeroLoads.get(0).getUnits() : Units.AMPS;
  }

  private AnalysisStatus getAnalysisStatus(List<AnalysisStatus> statuses) {
    return statuses.contains(AnalysisStatus.FAIL)
        ? AnalysisStatus.FAIL
        : statuses.contains(AnalysisStatus.WARN) ? AnalysisStatus.WARN : AnalysisStatus.PASS;
  }

  private AnalysisType getAnalysisType(ProjectAnalysis projectAnalysis, String condition) {
    return NORMAL_ANALYSIS_NAME.equalsIgnoreCase(condition)
        ? projectAnalysis.getAnalysis().getNormalAnalysis()
        : projectAnalysis.getAnalysis().getDegradedAnalysis();
  }

  private Paragraph getStatusParagraph(AnalysisStatus status, float fontSize) {
    Font font = new Font();

    if (status == null) {
      status = AnalysisStatus.PASS;
    }

    switch (status) {
      case PASS:
        font.setColor(PASS_COLOR);
        break;
      case WARN:
        font.setColor(WARN_COLOR);
        break;
      case FAIL:
        font.setColor(FAIL_COLOR);
        break;
      default:
        font.setColor(Color.BLACK);
        break;
    }

    font.setSize(fontSize);

    // show `CAUTION` not `WARN` label
    String statusText = status.equals(AnalysisStatus.WARN) ? "CAUTION" : status.toString();

    return new Paragraph("(" + statusText + ")", font);
  }

  private List<AnalysisLoad> setDefaultLoads(
      List<FlightPhaseDto> flightPhases, String electricalPhase, Units units) {
    List<AnalysisLoad> loads = new ArrayList<>();

    for (FlightPhaseDto flightPhase : flightPhases) {
      AnalysisLoad load =
          new AnalysisLoad(
              0d,
              PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()),
              0d,
              electricalPhase,
              units);
      loads.add(load);
    }

    return loads;
  }

  private static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
    Map<Object, Boolean> map = new ConcurrentHashMap<>();
    return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
  }
}
