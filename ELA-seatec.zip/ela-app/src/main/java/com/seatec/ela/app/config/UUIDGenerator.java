package com.seatec.ela.app.config;

import com.seatec.ela.app.model.base.BaseEntity;
import java.io.Serializable;
import java.util.UUID;
import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

/**
 * Set a value for the entities 'id' if it isn't already set.
 *
 * @author asparago
 */
public class UUIDGenerator implements IdentifierGenerator {

  @Override
  public Serializable generate(SharedSessionContractImplementor session, Object obj)
      throws HibernateException {
    BaseEntity entity = (BaseEntity) obj;
    return (entity.getId() == null) ? UUID.randomUUID() : entity.getId();
  }
}
