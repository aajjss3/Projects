package com.seatec.ela.app.validator.filter;

public interface CreateProject {}
