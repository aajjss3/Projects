package com.seatec.ela.app.util.enumeration;

public enum AnalysisStatus {
  PASS,
  FAIL,
  WARN;

  public static AnalysisStatus map(String status) {
    if ("FAIL".equalsIgnoreCase(status)) {
      return FAIL;
    } else if ("WARN".equalsIgnoreCase(status)) {
      return WARN;
    } else {
      return PASS;
    }
  }
}
