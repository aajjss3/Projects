package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackIdLong;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import com.seatec.ela.app.util.regexp.ValidationRegExp;
import com.seatec.ela.app.validator.filter.ValidateFleet;
import com.seatec.ela.app.validator.filter.ValidateSubFleet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class FleetDto implements UserTrackIdLong, UserTrackName {

  private Long id;

  @NotEmpty(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      message = "{field.required}")
  @Pattern(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      regexp = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE)
  private String name;

  @NotEmpty(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      message = "{field.required}")
  @Pattern(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      regexp = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE)
  private String manufacturer;

  @NotEmpty(
      groups = {ValidateFleet.class},
      message = "{field.required}")
  @Pattern(
      groups = {ValidateFleet.class},
      regexp = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE)
  private String busStructureBucket;

  @NotEmpty(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      message = "{field.required}")
  @Pattern(
      groups = {ValidateFleet.class, ValidateSubFleet.class},
      regexp = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE)
  private String structureName;

  private boolean archived;

  private boolean etops;

  private Long parentFleetId;

  private Map<String, Set<String>> metadata;

  public FleetDto() {}

  public FleetDto(Fleet fleet) {
    this.id = fleet.getId();
    this.name = fleet.getName();
    this.manufacturer = fleet.getManufacturer();
    this.busStructureBucket = fleet.getBusStructureBucket();
    this.structureName = fleet.getStructureName();
    this.archived = fleet.isArchived();
    if (fleet.getParentFleet() != null) {
      this.parentFleetId = fleet.getParentFleet().getId();
    }
    this.etops = fleet.isEtops();
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getManufacturer() {
    return manufacturer;
  }

  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public String getBusStructureBucket() {
    return busStructureBucket;
  }

  public void setBusStructureBucket(String busStructureBucket) {
    this.busStructureBucket = busStructureBucket;
  }

  public String getStructureName() {
    return structureName;
  }

  public void setStructureName(String structureName) {
    this.structureName = structureName;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public Long getParentFleetId() {
    return parentFleetId;
  }

  public void setParentFleetId(Long parentFleetId) {
    this.parentFleetId = parentFleetId;
  }

  public Map<String, Set<String>> getMetadata() {
    return metadata;
  }

  public void setMetadata(Map<String, Set<String>> metadata) {
    this.metadata = metadata;
  }

  public boolean isEtops() {
    return etops;
  }

  public void setEtops(boolean etops) {
    this.etops = etops;
  }

  public List<String> getOperatingModes() {
    return OperatingMode.getOperatingModes(this.manufacturer, this.name);
  }

  public List<FlightPhaseDto> getFlightPhases() {
    return FlightPhase.getFlightPhases(this.manufacturer, this.etops, this.name, false);
  }
}
