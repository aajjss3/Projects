package com.seatec.ela.app.util.enumeration;

import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.model.FlightPhaseDto;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FlightPhase {
  private static final String AIRBUS_MANUFACTURER = "airbus";
  private static final String BOEING_MANUFACTURER = "boeing";

  /** Hydraulic Motor driven electrical Generator - a flight phase that is added on ETOPs fleets */
  public static final String HMG_FLIGHT_PHASE = "HMG";

  public static final String STANDBY_FLIGHT_PHASE = "STANDBY";

  public static final String BOEING_717_FLEET = "B717";

  /**
   * Returns a list of Flight Phases based on Fleet Manufacturer
   *
   * @param manufacturer - Fleet Manufacturer of Aircraft
   * @param etops - Extended-range Twin-engine Operational Performance Standards
   * @param fleetName - Name of the fleet
   * @param excludeBatterySupplied - Exclude flight phases where battery (not generator) is
   *     supplying load
   * @return List<FlightPhaseDto>
   */
  public static List<FlightPhaseDto> getFlightPhases(
      String manufacturer, boolean etops, String fleetName, boolean excludeBatterySupplied) {
    List<FlightPhaseDto> flightPhaseDtos = Collections.emptyList();

    switch (manufacturer.toLowerCase()) {
      case AIRBUS_MANUFACTURER:
        flightPhaseDtos =
            Arrays.stream(ClientConfig.Airbus.values())
                .map(phase -> new FlightPhaseDto(phase.toString(), false))
                .collect(Collectors.toList());
        break;
      case BOEING_MANUFACTURER:
        // flight phase(s) where battery (not generator) is supplying load
        List<String> batterySupplied =
            new ArrayList<>(Arrays.asList(STANDBY_FLIGHT_PHASE, HMG_FLIGHT_PHASE));

        if (fleetName.startsWith(BOEING_717_FLEET)) {
          flightPhaseDtos =
              Arrays.stream(ClientConfig.Boeing717.values())
                  .map(
                      phase ->
                          new FlightPhaseDto(
                              phase.toString(), batterySupplied.contains(phase.toString())))
                  .collect(Collectors.toList());
        } else {
          flightPhaseDtos =
              Arrays.stream(ClientConfig.Boeing.values())
                  .map(
                      phase ->
                          new FlightPhaseDto(
                              phase.toString(), batterySupplied.contains(phase.toString())))
                  .collect(Collectors.toList());

          // a rule which permits twin engine aircraft to fly routes which, at some point,
          // are more than 60 minutes flying time away from the nearest airport suitable
          // for emergency landing.
          if (etops) {
            flightPhaseDtos.add(new FlightPhaseDto(HMG_FLIGHT_PHASE, true));
          }
        }
        break;
    }

    if (excludeBatterySupplied) {
      flightPhaseDtos =
          flightPhaseDtos.stream().filter(f -> !f.isBatterySupplied()).collect(Collectors.toList());
    }

    return flightPhaseDtos;
  }
}
