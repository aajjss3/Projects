package com.seatec.ela.app.service.contract.project;

import com.seatec.ela.app.dto.AircraftBusStructureBucketDto;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import java.util.List;
import java.util.UUID;

/** Service for dealing with AircraftChangeGroups. */
public interface IAircraftChangeGroupService {

  List<AircraftChangeGroup> findAllByChangeGroupIdIn(List<UUID> changeGroupIds);

  List<AircraftChangeGroup> convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
      AircraftBusStructureBucketDto aircraftBusStructureBucketDto, ChangeGroup changeGroup);

  AircraftChangeGroup save(AircraftChangeGroup entity);
}
