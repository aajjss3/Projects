package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.Component;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ComponentRepository extends CrudRepository<Component, Long> {

  List<Component> findByNodeIdIn(List<Long> nodeId);

  @Query(
      nativeQuery = true,
      value =
          "WITH RECURSIVE nodetree AS "
              + "(SELECT id, name, voltage, nominal_power, display_order, node_id, ela_id, node_type, requires_approval, bus_rating, voltage_type, sheddable, description, efficiency_table_id, electrical_phase "
              + "FROM node n "
              + "WHERE node_id IS NULL AND ela_id = :elaId "
              + "UNION ALL "
              + "SELECT ni.id, ni.name, ni.voltage, ni.nominal_power, ni.display_order, ni.node_id, ni.ela_id, ni.node_type, ni.requires_approval, ni.bus_rating, ni.voltage_type, ni.sheddable, ni.description, ni.efficiency_table_id, ni.electrical_phase "
              + "FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id) "
              + ") "
              + "SELECT c.* FROM component c INNER JOIN nodetree nt ON nt.id = c.node_id")
  List<Component> getComponentsInEla(@Param("elaId") Long elaId);
}
