package com.seatec.ela.app.aop.userevent;
/**
 * Used to populate details for LogDetail
 *
 * @see LogDetail
 * @see LogConfig
 */
public interface UserTrackAuthor {
  public String getAuthor();
}
