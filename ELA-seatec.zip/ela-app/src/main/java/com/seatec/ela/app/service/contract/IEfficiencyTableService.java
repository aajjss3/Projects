package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.model.EfficiencyTable;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface IEfficiencyTableService {

  List<EfficiencyTable> findAll();

  Map<UUID, EfficiencyTable> findAllAsMap();
}
