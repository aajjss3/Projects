package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.validator.annotation.ComponentLoadChange;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ComponentLoadChangeValidator
    implements ConstraintValidator<ComponentLoadChange, ComponentChange> {

  @Override
  public void initialize(ComponentLoadChange constraintAnnotation) {}

  @Override
  public boolean isValid(ComponentChange componentChange, ConstraintValidatorContext context) {
    Double nominalPower = componentChange.getNominalPower();
    boolean badLoad;

    // Nominal Power Validator
    if (nominalPower != null && nominalPower != 0d) {
      badLoad =
          componentChange.getLoadChanges().stream()
              .anyMatch(
                  load ->
                      load.getVa() > nominalPower
                          || load.getVa() < 0.0
                          || load.getPowerFactor() > 1.0
                          || load.getPowerFactor() < 0.0);
    } else {
      badLoad =
          componentChange.getLoadChanges().stream()
              .anyMatch(
                  load ->
                      load.getVa() < 0.0
                          || load.getPowerFactor() > 1.0
                          || load.getPowerFactor() < 0.0);
    }

    // if invalid then return Custom constraint
    if (badLoad) {
      return buildCustomConstraint(
          "not a valid component load for Nominal Power", "nominalPower", context);
    }

    // Power Factor Validator
    ElectricalPhase electricalPhase = componentChange.getElectricalPhase();
    if (electricalPhase != null && electricalPhase.equals(ElectricalPhase.DC)) {
      Optional<LoadChange> loadChange =
          componentChange.getLoadChanges().stream()
              .filter(load -> !load.getPowerFactor().equals(1d))
              .findFirst();

      // validation failed so build error message
      if (loadChange.isPresent()) {
        LoadChange loadChangeEntity = loadChange.get();
        int idx = componentChange.getLoadChanges().indexOf(loadChangeEntity);

        return buildCustomConstraint(
            "not a valid Power Factor '"
                + loadChangeEntity.getPowerFactor()
                + "' for component load (Operating Mode:"
                + " '"
                + loadChangeEntity.getOperatingMode()
                + "' "
                + "and Flight Phase '"
                + loadChangeEntity.getFlightPhase()
                + "')",
            "loadChanges[" + idx + "].powerFactor",
            context);
      }
    }

    return true;
  }

  private boolean buildCustomConstraint(
      String message, String fieldName, ConstraintValidatorContext context) {
    // disable default constraint violation and build custom message
    context.disableDefaultConstraintViolation();
    context
        .buildConstraintViolationWithTemplate(message)
        .addPropertyNode(fieldName)
        .addConstraintViolation();
    return false;
  }
}
