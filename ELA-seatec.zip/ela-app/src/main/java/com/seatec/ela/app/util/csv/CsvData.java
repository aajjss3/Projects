package com.seatec.ela.app.util.csv;

import java.util.LinkedHashMap;
import java.util.List;

public class CsvData {
  private LinkedHashMap<String, List<AirbusCsvAggregateKey>> keyMap = new LinkedHashMap<>(100);
  private LinkedHashMap<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap =
      new LinkedHashMap<>(2000);

  public LinkedHashMap<String, List<AirbusCsvAggregateKey>> getKeyMap() {
    return keyMap;
  }

  public LinkedHashMap<AirbusCsvAggregateKey, AirbusCsvAggregate> getDataMap() {
    return dataMap;
  }
}
