package com.seatec.ela.app.util.enumeration;

public final class Utility {
  public static String[] concatenate(String[] a, String[] b) {
    int length = a.length + b.length;
    String[] result = new String[length];
    System.arraycopy(a, 0, result, 0, a.length);
    System.arraycopy(b, 0, result, a.length, b.length);
    return result;
  }
}
