package com.seatec.ela.app.validator.annotation;

import com.seatec.ela.app.validator.constraint.BatteryChargeTypeRequiredIfBoeingValidator;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = BatteryChargeTypeRequiredIfBoeingValidator.class)
@Documented
@Inherited
public @interface BatteryChargeTypeRequiredIfBoeing {
  String message() default "Battery Configuration required with Boeing Manufacturer";

  Class<?>[] groups() default {};

  Class[] payload() default {};
}
