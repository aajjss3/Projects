package com.seatec.ela.app.service.project.change;

import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.project.change.ChangeRepo;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.service.contract.project.change.IChangeCommentService;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import com.seatec.ela.app.util.FieldValidator;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ChangeService implements IChangeService {

  @Autowired private IChangeCommentService changeCommentService;

  @Autowired private IChangeGroupService changeGroupService;

  @Autowired private IProjectService projectService;

  @Autowired private ChangeRepo changeRepo;

  @Autowired
  @Qualifier("mapAll")
  private ModelMapper mapper;

  public ChangeService() {}

  public ChangeService(
      IChangeCommentService changeCommentService,
      IChangeGroupService changeGroupService,
      IProjectService projectService,
      ChangeRepo changeRepo,
      ModelMapper mapper) {
    this.changeCommentService = changeCommentService;
    this.changeGroupService = changeGroupService;
    this.projectService = projectService;
    this.changeRepo = changeRepo;
    this.mapper = mapper;
  }

  public List<Change> findAllByProjectAndChangeGroupId(UUID changeGroupId, UUID projectId) {
    ChangeGroup changeGroupEntity =
        findChangeGroupByProjectAndChangeGroupId(projectId, changeGroupId);
    return changeGroupEntity.getChanges();
  }

  public List<Change> findAllByChangeGroupId(UUID changeGroupId) {
    return changeRepo.findAllByChangeGroupId(changeGroupId);
  }

  public Optional<Change> findById(UUID id) {
    return changeRepo.findById(id);
  }

  /**
   * Save Change record for a given Change Group
   *
   * @param change Represents Change Entity
   * @param changeGroupId Represents unique ChangeGroup identifier (UUID)
   * @return Change Entity
   */
  @Transactional
  public Change create(Change change, UUID changeGroupId, UUID projectId) {
    ChangeGroup changeGroupEntity =
        findChangeGroupByProjectAndChangeGroupId(projectId, changeGroupId);

    // get project
    Project project = changeGroupEntity.getProject();

    // verify project is not approved (locked state aka read-only)
    if (project.getApproved() != null) {
      throw new BadRequestException(
          "Cannot create Changes after a project has been approved.", Level.ERROR);
    }

    // business rule: cannot have multiple node/bus with same NodeName
    checkForDuplicateNodeNamesInChangeGroup(changeGroupEntity, change.getNodeChange());

    // verify loadChanges() is not null (intermittent components could pass null)
    if (change.getComponentChange() != null
        && change.getComponentChange().getLoadChanges() == null) {
      if (!change.getComponentChange().getIntermittent()) {
        throw new BadRequestException(
            "Loads are missing and required for a non-intermittent component.", Level.ERROR);
      } else {
        // cannot save entity with null value (UI periodically passes null)
        change.getComponentChange().setLoadChanges(new ArrayList<>());
      }
    }

    // verify flightPhase & operating mode for componentChange > loads
    verifyChangeFlightPhaseAndOperatingMode(change, changeGroupEntity);

    // changeGroup node bus tree (entity nodes merged with change records)
    List<ChangeGroupNodeDto> changeGroupNodeDtos =
        changeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(changeGroupId);

    // business rule: if the change is for a component, dont persist the componentchange if there
    // is already an existing component or componentchange for the same node with the same elect
    // ident and phase. ie, a node cannot contain 2 components with the same elect ident and phase.
    verifyComponentIsUniqueByElectIdentAndElectricalPhase(changeGroupNodeDtos, change);

    change.setChangeGroup(changeGroupEntity);
    change.setId(null); // do not let client set the ID

    // get changes for changeGroup
    List<Change> changes = changeGroupEntity.getChanges();

    // business rule: cannot have duplicate changes
    checkIsValidToProceedWithSave(change, changes, changeGroupNodeDtos);

    // business rule: cannot have incompatible power type / voltage
    if (Arrays.asList(ActionType.ADD, ActionType.EDIT).contains(change.getAction())) {
      verifyCompatibleVoltageAndVoltageType(changeGroupNodeDtos, change);
    }

    // split changeGroup if incompatible bus
    splitChangeGroupIfIncompatibleBusOrComponent(changeGroupNodeDtos, changeGroupEntity, change);

    if (change.getNodeChange() != null && change.getAction() == ActionType.DELETE) {
      String nodeChangeName = change.getNodeChange().getName();

      // remove any existing component changes or node changes for this bus
      for (Iterator<Change> iter = changes.iterator(); iter.hasNext(); ) {
        Change c = iter.next();
        if (c.getComponentChange() != null && c.getNodeName().equals(nodeChangeName)
            || c.getNodeChange() != null && c.getNodeName().equals(nodeChangeName)) {
          iter.remove();
          c.setChangeGroup(null);
          changeRepo.delete(c);
        }
      }

      // create delete component changes for each component
      List<ComponentDto> components =
          changeGroupService.findComponentsByChangeGroupAndNodeName(
              changeGroupEntity, nodeChangeName);
      components.forEach(
          component -> {
            ComponentChange componentChange = new ComponentChange();
            mapper.map(component, componentChange);
            Change c = new Change();
            c.setChangeGroup(changeGroupEntity);
            c.setAction(ActionType.DELETE);
            c.setChanger(change.getChanger());
            c.setNodeName(nodeChangeName);
            c.setComponentElectIdent(component.getElectIdent());
            c.setComponentChange(componentChange);
            changeRepo.save(c);
          });
    }

    // save Change record
    return changeRepo.save(change);
  }

  @Transactional
  public void delete(UUID id, UUID changeGroupId, UUID projectId) {
    ChangeGroup changeGroupEntity =
        findChangeGroupByProjectAndChangeGroupId(projectId, changeGroupId);
    Change changeEntity =
        changeRepo
            .findById(id)
            .orElseThrow(
                () -> new NotFoundException("Change (" + id + ") record not found.", Level.ERROR));

    // a component change can't be deleted if it's parent node is also deleted
    if (changeEntity.getComponentChange() != null) {
      verifyComponentChangeDoesNotContainRelatedNodeChange(
          changeGroupEntity, changeEntity.getNodeName());
    }

    // if a node change
    if (changeEntity.getNodeChange() != null) {
      // change cannot be deleted if there is another change in changeGroup with same name.
      if (changeEntity.getNodeChange().getName() != null) {
        verifyChangeGroupChangeDoesNotContainNodeChangeWithSameNodeName(
            changeGroupEntity, changeEntity.getNodeChange());
      }

      String nodeName = changeEntity.getNodeChange().getName();

      // if node children then throw exception
      checkForChildNodeChanges(changeGroupEntity, changeEntity.getId(), nodeName);

      if (changeEntity.getAction().equals(ActionType.ADD)
          || changeEntity.getAction().equals(ActionType.DELETE)) {
        // check/delete related component changes
        deleteRelatedComponentChanges(changeGroupEntity, nodeName, changeEntity.getAction());
      }
    }

    // delete related comments
    changeCommentService.deleteAllByChangeId(
        changeGroupEntity.getProject().getId(), changeGroupEntity.getId(), changeEntity.getId());

    // remove association to Change Group
    changeGroupEntity.removeChange(changeEntity);

    // delete
    changeRepo.delete(changeEntity);
  }

  @Transactional
  public void update(Change change, UUID changeId) {
    Change changeEntity =
        changeRepo
            .findById(changeId)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Change (" + changeId + ") record not found.", Level.ERROR));

    boolean isNodeChange = change.getNodeChange() != null;

    // business rule - cannot change name of an existing node/bus
    if (isNodeChange
        && !change
            .getNodeChange()
            .getName()
            .equalsIgnoreCase(changeEntity.getNodeChange().getName())) {
      throw new ConflictException(
          "Cannot edit the Name value for an existing entity.", Level.ERROR);
    }

    // verify flightPhase & operating mode for componentChange > loads
    verifyChangeFlightPhaseAndOperatingMode(change, changeEntity.getChangeGroup());

    changeEntity.setChanger(change.getChanger());
    ActionType entityAction = changeEntity.getAction();
    ActionType changeAction = change.getAction();

    // action: ADD || EDIT -> EDIT (update fields only)
    if (entityAction == ActionType.ADD && changeAction == ActionType.EDIT
        || entityAction == ActionType.EDIT && changeAction == ActionType.EDIT) {
      if (isNodeChange) {
        changeEntity.setNodeChange(change.getNodeChange());
      } else {
        changeEntity.setComponentElectIdent(change.getComponentElectIdent());
        changeEntity.setComponentChange(change.getComponentChange());
      }
    }

    // action: EDIT -> DELETE (update action only)
    else if (entityAction == ActionType.EDIT && changeAction == ActionType.DELETE) {
      changeEntity.setAction(changeAction);
    }

    // action: DELETE -> EDIT (update action and fields)
    else if (entityAction == ActionType.DELETE && changeAction == ActionType.EDIT) {
      changeEntity.setAction(changeAction);

      if (isNodeChange) {
        changeEntity.setNodeChange(change.getNodeChange());
      } else {
        changeEntity.setComponentElectIdent(change.getComponentElectIdent());
        changeEntity.setComponentChange(change.getComponentChange());
      }
    }

    // action: DELETE || EDIT || ADD -> ADD (throw exception)
    else if (entityAction == ActionType.ADD && changeAction == ActionType.ADD
        || entityAction == ActionType.DELETE && changeAction == ActionType.ADD
        || entityAction == ActionType.DELETE && changeAction == ActionType.DELETE
        || entityAction == ActionType.EDIT && changeAction == ActionType.ADD) {
      throw new ConflictException(
          "Cannot '"
              + changeAction
              + "' this item because its marked as '"
              + entityAction
              + "' already. To resolve, remove the '"
              + entityAction
              + "' Change entry.",
          Level.ERROR);
    }

    // action: ADD -> DELETE (throw exception - client should route to DELETE Change API)
    else {
      throw new BadRequestException("Cannot perform this action (ADD -> DELETE).", Level.ERROR);
    }
  }

  private void checkForChildNodeChanges(ChangeGroup changeGroup, UUID changeId, String nodeName) {
    boolean hasNodeChildren =
        changeGroup.getChanges().stream()
            .anyMatch(
                change ->
                    change.getNodeChange() != null
                        && change.getId() != changeId
                        && change.getAction() != ActionType.DELETE
                        && change.getNodeName() != null
                        && change.getNodeName().equalsIgnoreCase(nodeName));

    if (hasNodeChildren) {
      throw new ConflictException(
          "Node/Bus '" + nodeName + "' has children. Must delete children first.", Level.ERROR);
    }
  }

  private void checkForDuplicateNodeNamesInChangeGroup(
      ChangeGroup changeGroupEntity, NodeChange nodeChange) {
    // business rule: cant have multiple nodes with same name (excluding deleted)
    if (nodeChange != null) {
      boolean canAdd =
          changeGroupEntity.getChanges().stream()
              .noneMatch(
                  c ->
                      c.getNodeChange() != null
                          && c.getNodeChange().getName().equalsIgnoreCase(nodeChange.getName())
                          && !c.getAction().equals(ActionType.DELETE));

      if (!canAdd) {
        throw new ConflictException(
            "Node/Bus '"
                + nodeChange.getName()
                + "' already exists. Cannot add multiple active Node/Bus with same name.",
            Level.ERROR);
      }
    }
  }

  private void checkIsValidToProceedWithSave(
      Change change, List<Change> changes, List<ChangeGroupNodeDto> changeGroupNodeDtos) {

    // determine which node name to use
    String nodeName = getNodeNameFromChange(change);

    // If no changes already present
    if (changes.isEmpty()) {
      // check if component change's nodeName matches a node
      if (change.getComponentChange() != null) {
        ChangeGroupNodeDto matchingNode = findNode(changeGroupNodeDtos, nodeName);
        if (matchingNode == null) {
          throw new NotFoundException("No match found for Node name (" + nodeName + ").");
        }
      } else {
        // check if changeGroupNodeDtos contains matching nodeName
        if (nodeName != null && !nodeName.isEmpty()) {
          verifyNodeExists(changeGroupNodeDtos, nodeName);
        }
      }
    } else {
      boolean isDuplicate = false;

      // if existing ComponentChanges, verify business rules
      boolean isRootLevelNodeAdd =
          change.getAction().equals(ActionType.ADD) && change.getNodeName() == null
              || change.getNodeName().isEmpty();

      if (!isRootLevelNodeAdd) {
        verifyNodeExists(changeGroupNodeDtos, nodeName);

        if (change.getComponentChange() != null) {
          isDuplicate =
              changes.stream()
                  .anyMatch(
                      ch ->
                          ch.getNodeName() != null
                              && ch.getNodeName().equalsIgnoreCase(nodeName)
                              && ch.getComponentElectIdent() != null
                              && ch.getComponentElectIdent()
                                  .equalsIgnoreCase(change.getComponentElectIdent())
                              && ch.getComponentChange() != null
                              && ch.getComponentChange()
                                  .getElectIdent()
                                  .equalsIgnoreCase(change.getComponentChange().getElectIdent())
                              && ch.getComponentChange().getElectricalPhase()
                                  == change.getComponentChange().getElectricalPhase());
        } else {
          isDuplicate =
              changes.stream()
                  .filter(Objects::nonNull)
                  .anyMatch(
                      ch ->
                          ch.getNodeName() != null
                              && ch.getNodeName().equalsIgnoreCase(nodeName)
                              && ch.getNodeChange() != null
                              && ch.getNodeChange()
                                  .getName()
                                  .equalsIgnoreCase(change.getNodeChange().getName()));
        }
      } else {
        List<NodeChange> nodeChanges =
            changes.stream()
                .map(Change::getNodeChange)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        if (!nodeChanges.isEmpty()) {
          // if rootLevel then nodeName is empty so check name for dups
          isDuplicate =
              nodeChanges.stream().anyMatch(ch -> ch.getName().equalsIgnoreCase(nodeName));
        }
      }

      if (isDuplicate) {
        throw new ConflictException(
            "Change with Node (" + nodeName + ") already exists.", Level.ERROR);
      }
    }
  }

  private boolean isNodePresentInChangeGroupNodeDtos(
      List<ChangeGroupNodeDto> changeGroupNodeDtos, String nodeName) {

    if (!changeGroupNodeDtos.isEmpty()) {
      boolean isFound = false;

      for (ChangeGroupNodeDto changeGroupNodeDto : changeGroupNodeDtos) {
        if (changeGroupNodeDto.getName().equalsIgnoreCase(nodeName)) {
          isFound = true;
        } else {
          if (changeGroupNodeDto.getChangeGroupNodeDto() != null
              && !changeGroupNodeDto.getChangeGroupNodeDto().isEmpty()) {
            isFound =
                isNodePresentInChangeGroupNodeDtos(
                    changeGroupNodeDto.getChangeGroupNodeDto(), nodeName);
          }
        }

        if (isFound) {
          break;
        }
      }

      return isFound;
    }

    return false;
  }

  private void splitChangeGroupIfIncompatibleBusOrComponent(
      List<ChangeGroupNodeDto> changeGroupNodeDtos, ChangeGroup changeGroup, Change change) {

    List<Aircraft> aircraftsInChangeGroup =
        changeGroup.getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .collect(Collectors.toList());

    // determine which node name to use
    String nodeName = getNodeNameFromChange(change);

    // cannot split if single ship in change group
    if (aircraftsInChangeGroup.size() > 1) {
      // get matching node
      ChangeGroupNodeDto changeGroupNodeDto =
          changeGroupNodeDtos.stream()
              .flatMap(ChangeGroupNodeDto::streamNodes)
              .filter(x -> x.getName().equals(nodeName))
              .findFirst()
              .orElse(null);
      boolean isGlobal = false;
      if (changeGroupNodeDto != null) {
        if (change.getNodeChange() != null || change.getAction() == ActionType.ADD) {
          isGlobal = changeGroupNodeDto.getIsGlobal();
        } else {
          List<ComponentDto> componentDtos = changeGroupNodeDto.getComponentDtos();
          if (componentDtos != null) {
            ComponentDto componentDto =
                componentDtos.stream()
                    .filter(c -> c.getElectIdent().equals(change.getComponentElectIdent()))
                    .findFirst()
                    .orElse(null);
            if (componentDto != null) {
              isGlobal = componentDto.getIsGlobal() == null ? true : componentDto.getIsGlobal();
            }
          }
        }
      }

      // if node/bus is not found on every effectivity then split
      if (changeGroupNodeDto != null && !isGlobal) {
        // get aircrafts for existing change group
        List<Aircraft> aircrafts =
            changeGroup.getAircraftChangeGroups().stream()
                .map(AircraftChangeGroup::getAircraft)
                .collect(Collectors.toList());
        List<Aircraft> aircraftsToChange = new ArrayList<>();

        // find matching ela
        for (Aircraft aircraft : aircrafts) {
          // only want latest Ela based on create date
          Optional<Ela> ela =
              aircraft.getElas().stream().max(Comparator.comparing(Ela::getCreatedDate));
          if (ela.isPresent()) {
            Optional<Node> matchingNode =
                ela.get().getNodes().stream()
                    .flatMap(Node::streamNodes)
                    .filter(x -> x.getName().equals(nodeName))
                    .findAny();
            if (matchingNode.isPresent()) {
              if (change.getComponentChange() != null && change.getAction() != ActionType.ADD) {
                Component matchingComponent =
                    matchingNode.get().getComponents().stream()
                        .filter(c -> c.getElectIdent().equals(change.getComponentElectIdent()))
                        .findFirst()
                        .orElse(null);
                if (matchingComponent != null) {
                  aircraftsToChange.add(aircraft);
                }
              } else {
                aircraftsToChange.add(aircraft);
              }
            }
          }
        }

        if (!aircraftsToChange.isEmpty()) {
          for (Aircraft aircraft : aircraftsToChange) {
            AircraftChangeGroup acg =
                changeGroup.getAircraftChangeGroups().stream()
                    .filter(x -> x.getAircraft().getId().equals(aircraft.getId()))
                    .findFirst()
                    .orElseThrow(
                        () -> new NotFoundException("Error finding Aircraft Change Group to move"));
            changeGroup.removeAircraftChangeGroup(acg);
          }

          String changeGroupName = changeGroup.getName();

          // db length is 127 for change_group.name
          // need to verify name length and truncate if beyond allotted amount so we can append
          // split verbiage to end and stay under 127 length
          List<ChangeGroup> changeGroups = changeGroup.getProject().getChangeGroups();

          // generate unique change group name
          changeGroupName = generateUniqueChangeGroupName(changeGroupName, changeGroups, 1);

          // create new ChangeGroup
          ChangeGroup changeGroupEntity = new ChangeGroup();
          changeGroupEntity.setProject(changeGroup.getProject());
          changeGroupEntity.setName(changeGroupName);
          ChangeGroup newChangeGroup =
              changeGroupService.save(changeGroupEntity, changeGroupEntity.getProject().getId());

          // Map aircraft(s) to new Change Group
          for (AircraftChangeGroup aircraftChangeGroup :
              convertAircraftToAircraftChangeGroup(aircraftsToChange, Collections.emptyList())) {
            newChangeGroup.addAircraftChangeGroup(aircraftChangeGroup);
          }

          // update Change Group reference for Change
          change.setChangeGroup(newChangeGroup);
        }
      }
    }
  }

  private String generateUniqueChangeGroupName(
      String changeGroupName, List<ChangeGroup> changeGroups, int idx) {
    // set new name
    String newChangeGroupName =
        changeGroupName.length() > 115
            ? changeGroupName.substring(0, 114)
            : changeGroupName + " (split " + idx + ")"; // 10-12 chars (1, 10, 100)

    boolean exists = false;

    if (!changeGroups.isEmpty()) {
      exists =
          changeGroups.stream().anyMatch(m -> m.getName().equalsIgnoreCase(newChangeGroupName));
    }

    if (exists) {
      return generateUniqueChangeGroupName(changeGroupName, changeGroups, idx + 1);
    }

    return newChangeGroupName;
  }

  private List<AircraftChangeGroup> convertAircraftToAircraftChangeGroup(
      List<Aircraft> aircrafts, List<Aircraft> aircraftsToChange) {
    List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();

    for (Aircraft aircraft : aircrafts) {
      Optional<Aircraft> potenitalMatch =
          aircraftsToChange.stream()
              .filter(f -> f.getAircraftShipNo().equalsIgnoreCase(aircraft.getAircraftShipNo()))
              .findFirst();

      if (!potenitalMatch.isPresent()) {
        AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
        aircraftChangeGroup.setAircraft(aircraft);
        aircraftChangeGroups.add(aircraftChangeGroup);
      }
    }

    return aircraftChangeGroups;
  }

  /**
   * Determine which NodeName to use based on ActionType
   *
   * @param change - Entity to compare against
   * @return String
   */
  private String getNodeNameFromChange(Change change) {
    // use change.nodeChange.name if EDIT | DELETE
    // use change.nodeName if ADD
    return change.getNodeChange() != null && !change.getAction().equals(ActionType.ADD)
        ? change.getNodeChange().getName()
        : change.getNodeName();
  }

  private void verifyChangeFlightPhaseAndOperatingMode(Change change, ChangeGroup changeGroup) {
    if (change.getComponentChange() != null) {
      // verify an aircraft exists in change group
      if (changeGroup == null || changeGroup.getAircraftChangeGroups().isEmpty()) {
        throw new NotFoundException(
            String.format(
                "Unable to locate an aircraft for Change Group %s",
                changeGroup == null ? "" : changeGroup.getName()),
            Level.ERROR);
      }

      // get aircraft manufacturer for first ship in CG
      Fleet fleet = changeGroup.getAircraftChangeGroups().get(0).getAircraft().getFleet();

      // iterate through component change Loads
      if (change.getComponentChange().getLoadChanges() != null) {
        for (LoadChange loadChange : change.getComponentChange().getLoadChanges()) {
          // check operating mode

          // verify operatingMode is not null or empty
          if (loadChange.getOperatingMode() == null || loadChange.getOperatingMode().isEmpty()) {
            throw new BadRequestException(
                "Operating Mode for Load within Component '"
                    + change.getComponentChange().getElectIdent()
                    + "' and Node '"
                    + change.getNodeName()
                    + "'"
                    + " is required (current value is NULL or empty)",
                Level.ERROR);
          }

          // force uppercase on value
          loadChange.setOperatingMode(loadChange.getOperatingMode().toUpperCase());
          boolean operatingModeMatch =
              fleet.getOperatingModes().stream()
                  .anyMatch(opMode -> opMode.equalsIgnoreCase(loadChange.getOperatingMode()));
          if (!operatingModeMatch) {
            throw new BadRequestException(
                "Load contains incompatible Operating Mode '"
                    + loadChange.getOperatingMode()
                    + "' for Component '"
                    + change.getComponentChange().getElectIdent()
                    + "' and Node '"
                    + change.getNodeName()
                    + "'",
                Level.ERROR);
          }

          // check flight mode

          // verify flightPhase is not null or empty
          if (loadChange.getFlightPhase() == null || loadChange.getFlightPhase().isEmpty()) {
            throw new BadRequestException(
                "Flight Phase for Load within Component '"
                    + change.getComponentChange().getElectIdent()
                    + "' and Node '"
                    + change.getNodeName()
                    + "'"
                    + " is required (current value is NULL or empty)",
                Level.ERROR);
          }

          // force uppercase on value
          loadChange.setFlightPhase(loadChange.getFlightPhase().toUpperCase());
          boolean flightPhaseMatch =
              fleet.getFlightPhases().stream()
                  .anyMatch(f -> f.getName().equalsIgnoreCase(loadChange.getFlightPhase()));
          if (!flightPhaseMatch) {
            throw new BadRequestException(
                "Load contains incompatible Flight Phase '"
                    + loadChange.getFlightPhase()
                    + "' for Component '"
                    + change.getComponentChange().getElectIdent()
                    + "' and Node '"
                    + change.getNodeName()
                    + "'",
                Level.ERROR);
          }
        }
      }
    }
  }

  private void verifyCompatibleVoltageAndVoltageType(
      List<ChangeGroupNodeDto> changeGroupNodeDtos, Change change) {
    // only check nodeChange not componentChange
    if (!changeGroupNodeDtos.isEmpty()
        && change.getNodeChange() != null
        && (change.getNodeName() != null && !change.getNodeName().isEmpty())) {

      ChangeGroupNodeDto matchingParentChangeGroupNodeDto =
          findMatchingActiveChangeGroupNodeDto(changeGroupNodeDtos, change.getNodeName());

      Double changeVoltage = change.getNodeChange().getVoltage();
      ElectricalPhase changeVoltageType = change.getNodeChange().getVoltageType();

      Double parentVoltage = matchingParentChangeGroupNodeDto.getVoltage();
      ElectricalPhase parentChangeVoltageType = matchingParentChangeGroupNodeDto.getVoltageType();

      NodeType changeNodeType = change.getNodeChange().getNodeType();
      NodeType parentNodeType = matchingParentChangeGroupNodeDto.getNodeType();

      // voltageType check
      checkValidVoltageType(
          changeNodeType, parentNodeType, changeVoltageType, parentChangeVoltageType);

      // voltage check
      checkValidVoltage(changeNodeType, parentNodeType, changeVoltage, parentVoltage);
    }
  }

  private ChangeGroupNodeDto findMatchingActiveChangeGroupNodeDto(
      List<ChangeGroupNodeDto> changeGroupNodeDtos, String nodeName) {
    return changeGroupNodeDtos.stream()
        .flatMap(ChangeGroupNodeDto::streamNodes)
        .filter(
            x ->
                x.getName().equals(nodeName)
                    && (x.getAction() == null || !x.getAction().equals(ActionType.DELETE)))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    "Matching Node Name '" + nodeName + "' not found.", Level.ERROR));
  }

  private void verifyChangeGroupChangeDoesNotContainNodeChangeWithSameNodeName(
      ChangeGroup changeGroup, NodeChange nodeChange) {
    Optional<Change> existingChanges =
        changeGroup.getChanges().stream()
            .filter(
                c ->
                    c.getNodeChange() != null
                        && c.getNodeChange().getName() != null
                        && c.getNodeChange().getName().equalsIgnoreCase(nodeChange.getName())
                        && !c.getNodeChange()
                            .getId()
                            .toString()
                            .equals(nodeChange.getId().toString())
                        && (c.getAction() == ActionType.ADD || c.getAction() == ActionType.EDIT))
            .findAny();
    if (existingChanges.isPresent()) {
      throw new ConflictException(
          "Cannot delete change since an existing nodeChange has the same name: "
              + nodeChange.getName(),
          Level.ERROR);
    }
  }

  private void verifyComponentIsUniqueByElectIdentAndElectricalPhase(
      List<ChangeGroupNodeDto> changeGroupNodeDtos, Change change) {
    // verify component change exists and action is ADD
    if (change.getComponentChange() != null && change.getAction().equals(ActionType.ADD)) {
      String electIdent = change.getComponentChange().getElectIdent();
      ElectricalPhase phase = change.getComponentChange().getElectricalPhase();

      ChangeGroupNodeDto changeGroupNodeDto =
          findMatchingActiveChangeGroupNodeDto(changeGroupNodeDtos, change.getNodeName());

      if (changeGroupNodeDto.getComponentDtos().stream()
          .anyMatch(
              componentDto ->
                  componentDto.getElectIdent().equalsIgnoreCase(electIdent)
                      && componentDto.getElectricalPhase() == phase)) {
        throw new ConflictException(
            "The node: "
                + change.getNodeName()
                + ", already has an existing component or component change with a similar electrical ident: "
                + electIdent
                + ", and phase: "
                + phase.toString(),
            Level.ERROR);
      }
    }
  }

  private void verifyNodeExists(List<ChangeGroupNodeDto> changeGroupNodeDtos, String nodeName) {
    boolean isNodePresent = isNodePresentInChangeGroupNodeDtos(changeGroupNodeDtos, nodeName);

    if (!isNodePresent) {
      throw new NotFoundException(
          "Node Name (" + nodeName + ") does not exist in this Change Group.", Level.ERROR);
    }
  }

  private void verifyComponentChangeDoesNotContainRelatedNodeChange(
      ChangeGroup changeGroup, String nodeName) {
    Optional<Change> parentNodeChange =
        changeGroup.getChanges().stream()
            .filter(
                c ->
                    c.getNodeChange() != null
                        && c.getNodeName() != null
                        && c.getNodeName().equals(nodeName)
                        && c.getAction() == ActionType.DELETE)
            .findAny();
    if (parentNodeChange.isPresent()) {
      throw new ConflictException(
          "Cannot delete component change until node change (" + nodeName + ") is deleted.",
          Level.ERROR);
    }
  }

  private void deleteRelatedComponentChanges(
      ChangeGroup changeGroup, String nodeName, ActionType action) {
    List<Change> relatedComponentChangesToDelete =
        changeGroup.getChanges().stream()
            .filter(
                change ->
                    change.getAction().equals(action)
                        && change.getComponentChange() != null
                        && change.getNodeName() != null
                        && change.getNodeName().equalsIgnoreCase(nodeName))
            .collect(Collectors.toList());

    // if any match then delete them
    if (!relatedComponentChangesToDelete.isEmpty()) {
      for (Change relatedComponentChangeToDelete : relatedComponentChangesToDelete) {
        changeGroup.removeChange(relatedComponentChangeToDelete);
        changeRepo.delete(relatedComponentChangeToDelete);
      }
    }
  }

  private ChangeGroup findChangeGroupByProjectAndChangeGroupId(UUID projectId, UUID changeGroupId) {
    Project project =
        projectService
            .findById(projectId)
            .orElseThrow(
                () -> new NotFoundException("Project (" + projectId + ") not found", Level.ERROR));

    return project.getChangeGroups().stream()
        .filter(changeGroup -> changeGroup.getId().equals(changeGroupId))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    "Change Group ("
                        + changeGroupId
                        + ") not found for Project: "
                        + project.getTitle()
                        + ".",
                    Level.ERROR));
  }

  private ChangeGroupNodeDto findNode(List<ChangeGroupNodeDto> changeGroupNodeDtos, String name) {
    return changeGroupNodeDtos.stream()
        .flatMap(ChangeGroupNodeDto::streamNodes)
        .filter(x -> x.getName().equals(name))
        .findFirst()
        .orElse(null);
  }

  private void throwVoltageException(
      NodeType changeNodeType, NodeType parentNodeType, Double voltage, Double parentVoltage) {
    StringBuilder sb = new StringBuilder();

    sb.append("Incompatible Voltage (" + voltage + ") ");
    sb.append("for Node Type (" + changeNodeType + ") ");
    sb.append("based on parent Node Type (" + parentNodeType + ") ");
    sb.append("and Voltage (" + parentVoltage + ")");

    throw new ConflictException(sb.toString(), Level.ERROR);
  }

  private void throwVoltageTypeException(
      NodeType nodeType,
      NodeType parentNodeType,
      ElectricalPhase voltageType,
      ElectricalPhase parentVoltageType) {
    StringBuilder sb = new StringBuilder();

    sb.append("Incompatible Voltage Type (" + voltageType + ") ");
    sb.append("for Node Type (" + nodeType + ")");
    if (parentNodeType != null) {
      sb.append(" based on parent Node Type (" + parentNodeType + ")");
    }
    if (parentVoltageType != null) {
      sb.append(" and Voltage Type (" + parentVoltageType + ")");
    }

    throw new ConflictException(sb.toString(), Level.ERROR);
  }

  private void checkValidVoltage(
      NodeType changeNodeType,
      NodeType parentNodeType,
      Double changeVoltage,
      Double parentVoltage) {
    if (changeNodeType.equals(NodeType.BUS)
        && Arrays.asList(NodeType.ATU, NodeType.TRU).contains(parentNodeType)) {
      // skip voltage check per business rules
    } else {
      if (FieldValidator.isDoublesChanged(changeVoltage, parentVoltage)) {
        throwVoltageException(changeNodeType, parentNodeType, changeVoltage, parentVoltage);
      }
    }
  }

  private void checkValidVoltageType(
      NodeType changeNodeType,
      NodeType parentNodeType,
      ElectricalPhase changeVoltageType,
      ElectricalPhase parentChangeVoltageType) {
    // business rule: if change is ATU nodeType then verify AC voltageType
    if (changeNodeType.equals(NodeType.ATU)) {
      if (!changeVoltageType.equals(ElectricalPhase.AC)) {
        throwVoltageTypeException(changeNodeType, null, changeVoltageType, null);
      }
    }

    // business rule: if change is TRU nodeType then verify AC3 voltageType
    else if (changeNodeType.equals(NodeType.TRU)) {
      if (!changeVoltageType.equals(ElectricalPhase.AC3)) {
        throwVoltageTypeException(changeNodeType, null, changeVoltageType, null);
      }
    }

    // business rule: if change is BUS nodeType then
    // verify it conforms to proper voltageType rules
    else if (changeNodeType.equals(NodeType.BUS)) {
      // ATU check (if parentNode NodeType is ATU then child has to be AC)
      if (parentNodeType.equals(NodeType.ATU)) {
        if (!changeVoltageType.equals(ElectricalPhase.AC)) {
          throwVoltageTypeException(
              changeNodeType, parentNodeType, changeVoltageType, parentChangeVoltageType);
        }
      }

      // TRU check (if parent NodeType is TRU then child has to be DC)
      else if (parentNodeType.equals(NodeType.TRU)) {
        if (!changeVoltageType.equals(ElectricalPhase.DC)) {
          throwVoltageTypeException(
              changeNodeType, parentNodeType, changeVoltageType, parentChangeVoltageType);
        }
      }

      // not ATU or TRU parent nodeType
      else {
        // voltageType values must match between parent/child
        if (!changeVoltageType.equals(parentChangeVoltageType)) {
          throwVoltageTypeException(
              changeNodeType, parentNodeType, changeVoltageType, parentChangeVoltageType);
        }
      }
    }

    // not ATU, TRU, or BUS nodeType
    else {
      // voltageType values must match between parent/child
      if (!changeVoltageType.equals(parentChangeVoltageType)) {
        throwVoltageTypeException(
            changeNodeType, parentNodeType, changeVoltageType, parentChangeVoltageType);
      }
    }
  }
}
