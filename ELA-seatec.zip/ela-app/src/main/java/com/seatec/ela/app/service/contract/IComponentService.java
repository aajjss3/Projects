package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import java.util.List;

/** Service for dealing with Components. */
public interface IComponentService {
  List<Component> findByNodeIds(List<Long> nodeId);

  Component getComponentByElectIdentAndPhase(
      Node node, String electIdent, ElectricalPhase electricalPhase);

  Load getLoadByOperatingModeAndFlightPhase(
      Component component, String operatingMode, String flightPhase);

  void delete(Component component);
}
