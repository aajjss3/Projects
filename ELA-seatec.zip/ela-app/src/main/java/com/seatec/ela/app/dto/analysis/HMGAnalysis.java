package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class HMGAnalysis implements Serializable {
  private static final long serialVersionUID = 1L;

  // DC Values
  private double dcTotalLoadAmps;
  private double dcCapacityAmps;
  private double dcPercentCapacity;

  // AC Values
  private double acTotalLoadKVA;
  private double acCapacityKVA;
  private double acPercentCapacity;

  // AC Phase Values
  private double aPhaseKVA;
  private double aPhasePf;
  private double bPhaseKVA;
  private double bPhasePf;
  private double cPhaseKVA;
  private double cPhasePf;
  private double avgPhaseKVA;
  private double avgPhasePf;

  // Status
  private AnalysisStatus dcStatus;
  private AnalysisStatus acStatus;

  public double getDcTotalLoadAmps() {
    return dcTotalLoadAmps;
  }

  public void setDcTotalLoadAmps(double dcTotalLoadAmps) {
    this.dcTotalLoadAmps = dcTotalLoadAmps;
  }

  public double getDcCapacityAmps() {
    return dcCapacityAmps;
  }

  public void setDcCapacityAmps(double dcCapacityAmps) {
    this.dcCapacityAmps = dcCapacityAmps;
  }

  public double getAcTotalLoadKVA() {
    return acTotalLoadKVA;
  }

  public void setAcTotalLoadKVA(double acTotalLoadKVA) {
    this.acTotalLoadKVA = acTotalLoadKVA;
  }

  public double getAcCapacityKVA() {
    return acCapacityKVA;
  }

  public void setAcCapacityKVA(double acCapacityKVA) {
    this.acCapacityKVA = acCapacityKVA;
  }

  public double getaPhaseKVA() {
    return aPhaseKVA;
  }

  public void setaPhaseKVA(double aPhaseKVA) {
    this.aPhaseKVA = aPhaseKVA;
  }

  public double getaPhasePf() {
    return aPhasePf;
  }

  public void setaPhasePf(double aPhasePf) {
    this.aPhasePf = aPhasePf;
  }

  public double getbPhaseKVA() {
    return bPhaseKVA;
  }

  public void setbPhaseKVA(double bPhaseKVA) {
    this.bPhaseKVA = bPhaseKVA;
  }

  public double getbPhasePf() {
    return bPhasePf;
  }

  public void setbPhasePf(double bPhasePf) {
    this.bPhasePf = bPhasePf;
  }

  public double getcPhaseKVA() {
    return cPhaseKVA;
  }

  public void setcPhaseKVA(double cPhaseKVA) {
    this.cPhaseKVA = cPhaseKVA;
  }

  public double getcPhasePf() {
    return cPhasePf;
  }

  public void setcPhasePf(double cPhasePf) {
    this.cPhasePf = cPhasePf;
  }

  public double getAvgPhaseKVA() {
    return avgPhaseKVA;
  }

  public void setAvgPhaseKVA(double avgPhaseKVA) {
    this.avgPhaseKVA = avgPhaseKVA;
  }

  public double getAvgPhasePf() {
    return avgPhasePf;
  }

  public void setAvgPhasePf(double avgPhasePf) {
    this.avgPhasePf = avgPhasePf;
  }

  public AnalysisStatus getDcStatus() {
    return dcStatus;
  }

  public void setDcStatus(AnalysisStatus dcStatus) {
    this.dcStatus = dcStatus;
  }

  public AnalysisStatus getAcStatus() {
    return acStatus;
  }

  public void setAcStatus(AnalysisStatus acStatus) {
    this.acStatus = acStatus;
  }

  public double getDcPercentCapacity() {
    return dcPercentCapacity;
  }

  public void setDcPercentCapacity(double dcPercentCapacity) {
    this.dcPercentCapacity = dcPercentCapacity;
  }

  public double getAcPercentCapacity() {
    return acPercentCapacity;
  }

  public void setAcPercentCapacity(double acPercentCapacity) {
    this.acPercentCapacity = acPercentCapacity;
  }
}
