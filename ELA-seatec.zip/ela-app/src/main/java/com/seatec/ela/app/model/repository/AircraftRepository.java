package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.Aircraft;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AircraftRepository extends CrudRepository<Aircraft, Long> {

  List<Aircraft> findByIdIn(List<Long> ids);

  List<Aircraft> findAllByOrderByAircraftShipNoAsc();

  List<Aircraft> findAllByCloakedFalseAndArchivedFalseOrderByAircraftShipNoAsc();

  List<Aircraft> findAllByCloakedFalseOrderByAircraftShipNoAsc();

  Aircraft findFirstByOrderByIdDesc();

  List<Aircraft> findByAircraftShipNo(String aircraftShipNo);

  List<Aircraft> findByCloakedFalseAndArchivedFalseAndAircraftShipNo(String aircraftShipNo);

  List<Aircraft> findByCloakedFalseAndAircraftShipNo(String aircraftShipNo);

  List<Aircraft> findAllByFleet_Name(String name);

  List<Aircraft> findAllByCloakedTrueOrderByAircraftShipNoAsc();

  List<Aircraft> findAllByCloakedTrueAndAircraftShipNo(String aircraftShipNo);
}
