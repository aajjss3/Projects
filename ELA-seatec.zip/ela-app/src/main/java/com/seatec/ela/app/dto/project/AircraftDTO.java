package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdLong;
import com.seatec.ela.app.aop.userevent.UserTrackShipNo;

public class AircraftDTO implements UserTrackIdLong, UserTrackShipNo {

  private Long id;

  private String aircraftShipNo;

  private String serialNumber;

  private String registrationNumber;

  private String lineNumber;

  private String variableNumber;

  private String origWorkbookFilename;

  private String origWorkBookchecksum;

  private boolean archived;

  public String getAircraftShipNo() {
    return aircraftShipNo;
  }

  public void setAircraftShipNo(String aircraftShipNo) {
    this.aircraftShipNo = aircraftShipNo;
  }

  public String getSerialNumber() {
    return serialNumber;
  }

  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public String getRegistrationNumber() {
    return registrationNumber;
  }

  public void setRegistrationNumber(String registrationNumber) {
    this.registrationNumber = registrationNumber;
  }

  public String getLineNumber() {
    return lineNumber;
  }

  public void setLineNumber(String lineNumber) {
    this.lineNumber = lineNumber;
  }

  public String getVariableNumber() {
    return variableNumber;
  }

  public void setVariableNumber(String variableNumber) {
    this.variableNumber = variableNumber;
  }

  public String getOrigWorkbookFilename() {
    return origWorkbookFilename;
  }

  public void setOrigWorkbookFilename(String origWorkbookFilename) {
    this.origWorkbookFilename = origWorkbookFilename;
  }

  public String getOrigWorkBookchecksum() {
    return origWorkBookchecksum;
  }

  public void setOrigWorkBookchecksum(String origWorkBookchecksum) {
    this.origWorkBookchecksum = origWorkBookchecksum;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }
}
