package com.seatec.ela.app.util.enumeration;

public enum QueryOperation {
  LIKE,
  EQUAL,
  NOT_NULL,
  IN
}
