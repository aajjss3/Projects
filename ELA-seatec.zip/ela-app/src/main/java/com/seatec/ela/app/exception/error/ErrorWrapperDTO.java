package com.seatec.ela.app.exception.error;

import java.util.ArrayList;
import java.util.List;

public class ErrorWrapperDTO {

  private List<ErrorDTO> errors = new ArrayList<ErrorDTO>();

  public ErrorWrapperDTO() {}

  public ErrorWrapperDTO(List<ErrorDTO> errors) {
    super();
    this.errors.addAll(errors);
  }

  public ErrorWrapperDTO(ErrorDTO error) {
    super();
    this.errors.add(error);
  }

  public List<ErrorDTO> getErrors() {
    return errors;
  }

  public void setErrors(List<ErrorDTO> errors) {
    this.errors = errors;
  }
}
