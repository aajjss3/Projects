package com.seatec.ela.app.dto;

import java.util.List;

public class AutoLandFleetConfigDto {
  private final String fleetPrefix;

  // AutoLand Analysis Nodes
  // DC nodes used in the analysis
  private final List<String> nodeNames;

  // AC nodes used to get the DC equivalent total load for the static inverter
  private final List<String> nodeNamesInverterCalculations;

  private final Double deratedDCVoltageInVoltsBatteryCharger;

  private final Double deratedDCVoltageInVoltsBatteryOnly;
  private final Double powerEfficiencyInverter;
  private final String inverterNodeName;

  private final LoadFiltersDto loadFilters;
  private final SummarizedLoadFiltersDto summarizedLoadFilters;

  public AutoLandFleetConfigDto(
      String fleetPrefix,
      List<String> nodeNames,
      List<String> nodeNamesInverterCalculations,
      Double deratedDCVoltageInVoltsBatteryCharger,
      Double deratedDCVoltageInVoltsBatteryOnly,
      Double powerEfficiencyInverter,
      String inverterNodeName,
      LoadFiltersDto loadFilters,
      SummarizedLoadFiltersDto summarizedLoadFilters) {
    this.fleetPrefix = fleetPrefix;
    this.nodeNames = nodeNames;
    this.nodeNamesInverterCalculations = nodeNamesInverterCalculations;
    this.deratedDCVoltageInVoltsBatteryCharger = deratedDCVoltageInVoltsBatteryCharger;
    this.deratedDCVoltageInVoltsBatteryOnly = deratedDCVoltageInVoltsBatteryOnly;
    this.powerEfficiencyInverter = powerEfficiencyInverter;
    this.inverterNodeName = inverterNodeName;
    this.loadFilters = loadFilters;
    this.summarizedLoadFilters = summarizedLoadFilters;
  }

  public String getFleetPrefix() {
    return fleetPrefix;
  }

  public List<String> getNodeNames() {
    return nodeNames;
  }

  public List<String> getNodeNamesInverterCalculations() {
    return nodeNamesInverterCalculations;
  }

  public Double getDeratedDCVoltageInVoltsBatteryCharger() {
    return deratedDCVoltageInVoltsBatteryCharger;
  }

  public Double getDeratedDCVoltageInVoltsBatteryOnly() {
    return deratedDCVoltageInVoltsBatteryOnly;
  }

  public Double getPowerEfficiencyInverter() {
    return powerEfficiencyInverter;
  }

  public String getInverterNodeName() {
    return inverterNodeName;
  }

  public LoadFiltersDto getLoadFilters() {
    return loadFilters;
  }

  public SummarizedLoadFiltersDto getSummarizedLoadFilters() {
    return summarizedLoadFilters;
  }
}
