package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.FleetNameDTO;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.service.contract.IFleetService;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ServerErrorException;

@Service
public class FleetService implements IFleetService {

  @Autowired private IAircraftService aircraftService;

  @Autowired private FleetRepository repository;

  @Autowired private KeycloakService keycloakService;

  @Override
  public List<Fleet> findAll(
      boolean hasEla,
      boolean includeCloaked,
      boolean includeArchived,
      String aircraftShipNo,
      String userId) {
    List<Fleet> fleets;
    if (StringUtils.isEmpty(aircraftShipNo)) {
      fleets = repository.findByParentFleetNullOrderByName();
    } else {
      List<Aircraft> aircraft = aircraftService.findByAircraftShipNo(aircraftShipNo, userId);
      fleets =
          aircraft.isEmpty() ? Collections.emptyList() : Arrays.asList(aircraft.get(0).getFleet());
    }

    // only include Aircrafts that contain an Ela
    if (hasEla) {
      removeAircraftsWithoutEla(fleets);
    }

    boolean removeCloaked = false;
    boolean removeArchived = false;
    if (!includeCloaked
        || !keycloakService.isUserAndInRole(userId, KeycloakRole.IT_ADMIN.getName())) {
      removeCloaked = true;
    }

    if (!includeArchived
        || !keycloakService.isUserValidAndInRoles(
            userId,
            Arrays.asList(
                KeycloakRole.ENGINEERING_ADMIN.getName(), KeycloakRole.IT_ADMIN.getName()))) {
      removeArchived = true;
    }
    if (removeCloaked || removeArchived) {
      filterAircrafts(fleets, removeArchived, removeCloaked);
    }

    return fleets;
  }

  @Override
  public List<Fleet> findByName(String name) {
    return repository.findByName(name);
  }

  @Override
  public Optional<Fleet> findById(Long id) {
    return repository.findById(id);
  }

  @Override
  @Transactional
  public Fleet create(Fleet fleet, Long parentId) {
    fleet.setId(null);
    return processSave(fleet, parentId);
  }

  @Override
  @Transactional
  public Fleet update(Fleet entity, Long parentId) {
    if (entity.getId() == null) {
      throw new BadRequestException("Fleet Resource invalid Id");
    }
    Fleet fleet =
        repository
            .findById(entity.getId())
            .orElseThrow(
                () ->
                    new BadRequestException("Fleet Resource id " + entity.getId() + " not found"));
    fleet.setName(entity.getName());
    fleet.setManufacturer(entity.getManufacturer());
    fleet.setBusStructureBucket(entity.getBusStructureBucket());
    fleet.setStructureName(entity.getStructureName());
    fleet.setArchived(entity.isArchived());
    return processSave(fleet, parentId);
  }

  @Override
  @Transactional
  public void deleteById(Long id) {
    Optional<Fleet> entity = repository.findById(id);
    if (entity.isPresent()) {
      Fleet fleet = entity.get();
      if (fleet.getAircraft().size() == 0 && fleet.getSubFleets().size() == 0) {
        repository.deleteById(id);
      } else {
        throw new BadRequestException("Aircraft and SubFleet must be zero");
      }
    } else {
      throw new ServerErrorException(
          "No class com.seatec.ela.app.model.Fleet entity with id " + id + " exists!");
    }
  }

  @Transactional(readOnly = true)
  public List<FleetNameDTO> getFleetNames() {
    List<FleetNameDTO> allFleets = repository.getFleetNames();

    List<FleetNameDTO> subFleets =
        allFleets.stream()
            .filter(fleet -> fleet.getParentId() != null)
            .collect(Collectors.toList());
    for (FleetNameDTO subFleet : subFleets) {
      allFleets.stream()
          .filter(fleet -> fleet.getId().equals(subFleet.getParentId()))
          .findFirst()
          .get()
          .addSubFleet(subFleet);
    }

    return allFleets.stream()
        .filter(fleet -> fleet.getParentId() == null)
        .sorted((f1, f2) -> f1.getName().compareTo(f2.getName()))
        .collect(Collectors.toList());
  }

  private void removeAircraftsWithoutEla(List<Fleet> fleets) {
    for (Fleet fleet : fleets) {
      SortedSet<Aircraft> aircraftsToKeep = new TreeSet<>();
      SortedSet<Aircraft> aircrafts = fleet.getAircraft();

      if (!fleet.getSubFleets().isEmpty()) {
        removeAircraftsWithoutEla(fleet.getSubFleets());
      }

      for (Aircraft aircraft : aircrafts) {
        if (!aircraft.getElas().isEmpty()) {
          aircraftsToKeep.add(aircraft);
        }
      }
      fleet.setAircraft(aircraftsToKeep);
    }
  }

  private void filterAircrafts(List<Fleet> fleets, boolean removeArchived, boolean removeCloaked) {
    for (Fleet fleet : fleets) {
      SortedSet<Aircraft> aircraftsToKeep = new TreeSet<>();
      SortedSet<Aircraft> aircrafts = fleet.getAircraft();

      if (!fleet.getSubFleets().isEmpty()) {
        filterAircrafts(fleet.getSubFleets(), removeArchived, removeCloaked);
      }

      for (Aircraft aircraft : aircrafts) {
        if (removeCloaked && aircraft.isCloaked()) {
          continue;
        }
        if (removeArchived && aircraft.isArchived()) {
          continue;
        }
        aircraftsToKeep.add(aircraft);
      }
      fleet.setAircraft(aircraftsToKeep);
    }
  }

  private Fleet processSave(Fleet fleet, Long parentId)
      throws BadRequestException, ConflictException {
    if (parentId == null) {
      return repository.save(fleet);
    }
    Optional<Fleet> parent = repository.findById(parentId);
    if (parent.isPresent()) {
      fleet.setParentFleet(parent.get());
      return repository.save(fleet);
    } else {
      throw new BadRequestException("Parent Id not valid");
    }
  }
}
