package com.seatec.ela.app.util.enumeration;

public enum ProjectStatus {
  STARTED,
  SUBMITTED,
  CHECKED,
  APPROVED,
  RETIRED,
  CHECKER_REJECTED,
  APPROVER_REJECTED;
}
