package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.Node;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface NodeRepository extends CrudRepository<Node, Long> {

  @Query(
      nativeQuery = true,
      value =
          "WITH RECURSIVE nodetree AS "
              + "(SELECT id, name, voltage, nominal_power, display_order, node_id, ela_id, node_type, requires_approval, bus_rating, voltage_type, sheddable, efficiency_table_id, description, normal_tr, electrical_phase "
              + "FROM node n "
              + "WHERE node_id IS NULL AND ela_id = :elaId "
              + "UNION ALL "
              + "SELECT ni.id, ni.name, ni.voltage, ni.nominal_power, ni.display_order, ni.node_id, ni.ela_id, ni.node_type, ni.requires_approval, ni.bus_rating, ni.voltage_type, ni.sheddable, ni.efficiency_table_id, ni.description, ni.normal_tr, ni.electrical_phase "
              + "FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id) "
              + ") "
              + "SELECT * FROM nodetree")
  List<Node> getNodesInEla(@Param("elaId") Long elaId);

  List<Node> findByIdIn(Collection<Long> ids);
}
