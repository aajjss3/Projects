package com.seatec.ela.app.validator.annotation;

import com.seatec.ela.app.model.project.Project;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

@Target(ElementType.TYPE)
@Constraint(validatedBy = ValidateProjectDifferentApprovalChecker.Validator.class)
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidateProjectDifferentApprovalChecker {
  String message() default "Approval Engineer and Checker Engineer must be different";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  class Validator implements ConstraintValidator<ValidateProjectDifferentApprovalChecker, Project> {

    @Override
    public boolean isValid(Project project, ConstraintValidatorContext constraintValidatorContext) {
      // currently, the approval engineer can be null so we'll just treat this case
      // as valid.  By extension, when the check engineer is also null thus technically being
      // "equal"
      // doesn't really make sense for this validator to flag so we don't fail either scenario.
      if (project.getApprovalEngineer() == null) {
        return true;
      }
      return !project.getApprovalEngineer().equals(project.getCheckEngineer());
    }
  }
}
