package com.seatec.ela.app.model.structure;

import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.base.BaseEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "node_structure")
public class NodeStructure extends BaseEntity {

  @Column(nullable = false, name = "structure_name")
  private String structureName;

  @Column(nullable = false, name = "node_name")
  private String nodeName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "node_id", insertable = true, updatable = false, nullable = true)
  private NodeStructure parentNodeStructure;

  @OneToMany(fetch = FetchType.LAZY, mappedBy = "parentNodeStructure", cascade = CascadeType.ALL)
  @OrderBy("displayOrder ASC")
  private List<NodeStructure> subNodeStructure = new ArrayList<>();

  @Column(name = "display_order")
  private Integer displayOrder;

  @Enumerated(EnumType.STRING)
  @Column(name = "node_type")
  private NodeType nodeType;

  @Enumerated(EnumType.STRING)
  @Column(name = "voltage_type")
  private VoltageType voltageType;

  @Enumerated(EnumType.STRING)
  @Column(name = "electrical_phase", nullable = false)
  private ElectricalPhase electricalPhase;

  @Column(name = "three_phase")
  private boolean threePhase;

  @Column(name = "voltage")
  private Double voltage;

  @Column(name = "bus_rating_va")
  private String busRatingVA;

  @Column(name = "bus_rating_amp")
  private String busRatingAmp;

  @Column(name = "requires_approval")
  private boolean requiresApproval;

  @Column(name = "sheddable")
  private boolean sheddable;

  @Column(name = "optional")
  private boolean optional;

  @Column(name = "efficiency_table_name")
  private String efficiencyTableName;

  @Column(name = "normal_tr", nullable = false)
  @ColumnDefault("false")
  private boolean normalTr;

  public String getStructureName() {
    return structureName;
  }

  public void setStructureName(String structureName) {
    this.structureName = structureName;
  }

  public String getNodeName() {
    return nodeName;
  }

  public void setNodeName(String nodeName) {
    this.nodeName = nodeName;
  }

  public NodeStructure getParentNodeStructure() {
    return parentNodeStructure;
  }

  public void setParentNodeStructure(NodeStructure parentNodeStructure) {
    this.parentNodeStructure = parentNodeStructure;
  }

  public List<NodeStructure> getSubNodeStructure() {
    return subNodeStructure;
  }

  public void setSubNodeStructure(List<NodeStructure> subNodeStructure) {
    this.subNodeStructure = subNodeStructure;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public VoltageType getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(VoltageType voltageType) {
    this.voltageType = voltageType;
  }

  public boolean isThreePhase() {
    return threePhase;
  }

  public void setThreePhase(boolean threePhase) {
    this.threePhase = threePhase;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public String getBusRatingVA() {
    return busRatingVA;
  }

  public void setBusRatingVA(String busRatingVA) {
    this.busRatingVA = busRatingVA;
  }

  public String getBusRatingAmp() {
    return busRatingAmp;
  }

  public void setBusRatingAmp(String busRatingAmp) {
    this.busRatingAmp = busRatingAmp;
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public boolean isOptional() {
    return optional;
  }

  public void setOptional(boolean optional) {
    this.optional = optional;
  }

  public String getEfficiencyTableName() {
    return efficiencyTableName;
  }

  public void setEfficiencyTableName(String efficiencyTableName) {
    this.efficiencyTableName = efficiencyTableName;
  }

  public boolean isNormalTr() {
    return normalTr;
  }

  public void setNormalTr(boolean normalTr) {
    this.normalTr = normalTr;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NodeStructure nodeStructure = (NodeStructure) o;
    return Objects.equals(id, nodeStructure.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  public Stream<NodeStructure> streamNodeStructures() {
    return Stream.concat(
        Stream.of(this), subNodeStructure.stream().flatMap(NodeStructure::streamNodeStructures));
  }

  public String[] getBusRatingAmps() {
    if (busRatingAmp != null) {
      return busRatingAmp.split("-|\\s+");
    } else return null;
  }

  public String[] getBusRatingVAs() {
    if (busRatingVA != null) {
      return busRatingVA.split("-|\\s+");
    } else return null;
  }
}
