package com.seatec.ela.app.service.contract.project.change.history;

import com.seatec.ela.app.dto.project.ChangeGroupDTO;
import com.seatec.ela.app.dto.project.change.history.ChangeHistoryDTO;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.change.Change;
import java.util.List;

/** Service for dealing with Project > ChangeGroup > Change > ChangeHistory */
public interface IChangeHistoryService {
  List<ChangeHistoryDTO> findAllByChangeGroupDTO(ChangeGroupDTO changeGroupDTO, boolean isApproved);

  void saveOriginalNodeValues(Change change, Ela ela, Node node);

  void saveOriginalComponentValues(Change change, Ela ela, Component component);
}
