package com.seatec.ela.app.dto.project.change.history;

import com.seatec.ela.app.model.project.change.history.ComponentChangeHistory;
import com.seatec.ela.app.model.project.change.history.LoadChangeHistory;
import com.seatec.ela.app.model.project.change.history.NodeChangeHistory;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ChangeHistoryDTO {

  private UUID changeId;

  private List<NodeChangeHistory> nodeChanges = new ArrayList<>();

  private List<ComponentChangeHistory> componentChanges = new ArrayList<>();

  private List<LoadChangeHistory> loadChanges = new ArrayList<>();

  public ChangeHistoryDTO() {}

  public ChangeHistoryDTO(UUID changeId) {
    this.changeId = changeId;
  }

  public ChangeHistoryDTO(
      UUID changeId,
      List<NodeChangeHistory> nodeChangeHistories,
      List<ComponentChangeHistory> componentChangeHistories,
      List<LoadChangeHistory> loadChangeHistories) {
    this.changeId = changeId;
    this.nodeChanges = nodeChangeHistories;
    this.componentChanges = componentChangeHistories;
    this.loadChanges = loadChangeHistories;
  }

  public UUID getChangeId() {
    return changeId;
  }

  public void setChangeId(UUID changeId) {
    this.changeId = changeId;
  }

  public List<ComponentChangeHistory> getComponentChanges() {
    return componentChanges;
  }

  public void setComponentChanges(List<ComponentChangeHistory> componentChanges) {
    this.componentChanges = componentChanges;
  }

  public List<LoadChangeHistory> getLoadChanges() {
    return loadChanges;
  }

  public void setLoadChanges(List<LoadChangeHistory> loadChanges) {
    this.loadChanges = loadChanges;
  }

  public List<NodeChangeHistory> getNodeChanges() {
    return nodeChanges;
  }

  public void setNodeChanges(List<NodeChangeHistory> nodeChanges) {
    this.nodeChanges = nodeChanges;
  }
}
