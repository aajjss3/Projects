package com.seatec.ela.app.dto.analysis;

import java.io.Serializable;

public class FuelJettisonLoad implements Serializable {

  private String flightPhase;
  private Double loadWithJettison;
  private Double loadWithoutJettison;
  private Double percentageWithJettison;
  private Double percentageWithoutJettison;

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public Double getLoadWithJettison() {
    return loadWithJettison;
  }

  public void setLoadWithJettison(Double loadWithJettison) {
    this.loadWithJettison = loadWithJettison;
  }

  public Double getLoadWithoutJettison() {
    return loadWithoutJettison;
  }

  public void setLoadWithoutJettison(Double loadWithoutJettison) {
    this.loadWithoutJettison = loadWithoutJettison;
  }

  public Double getPercentageWithJettison() {
    return percentageWithJettison;
  }

  public void setPercentageWithJettison(Double percentageWithJettison) {
    this.percentageWithJettison = percentageWithJettison;
  }

  public Double getPercentageWithoutJettison() {
    return percentageWithoutJettison;
  }

  public void setPercentageWithoutJettison(Double percentageWithoutJettison) {
    this.percentageWithoutJettison = percentageWithoutJettison;
  }
}
