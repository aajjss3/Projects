package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackAircraftIdLong;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.aop.userevent.UserTrackedCloneAircraftIdLong;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ElaCreationDto
    implements UserTrackName, UserTrackAircraftIdLong, UserTrackedCloneAircraftIdLong {
  @NotEmpty(message = "{field.required}")
  String name;

  @NotNull(message = "{field.required}")
  Long aircraftId;

  Long cloneAircraftId;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Long getAircraftId() {
    return aircraftId;
  }

  public void setAircraftId(Long aircraftId) {
    this.aircraftId = aircraftId;
  }

  public Long getCloneAircraftId() {
    return cloneAircraftId;
  }

  public void setCloneAircraftId(Long cloneAircraftId) {
    this.cloneAircraftId = cloneAircraftId;
  }
}
