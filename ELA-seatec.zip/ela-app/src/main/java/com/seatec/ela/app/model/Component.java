package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "component")
@JsonView({View.SummaryView.class, View.NodeSummaryView.class})
public class Component implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @Column(name = "name")
  private String name;

  @Column(name = "ata")
  private String ata;

  @Column(name = "display_order")
  private Integer displayOrder;

  @Column(name = "clipsed")
  private Boolean clipsed;

  @Column(name = "sheddable")
  private Boolean sheddable;

  @Column(name = "elect_ident")
  private String electIdent;

  @Column(name = "panel")
  private String panel;

  @Column(name = "nominal_power")
  private Double nominalPower;

  @Enumerated(EnumType.STRING)
  @Column(name = "electrical_phase", nullable = false)
  private ElectricalPhase electricalPhase;

  @Column(name = "intermittent")
  private Boolean intermittent;

  @Column(name = "connected_load_va")
  private Double connectedLoadVa;

  @Column(name = "connected_load_pf")
  private Double connectedLoadPf;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "node_id", nullable = false)
  @JsonIgnore
  private Node node;

  @OneToMany(mappedBy = "component", cascade = CascadeType.ALL, orphanRemoval = true)
  @JsonView(View.NodeSummaryView.class)
  private List<Load> loads = new ArrayList<>();

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAta() {
    return ata;
  }

  public void setAta(String ata) {
    this.ata = ata;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Boolean getClipsed() {
    return clipsed;
  }

  public void setClipsed(Boolean clipsed) {
    this.clipsed = clipsed;
  }

  public Boolean getSheddable() {
    return sheddable;
  }

  public void setSheddable(Boolean sheddable) {
    this.sheddable = sheddable;
  }

  public String getElectIdent() {
    return electIdent;
  }

  public void setElectIdent(String electIdent) {
    this.electIdent = electIdent;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public Boolean getIntermittent() {
    return intermittent;
  }

  public void setIntermittent(Boolean intermittent) {
    this.intermittent = intermittent;
  }

  public Double getConnectedLoadVa() {
    return connectedLoadVa;
  }

  public void setConnectedLoadVa(Double connectedLoadVa) {
    this.connectedLoadVa = connectedLoadVa;
  }

  public Double getConnectedLoadPf() {
    return connectedLoadPf;
  }

  public void setConnectedLoadPf(Double connectedLoadPf) {
    this.connectedLoadPf = connectedLoadPf;
  }

  public List<Load> getLoads() {
    return loads;
  }

  public void setLoads(List<Load> loads) {
    this.loads = loads;
  }

  public void addLoad(Load load) {
    this.loads.add(load);
    load.setComponent(this);
  }

  public void removeLoad(Load load) {
    this.loads.remove(load);
    load.setComponent(this);
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public Node getNode() {
    return node;
  }

  public void setNode(Node node) {
    this.node = node;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Component component = (Component) o;
    return id == component.id;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  public Component shallowCopy() {
    Component copy = new Component();
    copy.setNode(getNode());
    copy.setElectricalPhase(getElectricalPhase());
    copy.setDisplayOrder(getDisplayOrder());
    copy.setIntermittent(getIntermittent());
    copy.setSheddable(getSheddable());
    copy.setPanel(getPanel());
    copy.setName(getName());
    copy.setElectIdent(getElectIdent());
    copy.setAta(getAta());
    copy.setClipsed(getClipsed());
    copy.setId(getId());
    copy.setNominalPower(getNominalPower());
    copy.setConnectedLoadVa(getConnectedLoadVa());
    copy.setConnectedLoadPf(getConnectedLoadPf());
    return copy;
  }

  public Component clone() {
    Component newComponent = shallowCopy();
    newComponent.setNode(null);
    newComponent.setId(0);
    for (Load load : this.getLoads()) {
      Load newLoad = load.clone();
      newComponent.addLoad(newLoad);
    }
    return newComponent;
  }
}
