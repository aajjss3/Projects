package com.seatec.ela.app.service.contract;

import java.util.List;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;

/** Service for dealing with Keycloak Admin REST API. */
public interface IKeycloakExternalService {

  List<UserRepresentation> findAllUsers();

  UserRepresentation findUser(String id);

  RoleRepresentation getRoleByName(String roleName);

  void createUser(UserRepresentation user);

  void updateUser(UserRepresentation user);

  List<String> findAllRoles();
}
