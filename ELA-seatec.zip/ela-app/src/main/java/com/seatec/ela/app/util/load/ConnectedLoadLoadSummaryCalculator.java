package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.Map;
import javax.validation.constraints.NotNull;

/**
 * ConnectedLoadLoadSummaryCalculator calculates load summaries using a component's connected load.
 * The load summaries will have a pseudo-flight phase of "ConnectedLoad" and an operating mode of
 * null.
 */
class ConnectedLoadLoadSummaryCalculator {
  private static final IPseudoFlightPhaseAggregator LOAD_SUMMARY_AGGREGATOR =
      new ConnectedLoadAggregator();

  // suppress default constructor for noninstantiability
  private ConnectedLoadLoadSummaryCalculator() {
    throw new AssertionError();
  }

  static void calcLoadSummary(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull Component component) {
    PseudoFlightPhaseLoadSummaryUtil.calcLoadSummary(
        loadSummaryMap, summaryType, component, LOAD_SUMMARY_AGGREGATOR);
  }

  static void calcLoadSummariesPhaseSplit(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull LoadSummaryOptions loadSummaryOptions,
      @NotNull Component component) {

    PseudoFlightPhaseLoadSummaryUtil.calcLoadSummariesPhaseSplit(
        loadSummaryMap, summaryType, loadSummaryOptions, component, LOAD_SUMMARY_AGGREGATOR);
  }
}
