package com.seatec.ela.app.util;

import java.math.BigDecimal;

public class FieldValidator {

  public static boolean isDoubleGreaterZero(Double d) {
    return (d != null && d > 0.d) ? true : false;
  }

  public static boolean isDoublesChanged(Double d1, Double d2) {
    BigDecimal a = new BigDecimal(d1 == null ? 0 : d1);
    BigDecimal b = new BigDecimal(d2 == null ? 0d : d2);
    return a.compareTo(b) != 0;
  }
}
