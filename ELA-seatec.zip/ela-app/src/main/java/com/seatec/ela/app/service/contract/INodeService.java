package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Service for dealing with Ela. */
public interface INodeService {

  /**
   * Find a fully hydrated node tree belonging to an Ela by the node id
   *
   * <p>The root of the node tree, if present, will match the node id. All descendant nodes of the
   * root will be fully hydrated with their subNodes, components, and loads.
   *
   * @param id - id of node
   * @param elaId - id of ela
   * @param loadSummaryRequest - load summary request, if null then load summaries aren't calculated
   * @return node if it exists
   */
  Optional<Node> findById(Long id, Long elaId, LoadSummaryRequest loadSummaryRequest);

  /**
   * Find a subset of fully hydrated node trees belonging to an Ela by their node ids.
   *
   * <p>The roots of the node trees returned will match the node ids. All descendant nodes of the
   * roots will be fully hydrated with their subNodes, components, and loads. Therefore only the top
   * level node ids are needed as input parameters.
   *
   * @param topLevelNodeIds - list of ids of the top level nodes.
   * @param elaId - id of ela
   * @param loadSummaryRequest - load summary request, if null then load summaries aren't calculated
   * @return list of top level nodes found fully hydrated
   */
  List<Node> hydrateNodes(
      List<Long> topLevelNodeIds, Long elaId, LoadSummaryRequest loadSummaryRequest);

  /**
   * Find the complete list of fully hydrated node trees belonging to an Ela.
   *
   * <p>The roots of the node trees will be all of the top level nodes of an Ela. All descendant
   * nodes of the roots will be fully hydrated with their subNodes, components, and loads.
   *
   * @param elaId - the ela that the nodes belong to
   * @param loadSummaryRequest - load summary request, if null then load summaries aren't calculated
   * @return list of top level nodes found fully hydrated
   */
  List<Node> hydrateNodes(Long elaId, LoadSummaryRequest loadSummaryRequest);

  /**
   * Fully hydrate an Ela object by replacing its node collection with a collection of hydrated
   * nodes.
   *
   * @param ela - node to hydrate
   */
  Ela hydrateEla(Ela ela);

  /**
   * Map the loads in the list by their parent component.
   *
   * @param loads - list of loads
   * @return a map of components with their loads
   */
  Map<Component, List<Load>> getLoadsByComponent(List<Load> loads);

  Node getNodeByName(List<Node> nodes, String nodeName);
}
