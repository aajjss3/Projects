package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.dto.project.change.ChangeDTO;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ChangeGroupDTO implements UserTrackIdUUID, UserTrackName {

  private UUID id;

  private String name;

  private List<AircraftChangeGroupDTO> aircraftChangeGroups =
      new ArrayList<AircraftChangeGroupDTO>();

  private List<ChangeDTO> changes = new ArrayList<ChangeDTO>();

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<AircraftChangeGroupDTO> getAircraftChangeGroups() {
    return aircraftChangeGroups;
  }

  public void setAircraftChangeGroups(List<AircraftChangeGroupDTO> aircraftChangeGroups) {
    this.aircraftChangeGroups = aircraftChangeGroups;
  }

  public List<ChangeDTO> getChanges() {
    return changes;
  }

  public void setChanges(List<ChangeDTO> changes) {
    this.changes = changes;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }
}
