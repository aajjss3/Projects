package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AnalysisType implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("truAnalysis")
  List<AnalysisNode> truNodes = new ArrayList<AnalysisNode>();

  @JsonProperty("atuAnalysis")
  List<AnalysisNode> atuNodes = new ArrayList<AnalysisNode>();

  @JsonProperty("generatorAnalysis")
  List<AnalysisNode> generatorNodes = new ArrayList<AnalysisNode>();

  // bus analysis ONLY applies to normal analysis, not degraded analysis
  @JsonProperty("busAnalysis")
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  List<AnalysisNode> busNodes = new ArrayList<AnalysisNode>();

  // fuel jettison ONLY applies to degraded analysis and only for 767-300 and 767-400 fleets
  @JsonProperty("fuelJettison")
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  List<FuelJettisonGenerator> fuelJettisonGenerators = new ArrayList<>();

  // AutoLand Condition for normal analysis for fleets (B767, B757, B757ETOPS)
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private AutoLandCondition autoLandCondition;

  // Static Inverter Analysis only for Boeing, only for degraded analysis
  @JsonProperty("staticInverterAnalysis")
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  List<StaticInverter> staticInverterAnalysis = new ArrayList<>();

  // for Boeing 737 - perform a TRU3 Out analysis
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private TRU3OutAnalysis tru3OutAnalysis;

  // HMG Generator
  @JsonProperty("hmgAnalysis")
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  List<HMGAnalysis> hmgAnalysis = new ArrayList<>();

  public void addFuelJettisonGenerator(FuelJettisonGenerator fuelJettisonGenerator) {
    fuelJettisonGenerators.add(fuelJettisonGenerator);
  }

  public List<FuelJettisonGenerator> getFuelJettisonGenerators() {
    return fuelJettisonGenerators;
  }

  public void setFuelJettisonGenerators(List<FuelJettisonGenerator> fuelJettisonGenerators) {
    this.fuelJettisonGenerators = fuelJettisonGenerators;
  }

  public List<AnalysisNode> getTruNodes() {
    return truNodes;
  }

  public void setTruNodes(List<AnalysisNode> truNodes) {
    this.truNodes = truNodes;
  }

  public List<AnalysisNode> getAtuNodes() {
    return atuNodes;
  }

  public void setAtuNodes(List<AnalysisNode> atuNodes) {
    this.atuNodes = atuNodes;
  }

  public List<AnalysisNode> getGeneratorNodes() {
    return generatorNodes;
  }

  public void setGeneratorNodes(List<AnalysisNode> generatorNodes) {
    this.generatorNodes = generatorNodes;
  }

  public List<AnalysisNode> getBusNodes() {
    return busNodes;
  }

  public void setBusNodes(List<AnalysisNode> busNodes) {
    this.busNodes = busNodes;
  }

  public void addTruNode(AnalysisNode analysisNode) {
    truNodes.add(analysisNode);
  }

  public void addAtuNode(AnalysisNode analysisNode) {
    atuNodes.add(analysisNode);
  }

  public void addGeneratorNode(AnalysisNode analysisNode) {
    generatorNodes.add(analysisNode);
  }

  public void addBusNode(AnalysisNode analysisNode) {
    busNodes.add(analysisNode);
  }

  public AutoLandCondition getAutoLandCondition() {
    return autoLandCondition;
  }

  public void setAutoLandCondition(AutoLandCondition autoLandCondition) {
    this.autoLandCondition = autoLandCondition;
  }

  public List<StaticInverter> getStaticInverterAnalysis() {
    return staticInverterAnalysis;
  }

  public void setStaticInverterAnalysis(List<StaticInverter> staticInverterAnalysis) {
    this.staticInverterAnalysis = staticInverterAnalysis;
  }

  public void addStaticInverterAnalysis(StaticInverter analysisStaticInverter) {
    staticInverterAnalysis.add(analysisStaticInverter);
  }

  public List<HMGAnalysis> getHmgAnalysis() {
    return hmgAnalysis;
  }

  public void setHmgAnalysis(List<HMGAnalysis> hmgAnalysis) {
    this.hmgAnalysis = hmgAnalysis;
  }

  public void addHmgAnalysis(HMGAnalysis analysisHMG) {
    hmgAnalysis.add(analysisHMG);
  }

  public TRU3OutAnalysis getTru3OutAnalysis() {
    return tru3OutAnalysis;
  }

  public void setTru3OutAnalysis(TRU3OutAnalysis tru3OutAnalysis) {
    this.tru3OutAnalysis = tru3OutAnalysis;
  }
}
