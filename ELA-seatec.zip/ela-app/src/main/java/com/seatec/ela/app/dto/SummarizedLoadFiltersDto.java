package com.seatec.ela.app.dto;

import com.seatec.ela.app.model.SummaryType;

public class SummarizedLoadFiltersDto {
  private final String flightPhase;
  private final String operatingMode;
  private final SummaryType summaryType;
  private final boolean isMaxPhaseLoad;
  private final boolean isMaxImbalance;

  public SummarizedLoadFiltersDto(
      String flightPhase,
      String operatingMode,
      SummaryType summaryType,
      boolean isMaxPhaseLoad,
      boolean isMaxImbalance) {
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.summaryType = summaryType;
    this.isMaxPhaseLoad = isMaxPhaseLoad;
    this.isMaxImbalance = isMaxImbalance;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public String getOperatingMode() {
    return operatingMode;
  }

  public SummaryType getSummaryType() {
    return summaryType;
  }

  public boolean isMaxPhaseLoad() {
    return isMaxPhaseLoad;
  }

  public boolean isMaxImbalance() {
    return isMaxImbalance;
  }
}
