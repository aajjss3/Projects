package com.seatec.ela.app.config;

import java.awt.Color;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ClientConfig {

  @Value("${app.ela.client.name}")
  private String name;

  @Value("${app.ela.client.report.project}")
  private String projectReportName;

  @Value("${app.ela.client.report.ela}")
  private String elaReportName;

  @Value("${app.ela.client.report.faa.ela}")
  private String faaElaName;

  @Value("${app.ela.client.report.faa.report}")
  private String faaElaReportName;

  // clients
  private static final String DELTA = "delta";
  private static final Color DELTA_DARK_BLUE = new Color(17, 23, 43);
  private static final Color DELTA_NAVY_BLUE = new Color(0, 51, 102);
  private static final Color DELTA_BABY_BLUE = new Color(245, 250, 255);

  private static final String BOEING = "boeing";

  /* GENERAL */
  public String getName() {
    return name;
  }

  public String getProjectReportName() {
    return projectReportName;
  }

  public String getElaReportName() {
    return elaReportName;
  }

  public String getFaaElaName() {
    return faaElaName;
  }

  public String getFaaElaReportName() {
    return faaElaReportName;
  }

  /* THEME / STYLING */
  public Color getPrimaryBackgroundColor() {
    switch (name) {
      case DELTA:
        return DELTA_DARK_BLUE;
      case BOEING:
        return Color.WHITE;
      default:
        return Color.WHITE;
    }
  }

  public Color getSecondaryBackgroundColor() {
    switch (this.name) {
      case DELTA:
        return DELTA_BABY_BLUE;
      case BOEING:
        return Color.WHITE;
      default:
        return Color.BLACK;
    }
  }

  public Color getPrimaryFontColor() {
    switch (this.name) {
      case DELTA:
        return DELTA_NAVY_BLUE;
      case BOEING:
        return Color.WHITE;
      default:
        return Color.BLACK;
    }
  }

  public Color getSecondaryFontColor() {
    switch (this.name) {
      case DELTA:
      case BOEING:
        return Color.GRAY;
      default:
        return Color.BLACK;
    }
  }

  /* FLIGHT PHASES */
  public enum Airbus {
    GROUND,
    START,
    ROLL,
    TOFF,
    CLIMB,
    CRUISE,
    DESCENT,
    LANDING,
    TAXI
  }

  public enum Boeing {
    LOADING,
    ENGINE_START,
    TAXI,
    TAKEOFF_CLIMB,
    CRUISE,
    HOLD_LAND,
    STANDBY
  }

  public enum Boeing717 {
    LOADING,
    ENGINE_START,
    TAXI,
    TAKEOFF_CLIMB,
    CRUISE_COLD,
    CRUISE_HOT,
    DESCENT_LAND,
    EMERGENCY,
    GROUND_SERVICE,
    STANDBY
  }
}
