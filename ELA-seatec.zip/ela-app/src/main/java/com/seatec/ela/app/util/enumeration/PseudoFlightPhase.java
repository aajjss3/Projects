package com.seatec.ela.app.util.enumeration;

public enum PseudoFlightPhase {
  NominalPower,
  ConnectedLoad
}
