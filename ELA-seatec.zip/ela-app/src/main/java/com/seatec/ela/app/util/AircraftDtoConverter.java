package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.model.Aircraft;

public class AircraftDtoConverter {
  public static Aircraft convertToEntity(AircraftDto aircraftDto) {
    if (aircraftDto == null) {
      return null;
    }
    return new Aircraft(
        aircraftDto.getId(),
        aircraftDto.getAircraftShipNo(),
        aircraftDto.getSerialNumber(),
        aircraftDto.getRegistrationNumber(),
        aircraftDto.getLineNumber(),
        aircraftDto.getVariableNumber(),
        null,
        aircraftDto.isArchived(),
        aircraftDto.getBatteryCharge());
  }

  public static AircraftDto convertToDto(Aircraft aircraft) {
    if (aircraft == null) {
      return null;
    }
    return new AircraftDto(aircraft);
  }
}
