package com.seatec.ela.app.controller;

import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.FleetNameDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.service.contract.IFleetService;
import com.seatec.ela.app.util.FleetDtoConverter;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.filter.ValidateFleet;
import com.seatec.ela.app.validator.filter.ValidateSubFleet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/fleets")
@Validated
public class FleetController implements IConstraintViolation {

  @Autowired IFleetService fleetService;

  @Autowired private Validator validator;

  @ExceptionHandler(DataIntegrityViolationException.class)
  ResponseEntity<ErrorWrapperDTO> handle(DataIntegrityViolationException exception) {
    return handleDataIntegrityViolationException(
        exception,
        "Constraint Violation: Check for Unique Name and Required Fields With Valid Content");
  }

  @GetMapping()
  @ResponseStatus(HttpStatus.OK)
  public List<Fleet> findFleets(
      @RequestParam(value = "hasEla", required = false) boolean hasEla,
      @RequestParam(value = "aircraft", required = false) String aircraftShipNo,
      @RequestParam(value = "includeCloaked", required = false, defaultValue = "false")
          boolean includeCloaked,
      @RequestParam(value = "includeArchived", required = false, defaultValue = "false")
          boolean includeArchived,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    return fleetService.findAll(hasEla, includeCloaked, includeArchived, aircraftShipNo, userId);
  }

  @GetMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public FleetDto getFleetById(@PathVariable("id") Long id) {
    Optional<Fleet> result = fleetService.findById(id);
    Fleet entity = result.orElse(null);
    return FleetDtoConverter.convertToDto(entity);
  }

  /**
   * Handles creating a new FleetDto
   *
   * @param fleet Represents the new FleetDto and associated values
   * @return FleetDto
   */
  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public FleetDto createFleet(
      @Validated(value = {ValidateSubFleet.class}) @RequestBody FleetDto fleet) {
    if (fleet.getParentFleetId() == null) {
      validateFleet(fleet);
    }
    return FleetDtoConverter.convertToDto(
        fleetService.create(FleetDtoConverter.convertToEntity(fleet), fleet.getParentFleetId()));
  }

  @PutMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public FleetDto updateFleet(
      @Validated(value = {ValidateSubFleet.class}) @RequestBody FleetDto fleet) {
    if (fleet.getParentFleetId() == null) {
      validateFleet(fleet);
    }
    return FleetDtoConverter.convertToDto(
        fleetService.update(FleetDtoConverter.convertToEntity(fleet), fleet.getParentFleetId()));
  }

  @DeleteMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public void deleteFleet(@PathVariable("id") Long id) {
    fleetService.deleteById(id);
  }

  @GetMapping("names")
  @ResponseStatus(HttpStatus.OK)
  public List<FleetNameDTO> getFleetNames() {
    return fleetService.getFleetNames();
  }

  private void validateFleet(FleetDto fleet) {
    Set<ConstraintViolation<FleetDto>> violations = validator.validate(fleet, ValidateFleet.class);
    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }
  }
}
