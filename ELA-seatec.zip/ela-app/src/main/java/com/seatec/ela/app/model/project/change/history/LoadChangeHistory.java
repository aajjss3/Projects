package com.seatec.ela.app.model.project.change.history;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.base.BaseLoadChange;
import com.seatec.ela.app.model.project.change.Change;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "load_change_history")
public class LoadChangeHistory extends BaseLoadChange {

  @JsonIgnore
  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "change_id", nullable = false)
  private Change change;

  @JsonIgnore
  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "aircraft_id", nullable = false)
  private Aircraft aircraft;

  @JsonIgnore
  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ela_id", nullable = false)
  private Ela ela;

  public Change getChange() {
    return change;
  }

  public void setChange(Change change) {
    this.change = change;
  }

  public Aircraft getAircraft() {
    return aircraft;
  }

  public void setAircraft(Aircraft aircraft) {
    this.aircraft = aircraft;
  }

  public Ela getEla() {
    return ela;
  }

  public void setEla(Ela ela) {
    this.ela = ela;
  }
}
