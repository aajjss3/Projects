package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.dto.FleetNameDTO;
import com.seatec.ela.app.model.Fleet;
import java.util.List;
import java.util.Optional;

/** Service for dealing with Fleet. */
public interface IFleetService {

  /**
   * Find All Fleets
   *
   * @param hasEla filter for including aircrafts containing an Ela
   * @param includeCloaked filter for including cloaked Aircraft
   * @param includeArchived filter for included archived Aircraft
   * @param aircraftShipNo
   * @return Fleet collection
   */
  List<Fleet> findAll(
      boolean hasEla,
      boolean includeCloaked,
      boolean includeArchived,
      String aircraftShipNo,
      String userId);

  /**
   * Find Fleet by name
   *
   * @param name of Fleet
   * @return fleets that match the elaName
   */
  List<Fleet> findByName(String name);

  /**
   * Find Fleet by id.
   *
   * @param id id of airbus Fleet
   * @return Fleet if it exists
   */
  Optional<Fleet> findById(Long id);

  /**
   * create Fleet by entity
   *
   * @param entity of Fleet
   * @return Fleet
   */
  Fleet create(Fleet entity, Long parentId);

  /**
   * update Fleet by entity
   *
   * @param entity of Fleet
   * @return Fleet
   */
  Fleet update(Fleet entity, Long parentId);

  /**
   * Delete Fleet by id
   *
   * @param id of Fleet
   * @return Long
   */
  void deleteById(Long id);

  List<FleetNameDTO> getFleetNames();
}
