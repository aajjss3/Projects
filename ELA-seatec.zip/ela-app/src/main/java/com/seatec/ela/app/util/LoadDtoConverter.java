package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.changeGroup.LoadDto;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.project.LoadChange;
import java.util.List;
import java.util.stream.Collectors;

public class LoadDtoConverter {

  public static List<LoadDto> convertLoadToLoadDto(List<Load> loads) {
    return loads.stream()
        .map(
            load ->
                new LoadDto(
                    load.getVa(),
                    load.getW(),
                    load.getVar(),
                    load.getPowerFactor(),
                    load.getFlightPhase(),
                    load.getOperatingMode()))
        .collect(Collectors.toList());
  }

  public static LoadDto convertLoadChangeToLoadDto(LoadChange loadChange) {
    LoadDto loadDto =
        new LoadDto(
            loadChange.getVa(),
            loadChange.getPowerFactor(),
            loadChange.getFlightPhase(),
            loadChange.getOperatingMode());
    return loadDto;
  }

  public static List<LoadDto> convertLoadChangesToLoadDtos(List<LoadChange> loadChanges) {
    return loadChanges.stream()
        .map(lc -> convertLoadChangeToLoadDto(lc))
        .collect(Collectors.toList());
  }
}
