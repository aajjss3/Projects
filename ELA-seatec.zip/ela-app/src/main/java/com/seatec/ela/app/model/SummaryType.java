package com.seatec.ela.app.model;

public enum SummaryType {
  COMPONENTS,
  COMPONENTS_AND_CHILDREN
}
