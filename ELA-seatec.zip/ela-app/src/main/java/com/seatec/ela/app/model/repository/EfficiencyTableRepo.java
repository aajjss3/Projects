package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.EfficiencyTable;
import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EfficiencyTableRepo extends CrudRepository<EfficiencyTable, UUID> {
  EfficiencyTable findByName(String name);

  List<EfficiencyTable> findAll();
}
