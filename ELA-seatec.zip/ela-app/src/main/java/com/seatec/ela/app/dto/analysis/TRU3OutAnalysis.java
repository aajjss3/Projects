package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class TRU3OutAnalysis implements Serializable {

  private static final long serialVersionUID = 1L;

  private double bbLoadInAmps;
  private double hbLoadInAmps;
  private double shbLoadInAmps;
  private double batteryChargeRating;
  private double totalLoadInAmps;
  private double rating;
  private AnalysisStatus status;
  private String flightPhase;

  public double getBbLoadInAmps() {
    return bbLoadInAmps;
  }

  public void setBbLoadInAmps(double bbLoadInAmps) {
    this.bbLoadInAmps = bbLoadInAmps;
  }

  public double getHbLoadInAmps() {
    return hbLoadInAmps;
  }

  public void setHbLoadInAmps(double hbLoadInAmps) {
    this.hbLoadInAmps = hbLoadInAmps;
  }

  public double getShbLoadInAmps() {
    return shbLoadInAmps;
  }

  public void setShbLoadInAmps(double shbLoadInAmps) {
    this.shbLoadInAmps = shbLoadInAmps;
  }

  public double getBatteryChargeRating() {
    return batteryChargeRating;
  }

  public void setBatteryChargeRating(double batteryChargeRating) {
    this.batteryChargeRating = batteryChargeRating;
  }

  public double getTotalLoadInAmps() {
    return totalLoadInAmps;
  }

  public void setTotalLoadInAmps(double totalLoadInAmps) {
    this.totalLoadInAmps = totalLoadInAmps;
  }

  public double getRating() {
    return rating;
  }

  public void setRating(double rating) {
    this.rating = rating;
  }

  public AnalysisStatus getStatus() {
    return status;
  }

  public void setStatus(AnalysisStatus status) {
    this.status = status;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }
}
