package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class TRUsAutoLandAnalysisDTO implements Serializable {

  private static final long serialVersionUID = 1L;

  private TRUAutoLandAnalysisDTO tru1;
  private TRUAutoLandAnalysisDTO tru2;
  private TRUAutoLandAnalysisDTO tru3;
  private AnalysisStatus status;

  public TRUsAutoLandAnalysisDTO(
      TRUAutoLandAnalysisDTO tru1,
      TRUAutoLandAnalysisDTO tru2,
      TRUAutoLandAnalysisDTO tru3,
      AnalysisStatus status) {
    this.tru1 = tru1;
    this.tru2 = tru2;
    this.tru3 = tru3;
    this.status = status;
  }

  public TRUAutoLandAnalysisDTO getTru1() {
    return tru1;
  }

  public void setTru1(TRUAutoLandAnalysisDTO tru1) {
    this.tru1 = tru1;
  }

  public TRUAutoLandAnalysisDTO getTru2() {
    return tru2;
  }

  public void setTru2(TRUAutoLandAnalysisDTO tru2) {
    this.tru2 = tru2;
  }

  public TRUAutoLandAnalysisDTO getTru3() {
    return tru3;
  }

  public void setTru3(TRUAutoLandAnalysisDTO tru3) {
    this.tru3 = tru3;
  }

  public AnalysisStatus getStatus() {
    return status;
  }

  public void setStatus(AnalysisStatus status) {
    this.status = status;
  }
}
