package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.dto.ElaComponentsDto;
import com.seatec.ela.app.dto.project.AircraftDTO;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import java.util.List;
import java.util.Optional;

/** Service for dealing with Ela. */
public interface IElaService {

  List<ElaComponentsDto> findElaComponentDtosByAircraftDTOS(List<AircraftDTO> aircraftDTOS);

  List<ElaComponentsDto> findElaComponentDtosByComponentIds(List<Long> componentIds);

  /**
   * Find Ela by name
   *
   * @param name of ELA
   * @return elas that match the elaName
   */
  List<Ela> findByName(String name);

  /**
   * Find Ela by id.
   *
   * @param id id of airbus ELA
   * @return airbusELA if it exists
   */
  Optional<Ela> findById(Long id);

  /**
   * save Ela by entity
   *
   * @param entity of airbus ELA
   * @return no return value
   */
  void save(Ela entity);

  /**
   * Delete Ela by name
   *
   * @param name of ELA
   * @return Long
   */
  Long deleteByName(String name);

  /**
   * Find all Elas
   *
   * @return all elas
   */
  List<Ela> findAll();

  /**
   * Find elas that are associated to an aircraft ship number.
   *
   * @return elas associated to aircraft matching the ship number
   */
  List<Ela> findByAircraftShipNo(String aircraftShipNo, String userId);

  List<Long> findDistinctElaIdByAircraftChangeGroups(List<AircraftChangeGroup> changeGroup);

  void rebase(List<ChangeGroup> changeGroups);

  void elaAircraftCloakPermission(Long elaId, String userId);
}
