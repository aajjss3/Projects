package com.seatec.ela.app.util.ela;

import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.structure.NodeStructure;
import com.seatec.ela.app.util.csv.AirbusCsvAggregate;
import com.seatec.ela.app.util.csv.AirbusCsvAggregateKey;
import com.seatec.ela.app.util.csv.CsvData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@org.springframework.stereotype.Component
public class ElaFactory {
  enum OperationalMode {
    MAXI,
    OPERATIONAL
  }

  enum FlightPhase {
    GROUND,
    START,
    ROLL,
    TOFF,
    CLIMB,
    CRUISE,
    DESCENT,
    LANDING,
    TAXI
  }

  private static final Logger logger = LoggerFactory.getLogger(ElaFactory.class);

  /**
   * Create Ela Entity
   *
   * @param bean - bean containing information for Ela Creation
   * @param csvData - optional import data
   * @return returns new Ela
   */
  public Ela createEla(ElaCreationBean bean, CsvData csvData) {
    Ela ela = new Ela();
    ela.setName(bean.getElaName());
    ela.setAircraft(bean.getAircraft());
    if (bean.isAircraftClone()) {
      ela.setCreatedBy(
          "API Clone of " + bean.getCloneAircraft().getAircraftShipNo()); // maybe import or clone
      for (Node sourceNode : bean.getCloneEla().getNodes()) {
        Node newNode = sourceNode.cloneWithSubNodes();
        ela.addNode(newNode);
      }
    } else {
      ela.setCreatedBy("API Import");
      LinkedHashMap<String, List<AirbusCsvAggregateKey>> keyMap = csvData.getKeyMap();
      LinkedHashMap<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap = csvData.getDataMap();
      for (NodeStructure nodeStructure : bean.getStructureList()) {
        createAndFill(nodeStructure, null, ela, bean.getEfficiencyTableMap(), keyMap, dataMap);
        keyMap.remove(nodeStructure.getNodeName());
      }
      if (!keyMap.isEmpty()) {
        logger.warn(
            "Unused CSV data remains after filling Node Structure: {} ",
            String.join(",", keyMap.keySet()));
      }
    }
    return ela;
  }

  /**
   * Used to Find if an optional Node should be created in the new ela
   *
   * @param keyMap KeyMap of imported data
   * @param dataMap DataAMap of imported data
   * @param subNodeList List of sub Node Structure children for the bus
   * @param parentNode Node of the parent for the node
   * @param nodeName name of the current node
   * @return true to keep the node
   */
  private boolean foundLikeMatch(
      Map<String, List<AirbusCsvAggregateKey>> keyMap,
      Map<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap,
      List<NodeStructure> subNodeList,
      Node parentNode,
      String nodeName) {
    // ETL does a query if a Bus exists in ingest data with a partial match to the BusName to
    // determine optional bus should exist
    // Here import uses the following analysis from CSV data:
    if (keyMap.containsKey(nodeName)) {
      // Bus Name found directly from import data
      return true;
    }
    for (NodeStructure nodeStructure : subNodeList) {
      if (keyMap.containsKey(nodeStructure.getNodeName())) {
        // SubNode Bus Name found directly from import data
        return true;
      }
    }
    if (parentNode != null) {
      List<AirbusCsvAggregateKey> keyList = keyMap.get(parentNode.getName());
      for (AirbusCsvAggregateKey key : keyList) {
        AirbusCsvAggregate data = dataMap.get(key);
        if (data.getDesignator().matches(".*" + nodeName + ".*")) {
          // Parent Node Designation partially matches for Node Name (we will assume it is likely to
          // exist)
          return true;
        }
      }
    }
    return false;
  }

  private void createAndFill(
      NodeStructure nodeStructure,
      Node parentNode,
      Ela ela,
      Map<String, EfficiencyTable> efficiencyTableMap,
      Map<String, List<AirbusCsvAggregateKey>> keyMap,
      Map<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap) {
    String name = nodeStructure.getNodeName();

    if (nodeStructure.isOptional()
        && !foundLikeMatch(
            keyMap,
            dataMap,
            nodeStructure.getSubNodeStructure(),
            parentNode,
            nodeStructure.getNodeName())) {
      logger.info("Skipping Optional Bus {}", nodeStructure.getNodeName());
      return;
    }

    Node node = createNode(nodeStructure, parentNode, ela, efficiencyTableMap);
    List<AirbusCsvAggregateKey> keyList = keyMap.get(name);
    if (keyList == null || keyList.isEmpty()) {
      if (!nodeStructure.isOptional() && node.getNodeType().equals(NodeType.BUS)) {
        logger.info("Required Bus Node {} has no components", node.getName());
      }
    } else {
      List initialList = new ArrayList<AirbusCsvAggregateKey>(keyList);
      for (AirbusCsvAggregateKey key : keyList) {
        if (!initialList.contains(key)) {
          continue;
        }
        List<AirbusCsvAggregateKey> sameIdentifierKeys =
            keyList.stream()
                .filter(s -> s.getIdentifier().equals(key.getIdentifier()))
                .collect(Collectors.toList());
        boolean threePhase =
            sameIdentifierKeys.stream()
                .map(s -> s.getPhase())
                .collect(Collectors.toList())
                .containsAll(Arrays.asList("A", "B", "C"));
        if (threePhase) {
          populateThreePhaseComponent(node, sameIdentifierKeys, dataMap);
          initialList.removeIf(k -> sameIdentifierKeys.contains(k));
        } else {
          populateSinglePhaseComponent(node, key, dataMap.get(key));
          initialList.remove(key);
        }
      }
    }
    reorderComponentDisplayOrder(node);
    for (NodeStructure childNodeStructure : nodeStructure.getSubNodeStructure()) {
      createAndFill(childNodeStructure, node, ela, efficiencyTableMap, keyMap, dataMap);
      keyMap.remove(childNodeStructure.getNodeName());
    }
  }

  private Node createNode(
      NodeStructure nodeStructure,
      Node parentNode,
      Ela ela,
      Map<String, EfficiencyTable> efficiencyTableMap) {
    Node node = new Node();
    node.setName(nodeStructure.getNodeName());
    node.setNodeType(nodeStructure.getNodeType());
    node.setVoltage(nodeStructure.getVoltage());
    node.setVoltageType(ElectricalPhase.fromVoltageType(nodeStructure.getVoltageType()));
    node.setElectricalPhase(nodeStructure.getElectricalPhase());
    node.setDisplayOrder(nodeStructure.getDisplayOrder());
    node.setParentNode(parentNode);
    node.setRequiresApproval(nodeStructure.isRequiresApproval());
    node.setSheddable(nodeStructure.isSheddable());
    node.setNormalTr(nodeStructure.isNormalTr());

    String effName = nodeStructure.getEfficiencyTableName();
    if (!StringUtils.isBlank(effName)) {
      EfficiencyTable effTable = efficiencyTableMap.get(effName);
      if (effTable == null) {
        throw new BadRequestException(
            "Node "
                + nodeStructure.getNodeName()
                + " Efficiency Table name "
                + effName
                + " does not match not found");
      } else {
        node.setEfficiencyTable(effTable);
      }
    }
    // we need to use first value.  First use amp if present else va else null
    // variations "35-50-60" in one case and "35-60", "35-50"  also "220-200" also "50 SHARED"
    // May need to log that we chose one bus and that there are other possible values??
    String[] amp = nodeStructure.getBusRatingAmps();
    String[] va = nodeStructure.getBusRatingVAs();
    if (amp != null && !StringUtils.isBlank(amp[0]) && NumberUtils.isCreatable(amp[0])) {
      if (node.getNodeType().equals(NodeType.TRU)) {
        node.setNominalPower(NumberUtils.toDouble(amp[0]));
      } else {
        node.setBusRating(NumberUtils.toDouble(amp[0]));
      }
      if (amp.length > 1) {
        logger.info(
            "Node BusRating or TRU Nominal Power using {} other possible values {}",
            node.getBusRating(),
            amp);
      }
    } else if (va != null && !StringUtils.isBlank(va[0]) && NumberUtils.isCreatable(va[0])) {
      if (node.getNodeType().equals(NodeType.GENERATOR)
          || node.getNodeType().equals(NodeType.ATU)) {
        node.setNominalPower(NumberUtils.toDouble(va[0]));
      } else {
        node.setBusRating(NumberUtils.toDouble(va[0]));
      }
      if (va.length > 1) {
        logger.info(
            "Node BusRating or Generator/ATU Nominal Power using {} other possible values {}",
            node.getBusRating(),
            va);
      }
    }

    if (parentNode == null) {
      ela.addNode(node);
    } else {
      parentNode.addSubNode(node);
    }
    return node;
  }

  private Component createComponent(Node node, AirbusCsvAggregate data, boolean threePhase) {
    int displayOrder = node.getComponents() == null ? 1 : node.getComponents().size() + 1;
    Component component = new Component();
    component.setDisplayOrder(displayOrder);
    component.setIntermittent(data.isIntermittent());
    component.setClipsed(data.isClipsed());
    component.setSheddable(data.isSheddable());
    component.setName(data.getBusBar());
    if (node.getVoltageType().equals(ElectricalPhase.DC)) {
      component.setElectricalPhase(ElectricalPhase.DC);
    } else { // default to AC
      component.setElectricalPhase(ElectricalPhase.AC);
    }
    component.setElectIdent(data.getIdentifier());
    component.setAta(data.getAtacode());
    component.setName(data.getDesignator());
    component.setPanel(data.getPanel());
    double nomPower = NumberUtils.toDouble(data.getNominalPower());
    if (threePhase) {
      component.setNominalPower(3 * nomPower);
    } else {
      component.setNominalPower(nomPower);
    }
    if (!component.getIntermittent()) {
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.GROUND.toString(),
              calcFlightPhase(nomPower, data.getMaxiGroundStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.START.toString(),
              calcFlightPhase(nomPower, data.getMaxiStartStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.ROLL.toString(),
              calcFlightPhase(nomPower, data.getMaxiRollStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.TOFF.toString(),
              calcFlightPhase(nomPower, data.getMaxiTakeoffStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.CLIMB.toString(),
              calcFlightPhase(nomPower, data.getMaxiClimbStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.CRUISE.toString(),
              calcFlightPhase(nomPower, data.getMaxiCruiseStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.DESCENT.toString(),
              calcFlightPhase(nomPower, data.getMaxiDescendStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.LANDING.toString(),
              calcFlightPhase(nomPower, data.getMaxiLandStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.MAXI.toString(),
              FlightPhase.TAXI.toString(),
              calcFlightPhase(nomPower, data.getMaxiTaxiStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.GROUND.toString(),
              calcFlightPhase(nomPower, data.getOperationalGroundStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.START.toString(),
              calcFlightPhase(nomPower, data.getOperationalStartStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.ROLL.toString(),
              calcFlightPhase(nomPower, data.getOperationalRollStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.TOFF.toString(),
              calcFlightPhase(nomPower, data.getOperationalTakeoffStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.CLIMB.toString(),
              calcFlightPhase(nomPower, data.getOperationalClimbStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.CRUISE.toString(),
              calcFlightPhase(nomPower, data.getOperationalCruiseStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.DESCENT.toString(),
              calcFlightPhase(nomPower, data.getOperationalDescendStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.LANDING.toString(),
              calcFlightPhase(nomPower, data.getOperationalLandStage(), threePhase)));
      component.addLoad(
          createLoad(
              OperationalMode.OPERATIONAL.toString(),
              FlightPhase.TAXI.toString(),
              calcFlightPhase(nomPower, data.getOperationalTaxiStage(), threePhase)));
    }
    node.addComponent(component);
    return component;
  }

  private Load createLoad(String operatingMode, String flightPhase, Double number) {
    Load load = new Load();
    load.setOperatingMode(operatingMode);
    load.setFlightPhase(flightPhase);
    load.setVa(number);
    load.setPowerFactor(1d);
    return load;
  }

  private void populateSinglePhaseComponent(
      Node node, AirbusCsvAggregateKey key, AirbusCsvAggregate data) {
    Component component = createComponent(node, data, false);
    if (key.getPhase().equals("A")) {
      component.setElectricalPhase(ElectricalPhase.ACA);
    } else if (key.getPhase().equals("B")) {
      component.setElectricalPhase(ElectricalPhase.ACB);
    } else if (key.getPhase().equals("C")) {
      component.setElectricalPhase(ElectricalPhase.ACC);
    }
  }

  private void populateThreePhaseComponent(
      Node node,
      List<AirbusCsvAggregateKey> sameIdentifierKeys,
      Map<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap) {
    AirbusCsvAggregateKey consistentKey = getConsistentKey(sameIdentifierKeys, dataMap);
    if (consistentKey != null) {
      Component component = createComponent(node, dataMap.get(consistentKey), true);
      component.setElectricalPhase(ElectricalPhase.AC3);
    } else {
      for (AirbusCsvAggregateKey key : sameIdentifierKeys) {
        populateSinglePhaseComponent(node, key, dataMap.get(key));
      }
    }
  }

  private AirbusCsvAggregateKey getConsistentKey(
      List<AirbusCsvAggregateKey> sameIdentifierKeys,
      Map<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap) {
    AirbusCsvAggregateKey primaryKey = sameIdentifierKeys.get(0);
    for (AirbusCsvAggregateKey key : sameIdentifierKeys) {
      if (key.getPhase().equals("A")) {
        primaryKey = key;
      }
      if (!dataMap.get(key).consistentTo(dataMap.get(primaryKey))) {
        return null;
      }
    }
    return primaryKey;
  }

  private void reorderComponentDisplayOrder(Node node) {
    List<Component> list =
        node.getComponents().stream()
            .sorted((s1, s2) -> s1.getDisplayOrder().compareTo(s2.getDisplayOrder()))
            .collect(Collectors.toList());
    IntStream.range(1, list.size())
        .forEachOrdered(
            order -> {
              list.get((int) order - 1).setDisplayOrder(order);
            });
  }

  private double calcFlightPhase(double nomPower, String phaseString, boolean threePhase) {
    double flightPhaseNum = NumberUtils.toDouble(phaseString);
    if (nomPower == 0d || flightPhaseNum == 0d) {
      return 0d;
    } else {
      if (threePhase) {
        return 3 * flightPhaseNum;
      } else {
        return flightPhaseNum;
      }
    }
  }
}
