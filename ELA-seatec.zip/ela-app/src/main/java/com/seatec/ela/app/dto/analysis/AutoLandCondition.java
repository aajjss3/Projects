package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.seatec.ela.app.util.BatteryDischargeCalculation;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import java.io.Serializable;

/**
 * AutoLand Analysis for Boeing fleets - B767, B757, B757ETOPS, B737.
 *
 * <p>TRU analysis for B737
 *
 * <p>Battery analysis for B767, B757, B757ETOPS
 *
 * <pre>
 *   - AutoLand is only an analysis for the Hold/Land flight phase
 *   - NOTE: Battery drains for AutoLand Analysis when load is over 60 Amps
 *   or if the charger is INOP. If the charger is INOP, the battery can supply
 *   the above Autoland load. Autoland is limited to less than 5 minutes.
 * </pre>
 */
public class AutoLandCondition implements Serializable, IBatteryAnalysis {

  private static final long serialVersionUID = 1L;

  // used for B767, B757, B757ETOPS AutoLand Analysis
  private static final Double REQUIRED_BATTERY_LIFE_IN_MINUTES = 5.0d;

  // used for B767, B757, B757ETOPS AutoLand Analysis
  @JsonInclude(Include.NON_NULL)
  private AutoLandAnalysis analysisBatteryCharger;

  // used for B767, B757, B757ETOPS AutoLand Analysis
  @JsonInclude(Include.NON_NULL)
  private AutoLandAnalysis analysisBatteryOnly;

  // used for B767, B757, B757ETOPS AutoLand Analysis
  @JsonInclude(Include.NON_NULL)
  private BatteryChargeType batteryCapacity;

  // used for B737 AutoLand Analysis
  @JsonInclude(Include.NON_NULL)
  private TRUsAutoLandAnalysisDTO truAutoLandAnalysis;

  /**
   * The status used for B767, B757, B757ETOPS AutoLand Analysis
   *
   * <p>If Battery Life is ≥ REQUIRED_BATTERY_LIFE_IN_MINUTES, Status = PASS
   *
   * <p>If Battery Life is < REQUIRED_BATTERY_LIFE_IN_MINUTES, Status = FAIL
   *
   * @return the analysis status
   */
  @JsonProperty(value = "status", access = Access.READ_ONLY)
  public AnalysisStatus getStatus() {
    AnalysisStatus analysisStatus = AnalysisStatus.PASS;
    if (batteryCapacity != null && analysisBatteryOnly != null) {
      if (Double.compare(getActualBatteryLifeInMinutes(), REQUIRED_BATTERY_LIFE_IN_MINUTES) < 0) {
        analysisStatus = AnalysisStatus.FAIL;
      }
    } else if (truAutoLandAnalysis != null) {
      analysisStatus = truAutoLandAnalysis.getStatus();
    }
    return analysisStatus;
  }

  /**
   * The required battery life used for B767, B757, B757ETOPS AutoLand Analysis
   *
   * @return the required battery life in minutes
   */
  @JsonInclude(Include.NON_NULL)
  @JsonProperty(value = "requiredBatteryLifeInMinutes", access = Access.READ_ONLY)
  public Double getRequiredBatteryLifeInMinutes() {
    return (batteryCapacity != null) ? REQUIRED_BATTERY_LIFE_IN_MINUTES : null;
  }

  /**
   * The battery life used for B767, B757, B757ETOPS AutoLand Analysis
   *
   * @return the actual battery life in minutes
   */
  @JsonInclude(Include.NON_NULL)
  @JsonProperty(value = "actualBatteryLifeInMinutes", access = Access.READ_ONLY)
  public Double getActualBatteryLifeInMinutes() {
    Double actualBatteryLifeInMinutesBatteryOnly = null;
    if (batteryCapacity != null && analysisBatteryOnly != null) {
      actualBatteryLifeInMinutesBatteryOnly =
          BatteryDischargeCalculation.boeingEquation(batteryCapacity, getTotalLoadInAmps());
    }
    return actualBatteryLifeInMinutesBatteryOnly;
  }

  /**
   * The total load in amps for B767, B757, B757ETOPS AutoLand Analysis
   *
   * @return the total load in Amps
   */
  @JsonInclude(Include.NON_NULL)
  @JsonProperty(value = "totalLoadInAmps", access = Access.READ_ONLY)
  public Double getTotalLoadInAmps() {
    Double totalLoadInAmpsBatteryOnly = null;
    if (analysisBatteryOnly != null) {
      totalLoadInAmpsBatteryOnly = analysisBatteryOnly.getTotalLoadInAmpsSummary();
    }
    return totalLoadInAmpsBatteryOnly;
  }

  public AutoLandAnalysis getAnalysisBatteryCharger() {
    return analysisBatteryCharger;
  }

  public void setAnalysisBatteryCharger(AutoLandAnalysis analysisBatteryCharger) {
    this.analysisBatteryCharger = analysisBatteryCharger;
  }

  public AutoLandAnalysis getAnalysisBatteryOnly() {
    return analysisBatteryOnly;
  }

  public void setAnalysisBatteryOnly(AutoLandAnalysis analysisBatteryOnly) {
    this.analysisBatteryOnly = analysisBatteryOnly;
  }

  public BatteryChargeType getBatteryCapacity() {
    return batteryCapacity;
  }

  public void setBatteryCapacity(BatteryChargeType batteryCapacity) {
    this.batteryCapacity = batteryCapacity;
  }

  public TRUsAutoLandAnalysisDTO getTruAutoLandAnalysis() {
    return truAutoLandAnalysis;
  }

  public void setTruAutoLandAnalysis(TRUsAutoLandAnalysisDTO truAutoLandAnalysis) {
    this.truAutoLandAnalysis = truAutoLandAnalysis;
  }
}
