package com.seatec.ela.app.util.enumeration;

public enum ActionType {
  ADD,
  DELETE,
  EDIT
}
