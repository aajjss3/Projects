package com.seatec.ela.app.model;

public enum EfficiencyType {
  ATU,
  TRU,
  TRU_ESS
}
