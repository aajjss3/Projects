package com.seatec.ela.app.dto.changeGroup;

import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.View;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@JsonView(View.EffectivitySummaryView.class)
public class ComponentDto {

  private ActionType action;

  private String name;

  private String ata;

  private Integer displayOrder;

  private Boolean clipsed;

  private Boolean sheddable;

  private String electIdent;

  private String panel;

  private Double nominalPower;

  private ElectricalPhase electricalPhase;

  private Boolean intermittent;

  private Double connectedLoadVa;

  private Double connectedLoadPf;

  private List<LoadDto> loads = new ArrayList<>();

  private List<String> editedFields = new ArrayList<>();

  private UUID changeId;

  private Boolean isGlobal;

  public ComponentDto() {}

  public ComponentDto(String name, Double nominalPower, boolean sheddable) {
    this.name = name;
    this.nominalPower = nominalPower;
    this.sheddable = sheddable;
  }

  public ComponentDto(
      String name,
      String ata,
      Integer displayOrder,
      Boolean clipsed,
      Boolean sheddable,
      String electIdent,
      String panel,
      Double nominalPower,
      ElectricalPhase electricalPhase,
      Boolean intermittent,
      Double connectedLoadVa,
      Double connectedLoadPf) {
    this.name = name;
    this.ata = ata;
    this.displayOrder = displayOrder;
    this.clipsed = clipsed;
    this.sheddable = sheddable;
    this.electIdent = electIdent;
    this.panel = panel;
    this.nominalPower = nominalPower;
    this.electricalPhase = electricalPhase;
    this.intermittent = intermittent;
    this.connectedLoadVa = connectedLoadVa;
    this.connectedLoadPf = connectedLoadPf;
  }

  public ActionType getAction() {
    return action;
  }

  public void setAction(ActionType action) {
    this.action = action;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAta() {
    return ata;
  }

  public void setAta(String ata) {
    this.ata = ata;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Boolean getClipsed() {
    return clipsed;
  }

  public void setClipsed(Boolean clipsed) {
    this.clipsed = clipsed;
  }

  public Boolean getSheddable() {
    return sheddable;
  }

  public void setSheddable(Boolean sheddable) {
    this.sheddable = sheddable;
  }

  public String getElectIdent() {
    return electIdent;
  }

  public void setElectIdent(String electIdent) {
    this.electIdent = electIdent;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public Boolean getIntermittent() {
    return intermittent;
  }

  public void setIntermittent(Boolean intermittent) {
    this.intermittent = intermittent;
  }

  public List<LoadDto> getLoads() {
    return loads;
  }

  public void setLoads(List<LoadDto> loads) {
    this.loads = loads;
  }

  public void addLoad(LoadDto load) {
    this.loads.add(load);
  }

  public void removeLoad(LoadDto load) {
    this.loads.remove(load);
  }

  public List<String> getEditedFields() {
    return editedFields;
  }

  public void setEditedFields(List<String> editedFields) {
    this.editedFields = editedFields;
  }

  public void addEditedField(String editedFields) {
    this.editedFields.add(editedFields);
  }

  public void removeEditedField(String editedFields) {
    this.editedFields.remove(editedFields);
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public UUID getChangeId() {
    return changeId;
  }

  public void setChangeId(UUID changeId) {
    this.changeId = changeId;
  }

  public Double getConnectedLoadVa() {
    return connectedLoadVa;
  }

  public void setConnectedLoadVa(Double connectedLoadVa) {
    this.connectedLoadVa = connectedLoadVa;
  }

  public Double getConnectedLoadPf() {
    return connectedLoadPf;
  }

  public void setConnectedLoadPf(Double connectedLoadPf) {
    this.connectedLoadPf = connectedLoadPf;
  }

  public Boolean getIsGlobal() {
    return isGlobal;
  }

  public void setIsGlobal(Boolean global) {
    isGlobal = global;
  }
}
