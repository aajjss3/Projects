package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.analysis.Analysis;
import com.seatec.ela.app.dto.analysis.HMGAnalysis;
import com.seatec.ela.app.model.*;
import com.seatec.ela.app.util.FieldValidator;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class HMGAnalysisService {

  // Initial Scope is B767-300, B767-400, B757-200ETOPS, B757-300 (they are all etops)
  // These fleet should have HMG and HMG flightStage on Buses that have HMG loads in KVA
  // HMG load on AC node is AC.  HMG load on DC node is DC.
  // Which buses are relevant can vary for different aircraft
  // Typically, for the initial scope HMG AC Analysis Nodes:  "CFI", "LXR", "RXR", "ASBY"
  // Typically, for the initial scope HMG DC Analysis Nodes:  "DSBU", "BB1S", "HB61"

  // Fleets B767, B757 HMG DC Capacity
  private static final Double HMG_DC_CAPACITY = 50.0d;

  /**
   * Returns HMGAnalysis for B767-300, B767-400, B757-200ETOPS, B757-300 when HMG Generator Present.
   *
   * @param allNodesWithSummarizedLoads
   * @param analysis
   * @return
   */
  public Optional<HMGAnalysis> calculate(
      List<Node> allNodesWithSummarizedLoads, Analysis analysis) {

    Node generatorNode =
        allNodesWithSummarizedLoads.stream()
            .filter(
                n ->
                    ("HMG GEN".equalsIgnoreCase(n.getName())
                        && n.getNodeType() == NodeType.STANDBY_GEN))
            .findFirst()
            .orElse(null);
    if (generatorNode == null) {
      return Optional.empty();
    }

    double dcAmps = 0.0d;
    double wattsPhaseA = 0.0d;
    double varPhaseA = 0.0d;
    double wattsPhaseB = 0.0d;
    double varPhaseB = 0.0d;
    double wattsPhaseC = 0.0d;
    double varPhaseC = 0.0d;
    // adding all HMG loads (assumes no low voltage AC loads)
    for (Node node : allNodesWithSummarizedLoads) {
      if (NodeType.BUS.equals(node.getNodeType())) {
        for (SummarizedLoad summarizedLoad : node.getSummarizedLoads()) {
          if ("HMG".equalsIgnoreCase(summarizedLoad.getFlightPhase())
              && summarizedLoad.getSummaryType().equals(SummaryType.COMPONENTS)) {
            switch (summarizedLoad.getElectricalPhase()) {
              case DC:
                dcAmps += summarizedLoad.getW() / node.getVoltage();
                break;
              case ACA:
                wattsPhaseA += summarizedLoad.getW();
                varPhaseA += summarizedLoad.getVar();
                break;
              case ACB:
                wattsPhaseB += summarizedLoad.getW();
                varPhaseB += summarizedLoad.getVar();
                break;
              case ACC:
                wattsPhaseC += summarizedLoad.getW();
                varPhaseC += summarizedLoad.getVar();
                break;
            }
          }
        }
      }
    }
    double wattsAC = wattsPhaseA + wattsPhaseB + wattsPhaseC;
    double varAC = varPhaseA + varPhaseB + varPhaseC;
    double avgWattsPhase = wattsAC / 3;
    double avgVarPhase = varAC / 3;

    HMGAnalysis hmgAnalysis = new HMGAnalysis();
    hmgAnalysis.setAcTotalLoadKVA(LoadUtil.getVa(wattsAC / 1000d, varAC / 1000d));
    hmgAnalysis.setaPhaseKVA(LoadUtil.getVa(wattsPhaseA / 1000d, varPhaseA / 1000d));
    hmgAnalysis.setaPhasePf(LoadUtil.getPowerFactor(wattsPhaseA, varPhaseA));
    hmgAnalysis.setbPhaseKVA(LoadUtil.getVa(wattsPhaseB / 1000d, varPhaseB / 1000d));
    hmgAnalysis.setbPhasePf(LoadUtil.getPowerFactor(wattsPhaseB / 1000d, varPhaseB / 1000d));
    hmgAnalysis.setcPhaseKVA(LoadUtil.getVa(wattsPhaseC / 1000d, varPhaseC / 1000d));
    hmgAnalysis.setcPhasePf(LoadUtil.getPowerFactor(wattsPhaseC / 1000d, varPhaseC / 1000d));
    hmgAnalysis.setAvgPhaseKVA(LoadUtil.getVa(avgWattsPhase / 1000d, avgVarPhase / 1000d));
    hmgAnalysis.setAvgPhasePf(LoadUtil.getPowerFactor(avgWattsPhase / 1000d, avgVarPhase / 1000d));
    if (FieldValidator.isDoubleGreaterZero(generatorNode.getNominalPower())) {
      double capacityAC = generatorNode.getNominalPower();
      hmgAnalysis.setAcCapacityKVA(capacityAC / 1000d);
      double percentAc = LoadUtil.getVa(wattsAC, varAC) / capacityAC * 100d;
      hmgAnalysis.setAcPercentCapacity(percentAc);
      hmgAnalysis.setAcStatus(
          ElaAnalysisService.determineStatus(
              percentAc, analysis.getThresholdUpperLimit(), analysis.getThresholdLowerLimit()));
    } else {
      hmgAnalysis.setAcStatus(AnalysisStatus.FAIL);
    }
    hmgAnalysis.setDcTotalLoadAmps(dcAmps);
    hmgAnalysis.setDcCapacityAmps(HMG_DC_CAPACITY);
    double percentAmps = dcAmps / HMG_DC_CAPACITY * 100;
    hmgAnalysis.setDcPercentCapacity(percentAmps);
    hmgAnalysis.setDcStatus(
        ElaAnalysisService.determineStatus(
            percentAmps, analysis.getThresholdUpperLimit(), analysis.getThresholdLowerLimit()));

    return Optional.of(hmgAnalysis);
  }
}
