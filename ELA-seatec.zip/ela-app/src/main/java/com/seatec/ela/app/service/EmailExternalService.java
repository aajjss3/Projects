package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.email.ProjectChangeNotification;
import com.seatec.ela.app.exception.UnauthorizedException;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.util.enumeration.ProjectStatus;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import javax.mail.internet.InternetAddress;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailExternalService {

  private static Logger logger = LoggerFactory.getLogger(EmailExternalService.class);

  private static final String DEFAULT_NAME = "Team";

  @Autowired public JavaMailSender emailSender;

  @Autowired public KeycloakExternalService keycloakService;

  @Autowired private MailContentBuilder mailContentBuilder;

  @Value("${app.ela.application.email.enable:false}")
  boolean enableEmail;

  @Value("${app.ela.customer.name:Seatec}")
  String customerName;

  @Value("${spring.mail.properties.replyto:noreply@seatec.com}")
  String replyTo;

  @Value("${spring.mail.properties.replytodisplayname:No Reply}")
  String replyToName;

  @Value("${spring.mail.properties.from:noreply@seatec.com}")
  String from;

  @Value("${spring.mail.properties.fromdisplayname:SeaTec App Store}")
  String fromName;

  @Value("${spring.mail.properties.support.email:solutiondesk@seatec.com}")
  String supportEmail;

  @Value("${spring.mail.properties.login.url:https://apps-sandbox.seatec.com/ela}")
  String loginUrl;

  @Value("${spring.mail.properties.blacklist:.*@noemail.com}")
  String emailBlacklist;

  @Value("${spring.mail.properties.whitelist:.*}")
  String emailWhitelist;

  public void sendUserLoginEmail(UserRepresentation user, String tempPassword) {
    SimpleMailMessage message = new SimpleMailMessage();
    String email = user.getEmail();
    String name = user.getFirstName() + " " + user.getLastName();
    String userName = user.getUsername();

    if (fillFromField(message, email)) {
      message.setSentDate(new Date());
      message.setTo(email);
      String subject = mailContentBuilder.buildLoginSubject(customerName);
      message.setSubject(subject);
      String text =
          mailContentBuilder.buildLoginText(
              name, userName, tempPassword, loginUrl, supportEmail, customerName);
      message.setText(text);
      sendEmail(message);
    }
  }

  public void sendProjectUpdateEmail(Project project, ProjectStatus projectStatus) {
    String projectNumber = project.getNumber();
    String projectRevision = project.getRevisionLevel();
    String projectTitle = project.getTitle();
    String subject =
        mailContentBuilder.buildProjectSubject(
            customerName, projectNumber, projectRevision, projectTitle);
    String text;
    switch (projectStatus) {
      case SUBMITTED:
      case CHECKED:
      case CHECKER_REJECTED:
      case APPROVER_REJECTED:
        text =
            mailContentBuilder.buildProjectNotificationText(
                DEFAULT_NAME,
                loginUrl,
                supportEmail,
                customerName,
                projectNumber,
                projectRevision,
                projectTitle);
        break;
      case APPROVED:
        text =
            mailContentBuilder.buildProjectApprovalText(
                DEFAULT_NAME,
                loginUrl,
                supportEmail,
                customerName,
                projectNumber,
                projectRevision,
                projectTitle);
        break;
      default:
        return;
    }
    String[] email = findProjectUsers(project);
    SimpleMailMessage message = new SimpleMailMessage();
    if (fillFromField(message, email)) {
      message.setSentDate(new Date());
      message.setTo(email);
      message.setSubject(subject);
      message.setText(text);
      sendEmail(message);
    }
  }

  public void sendProjectChangeNotifications(
      List<ProjectChangeNotification> projectChangeNotifications) {
    if (!projectChangeNotifications.isEmpty()) {
      // iterate over each notification
      for (ProjectChangeNotification pcn : projectChangeNotifications) {

        // generate email context
        String[] emails = getUserEmailAddresses(pcn.getRecipients());
        String subject =
            mailContentBuilder.buildProjectChangeSubject(
                customerName,
                pcn.getProjectNumber(),
                pcn.getProjectRevision(),
                pcn.getProjectTitle());
        String text =
            mailContentBuilder.buildProjectChangeNotificationText(
                loginUrl, supportEmail, customerName, pcn.getProjectChanges());

        // send email
        SimpleMailMessage message = new SimpleMailMessage();
        if (fillFromField(message, emails)) {
          message.setSentDate(new Date());
          message.setTo(emails);
          message.setSubject(subject);
          message.setText(text);
          sendEmail(message);
        }
      }
    }
  }

  private boolean fillFromField(SimpleMailMessage message, String... email) {
    if (email == null || email.length == 0) {
      logger.warn("fillFromField: no email receipients found " + email);
      return false;
    }
    try {
      InternetAddress replyAddress = new InternetAddress(replyTo, replyToName);
      InternetAddress fromAddress = new InternetAddress(from, fromName);
      message.setFrom(fromAddress.toString());
      message.setReplyTo(replyAddress.toString());
    } catch (UnsupportedEncodingException ex) {
      logger.warn("fillFromField: error Exception" + ex.getLocalizedMessage());
      return false;
    }
    return true;
  }

  private boolean sendEmail(SimpleMailMessage message) {
    try {
      if (enableEmail) {
        emailSender.send(message);
      } else {
        message.setText("Content Blocked from Log");
        logger.info(" [Email disabled] smtp message not sent for {} ", message.toString());
      }
    } catch (MailException ex) {
      logger.warn("send mail exception " + ex.getLocalizedMessage());
      return false;
    }
    return true;
  }

  private String[] findProjectUsers(Project project) {
    List<String> emailAddresses = new ArrayList<>();
    try {
      UserRepresentation author = getUserRepresentation(project.getAuthor());
      if (author != null) {
        emailAddresses.add(author.getEmail());
      }
      UserRepresentation checker = getUserRepresentation(project.getCheckEngineer());
      if (checker != null) {
        emailAddresses.add(checker.getEmail());
      }
      UserRepresentation approver = getUserRepresentation(project.getApprovalEngineer());
      if (approver != null) {
        emailAddresses.add(approver.getEmail());
      }
      for (String userId : project.getCoauthors()) {
        UserRepresentation user = getUserRepresentation(userId);
        if (user != null) {
          emailAddresses.add(user.getEmail());
        }
      }
    } catch (UnauthorizedException ex) {
      logger.warn("findProjectUsers: error Exception" + ex.getLocalizedMessage());
      return new String[0];
    }

    // filter email list (blacklist & whitelist)
    return filterEmailList(emailAddresses, project.getTitle());
  }

  private String[] getUserEmailAddresses(List<String> userIds) {
    Pattern blacklistPattern = Pattern.compile(emailBlacklist);
    Pattern whitelistPattern = Pattern.compile(emailWhitelist);

    List<String> userEmailAddresses = new ArrayList<>();

    for (String userId : userIds) {
      UserRepresentation userRepresentation = getUserRepresentation(userId);
      if (userRepresentation != null
          && !blacklistPattern.matcher(userRepresentation.getEmail()).matches()
          && whitelistPattern.matcher(userRepresentation.getEmail()).matches()) {
        userEmailAddresses.add(userRepresentation.getEmail());
      }
    }

    return userEmailAddresses.toArray(new String[0]);
  }

  private UserRepresentation getUserRepresentation(String userId) {
    if (userId != null) {
      try {
        return keycloakService.findUser(userId);
      } catch (Exception ex) {
        logger.warn(
            "getUserRepresentation userId {} experienced an error skipping User Exceptionl {}",
            userId,
            ex.getLocalizedMessage());
        return null;
      }
    } else {
      logger.warn("getUserRepresentation unexpected null userId");
      return null;
    }
  }

  private String[] filterEmailList(List<String> emailAddresses, String projectTitle) {
    Pattern blacklistPattern = Pattern.compile(emailBlacklist);
    Pattern whitelistPattern = Pattern.compile(emailWhitelist);
    long unfilteredCount = emailAddresses.stream().filter(Objects::nonNull).count();

    String[] filteredEmailList =
        emailAddresses.stream()
            .filter(
                x ->
                    x != null
                        && (!blacklistPattern.matcher(x).matches()
                            && whitelistPattern.matcher(x).matches()))
            .toArray(String[]::new);

    if (filteredEmailList.length < unfilteredCount) {
      logger.warn(
          "email for project {} filtered send list from {} to remaining {} ",
          projectTitle,
          unfilteredCount,
          filteredEmailList);
    }

    return filteredEmailList;
  }
}
