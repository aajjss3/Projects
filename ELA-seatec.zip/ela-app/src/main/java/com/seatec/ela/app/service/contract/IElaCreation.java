package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.dto.ElaCreationDto;
import com.seatec.ela.app.model.Ela;
import java.io.InputStream;

public interface IElaCreation {
  public Ela createEla(ElaCreationDto elaDto, InputStream input);
}
