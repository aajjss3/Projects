package com.seatec.ela.app.service.report;

import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DATE_TIME_SHORT;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.FONT_FAMILY;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.PRIMARY_COLOR;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.SECONDARY_COLOR;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.convertActionTypeText;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.createBaseTable;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.createBlankRow;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.getBlankCell;

import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.dto.analysis.AnalysisLoad.Units;
import com.seatec.ela.app.dto.project.AircraftChangeGroupDTO;
import com.seatec.ela.app.dto.project.AircraftDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ChangeGroupDTO;
import com.seatec.ela.app.dto.project.LoadChangeDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.change.ChangeDTO;
import com.seatec.ela.app.dto.project.change.history.ChangeHistoryDTO;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.change.history.ComponentChangeHistory;
import com.seatec.ela.app.model.project.change.history.LoadChangeHistory;
import com.seatec.ela.app.model.project.change.history.NodeChangeHistory;
import com.seatec.ela.app.model.repository.project.ChangeGroupEffectivityDao;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.service.contract.IComponentService;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.service.contract.project.change.history.IChangeHistoryService;
import com.seatec.ela.app.service.contract.report.IPdfHistoryService;
import com.seatec.ela.app.util.FieldValidator;
import com.seatec.ela.app.util.PhaseUtil;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import com.seatec.ela.app.util.pdf.PdfFormatUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/** Perform the PDFTable and content generation for Project and ELA PDF service */
@Service
public class PdfHistoryService implements IPdfHistoryService {

  // globals
  private static final Font PROJECT_HISTORY_TABLE_HEADER_1_FONT =
      FontFactory.getFont(FONT_FAMILY, 14, PRIMARY_COLOR);
  private static final Font PROJECT_HISTORY_TABLE_HEADER_2_FONT =
      FontFactory.getFont(FONT_FAMILY, 12, PRIMARY_COLOR);
  private static final Font PROJECT_HISTORY_TABLE_HEADER_3_FONT =
      FontFactory.getFont(FONT_FAMILY, 10, PRIMARY_COLOR);
  private static final Font PROJECT_HISTORY_TABLE_HEADER_4_FONT =
      FontFactory.getFont(FONT_FAMILY, 8, SECONDARY_COLOR);

  private static final String[] PROJECT_HISTORY_TABLE_HEADERS = {
    "Action", "Component/Node", "Parent Node/Bus"
  };

  private static final String ELA_CHANGE_HISTORY_TITLE = "Change History";
  private static final String[] ELA_CHANGE_HISTORY_TABLE_HEADERS = {
    "Project Number", "Project Title", "Description", "Approved"
  };

  @Autowired private IAircraftService aircraftService;

  @Autowired private IChangeHistoryService changeHistoryService;

  @Autowired private IComponentService componentService;

  @Autowired private IElaService elaService;

  @Autowired private ChangeGroupEffectivityDao changeGroupEffectivityDao;

  @Autowired private IProjectService projectService;

  @Autowired private PdfFormatUtil pdfFormatUtil;

  @Autowired
  @Qualifier("mapAll")
  private ModelMapper mapper;

  public PdfPTable generateElaChangeHistory(String aircraftShipNo) {
    PdfPTable pdfPTable = createBaseTable(ELA_CHANGE_HISTORY_TABLE_HEADERS.length);

    List<AssignedProjectDTO> projectDTOS =
        projectService
            .getApprovedProjects(
                aircraftShipNo, null, null, null, null, null, true, null, null, "created", true)
            .getContents();

    // page header
    PdfPCell titleRow = getBlankCell();
    titleRow.addElement(new Paragraph(ELA_CHANGE_HISTORY_TITLE, PdfFormatUtil.createFont(1)));
    titleRow.setColspan(ELA_CHANGE_HISTORY_TABLE_HEADERS.length);
    pdfPTable.addCell(titleRow);

    // table > header
    for (String changeHistoryColumnName : ELA_CHANGE_HISTORY_TABLE_HEADERS) {
      PdfPCell headerRowFirstColumn = getBlankCell();
      headerRowFirstColumn.addElement(new Phrase(changeHistoryColumnName));
      pdfPTable.addCell(headerRowFirstColumn);
    }

    // table > body
    if (projectDTOS.isEmpty()) {
      // project number
      PdfPCell bodyRowEmptyColumnCells = getBlankCell();
      bodyRowEmptyColumnCells.setColspan(ELA_CHANGE_HISTORY_TABLE_HEADERS.length);
      bodyRowEmptyColumnCells.addElement(new Phrase("No projects found"));
      pdfPTable.addCell(bodyRowEmptyColumnCells);
    } else {
      for (ProjectDTO projectDTO : projectDTOS) {
        // project number
        PdfPCell bodyRowNumberColumnCell = getBlankCell();
        bodyRowNumberColumnCell.addElement(new Phrase(projectDTO.getNumber()));
        pdfPTable.addCell(bodyRowNumberColumnCell);

        // project title
        PdfPCell bodyRowTitleColumnCell = getBlankCell();
        bodyRowTitleColumnCell.addElement(new Phrase(projectDTO.getTitle()));
        pdfPTable.addCell(bodyRowTitleColumnCell);

        // project description
        PdfPCell bodyRowDescriptionColumnCell = getBlankCell();
        bodyRowDescriptionColumnCell.addElement(new Phrase(projectDTO.getDescription()));
        pdfPTable.addCell(bodyRowDescriptionColumnCell);

        // project approval date
        PdfPCell bodyRowApprovalColumnCell = getBlankCell();
        bodyRowApprovalColumnCell.addElement(
            new Phrase(DATE_TIME_SHORT.format(projectDTO.getApproved())));
        pdfPTable.addCell(bodyRowApprovalColumnCell);
      }
    }

    return pdfPTable;
  }

  /**
   * Generates a PDFPTable for all Revision History (changes) related to this project
   *
   * @param changeGroups - List of Project Change Group Entities
   * @return PDFPTable instance
   */
  public PdfPTable generateProjectChangeHistory(
      List<ChangeGroup> changeGroups, boolean isApproved) {
    // manual creation of PDF Table in order to force settings
    PdfPTable changeHistoryTable = new PdfPTable(1);
    changeHistoryTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    changeHistoryTable.setWidthPercentage(100);
    changeHistoryTable.setKeepTogether(false);

    // grab and convert change group entity to dto
    List<ChangeGroupDTO> changeGroupDtos =
        changeGroups.stream()
            .map(cg -> mapper.map(cg, ChangeGroupDTO.class))
            .collect(Collectors.toList());

    // iterate over change group DTOs
    for (ChangeGroupDTO changeGroupDTO : changeGroupDtos) {
      PdfPTable changeGroupTable = createBaseTable();
      changeGroupTable.setSpacingAfter(15f);

      // Change Group Name first row
      PdfPCell changeGroupTitleRow = getBlankCell();
      changeGroupTitleRow.setPaddingBottom(10f);
      changeGroupTitleRow.addElement(
          new Phrase(
              String.format("Change Group: %s", changeGroupDTO.getName()),
              PROJECT_HISTORY_TABLE_HEADER_2_FONT));
      changeGroupTable.addCell(changeGroupTitleRow);

      // verify changes exist within Change Group
      if (!changeGroupDTO.getChanges().isEmpty()) {
        PdfPTable dataTable = generateHistoryTable(changeGroupDTO, isApproved);
        changeGroupTable.addCell(dataTable);
        changeHistoryTable.addCell(changeGroupTable);
      }
    }

    return changeHistoryTable;
  }

  private List<AircraftDTO> getAircraftDTOList(ChangeGroupDTO changeGroupDTO) {
    return changeGroupDTO.getAircraftChangeGroups().stream()
        .map(AircraftChangeGroupDTO::getAircraft)
        .collect(Collectors.toList());
  }

  private PdfPTable generateHistoryTable(ChangeGroupDTO changeGroupDTO, boolean isApproved) {
    // get change DTOs for change group
    List<ChangeDTO> changes = changeGroupDTO.getChanges();

    Units unit = Units.KVA;

    PdfPTable pdfPTable = createBaseTable();

    // get aircraft DTOs in change group
    List<AircraftDTO> aircraftDTOs = getAircraftDTOList(changeGroupDTO);

    // get first ship in list of aircraftDTOs
    AircraftDTO aircraftDTO = aircraftDTOs.get(0);
    Aircraft firstAircraftInList =
        getAircraftEntity(aircraftDTO.getId(), aircraftDTO.getAircraftShipNo());
    Fleet firstAircraftFleet = firstAircraftInList.getFleet();

    // get operating mode(s)
    List<String> operatingModes = getOperatingModes(firstAircraftFleet);

    // get flight phase(s)
    List<FlightPhaseDto> flightPhases = getFlightPhases(firstAircraftFleet, true);

    List<ChangeHistoryDTO> changeHistoryDTOS = new ArrayList<>();

    // only perform the section below if a component change is present
    if (changes.stream().anyMatch(c -> c.getComponentChange() != null)) {
      // normalize "pre" values from different sources based on approval status
      // doing outside all FOR loops to reduce recurring calls
      changeHistoryDTOS = changeHistoryService.findAllByChangeGroupDTO(changeGroupDTO, isApproved);
    }

    // iterate over changeDTOs
    for (ChangeDTO changeDTO : changes) {
      boolean isNodeChange = changeDTO.getNodeChange() != null;
      String nodeOrComponentName =
          isNodeChange
              ? changeDTO.getNodeChange().getName()
              : changeDTO.getComponentChange().getElectIdent()
                  + " - "
                  + changeDTO.getComponentChange().getName();

      // iterate over operating modes
      for (String operatingMode : operatingModes) {
        String changeLabel =
            generateChangeLabel(
                isNodeChange,
                changeDTO,
                nodeOrComponentName,
                isNodeChange ? "Node/Bus" : operatingMode);
        PdfPCell blueBgCell = pdfFormatUtil.pdfPCellBlueBackgroundWithText(changeLabel, 1);
        pdfPTable.addCell(blueBgCell);

        // not applicable per operating mode if node change
        // because we dont show pre/post values in those scenarios
        if (isNodeChange) {
          PdfPCell blankRow = createBlankRow(1);
          pdfPTable.addCell(blankRow);

          break;
        } else {
          if (!changeHistoryDTOS.isEmpty()) {
            // get history for changeId (filter main list)
            List<ChangeHistoryDTO> changeHistories =
                getChangeHistoryByChangeId(changeHistoryDTOS, changeDTO.getId());

            // group change summary by aircraft pre values
            // allows us to group/show "most common" loads at top then
            // less common below it
            Map<String, List<AircraftDTO>> aircraftLoadGroups =
                getLoadChangeGroupings(aircraftDTOs, changeHistories, flightPhases, operatingMode);

            if (!aircraftLoadGroups.isEmpty()) {
              // get all load changes
              List<LoadChangeHistory> loadChangeHistoryList =
                  getLoadChangeHistoryByChangeHistory(changeHistories);

              if (!loadChangeHistoryList.isEmpty()) {
                // get list of matching load change history records based on operating mode
                List<LoadChangeHistory> loadChangeHistoryByOperatingMode =
                    getLoadChangeHistoryByOperatingMode(loadChangeHistoryList, operatingMode);

                if (!loadChangeHistoryByOperatingMode.isEmpty()) {
                  PdfPTable loadHistoryTable =
                      generateLoadHistoryTable(
                          changeDTO,
                          aircraftLoadGroups,
                          loadChangeHistoryByOperatingMode,
                          flightPhases,
                          operatingMode,
                          unit);
                  pdfPTable.addCell(loadHistoryTable);
                }
              }
            }
          }
        }
      }
    }

    return pdfPTable;
  }

  private String generateChangeLabel(
      boolean isNodeChange, ChangeDTO changeDTO, String nodeOrComponentName, String operatingMode) {

    String parentNodeOrComponentName =
        isNodeChange
            ? ""
            : "on "
                + changeDTO.getNodeName()
                + PhaseUtil.getPhaseLabel(changeDTO.getComponentChange().getElectricalPhase());

    return String.format(
        "Change: %s '%s' %s (%S)",
        convertActionTypeText(changeDTO.getAction()),
        nodeOrComponentName,
        parentNodeOrComponentName,
        PdfFormatUtil.convertOperatingModeText(operatingMode));
  }

  private PdfPTable generateLoadHistoryTable(
      ChangeDTO change,
      Map<String, List<AircraftDTO>> aircraftLoadGroups,
      List<LoadChangeHistory> loadChangeHistories,
      List<FlightPhaseDto> flightPhases,
      String operatingMode,
      Units unit) {
    int totalTableColumns = flightPhases.size() + 1;

    // blue table header row
    PdfPTable pdfPTable = createBaseTable(totalTableColumns);

    float totalWidth = pdfPTable.getTotalWidth();
    float flightPhaseColumnWidth = totalTableColumns + 2 / totalWidth;
    float[] tableWidths = new float[totalTableColumns];

    tableWidths[0] = flightPhaseColumnWidth * 2;
    for (int i = 1; i < totalTableColumns; i++) {
      tableWidths[i] = flightPhaseColumnWidth;
    }

    pdfPTable.setWidths(tableWidths);

    // set header row
    pdfPTable.addCell(PdfFormatUtil.getBlankCell()); // skip first column

    // set default values for most common hashMap
    Map.Entry<String, List<AircraftDTO>> mostCommonHashMapEntry =
        aircraftLoadGroups.entrySet().stream().findFirst().get();
    String mostCommonKey = mostCommonHashMapEntry.getKey();
    int mostCommonValueSize = mostCommonHashMapEntry.getValue().size();
    boolean isMultipleEntries = aircraftLoadGroups.entrySet().size() > 1;

    // determine which element is the most common and display that at beginning
    // if more elements exist then display those after and itemize the aircrafts impacted
    if (isMultipleEntries) {
      for (Map.Entry<String, List<AircraftDTO>> entry : aircraftLoadGroups.entrySet()) {
        String k = entry.getKey();
        List<AircraftDTO> v = entry.getValue();
        if (v.size() > mostCommonValueSize) {
          mostCommonValueSize = v.size();
          mostCommonKey = k;
        }
      }
    }

    // display most common
    List<AircraftDTO> mostCommonAircrafts = aircraftLoadGroups.get(mostCommonKey);

    // output load table (showing before/after values if single entry)
    appendLoadHistoryTable(
        pdfPTable,
        change,
        loadChangeHistories,
        mostCommonAircrafts,
        flightPhases,
        operatingMode,
        unit,
        isMultipleEntries);

    if (isMultipleEntries) {
      // remove most common key from hashMap and display the remaining keys
      aircraftLoadGroups.remove(mostCommonKey);

      for (Map.Entry<String, List<AircraftDTO>> entry : aircraftLoadGroups.entrySet()) {
        List<AircraftDTO> val = entry.getValue();

        // output load table (showing before/after values)
        appendLoadHistoryTable(
            pdfPTable, change, loadChangeHistories, val, flightPhases, operatingMode, unit, false);
      }
    }

    return pdfPTable;
  }

  private void appendLoadHistoryTable(
      PdfPTable pdfPTable,
      ChangeDTO change,
      List<LoadChangeHistory> loadChangeHistories,
      List<AircraftDTO> aircraftDTOS,
      List<FlightPhaseDto> flightPhases,
      String operatingMode,
      Units unit,
      boolean isSummaryView) {
    List<String> originalValues = new ArrayList<>();
    originalValues.add("Before");

    List<String> modifiedValues = new ArrayList<>();
    modifiedValues.add("After");

    // all aircrafts in this group contain same pre-values so pick any to display
    List<LoadChangeHistory> loadChangeHistoryByAircraft =
        getLoadChangeHistoryByAircraft(
            loadChangeHistories, aircraftDTOS.get(0).getAircraftShipNo());

    // iterate over flight phases and loads to populate before/after values
    for (FlightPhaseDto flightPhase : flightPhases) {
      Double originalVal = 0d;
      Double modifiedVal = 0d;

      PdfPCell flightPhaseCell =
          pdfFormatUtil.flightPhaseTableHeaderRowCell(
              PdfFormatUtil.convertFlightPhaseText(flightPhase.getName()), 8f);
      pdfPTable.addCell(flightPhaseCell);

      // original value
      for (LoadChangeHistory load : loadChangeHistoryByAircraft) {
        if (flightPhase.getName().equalsIgnoreCase(load.getFlightPhase())
            && operatingMode.equalsIgnoreCase(load.getOperatingMode())) {
          originalVal = load.getVa();
          break;
        }
      }

      // append value to list
      originalValues.add(
          Units.KVA.equals(unit)
              ? PdfFormatUtil.DECIMAL_FORMAT_3_PLACE_NO_LEAD.format(originalVal)
              : PdfFormatUtil.DECIMAL_FORMAT_1_PLACE_NO_LEAD.format(originalVal));

      if (!isSummaryView) {
        // modified value
        for (LoadChangeDTO load : change.getComponentChange().getLoadChanges()) {
          if (flightPhase.getName().equalsIgnoreCase(load.getFlightPhase())
              && operatingMode.equalsIgnoreCase(load.getOperatingMode())) {
            modifiedVal = load.getVa();
            break;
          }
        }

        // append to modified values list
        modifiedValues.add(
            Units.KVA.equals(unit)
                ? PdfFormatUtil.DECIMAL_FORMAT_3_PLACE_NO_LEAD.format(modifiedVal)
                : PdfFormatUtil.DECIMAL_FORMAT_1_PLACE_NO_LEAD.format(modifiedVal));
      }
    }

    // "Before" row output
    // do not show if action is "ADD"
    if (!ActionType.ADD.equals(change.getAction())) {
      for (String columnValue : originalValues) {
        pdfPTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, false));
      }
    }

    // "After" row output
    // do not show if action is "DELETE"
    if (!isSummaryView && !ActionType.DELETE.equals(change.getAction())) {
      for (int i = 0; i < modifiedValues.size(); i++) {
        String columnValue = modifiedValues.get(i);
        boolean isHighlighted = (i != 0) && !originalValues.get(i).equalsIgnoreCase(columnValue);
        pdfPTable.addCell(pdfFormatUtil.flightPhaseTableBodyRowCell(columnValue, isHighlighted));
      }
    }

    // output aircrafts included (sorted asc)
    int numberOfColumns = pdfPTable.getNumberOfColumns();
    String commaSeparatedAircraftList =
        "Aircrafts Included: "
            + aircraftDTOS.stream()
                .map(AircraftDTO::getAircraftShipNo)
                .sorted()
                .collect(Collectors.joining(", "));
    PdfPCell aircraftListCell =
        pdfFormatUtil.flightPhaseTableBodyRowCell(commaSeparatedAircraftList, false);
    aircraftListCell.setColspan(numberOfColumns);
    pdfPTable.addCell(aircraftListCell);

    // add blank row
    PdfPCell blankRow = createBlankRow(numberOfColumns);
    pdfPTable.addCell(blankRow);
  }

  private Aircraft getAircraftEntity(Long id, String shipNbr) {
    return aircraftService
        .findById(id)
        .orElseThrow(
            () -> new NotFoundException("Unable to locate aircraft '" + shipNbr + "'", Level.WARN));
  }

  private List<ChangeHistoryDTO> getChangeHistoryByAircraft(
      List<ChangeHistoryDTO> changeHistoryDTOS, AircraftDTO aircraftDTO) {
    return changeHistoryDTOS.stream()
        .map(
            f -> {
              ChangeHistoryDTO changeHistoryDTO = new ChangeHistoryDTO();

              // check node change history for a match
              for (NodeChangeHistory t : f.getNodeChanges()) {
                if (t.getAircraft()
                    .getAircraftShipNo()
                    .equalsIgnoreCase(aircraftDTO.getAircraftShipNo())) {
                  changeHistoryDTO.getNodeChanges().add(t);
                }
              }

              // check component change history for a match
              for (ComponentChangeHistory t : f.getComponentChanges()) {
                if (t.getAircraft()
                    .getAircraftShipNo()
                    .equalsIgnoreCase(aircraftDTO.getAircraftShipNo())) {
                  changeHistoryDTO.getComponentChanges().add(t);
                }
              }

              // check load change history for a match
              for (LoadChangeHistory t : f.getLoadChanges()) {
                if (t.getAircraft()
                    .getAircraftShipNo()
                    .equalsIgnoreCase(aircraftDTO.getAircraftShipNo())) {
                  changeHistoryDTO.getLoadChanges().add(t);
                }
              }

              changeHistoryDTO.setChangeId(f.getChangeId());

              return changeHistoryDTO;
            })
        .collect(Collectors.toList());
  }

  private List<ChangeHistoryDTO> getChangeHistoryByChangeId(
      List<ChangeHistoryDTO> changeHistoryDTOS, UUID changeId) {
    return changeHistoryDTOS.stream()
        .map(
            f -> {
              ChangeHistoryDTO changeHistoryDTO = new ChangeHistoryDTO();
              changeHistoryDTO.setChangeId(f.getChangeId());

              // check node change history for a match
              for (NodeChangeHistory t : f.getNodeChanges()) {
                if (t.getChange().getId().equals(changeId)) {
                  changeHistoryDTO.getNodeChanges().add(t);
                }
              }

              // check component change history for a match
              for (ComponentChangeHistory t : f.getComponentChanges()) {
                if (t.getChange().getId().equals(changeId)) {
                  changeHistoryDTO.getComponentChanges().add(t);
                }
              }

              // check load change history for a match
              for (LoadChangeHistory t : f.getLoadChanges()) {
                if (t.getChange().getId().equals(changeId)) {
                  changeHistoryDTO.getLoadChanges().add(t);
                }
              }

              return changeHistoryDTO;
            })
        .collect(Collectors.toList());
  }

  private Map<String, List<AircraftDTO>> getLoadChangeGroupings(
      List<AircraftDTO> aircraftDTOS,
      List<ChangeHistoryDTO> changeHistories,
      List<FlightPhaseDto> flightPhases,
      String operatingMode) {
    Map<String, List<AircraftDTO>> aircraftLoadGroups = new HashMap<>();

    for (AircraftDTO aircraft : aircraftDTOS) {
      boolean isMatch = true;

      // get change history for aircraft (includes: node, component, and load)
      List<ChangeHistoryDTO> loadChangeHistoryByAircraft =
          getChangeHistoryByAircraft(changeHistories, aircraft);

      // get load history list
      List<LoadChangeHistory> loadChangeHistories =
          loadChangeHistoryByAircraft.stream()
              .flatMap(f -> f.getLoadChanges().stream())
              .collect(Collectors.toList());

      // skip check if no aircraft load history data
      if (loadChangeHistories.isEmpty()) {
        continue;
      }

      // get load history for operating mode
      List<LoadChangeHistory> loadChangeHistoriesByOperatingMode =
          getLoadChangeHistoryByOperatingMode(loadChangeHistories, operatingMode);

      // iterate over saved map items
      Map<String, List<AircraftDTO>> tempMap = new HashMap<>();
      for (Map.Entry<String, List<AircraftDTO>> entry : aircraftLoadGroups.entrySet()) {
        String key = entry.getKey();

        // iterate over saved aircrafts in map item
        List<AircraftDTO> tempList = entry.getValue();

        for (AircraftDTO aircraftDTO1 : tempList) {
          // bypass same ship comparison
          if (aircraft.getAircraftShipNo().equalsIgnoreCase(aircraftDTO1.getAircraftShipNo())) {
            continue;
          }

          // iterate over flight phases
          for (FlightPhaseDto flightPhaseDto : flightPhases) {
            // get load history for flight phase
            LoadChangeHistory loadChangeHistoryByFlightPhase =
                getLoadChangeHistoryByFlightPhase(
                    loadChangeHistoriesByOperatingMode, flightPhaseDto.getName());

            // get load history for aircraft and flight phase
            LoadChangeHistory loadChangeHistoryByAircraftAndFlightPhase =
                getLoadChangeHistoryByAircraftAndFlightPhase(
                    loadChangeHistoriesByOperatingMode,
                    aircraft.getAircraftShipNo(),
                    flightPhaseDto.getName());

            // check if values differ (if so, set match to false and exit loop)
            if (FieldValidator.isDoublesChanged(
                loadChangeHistoryByFlightPhase.getVa(),
                loadChangeHistoryByAircraftAndFlightPhase.getVa())) {
              isMatch = false;
              break;
            }
          }

          // exit loop if match is false
          if (!isMatch) {
            break;
          }
        }

        // append to temp map
        if (isMatch) {
          tempList.add(aircraft);
          tempMap.put(key, tempList);
        }
      }

      if (isMatch) {
        aircraftLoadGroups.putAll(tempMap);
      }

      // add new summary group if missing
      if (aircraftLoadGroups.isEmpty() || !isMatch) {
        List<AircraftDTO> aircraftDTOS1 = new ArrayList<>();
        aircraftDTOS1.add(aircraft);
        aircraftLoadGroups.put(aircraft.getAircraftShipNo(), aircraftDTOS1);
      }
    }

    return aircraftLoadGroups;
  }

  private List<LoadChangeHistory> getLoadChangeHistoryByAircraft(
      List<LoadChangeHistory> loadChangeHistories, String aircraftShipNbr) {
    return loadChangeHistories.stream()
        .filter(f -> f.getAircraft().getAircraftShipNo().equalsIgnoreCase(aircraftShipNbr))
        .collect(Collectors.toList());
  }

  private List<LoadChangeHistory> getLoadChangeHistoryByChangeHistory(
      List<ChangeHistoryDTO> changeHistoryDTOList) {
    return changeHistoryDTOList.stream()
        .flatMap(f -> f.getLoadChanges().stream())
        .collect(Collectors.toList());
  }

  private List<LoadChangeHistory> getLoadChangeHistoryByOperatingMode(
      List<LoadChangeHistory> loadChangeHistories, String operatingMode) {
    return loadChangeHistories.stream()
        .filter(f -> f.getOperatingMode().equalsIgnoreCase(operatingMode))
        .collect(Collectors.toList());
  }

  private LoadChangeHistory getLoadChangeHistoryByFlightPhase(
      List<LoadChangeHistory> loadChangeHistories, String flightPhase) {
    return loadChangeHistories.stream()
        .filter(f -> f.getFlightPhase().equalsIgnoreCase(flightPhase))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    "Unable to locate load change history for flight phase " + flightPhase,
                    Level.WARN));
  }

  private LoadChangeHistory getLoadChangeHistoryByAircraftAndFlightPhase(
      List<LoadChangeHistory> loadChangeHistories, String aircraftShipNbr, String flightPhase) {
    return loadChangeHistories.stream()
        .filter(
            f ->
                f.getFlightPhase().equalsIgnoreCase(flightPhase)
                    && f.getAircraft().getAircraftShipNo().equalsIgnoreCase(aircraftShipNbr))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    "Unable to locate load change history for aircraft '"
                        + aircraftShipNbr
                        + "' and flight phase "
                        + flightPhase,
                    Level.WARN));
  }

  private List<FlightPhaseDto> getFlightPhases(Fleet fleet, boolean excludeBatterySupplied) {
    return FlightPhase.getFlightPhases(
        fleet.getManufacturer(), fleet.isEtops(), fleet.getName(), excludeBatterySupplied);
  }

  private List<String> getOperatingModes(Fleet fleet) {
    return OperatingMode.getOperatingModes(fleet.getManufacturer(), fleet.getName());
  }
}
