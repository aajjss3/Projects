package com.seatec.ela.app.service;

import com.seatec.ela.app.config.ClientConfig.Boeing;
import com.seatec.ela.app.dto.analysis.AutoLandCondition;
import com.seatec.ela.app.dto.analysis.TRUAutoLandAnalysisDTO;
import com.seatec.ela.app.dto.analysis.TRUsAutoLandAnalysisDTO;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.stereotype.Service;

@Service
public class TRUAutoLandAnalysisService {

  private static final String DC1 = "DC1";
  private static final String DC2 = "DC2";
  private static final String BB = "BB";
  private static final String TRU1 = "TRU 1";
  private static final String TRU2 = "TRU 2";
  private static final String TRU3 = "TRU 3";

  private static Logger logger = LoggerFactory.getLogger(TRUAutoLandAnalysisService.class);

  public AutoLandCondition getAutoLandCondition(
      String aircraftShipNo,
      List<Node> nodes,
      double thresholdLowerLimit,
      double thresholdUpperLimit) {
    AutoLandCondition condition = new AutoLandCondition();
    // if autoland analysis fails for any reason - log the cause and return an empty dto which
    // allows the other types of analysis to be returned to the caller.
    try {
      TRUAutoLandAnalysisDTO tru1 =
          getTRUAutoLandAnalysis(
              DC1, TRU1, nodes, thresholdLowerLimit, thresholdUpperLimit, aircraftShipNo);
      TRUAutoLandAnalysisDTO tru2 =
          getTRUAutoLandAnalysis(
              DC2, TRU2, nodes, thresholdLowerLimit, thresholdUpperLimit, aircraftShipNo);
      TRUAutoLandAnalysisDTO tru3 =
          getTRUAutoLandAnalysis(
              BB, TRU3, nodes, thresholdLowerLimit, thresholdUpperLimit, aircraftShipNo);

      AnalysisStatus status = AnalysisStatus.PASS;
      if (tru1.getAnalysisStatus() == AnalysisStatus.FAIL
          || tru2.getAnalysisStatus() == AnalysisStatus.FAIL
          || tru3.getAnalysisStatus() == AnalysisStatus.FAIL) {
        status = AnalysisStatus.FAIL;
      } else if (tru1.getAnalysisStatus() == AnalysisStatus.WARN
          || tru2.getAnalysisStatus() == AnalysisStatus.WARN
          || tru3.getAnalysisStatus() == AnalysisStatus.WARN) {
        status = AnalysisStatus.WARN;
      }

      condition.setTruAutoLandAnalysis(new TRUsAutoLandAnalysisDTO(tru1, tru2, tru3, status));
    } catch (Exception e) {
      logger.error(
          "Unable to determine the auto land analysis for aircraft ship no: "
              + aircraftShipNo
              + ". See the stacktrace below for the reason: ",
          e);
    }
    return condition;
  }

  private TRUAutoLandAnalysisDTO getTRUAutoLandAnalysis(
      String busName,
      String transformerName,
      List<Node> nodes,
      double thresholdLowerLimit,
      double thresholdUpperLimit,
      String aircraftShipNo) {

    Node busNode =
        nodes.stream()
            .filter(n -> n.getName().equalsIgnoreCase(busName))
            .findFirst()
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to determine the Auto Land Analysis since there is no node: '"
                            + busName
                            + "' for aircraft ship no: "
                            + aircraftShipNo,
                        Level.ERROR));
    SummarizedLoad load =
        busNode.getSummarizedLoads().stream()
            .filter(
                l ->
                    l.getFlightPhase().equalsIgnoreCase(Boeing.HOLD_LAND.toString())
                        && l.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN)
            .findFirst()
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to determine the Auto Land Analysis since there is no Summarized Load with a flight phase of: 'HOLD_LAND' for aircraft ship no: "
                            + aircraftShipNo,
                        Level.ERROR));

    double totalInAmps = LoadUtil.getAmps(load.getW(), busNode.getVoltage());

    Node transformerNode =
        nodes.stream()
            .filter(n -> n.getName().equalsIgnoreCase(transformerName))
            .findFirst()
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to determine the Auto Land Analysis since there is no node: '"
                            + transformerName
                            + "' for aircraft ship no: "
                            + aircraftShipNo,
                        Level.ERROR));

    double ratio = (totalInAmps / transformerNode.getNominalPower()) * 100d;

    AnalysisStatus status;
    if (ratio <= thresholdLowerLimit) {
      status = AnalysisStatus.PASS;
    } else if (ratio < thresholdUpperLimit) {
      status = AnalysisStatus.WARN;
    } else {
      status = AnalysisStatus.FAIL;
    }

    return new TRUAutoLandAnalysisDTO(
        totalInAmps, ratio, status, transformerNode.getNominalPower());
  }
}
