package com.seatec.ela.app.service.contract.project;

import com.seatec.ela.app.model.project.NodeChange;
import java.util.Optional;
import java.util.UUID;

/** Service for dealing with Project > ChangeGroup > Change > NodeChange */
public interface INodeChangeService {

  Optional<NodeChange> findById(UUID id);

  NodeChange save(NodeChange entity);
}
