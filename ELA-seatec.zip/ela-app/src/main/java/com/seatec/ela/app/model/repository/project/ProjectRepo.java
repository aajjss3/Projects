package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.model.project.Project;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepo
    extends CrudRepository<Project, UUID>, JpaSpecificationExecutor<Project> {

  Page<Project> findAllByOrderByTitleAsc(Pageable pageable);

  Page<Project>
      findAllByCheckEngineerAndCheckedIsNullAndSubmittedIsNotNullAndRejectedIsNullOrApprovalEngineerAndApprovedIsNullAndSubmittedIsNotNullAndRejectedIsNullAndCheckedIsNotNull(
          @Param("approvalEngineer") String approvalEngineer,
          @Param("checkEngineer") String checkEngineer,
          Pageable pageable);

  List<Project> findAllByApprovedIsNull();

  @Query(
      value =
          "select string_agg(distinct f.name, ', ' order by f.name) as fleets FROM project p "
              + "LEFT JOIN change_group cg ON cg.project_id = p.id "
              + "LEFT JOIN aircraft_change_group acg ON acg.change_group_id = cg.id "
              + "LEFT JOIN aircraft a ON acg.aircraft_id = a.id "
              + "LEFT JOIN fleet f ON a.fleet_id = f.id "
              + "where p.id = :projectId",
      nativeQuery = true)
  String findFleetsByProject(UUID projectId);
}
