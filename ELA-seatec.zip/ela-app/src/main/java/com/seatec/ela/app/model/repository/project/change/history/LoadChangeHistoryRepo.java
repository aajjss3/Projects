package com.seatec.ela.app.model.repository.project.change.history;

import com.seatec.ela.app.model.project.change.history.LoadChangeHistory;
import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LoadChangeHistoryRepo extends CrudRepository<LoadChangeHistory, UUID> {
  List<LoadChangeHistory> findByChangeId(@Param("changeId") UUID changeId);
}
