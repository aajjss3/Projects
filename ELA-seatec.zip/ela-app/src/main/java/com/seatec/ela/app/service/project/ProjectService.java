package com.seatec.ela.app.service.project;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.email.ProjectChange;
import com.seatec.ela.app.dto.email.ProjectChangeNotification;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectCommentDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.ProjectWrapperDTO;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ForbiddenException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.ProjectComment;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectDAO;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.model.repository.specification.FilterSpecification;
import com.seatec.ela.app.service.ElaService;
import com.seatec.ela.app.service.EmailExternalService;
import com.seatec.ela.app.service.KeycloakService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.util.PhaseUtil;
import com.seatec.ela.app.util.enumeration.AssignedProjectRole;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import com.seatec.ela.app.util.enumeration.ProjectStatus;
import com.seatec.ela.app.util.enumeration.QueryOperation;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.keycloak.representations.idm.UserRepresentation;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProjectService implements IProjectService {

  private static final List<String> ADMIN_ROLES =
      Arrays.asList(KeycloakRole.ENGINEERING_ADMIN.getName(), KeycloakRole.IT_ADMIN.getName());
  private static final List<String> APPROVER_AUTHOR_CHECKER_ROLES =
      Arrays.asList(
          KeycloakRole.APPROVER.getName(),
          KeycloakRole.AUTHOR.getName(),
          KeycloakRole.CHECKER.getName());
  public static final List<String> ALL_ROLES_EXCEPT_VIEWER =
      Arrays.asList(
          KeycloakRole.APPROVER.getName(),
          KeycloakRole.AUTHOR.getName(),
          KeycloakRole.CHECKER.getName(),
          KeycloakRole.ENGINEERING_ADMIN.getName(),
          KeycloakRole.IT_ADMIN.getName());

  @Autowired private ProjectRepo repository;

  @Autowired private EmailExternalService emailService;

  @Autowired private AircraftRepository aircraftRepo;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private KeycloakService keycloakService;

  @Autowired private ElaService elaService;

  @Autowired private ProjectAnalysisService projectAnalysisService;

  @Autowired private ProjectDAO projectDAO;

  @Autowired
  @Qualifier("mapAllFlatProject")
  ModelMapper mapperPartial;

  @Autowired
  @Qualifier("mapAll")
  ModelMapper mapperAll;

  public ProjectService() {}

  public ProjectService(
      ProjectRepo projectRepo,
      EmailExternalService emailExternalService,
      AircraftRepository aircraftRepository,
      ChangeGroupRepo changeGroupRepo,
      KeycloakService keycloakService,
      ElaService elaService,
      @Qualifier("mapAllFlatProject") ModelMapper mapperPartial,
      @Qualifier("mapAll") ModelMapper mapperAll) {
    this.repository = projectRepo;
    emailService = emailExternalService;
    aircraftRepo = aircraftRepository;
    this.changeGroupRepo = changeGroupRepo;
    this.keycloakService = keycloakService;
    this.elaService = elaService;
    this.mapperPartial = mapperPartial;
    this.mapperAll = mapperAll;
  }

  @Transactional(readOnly = true)
  public PaginationDTO<ProjectDTO> getAllProjects(String userId, Integer page, Integer size) {

    // Viewers are only allowed to see approved projects
    if (!keycloakService.isUserValidAndInRoles(userId, ALL_ROLES_EXCEPT_VIEWER)) {
      return new PaginationDTO<ProjectDTO>();
    }

    Page<Project> projectPage;
    PaginationDTO<ProjectDTO> paginationDTO = new PaginationDTO<>();
    if (page != null && size != null) {
      Pageable pageable = createPageRequest(page, size, "started");
      projectPage = repository.findAllByOrderByTitleAsc(pageable);
      setPageMetadata(page, size, projectPage, paginationDTO);
    } else {
      projectPage = repository.findAllByOrderByTitleAsc(Pageable.unpaged());
    }

    List<ProjectDTO> projectsDTOs =
        projectPage.getContent().stream()
            .map(project -> mapperPartial.map(project, ProjectDTO.class))
            .collect(Collectors.toList());
    paginationDTO.addContents(projectsDTOs);
    return paginationDTO;
  }

  public Optional<Project> findById(UUID id) {
    return repository.findById(id);
  }

  public Optional<Project> findById(UUID id, String userId) {
    Optional<Project> project = findById(id);
    if (project.isPresent()) {
      boolean isApproved = project.get().getApproved() != null;
      if (isApproved || keycloakService.isUserValidAndInRoles(userId, ALL_ROLES_EXCEPT_VIEWER)) {
        return project;
      } else {
        throw new ForbiddenException(
            "Viewers are only allowed to view approved projects.", Level.ERROR);
      }
    }
    return Optional.empty();
  }

  @Transactional
  public Project initialSave(Project project) {
    // set status fields to empty on initial create
    project.setApproved(null);
    project.setChecked(null);
    project.setRetired(null);
    project.setSubmitted(null);

    return repository.save(project);
  }

  @Transactional
  public void updateProject(Project entity, UUID id) {
    Project projectEntity =
        repository
            .findById(id)
            .orElseThrow(
                () -> new NotFoundException("Unable to locate project (" + id + ")", Level.ERROR));

    projectEntity.setApprovalEngineer(entity.getApprovalEngineer());
    projectEntity.setCheckEngineer(entity.getCheckEngineer());
    projectEntity.setDescription(entity.getDescription());
    projectEntity.setMaintenanceDescription(entity.getMaintenanceDescription());
    projectEntity.setNumber(entity.getNumber());
    projectEntity.setRevisionLevel(entity.getRevisionLevel());
    projectEntity.setStarted(entity.getStarted());
    projectEntity.setTitle(entity.getTitle());
    projectEntity.setCoauthors(entity.getCoauthors());
  }

  /**
   * Deletes a project based on business rule(s).
   *
   * @param id - project entity unique identifier
   * @param userId - keycloak user unique identifier
   */
  @Transactional
  public void deleteProject(UUID id, String userId) {
    Project project =
        repository
            .findById(id)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        String.format("Unable to locate Project (id: '%s')", id), Level.ERROR));

    /*

     business rule(s)...
     Authors => can delete their own projects
     Co-Authors => can delete projects they are co-author on
     Checkers => can delete projects they are checker on
     Approvers => can delete projects they are approver on
     Engineering/IT Admins => can delete any project

    */
    if (!isUserAProjectContributor(project, userId)) {
      if (!keycloakService.isUserValidAndInRoles(userId, ADMIN_ROLES)) {
        throw new BadRequestException(
            "Unable to delete Project: User does not have valid permissions.", Level.ERROR);
      }
    }

    repository.deleteById(id);
  }

  /**
   * retrieve all projects that have not been approved (project.approved is null). Use server side
   * pagination and sorting.
   */
  // NOTE: there is a field returned called 'fleets' that is not directly on the Project domain
  // object. Therefore I could not get springs pagination api to work.
  // Also, for 3 fields the sorting is done not on the database field but on a ui display field so
  // could not use sql's OFFSET and LIMIT clauses for pagination. Instead, sorting and pagination is
  // handled in the java code after querying all projects.
  @Transactional(readOnly = true)
  public PaginationDTO<AssignedProjectDTO> getMyProjects(
      String userId, Integer page, Integer size, String sortField, boolean sortAscending) {
    PaginationDTO<AssignedProjectDTO> paginationDTO = new PaginationDTO<>();
    List<AssignedProjectDTO> projectDTOs;

    // if pagination is required
    if (page != null && size != null) {
      // if user is admin role, they should see all projects (excluding approved)
      List<AssignedProjectDTO> paginatedDTOs = null;
      if (keycloakService.isUserValidAndInRoles(userId, ADMIN_ROLES)) {
        paginatedDTOs = projectDAO.findAllByApprovedIsNull();
      } else {
        paginatedDTOs = projectDAO.getMyProjects(userId);
      }
      Integer count = paginatedDTOs.size();
      projectDTOs = sortAndPaginate(paginatedDTOs, page, size, sortField, sortAscending, true);
      Integer totalPages = (count % size > 0) ? (count / size) + 1 : count / size;
      setPageMetadata(page, size, totalPages, count.longValue(), paginationDTO);
    }
    // if results are not paginated (i.e. return all)
    else {
      // if user is admin role, they should see all projects (excluding approved)
      if (keycloakService.isUserValidAndInRoles(userId, ADMIN_ROLES)) {
        projectDTOs = projectDAO.findAllByApprovedIsNull();
      } else {
        projectDTOs = projectDAO.getMyProjects(userId);
      }
      sort(projectDTOs, sortField, sortAscending, true);
    }

    // set the role
    for (AssignedProjectDTO projectDTO : projectDTOs) {
      if (projectDTO.getApprovalEngineer() != null
          && projectDTO.getApprovalEngineer().equals(userId)) {
        projectDTO.setRole(AssignedProjectRole.APPROVER);
      } else if (projectDTO.getCheckEngineer() != null
          && projectDTO.getCheckEngineer().equals(userId)) {
        projectDTO.setRole(AssignedProjectRole.CHECKER);
      } else if (projectDTO.getAuthor() != null && projectDTO.getAuthor().equals(userId)) {
        projectDTO.setRole(AssignedProjectRole.AUTHOR);
      } else if (projectDTO.getCoauthors() != null && projectDTO.getCoauthors().contains(userId)) {
        projectDTO.setRole(AssignedProjectRole.COAUTHOR);
      } else {
        projectDTO.setRole(AssignedProjectRole.NONE);
      }
    }
    paginationDTO.addContents(projectDTOs);
    return paginationDTO;
  }

  @Transactional(readOnly = true)
  public PaginationDTO<ProjectWrapperDTO> getPendingReviewProjects(
      String userId, Integer page, Integer size) {

    Page<Project> projectPage;
    PaginationDTO<ProjectWrapperDTO> paginationDTO = new PaginationDTO<>();
    if (page != null && size != null) {
      Pageable pageable = createPageRequest(page, size, "submitted");
      projectPage =
          repository
              .findAllByCheckEngineerAndCheckedIsNullAndSubmittedIsNotNullAndRejectedIsNullOrApprovalEngineerAndApprovedIsNullAndSubmittedIsNotNullAndRejectedIsNullAndCheckedIsNotNull(
                  userId, userId, pageable);
      setPageMetadata(page, size, projectPage, paginationDTO);
    } else {
      projectPage =
          repository
              .findAllByCheckEngineerAndCheckedIsNullAndSubmittedIsNotNullAndRejectedIsNullOrApprovalEngineerAndApprovedIsNullAndSubmittedIsNotNullAndRejectedIsNullAndCheckedIsNotNull(
                  userId, userId, Pageable.unpaged());
    }

    List<ProjectDTO> checker = new ArrayList<>();
    List<ProjectDTO> approver = new ArrayList<>();
    for (Project project : projectPage.getContent()) {
      // a user can either be an approver or a checker but not both.
      if (userId.equals(project.getApprovalEngineer()) && project.getApproved() == null) {
        approver.add(mapperPartial.map(project, ProjectDTO.class));
      } else if (userId.equals(project.getCheckEngineer()) && project.getChecked() == null) {
        checker.add(mapperPartial.map(project, ProjectDTO.class));
      }
    }

    paginationDTO.addContents(Collections.singletonList(new ProjectWrapperDTO(checker, approver)));
    return paginationDTO;
  }

  @Transactional
  public void submitProject(UUID projectId, String userId, ProjectCommentDTO comment) {
    Project project = repository.findById(projectId).get();

    // cannot submit the project if the user is not the author or a coauthor
    if (!userId.equals(project.getAuthor()) && !project.getCoauthors().contains(userId)) {
      throw new BadRequestException(
          "Unable to Submit: The user is not the author or coauthor", Level.WARN);
    }

    // cannot submit the project if the project does not contain any change groups, or if any of the
    // change groups associated with a project does not
    // contain a change.
    List<ChangeGroup> changeGroups = project.getChangeGroups();
    if (changeGroups.isEmpty()) {
      throw new ForbiddenException(
          "Unable to Submit: No changes have been created for this project, reference 'Section 3: Changes'",
          Level.WARN);
    }
    changeGroups.stream()
        .forEach(
            changeGroup -> {
              if (changeGroup.getChanges().isEmpty()) {
                throw new ForbiddenException(
                    "Unable to Submit: An effectivity change group does not contain changes, reference change group "
                        + changeGroup.getName(),
                    Level.WARN);
              }
            });

    checkChangeGroupsEffectivity(changeGroups, ProjectStatus.SUBMITTED.toString());

    // cannot submit the project if its missing a check engineer or approval engineer
    if (project.getCheckEngineer() == null || project.getApprovalEngineer() == null) {
      throw new ForbiddenException(
          "Unable to Submit: Please select a Checker and Approver", Level.WARN);
    }

    // append comment
    project.addComment(setAndConvertProjectCommentDTOToProjectComment(comment, userId));

    project.setRejected(null);
    project.setSubmitted(Instant.now());
    emailService.sendProjectUpdateEmail(project, ProjectStatus.SUBMITTED);
  }

  @Transactional
  public void checkProject(UUID projectId, String userId, ProjectCommentDTO comment) {
    Project project = repository.findById(projectId).get();

    // cannot check a project if it has not been submitted
    if (project.getSubmitted() == null) {
      throw new ForbiddenException(
          "Unable to Sign-off: The project has not been submitted.", Level.WARN);
    }

    // cannot check a project if its has been rejected
    if (project.getRejected() != null) {
      throw new ForbiddenException(
          "Unable to Sign-off: The project has been rejected.", Level.WARN);
    }

    // cannot check a project if it has already been approved or checked
    if (project.getApproved() != null || project.getChecked() != null) {
      throw new ForbiddenException(
          "Unable to Sign-off: Project "
              + project.getNumber()
              + " has already been checked or approved",
          Level.WARN);
    }

    // only the check engineer can check the project
    if (!project.getCheckEngineer().equals(userId)) {
      throw new ForbiddenException("Unable to Sign-off: The user is not authorized.", Level.WARN);
    }

    checkChangeGroupsEffectivity(project.getChangeGroups(), ProjectStatus.CHECKED.toString());

    // append comment
    project.addComment(setAndConvertProjectCommentDTOToProjectComment(comment, userId));

    project.setChecked(Instant.now());
    emailService.sendProjectUpdateEmail(project, ProjectStatus.CHECKED);
  }

  @Transactional
  public void approveProject(UUID projectId, String userId, ProjectCommentDTO comment) {
    Project project = repository.findById(projectId).get();

    // cannot approve a project if it has not already been submitted and checked
    if (project.getSubmitted() == null || project.getChecked() == null) {
      throw new ForbiddenException(
          "Unable to Approve: The project has not been submitted and checked.", Level.WARN);
    }

    // cannot approve a project if its has been rejected
    if (project.getRejected() != null) {
      throw new ForbiddenException("Unable to Approve: The project has been rejected.", Level.WARN);
    }

    // only the approval engineer can approve a project
    if (!project.getApprovalEngineer().equals(userId)) {
      throw new ForbiddenException("Unable to Approve: The user is not authorized.", Level.WARN);
    }

    checkChangeGroupsEffectivity(project.getChangeGroups(), ProjectStatus.APPROVED.toString());

    // append comment
    project.addComment(setAndConvertProjectCommentDTOToProjectComment(comment, userId));

    project.setChecked(Instant.now());
    emailService.sendProjectUpdateEmail(project, ProjectStatus.CHECKED);

    project.setApproved(Instant.now());

    // rebase ELA
    elaService.rebase(project.getChangeGroups());

    // distribute email notification(s)
    emailService.sendProjectUpdateEmail(project, ProjectStatus.APPROVED);

    // send project authors notification that were potentially impacted by ELA changes
    List<ProjectChangeNotification> projectChangeNotifications =
        getProjectChangeNotifications(project);
    emailService.sendProjectChangeNotifications(projectChangeNotifications);
  }

  @Transactional
  public void rejectProject(UUID projectId, ProjectCommentDTO comment, String userId, String role) {

    Project project = repository.findById(projectId).get();
    boolean checkerUser = role.equals("checker") && project.getCheckEngineer().equals(userId);
    boolean approverUser = role.equals("approver") && project.getApprovalEngineer().equals(userId);

    // only the check engineer or approval engineer can reject a project.
    if (!checkerUser && !approverUser) {
      throw new ForbiddenException("Unable to Reject: The user is not authorized.", Level.WARN);
    }

    // cannot reject a project if it has not been submitted
    if (project.getSubmitted() == null) {
      throw new ForbiddenException(
          "Unable to Reject: The project has not been submitted.", Level.WARN);
    }

    // cannot reject a project if it has already been approved
    if (project.getApproved() != null) {
      throw new ForbiddenException(
          "Unable to Reject: The project has already been approved.", Level.WARN);
    }

    project.setRejected(Instant.now());
    project.setChecked(null);

    // append comment
    project.addComment(setAndConvertProjectCommentDTOToProjectComment(comment, userId));

    if (checkerUser) {
      emailService.sendProjectUpdateEmail(project, ProjectStatus.CHECKER_REJECTED);
    } else if (approverUser) {
      emailService.sendProjectUpdateEmail(project, ProjectStatus.APPROVER_REJECTED);
    }
  }

  /** override any existing coauthors with the list of coauthors passed in */
  @Transactional
  public void setProjectCoauthors(UUID projectId, List<String> coauthors) {
    Project project = repository.findById(projectId).get();
    project.setCoauthors(coauthors);
  }

  @Transactional
  public void saveProjectAnalysis(UUID projectId) {
    Project project = repository.findById(projectId).get();

    ProjectReportDTO projectAnalysis =
        projectAnalysisService.getProjectAnalysis(project.getChangeGroups());

    project.setAnalysis(projectAnalysis);
  }

  /**
   * return a collection of approved projects. filter approved projects by the parameters passed in.
   * if 'isEntire' is true then return each projects changeGroups. If 'isEntire' is false then do
   * not return a projects changeGroups. Filter projectDescription, projectTitle,
   * maintenanceDescription by partial case insensitive matches. Filter projectNumber,
   * aircraftShipNo, fleetName by exact matches. Use server side pagination if 'page' and 'size' are
   * not null.
   */
  @Transactional(readOnly = true)
  public PaginationDTO<AssignedProjectDTO> getApprovedProjects(
      String aircraftShipNo,
      String fleetName,
      String projectNumber,
      String projectDescription,
      String projectTitle,
      String maintenanceDescription,
      boolean isEntire,
      Integer page,
      Integer size,
      String sortField,
      boolean sortAscending) {

    Specification<Project> projectSpec =
        Specification.where(
                new FilterSpecification<Project>(QueryOperation.NOT_NULL, "approved", null))
            .and(new FilterSpecification<Project>(QueryOperation.LIKE, "number", projectNumber))
            .and(
                new FilterSpecification<Project>(
                    QueryOperation.LIKE, "description", projectDescription))
            .and(new FilterSpecification<Project>(QueryOperation.LIKE, "title", projectTitle))
            .and(
                new FilterSpecification<Project>(
                    QueryOperation.LIKE, "maintenanceDescription", maintenanceDescription));

    // if aircraftShipNo and fleetNumber are both passed in then only query by aircraftShipNo.
    if (aircraftShipNo != null || fleetName != null) {
      List<Long> aircraftIds = new ArrayList<>();

      if (aircraftShipNo != null) {
        Aircraft aircraft = aircraftRepo.findByAircraftShipNo(aircraftShipNo).get(0);
        aircraftIds.add(aircraft.getId());
      } else {
        List<Aircraft> aircrafts = aircraftRepo.findAllByFleet_Name(fleetName);

        // if aircraft list is empty
        if (aircrafts.isEmpty()) {
          return new PaginationDTO<AssignedProjectDTO>();
        }

        aircraftIds.addAll(aircrafts.stream().map(Aircraft::getId).collect(Collectors.toList()));
      }

      List<ChangeGroup> changeGroups = changeGroupRepo.findAllByAircrafts(aircraftIds);

      // if no change groups are found based on aircraft ids
      if (changeGroups.isEmpty()) {
        return new PaginationDTO<AssignedProjectDTO>();
      }
      projectSpec =
          projectSpec.and(
              new FilterSpecification<Project>(QueryOperation.IN, "changeGroups", changeGroups));
    }

    Page<Project> projectPage = repository.findAll(projectSpec, Pageable.unpaged());

    // convert from Project domain entity to AssignedProjectDTO
    List<AssignedProjectDTO> projectDTOs =
        (isEntire)
            ? projectPage.getContent().stream()
                .map(project -> mapperAll.map(project, AssignedProjectDTO.class))
                .collect(Collectors.toList())
            : projectPage.getContent().stream()
                .map(project -> mapperPartial.map(project, AssignedProjectDTO.class))
                .collect(Collectors.toList());

    // retrieve the project's fleets and set on the AssignedProjectDTO
    projectDTOs.stream().forEach(p -> p.setFleets(repository.findFleetsByProject(p.getId())));

    PaginationDTO<AssignedProjectDTO> paginationDTO = new PaginationDTO<>();
    // if pagination is required
    if (page != null && size != null) {
      List<AssignedProjectDTO> paginatedProjectDTOs =
          sortAndPaginate(projectDTOs, page, size, sortField, sortAscending, false);
      paginationDTO.addContents(paginatedProjectDTOs);
      Long count = new Long(projectDTOs.size());
      Integer totalPages =
          (count.intValue() % size > 0) ? (count.intValue() / size) + 1 : count.intValue() / size;
      setPageMetadata(page, size, totalPages, count, paginationDTO);
    } else { // if no pagination
      sort(projectDTOs, sortField, sortAscending, false);
      paginationDTO.addContents(projectDTOs);
    }

    return paginationDTO;
  }

  private List<ProjectChangeNotification> getProjectChangeNotifications(Project publishedProject) {
    List<Project> notApprovedProjects = getAllProjectsExceptApproved();
    List<ProjectChangeNotification> changeNotifications = new ArrayList<>();

    // grab all elas in approved project
    List<Ela> approvedProjectElas = getProjectElas(publishedProject.getChangeGroups());
    List<Change> approvedProjectChanges = getProjectChanges(publishedProject.getChangeGroups());

    // iterate over not approved projects
    for (Project notApprovedProject : notApprovedProjects) {
      // grab all elas in not-approved project
      List<Ela> elasInNotApprovedProject = getProjectElas(notApprovedProject.getChangeGroups());

      // go to next project if no elas present
      if (elasInNotApprovedProject.isEmpty()) {
        continue;
      }

      // only take latest Ela from [createdDate] sorted list
      Ela elaInNotApprovedProject = elasInNotApprovedProject.get(0);

      // check if project has overlapping ela(s) that could be impacted
      boolean projectContainsMatchingEla = approvedProjectElas.contains(elaInNotApprovedProject);

      // if project contains matching ela (ie. not-approved project potentially impacted)
      if (projectContainsMatchingEla) {
        ProjectChangeNotification pcn =
            new ProjectChangeNotification(
                notApprovedProject.getTitle(),
                notApprovedProject.getNumber(),
                notApprovedProject.getRevisionLevel(),
                getRecipients(notApprovedProject));

        List<ProjectChange> projectChanges = new ArrayList<>();
        for (ChangeGroup cg : notApprovedProject.getChangeGroups()) {
          ProjectChange projectChange = new ProjectChange();
          projectChange.setChangeGroupName(cg.getName());

          List<Change> changes = cg.getChanges();

          // verify a change group contains at least one change
          if (!changes.isEmpty()) {
            // iterate over changes (not approved project)
            List<String> conflictingChanges = new ArrayList<>();

            for (Change change : changes) {
              // check against nodeName
              boolean isMatchingChange =
                  approvedProjectChanges.stream()
                      .anyMatch(
                          change1 -> change1.getNodeName().equalsIgnoreCase(change.getNodeName()));
              if (isMatchingChange) {
                // append notification to list if affected
                conflictingChanges.add(convertChangeToDetailedLabel(change));
              }
            }

            if (!conflictingChanges.isEmpty()) {
              projectChange.setConflictingChanges(conflictingChanges);
              projectChanges.add(projectChange);
            }
          }
        }

        pcn.setProjectChanges(projectChanges);
        changeNotifications.add(pcn);
      }
    }

    return changeNotifications;
  }

  private String convertChangeToDetailedLabel(Change change) {
    return String.format(
        "%s %s %s %s",
        change.getAction().toString().toUpperCase(),
        change.getNodeChange() != null
            ? change.getNodeChange().getName()
            : change.getComponentChange().getElectIdent(),
        change.getComponentChange() != null
            ? PhaseUtil.getPhaseLabel(change.getComponentChange().getElectricalPhase())
            : "",
        change.getNodeChange() != null ? "(Node/Bus)" : "(Component)");
  }

  private List<Project> getAllProjectsExceptApproved() {
    return repository.findAllByApprovedIsNull();
  }

  private List<String> getRecipients(Project project) {
    List<String> recipients = new ArrayList<>();

    // append authors
    if (project.getAuthor() != null && !project.getAuthor().isEmpty()) {
      recipients.add(project.getAuthor());
    }

    // append co-authors
    recipients.addAll(project.getCoauthors());

    // append check engineer
    if (project.getCheckEngineer() != null && !project.getCheckEngineer().isEmpty()) {
      recipients.add(project.getCheckEngineer());
    }

    // append approval engineer
    if (project.getApprovalEngineer() != null && !project.getApprovalEngineer().isEmpty()) {
      recipients.add(project.getApprovalEngineer());
    }

    return recipients;
  }

  private List<Change> getProjectChanges(List<ChangeGroup> changeGroups) {
    return changeGroups.stream()
        .filter(cg -> !cg.getChanges().isEmpty())
        .flatMap(cg -> cg.getChanges().stream())
        .collect(Collectors.toList());
  }

  private List<Ela> getProjectElas(List<ChangeGroup> changeGroups) {
    return changeGroups.stream()
        .filter(cg -> !cg.getChanges().isEmpty())
        .flatMap(cg -> cg.getAircraftChangeGroups().stream())
        .map(AircraftChangeGroup::getAircraft)
        .flatMap(
            aircraft ->
                aircraft.getElas().stream()
                    .sorted(Comparator.comparing(Ela::getCreatedDate).reversed()))
        .collect(Collectors.toList());
  }

  private boolean isUserAProjectContributor(Project project, String userId) {
    return (project.getApprovalEngineer() != null && project.getApprovalEngineer().equals(userId))
        || (project.getCheckEngineer() != null && project.getCheckEngineer().equals(userId))
        || (project.getAuthor() != null && project.getAuthor().equals(userId))
        || (project.getCoauthors() != null && project.getCoauthors().contains(userId));
  }

  private void checkChangeGroupsEffectivity(List<ChangeGroup> changeGroups, String state) {
    long acgCount =
        changeGroups.stream().filter(cg -> cg.getAircraftChangeGroups().size() != 0).count();
    if (acgCount == 0) {
      throw new BadRequestException(
          "Unable to transition to " + state + ": There are no aircrafts in the Effectivity ",
          Level.WARN);
    }
  }

  private void setPageMetadata(
      Integer page, Integer size, Page<Project> projectPage, PaginationDTO<?> paginationDTO) {
    // if no records are found and the request is for the first page then return an empty result
    // set. for any other page return an empty result set.
    if (page > 1 && page > projectPage.getTotalPages()) {
      throw new BadRequestException(
          "The page you requested is greater than the total number of pages.", Level.WARN);
    }
    paginationDTO.setMetadata(
        page, size, projectPage.getTotalPages(), projectPage.getTotalElements());
  }

  private void setPageMetadata(
      Integer page, Integer size, Integer totalPages, Long count, PaginationDTO<?> paginationDTO) {
    // if no records are found and the request is for the first page then return an empty result
    // set. for any other page return an empty result set.
    if (page > 1 && page > totalPages) {
      throw new BadRequestException(
          "The page you requested is greater than the total number of pages.", Level.WARN);
    }
    paginationDTO.setMetadata(page, size, totalPages, count);
  }

  private Pageable createPageRequest(Integer page, Integer size, String sortField) {
    // pagination starts at 0 in the api but the client passes in 1 for the first page.
    return PageRequest.of(page - 1, size, Sort.by(sortField).descending());
  }

  private ProjectComment setAndConvertProjectCommentDTOToProjectComment(
      ProjectCommentDTO comment, String userId) {
    comment.setAuthor(userId);
    UserRepresentation user = keycloakService.findUser(userId);
    comment.setDisplayName(user.getFirstName() + " " + user.getLastName());
    comment.setCreated(Instant.now());

    return mapperPartial.map(comment, ProjectComment.class);
  }

  /**
   * sort
   *
   * @param projectDTOs
   * @param sortField
   * @param sortAscending
   * @param sortApprovedByStatus - if false then sort approved by the actual date
   */
  private void sort(
      List<AssignedProjectDTO> projectDTOs,
      String sortField,
      boolean sortAscending,
      boolean sortApprovedByStatus) {

    Comparator<AssignedProjectDTO> field = null;

    if (sortField.equalsIgnoreCase("title")) {
      field = fieldComparator(AssignedProjectDTO::getTitle);
    } else if (sortField.equalsIgnoreCase("description")) {
      field = fieldComparator(AssignedProjectDTO::getDescription);
    } else if (sortField.equalsIgnoreCase("number")) {
      field = fieldComparator(AssignedProjectDTO::getNumber);
    } else if (sortField.equalsIgnoreCase("fleets")) {
      field = fieldComparator(AssignedProjectDTO::getFleets);
    } else if (sortField.equalsIgnoreCase("started")) {
      field = fieldComparator(AssignedProjectDTO::getStarted);
    } else if (sortField.equalsIgnoreCase("submitted")) {
      field = fieldComparator(AssignedProjectDTO::getSubmittedStatus);
    } else if (sortField.equalsIgnoreCase("checked")) {
      field = fieldComparator(AssignedProjectDTO::getCheckedStatus);
    } else if (sortField.equalsIgnoreCase("approved")) {
      if (sortApprovedByStatus) {
        field = fieldComparator(AssignedProjectDTO::getApprovedStatus);
      } else {
        field = fieldComparator(AssignedProjectDTO::getApproved);
      }
    } else if (sortField.equalsIgnoreCase("created")) {
      field = fieldComparator(AssignedProjectDTO::getCreated);
    }

    if (sortAscending) {
      projectDTOs.sort(field);
    } else {
      projectDTOs.sort(field.reversed());
    }
  }

  /**
   * sort and paginate
   *
   * @param projectDTOs
   * @param page
   * @param size
   * @param sortField
   * @param sortAscending
   * @param sortApprovedByStatus - if false then sort approved by the actual date
   * @return
   */
  private List<AssignedProjectDTO> sortAndPaginate(
      List<AssignedProjectDTO> projectDTOs,
      Integer page,
      Integer size,
      String sortField,
      boolean sortAscending,
      boolean sortApprovedByStatus) {

    // if page requested it greater than total number of pages
    if ((page - 1) * size > projectDTOs.size()) {
      return new ArrayList<AssignedProjectDTO>();
    }

    sort(projectDTOs, sortField, sortAscending, sortApprovedByStatus);

    // paginate
    List<AssignedProjectDTO> paginatedProjectDTOs = new ArrayList<>();
    int totalProjects = projectDTOs.size();
    int indexOfLastPaginatedProject =
        projectDTOs.size() > page * size ? page * size : totalProjects;
    paginatedProjectDTOs.addAll(
        projectDTOs.subList(((page - 1) * size), indexOfLastPaginatedProject));
    return paginatedProjectDTOs;
  }

  @SuppressWarnings("rawtypes")
  private static <T extends Comparable> Comparator<AssignedProjectDTO> fieldComparator(
      Function<AssignedProjectDTO, T> func) {
    return Comparator.comparing(func, Comparator.nullsFirst(Comparator.naturalOrder()));
  }
}
