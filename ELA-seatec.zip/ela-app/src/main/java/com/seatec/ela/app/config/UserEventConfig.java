package com.seatec.ela.app.config;

import com.seatec.ela.app.aop.userevent.LogConfig;
import com.seatec.ela.app.aop.userevent.LogDetail;
import com.seatec.ela.app.aop.userevent.LogUserTrackConfig;
import javax.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Aspect
@Component
public class UserEventConfig {
  private static final Logger logger = LoggerFactory.getLogger(UserEventConfig.class);

  public UserEventConfig() {}

  @Pointcut(
      "within(com.seatec.ela.app..*)  && @within(org.springframework.web.bind.annotation.RestController)")
  public void restControllers() {}

  @Pointcut(
      "@annotation(org.springframework.web.bind.annotation.RequestMapping) "
          + "|| @annotation(org.springframework.web.bind.annotation.GetMapping)"
          + "|| @annotation(org.springframework.web.bind.annotation.PostMapping)"
          + "|| @annotation(org.springframework.web.bind.annotation.PatchMapping)"
          + "|| @annotation(org.springframework.web.bind.annotation.PutMapping)"
          + "|| @annotation(org.springframework.web.bind.annotation.DeleteMapping)")
  public void mappingAnnotations() {}

  @Pointcut("execution(@(@org.springframework.web.bind.annotation.RequestMapping *) * *(..))")
  public void requestMappingAnnotations() {}

  @Around("restControllers() && requestMappingAnnotations() && mappingAnnotations()")
  public Object aroundAllControllerMethod(ProceedingJoinPoint joinPoint) throws Throwable {
    try {
      Object methodReturnObject = joinPoint.proceed();
      logIfConfigured(joinPoint, methodReturnObject, null, true);
      return methodReturnObject;
    } catch (Exception ex) {
      logIfConfigured(joinPoint, null, ex.getLocalizedMessage(), false);
      throw ex;
    }
  }

  private void logIfConfigured(
      ProceedingJoinPoint joinPoint,
      Object methodReturnObject,
      String errorMessage,
      boolean success) {
    RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
    if (requestAttributes != null) {
      HttpServletRequest request =
          ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
      LogUserTrackConfig config = LogConfig.findMatchingConfig(joinPoint);
      if (request != null && config != null) {
        String successMessage = success ? "SUCCESS" : "ERROR";
        String details =
            LogDetail.createDetail(request, config, joinPoint, methodReturnObject, errorMessage);
        logger.info(
            "User Event: {} {} {}, details: {}",
            config.getActionString(),
            config.getConcern(),
            successMessage,
            details);
      }
    }
  }
}
