package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.validator.annotation.NodeOrComponentChange;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NodeOrComponentChangeValidator
    implements ConstraintValidator<NodeOrComponentChange, Change> {

  @Override
  public void initialize(NodeOrComponentChange constraintAnnotation) {}

  @Override
  public boolean isValid(Change change, ConstraintValidatorContext context) {
    boolean isComponentChange =
        change.getComponentChange() != null
            && change.getComponentElectIdent() != null
            && !change.getComponentElectIdent().isEmpty()
            && (change.getNodeName() == null || !change.getNodeName().isEmpty());
    boolean isNodeChange = change.getNodeChange() != null;
    return isComponentChange || isNodeChange;
  }
}
