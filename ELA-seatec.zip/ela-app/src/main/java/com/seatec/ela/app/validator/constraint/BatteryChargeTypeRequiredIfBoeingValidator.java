package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.service.FleetService;
import com.seatec.ela.app.validator.annotation.BatteryChargeTypeRequiredIfBoeing;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

public class BatteryChargeTypeRequiredIfBoeingValidator
    implements ConstraintValidator<BatteryChargeTypeRequiredIfBoeing, AircraftDto> {

  private static final String BOEING_MANUFACTURER = "boeing";

  @Autowired FleetService fleetService;

  public BatteryChargeTypeRequiredIfBoeingValidator() {}

  public BatteryChargeTypeRequiredIfBoeingValidator(FleetService fleetService) {
    this.fleetService = fleetService;
  }

  @Override
  public void initialize(BatteryChargeTypeRequiredIfBoeing constraintAnnotation) {}

  @Override
  public boolean isValid(AircraftDto aircraftDto, ConstraintValidatorContext context) {
    boolean isValid = true;

    if (aircraftDto.getFleetId() != null) {
      Optional<Fleet> fleet = fleetService.findById(aircraftDto.getFleetId());

      if (fleet.isPresent()) {
        boolean isBatteryChargeTypeRequired =
            fleet.get().getManufacturer() != null
                && fleet.get().getManufacturer().equalsIgnoreCase(BOEING_MANUFACTURER);

        if (isBatteryChargeTypeRequired && aircraftDto.getBatteryCharge() == null) {
          isValid = false;
        }
      }
    }

    return isValid;
  }
}
