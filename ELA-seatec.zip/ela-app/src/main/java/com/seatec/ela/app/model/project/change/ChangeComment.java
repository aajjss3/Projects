package com.seatec.ela.app.model.project.change;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.base.BaseEntity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "change_comment")
public class ChangeComment extends BaseEntity {

  @Column(length = 512)
  private String comment;

  // the keycloak user id of the user making the comment
  @Column(length = 127)
  private String author;

  // friendly name to display of the user making the comment
  @Column(name = "display_name", length = 127)
  private String displayName;

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "change_id", updatable = false, nullable = false)
  private Change change;

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public Change getChange() {
    return change;
  }

  public void setChange(Change change) {
    this.change = change;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }
}
