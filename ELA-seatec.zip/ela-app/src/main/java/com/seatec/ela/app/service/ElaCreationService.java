package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.ElaCreationDto;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.EfficiencyTableRepo;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.NodeStructureRepository;
import com.seatec.ela.app.model.structure.NodeStructure;
import com.seatec.ela.app.service.contract.IElaCreation;
import com.seatec.ela.app.util.csv.CsvData;
import com.seatec.ela.app.util.csv.CsvImport;
import com.seatec.ela.app.util.ela.ElaCreationBean;
import com.seatec.ela.app.util.ela.ElaFactory;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ElaCreationService implements IElaCreation {
  @Autowired private AircraftRepository aircraftRepo;

  @Autowired private NodeStructureRepository nodeStructRepo;

  @Autowired private EfficiencyTableRepo effTableRepo;

  @Autowired private ElaRepository elaRepo;

  @Autowired private NodeService nodeService;

  @Autowired private Validator validator;

  @Autowired private CsvImport csvImport;

  @Autowired private ElaFactory elaFactory;

  @Override
  @Transactional
  public Ela createEla(ElaCreationDto elaDto, InputStream inputStream) {
    ElaCreationBean bean = createValidElaCreationBean(elaDto, inputStream);
    CsvData csvData = null;
    if (!bean.isAircraftClone()) {
      csvData = csvImport.importAirbusCsv(inputStream);
    }
    Ela ela = elaFactory.createEla(bean, csvData);
    elaRepo.save(ela);
    return ela;
  }

  private ElaCreationBean createValidElaCreationBean(
      ElaCreationDto elaDto, InputStream inputStream) {
    ElaCreationBean bean = new ElaCreationBean();
    bean.setElaName(elaDto.getName());
    if (inputStream != null) {
      bean.setFilePresent(true);
    }
    Aircraft aircraft = aircraftRepo.findById(elaDto.getAircraftId()).orElse(null);
    if (aircraft != null) {
      bean.setAircraft(aircraft);
      bean.setAircraftArchived(aircraft.isArchived());
      if (aircraft.getElas().size() > 0) {
        throw new ConflictException(
            "Ela already exists for Aircraft ShipNo " + aircraft.getAircraftShipNo());
      }
      Fleet fleet = aircraft.getFleet();
      if (fleet != null) {
        bean.setFleet(fleet);
        bean.setFleetArchived(fleet.isArchived());
        String structureName = fleet.getStructureName();
        bean.setNodeStructureName(structureName);
        if (!StringUtils.isBlank(structureName)) {
          List<NodeStructure> structureList =
              nodeStructRepo.findByStructureNameAndParentNodeStructure(
                  fleet.getStructureName(), null);
          bean.setStructureList(structureList);
          Map<String, EfficiencyTable> efficiencyTableMap = createEfficiencyMap(structureList);
          bean.setEfficiencyTableMap(efficiencyTableMap);
        }
      }
    }
    if (elaDto.getCloneAircraftId() != null) {
      bean.setAircraftClone(true);
      Aircraft cloneAircraft = aircraftRepo.findById(elaDto.getCloneAircraftId()).orElse(null);
      if (cloneAircraft != null) {
        bean.setCloneAircraft(cloneAircraft);
        bean.setCloneCloaked(cloneAircraft.isCloaked());
        Fleet cloneFleet = cloneAircraft.getFleet();
        if (cloneFleet != null
            && cloneFleet.getStructureName() != null
            && cloneFleet.getStructureName().equals(bean.getNodeStructureName())) {
          bean.setAircraftNodeStructureMatch(true);
          Ela cloneEla = elaRepo.findFirstByAircraftOrderByCreatedDateDesc(cloneAircraft);
          // efficiently load nodes for ela
          Ela hydrated = nodeService.hydrateEla(cloneEla);
          // clear out any node ids so we don't get a detached entity issue
          hydrated
              .getNodes()
              .forEach(
                  n -> {
                    n.setId(null);
                    n.streamNodes().forEach(node -> node.setId(null));
                  });
          bean.setCloneEla(hydrated);
        }
      }
      validateElaCreationBean(bean, ElaCreationBean.ValidateClone.class);
    } else {
      validateElaCreationBean(bean, ElaCreationBean.FilePresent.class);
    }
    validateElaCreationBean(bean, ElaCreationBean.ValidateAll.class);
    return bean;
  }

  private List<NodeStructure> fullNodeStructureList(List<NodeStructure> structureList) {
    return structureList.stream()
        .flatMap(n -> n.streamNodeStructures())
        .collect(Collectors.toList());
  }

  private List<String> findEfficiencyNames(List<NodeStructure> fullStructureList) {
    return fullStructureList.stream()
        .map(n -> n.getEfficiencyTableName())
        .filter(Objects::nonNull)
        .distinct()
        .collect(Collectors.toList());
  }

  Map<String, EfficiencyTable> createEfficiencyMap(List<NodeStructure> structureList) {
    List<String> efficiencyNameList = findEfficiencyNames(fullNodeStructureList(structureList));
    Map result = new HashMap<String, EfficiencyTable>();
    for (String effName : efficiencyNameList) {
      EfficiencyTable table = effTableRepo.findByName(effName);
      result.put(effName, table);
    }
    return result;
  };

  private void validateElaCreationBean(ElaCreationBean bean, Class klass) {
    Set<ConstraintViolation<ElaCreationBean>> violations = validator.validate(bean, klass);
    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }
  }
}
