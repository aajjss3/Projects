package com.seatec.ela.app.exception;

import org.slf4j.event.Level;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception to throw when a Http Status FORBIDDEN (403) is desired.
 *
 * @see CustomException for furthur documentation
 * @author alan
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class ForbiddenException extends CustomException {

  public ForbiddenException(String message) {
    super(message);
  }

  public ForbiddenException(String message, Level logLevel) {
    super(message, logLevel);
  }

  public ForbiddenException(String message, Level logLevel, Exception rootCause) {
    super(message, logLevel, rootCause);
  }
}
