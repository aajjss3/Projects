package com.seatec.ela.app.dto.report;

import com.seatec.ela.app.dto.analysis.ProjectAnalysis;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ProjectReportChangeGroupDTO implements Serializable {

  /**
   * If a serializable class doesn’t declare a serialVersionUID, the JVM will generate one
   * automatically at run-time. However, it is highly recommended that each class declares its
   * serialVersionUID as the generated one is compiler dependent and thus may result in unexpected
   * InvalidClassExceptions.
   */
  private static final long serialVersionUID = 1L;

  private UUID id;

  private String name;

  private List<ProjectAnalysis> analyses = new ArrayList<>();

  public ProjectReportChangeGroupDTO(UUID id, String name) {
    this.id = id;
    this.name = name;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<ProjectAnalysis> getAnalyses() {
    return analyses;
  }

  public void setAnalyses(List<ProjectAnalysis> analyses) {
    this.analyses = analyses;
  }

  public void addAnalyses(ProjectAnalysis analyses) {
    this.analyses.add(analyses);
  }

  public void removeAnalyses(ProjectAnalysis analyses) {
    this.analyses.remove(analyses);
  }
}
