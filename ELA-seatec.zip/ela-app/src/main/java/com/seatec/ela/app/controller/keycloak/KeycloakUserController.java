package com.seatec.ela.app.controller.keycloak;

import com.seatec.ela.app.dto.KeycloakUserDto;
import com.seatec.ela.app.service.contract.IKeycloakService;
import com.seatec.ela.app.util.KeycloakDataConverter;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/keycloak/users")
public class KeycloakUserController {

  @Autowired private IKeycloakService keycloakService;

  @Autowired private KeycloakDataConverter keycloakDataConverter;

  /**
   * Retrieves a collection of Keycloak UserRepresentation Entities
   *
   * @return List<KeycloakUserDto>
   */
  @GetMapping()
  @ResponseStatus(HttpStatus.OK)
  public List<KeycloakUserDto> findAllActiveUsers() {
    List<UserRepresentation> allActiveUsers = keycloakService.findAllActiveUsers();
    return allActiveUsers.stream()
        .map(keycloakDataConverter::convertToUserDto)
        .collect(Collectors.toList());
  }

  /**
   * Retrieves a Keycloak UserRepresentation Entity
   *
   * @param keycloakId Represents a Keycloak User unique identifier
   * @return KeycloakUserDto
   */
  @GetMapping("/{keycloakId}")
  @ResponseStatus(HttpStatus.OK)
  public KeycloakUserDto findUser(@PathVariable("keycloakId") String keycloakId) {
    return keycloakDataConverter.convertToUserDto(keycloakService.findUser(keycloakId));
  }

  /**
   * Creates a new Keycloak User including associated Keycloak Groups
   *
   * @param user Represents a Keycloak User
   * @return UserRepresentation
   */
  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public void create(@RequestBody @Valid KeycloakUserDto user) {
    keycloakService.createUser(user);
  }

  /**
   * Updates an existing active Keycloak User
   *
   * @param user Represents a KeycloakUserDto
   * @param id Represents a Keycloak User unique identifier
   */
  @PutMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public void update(@RequestBody @Valid KeycloakUserDto user, @PathVariable("id") String id) {
    keycloakService.updateUser(user, id);
  }
}
