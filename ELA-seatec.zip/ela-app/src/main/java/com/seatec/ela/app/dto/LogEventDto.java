package com.seatec.ela.app.dto;

import com.seatec.ela.app.util.enumeration.LogSource;
import org.slf4j.event.Level;

public class LogEventDto {
  private String message;

  private Level status = Level.INFO;

  private String url;

  /** Originating source of error (API, UI, etc) */
  private LogSource source = LogSource.UI;

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Level getStatus() {
    return status;
  }

  public void setStatus(Level status) {
    this.status = status;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public LogSource getSource() {
    return source;
  }

  public void setSource(LogSource source) {
    this.source = source;
  }
}
