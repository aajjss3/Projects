package com.seatec.ela.app.model.project;

import com.seatec.ela.app.model.base.BaseNodeChange;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "node_change")
public class NodeChange extends BaseNodeChange {}
