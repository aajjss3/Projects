package com.seatec.ela.app.dto.analysis;

import java.io.Serializable;

public class ProjectAnalysis implements Serializable {

  /**
   * If a serializable class doesn’t declare a serialVersionUID, the JVM will generate one
   * automatically at run-time. However, it is highly recommended that each class declares its
   * serialVersionUID as the generated one is compiler dependent and thus may result in unexpected
   * InvalidClassExceptions.
   */
  private static final long serialVersionUID = 1L;

  private String aircraftShipNo;
  private Long aircraftId;
  private Analysis analysis;

  public ProjectAnalysis(String aircraftShipNo, Long aircraftId, Analysis analysis) {
    this.aircraftShipNo = aircraftShipNo;
    this.aircraftId = aircraftId;
    this.analysis = analysis;
  }

  public String getAircraftShipNo() {
    return aircraftShipNo;
  }

  public void setAircraftShipNo(String aircraftShipNo) {
    this.aircraftShipNo = aircraftShipNo;
  }

  public Analysis getAnalysis() {
    return analysis;
  }

  public void setAnalysis(Analysis analysis) {
    this.analysis = analysis;
  }

  public Long getAircraftId() {
    return aircraftId;
  }

  public void setAircraftId(Long aircraftId) {
    this.aircraftId = aircraftId;
  }
}
