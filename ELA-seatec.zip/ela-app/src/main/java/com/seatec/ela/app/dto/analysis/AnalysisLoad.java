package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;

public class AnalysisLoad implements Comparable<AnalysisLoad>, Serializable {

  public enum Units {
    KVA,
    AMPS
  }

  private static final long serialVersionUID = 1L;

  private Double result; // in either KVA or Amps
  private String flightPhase;
  private Double value; // in either KVA or Amps
  private String electricalPhase;
  private Units units;
  @JsonIgnore private Double powerFactor; // only needed to calculate fuel jettison analysis

  public AnalysisLoad(
      Double result,
      String flightPhase,
      Double value,
      String electricalPhase,
      Units units,
      double powerFactor) {
    this.result = result;
    this.flightPhase = flightPhase;
    this.value = value;
    this.electricalPhase = electricalPhase;
    this.units = units;
    this.powerFactor = powerFactor;
  }

  public AnalysisLoad(
      Double result, String flightPhase, Double value, String electricalPhase, Units units) {
    this.result = result;
    this.flightPhase = flightPhase;
    this.value = value;
    this.electricalPhase = electricalPhase;
    this.units = units;
  }

  public AnalysisLoad() {}

  public Double getResult() {
    return result;
  }

  public void setResult(Double result) {
    this.result = result;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public Double getValue() {
    return value;
  }

  public void setValue(Double value) {
    this.value = value;
  }

  public String getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(String electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public Units getUnits() {
    return units;
  }

  public void setUnits(Units units) {
    this.units = units;
  }

  public Double getPowerFactor() {
    return powerFactor;
  }

  public void setPowerFactor(Double powerFactor) {
    this.powerFactor = powerFactor;
  }

  @Override
  public int compareTo(AnalysisLoad other) {
    return this.getFlightPhase().compareTo(other.getFlightPhase());
  }
}
