package com.seatec.ela.app.aop.userevent;

import org.aspectj.lang.ProceedingJoinPoint;

/**
 * Logconfig configures which controllers have UserEvent logging and the basic logging content for
 * those events
 *
 * @see Action
 * @see LogUserTrackConfig
 */
public class LogConfig {

  /**
   * Action holds the different action types to use in log messages.
   *
   * <ul>
   *   <li>GET route normally uses LIST or SEARCH. They also may have special values such as SUMMARY
   *       or ANALYSIS.
   *   <li>POST route normally uses CREATE
   *   <li>PUT route normally uses UPDATE
   *   <li>DELETE route normally uses DELETE
   * </ul>
   */
  enum Action {
    LIST,
    SEARCH,
    VIEW,
    CREATE,
    UPDATE,
    DELETE,
    SUMMARY,
    ANALYSIS,
    REPORT
  }

  /** Configures the controllers that have UserEvents */
  static final LogUserTrackConfig[] LOG_USER_TRACK_CONFIGS = {
    new LogUserTrackConfig("AircraftController", "findAircraft", Action.SEARCH, "Aircraft", null),
    new LogUserTrackConfig("AircraftController", "getAircraftById", Action.VIEW, "Aircraft", null),
    new LogUserTrackConfig("AircraftController", "createAircraft", Action.CREATE, "Aircraft", null),
    new LogUserTrackConfig("AircraftController", "updateAircraft", Action.UPDATE, "Aircraft", null),
    new LogUserTrackConfig("AircraftController", "deleteAircraft", Action.DELETE, "Aircraft", null),
    new LogUserTrackConfig(
        "AircraftController", "findCloakedAircraft", Action.SEARCH, "Aircraft Cloak", null),
    new LogUserTrackConfig(
        "AircraftController", "aircraftCloakOperation", Action.UPDATE, "Aircraft Cloak", null),
    new LogUserTrackConfig(
        "ChangeController", "findAllByProjectAndChangeGroupId", Action.LIST, "Change", null),
    new LogUserTrackConfig("ChangeController", "findById", Action.VIEW, "Change", null),
    new LogUserTrackConfig("ChangeController", "create", Action.CREATE, "Change", null),
    new LogUserTrackConfig("ChangeController", "update", Action.UPDATE, "Change", null),
    new LogUserTrackConfig("ChangeController", "delete", Action.DELETE, "Change", null),
    new LogUserTrackConfig(
        "ChangeGroupController", "findAllByProjectId", Action.LIST, "ChangeGroup", null),
    new LogUserTrackConfig(
        "ChangeGroupController", "findById", Action.VIEW, "ChangeGroup Effectivity", null),
    new LogUserTrackConfig(
        "ChangeGroupController",
        "findChangeGroupEffectivityByChangeGroupId",
        Action.LIST,
        "ChangeGroup",
        null),
    new LogUserTrackConfig(
        "ChangeGroupController",
        "findComponentsByChangeGroupNode",
        Action.LIST,
        "ChangeGroup Node Component",
        null),
    new LogUserTrackConfig(
        "ChangeGroupController",
        "findParentFleetsByChangeGroup",
        Action.LIST,
        "ChangeGroup Parent Fleet",
        null),
    new LogUserTrackConfig(
        "ChangeGroupController", "updateChangeGroupName", Action.UPDATE, "ChangeGroup", null),
    new LogUserTrackConfig(
        "ChangeGroupController",
        "saveByBusStructureBucketUsingAircraftIds",
        Action.CREATE,
        "ChangeGroup Effectivity",
        null),
    new LogUserTrackConfig("ChangeGroupController", "save", Action.CREATE, "ChangeGroup", null),
    new LogUserTrackConfig("ChangeGroupController", "update", Action.UPDATE, "ChangeGroup", null),
    new LogUserTrackConfig(
        "ChangeGroupController",
        "updateEffectivity",
        Action.CREATE,
        "ChangeGroup Effectivity",
        null),
    new LogUserTrackConfig("ChangeGroupController", "delete", Action.DELETE, "ChangeGroup", null),
    new LogUserTrackConfig(
        "ChangeGroupController", "getAircraftAnalysis", Action.ANALYSIS, "ChangeGroup", null),
    new LogUserTrackConfig(
        "ELARestController", "findElas", Action.VIEW, "Ela", "ElaShipNo".split(",")),
    new LogUserTrackConfig("ELARestController", "findEla", Action.VIEW, "Ela", "ElaId".split(",")),
    new LogUserTrackConfig(
        "ELARestController", "findElaSummary", Action.SUMMARY, "Ela", "ElaId".split(",")),
    new LogUserTrackConfig(
        "ELARestController", "getNode", Action.VIEW, "Ela Node", "ElaId,NodeId".split(",")),
    new LogUserTrackConfig(
        "ELARestController", "getAnalysis", Action.VIEW, "Ela", "ElaId".split(",")),
    new LogUserTrackConfig(
        "ELARestController", "processUpload", Action.CREATE, "Ela", "Ela".split(",")),
    new LogUserTrackConfig(
        "ELARestController", "getElaReport", Action.REPORT, "Ela", "Ela".split(",")),
    new LogUserTrackConfig(
        "FleetController",
        "findFleets",
        Action.SEARCH,
        "Fleet",
        "HasEla, AircraftShipNo, IncludeCloaked".split(",")),
    new LogUserTrackConfig("FleetController", "createFleet", Action.CREATE, "Fleet", null),
    new LogUserTrackConfig("FleetController", "updateFleet", Action.UPDATE, "Fleet", null),
    new LogUserTrackConfig(
        "FleetController", "deleteFleet", Action.DELETE, "Fleet", "FleetId".split(",")),
    new LogUserTrackConfig(
        "FleetController", "getFleetById", Action.VIEW, "Fleet", "FleetId".split(",")),
    new LogUserTrackConfig("KeycloakRoleController", "findAllRoles", Action.LIST, "Role", null),
    new LogUserTrackConfig(
        "KeycloakRoleController", "findUsersInRole", Action.SEARCH, "Role User", null),
    new LogUserTrackConfig("KeycloakUserController", "findUser", Action.VIEW, "User", null),
    new LogUserTrackConfig(
        "KeycloakUserController", "findAllActiveUsers", Action.LIST, "User", null),
    new LogUserTrackConfig("KeycloakUserController", "create", Action.CREATE, "User", null),
    new LogUserTrackConfig(
        "KeycloakUserController", "update", Action.UPDATE, "User", "UserData,UserId".split(",")),
    new LogUserTrackConfig("ProjectController", "getProjectById", Action.VIEW, "Project", null),
    new LogUserTrackConfig("ProjectController", "getProjectReport", Action.REPORT, "Project", null),
    new LogUserTrackConfig("ProjectController", "createProject", Action.CREATE, "Project", null),
    new LogUserTrackConfig("ProjectController", "updateProject", Action.UPDATE, "Project", null),
    new LogUserTrackConfig(
        "ProjectController", "deleteProjectById", Action.DELETE, "Project", null),
    new LogUserTrackConfig("ProjectController", "getProjects", Action.SEARCH, "Project", null),
    new LogUserTrackConfig("ProjectController", "getMyProjects", Action.SEARCH, "MyProject", null),
    new LogUserTrackConfig(
        "ProjectController",
        "getPendingReviewProjects",
        Action.LIST,
        "Pending Review Project",
        null),
    new LogUserTrackConfig(
        "ProjectController", "projectWorkflow", Action.UPDATE, "Project Workflow", null),
    new LogUserTrackConfig(
        "ProjectController", "rejectProject", Action.UPDATE, "Project Reject", null),
    new LogUserTrackConfig(
        "ProjectController", "setProjectCoauthors", Action.UPDATE, "Project Coauthor", null),
    new LogUserTrackConfig(
        "ProjectController", "getApprovedProjects", Action.LIST, "Approved Project", null),
  };

  /** Returns the matching UserTrackConfig */
  public static LogUserTrackConfig findMatchingConfig(ProceedingJoinPoint joinPoint) {
    Object className = joinPoint.getTarget().getClass().getSimpleName();
    String methodName = joinPoint.getSignature().getName();
    for (LogUserTrackConfig item : LOG_USER_TRACK_CONFIGS) {
      if (item.getSourceClass().equals(className) && item.getSourceMethod().equals(methodName)) {
        return item;
      }
    }
    return null;
  }
}
