package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * AutoLand Analysis for fleets (B767, B757, B757ETOPS)
 *
 * <p>AutoLand is only an analysis for the Hold/Land flight phase
 *
 * <pre>
 * The totalLoadInAmpsSummary assumes all nodes are DC.
 * - For DC loads, you can directly add Amps.
 * - For DC loads, there are no Vars.
 * - For AC loads, you can NOT directly add Amps.
 * - For AC loads, first sum Watts and sum Vars, then convert.
 * </pre>
 */
public class AutoLandAnalysis implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<AutoLandAnalysisNode> nodes = new ArrayList<>();

  private Double deratedDCVoltageInAmps;

  public void addNode(AutoLandAnalysisNode node) {
    this.nodes.add(node);
  }

  public List<AutoLandAnalysisNode> getNodes() {
    return nodes;
  }

  @JsonProperty(value = "totalLoadInAmpsSummary", access = Access.READ_ONLY)
  public Double getTotalLoadInAmpsSummary() {
    return nodes.stream().map(node -> node.getTotalLoadInAmps()).reduce(0.0d, Double::sum);
  }

  public Double getDeratedDCVoltageInAmps() {
    return deratedDCVoltageInAmps;
  }

  public void setDeratedDCVoltageInAmps(Double deratedDCVoltageInAmps) {
    this.deratedDCVoltageInAmps = deratedDCVoltageInAmps;
  }
}
