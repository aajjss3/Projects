package com.seatec.ela.app.model;

import com.seatec.ela.app.model.structure.VoltageType;

public enum ElectricalPhase {
  AC,
  ACA,
  ACB,
  ACC,
  AC3,
  DC,
  NA;

  public static ElectricalPhase fromVoltageType(VoltageType voltageType) {
    switch (voltageType) {
      case AC:
        return ElectricalPhase.AC;
      case AC3:
        return ElectricalPhase.AC3;
      case DC:
        return ElectricalPhase.DC;
      default:
        return ElectricalPhase.NA;
    }
  }
}
