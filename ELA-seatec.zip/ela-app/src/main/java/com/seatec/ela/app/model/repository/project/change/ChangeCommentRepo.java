package com.seatec.ela.app.model.repository.project.change;

import com.seatec.ela.app.model.project.change.ChangeComment;
import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ChangeCommentRepo extends CrudRepository<ChangeComment, UUID> {
  List<ChangeComment> findAllByChangeId(@Param("changeId") UUID changeId);

  void deleteByChangeId(@Param("changeId") UUID changeId);
}
