package com.seatec.ela.app.util;

public class LoadUtil {

  public static double getVa(double w, double var) {
    double kw = w / 1000;
    double kvar = var / 1000;
    double kva = Math.sqrt(Math.pow(kw, 2) + Math.pow(kvar, 2));
    return kva * 1000;
  }

  public static double getPowerFactor(double w, double var) {
    if (var == 0 || w == 0) {
      return 1;
    }
    double kva = getVa(w, var) / 1000;
    double kw = w / 1000;
    return kw / kva;
  }

  public static double getW(double va, double pf) {
    return va * pf;
  }

  public static double getVar(double va, double pf) {
    double kva = va / 1000;
    double w = getW(va, pf);
    double kw = w / 1000;
    double kvar = Math.sqrt(Math.abs(Math.pow(kva, 2) - Math.pow(kw, 2)));
    return kvar * 1000;
  }

  public static double getAmps(double va, double pf, double inlineVoltage) {
    return (va * pf) / inlineVoltage;
  }

  public static double getAmps(double w, double inlineVoltage) {
    return w / inlineVoltage;
  }
}
