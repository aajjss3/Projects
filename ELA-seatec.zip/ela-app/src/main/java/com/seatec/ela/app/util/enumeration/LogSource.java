package com.seatec.ela.app.util.enumeration;

public enum LogSource {
  UI
}
