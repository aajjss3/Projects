package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PseudoFlightPhaseLoadSummaryUtil calculates load summaries using a component's nominal power or
 * connected load depending on the IPseudoFlightPhaseAggregator used. The load summaries will have a
 * pseudo-flight phase of either "NominalPower" or "ConnectedLoad" with an operating mode of null.
 */
class PseudoFlightPhaseLoadSummaryUtil {
  private static Logger logger = LoggerFactory.getLogger(PseudoFlightPhaseLoadSummaryUtil.class);

  // suppress default constructor for noninstantiability
  private PseudoFlightPhaseLoadSummaryUtil() {
    throw new AssertionError();
  }

  static void calcLoadSummary(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull Component component,
      @NotNull IPseudoFlightPhaseAggregator loadSummaryAggregator) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(component, "component must not be null");
    Objects.requireNonNull(loadSummaryAggregator, "load summary aggregator must not be null");

    logger.trace(
        "Calculating {} load summary for component id: {} name: {}",
        loadSummaryAggregator.getPseudoFlightPhase(),
        component.getId(),
        component.getName());

    SummarizedLoad loadSummary =
        LoadSummaryUtil.findOrCreateLoadSummary(
            loadSummaryMap, summaryType, component, loadSummaryAggregator.getPseudoFlightPhase());
    loadSummaryAggregator.aggregateLoadSummary(loadSummary, component);
  }

  static void calcLoadSummariesPhaseSplit(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull LoadSummaryOptions loadSummaryOptions,
      @NotNull Component component,
      @NotNull IPseudoFlightPhaseAggregator loadSummaryAggregator) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");
    Objects.requireNonNull(component, "component must not be null");
    Objects.requireNonNull(loadSummaryAggregator, "load summary aggregator must not be null");

    logger.trace(
        "Calculating {} phase split load summaries for component id: {} name: {}",
        loadSummaryAggregator.getPseudoFlightPhase(),
        component.getId(),
        component.getName());

    // AC3 - Split into ACA, ACB, ACC
    List<SummarizedLoad> loadSummaries =
        LoadSummaryUtil.findOrCreateLoadSummariesPhaseSplit(
            loadSummaryMap, summaryType, loadSummaryAggregator.getPseudoFlightPhase());
    loadSummaryAggregator.aggregateLoadSummariesPhaseSplit(loadSummaries, component);

    if (loadSummaryOptions.getIncludeAggregateAC3Loads()) {
      // AC3 Aggregates
      calcLoadSummary(loadSummaryMap, summaryType, component, loadSummaryAggregator);
    }
  }
}
