package com.seatec.ela.app.model;

import java.util.Objects;

public final class LoadSummaryOptions {

  private final boolean includeComponentsWithoutChildren;
  private final boolean includeNominalPower;
  private final boolean includePhaseSummary;
  private final boolean includeAggregateAC3Loads;
  private final boolean includeEssentialLoadAggregate;

  /**
   * LoadSummaryOptions
   *
   * @param includeComponentsWithoutChildren - If true create summarized load for components without
   *     children in addition to summarized loads for components with children. If false then only
   *     create summarized loads for components with children.
   * @param includeNominalPower - If true also create summarized loads for nominal power. If false
   *     then do not create summarized loads for nominal power.
   * @param includePhaseSummary - If true also create summarized loads for phase summary. If false,
   *     then do not create summarized loads for phase summary.
   * @param includeAggregateAC3Loads - If true also create summarized loads for AC3 (in addition to
   *     the AC3 being equally split into ACA, ACB, and ACC summarized loads)
   * @param includeEssentialLoadAggregate - If true then in addition to the normal aggregate of all
   *     loads (essential and sheddable) also perform separate calculations for only essential loads
   *     (not sheddable loads) and store on the SummarizedLoad object in separate fields. These
   *     aggregates of only essential loads is used by the Degraded Analysis (see
   *     LoadAnalysisService)
   */
  public LoadSummaryOptions(
      boolean includeComponentsWithoutChildren,
      boolean includeNominalPower,
      boolean includePhaseSummary,
      boolean includeAggregateAC3Loads,
      boolean includeEssentialLoadAggregate) {
    this.includeComponentsWithoutChildren = includeComponentsWithoutChildren;
    this.includeNominalPower = includeNominalPower;
    this.includePhaseSummary = includePhaseSummary;
    this.includeAggregateAC3Loads = includeAggregateAC3Loads;
    this.includeEssentialLoadAggregate = includeEssentialLoadAggregate;
  }

  public boolean getIncludeComponentsWithoutChildren() {
    return includeComponentsWithoutChildren;
  }

  public boolean getIncludeNominalPower() {
    return includeNominalPower;
  }

  public boolean getIncludePhaseSummary() {
    return includePhaseSummary;
  }

  public boolean getIncludeAggregateAC3Loads() {
    return includeAggregateAC3Loads;
  }

  public boolean getIncludeEssentialLoadAggregate() {
    return includeEssentialLoadAggregate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LoadSummaryOptions that = (LoadSummaryOptions) o;
    return includeComponentsWithoutChildren == that.includeComponentsWithoutChildren
        && includeNominalPower == that.includeNominalPower
        && includePhaseSummary == that.includePhaseSummary
        && includeAggregateAC3Loads == that.includeAggregateAC3Loads
        && includeEssentialLoadAggregate == that.includeEssentialLoadAggregate;
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        includeComponentsWithoutChildren,
        includeNominalPower,
        includePhaseSummary,
        includeAggregateAC3Loads,
        includeEssentialLoadAggregate);
  }
}
