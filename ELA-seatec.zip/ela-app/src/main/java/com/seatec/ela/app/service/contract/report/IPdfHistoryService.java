package com.seatec.ela.app.service.contract.report;

import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.model.project.ChangeGroup;
import java.util.List;

public interface IPdfHistoryService {
  PdfPTable generateElaChangeHistory(String aircraftShipNo);

  PdfPTable generateProjectChangeHistory(List<ChangeGroup> changeGroups, boolean isApproved);
}
