package com.seatec.ela.app.model;

public enum CalculationType {
  KVA_AVAILABLE,
  PERCENTAGE_USED
}
