package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.ComponentUtil;
import java.util.List;

/** DefaultAggregator aggregates the loads for a component */
class DefaultAggregator {

  void aggregateLoadSummary(
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load) {

    if (loadSummaryOptions.getIncludeEssentialLoadAggregate()
        && ComponentUtil.isEssential(component)) {
      // Essential Only
      loadSummary.aggregateWEssentialLoad(load.getW());
      loadSummary.aggregateVarEssentialLoad(load.getVar());
    }
    // Essential and Sheddable
    loadSummary.aggregateW(load.getW());
    loadSummary.aggregateVar(load.getVar());
  }

  void aggregateLoadSummariesPhaseSplit(
      List<SummarizedLoad> loadSummaries,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load) {

    Double splitValue = load.getW() > 0d ? load.getW() / LoadSummaryUtil.THREE_PHASE_SPLIT : 0d;
    Double splitVar = load.getVar() > 0d ? load.getVar() / LoadSummaryUtil.THREE_PHASE_SPLIT : 0d;

    for (SummarizedLoad loadSummary : loadSummaries) {
      if (loadSummaryOptions.getIncludeEssentialLoadAggregate()
          && ComponentUtil.isEssential(component)) {
        // Essential Only
        loadSummary.aggregateWEssentialLoad(splitValue);
        loadSummary.aggregateVarEssentialLoad(splitVar);
      }
      // Essential and Sheddable
      loadSummary.aggregateW(splitValue);
      loadSummary.aggregateVar(splitVar);
    }
  }
}
