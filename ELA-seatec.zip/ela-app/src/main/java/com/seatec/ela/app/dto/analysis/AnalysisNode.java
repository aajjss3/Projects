package com.seatec.ela.app.dto.analysis;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AnalysisNode implements Comparable<AnalysisNode>, Serializable {

  /**
   * If a serializable class doesn’t declare a serialVersionUID, the JVM will generate one
   * automatically at run-time. However, it is highly recommended that each class declares its
   * serialVersionUID as the generated one is compiler dependent and thus may result in unexpected
   * InvalidClassExceptions.
   */
  private static final long serialVersionUID = 1L;

  private Long nodeId;
  private Double rating;
  private String name;
  private String voltageType;
  // contains the rolled up aggregate worst case status of all the AnalysisLoads
  private AnalysisStatus status;

  @JsonProperty("loads")
  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  private List<AnalysisLoad> analysisLoads = new ArrayList<AnalysisLoad>();

  public AnalysisNode(Long nodeId, Double rating, String name) {
    this.nodeId = nodeId;
    this.rating = rating;
    this.name = name;
  }

  public Long getNodeId() {
    return nodeId;
  }

  public void setNodeId(Long nodeId) {
    this.nodeId = nodeId;
  }

  public Double getRating() {
    return rating;
  }

  public void setRating(Double rating) {
    this.rating = rating;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<AnalysisLoad> getAnalysisLoads() {
    return analysisLoads;
  }

  public void setAnalysisLoads(List<AnalysisLoad> analysisLoads) {
    this.analysisLoads = analysisLoads;
  }

  public void addAnalysisLoad(AnalysisLoad analysisLoad) {
    analysisLoads.add(analysisLoad);
  }

  public String getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(String voltageType) {
    this.voltageType = voltageType;
  }

  public AnalysisStatus getStatus() {
    return status;
  }

  public void setStatus(AnalysisStatus status) {
    this.status = status;
  }

  @Override
  public int compareTo(AnalysisNode other) {
    return (this.getName().compareTo(other.getName()) != 0)
        ? this.getName().compareTo(other.getName())
        : this.getNodeId().compareTo(other.getNodeId());
  }
}
