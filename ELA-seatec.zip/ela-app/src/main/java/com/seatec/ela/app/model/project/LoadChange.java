package com.seatec.ela.app.model.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.base.BaseLoadChange;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "load_change")
public class LoadChange extends BaseLoadChange {

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "component_change_id", insertable = false, updatable = false, nullable = false)
  private ComponentChange componentChange;

  public ComponentChange getComponentChange() {
    return componentChange;
  }

  public void setComponentChange(ComponentChange componentChange) {
    this.componentChange = componentChange;
  }
}
