package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;

public class TRUAutoLandAnalysisDTO implements Serializable {

  private static final long serialVersionUID = 1L;

  private double totalAmps;
  private double ratio;
  private AnalysisStatus status;
  private double rating;

  public TRUAutoLandAnalysisDTO(
      double totalAmps, double ratio, AnalysisStatus status, double rating) {
    this.totalAmps = totalAmps;
    this.ratio = ratio;
    this.status = status;
    this.rating = rating;
  }

  public double getTotalAmps() {
    return totalAmps;
  }

  public void setTotalAmps(double totalAmps) {
    this.totalAmps = totalAmps;
  }

  public double getRatio() {
    return ratio;
  }

  public void setRatio(double ratio) {
    this.ratio = ratio;
  }

  public AnalysisStatus getAnalysisStatus() {
    return status;
  }

  public void setAnalysisStatus(AnalysisStatus status) {
    this.status = status;
  }

  public double getRating() {
    return rating;
  }

  public void setRating(double rating) {
    this.rating = rating;
  }
}
