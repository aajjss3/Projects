package com.seatec.ela.app.util;

import com.seatec.ela.app.util.enumeration.BatteryChargeType;

/**
 * The aircraft battery discharge calculation. Currently only used for standby operation analysis
 * for Boeing aircrafts.
 */
public class BatteryDischargeCalculation {

  public static double boeingEquation(BatteryChargeType type, double value) {

    double constantA = 0d;
    double constantB = 0d;

    switch (type) {
      case SINGLE_40AH:
        constantA = BoeingConstants.SINGLE_40AH.getConstantA();
        constantB = BoeingConstants.SINGLE_40AH.getConstantB();
        break;
      case DUAL_40AH:
        constantA = BoeingConstants.DUAL_40AH.getConstantA();
        constantB = BoeingConstants.DUAL_40AH.getConstantB();
        break;
      case SINGLE_48AH:
        constantA = BoeingConstants.SINGLE_48AH.getConstantA();
        constantB = BoeingConstants.SINGLE_48AH.getConstantB();
        break;
      case DUAL_48AH:
        constantA = BoeingConstants.DUAL_48AH.getConstantA();
        constantB = BoeingConstants.DUAL_48AH.getConstantB();
        break;
      case SINGLE_47AH:
        constantA = BoeingConstants.SINGLE_47AH.getConstantA();
        constantB = BoeingConstants.SINGLE_47AH.getConstantB();
    }
    return constantA * (Math.pow(value, constantB));
  }

  private enum BoeingConstants {
    SINGLE_40AH(4348, -1.15974),
    DUAL_40AH(9671.4, -1.15974),
    SINGLE_48AH(3834.66, -1.07395),
    DUAL_48AH(8072.6, -1.07395),
    SINGLE_47AH(4589.5, -1.13633);

    private final double constantA;
    private final double constantB;

    private BoeingConstants(double constantA, double constantB) {
      this.constantA = constantA;
      this.constantB = constantB;
    }

    public double getConstantA() {
      return constantA;
    }

    public double getConstantB() {
      return constantB;
    }
  }
}
