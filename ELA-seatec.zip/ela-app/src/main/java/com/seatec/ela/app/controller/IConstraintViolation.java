package com.seatec.ela.app.controller;

import com.seatec.ela.app.exception.error.ErrorDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public interface IConstraintViolation {

  static Logger logger = LoggerFactory.getLogger(IConstraintViolation.class.getName());

  /**
   * handles DataIntegrityViolationException with CONFLICT when ConstraintViolation is found;
   * otherwise INTERNAL_SERVER_ERROR. Typically, called by method in controller annotated
   * by @ExceptionHandler(DataIntegrityViolationException.class).
   *
   * @param exception exception for DataIntegrityViolation that will be checked for
   *     ConstraintViolationException
   * @param constraintViolationMessage Message to be returned with 409
   * @return
   */
  default ResponseEntity<ErrorWrapperDTO> handleDataIntegrityViolationException(
      DataIntegrityViolationException exception, String constraintViolationMessage) {
    String message = null;
    ResponseEntity<ErrorWrapperDTO> response = null;
    if (exception.getCause() instanceof org.hibernate.exception.ConstraintViolationException) {
      response =
          new ResponseEntity<ErrorWrapperDTO>(
              new ErrorWrapperDTO(new ErrorDTO(null, constraintViolationMessage)),
              HttpStatus.CONFLICT);
      logger.warn(
          "Data Integrity Violation with Constraint Violation was thrown mapping to ConflictException behavior "
              + constraintViolationMessage);
    } else {
      message =
          (exception.getCause() != null)
              ? exception.getCause().getMessage()
              : exception.getLocalizedMessage();
      response =
          new ResponseEntity<ErrorWrapperDTO>(
              new ErrorWrapperDTO(new ErrorDTO(null, message)), HttpStatus.INTERNAL_SERVER_ERROR);
      logger.error("Uncaught exception was thrown.", exception);
    }
    return response;
  }
}
