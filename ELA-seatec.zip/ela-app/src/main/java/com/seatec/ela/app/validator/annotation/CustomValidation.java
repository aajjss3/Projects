package com.seatec.ela.app.validator.annotation;

import javax.validation.ConstraintValidatorContext;

public class CustomValidation {

  /**
   * Disable default constraint violation and build one with a custom field and message
   *
   * @param message
   * @param field
   * @param context
   * @return
   */
  protected boolean buildCustomConstraint(
      String message, String field, ConstraintValidatorContext context) {
    context.disableDefaultConstraintViolation();
    context
        .buildConstraintViolationWithTemplate(message)
        .addPropertyNode(field)
        .addConstraintViolation();
    return false;
  }
}
