package com.seatec.ela.app.model;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** A request for calculating load summaries. */
public final class LoadSummaryRequest {

  private final Map<UUID, EfficiencyTable> efficiencyTableMap;
  private final LoadSummaryOptions loadSummaryOptions;

  /**
   * @param efficiencyTableMap - a non-null map of efficiency tables keyed by their ids
   * @param loadSummaryOptions - the load summary options
   */
  public LoadSummaryRequest(
      Map<UUID, EfficiencyTable> efficiencyTableMap, LoadSummaryOptions loadSummaryOptions) {
    this.efficiencyTableMap = efficiencyTableMap;
    this.loadSummaryOptions = loadSummaryOptions;
  }

  public Map<UUID, EfficiencyTable> getEfficiencyTableMap() {
    return efficiencyTableMap;
  }

  public LoadSummaryOptions getLoadSummaryOptions() {
    return loadSummaryOptions;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LoadSummaryRequest that = (LoadSummaryRequest) o;
    return Objects.equals(efficiencyTableMap, that.efficiencyTableMap)
        && Objects.equals(loadSummaryOptions, that.loadSummaryOptions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(efficiencyTableMap, loadSummaryOptions);
  }
}
