package com.seatec.ela.app.util;

import javax.servlet.http.HttpServletRequest;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;

public class RequestUtil {

  public static String getUserIdFromRequest(HttpServletRequest request) {
    return ((KeycloakAuthenticationToken) request.getUserPrincipal())
        .getAccount()
        .getKeycloakSecurityContext()
        .getToken()
        .getSubject();
  }
}
