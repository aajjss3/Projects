package com.seatec.ela.app.config;

import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import org.modelmapper.Conditions;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.convention.NamingConventions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfiguration {

  /**
   * Returns a ModelMapper instance for only mapping fields whose source value is not null.
   *
   * @return
   */
  @Bean(name = "mapNonNulls")
  public ModelMapper getNonNullMapper() {
    return createMapper(true);
  }

  /**
   * Returns a ModelMapper instance for mapping all fields, independent of the source fields values.
   *
   * @return
   */
  @Bean(name = "mapAll")
  public ModelMapper getAllMapper() {
    return createMapper(false);
  }

  /**
   * Returns a ModelMapper instance for mapping all fields exception Project.changeGroups
   *
   * @return
   */
  @Bean(name = "mapAllFlatProject")
  public ModelMapper flatProjectToProjectDTOMapper() {
    ModelMapper mapper = createMapper(false);
    mapper
        .createTypeMap(Project.class, ProjectDTO.class)
        .addMappings(
            map -> {
              map.skip(ProjectDTO::setChangeGroups);
            });
    mapper
        .createTypeMap(Project.class, AssignedProjectDTO.class)
        .addMappings(
            map -> {
              map.skip(ProjectDTO::setChangeGroups);
            });
    return mapper;
  }

  private ModelMapper createMapper(boolean excludeNulls) {
    ModelMapper mapper = new ModelMapper();
    mapper.getConfiguration().setFieldMatchingEnabled(true);
    mapper.getConfiguration().setSourceNamingConvention(NamingConventions.NONE);
    mapper.getConfiguration().setDestinationNamingConvention(NamingConventions.NONE);
    mapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
    if (excludeNulls) {
      mapper.getConfiguration().setPropertyCondition(Conditions.isNotNull());
    }
    setDefaultMapping(mapper);
    return mapper;
  }

  /**
   * Contains any default mappings that should always occur. do not map the id field between
   * entities when the source id field is a UUID and the destination is a Long
   */
  private void setDefaultMapping(ModelMapper mapper) {
    mapper
        .createTypeMap(NodeChange.class, Node.class)
        .addMappings(
            map -> {
              map.skip(Node::setId);
              map.skip(Node::setDisplayOrder);
            });

    mapper
        .createTypeMap(ComponentChange.class, Component.class)
        .addMappings(
            map -> {
              map.skip(Component::setId);
              map.skip(Component::setDisplayOrder);
            });

    mapper
        .createTypeMap(LoadChange.class, Load.class)
        .addMappings(
            map -> {
              map.skip(Load::setId);
            });
  }
}
