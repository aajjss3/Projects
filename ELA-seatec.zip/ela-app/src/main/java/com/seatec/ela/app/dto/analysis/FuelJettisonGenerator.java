package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FuelJettisonGenerator implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<FuelJettisonLoad> fuelJettisonLoads = new ArrayList<>();
  private String generatorName;
  private AnalysisStatus generatorStatus;
  private AnalysisStatus withJettisonStatus;
  private AnalysisStatus withoutJettisonStatus;
  private Double rating;

  public List<FuelJettisonLoad> getFuelJettisonLoads() {
    return fuelJettisonLoads;
  }

  public void setFuelJettisonLoads(List<FuelJettisonLoad> fuelJettisonLoads) {
    this.fuelJettisonLoads = fuelJettisonLoads;
  }

  public String getGeneratorName() {
    return generatorName;
  }

  public void setGeneratorName(String generatorName) {
    this.generatorName = generatorName;
  }

  public void addFuelJettisonLoad(FuelJettisonLoad fuelJettisonLoad) {
    fuelJettisonLoads.add(fuelJettisonLoad);
  }

  public AnalysisStatus getGeneratorStatus() {
    return generatorStatus;
  }

  public void setGeneratorStatus(AnalysisStatus generatorStatus) {
    this.generatorStatus = generatorStatus;
  }

  public AnalysisStatus getWithJettisonStatus() {
    return withJettisonStatus;
  }

  public void setWithJettisonStatus(AnalysisStatus withJettisonStatus) {
    this.withJettisonStatus = withJettisonStatus;
  }

  public AnalysisStatus getWithoutJettisonStatus() {
    return withoutJettisonStatus;
  }

  public void setWithoutJettisonStatus(AnalysisStatus withoutJettisonStatus) {
    this.withoutJettisonStatus = withoutJettisonStatus;
  }

  public Double getRating() {
    return rating;
  }

  public void setRating(Double rating) {
    this.rating = rating;
  }
}
