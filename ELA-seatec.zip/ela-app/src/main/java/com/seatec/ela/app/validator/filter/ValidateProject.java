package com.seatec.ela.app.validator.filter;

// Validation group intended for use when we need to validate multiple project-level properties
public interface ValidateProject {}
