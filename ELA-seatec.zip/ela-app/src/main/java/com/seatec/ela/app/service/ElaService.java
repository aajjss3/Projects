package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.ElaComponentsDto;
import com.seatec.ela.app.dto.project.AircraftDTO;
import com.seatec.ela.app.exception.ForbiddenException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.service.project.ProjectAnalysisService;
import com.seatec.ela.app.util.NodeUtil;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ElaService implements IElaService {

  @Autowired private ProjectAnalysisService projectAnalysisService;

  @Autowired private ElaRepository repository;

  @Autowired private KeycloakService keycloakService;

  @Autowired private INodeService nodeService;

  @Autowired private NodeRepository nodeRepository;

  /**
   * finds related elas and components
   *
   * @param aircraftDTOS - list of aircraft DTOs in change group
   * @return ElaComponentsDto list
   */
  @Transactional(readOnly = true)
  public List<ElaComponentsDto> findElaComponentDtosByAircraftDTOS(List<AircraftDTO> aircraftDTOS) {
    List<ElaComponentsDto> elaComponentsDtos = new ArrayList<>();

    for (AircraftDTO aircraftDTO : aircraftDTOS) {
      Optional<Ela> ela = findByAircraftShipNo(aircraftDTO.getAircraftShipNo());

      if (ela.isPresent()) {
        ElaComponentsDto elaComponentsDto = new ElaComponentsDto(ela.get());

        // find matching ElaComponentsDto
        Optional<ElaComponentsDto> matchingDto =
            elaComponentsDtos.stream()
                .filter(e -> e.getEla().getId().equals(elaComponentsDto.getEla().getId()))
                .findFirst();

        // generate a random componentId since component Entity doesn't exist yet
        // this allows us to map downstream (load to ela/aircraft/component)
        Long componentId = new Random().nextLong();

        // if Ela entry does not exist then add it
        if (!matchingDto.isPresent()) {
          elaComponentsDto.addComponentId(componentId);
          elaComponentsDtos.add(elaComponentsDto);
          continue;
        }

        // append componentId to existing list
        matchingDto.get().addComponentId(componentId);
      }
    }

    return elaComponentsDtos;
  }

  @Transactional(readOnly = true)
  public List<ElaComponentsDto> findElaComponentDtosByComponentIds(List<Long> componentIds) {
    List<ElaComponentsDto> elaComponentsDtos = new ArrayList<>();

    for (Long componentId : componentIds) {
      Optional<Ela> ela = repository.findByComponentId(componentId);

      if (ela.isPresent()) {
        ElaComponentsDto elaComponentsDto = new ElaComponentsDto(ela.get());

        // find matching ElaComponentsDto
        Optional<ElaComponentsDto> matchingDto =
            elaComponentsDtos.stream()
                .filter(e -> e.getEla().getId().equals(elaComponentsDto.getEla().getId()))
                .findFirst();

        // if Ela entry does not exist then add it
        if (!matchingDto.isPresent()) {
          elaComponentsDto.addComponentId(componentId);
          elaComponentsDtos.add(elaComponentsDto);
          continue;
        }

        // if entry exists then check if componentId exists, if not, add it
        boolean componentIdExists = matchingDto.get().getComponentIds().contains(componentId);

        // append componentId to existing list
        if (!componentIdExists) {
          matchingDto.get().addComponentId(componentId);
        }
      }
    }

    return elaComponentsDtos;
  }

  @Override
  public List<Ela> findByName(String name) {
    return repository.findByName(name);
  }

  @Override
  public Optional<Ela> findById(Long id) {
    return repository.findById(id);
  }

  @Override
  @Transactional
  public void save(Ela entity) {
    repository.save(entity);
  }

  @Override
  @Transactional
  public Long deleteByName(String name) {
    return repository.deleteByName(name);
  }

  @Override
  public List<Ela> findAll() {
    List<Ela> result = new ArrayList<>();
    Iterable<Ela> iterable = repository.findAll();
    iterable.forEach(result::add);

    return result;
  }

  public List<Long> findDistinctElaIdByAircraftChangeGroups(
      List<AircraftChangeGroup> aircraftChangeGroups) {
    List<Long> elaIds = new ArrayList<>();
    List<Aircraft> aircrafts =
        aircraftChangeGroups.stream()
            .map(AircraftChangeGroup::getAircraft)
            .collect(Collectors.toList());

    for (Aircraft aircraft : aircrafts) {
      Ela ela = repository.findFirstByAircraftOrderByCreatedDateDesc(aircraft);
      if (ela == null) {
        throw new NotFoundException(
            "Unable to find an ela for the aircraft ship number: " + aircraft.getAircraftShipNo());
      }
      elaIds.add(ela.getId());
    }

    return elaIds;
  }

  @Override
  public List<Ela> findByAircraftShipNo(String aircraftShipNo, String userId) {
    if (keycloakService.isUserAndInRole(userId, KeycloakRole.IT_ADMIN.getName())) {
      return repository.findByAircraftShipNo(aircraftShipNo);
    } else if (keycloakService.isUserAndInRole(userId, KeycloakRole.ENGINEERING_ADMIN.getName())) {
      return repository.findByCloakedFalseAndAircraftShipNo(aircraftShipNo);
    } else {
      return repository.findByArchivedFalseAndCloakedFalseAndAircraftShipNo(aircraftShipNo);
    }
  }

  @Override
  public void elaAircraftCloakPermission(Long elaId, String userId) {
    Optional<Ela> ela = repository.findById(elaId);
    if (ela.isPresent()) {
      Aircraft aircraft = ela.get().getAircraft();
      if (aircraft != null
          && aircraft.isCloaked()
          && !keycloakService.isUserAndInRole(userId, KeycloakRole.IT_ADMIN.getName())) {
        throw new ForbiddenException(
            "No permission to access resource on aircraft " + aircraft.getAircraftShipNo());
      }
    }
  }

  @CacheEvict(
      value = {"hydrateEla", "hydrateNodes", "findByIdNodes"},
      allEntries = true)
  public void rebase(List<ChangeGroup> changeGroups) {
    for (ChangeGroup cg : changeGroups) {
      // verify changes exist
      if (!cg.getChanges().isEmpty()) {
        List<Aircraft> aircrafts =
            cg.getAircraftChangeGroups().stream()
                .map(AircraftChangeGroup::getAircraft)
                .collect(Collectors.toList());

        // iterate over aircrafts
        for (Aircraft aircraft : aircrafts) {
          Ela ela = repository.findFirstByAircraftOrderByCreatedDateDesc(aircraft);

          if (ela != null) {
            // ela nodes (AFTER merging project changes)
            List<Node> nodes = new ArrayList<>();

            // ela nodes (BEFORE merging project changes)
            List<Node> originalNodes = new ArrayList<>();

            List<Node> topLevelNodes = nodeService.hydrateNodes(ela.getId(), null);

            // get the complete list of nodes. each node does not contain summarized loads
            List<Node> allNodes = NodeUtil.flattenNodeTrees(topLevelNodes);
            List<Long> allNodeIds = allNodes.stream().map(Node::getId).collect(Collectors.toList());

            // get all Node Entities (for persistence)
            List<Node> matchingNodes = nodeRepository.findByIdIn(allNodeIds);
            nodes.addAll(matchingNodes);
            originalNodes.addAll(matchingNodes);

            // apply changes
            projectAnalysisService.applyChanges(ela, nodes, cg.getChanges(), true);

            // persist changes to db
            // delete node(s)
            for (Node originalNode : originalNodes) {
              if (!nodes.contains(originalNode)) {
                // verify not top level node
                if (originalNode.getParentNode() != null) {
                  originalNode.getParentNode().removeNode(originalNode);
                }

                nodeRepository.delete(originalNode);
              }
            }

            // add node(s)
            for (Node node : nodes) {
              if (!originalNodes.contains(node)) {
                nodeRepository.save(node);
              }
            }
          }
        }
      }
    }
  }

  /**
   * Find ELAs that are associated to an aircraft ship number.
   *
   * @param aircraftShipNo - Unique Aircraft ship number
   * @return ELAs associated to aircraft matching the ship number
   */
  private Optional<Ela> findByAircraftShipNo(String aircraftShipNo) {
    return repository.findByAircraftShipNo(aircraftShipNo).stream().findFirst();
  }
}
