package com.seatec.ela.app.model.repository;

import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ElaRepository extends CrudRepository<Ela, Long> {

  @Query(
      nativeQuery = true,
      value =
          "WITH RECURSIVE nodetree AS ("
              + "SELECT n.* "
              + "FROM node n "
              + "INNER JOIN component c on c.node_id = n.id "
              + "WHERE c.id = :componentId "
              + "UNION ALL "
              + "SELECT ni.* "
              + "FROM node AS ni "
              + "INNER JOIN nodetree AS np ON (ni.id = np.node_id)"
              + ") "
              + "SELECT e.* FROM nodetree nt "
              + "INNER JOIN ela e ON e.id = nt.ela_id "
              + "WHERE nt.ela_id IS NOT NULL AND nt.node_id IS NULL")
  Optional<Ela> findByComponentId(@Param("componentId") Long componentId);

  List<Ela> findByName(String name);

  Long deleteByName(String name);

  @Query(
      "SELECT e FROM Ela e WHERE e.aircraft.aircraftShipNo = :aircraftShipNo ORDER BY createdDate DESC")
  List<Ela> findByAircraftShipNo(@Param("aircraftShipNo") String aircraftShipNo);

  @Query(
      "SELECT e FROM Ela e WHERE e.aircraft.aircraftShipNo = :aircraftShipNo AND e.aircraft.cloaked = FALSE AND e.aircraft.archived = FALSE ORDER BY createdDate DESC")
  List<Ela> findByArchivedFalseAndCloakedFalseAndAircraftShipNo(
      @Param("aircraftShipNo") String aircraftShipNo);

  @Query(
      "SELECT e FROM Ela e WHERE e.aircraft.aircraftShipNo = :aircraftShipNo AND e.aircraft.cloaked = FALSE ORDER BY createdDate DESC")
  List<Ela> findByCloakedFalseAndAircraftShipNo(@Param("aircraftShipNo") String aircraftShipNo);

  Ela findFirstByAircraftOrderByCreatedDateDesc(@Param("aircraft") Aircraft aircraft);
}
