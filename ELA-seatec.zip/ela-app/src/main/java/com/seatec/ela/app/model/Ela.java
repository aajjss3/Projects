package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "ela")
@JsonView(View.SummaryView.class)
public class Ela implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "name", nullable = false)
  private String name;

  @Column(name = "created_date", nullable = false)
  @CreationTimestamp
  private Date createdDate;

  @Column(name = "created_by", nullable = false)
  private String createdBy;

  @ManyToOne
  @JoinColumn(name = "aircraft_id")
  @JsonIgnore
  private Aircraft aircraft;

  @OneToMany(mappedBy = "ela", cascade = CascadeType.ALL, orphanRemoval = true)
  @OrderBy("displayOrder ASC")
  private List<Node> nodes = new ArrayList<>();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCreatedBy() {
    return createdBy;
  }

  public void setCreatedBy(String createdBy) {
    this.createdBy = createdBy;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }

  public Aircraft getAircraft() {
    return aircraft;
  }

  public void setAircraft(Aircraft aircraft) {
    this.aircraft = aircraft;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public List<Node> getNodes() {
    return nodes;
  }

  public void setNodes(List<Node> nodes) {
    this.nodes = nodes;
  }

  public void addNode(Node node) {
    this.nodes.add(node);
    node.setEla(this);
  }

  public void removeNode(Node node) {
    this.nodes.remove(node);
    node.setEla(this);
  }

  public Node findNode(String name) {
    return nodes.stream()
        .flatMap(n -> n.streamNodes())
        .filter(x -> x.getName().equals(name))
        .findFirst()
        .orElse(null);
  }

  public Ela shallowCopy() {
    Ela ela = new Ela();
    ela.setId(id);
    ela.setName(name);
    ela.setCreatedBy(createdBy);
    ela.setCreatedDate(createdDate);
    return ela;
  }
}
