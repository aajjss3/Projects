package com.seatec.ela.app.model;

import java.util.Objects;

/** The key representing the bucket of a SummarizedLoad of a node. */
public final class LoadSummaryBucketKey {
  private final SummaryType summaryType;
  private final ElectricalPhase electricalPhase;
  private final String flightPhase;
  private final String operatingMode;
  private final boolean isMaxImbalance;
  private final boolean isMaxPhaseLoad;

  public LoadSummaryBucketKey(
      SummaryType summaryType,
      ElectricalPhase electricalPhase,
      String flightPhase,
      String operatingMode,
      boolean isMaxImbalance,
      boolean isMaxPhaseLoad) {
    this.summaryType = summaryType;
    this.electricalPhase = electricalPhase;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.isMaxImbalance = isMaxImbalance;
    this.isMaxPhaseLoad = isMaxPhaseLoad;
  }

  public static LoadSummaryBucketKey from(SummarizedLoad summarizedLoad) {
    return new LoadSummaryBucketKey(
        summarizedLoad.getSummaryType(),
        summarizedLoad.getElectricalPhase(),
        summarizedLoad.getFlightPhase(),
        summarizedLoad.getOperatingMode(),
        summarizedLoad.isMaxImbalance(),
        summarizedLoad.isMaxPhaseLoad());
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LoadSummaryBucketKey that = (LoadSummaryBucketKey) o;
    return isMaxImbalance == that.isMaxImbalance
        && isMaxPhaseLoad == that.isMaxPhaseLoad
        && summaryType == that.summaryType
        && electricalPhase == that.electricalPhase
        && Objects.equals(flightPhase, that.flightPhase)
        && Objects.equals(operatingMode, that.operatingMode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        summaryType, electricalPhase, flightPhase, operatingMode, isMaxImbalance, isMaxPhaseLoad);
  }
}
