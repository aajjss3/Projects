package com.seatec.ela.app.util.csv;

import com.seatec.ela.app.exception.BadRequestException;
import org.apache.commons.codec.binary.StringUtils;

public class AirbusCsvAggregate {
  boolean maxi;
  boolean operational;
  // Common Fields
  private String intermittent;
  private String clipsed;
  private String sheddable;
  private String busBar;
  private String phase;
  private String identifier;
  private String panel;
  private String atacode;
  private String designator;
  private String nominalPower;
  private String modified;
  private String comment;
  // MAXI Flight Stage
  private String maxiLoad;
  private String maxiGroundStage;
  private String maxiStartStage;
  private String maxiRollStage;
  private String maxiTakeoffStage;
  private String maxiClimbStage;
  private String maxiCruiseStage;
  private String maxiDescendStage;
  private String maxiLandStage;
  private String maxiTaxiStage;
  // OPERATIONAL Flight Stage
  private String operationalLoad;
  private String operationalGroundStage;
  private String operationalStartStage;
  private String operationalRollStage;
  private String operationalTakeoffStage;
  private String operationalClimbStage;
  private String operationalCruiseStage;
  private String operationalDescendStage;
  private String operationalLandStage;
  private String operationalTaxiStage;
  private long index;

  AirbusCsvAggregate(AirbusCsv input, long index) {
    this.index = index;
    this.fillCommon(input);
    if (input.isMaxi()) {
      this.fillMaxi(input);
    } else {
      this.fillOperational(input);
    }
  }

  public AirbusCsvAggregate updateAirbusCsvAggregate(AirbusCsv input) {
    if (this.isOperational()) {
      commonMatch(input);
      fillMaxi(input);
    } else {
      commonMatch(input);
      fillOperational(input);
    }
    return this;
  }

  private void commonMatch(AirbusCsv input) {
    boolean result =
        StringUtils.equals(this.getIntermittent(), input.getIntermittent())
            && StringUtils.equals(this.getClipsed(), input.getClipsed())
            && StringUtils.equals(this.getSheddable(), input.getSheddable())
            && StringUtils.equals(this.getBusBar(), input.getBusBar())
            && StringUtils.equals(this.getPhase(), input.getPhase())
            && StringUtils.equals(this.getIdentifier(), input.getIdentifier())
            && StringUtils.equals(this.getPanel(), input.getPanel())
            && StringUtils.equals(this.getAtacode(), input.getAtacode())
            && StringUtils.equals(this.getDesignator(), input.getDesignator())
            && StringUtils.equals(this.getNominalPower(), input.getNominalPower());
    if (!result) {
      throw new BadRequestException(
          "CSV Data inconsistent for BusBar "
              + this.getBusBar()
              + " and Identifier "
              + this.getPanel()
              + " Designator "
              + this.getDesignator());
    }
  }

  private void fillCommon(AirbusCsv input) {
    this.setIntermittent(input.getIntermittent());
    this.setClipsed(input.getClipsed());
    this.setSheddable(input.getSheddable());
    this.setBusBar(input.getBusBar());
    this.setPhase(input.getPhase());
    this.setIdentifier(input.getIdentifier());
    this.setPanel(input.getPanel());
    this.setAtacode(input.getAtacode());
    this.setDesignator(input.getDesignator());
    this.setNominalPower(input.getNominalPower());
    this.setModified(input.getModified());
    this.setComment(input.getComment());
  }

  private void fillMaxi(AirbusCsv input) {
    this.setMaxi(true);
    this.setMaxiLoad(input.getLoad());
    this.setMaxiGroundStage(input.getGroundStage());
    this.setMaxiStartStage(input.getStartStage());
    this.setMaxiRollStage(input.getRollStage());
    this.setMaxiTakeoffStage(input.getTakeoffStage());
    this.setMaxiClimbStage(input.getClimbStage());
    this.setMaxiCruiseStage(input.getCruiseStage());
    this.setMaxiDescendStage(input.getDescendStage());
    this.setMaxiLandStage(input.getLandStage());
    this.setMaxiTaxiStage(input.getTaxiStage());
  }

  private void fillOperational(AirbusCsv input) {
    this.setOperational(true);
    this.setOperationalLoad(input.getLoad());
    this.setOperationalGroundStage(input.getGroundStage());
    this.setOperationalStartStage(input.getStartStage());
    this.setOperationalRollStage(input.getRollStage());
    this.setOperationalTakeoffStage(input.getTakeoffStage());
    this.setOperationalClimbStage(input.getClimbStage());
    this.setOperationalCruiseStage(input.getCruiseStage());
    this.setOperationalDescendStage(input.getDescendStage());
    this.setOperationalLandStage(input.getLandStage());
    this.setOperationalTaxiStage(input.getTaxiStage());
  }

  public boolean isMaxi() {
    return maxi;
  }

  public void setMaxi(boolean maxi) {
    this.maxi = maxi;
  }

  public boolean isOperational() {
    return operational;
  }

  public void setOperational(boolean operational) {
    this.operational = operational;
  }

  public String getIntermittent() {
    return intermittent;
  }

  public boolean isIntermittent() {
    return StringUtils.equals(intermittent, "I");
  }

  public void setIntermittent(String intermittent) {
    this.intermittent = intermittent;
  }

  public String getClipsed() {
    return clipsed;
  }

  public boolean isClipsed() {
    return StringUtils.equals(clipsed, "C");
  }

  public void setClipsed(String clipsed) {
    this.clipsed = clipsed;
  }

  public String getSheddable() {
    return sheddable;
  }

  public boolean isSheddable() {
    return StringUtils.equals(sheddable, "S");
  }

  public void setSheddable(String sheddable) {
    this.sheddable = sheddable;
  }

  public String getBusBar() {
    return busBar;
  }

  public void setBusBar(String busBar) {
    this.busBar = busBar;
  }

  public String getPhase() {
    return phase;
  }

  public void setPhase(String phase) {
    this.phase = phase;
  }

  public String getMaxiLoad() {
    return maxiLoad;
  }

  public void setMaxiLoad(String maxiLoad) {
    this.maxiLoad = maxiLoad;
  }

  public String getOperationalLoad() {
    return operationalLoad;
  }

  public void setOperationalLoad(String operationalLoad) {
    this.operationalLoad = operationalLoad;
  }

  public String getIdentifier() {
    return identifier;
  }

  public void setIdentifier(String identifier) {
    this.identifier = identifier;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public String getAtacode() {
    return atacode;
  }

  public void setAtacode(String atacode) {
    this.atacode = atacode;
  }

  public String getDesignator() {
    return designator;
  }

  public void setDesignator(String designator) {
    this.designator = designator;
  }

  public String getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(String nominalPower) {
    this.nominalPower = nominalPower;
  }

  public String getModified() {
    return modified;
  }

  public void setModified(String modified) {
    this.modified = modified;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getMaxiGroundStage() {
    return maxiGroundStage;
  }

  public void setMaxiGroundStage(String maxiGroundStage) {
    this.maxiGroundStage = maxiGroundStage;
  }

  public String getMaxiStartStage() {
    return maxiStartStage;
  }

  public void setMaxiStartStage(String maxiStartStage) {
    this.maxiStartStage = maxiStartStage;
  }

  public String getMaxiRollStage() {
    return maxiRollStage;
  }

  public void setMaxiRollStage(String maxiRollStage) {
    this.maxiRollStage = maxiRollStage;
  }

  public String getMaxiTakeoffStage() {
    return maxiTakeoffStage;
  }

  public void setMaxiTakeoffStage(String maxiTakeoffStage) {
    this.maxiTakeoffStage = maxiTakeoffStage;
  }

  public String getMaxiClimbStage() {
    return maxiClimbStage;
  }

  public void setMaxiClimbStage(String maxiClimbStage) {
    this.maxiClimbStage = maxiClimbStage;
  }

  public String getMaxiCruiseStage() {
    return maxiCruiseStage;
  }

  public void setMaxiCruiseStage(String maxiCruiseStage) {
    this.maxiCruiseStage = maxiCruiseStage;
  }

  public String getMaxiDescendStage() {
    return maxiDescendStage;
  }

  public void setMaxiDescendStage(String maxiDescendStage) {
    this.maxiDescendStage = maxiDescendStage;
  }

  public String getMaxiLandStage() {
    return maxiLandStage;
  }

  public void setMaxiLandStage(String maxiLandStage) {
    this.maxiLandStage = maxiLandStage;
  }

  public String getMaxiTaxiStage() {
    return maxiTaxiStage;
  }

  public void setMaxiTaxiStage(String maxiTaxiStage) {
    this.maxiTaxiStage = maxiTaxiStage;
  }

  public String getOperationalGroundStage() {
    return operationalGroundStage;
  }

  public void setOperationalGroundStage(String operationalGroundStage) {
    this.operationalGroundStage = operationalGroundStage;
  }

  public String getOperationalStartStage() {
    return operationalStartStage;
  }

  public void setOperationalStartStage(String operationalStartStage) {
    this.operationalStartStage = operationalStartStage;
  }

  public String getOperationalRollStage() {
    return operationalRollStage;
  }

  public void setOperationalRollStage(String operationalRollStage) {
    this.operationalRollStage = operationalRollStage;
  }

  public String getOperationalTakeoffStage() {
    return operationalTakeoffStage;
  }

  public void setOperationalTakeoffStage(String operationalTakeoffStage) {
    this.operationalTakeoffStage = operationalTakeoffStage;
  }

  public String getOperationalClimbStage() {
    return operationalClimbStage;
  }

  public void setOperationalClimbStage(String operationalClimbStage) {
    this.operationalClimbStage = operationalClimbStage;
  }

  public String getOperationalCruiseStage() {
    return operationalCruiseStage;
  }

  public void setOperationalCruiseStage(String operationalCruiseStage) {
    this.operationalCruiseStage = operationalCruiseStage;
  }

  public String getOperationalDescendStage() {
    return operationalDescendStage;
  }

  public void setOperationalDescendStage(String operationalDescendStage) {
    this.operationalDescendStage = operationalDescendStage;
  }

  public String getOperationalLandStage() {
    return operationalLandStage;
  }

  public void setOperationalLandStage(String operationalLandStage) {
    this.operationalLandStage = operationalLandStage;
  }

  public String getOperationalTaxiStage() {
    return operationalTaxiStage;
  }

  public void setOperationalTaxiStage(String operationalTaxiStage) {
    this.operationalTaxiStage = operationalTaxiStage;
  }

  public long getIndex() {
    return index;
  }

  public void setIndex(long index) {
    this.index = index;
  }

  public boolean consistentTo(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof AirbusCsvAggregate)) {
      return false;
    }

    AirbusCsvAggregate that = (AirbusCsvAggregate) o;

    if (maxi != that.maxi) {
      return false;
    }
    if (operational != that.operational) {
      return false;
    }
    if (intermittent != null
        ? !intermittent.equals(that.intermittent)
        : that.intermittent != null) {
      return false;
    }
    if (clipsed != null ? !clipsed.equals(that.clipsed) : that.clipsed != null) {
      return false;
    }
    if (sheddable != null ? !sheddable.equals(that.sheddable) : that.sheddable != null) {
      return false;
    }
    if (busBar != null ? !busBar.equals(that.busBar) : that.busBar != null) {
      return false;
    }
    if (maxiLoad != null ? !maxiLoad.equals(that.maxiLoad) : that.maxiLoad != null) {
      return false;
    }
    if (operationalLoad != null
        ? !operationalLoad.equals(that.operationalLoad)
        : that.operationalLoad != null) {
      return false;
    }
    if (identifier != null ? !identifier.equals(that.identifier) : that.identifier != null) {
      return false;
    }
    if (panel != null ? !panel.equals(that.panel) : that.panel != null) {
      return false;
    }
    if (atacode != null ? !atacode.equals(that.atacode) : that.atacode != null) {
      return false;
    }
    if (designator != null ? !designator.equals(that.designator) : that.designator != null) {
      return false;
    }
    if (nominalPower != null
        ? !nominalPower.equals(that.nominalPower)
        : that.nominalPower != null) {
      return false;
    }
    if (maxiGroundStage != null
        ? !maxiGroundStage.equals(that.maxiGroundStage)
        : that.maxiGroundStage != null) {
      return false;
    }
    if (maxiStartStage != null
        ? !maxiStartStage.equals(that.maxiStartStage)
        : that.maxiStartStage != null) {
      return false;
    }
    if (maxiRollStage != null
        ? !maxiRollStage.equals(that.maxiRollStage)
        : that.maxiRollStage != null) {
      return false;
    }
    if (maxiTakeoffStage != null
        ? !maxiTakeoffStage.equals(that.maxiTakeoffStage)
        : that.maxiTakeoffStage != null) {
      return false;
    }
    if (maxiClimbStage != null
        ? !maxiClimbStage.equals(that.maxiClimbStage)
        : that.maxiClimbStage != null) {
      return false;
    }
    if (maxiCruiseStage != null
        ? !maxiCruiseStage.equals(that.maxiCruiseStage)
        : that.maxiCruiseStage != null) {
      return false;
    }
    if (maxiDescendStage != null
        ? !maxiDescendStage.equals(that.maxiDescendStage)
        : that.maxiDescendStage != null) {
      return false;
    }
    if (maxiLandStage != null
        ? !maxiLandStage.equals(that.maxiLandStage)
        : that.maxiLandStage != null) {
      return false;
    }
    if (maxiTaxiStage != null
        ? !maxiTaxiStage.equals(that.maxiTaxiStage)
        : that.maxiTaxiStage != null) {
      return false;
    }
    if (operationalGroundStage != null
        ? !operationalGroundStage.equals(that.operationalGroundStage)
        : that.operationalGroundStage != null) {
      return false;
    }
    if (operationalStartStage != null
        ? !operationalStartStage.equals(that.operationalStartStage)
        : that.operationalStartStage != null) {
      return false;
    }
    if (operationalRollStage != null
        ? !operationalRollStage.equals(that.operationalRollStage)
        : that.operationalRollStage != null) {
      return false;
    }
    if (operationalTakeoffStage != null
        ? !operationalTakeoffStage.equals(that.operationalTakeoffStage)
        : that.operationalTakeoffStage != null) {
      return false;
    }
    if (operationalClimbStage != null
        ? !operationalClimbStage.equals(that.operationalClimbStage)
        : that.operationalClimbStage != null) {
      return false;
    }
    if (operationalCruiseStage != null
        ? !operationalCruiseStage.equals(that.operationalCruiseStage)
        : that.operationalCruiseStage != null) {
      return false;
    }
    if (operationalDescendStage != null
        ? !operationalDescendStage.equals(that.operationalDescendStage)
        : that.operationalDescendStage != null) {
      return false;
    }
    if (operationalLandStage != null
        ? !operationalLandStage.equals(that.operationalLandStage)
        : that.operationalLandStage != null) {
      return false;
    }
    return operationalTaxiStage != null
        ? operationalTaxiStage.equals(that.operationalTaxiStage)
        : that.operationalTaxiStage == null;
  }
}
