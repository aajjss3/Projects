package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.model.Aircraft;
import java.util.List;
import java.util.Optional;

/** Service for dealing with Aircrafts. */
public interface IAircraftService {

  /**
   * Find all aircrafts. Result is sorted by aircraft name.
   *
   * @return list of all aircrafts
   */
  Optional<Aircraft> findById(Long id);

  List<Aircraft> findByIdIn(List<Long> ids);

  List<Aircraft> findAll(String userId);

  Aircraft create(Aircraft entity, Long fleetId);

  Aircraft update(Aircraft entity, Long aircraftId);

  void deleteById(Long id);

  Aircraft findFirstByOrderByIdDesc();

  List<Aircraft> findByAircraftShipNo(String aircraftShipNo, String userId);

  List<Aircraft> findAllCloaked();

  List<Aircraft> findCloakedByAircraftShipNoAsc(String aircraftShipNo);

  void cloak(Long id);

  void uncloak(Long id);
}
