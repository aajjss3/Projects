package com.seatec.ela.app.model.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotBlank;

@MappedSuperclass
public class BaseChange extends BaseEntity {

  @NotBlank(message = "{field.required}")
  @Column(length = 127)
  private String name;

  @Column(name = "nominal_power", length = 127)
  private Double nominalPower;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }
}
