package com.seatec.ela.app;

import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.dto.ElaCreationDto;
import com.seatec.ela.app.dto.analysis.Analysis;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.View;
import com.seatec.ela.app.service.EfficiencyTableService;
import com.seatec.ela.app.service.ElaAnalysisService;
import com.seatec.ela.app.service.ElaCreationService;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.service.report.PdfService;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.annotation.IdExists;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/service/elas")
public class ELARestController {

  @Autowired private IElaService elaService;

  @Autowired private INodeService nodeService;

  @Autowired private ElaAnalysisService elaAnalysisService;

  @Autowired private ElaCreationService elaCreationService;

  @Autowired private PdfService pdfService;

  @Autowired private EfficiencyTableService efficiencyTableService;

  @GetMapping()
  @JsonView(View.SummaryView.class)
  public List<Ela> findElas(
      @RequestParam(value = "aircraft") String aircraft, HttpServletRequest request) {
    if (!StringUtils.isEmpty(aircraft)) {
      String userId = RequestUtil.getUserIdFromRequest(request);
      List<Ela> elas = elaService.findByAircraftShipNo(aircraft, userId);
      if (!elas.isEmpty()) {
        Ela ela = elas.get(0);
        Ela hydrated = nodeService.hydrateEla(ela);
        return Arrays.asList(hydrated);
      }
      return elas;
    }
    throw new IllegalArgumentException("Required String parameter 'aircraft' must not be empty");
  }

  @GetMapping("/{id}")
  public Ela findEla(@PathVariable Long id) {
    return elaService.findById(id).orElse(null);
  }

  @GetMapping("/{id}/summary")
  @JsonView(View.SummaryView.class)
  public Ela findElaSummary(@PathVariable Long id) {
    return elaService.findById(id).orElse(null);
  }

  @GetMapping("/{elaId}/node/{id}")
  @JsonView(View.NodeSummaryView.class)
  public Node getNode(@PathVariable Long elaId, @PathVariable Long id, HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    elaService.elaAircraftCloakPermission(elaId, userId);

    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();
    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, false);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    return nodeService.findById(id, elaId, loadSummaryRequest).orElse(null);
  }

  /**
   * Return the Ela data as a PDF with a content type of application/pdf. If input data validation
   * fails or an error occurs, then return the standard JSON response.
   *
   * @param id Unique identifier for a Ela Entity
   * @return ResponseEntity<Resource>
   */
  @GetMapping("/{id}/report")
  public ResponseEntity<Resource> getElaReport(
      @IdExists(entity = Ela.class, message = "{id.invalid}") @PathVariable("id") Long id,
      @RequestParam(value = "faaReport", required = false, defaultValue = "false")
          boolean faaReport) {

    Ela ela =
        elaService
            .findById(id)
            .orElseThrow(
                () -> new NotFoundException(String.format("Ela (%s) not found.", id), Level.ERROR));

    HttpHeaders headers = new HttpHeaders();
    headers.add(
        "Content-Disposition",
        "inline; filename=ela-report-" + ela.getAircraft().getAircraftShipNo() + ".pdf");
    return ResponseEntity.ok()
        .headers(headers)
        .contentType(MediaType.APPLICATION_PDF)
        .body(new ByteArrayResource(pdfService.getElaPdf(ela, faaReport).toByteArray()));
  }

  @GetMapping("/{elaId}/analyses")
  @ResponseStatus(HttpStatus.OK)
  public Analysis getAnalysis(@PathVariable("elaId") Long elaId, HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    elaService.elaAircraftCloakPermission(elaId, userId);
    return elaAnalysisService.getAnalysis(elaId);
  }

  @PostMapping()
  public Ela processUpload(
      @Validated @RequestPart ElaCreationDto elaDto,
      @RequestPart(required = false) MultipartFile file)
      throws IOException {
    if (file == null) {
      return elaCreationService.createEla(elaDto, null);
    } else {
      return elaCreationService.createEla(elaDto, file.getInputStream());
    }
  }
}
