package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.KeycloakGroupDto;
import com.seatec.ela.app.dto.KeycloakUserDto;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Keycloak REST API Data Converter for ELA Entity translation. */
@Component
public class KeycloakDataConverter {
  private static final String DEFAULT_ROLE = "user";

  @Value("${keycloak.resource}")
  private String keycloakClient;

  public KeycloakDataConverter() {}

  public KeycloakDataConverter(String keycloakClient) {
    this.keycloakClient = keycloakClient;
  }

  /**
   * Converts Keycloak GroupRepresentation Entity into ELA KeycloakGroupDto Entity.
   *
   * @param group [GroupRepresentation] represents a keycloak realm Group Entity.
   * @return KeycloakGroupDto Entity
   */
  public static KeycloakGroupDto convertToGroupDto(GroupRepresentation group) {
    return new KeycloakGroupDto(group.getId(), group.getName());
  }

  /**
   * Converts collection of Keycloak GroupRepresentation Entity into collection of ELA
   * KeycloakGroupDto Entities.
   *
   * @param groups [List<GroupRepresentation>] represents a keycloak realm Group Entity collection.
   * @return a collection of KeycloakGroupDto Entities
   */
  public static List<KeycloakGroupDto> convertToGroupDto(List<GroupRepresentation> groups) {
    return groups.stream()
        .map(KeycloakDataConverter::convertToGroupDto)
        .collect(Collectors.toList());
  }

  /**
   * Converts Keycloak UserRepresentation Entity into ELA KeycloakUserDto Entity.
   *
   * @param user [List<UserRepresentation>] represents a keycloak realm User Entity.
   * @return KeycloakUserDto Entity
   */
  public KeycloakUserDto convertToUserDto(UserRepresentation user) {
    return new KeycloakUserDto(
        user.getId(),
        user.getFirstName(),
        user.getLastName(),
        user.isEnabled(),
        user.getEmail(),
        user.isEmailVerified(),
        getElaRole(user.getClientRoles()));
  }

  /**
   * An ELA user should only have one client role other than the default "user" role.
   *
   * @param clientRoles the list of client roles
   * @return the user's role
   */
  private String getElaRole(Map<String, List<String>> clientRoles) {
    if (clientRoles != null) {
      List<String> elaRoles = clientRoles.get(keycloakClient);
      if (elaRoles != null) {
        List<String> nonDefaultRoles =
            elaRoles.stream()
                .filter(role -> !role.equals(DEFAULT_ROLE))
                .collect(Collectors.toList());
        return nonDefaultRoles.size() == 1 ? nonDefaultRoles.get(0) : null;
      }
    }
    return null;
  }

  /**
   * Converts collection of Keycloak UserRepresentation Entity into collection of ELA
   * KeycloakUserDto Entities.
   *
   * @param users [List<UserRepresentation>] represents a keycloak realm User Entity collection.
   * @return a collection of KeycloakUserDto Entities
   */
  public List<KeycloakUserDto> convertToUserDto(List<UserRepresentation> users) {
    return users.stream().map(this::convertToUserDto).collect(Collectors.toList());
  }
}
