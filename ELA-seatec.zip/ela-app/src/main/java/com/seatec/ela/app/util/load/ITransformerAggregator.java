package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;

public interface ITransformerAggregator {
  void aggregateLoadSummary(
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable);
}
