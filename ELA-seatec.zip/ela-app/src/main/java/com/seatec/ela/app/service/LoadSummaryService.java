package com.seatec.ela.app.service;

import static com.seatec.ela.app.service.ElaAnalysisService.BOEING_717_NORMAL_CALCULATION;
import static com.seatec.ela.app.service.ElaAnalysisService.BOEING_NORMAL_CALCULATION;

import com.seatec.ela.app.exception.InternalServerErrorException;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.NodeUtil;
import com.seatec.ela.app.util.load.AtuLoadSummaryCalculator;
import com.seatec.ela.app.util.load.DefaultLoadSummaryCalculator;
import com.seatec.ela.app.util.load.GeneratorLoadSummaryCalculator;
import com.seatec.ela.app.util.load.TruLoadSummaryCalculator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.stereotype.Service;

@Service
public class LoadSummaryService {
  private static Logger logger = LoggerFactory.getLogger(LoadSummaryService.class);

  /**
   * Calculate the load summaries for a node.
   *
   * @param node - the node
   * @param loadSummaryRequest - contains the efficiency table map for transformers and load summary
   *     options
   * @return the list of load summaries for the given node
   */
  public List<SummarizedLoad> retrieveLoadSummaries(
      @NotNull Node node, @NotNull LoadSummaryRequest loadSummaryRequest) {

    Objects.requireNonNull(node, "node must not be null");
    Objects.requireNonNull(loadSummaryRequest, "loadSummaryRequest must not be null");

    LoadSummaryOptions loadSummaryOptions = loadSummaryRequest.getLoadSummaryOptions();

    if (loadSummaryOptions == null) {
      loadSummaryOptions = new LoadSummaryOptions(false, false, false, false, false);
    }
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    if (loadSummaryOptions.getIncludeComponentsWithoutChildren()) {
      calculateLoadSummariesNode(
          loadSummaryMap, loadSummaryOptions, SummaryType.COMPONENTS, node, null);
    }
    calculateLoadSummariesNode(
        loadSummaryMap, loadSummaryOptions, SummaryType.COMPONENTS_AND_CHILDREN, node, null);

    // adjust transformer loads
    Map<UUID, EfficiencyTable> efficiencyTableMap = loadSummaryRequest.getEfficiencyTableMap();
    adjustLoadSummariesTransformers(loadSummaryMap, loadSummaryOptions, efficiencyTableMap);

    // if the node is a Generator, then create 'pseudo' LoadSummary objects to hold Phase Summary
    // data and add to the collection of
    // loadSummaries.
    if (NodeType.GENERATOR.equals(node.getNodeType())
        && loadSummaryOptions.getIncludePhaseSummary()) {
      GeneratorLoadSummaryCalculator.addPhaseSummariesToLoadSummaries(
          loadSummaryMap, loadSummaryOptions);
    }

    if (logger.isDebugEnabled()) {
      loadSummaryMap.values().forEach(l -> debugLoadSummary(node, l));
    }

    return new ArrayList<>(loadSummaryMap.values());
  }

  private void calculateLoadSummariesNode(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      LoadSummaryOptions loadSummaryOptions,
      SummaryType summaryType,
      Node node,
      Node topMostAncestorTransformer) {

    logger.trace(
        "Calculating {} load summaries for node identifier: {}, type: {}",
        summaryType,
        NodeUtil.getNodeIdentifier(node),
        node.getNodeType());

    /*
     * When summing up loads - if a node is a transformer (node type of ATU or TRU), then all child
     * and grandchild nodes under it are considered transformers and will have the same transformer
     * type as the first ancestral transformer parent/grandparent in the node tree (independent of the
     * actual child node's nodeType which might not even be a transformer type).
     */
    NodeType actingNodeType = node.getNodeType();

    if (topMostAncestorTransformer == null
        && (NodeType.ATU.equals(node.getNodeType()) || NodeType.TRU.equals(node.getNodeType()))) {

      /*
       * If a top most ancestor transformer hasn't been set yet,
       * then this transformer node becomes the top most ancestor transformer
       */
      topMostAncestorTransformer = node;
    }

    if (topMostAncestorTransformer != null) {
      actingNodeType = topMostAncestorTransformer.getNodeType();
      logger.trace(
          "topMostAncestorTransformer identifier: {}, type: {}",
          NodeUtil.getNodeIdentifier(topMostAncestorTransformer),
          topMostAncestorTransformer.getNodeType());
      logger.trace("actingNodeType: {}", actingNodeType);
    }

    switch (actingNodeType) {
      case ATU:
        AtuLoadSummaryCalculator.calculateLoadSummaries(
            loadSummaryMap, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
        break;
      case TRU:
        TruLoadSummaryCalculator.calculateLoadSummaries(
            loadSummaryMap, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
        break;
      default:
        DefaultLoadSummaryCalculator.calculateLoadSummaries(
            loadSummaryMap, summaryType, loadSummaryOptions, node);
        break;
    }

    if (SummaryType.COMPONENTS_AND_CHILDREN.equals(summaryType)) {
      logger.trace("SummaryType: {} - Recurse through child nodes", summaryType);
      for (Node subNode : node.getSubNodes()) {
        calculateLoadSummariesNode(
            loadSummaryMap, loadSummaryOptions, summaryType, subNode, topMostAncestorTransformer);
      }
    }
  }

  private void adjustLoadSummariesTransformers(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      LoadSummaryOptions loadSummaryOptions,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {

    for (SummarizedLoad loadSummary : loadSummaryMap.values()) {
      adjustLoadSummariesATU(loadSummary, loadSummaryOptions, efficiencyTableMap);
      adjustLoadSummariesTRU(loadSummaryMap, loadSummary, loadSummaryOptions, efficiencyTableMap);
    }
  }

  private void adjustLoadSummariesATU(
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    adjustLoadSummariesATUNormal(loadSummary, efficiencyTableMap);

    // for degraded analysis of ATU Transformers
    if (loadSummaryOptions.getIncludeEssentialLoadAggregate()) {
      adjustLoadSummariesATUDegraded(loadSummary, efficiencyTableMap);
    }
  }

  private void adjustLoadSummariesATUNormal(
      SummarizedLoad loadSummary, Map<UUID, EfficiencyTable> efficiencyTableMap) {

    if (!loadSummary.getAtuWs().isEmpty()) {
      loadSummary
          .getAtuWs()
          .forEach(
              (k, v) -> {
                Double valueInVAR = loadSummary.getAtuVars().get(k);
                aggregateVal(loadSummary, k, v, valueInVAR, NodeType.ATU, efficiencyTableMap);
              });

      loadSummary
          .getAtuVars()
          .forEach(
              (k, v) -> {
                Double valueInWatts = loadSummary.getAtuWs().get(k);
                aggregateVar(loadSummary, k, v, valueInWatts, NodeType.ATU, efficiencyTableMap);
              });
    }
  }

  private void aggregateVal(
      SummarizedLoad loadSummary,
      String nodeIdentifier,
      Double valueInWatts,
      Double valueInVAR,
      NodeType nodeType,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (valueInWatts != null && valueInVAR != null) {
      double va = LoadUtil.getVa(valueInWatts, valueInVAR);
      EfficiencyLoad el =
          retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
              nodeIdentifier,
              nodeType,
              va,
              loadSummary.getNodeToEfficiencyTableMap().get(nodeIdentifier),
              efficiencyTableMap);
      loadSummary.aggregateOriginalW(valueInWatts);
      double adjustedLoad = valueInWatts / el.getExPF();
      if (NodeType.TRU.equals(nodeType)) {
        // aggregate the VAR based on the efficiency table pf + adjusted va
        double var = LoadUtil.getVar(adjustedLoad, el.getPowerFactor());
        if (loadSummary.getOperatingMode().equals(BOEING_NORMAL_CALCULATION)
            || loadSummary.getOperatingMode().equals(BOEING_717_NORMAL_CALCULATION)) {
          double adjustedW = LoadUtil.getW(adjustedLoad, el.getPowerFactor());
          loadSummary.aggregateW(adjustedW);
          loadSummary.aggregateVar(var);
        } else {
          loadSummary.aggregateW(adjustedLoad);
        }
      } else {
        loadSummary.aggregateW(adjustedLoad);
      }
    }
  }

  private void aggregateVar(
      SummarizedLoad loadSummary,
      String nodeIdentifier,
      Double valueInVAR,
      Double valueInWatts,
      NodeType nodeType,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (valueInWatts != null && valueInVAR != null) {
      double va = LoadUtil.getVa(valueInWatts, valueInVAR);
      EfficiencyLoad el =
          retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
              nodeIdentifier,
              nodeType,
              va,
              loadSummary.getNodeToEfficiencyTableMap().get(nodeIdentifier),
              efficiencyTableMap);
      loadSummary.aggregateOriginalVar(valueInVAR);
      loadSummary.aggregateVar(valueInVAR / el.getExPF());
    }
  }

  private void adjustLoadSummariesATUDegraded(
      SummarizedLoad loadSummary, Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (!loadSummary.getAtuWsEssentialLoad().isEmpty()) {
      loadSummary
          .getAtuWsEssentialLoad()
          .forEach(
              (k, v) -> {
                Double valueInVAR = loadSummary.getAtuVarsEssentialLoad().get(k);
                aggregateOriginalValEssentialLoad(
                    loadSummary, k, v, valueInVAR, NodeType.ATU, efficiencyTableMap);
              });

      loadSummary
          .getAtuVarsEssentialLoad()
          .forEach(
              (k, v) -> {
                Double valueInWatts = loadSummary.getAtuWsEssentialLoad().get(k);
                aggregateOriginalVarEssentialLoad(
                    loadSummary, k, v, valueInWatts, NodeType.ATU, efficiencyTableMap);
              });
    }
  }

  private void aggregateOriginalValEssentialLoad(
      SummarizedLoad loadSummary,
      String nodeIdentifier,
      Double valueInWatts,
      Double valueInVAR,
      NodeType nodeType,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (valueInWatts != null && valueInVAR != null) {
      double va = LoadUtil.getVa(valueInWatts, valueInVAR);
      EfficiencyLoad el =
          retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
              nodeIdentifier,
              nodeType,
              va,
              loadSummary.getNodeToEfficiencyTableMap().get(nodeIdentifier),
              efficiencyTableMap);
      loadSummary.aggregateOriginalWEssentialLoad(valueInWatts);
      double adjustedLoad = valueInWatts / el.getExPF();
      if (NodeType.TRU.equals(nodeType)) {
        // aggregate the VAR based on the efficiency table pf + adjusted va
        if (loadSummary.getOperatingMode().equals(BOEING_NORMAL_CALCULATION)
            || loadSummary.getOperatingMode().equals(BOEING_717_NORMAL_CALCULATION)) {
          double adjustedW = LoadUtil.getW(adjustedLoad, el.getPowerFactor());
          loadSummary.aggregateWEssentialLoad(adjustedW);
        } else {
          loadSummary.aggregateWEssentialLoad(adjustedLoad);
        }
        double var = LoadUtil.getVar(adjustedLoad, el.getPowerFactor());
        loadSummary.aggregateVarEssentialLoad(var);
      } else {
        loadSummary.aggregateWEssentialLoad(adjustedLoad);
      }
    }
  }

  private void aggregateOriginalVarEssentialLoad(
      SummarizedLoad loadSummary,
      String nodeIdentifier,
      Double valueInVAR,
      Double valueInWatts,
      NodeType nodeType,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (valueInWatts != null && valueInVAR != null) {
      double va = LoadUtil.getVa(valueInWatts, valueInVAR);
      EfficiencyLoad el =
          retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
              nodeIdentifier,
              nodeType,
              va,
              loadSummary.getNodeToEfficiencyTableMap().get(nodeIdentifier),
              efficiencyTableMap);
      loadSummary.aggregateOriginalVarEssentialLoad(valueInVAR);
      loadSummary.aggregateVarEssentialLoad(valueInVAR / el.getExPF());
    }
  }

  private void adjustLoadSummariesTRU(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    adjustLoadSummariesTRUNormal(
        loadSummaryMap, loadSummary, loadSummaryOptions, efficiencyTableMap);
    // for degraded analysis of TRU Transformers
    if (loadSummaryOptions.getIncludeEssentialLoadAggregate()) {
      adjustLoadSummariesTRUDegraded(
          loadSummaryMap, loadSummary, loadSummaryOptions, efficiencyTableMap);
    }
  }

  private void adjustLoadSummariesTRUNormal(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (!loadSummary.getTruWs().isEmpty()) {
      loadSummary
          .getTruWs()
          .forEach(
              (k, v) -> {
                aggregateVal(loadSummary, k, v, 0d, NodeType.TRU, efficiencyTableMap);
              });

      if (ElectricalPhase.DC.equals(loadSummary.getElectricalPhase())) {
        // split loads that are type TRU and phase DC equally between ACA, ACB, ACC
        TruLoadSummaryCalculator.calcLoadSummariesDCSplitNormal(
            loadSummaryMap, loadSummary, loadSummaryOptions);
      }
    }
  }

  private void adjustLoadSummariesTRUDegraded(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {
    if (!loadSummary.getTruWsEssentialLoad().isEmpty()) {
      loadSummary
          .getTruWsEssentialLoad()
          .forEach(
              (k, v) -> {
                aggregateOriginalValEssentialLoad(
                    loadSummary, k, v, 0d, NodeType.TRU, efficiencyTableMap);
              });

      if (ElectricalPhase.DC.equals(loadSummary.getElectricalPhase())) {
        // split loads that are type TRU and phase DC equally between ACA, ACB, ACC
        TruLoadSummaryCalculator.calcLoadSummariesDCSplitDegraded(
            loadSummaryMap, loadSummary, loadSummaryOptions);
      }
    }
  }

  private void debugLoadSummary(Node node, SummarizedLoad summarizedLoad) {
    logger.debug(
        "Summarized load for {} {} summaryType: {} flightPhase: {} electricalPhase: {} operatingMode: {} isMaxImbalance: {} isMaxPhaseLoad: {} W: {} Var: {} Va: {} powerFactor: {}",
        node.getNodeType(),
        node.getName(),
        summarizedLoad.getSummaryType(),
        summarizedLoad.getFlightPhase(),
        summarizedLoad.getElectricalPhase(),
        summarizedLoad.getOperatingMode(),
        summarizedLoad.isMaxImbalance(),
        summarizedLoad.isMaxPhaseLoad(),
        summarizedLoad.getW(),
        summarizedLoad.getVar(),
        summarizedLoad.getVa(),
        summarizedLoad.getPowerFactor());
  }

  /**
   * Calculate the transformer adjusted load. This adjusted load value depends on the efficiency
   * power factor. Determine the closest efficiency power factor and then divide the load by it to
   * get the adjusted load.
   *
   * @param nodeIdentifier - the node id or name. only used for logging purposes
   * @param nodeType - the node type
   * @param value - the value
   * @param efficiencyTableId - the efficiency table record to use to adjust the load
   * @param efficiencyTableMap - the efficiency table map keyed by efficiency table id
   * @return - the efficiency load closest to the given value (current for ATU, otherwise active
   *     power)
   */
  public EfficiencyLoad retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
      String nodeIdentifier,
      NodeType nodeType,
      Double value,
      UUID efficiencyTableId,
      Map<UUID, EfficiencyTable> efficiencyTableMap) {

    EfficiencyTable efficiencyTable =
        findEfficiencyTableById(efficiencyTableMap, efficiencyTableId);
    return findClosestEfficiencyLoad(nodeIdentifier, nodeType, value, efficiencyTable);
  }

  private EfficiencyTable findEfficiencyTableById(
      Map<UUID, EfficiencyTable> efficiencyTableMap, UUID efficiencyTableId) {
    EfficiencyTable efficiencyTable = efficiencyTableMap.get(efficiencyTableId);
    if (efficiencyTable == null) {
      throw new InternalServerErrorException(
          "Unable to locate efficiency table for id " + efficiencyTableId);
    }
    return efficiencyTable;
  }

  private EfficiencyLoad findClosestEfficiencyLoad(
      String nodeIdentifier, NodeType nodeType, Double value, EfficiencyTable efficiencyTable) {
    return efficiencyTable.getLoads().stream()
        .min(
            Comparator.comparingDouble(
                el ->
                    nodeType == NodeType.ATU
                        ? Math.abs(el.getCurrent() - value)
                        : Math.abs(el.getActivePower() - value)))
        .orElseThrow(
            () ->
                new InternalServerErrorException(
                    "Unable to find an efficiency power factor for the type: '"
                        + nodeType.name()
                        + "' , the value: '"
                        + value
                        + "' , and the node ID or name: '"
                        + nodeIdentifier
                        + "'",
                    Level.ERROR));
  }
}
