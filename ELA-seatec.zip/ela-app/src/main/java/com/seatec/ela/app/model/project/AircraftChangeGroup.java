package com.seatec.ela.app.model.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.base.BaseEntity;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "aircraft_change_group")
public class AircraftChangeGroup extends BaseEntity {

  @JsonIgnore
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "change_group_id", insertable = true, updatable = false, nullable = false)
  private ChangeGroup changeGroup;

  @ManyToOne
  @JoinColumn(name = "aircraft_id", insertable = true, updatable = false, nullable = false)
  private Aircraft aircraft;

  public Aircraft getAircraft() {
    return aircraft;
  }

  public void setAircraft(Aircraft aircraft) {
    this.aircraft = aircraft;
  }

  public ChangeGroup getChangeGroup() {
    return changeGroup;
  }

  public void setChangeGroup(ChangeGroup changeGroup) {
    this.changeGroup = changeGroup;
  }
}
