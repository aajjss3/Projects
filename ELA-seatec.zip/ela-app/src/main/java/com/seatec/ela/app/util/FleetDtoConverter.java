package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.model.Fleet;

public class FleetDtoConverter {
  public static Fleet convertToEntity(FleetDto fleetDto) {
    if (fleetDto == null) {
      return null;
    }
    return new Fleet(
        fleetDto.getId(),
        fleetDto.getName(),
        fleetDto.getManufacturer(),
        fleetDto.getBusStructureBucket(),
        fleetDto.getStructureName(),
        fleetDto.isArchived(),
        fleetDto.isEtops());
  }

  public static FleetDto convertToDto(Fleet fleet) {
    if (fleet == null) {
      return null;
    }
    return new FleetDto(fleet);
  }
}
