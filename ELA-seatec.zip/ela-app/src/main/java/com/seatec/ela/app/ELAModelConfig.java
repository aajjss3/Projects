package com.seatec.ela.app;

import com.zaxxer.hikari.HikariDataSource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.cache.CacheManagerCustomizer;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.support.OpenEntityManagerInViewInterceptor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = "entityManagerFactory",
    transactionManagerRef = "modelTransactionManager",
    basePackages = {"com.seatec.ela.app.model.repository"})
public class ELAModelConfig {
  @Bean
  @Primary
  @ConfigurationProperties("app.datasource")
  public DataSourceProperties modelDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean(name = "modelDataSource")
  @Primary
  @ConfigurationProperties("app.datasource.configuration")
  public DataSource modelDataSource() {
    return modelDataSourceProperties()
        .initializeDataSourceBuilder()
        .type(HikariDataSource.class)
        .build();
  }

  @Bean(name = "entityManagerFactory")
  @Primary
  public LocalContainerEntityManagerFactoryBean entityManagerFactory(
      EntityManagerFactoryBuilder builder, @Qualifier("modelDataSource") DataSource dataSource) {
    return builder
        .dataSource(dataSource)
        .packages("com.seatec.ela.app.model")
        .persistenceUnit("elaappdb")
        .build();
  }

  @Bean(name = "modelTransactionManager")
  @Primary
  public PlatformTransactionManager modelTransactionManager(
      @Qualifier("entityManagerFactory") EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }

  @Bean(name = "testEntityManager")
  public TestEntityManager testEntityManager(
      @Qualifier("entityManagerFactory") EntityManagerFactory entityManagerFactory) {
    return new TestEntityManager(entityManagerFactory);
  }

  /**
   * Customize the cache manager in _local_ environments. Spring Boot autoconfiguration will only
   * invoke this customizer when the "generic" cache strategy is selected which currently only
   * applies in local envs. In deployed environments, the RedisCacheManager is selected thus
   * ignoring this customizer.
   *
   * @return
   */
  @Bean
  public CacheManagerCustomizer<ConcurrentMapCacheManager> customizeCacheManager() {
    return new CacheManagerCustomizer<ConcurrentMapCacheManager>() {
      @Override
      public void customize(ConcurrentMapCacheManager cacheManager) {
        // Rather than store object _references_, make copies of cached objects
        // so modifications of object graphs will only be transient.
        cacheManager.setStoreByValue(true);
      }
    };
  }

  @Configuration
  public class JpaWebConfig implements WebMvcConfigurer {
    @Autowired
    @Qualifier("entityManagerFactory")
    EntityManagerFactory entityManagerFactory;

    @Bean
    public OpenEntityManagerInViewInterceptor openEntityManagerInViewInterceptor() {
      OpenEntityManagerInViewInterceptor intercept = new OpenEntityManagerInViewInterceptor();
      intercept.setEntityManagerFactory(entityManagerFactory);
      return intercept;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
      registry.addWebRequestInterceptor(openEntityManagerInViewInterceptor());
    }
  }
}
