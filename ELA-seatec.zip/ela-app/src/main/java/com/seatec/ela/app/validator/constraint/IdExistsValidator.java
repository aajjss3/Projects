package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.model.repository.BaseDAO;
import com.seatec.ela.app.validator.annotation.IdExists;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Validate if a database record exists for the id(primary key) and entity(table) passed in. The
 * primary key of some domain entities are declared as Long and others as UUID so this class
 * declares the id type as Object to handle both scenarios.
 *
 * @author asparago
 */
public class IdExistsValidator implements ConstraintValidator<IdExists, Object> {

  private Class<?> entity;

  @Autowired BaseDAO baseDao;

  @Override
  public void initialize(IdExists constraintAnnotation) {
    this.entity = constraintAnnotation.entity();
  }

  @Override
  public boolean isValid(Object id, ConstraintValidatorContext context) {
    return baseDao.isValidId(entity, id);
  }
}
