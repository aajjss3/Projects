package com.seatec.ela.app.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.ArrayList;
import java.util.List;

/**
 * Used for server side pagination.
 *
 * @author asparago
 */
public class PaginationDTO<T> {

  @JsonInclude(Include.NON_NULL)
  private Integer page;

  @JsonInclude(Include.NON_NULL)
  private Integer size;

  @JsonInclude(Include.NON_NULL)
  private Integer totalPages;

  @JsonInclude(Include.NON_NULL)
  private Long totalRecords;

  private List<T> contents = new ArrayList<>();

  public Integer getPage() {
    return page;
  }

  public Integer getSize() {
    return size;
  }

  public List<T> getContents() {
    return contents;
  }

  public void setContents(List<T> contents) {
    this.contents = contents;
  }

  public void setPage(Integer page) {
    this.page = page;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public void addContents(List<T> contents) {
    this.contents.addAll(contents);
  }

  public Integer getTotalPages() {
    return totalPages;
  }

  public void setTotalPages(Integer totalPages) {
    this.totalPages = totalPages;
  }

  public Long getTotalRecords() {
    return totalRecords;
  }

  public void setTotalRecords(Long totalRecords) {
    this.totalRecords = totalRecords;
  }

  public void setMetadata(Integer page, Integer size, Integer totalPages, Long totalRecords) {
    this.page = page;
    this.size = size;
    this.totalPages = totalPages;
    this.totalRecords = totalRecords;
  }
}
