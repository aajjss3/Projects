package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.ComponentUtil;
import com.seatec.ela.app.util.enumeration.PseudoFlightPhase;
import java.util.List;

/** ConnectedLoadAggregator aggregates the component's connected load */
public class ConnectedLoadAggregator implements IPseudoFlightPhaseAggregator {

  private static final PseudoFlightPhase CONNECTED_LOAD = PseudoFlightPhase.ConnectedLoad;

  public PseudoFlightPhase getPseudoFlightPhase() {
    return CONNECTED_LOAD;
  }

  public void aggregateLoadSummary(SummarizedLoad loadSummary, Component component) {
    double connectedLoadW = ComponentUtil.getConnectedLoadW(component);
    double connectedLoadVar = ComponentUtil.getConnectedLoadVar(component);

    loadSummary.aggregateW(connectedLoadW);
    loadSummary.aggregateVar(connectedLoadVar);
  }

  public void aggregateLoadSummariesPhaseSplit(
      List<SummarizedLoad> loadSummaries, Component component) {

    double splitConnectedLoadW =
        ComponentUtil.getConnectedLoadW(component) / LoadSummaryUtil.THREE_PHASE_SPLIT;
    double splitConnectedLoadVar =
        ComponentUtil.getConnectedLoadVar(component) / LoadSummaryUtil.THREE_PHASE_SPLIT;

    for (SummarizedLoad loadSummary : loadSummaries) {
      loadSummary.aggregateW(splitConnectedLoadW);
      loadSummary.aggregateVar(splitConnectedLoadVar);
    }
  }
}
