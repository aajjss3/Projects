package com.seatec.ela.app.service.contract.project;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectCommentDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.ProjectWrapperDTO;
import com.seatec.ela.app.model.project.Project;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Service for dealing with Projects. */
public interface IProjectService {

  PaginationDTO<ProjectDTO> getAllProjects(String userId, Integer page, Integer size);

  Optional<Project> findById(UUID id, String userId);

  Optional<Project> findById(UUID id);

  Project initialSave(Project entity);

  void deleteProject(UUID id, String userId);

  void updateProject(Project entity, UUID id);

  PaginationDTO<AssignedProjectDTO> getMyProjects(
      String userId, Integer page, Integer size, String sortField, boolean sortDirection);

  PaginationDTO<ProjectWrapperDTO> getPendingReviewProjects(
      String userId, Integer page, Integer size);

  void submitProject(UUID projectId, String userId, ProjectCommentDTO comment);

  void checkProject(UUID projectId, String userId, ProjectCommentDTO comment);

  void approveProject(UUID projectId, String userId, ProjectCommentDTO comment);

  void rejectProject(UUID projectId, ProjectCommentDTO comment, String userId, String role);

  void setProjectCoauthors(UUID projectId, List<String> coauthors);

  void saveProjectAnalysis(UUID projectId);

  PaginationDTO<AssignedProjectDTO> getApprovedProjects(
      String aircraftShipNo,
      String fleetNumber,
      String projectNumber,
      String projectDescription,
      String projectTitle,
      String maintenceDescription,
      boolean isEntire,
      Integer page,
      Integer size,
      String sortField,
      boolean sortAscending);
}
