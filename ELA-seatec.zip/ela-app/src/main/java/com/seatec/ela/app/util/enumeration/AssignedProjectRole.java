package com.seatec.ela.app.util.enumeration;

public enum AssignedProjectRole {
  APPROVER,
  CHECKER,
  AUTHOR,
  COAUTHOR,
  NONE
}
