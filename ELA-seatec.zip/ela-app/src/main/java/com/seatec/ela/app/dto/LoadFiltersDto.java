package com.seatec.ela.app.dto;

public class LoadFiltersDto {
  private final String flightPhase;
  private final String operatingMode;

  public LoadFiltersDto(String flightPhase, String operatingMode) {
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public String getOperatingMode() {
    return operatingMode;
  }
}
