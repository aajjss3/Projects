package com.seatec.ela.app.validator.annotation;

import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;
import org.springframework.beans.factory.annotation.Autowired;

@Target({
  ElementType.FIELD,
  ElementType.TYPE,
  ElementType.METHOD,
  ElementType.PARAMETER,
  ElementType.ANNOTATION_TYPE
})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = AircraftOrFleetExists.Validator.class)
@Documented
public @interface AircraftOrFleetExists {
  int fleet() default 2; // position of the fleet param in the method signature

  int aircraft() default 1; // position of the aircraft param in the method signature

  String message() default "Either the aircraft or fleet is not valid";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  // required since validating a methods input parameters using cross-parameter constraints
  @SupportedValidationTarget({ValidationTarget.PARAMETERS})
  class Validator implements ConstraintValidator<AircraftOrFleetExists, Object[]> {

    private int aircraft; // position of the aircraft param in the method signature, starting with 1
    private int fleet; // position of the fleet param in the method signature, starting with 1

    @Autowired AircraftRepository aircraftRepo;
    @Autowired FleetRepository fleetRepo;

    @Override
    public void initialize(AircraftOrFleetExists constraintAnnotation) {
      this.fleet = constraintAnnotation.fleet();
      this.aircraft = constraintAnnotation.aircraft();
    }

    @Override
    public boolean isValid(Object[] value, ConstraintValidatorContext context) {
      String aircraftShipNo = (String) value[aircraft - 1]; // zero based
      String fleetName = (String) value[fleet - 1]; // zero based
      if (aircraftShipNo != null && !aircraftShipNo.isEmpty()) {
        if (aircraftRepo.findByAircraftShipNo(aircraftShipNo).isEmpty()) {
          return buildCustomConstraint(
              "{field.invalid.aircraft}" + ": " + aircraftShipNo, "aircraft", context);
        }
      } else if (fleetName != null && !fleetName.isEmpty()) {
        if (fleetRepo.findByName(fleetName).isEmpty()) {
          return buildCustomConstraint(
              "{field.invalid.fleet}" + ": " + fleetName, "fleet", context);
        }
      }
      return true;
    }

    private boolean buildCustomConstraint(
        String message, String field, ConstraintValidatorContext context) {
      // disable default constraint violation and build custom message
      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(message)
          .addPropertyNode(field)
          .addConstraintViolation();
      return false;
    }
  }
}
