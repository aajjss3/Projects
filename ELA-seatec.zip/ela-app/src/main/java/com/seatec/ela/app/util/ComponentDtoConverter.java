package com.seatec.ela.app.util;

import static com.seatec.ela.app.util.LoadDtoConverter.convertLoadChangesToLoadDtos;

import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.project.ComponentChange;
import java.util.ArrayList;
import java.util.List;

public class ComponentDtoConverter {
  public static ComponentDto convertComponentChangeToComponentDto(ComponentChange componentChange) {
    ComponentDto componentDto =
        new ComponentDto(
            componentChange.getName(),
            componentChange.getAta(),
            componentChange.getDisplayOrder(),
            componentChange.getClipsed(),
            componentChange.getSheddable(),
            componentChange.getElectIdent(),
            componentChange.getPanel(),
            componentChange.getNominalPower(),
            componentChange.getElectricalPhase(),
            componentChange.getIntermittent(),
            componentChange.getConnectedLoadVa(),
            componentChange.getConnectedLoadPf());

    // convert Loads
    if (componentChange.getLoadChanges() != null) {
      componentDto.setLoads(convertLoadChangesToLoadDtos(componentChange.getLoadChanges()));
    }

    return componentDto;
  }

  public static List<ComponentDto> convertComponentChangesToComponentDtos(
      List<ComponentChange> componentChanges) {
    List<ComponentDto> componentDtos = new ArrayList<>();

    for (ComponentChange componentChange : componentChanges) {
      componentDtos.add(convertComponentChangeToComponentDto(componentChange));
    }

    return componentDtos;
  }

  public static ComponentDto convertComponentToComponentDto(Component component) {
    return new ComponentDto(
        component.getName(),
        component.getAta(),
        component.getDisplayOrder(),
        component.getClipsed(),
        component.getSheddable(),
        component.getElectIdent(),
        component.getPanel(),
        component.getNominalPower(),
        component.getElectricalPhase(),
        component.getIntermittent(),
        component.getConnectedLoadVa(),
        component.getConnectedLoadPf());
  }
}
