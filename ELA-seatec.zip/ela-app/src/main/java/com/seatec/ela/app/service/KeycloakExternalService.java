package com.seatec.ela.app.service;

import static com.seatec.ela.app.service.KeycloakService.DEFAULT_ROLE;
import static com.seatec.ela.app.service.KeycloakService.UMA_PROTECTION_ROLE;

import com.google.gson.GsonBuilder;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.InternalServerErrorException;
import com.seatec.ela.app.exception.NotAcceptableException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.exception.UnauthorizedException;
import com.seatec.ela.app.service.contract.IKeycloakExternalService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;

@Service
public class KeycloakExternalService implements IKeycloakExternalService {

  @Autowired private KeycloakRestTemplate keycloakRestTemplate;

  private static final int MAX_USERS = 500;
  private static final String KEYCLOAK_CLIENT_ENDPOINT = "clients";
  private static final String KEYCLOAK_USER_ENDPOINT = "users";
  private static final String KEYCLOAK_GET_USER_ENDPOINT =
      KEYCLOAK_USER_ENDPOINT + "?briefRepresentation=true&max=" + MAX_USERS;
  private static final String KEYCLOAK_ROLES_ENDPOINT = "roles";
  private static final Pattern USER_ID_REGEX = Pattern.compile("^.*\\/([a-zA-Z0-9-]+)$");

  private String keycloakBaseUrl;

  @Value("${keycloak.auth-server-url}")
  private String keycloakServerUrl;

  @Value("${keycloak.realm}")
  private String keycloakRealmName;

  @Value("${keycloak.resource}")
  private String keycloakClient;

  @Value("${keycloak-ui-client}")
  private String keycloakUIClient;

  public KeycloakExternalService() {}

  public KeycloakExternalService(
      KeycloakRestTemplate restTemplate,
      String keycloakServerUrl,
      String keycloakRealmName,
      String keycloakClient,
      String keycloakUIClient) {
    this.keycloakRestTemplate = restTemplate;
    this.keycloakServerUrl = keycloakServerUrl;
    this.keycloakRealmName = keycloakRealmName;
    this.keycloakClient = keycloakClient;
    this.keycloakUIClient = keycloakUIClient;
    init();
  }

  @PostConstruct
  public void init() {
    this.keycloakBaseUrl = this.keycloakServerUrl + "/admin/realms/" + this.keycloakRealmName + "/";
  }

  /**
   * Search keycloak and return all users from a realm.
   *
   * @return collection of UserRepresentation Entities
   */
  public List<UserRepresentation> findAllUsers() {
    List<UserRepresentation> users = new ArrayList<>();
    users.addAll(
        getKeycloakCollection(KEYCLOAK_GET_USER_ENDPOINT + "&first=0", UserRepresentation[].class));
    // until we add paging, get another set if we have exactly MAX_USERS users
    int returnedCount = users.size();
    int first = 0;
    while (returnedCount == MAX_USERS) {
      first = first + MAX_USERS;
      String url = KEYCLOAK_GET_USER_ENDPOINT + "&first=" + first;
      List<UserRepresentation> userPage = getKeycloakCollection(url, UserRepresentation[].class);
      users.addAll(userPage);
      returnedCount = userPage.size();
    }
    users.stream().filter(user -> user.isEnabled()).forEach(this::fetchUserRoles);
    // only return users that have at least one client role
    return users.stream()
        .filter(
            u -> u.getClientRoles() != null && u.getClientRoles().get(keycloakClient).size() > 0)
        .collect(Collectors.toList());
  }

  /**
   * Search Keycloak by Realm for a matching User
   *
   * @param id Represents the Keycloak User unique identifier
   * @throws NotAcceptableException
   * @throws BadRequestException
   * @throws NotFoundException
   * @throws UnauthorizedException
   * @throws InternalServerErrorException
   * @throws NullPointerException
   * @return matching UserRepresentation entity
   */
  public UserRepresentation findUser(String id) {
    UserRepresentation user =
        getKeycloakEntity(KEYCLOAK_USER_ENDPOINT + "/" + id, UserRepresentation.class);
    fetchUserRoles(user);
    return user.getClientRoles().get(keycloakClient).size() > 0 ? user : null;
  }

  @Override
  public List<String> findAllRoles() {
    List<RoleRepresentation> roles =
        getKeycloakCollection(
            KEYCLOAK_CLIENT_ENDPOINT
                + "/"
                + findClient(keycloakClient).getId()
                + "/"
                + KEYCLOAK_ROLES_ENDPOINT,
            RoleRepresentation[].class);
    return roles.stream()
        .filter(r -> !r.getName().equals(DEFAULT_ROLE) && !r.getName().equals(UMA_PROTECTION_ROLE))
        .map(r -> r.getName())
        .sorted()
        .collect(Collectors.toList());
  }

  /**
   * Creates a new Keycloak User
   *
   * @param user Represents a Keycloak UserRepresentation Entity
   */
  public void createUser(UserRepresentation user) {
    ResponseEntity<UserRepresentation> response =
        createKeycloakEntity(KEYCLOAK_USER_ENDPOINT, user, UserRepresentation.class);
    // get the new id for the user off the Location header
    String newUserId = getNewUserId(response);
    // manually update user profile settings
    // createKeycloakEntity() call doesnt handle realm/client roles or groups
    if (newUserId != null) {
      // add realm roles to user profile
      if (user.getRealmRoles() != null) {
        addUserToRealmRoles(user.getRealmRoles(), newUserId);
      }
      // add client roles to user profile
      if (user.getClientRoles() != null) {
        addUserToClientRoles(user.getClientRoles(), newUserId);
      }
    } else {
      throw new NotFoundException(
          "Unable to locate new user id by from location header", Level.ERROR);
    }
  }

  public RoleRepresentation getRoleByName(String roleName) {
    String client = findClient(keycloakClient).getId();
    String sb =
        new StringBuilder()
            .append(KEYCLOAK_CLIENT_ENDPOINT)
            .append("/" + client)
            .append("/" + KEYCLOAK_ROLES_ENDPOINT)
            .append("/" + roleName)
            .toString();

    return getKeycloakEntity(sb, RoleRepresentation.class);
  }

  /**
   * Updates an existing Keycloak User
   *
   * @param user Represents a Keycloak UserRepresentation Entity
   */
  public void updateUser(UserRepresentation user) {
    updateKeycloakEntity(KEYCLOAK_USER_ENDPOINT + "/" + user.getId(), user);
    if (user.getClientRoles() != null) {
      for (Map.Entry<String, List<String>> entry : user.getClientRoles().entrySet()) {
        if (!entry.getKey().equals(keycloakClient)
            && !entry.getKey().equals(KeycloakService.REALM_MANAGEMENT_CLIENT)
            && !entry.getKey().equals(keycloakUIClient)) {
          throw new NotAcceptableException("Unsupported client " + entry.getKey());
        }
        if (entry.getKey().equals(keycloakUIClient) && entry.getValue().size() > 1) {
          throw new NotAcceptableException("Only one client role is allowed");
        } else if (entry.getKey().equals(keycloakClient) && entry.getValue().size() > 2) {
          throw new NotAcceptableException("Only one client role is allowed");
        }
        List<RoleRepresentation> existingRoles =
            getUserClientRoles(user.getId(), findClient(entry.getKey()).getId());
        Map<String, RoleRepresentation> existingRoleMap =
            existingRoles.stream()
                .collect(Collectors.toMap(RoleRepresentation::getName, Function.identity()));
        Set<String> newRoleNames = new HashSet<>(entry.getValue());
        List<String> rolesToAdd = new ArrayList<>();
        for (String roleName : entry.getValue()) {
          if (!existingRoleMap.keySet().contains(roleName)) {
            rolesToAdd.add(roleName);
          }
        }
        List<RoleRepresentation> rolesToDelete = new ArrayList<>();
        for (String roleName : existingRoleMap.keySet()) {
          if (!newRoleNames.contains(roleName)) {
            rolesToDelete.add(existingRoleMap.get(roleName));
          }
        }
        if (!rolesToDelete.isEmpty()) {
          deleteClientRoles(rolesToDelete, entry.getKey(), user.getId());
        }
        if (!rolesToAdd.isEmpty()) {
          Map<String, List<String>> roles = new HashMap<>();
          roles.put(entry.getKey(), rolesToAdd);
          addUserToClientRoles(roles, user.getId());
        }
      }
    }
  }

  private void fetchUserRoles(UserRepresentation user) {
    Map<String, List<String>> clientRoles = user.getClientRoles();
    if (clientRoles == null) {
      clientRoles = new HashMap<>();
      user.setClientRoles(clientRoles);
    }
    clientRoles.put(
        keycloakClient,
        getUserClientRoles(user.getId(), findClient(keycloakClient).getId()).stream()
            .filter(rr -> !rr.getName().equals(DEFAULT_ROLE))
            .map(RoleRepresentation::getName)
            .collect(Collectors.toList()));
  }

  private ClientRepresentation findClient(String name) {
    Optional<ClientRepresentation> client =
        getClients().stream().filter(c -> c.getClientId().equals(name)).findFirst();
    return client.orElse(null);
  }

  private List<ClientRepresentation> getClients() {
    return getKeycloakCollection(KEYCLOAK_CLIENT_ENDPOINT, ClientRepresentation[].class);
  }

  /**
   * The create user endpoint retunrs a 201 response + a Location header that contains the newly
   * created user's id. Fetch the id off the location header via regex.
   *
   * @param response the response from the create API call to keycloak
   * @return the id or null if it can't be found
   */
  private String getNewUserId(ResponseEntity<UserRepresentation> response) {
    List<String> headers = response.getHeaders().get("Location");
    if (headers.size() == 1) {
      String location = headers.get(0);
      // get id from the last part of the URL path
      Matcher m = USER_ID_REGEX.matcher(location);
      if (m.matches()) {
        return m.group(1);
      }
    }
    return null;
  }

  private List<RoleRepresentation> getUserClientRoles(String userid, String clientId) {
    return getKeycloakCollection(
        KEYCLOAK_USER_ENDPOINT + "/" + userid + "/role-mappings/clients/" + clientId,
        RoleRepresentation[].class);
  }

  private void addUserToRealmRoles(List<String> realmRoles, String userId) {
    List<RoleRepresentation> availableRealmRoles = getAvailableRealmRoles(userId);

    RoleRepresentation[] roles =
        realmRoles.stream()
            .map(r -> findRole(r, availableRealmRoles))
            .collect(Collectors.toList())
            .toArray(new RoleRepresentation[] {});

    createKeycloakEntity(
        KEYCLOAK_USER_ENDPOINT + "/" + userId + "/role-mappings/realm",
        roles,
        RoleRepresentation[].class);
  }

  private void addUserToClientRoles(Map<String, List<String>> clientRoleSet, String userId) {
    for (Map.Entry<String, List<String>> entry : clientRoleSet.entrySet()) {
      if (!entry.getKey().equals(keycloakClient)
          && !entry.getKey().equals(KeycloakService.REALM_MANAGEMENT_CLIENT)
          && !entry.getKey().equals(keycloakUIClient)) {
        throw new NotAcceptableException("Unsupported client " + entry.getKey());
      }

      String clientId = findClient(entry.getKey()).getId();
      List<RoleRepresentation> availableClientRoles = getAvailableClientRoles(userId, clientId);
      List<RoleRepresentation> clientRoles =
          entry.getValue().stream()
              .map(r -> findRole(r, availableClientRoles))
              .filter(Objects::nonNull)
              .collect(Collectors.toList());
      if (!clientRoles.isEmpty()) {
        String url = KEYCLOAK_USER_ENDPOINT + "/" + userId + "/role-mappings/clients/" + clientId;

        createKeycloakEntity(
            url, clientRoles.toArray(new RoleRepresentation[] {}), RoleRepresentation[].class);
      }
    }
  }

  private void deleteClientRoles(List<RoleRepresentation> roles, String client, String userId) {
    deleteKeycloakEntity(
        KEYCLOAK_USER_ENDPOINT
            + "/"
            + userId
            + "/role-mappings/clients/"
            + findClient(client).getId(),
        roles);
  }

  private RoleRepresentation findRole(String name, List<RoleRepresentation> roles) {
    Optional<RoleRepresentation> role =
        roles.stream().filter(r -> r.getName().equals(name)).findFirst();
    return role.orElse(null);
  }

  private List<RoleRepresentation> getAvailableRealmRoles(String userid) {
    return getKeycloakCollection(
        KEYCLOAK_USER_ENDPOINT + "/" + userid + "/role-mappings/realm/available",
        RoleRepresentation[].class);
  }

  private List<RoleRepresentation> getAvailableClientRoles(String userid, String clientId) {
    return getKeycloakCollection(
        KEYCLOAK_USER_ENDPOINT + "/" + userid + "/role-mappings/clients/" + clientId + "/available",
        RoleRepresentation[].class);
  }

  private <T> List<T> getKeycloakCollection(String requestUrl, Class<T[]> keycloakClass) {
    String externalApiUrl = keycloakBaseUrl + requestUrl;

    try {
      ResponseEntity<T[]> response =
          keycloakRestTemplate.getForEntity(externalApiUrl, keycloakClass);

      return Arrays.asList(response.getBody());
    } catch (HttpStatusCodeException e) {
      if (e.getRawStatusCode() == 404) {
        return Collections.emptyList();
      } else {
        throw errorHandler(e, externalApiUrl);
      }
    }
  }

  private <T> T getKeycloakEntity(String requestUrl, Class<T> keycloakClass) {
    String externalApiUrl = keycloakBaseUrl + requestUrl;

    try {
      ResponseEntity<T> response = keycloakRestTemplate.getForEntity(externalApiUrl, keycloakClass);
      return response.getBody();
    } catch (HttpStatusCodeException e) {
      throw errorHandler(e, externalApiUrl);
    }
  }

  private <T> ResponseEntity<T> createKeycloakEntity(
      String requestUrl, Object body, Class<T> keycloakClass) {
    String externalApiUrl = keycloakBaseUrl + requestUrl;

    try {
      ResponseEntity responseEntity =
          keycloakRestTemplate.postForEntity(externalApiUrl, body, keycloakClass);
      return responseEntity;
    } catch (HttpStatusCodeException e) {
      throw errorHandler(e, externalApiUrl);
    }
  }

  private void updateKeycloakEntity(String requestUrl, Object body) {
    String externalApiUrl = keycloakBaseUrl + requestUrl;

    try {
      keycloakRestTemplate.put(externalApiUrl, body);
    } catch (HttpStatusCodeException e) {
      throw errorHandler(e, externalApiUrl);
    }
  }

  private void deleteKeycloakEntity(String requestUrl, Object body) {
    String externalApiUrl = keycloakBaseUrl + requestUrl;

    try {
      GsonBuilder gsonBuilder = new GsonBuilder();
      String bodyJSON = gsonBuilder.create().toJson(body);

      HttpHeaders headers = new HttpHeaders();
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      headers.setContentType(MediaType.APPLICATION_JSON);

      HttpEntity<String> entity = new HttpEntity<>(bodyJSON, headers);
      keycloakRestTemplate.exchange(externalApiUrl, HttpMethod.DELETE, entity, String.class);
    } catch (HttpStatusCodeException e) {
      throw errorHandler(e, externalApiUrl);
    }
  }

  private static RuntimeException errorHandler(HttpStatusCodeException e, String url) {
    switch (e.getRawStatusCode()) {
      case 400:
        return new BadRequestException(
            e.getStatusCode().getReasonPhrase() + " Url: " + url, Level.ERROR);
      case 401:
        return new UnauthorizedException(
            e.getStatusCode().getReasonPhrase() + " Url: " + url, Level.ERROR);
      case 404:
        return new NotFoundException(
            e.getStatusCode().getReasonPhrase() + " Url: " + url, Level.ERROR);
      case 409:
        return new BadRequestException(
            "Entity already exists. Cannot insert duplicate.", Level.ERROR);
      case 500:
        return new InternalServerErrorException(
            e.getStatusCode().getReasonPhrase() + " Url: " + url, Level.ERROR);
      default:
        return new NotAcceptableException(
            "Unexpected HTTP Status ["
                + e.getRawStatusCode()
                + "] Reason: "
                + e.getStatusCode().getReasonPhrase(),
            Level.ERROR);
    }
  }
}
