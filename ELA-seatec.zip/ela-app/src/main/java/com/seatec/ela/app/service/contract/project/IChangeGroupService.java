package com.seatec.ela.app.service.contract.project;

import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.model.project.ChangeGroup;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Service for dealing with ChangeGroups. */
public interface IChangeGroupService {

  List<ChangeGroup> findAllByProjectId(UUID projectId);

  Optional<ChangeGroup> findById(UUID id);

  List<ChangeGroupNodeDto> findChangeGroupEffectivityBusStructureByChangeGroupId(
      UUID changeGroupId);

  ChangeGroup save(ChangeGroup entity, UUID projectId);

  void delete(UUID id);

  void update(ChangeGroup entity, UUID id);

  void updateEffectivity(List<Long> aircraftIds, UUID projectId, UUID changeGroupId);

  void saveByBusStructureBucketUsingAircraftIds(List<Long> aircraftIds, UUID projectId);

  List<ComponentDto> findComponentsByChangeGroupAndNodeName(
      ChangeGroup changeGroup, String nodeName);

  List<FleetDto> findParentFleets(UUID changeGroupId);

  void updateChangeGroupName(UUID id, String name);
}
