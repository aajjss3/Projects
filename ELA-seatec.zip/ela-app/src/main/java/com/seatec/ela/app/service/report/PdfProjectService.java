package com.seatec.ela.app.service.report;

import static com.seatec.ela.app.util.pdf.PdfFormatUtil.BOLD_FONT;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.DATE_TIME_LONG;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.ITALIC_FONT;
import static com.seatec.ela.app.util.pdf.PdfFormatUtil.PAGE_H2_FONT;

import com.lowagie.text.Chunk;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.dto.analysis.ProjectAnalysis;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.service.contract.IKeycloakService;
import com.seatec.ela.app.service.contract.report.IPdfProjectService;
import com.seatec.ela.app.service.project.ProjectAnalysisService;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.pdf.PdfFormatUtil;
import java.awt.Color;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.keycloak.representations.idm.UserRepresentation;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Contains PDF Service helper methods for generating ELA and Project reports Includes theming,
 * styles, formmatting, analysis, history, etc.
 */
@Service
public class PdfProjectService implements IPdfProjectService {
  // class font(s)
  private static final Font EFFECTIVITY_TABLE_BODY_CELL_TD_FONT = new Font(-1, 8, 0);
  private static final Font EFFECTIVITY_TABLE_HEADER_CELL_TH_FONT = new Font(-1, 10, 1);

  @Autowired private IKeycloakService keycloakService;

  @Autowired private PdfAnalysisService pdfAnalysisService;

  @Autowired private ProjectAnalysisService projectAnalysisService;

  public PdfPTable generateCoverPageForProject(Project project) {
    PdfPTable pdfPTable = new PdfPTable(2);
    pdfPTable.setWidthPercentage(100);
    pdfPTable.setWidths(new float[] {70f, 30f});

    // Column 1 - Project Info
    PdfPTable projectInfoSection =
        generateCoverPageIntroSection(
            String.format("Project: %s", project.getTitle()),
            project.getNumber(),
            project.getRevisionLevel(),
            project.getDescription(),
            project.getMaintenanceDescription());
    pdfPTable.addCell(projectInfoSection);

    // Column 2 - Signatures
    PdfPTable signatureSection = generateSignatureSection(project);
    pdfPTable.addCell(signatureSection);

    return pdfPTable;
  }

  public PdfPTable generateEffectivitySummary(List<ChangeGroup> changeGroups) {
    List<Aircraft> aircrafts = new ArrayList<>();

    // TODO: possibly streamline into single stream using .flatMap() or .addAll()
    for (ChangeGroup cg : changeGroups) {
      aircrafts.addAll(
          cg.getAircraftChangeGroups().stream()
              .map(AircraftChangeGroup::getAircraft)
              .collect(Collectors.toList()));
    }

    // sort by ship number
    List<Aircraft> sortedAircrafts =
        aircrafts.stream()
            .sorted(Comparator.comparing(Aircraft::getAircraftShipNo))
            .collect(Collectors.toList());

    PdfPTable effectivitySummaryTable = new PdfPTable(4);
    effectivitySummaryTable.setWidthPercentage(100);
    effectivitySummaryTable.setSpacingBefore(10f);

    // set table header row
    effectivitySummaryTable.setHeaderRows(1);

    // ship number (header)
    PdfPCell headerShpNoCell = createEffectivityTableHeaderCell("Customer/Ship Number");
    effectivitySummaryTable.addCell(headerShpNoCell);

    // serial number (header)
    PdfPCell headerSerialNoCell = createEffectivityTableHeaderCell("Serial Number");
    effectivitySummaryTable.addCell(headerSerialNoCell);

    // registration number (header)
    PdfPCell headerRegistrationNoCell = createEffectivityTableHeaderCell("Registration Number");
    effectivitySummaryTable.addCell(headerRegistrationNoCell);

    // ship status (header)
    PdfPCell statusCell = createEffectivityTableHeaderCell("Status");
    effectivitySummaryTable.addCell(statusCell);

    // set table body
    for (Aircraft aircraft : sortedAircrafts) {
      // ship number (body)
      PdfPCell bodyShipNoCell = createEffectivityTableBodyCell(aircraft.getAircraftShipNo());
      effectivitySummaryTable.addCell(bodyShipNoCell);

      // serial number (body)
      PdfPCell bodySerialNoCell = createEffectivityTableBodyCell(aircraft.getSerialNumber());
      effectivitySummaryTable.addCell(bodySerialNoCell);

      // registration number (body)
      PdfPCell bodyRegistrationNoCell =
          createEffectivityTableBodyCell(aircraft.getRegistrationNumber());
      effectivitySummaryTable.addCell(bodyRegistrationNoCell);

      // ship status (body)

      // default to blank
      PdfPCell bodyShipStatus = createEffectivityTableBodyCell("");

      // reverse stream (aircraft -> changeGroupId)
      Optional<ChangeGroup> matchingChangeGroup =
          aircraft.getAircraftChangeGroups().stream()
              .filter(f -> f.getAircraft().getId().equals(aircraft.getId()))
              .map(AircraftChangeGroup::getChangeGroup)
              .findFirst();

      if (matchingChangeGroup.isPresent()) {
        ProjectAnalysis aircraftAnalysis =
            projectAnalysisService
                .getAnalysis(matchingChangeGroup.get().getId(), aircraft.getId(), true)
                .get(0);

        AnalysisStatus aircraftStatus =
            pdfAnalysisService.determineAircraftStatus(
                aircraftAnalysis.getAnalysis().getNormalStatus(),
                aircraftAnalysis.getAnalysis().getDegradedStatus());

        bodyShipStatus =
            pdfAnalysisService.setStatusIconAndLabel(aircraftStatus, new Paragraph(""));
        bodyShipStatus.setBorderWidthBottom(0.25f);
        bodyShipStatus.setBorderColorBottom(Color.GRAY);
      }

      effectivitySummaryTable.addCell(bodyShipStatus);
    }

    return effectivitySummaryTable;
  }

  private PdfPCell createEffectivityTableBodyCell(String text) {
    PdfPCell cell = new PdfPCell(new Phrase(text, EFFECTIVITY_TABLE_BODY_CELL_TD_FONT));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setBorderWidthBottom(0.25f);
    cell.setBorderColorBottom(Color.GRAY);
    return cell;
  }

  private PdfPCell createEffectivityTableHeaderCell(String text) {
    return new PdfPCell(new Phrase(text, EFFECTIVITY_TABLE_HEADER_CELL_TH_FONT));
  }

  private PdfPTable generateCoverPageIntroSection(
      String title,
      String projectNumber,
      String revisionLevel,
      String description,
      String maintenanceDescription) {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.setWidthPercentage(100);

    // Project Title
    PdfPCell titleCell = PdfFormatUtil.getBlankCell();
    titleCell.addElement(new Phrase(title.toUpperCase(), PAGE_H2_FONT));
    titleCell.addElement(Chunk.NEWLINE);
    pdfPTable.addCell(titleCell);

    // Project Number
    PdfPCell projectNumberCell = PdfFormatUtil.getBlankCell();
    projectNumberCell.addElement(new Phrase("Project Number:", BOLD_FONT));
    projectNumberCell.addElement(new Phrase(projectNumber, ITALIC_FONT));
    pdfPTable.addCell(projectNumberCell);

    // Project Revision Level
    PdfPCell revisionLevelCell = PdfFormatUtil.getBlankCell();
    revisionLevelCell.addElement(new Phrase("Revision Level:", BOLD_FONT));
    revisionLevelCell.addElement(new Phrase(revisionLevel, ITALIC_FONT));
    pdfPTable.addCell(revisionLevelCell);

    // Project Description
    if (description != null && !description.isEmpty()) {
      PdfPCell descriptionCell = PdfFormatUtil.getBlankCell();
      descriptionCell.addElement(new Phrase("Description:", BOLD_FONT));
      descriptionCell.addElement(new Phrase(description, ITALIC_FONT));
      pdfPTable.addCell(descriptionCell);
    }

    // Project Maintenance Description
    if (maintenanceDescription != null && !maintenanceDescription.isEmpty()) {
      PdfPCell maintenanceDescriptionCell = PdfFormatUtil.getBlankCell();
      maintenanceDescriptionCell.addElement(new Phrase("Maintenance Description:", BOLD_FONT));
      maintenanceDescriptionCell.addElement(new Phrase(maintenanceDescription, ITALIC_FONT));
      pdfPTable.addCell(maintenanceDescriptionCell);
    }

    return pdfPTable;
  }

  private PdfPTable generateSignatureSection(Project project) {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.setWidthPercentage(100);

    PdfPCell signatureCell = PdfFormatUtil.getBlankCell();
    signatureCell.addElement(new Phrase("SIGNATURES", PAGE_H2_FONT));
    signatureCell.addElement(Chunk.NEWLINE);
    pdfPTable.addCell(signatureCell);

    try {
      // author
      pdfPTable.addCell(generateUserNameCell("Prepared by:", project.getAuthor()));

      // checker
      pdfPTable.addCell(generateUserNameCell("Checked by:", project.getCheckEngineer()));

      // approver
      pdfPTable.addCell(generateUserNameCell("Approved by:", project.getApprovalEngineer()));

      // approved date
      Instant approvalDate = project.getApproved();

      PdfPCell approvedDateCell = PdfFormatUtil.getBlankCell();
      approvedDateCell.addElement(new Phrase("Approved On:", BOLD_FONT));
      approvedDateCell.addElement(
          new Phrase(
              approvalDate != null ? DATE_TIME_LONG.format(approvalDate) : "____/____/______",
              ITALIC_FONT));
      pdfPTable.addCell(approvedDateCell);
    } catch (Exception ex) {
      throw new BadRequestException("Unable to add signatures.", Level.WARN, ex);
    }

    return pdfPTable;
  }

  private PdfPCell generateUserNameCell(String label, String userId) {
    PdfPCell pdfPCell = PdfFormatUtil.getBlankCell();
    pdfPCell.addElement(new Phrase(label, BOLD_FONT));
    pdfPCell.addElement(new Phrase(getUserName(userId), ITALIC_FONT));
    pdfPCell.addElement(Chunk.NEWLINE);

    return pdfPCell;
  }

  private String getUserName(String userId) {
    if (userId == null || userId.isEmpty()) {
      return "";
    }

    try {
      UserRepresentation user = keycloakService.findUser(userId);

      // verify user is present and first/last names exist
      if (user != null && (!user.getFirstName().isEmpty() && !user.getLastName().isEmpty())) {
        return String.format("%s %s", user.getFirstName(), user.getLastName());
      }

      return "";

    } catch (Exception ex) {
      return "";
    }
  }
}
