package com.seatec.ela.app.dto.changeGroup;

import com.seatec.ela.app.util.enumeration.ActionType;
import java.io.Serializable;

public class LoadDto implements Serializable {

  private ActionType action;

  // volt amperes
  private Double va;

  // watts
  private double w;

  // volt amperes reactive
  private double var;

  private Double powerFactor;

  private String flightPhase;

  private String operatingMode;

  private boolean edited;

  public LoadDto() {}

  public LoadDto(Double va, Double powerFactor, String flightPhase, String operatingMode) {
    this.va = va;
    this.powerFactor = powerFactor;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
  }

  public LoadDto(
      Double va,
      double w,
      double var,
      Double powerFactor,
      String flightPhase,
      String operatingMode) {
    this.va = va;
    this.w = w;
    this.var = var;
    this.powerFactor = powerFactor;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
  }

  public ActionType getAction() {
    return action;
  }

  public void setAction(ActionType action) {
    this.action = action;
  }

  public Double getVa() {
    return va;
  }

  public void setVa(Double va) {
    this.va = va;
  }

  public double getW() {
    return w;
  }

  public void setW(double w) {
    this.w = w;
  }

  public double getVar() {
    return var;
  }

  public void setVar(double var) {
    this.var = var;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public String getOperatingMode() {
    return operatingMode;
  }

  public void setOperatingMode(String operatingMode) {
    this.operatingMode = operatingMode;
  }

  public boolean isEdited() {
    return edited;
  }

  public void setEdited(boolean edited) {
    this.edited = edited;
  }

  public Double getPowerFactor() {
    return powerFactor;
  }

  public void setPowerFactor(Double powerFactor) {
    this.powerFactor = powerFactor;
  }
}
