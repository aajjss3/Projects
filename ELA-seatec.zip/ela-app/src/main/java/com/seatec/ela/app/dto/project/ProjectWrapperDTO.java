package com.seatec.ela.app.dto.project;

import java.util.ArrayList;
import java.util.List;

public class ProjectWrapperDTO {

  private List<ProjectDTO> checker = new ArrayList<ProjectDTO>();
  private List<ProjectDTO> approver = new ArrayList<ProjectDTO>();

  public ProjectWrapperDTO() {}

  public ProjectWrapperDTO(List<ProjectDTO> checker, List<ProjectDTO> approver) {
    this.approver = approver;
    this.checker = checker;
  }

  public List<ProjectDTO> getChecker() {
    return checker;
  }

  public void setChecker(List<ProjectDTO> checker) {
    this.checker = checker;
  }

  public List<ProjectDTO> getApprover() {
    return approver;
  }

  public void setApprover(List<ProjectDTO> approver) {
    this.approver = approver;
  }
}
