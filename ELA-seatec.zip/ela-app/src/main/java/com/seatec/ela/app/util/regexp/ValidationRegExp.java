package com.seatec.ela.app.util.regexp;

public class ValidationRegExp {
  public static final String TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE =
      "^([a-zA-Z0-9-_])[a-zA-Z0-9 -_]+[-_a-zA-Z0-9](?!\\s)$";
}
