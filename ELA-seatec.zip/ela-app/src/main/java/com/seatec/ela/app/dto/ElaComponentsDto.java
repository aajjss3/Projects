package com.seatec.ela.app.dto;

import com.seatec.ela.app.model.Ela;
import java.util.ArrayList;
import java.util.List;

public class ElaComponentsDto {

  private Ela ela;

  private List<Long> componentIds = new ArrayList<>();

  public ElaComponentsDto(Ela ela) {
    this.ela = ela;
  }

  public Ela getEla() {
    return ela;
  }

  public void setEla(Ela ela) {
    this.ela = ela;
  }

  public List<Long> getComponentIds() {
    return componentIds;
  }

  public void setComponentIds(List<Long> componentIds) {
    this.componentIds = componentIds;
  }

  public void addComponentId(Long componentId) {
    this.componentIds.add(componentId);
  }

  public void removeComponentId(Long componentId) {
    this.componentIds.remove(componentId);
  }
}
