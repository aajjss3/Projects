package com.seatec.ela.postgres;

import java.sql.Types;
import org.hibernate.dialect.PostgreSQL95Dialect;

public class ElaPostgreSQL95Dialect extends PostgreSQL95Dialect {
  public ElaPostgreSQL95Dialect() {
    this.registerColumnType(Types.JAVA_OBJECT, "jsonb");
  }
}
