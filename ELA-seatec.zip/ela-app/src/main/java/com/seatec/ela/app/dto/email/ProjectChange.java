package com.seatec.ela.app.dto.email;

import java.util.ArrayList;
import java.util.List;

public class ProjectChange {
  private List<String> conflictingChanges = new ArrayList<>();
  private String changeGroupName;

  public List<String> getConflictingChanges() {
    return conflictingChanges;
  }

  public void setConflictingChanges(List<String> conflictingChanges) {
    this.conflictingChanges = conflictingChanges;
  }

  public void addConflictingChange(String conflictingChange) {
    conflictingChanges.add(conflictingChange);
  }

  public String getChangeGroupName() {
    return changeGroupName;
  }

  public void setChangeGroupName(String changeGroupName) {
    this.changeGroupName = changeGroupName;
  }
}
