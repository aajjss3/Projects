package com.seatec.ela.app.util.csv;

import com.opencsv.bean.BeanVerifier;
import com.opencsv.exceptions.CsvConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CsvVerifier implements BeanVerifier<AirbusCsv> {

  private static final Logger logger = LoggerFactory.getLogger(CsvVerifier.class);

  @Override
  public boolean verifyBean(AirbusCsv bean) throws CsvConstraintViolationException {
    if (!bean.isSecurityValid()) {
      throw new CsvConstraintViolationException(
          "Content has Security Issues =+-@ have restricted use.");
    }
    if (bean.getBusBar().equals("BUSBAR")
        || bean.getIntermittent().contains("PERM")
        || bean.getPhase().equals("PHASE")
        || bean.getLandStage().equals("LOAD")) {
      if (!bean.isHeaderValid()) {
        String message =
            "Csv Header did not match expected "
                + "'PERM/INTER;C;S;BUSBAR;PHASE;LOAD;IDENT.;PANEL;ATA 100;D E S I G N A T I O N ;NOMINAL POWER;GROUND;START;ROLL;T/OFF;CLIMB;CRUISE;DESC;LAND;TAXI;MODIFIED;COMMENT'";
        logger.info(message);
        throw new CsvConstraintViolationException(message);
      } else {
        return false;
      }
    }
    if (!bean.isValid()) {
      String message =
          "Csv Header did not match expected Validation Failed NumbersValid "
              + bean.isNumbersValid()
              + " Load "
              + bean.isLoadValid()
              + " Phase "
              + bean.isPhaseValid();
      logger.info(message);
      throw new CsvConstraintViolationException(message);
    }
    return true;
  }
}
