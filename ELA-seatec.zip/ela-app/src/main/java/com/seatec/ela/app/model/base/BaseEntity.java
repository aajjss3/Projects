package com.seatec.ela.app.model.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import java.util.UUID;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.hibernate.annotations.UpdateTimestamp;

@TypeDefs({@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)})
@MappedSuperclass
@JsonIgnoreProperties(
    ignoreUnknown = true,
    value = {"hibernateLazyInitializer", "handler"})
public class BaseEntity implements Serializable, UserTrackIdUUID {

  @JsonIgnore @Version protected Integer version;

  /**
   * The 'id' values get set in java when the entity gets instantiated by the default constructor.
   * (see the BaseEntity() constructor in this class) The @GeneratedValue and @GenericGenerator
   * annotations are added here as a backup, in case the entities 'id' value is not set by the time
   * the entity is persisted.
   */
  @Id
  @GeneratedValue(generator = "uuid-generator")
  @GenericGenerator(name = "uuid-generator", strategy = "com.seatec.ela.app.config.UUIDGenerator")
  protected UUID id;

  @CreationTimestamp protected Instant created;

  @JsonIgnore @UpdateTimestamp protected Instant updated;

  /** Set the 'id' value in java when the entity gets instantiated with this default constructor. */
  public BaseEntity() {
    this.id = UUID.randomUUID();
  }

  public Integer getVersion() {
    return version;
  }

  public void setVersion(Integer version) {
    this.version = version;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public Instant getCreated() {
    return created;
  }

  public void setCreated(Instant created) {
    this.created = created;
  }

  public Instant getUpdated() {
    return updated;
  }

  public void setUpdated(Instant updated) {
    this.updated = updated;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
      return false;
    }
    return (((BaseEntity) obj).getId().equals(id)) ? true : false;
  }
}
