package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackAuthor;
import java.time.Instant;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class ProjectCommentDTO implements UserTrackAuthor {

  private Instant created;

  @NotBlank(message = "{field.required}")
  @Size(max = 512, message = "{field.value.max}")
  private String comment;

  private String author;

  private String displayName;

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public String getDisplayName() {
    return displayName;
  }

  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  public Instant getCreated() {
    return created;
  }

  public void setCreated(Instant created) {
    this.created = created;
  }
}
