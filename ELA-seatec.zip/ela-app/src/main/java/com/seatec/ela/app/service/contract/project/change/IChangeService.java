package com.seatec.ela.app.service.contract.project.change;

import com.seatec.ela.app.model.project.change.Change;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/** Service for dealing with Project > ChangeGroup > Changes. */
public interface IChangeService {

  List<Change> findAllByProjectAndChangeGroupId(UUID changeGroupId, UUID projectId);

  List<Change> findAllByChangeGroupId(UUID changeGroupId);

  Optional<Change> findById(UUID id);

  Change create(Change change, UUID changeGroupId, UUID projectId);

  void delete(UUID id, UUID changeGroupId, UUID projectId);

  void update(Change change, UUID changeId);
}
