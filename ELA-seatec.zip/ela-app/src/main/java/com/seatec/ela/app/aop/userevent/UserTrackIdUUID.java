package com.seatec.ela.app.aop.userevent;

import java.util.UUID;

/**
 * Used to populate details for LogDetail
 *
 * @see LogDetail
 * @see LogConfig
 */
public interface UserTrackIdUUID {
  public UUID getId();
}
