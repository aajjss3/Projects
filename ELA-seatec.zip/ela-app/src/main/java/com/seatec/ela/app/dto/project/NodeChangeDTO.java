package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;
import java.util.UUID;

public class NodeChangeDTO implements UserTrackIdUUID, UserTrackName {

  private UUID id;

  private String name;

  private Double nominalPower;

  private Double busRating;

  private boolean sheddable;

  private boolean requiresApproval;

  private NodeType nodeType;

  private Double voltage;

  private ElectricalPhase voltageType;

  private ElectricalPhase electricalPhase;

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public Double getBusRating() {
    return busRating;
  }

  public void setBusRating(Double busRating) {
    this.busRating = busRating;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public ElectricalPhase getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(ElectricalPhase voltageType) {
    this.voltageType = voltageType;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }
}
