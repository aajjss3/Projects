package com.seatec.ela.app.service.project;

import com.seatec.ela.app.dto.AircraftBusStructureBucketDto;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.service.contract.project.IAircraftChangeGroupService;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AircraftChangeGroupService implements IAircraftChangeGroupService {

  @Autowired private AircraftChangeGroupRepo aircraftChangeGroupRepo;

  public AircraftChangeGroupService() {}

  public AircraftChangeGroupService(AircraftChangeGroupRepo aircraftChangeGroupRepo) {
    this.aircraftChangeGroupRepo = aircraftChangeGroupRepo;
  }

  public List<AircraftChangeGroup> findAllByChangeGroupIdIn(List<UUID> changeGroupIds) {
    return aircraftChangeGroupRepo.findAllByChangeGroupIdIn(changeGroupIds);
  }

  public List<AircraftChangeGroup> convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
      AircraftBusStructureBucketDto aircraftBusStructureBucketDto, ChangeGroup changeGroup) {
    return aircraftBusStructureBucketDto.getAircrafts().stream()
        .map(
            aircraft -> {
              AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
              aircraftChangeGroup.setChangeGroup(changeGroup);
              aircraftChangeGroup.setAircraft(aircraft);
              return aircraftChangeGroup;
            })
        .collect(Collectors.toList());
  }

  @Transactional
  public AircraftChangeGroup save(AircraftChangeGroup entity) {
    return aircraftChangeGroupRepo.save(entity);
  }
}
