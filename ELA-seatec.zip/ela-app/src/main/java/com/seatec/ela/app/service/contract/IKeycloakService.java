package com.seatec.ela.app.service.contract;

import com.seatec.ela.app.dto.KeycloakUserDto;
import java.util.List;
import org.keycloak.representations.idm.UserRepresentation;

/** Service for dealing with Keycloak Admin API. */
public interface IKeycloakService {

  List<UserRepresentation> findAllActiveUsers();

  UserRepresentation findUser(String id);

  List<KeycloakUserDto> findUsersInRole(String roleName);

  void createUser(KeycloakUserDto user);

  void updateUser(KeycloakUserDto user, String id);

  boolean isUserAndInRole(String id, String roleName);

  List<String> findAllRoles();
}
