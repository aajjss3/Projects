package com.seatec.ela.app.service.project;

import com.seatec.ela.app.dto.analysis.*;
import com.seatec.ela.app.dto.report.ProjectReportChangeGroupDTO;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.base.BaseEntity;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.service.EfficiencyTableService;
import com.seatec.ela.app.service.ElaAnalysisService;
import com.seatec.ela.app.service.LoadSummaryService;
import com.seatec.ela.app.service.TRU3OutAnalysisService;
import com.seatec.ela.app.service.contract.IComponentService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.service.contract.project.change.history.IChangeHistoryService;
import com.seatec.ela.app.util.NodeUtil;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Perform a 'project analysis' on all aircrafts associated with the change group passed in. All
 * analysis is done in memory - do not persist any changes, additions or deletions to the database.
 * To perform a 'project analysis' for an aircraft apply the node, component and load changes
 * (located in the NodeChange, ComponentChange, and LoadChange entities associated with the project)
 * to the existing aircraft node structure. Then perform a summarized load on all nodes in the
 * aircraft node tree, and then perform a normal and degraded load analysis on the summarized loads.
 */
@Service
public class ProjectAnalysisService {

  @Autowired private IChangeHistoryService changeHistoryService;

  @Autowired private ElaAnalysisService elaAnalysisService;

  @Autowired private EfficiencyTableService efficiencyTableService;

  @Autowired private LoadSummaryService loadSummaryService;

  @Autowired
  @Qualifier("mapAll")
  private ModelMapper mapper;

  @Autowired private ElaRepository elaRepository;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private AircraftRepository aircraftRepo;

  @Autowired private INodeService nodeService;

  @Autowired private IComponentService componentService;

  @Autowired private TRU3OutAnalysisService tru3OutAnalysisService;

  /**
   * Retrieve project analysis for the change group passed in. This analysis is done in memory - no
   * changes, additions or deletions are persisted to the database but a hibernate session is
   * required to prevent a 'lazily initialize - no Session' error, therefore annotate
   * with @Transactional(readOnly = true)
   *
   * <p>The NodeChange, ComponentChange and LoadChange entities contain values for all fields, even
   * if the value did not change for an edit. Therefore, when using ModelMapper to map from a source
   * entity to a destination entity, map all fields, even if the source values is null.
   *
   * <p>This analysis is done on the last ela performed on the aircraft
   *
   * @param changeGroupId - Project Change Group unique identifier to perform analysis against.
   * @param aircraftId - if null, retrieve analysis for all aircrafts associated to the changGroupId
   *     passed in. if not null, then retrieve analysis for only that aircraft.
   * @param isSummary - if the analysis should include AnalysisLoad's then false. if the analysis
   *     should not include AnalysisLoad's then true.
   * @return - List of ProjectAnalysis DTOs
   */
  @Transactional(readOnly = true)
  public List<ProjectAnalysis> getAnalysis(UUID changeGroupId, Long aircraftId, boolean isSummary) {
    ChangeGroup changeGroup = changeGroupRepo.findById(changeGroupId).get();

    // return analysis from db if project is approved
    if (changeGroup.getProject().getApproved() != null) {
      return getSavedAnalysis(changeGroup, aircraftId);
    }

    List<ProjectAnalysis> projectAnalyses = new ArrayList<>();
    List<Aircraft> aircrafts = new ArrayList<>();

    if (aircraftId == null) {
      aircrafts.addAll(
          changeGroup.getAircraftChangeGroups().stream()
              .map(AircraftChangeGroup::getAircraft)
              .collect(Collectors.toList()));
    } else {
      Aircraft aircraft = aircraftRepo.findById(aircraftId).get();
      if (changeGroup.getAircraftChangeGroups().stream()
          .noneMatch(acg -> acg.getAircraft().getId().equals(aircraft.getId()))) {
        throw new BadRequestException(
            "Unable to match the aircraft passed in "
                + aircraft.getAircraftShipNo()
                + " to the change group passed in "
                + changeGroup.getName(),
            Level.WARN);
      }
      aircrafts.add(aircraft);
    }

    for (Aircraft aircraft : aircrafts) {
      // only perform analysis for the last ELA performed on the aircraft.
      Ela ela = elaRepository.findFirstByAircraftOrderByCreatedDateDesc(aircraft);
      if (ela == null) {
        throw new NotFoundException(
            "Unable to find an ela for aircraft " + aircraft.getAircraftShipNo());
      }
      Analysis analysis =
          getAircraftChangeAnalysis(ela, changeGroup.getChanges(), isSummary, false);
      projectAnalyses.add(
          new ProjectAnalysis(aircraft.getAircraftShipNo(), aircraft.getId(), analysis));
    }

    return projectAnalyses;
  }

  /**
   * Generates project analysis for the ela passed in. This analysis is persisted to the database if
   * [isRebase] parameter is true.
   *
   * @param ela - Ela Entity the analysis is performed against
   * @param changes - list of project changes to merge into existing Ela nodes.
   * @param isSummary - if the analysis should include AnalysisLoad's then false. if the analysis
   *     should not include AnalysisLoad's then true.
   * @param isRebase - flag to determine if modifications should be persisted to database or remain
   *     in memory.
   * @return - Analysis DTO
   */
  public Analysis getAircraftChangeAnalysis(
      Ela ela, List<Change> changes, boolean isSummary, boolean isRebase) {
    List<Node> topLevelNodes = nodeService.hydrateNodes(ela.getId(), null);

    // get the complete list of nodes. each node does not contain summarized loads
    List<Node> nodes = NodeUtil.flattenNodeTrees(topLevelNodes);

    // rebase handles persisting/applying changes outside of this method
    // so bypass this when rebasing flow.
    if (!isRebase) {
      applyChanges(ela, nodes, changes, false);
    }

    // generate Analysis and append LoadSummary data if requested
    return getAnalysis(ela.getAircraft().getFleet(), ela.getId(), nodes, isSummary);
  }

  public ProjectReportDTO getProjectAnalysis(List<ChangeGroup> changeGroups) {
    ProjectReportDTO projectReportDTO = new ProjectReportDTO();

    for (ChangeGroup cg : changeGroups) {
      ProjectReportChangeGroupDTO projectReportChangeGroupDTO =
          new ProjectReportChangeGroupDTO(cg.getId(), cg.getName());
      List<ProjectAnalysis> projectAnalyses = new ArrayList<>();

      if (!cg.getChanges().isEmpty()) {
        List<Aircraft> aircrafts =
            cg.getAircraftChangeGroups().stream()
                .map(AircraftChangeGroup::getAircraft)
                .collect(Collectors.toList());

        // iterate over aircrafts
        for (Aircraft aircraft : aircrafts) {
          Ela ela = aircraft.getElas().get(0);

          if (ela != null) {
            Analysis analysis = getAircraftChangeAnalysis(ela, cg.getChanges(), false, true);
            projectAnalyses.add(
                new ProjectAnalysis(aircraft.getAircraftShipNo(), aircraft.getId(), analysis));
          }
        }

        projectReportChangeGroupDTO.setAnalyses(projectAnalyses);
      }

      projectReportDTO.addProjectReportChangeGroup(projectReportChangeGroupDTO);
    }

    return projectReportDTO;
  }

  public void applyChanges(Ela ela, List<Node> nodes, List<Change> changes, boolean isRebase) {
    // first process all node changes, then process all component changes.
    // sort the collection of Change objects by the 'created' date - this ensures the changes are
    // processed in the proper order.
    // - the proper change order for adding is - add the parent node first, then add the child node.
    // (this is automatically performed when the
    // collection is sorted by created date)
    // - the proper change order for deleting is - delete the child node first, then delete the
    // parent node. (this is automatically performed when
    // the collection is sorted by created date)
    List<Change> nodeChanges =
        changes.stream()
            .filter(change -> change.getNodeChange() != null)
            .sorted(Comparator.comparing(BaseEntity::getCreated))
            .collect(Collectors.toList());
    List<Change> componentChanges =
        changes.stream()
            .filter(change -> change.getComponentChange() != null)
            .sorted(Comparator.comparing(BaseEntity::getCreated))
            .collect(Collectors.toList());

    Set<String> removedNodes = new HashSet<>();

    // node changes
    for (Change change : nodeChanges) {
      // 'existingOrParentNode' is the existing node for deleting or editing a node. for adding a
      // sub node this will be the parent node.
      // if adding a root level node then its not used.
      Node parentNode = null;
      Node currentNode = null;
      ActionType action = change.getAction();
      boolean isRootLevel = change.getNodeName() == null || change.getNodeName().isEmpty();

      if (action != ActionType.ADD || !isRootLevel) {
        parentNode = nodeService.getNodeByName(nodes, change.getNodeName());
      }

      if (action != ActionType.ADD) {
        currentNode = nodeService.getNodeByName(nodes, change.getNodeChange().getName());

        // save snapshot of original values
        if (isRebase) {
          changeHistoryService.saveOriginalNodeValues(change, ela, currentNode);
        }
      }

      switch (action) {
        case DELETE:
          nodes.remove(currentNode);
          removedNodes.add(change.getNodeChange().getName());
          break;
        case ADD:
          Node newNode = mapper.map(change.getNodeChange(), Node.class);

          if (parentNode != null) {
            setNodeDisplayOrder(newNode, parentNode.getSubNodes());
            parentNode.addSubNode(newNode);
          } else {
            setNodeDisplayOrder(newNode, ela.getNodes());
            newNode.setEla(ela);
          }
          nodes.add(newNode);
          break;
        case EDIT:
          mapper.map(change.getNodeChange(), currentNode);
          break;
      }
    }

    // component changes
    for (Change change : componentChanges) {
      // only process the ones that haven't had their parent removed
      if (!removedNodes.contains(change.getNodeName())) {
        ActionType action = change.getAction();
        List<LoadChange> loadChanges = change.getComponentChange().getLoadChanges();

        // find the node the component belongs to
        Node currentNode = nodeService.getNodeByName(nodes, change.getNodeName());

        // find the existing component (only used for DELETE|EDIT).
        Component currentComponent = null;

        if (action != ActionType.ADD) {
          currentComponent =
              componentService.getComponentByElectIdentAndPhase(
                  currentNode,
                  change.getComponentElectIdent(),
                  change.getComponentChange().getElectricalPhase());

          // save snapshot of original values
          if (isRebase) {
            changeHistoryService.saveOriginalComponentValues(change, ela, currentComponent);
          }
        }

        switch (action) {
          case DELETE:
            currentNode.getComponents().remove(currentComponent);

            // if rebase then persist change to db
            if (isRebase) {
              componentService.delete(currentComponent);
            }
            break;
          case ADD:
            Component newComponent = mapper.map(change.getComponentChange(), Component.class);
            newComponent.setNode(currentNode);

            for (LoadChange loadChange : loadChanges) {
              Load newLoad = mapper.map(loadChange, Load.class);
              newLoad.setComponent(newComponent);
              newComponent.addLoad(newLoad);
            }

            Optional<Integer> maxDisplayOrder =
                currentNode.getComponents().stream()
                    .max(Comparator.comparing(Component::getDisplayOrder))
                    .map(Component::getDisplayOrder);
            int displayOrder = maxDisplayOrder.map(integer -> integer + 1).orElse(1);
            newComponent.setDisplayOrder(displayOrder);

            currentNode.addComponent(newComponent);
            break;
          case EDIT:
            mapper.map(change.getComponentChange(), currentComponent);

            for (LoadChange loadChange : loadChanges) {
              Load existingLoad =
                  componentService.getLoadByOperatingModeAndFlightPhase(
                      currentComponent, loadChange.getOperatingMode(), loadChange.getFlightPhase());
              if (existingLoad != null) {
                existingLoad.setVa(loadChange.getVa());
              }
            }
            break;
        }
      }
    }
  }

  /**
   * Similar to ElaAnalysisService.getAnalysis() BUT without calling hydrateNodes() or findByElaId()
   *
   * @param fleet - Fleet Entity
   * @param elaId - Ela Entity Unique Identifier
   * @param nodes - Node Entities the analysis is performed against
   * @param isSummary - if the analysis should include AnalysisLoad's then false. if the analysis
   *     should not include AnalysisLoad's then true.
   * @return Analysis DTO
   */
  private Analysis getAnalysis(Fleet fleet, Long elaId, List<Node> nodes, boolean isSummary) {
    // if a TRU or ATU transformer node was added (i.e. node.id will be null and node.nodeType is
    // TRU or ATU) then set the new nodes efficiencyTable
    // as the same as an existing transformer efficiencyTable of the same type.
    for (Node node : nodes) {
      if (node.getId() == null
          && (node.getNodeType() == NodeType.TRU || node.getNodeType() == NodeType.ATU)) {
        setEfficiencyTable(nodes, node, node.getNodeType());
      }
    }

    // determine the loadSummaries of all nodes (including ones not directly changed)
    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

    LoadSummaryOptions loadSummaryOptions =
        new LoadSummaryOptions(false, false, false, false, true);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    nodes.forEach(
        node ->
            node.setSummarizedLoads(
                loadSummaryService.retrieveLoadSummaries(node, loadSummaryRequest)));

    for (Node node : nodes) {
      List<SummarizedLoad> summarizedLoads =
          loadSummaryService.retrieveLoadSummaries(node, loadSummaryRequest);
      node.setSummarizedLoads(summarizedLoads);
    }

    // calculate the normal and degraded analysis for the nodes
    Analysis analysis = elaAnalysisService.getNormalAndDegradedAnalysis(nodes, fleet, isSummary);

    // if boeing aircraft, then also calculate the standby operation analysis
    if (fleet != null && ElaAnalysisService.BOEING.equalsIgnoreCase(fleet.getManufacturer())) {
      elaAnalysisService.updateStaticInverterAndStandbyOperation(elaId, nodes, fleet, analysis);
    }

    // if the analysis is for B767, B757, B757ETOPS, B737 then also perform auto land analysis
    String autoLandCalculationType = ElaAnalysisService.getAutoLandCalculationType(fleet.getName());
    if (autoLandCalculationType != null) {
      elaAnalysisService.setAutoLandAnalysis(
          autoLandCalculationType, elaId, nodes, fleet, analysis);
    }

    // if the fleet is Boeing 737 then also perform `TRU3 Out` analysis
    if (fleet.getName().startsWith("B737")) {
      tru3OutAnalysisService.setTRU3OutAnalysis(analysis, nodes, elaId);
    }

    return analysis;
  }

  private List<ProjectAnalysis> getSavedAnalysis(ChangeGroup changeGroup, Long aircraftId) {
    ProjectReportDTO projectReportDTO = changeGroup.getProject().getAnalysis();

    // verify analysis exists
    if (projectReportDTO != null) {
      for (ProjectReportChangeGroupDTO projectReportChangeGroupDTO :
          projectReportDTO.getProjectReportChangeGroups()) {
        if (projectReportChangeGroupDTO.getId().equals(changeGroup.getId())) {
          if (aircraftId != null) {
            return projectReportChangeGroupDTO.getAnalyses().stream()
                .filter(projectAnalysis -> projectAnalysis.getAircraftId().equals(aircraftId))
                .collect(Collectors.toList());
          }

          return projectReportChangeGroupDTO.getAnalyses();
        }
      }
    }

    throw new NotFoundException(
        String.format("Unable to locate analysis for change group '%s'", changeGroup.getName()),
        Level.ERROR);
  }

  private void setNodeDisplayOrder(Node newNode, List<Node> subNodes) {
    Optional<Integer> maxDisplayOrder =
        subNodes.stream()
            .max(Comparator.comparing(Node::getDisplayOrder))
            .map(Node::getDisplayOrder);
    int displayOrder = maxDisplayOrder.isPresent() ? maxDisplayOrder.get() + 1 : 1;
    newNode.setDisplayOrder(displayOrder);
  }

  private void setEfficiencyTable(List<Node> nodes, Node node, NodeType nodeType) {
    EfficiencyTable efficiencyTable =
        nodes.stream()
            .filter(n -> n.getId() != null && n.getNodeType() == nodeType)
            .findFirst()
            .map(Node::getEfficiencyTable)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to find a suitable "
                            + nodeType
                            + " transformer to use for the added new transformer",
                        Level.ERROR));
    node.setEfficiencyTable(efficiencyTable);
  }
}
