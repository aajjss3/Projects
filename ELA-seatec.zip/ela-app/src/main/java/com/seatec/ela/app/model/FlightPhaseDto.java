package com.seatec.ela.app.model;

public class FlightPhaseDto {

  /** Name of Flight Phase */
  private String name;

  /** Is the flight phase load supplied by battery */
  private boolean isBatterySupplied;

  public FlightPhaseDto() {}

  public FlightPhaseDto(String name, boolean isBatterySupplied) {
    this.name = name;
    this.isBatterySupplied = isBatterySupplied;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public boolean isBatterySupplied() {
    return isBatterySupplied;
  }

  public void setBatterySupplied(boolean isBatterySupplied) {
    this.isBatterySupplied = isBatterySupplied;
  }
}
