package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.dto.ChangeGroupMappedNodeDto;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ChangeGroupEffectivityDao {

  @Autowired NamedParameterJdbcTemplate jdbcTemplate;

  private static final String SQL_SELECT_CHANGEGROUP_EFFECTIVITY =
      "WITH RECURSIVE nodetree AS (SELECT id, name, CAST(name As varchar(1000)) As fullName, "
          + "display_order as displayOrder, 0 as lvl, voltage, nominal_power, node_type, "
          + "requires_approval, bus_rating, voltage_type, normal_tr, sheddable, description, electrical_phase FROM node n "
          + "WHERE node_id IS NULL AND ela_id in (:elaIds) "
          + "UNION ALL SELECT ni.id, ni.name, "
          + "CAST(np.fullName || '|' || ni.name as varchar(1000)) As fullName, np.displayOrder, "
          + "np.lvl + 1, ni.voltage, ni.nominal_power, ni.node_type, ni.requires_approval, "
          + "ni.bus_rating, ni.voltage_type, ni.normal_tr, ni.sheddable, ni.description, ni.electrical_phase FROM node AS ni "
          + "INNER JOIN nodetree AS np ON (ni.node_id = np.id)) "
          + "SELECT id, name, fullName, displayOrder, lvl, voltage, nominal_power, node_type, "
          + "requires_approval, bus_rating, voltage_type, normal_tr, sheddable, description, electrical_phase "
          + "FROM nodetree GROUP BY lvl, displayOrder, name, fullName, id, voltage, nominal_power, "
          + "node_type, requires_approval, bus_rating, voltage_type, normal_tr, sheddable, description, electrical_phase ";

  /**
   * A collection of unique Nodes along with indicators of wither the node is present across all
   * effectivies in collection.
   *
   * @param elaIds - A collection of Ela Ids (Long)
   * @return Collection - Unique Nodes based on Project ChangeGroup Effectivities
   */
  public List<ChangeGroupMappedNodeDto> findChangeGroupEffectivities(List<Long> elaIds) {
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("elaIds", elaIds);

    return jdbcTemplate.query(
        SQL_SELECT_CHANGEGROUP_EFFECTIVITY,
        parameters,
        (rs, rowNum) -> {
          String ep = rs.getString("electrical_phase");
          ElectricalPhase electricalPhase = ep != null ? ElectricalPhase.valueOf(ep) : null;
          return new ChangeGroupMappedNodeDto(
              rs.getLong("id"),
              rs.getString("name"),
              rs.getString("fullName"),
              rs.getInt("displayOrder"),
              rs.getInt("lvl"),
              rs.getDouble("voltage"),
              rs.getDouble("nominal_power"),
              NodeType.valueOf(rs.getString("node_type")),
              rs.getBoolean("requires_approval"),
              rs.getDouble("bus_rating"),
              ElectricalPhase.valueOf(rs.getString("voltage_type")),
              rs.getBoolean("normal_tr"),
              rs.getBoolean("sheddable"),
              rs.getString("description"),
              electricalPhase);
        });
  }
}
