package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.service.project.ProjectService;
import com.seatec.ela.app.validator.annotation.UnapprovedProject;
import java.util.UUID;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Validate if a project has not been approved. This is primarily used to keep modifications from
 * happening on approved projects.
 */
public class UnapprovedProjectValidator implements ConstraintValidator<UnapprovedProject, UUID> {

  @Autowired private ProjectService projectService;

  @Override
  public void initialize(UnapprovedProject constraintAnnotation) {}

  @Override
  public boolean isValid(UUID projectId, ConstraintValidatorContext context) {
    Project project =
        projectService
            .findById(projectId)
            .orElseThrow(
                () -> new NotFoundException("Project with id " + projectId + " not found"));
    return project.getApproved() == null;
  }
}
