package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import java.util.UUID;

public class AircraftChangeGroupDTO implements UserTrackIdUUID {

  private UUID id;

  private AircraftDTO aircraft;

  public AircraftDTO getAircraft() {
    return aircraft;
  }

  public void setAircraft(AircraftDTO aircraft) {
    this.aircraft = aircraft;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }
}
