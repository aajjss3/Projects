package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.aop.userevent.UserTrackIdUUID;
import com.seatec.ela.app.aop.userevent.UserTrackTitle;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ProjectDTO implements UserTrackIdUUID, UserTrackTitle {

  private UUID id;

  private Instant started;

  private Instant submitted;

  private String submittedStatus;

  private Instant checked;

  private String checkedStatus;

  private Instant approved;

  private String approvedStatus;

  private Instant retired;

  private String description;

  private String number;

  private String revisionLevel;

  private String maintenanceDescription;

  private String title;

  private String checkEngineer;

  private String approvalEngineer;

  private List<ChangeGroupDTO> changeGroups = new ArrayList<ChangeGroupDTO>();

  private String author;

  private List<String> coauthors = new ArrayList<String>();

  private List<ProjectCommentDTO> comments = new ArrayList<ProjectCommentDTO>();

  private Instant rejected;

  private Instant created;

  public Instant getStarted() {
    return started;
  }

  public void setStarted(Instant started) {
    this.started = started;
  }

  public Instant getSubmitted() {
    return submitted;
  }

  public void setSubmitted(Instant submitted) {
    this.submitted = submitted;
  }

  public Instant getChecked() {
    return checked;
  }

  public void setChecked(Instant checked) {
    this.checked = checked;
  }

  public Instant getApproved() {
    return approved;
  }

  public void setApproved(Instant approved) {
    this.approved = approved;
  }

  public Instant getRetired() {
    return retired;
  }

  public void setRetired(Instant retired) {
    this.retired = retired;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getRevisionLevel() {
    return revisionLevel;
  }

  public void setRevisionLevel(String revisionLevel) {
    this.revisionLevel = revisionLevel;
  }

  public String getMaintenanceDescription() {
    return maintenanceDescription;
  }

  public void setMaintenanceDescription(String maintenanceDescription) {
    this.maintenanceDescription = maintenanceDescription;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getCheckEngineer() {
    return checkEngineer;
  }

  public void setCheckEngineer(String checkEngineer) {
    this.checkEngineer = checkEngineer;
  }

  public String getApprovalEngineer() {
    return approvalEngineer;
  }

  public void setApprovalEngineer(String approvalEngineer) {
    this.approvalEngineer = approvalEngineer;
  }

  public List<ChangeGroupDTO> getChangeGroups() {
    return changeGroups;
  }

  public void setChangeGroups(List<ChangeGroupDTO> changeGroups) {
    this.changeGroups = changeGroups;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public List<String> getCoauthors() {
    return coauthors;
  }

  public void setCoauthors(List<String> coauthors) {
    this.coauthors = coauthors;
  }

  public List<ProjectCommentDTO> getComments() {
    return comments;
  }

  public void setComments(List<ProjectCommentDTO> comments) {
    this.comments = comments;
  }

  public Instant getRejected() {
    return rejected;
  }

  public void setRejected(Instant rejected) {
    this.rejected = rejected;
  }

  public String getSubmittedStatus() {
    return submittedStatus;
  }

  public void setSubmittedStatus(String submittedStatus) {
    this.submittedStatus = submittedStatus;
  }

  public String getCheckedStatus() {
    return checkedStatus;
  }

  public void setCheckedStatus(String checkedStatus) {
    this.checkedStatus = checkedStatus;
  }

  public String getApprovedStatus() {
    return approvedStatus;
  }

  public void setApprovedStatus(String approvedStatus) {
    this.approvedStatus = approvedStatus;
  }

  public Instant getCreated() {
    return created;
  }

  public void setCreated(Instant created) {
    this.created = created;
  }
}
