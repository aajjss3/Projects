package com.seatec.ela.app.util;

import com.seatec.ela.app.model.ElectricalPhase;

public class PhaseUtil {

  // suppress default constructor for noninstantiability
  private PhaseUtil() {
    throw new AssertionError();
  }

  public static String getPhaseLabel(ElectricalPhase electricalPhase) {
    if (electricalPhase != null) {
      switch (electricalPhase) {
        case ACA:
        case AC:
          return " - Phase A";
        case ACB:
          return " - Phase B";
        case ACC:
          return " - Phase C";
        case AC3:
          return " - 3 Phase";
        default:
          return "";
      }
    }

    return "";
  }
}
