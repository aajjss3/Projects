package com.seatec.ela.app.model.repository.project.change.history;

import com.seatec.ela.app.model.project.change.history.ComponentChangeHistory;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ComponentChangeHistoryRepo extends CrudRepository<ComponentChangeHistory, UUID> {
  List<ComponentChangeHistory> findAllByChangeId(@Param("changeId") UUID changeId);

  Optional<ComponentChangeHistory> findByChangeId(@Param("changeId") UUID changeId);
}
