package com.seatec.ela.app.controller;

import com.seatec.ela.app.dto.LogEventDto;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/log")
public class LoggingController {

  @PostMapping()
  public void logEvent(@RequestBody LogEventDto logEventDto) {
    com.seatec.ela.app.util.logging.LogEvent.log(logEventDto);
  }
}
