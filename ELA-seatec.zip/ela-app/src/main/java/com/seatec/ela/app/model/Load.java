package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.model.View.BaseSummaryView;
import com.seatec.ela.app.util.LoadUtil;
import java.io.Serializable;
import java.util.Objects;
import javax.persistence.*;

@Entity
@Table(name = "load")
@JsonView(View.NodeSummaryView.class)
public class Load implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "va")
  @JsonView(BaseSummaryView.class)
  // volt amperes
  private Double va;

  @ManyToOne
  @JoinColumn(name = "component_id", nullable = false)
  @JsonIgnore
  private Component component;

  @Column(name = "flight_phase", nullable = false)
  @JsonView(BaseSummaryView.class)
  private String flightPhase;

  @Column(name = "operating_mode")
  @JsonView(BaseSummaryView.class)
  private String operatingMode;

  @Column(name = "power_factor", nullable = false)
  @JsonView(BaseSummaryView.class)
  private double powerFactor;

  // caches of calculated values
  @Transient
  // watts
  private double w;

  @Transient
  // volt amperes reactive
  private double var;

  public Long getId() {
    return id;
  }

  public Load() {}

  public Load(
      Double va,
      String flightPhase,
      String operatingMode,
      Component component,
      double powerFactor) {
    this.va = va;
    this.flightPhase = flightPhase;
    this.operatingMode = operatingMode;
    this.component = component;
    this.powerFactor = powerFactor;
    recalculate();
  }

  private void recalculate() {
    if (va != null) {
      w = LoadUtil.getW(va, powerFactor);
      var = LoadUtil.getVar(va, powerFactor);
    }
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Double getVa() {
    return va;
  }

  public void setVa(Double va) {
    this.va = va;
    recalculate();
  }

  public Component getComponent() {
    return component;
  }

  public void setComponent(Component component) {
    this.component = component;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public String getOperatingMode() {
    return operatingMode;
  }

  public void setOperatingMode(String operatingMode) {
    this.operatingMode = operatingMode;
  }

  public double getPowerFactor() {
    return powerFactor;
  }

  public void setPowerFactor(double powerFactor) {
    this.powerFactor = powerFactor;
    recalculate();
  }

  public double getW() {
    return w;
  }

  public double getVar() {
    return var;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Load load = (Load) o;
    return Objects.equals(id, load.id);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  public Load shallowCopy() {
    Load copy = new Load();
    copy.setComponent(getComponent());
    copy.setFlightPhase(getFlightPhase());
    copy.setId(getId());
    copy.setOperatingMode(getOperatingMode());
    copy.setVa(getVa());
    copy.setPowerFactor(getPowerFactor());
    return copy;
  }

  public Load clone() {
    Load newLoad = new Load();
    newLoad.setComponent(getComponent());
    newLoad.setFlightPhase(getFlightPhase());
    newLoad.setOperatingMode(getOperatingMode());
    newLoad.setVa(getVa());
    newLoad.setPowerFactor(getPowerFactor());
    return newLoad;
  }
}
