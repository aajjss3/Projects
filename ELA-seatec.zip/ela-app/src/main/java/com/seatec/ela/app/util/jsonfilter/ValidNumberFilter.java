package com.seatec.ela.app.util.jsonfilter;

/** determine if the Double is a valid number (not: null, infinity or NAN) */
public class ValidNumberFilter {

  @Override
  public boolean equals(Object obj) {
    return (obj == null || ((Double) obj).isInfinite() || ((Double) obj).isNaN()) ? true : false;
  }
}
