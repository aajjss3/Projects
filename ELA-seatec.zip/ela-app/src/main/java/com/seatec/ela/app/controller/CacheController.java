package com.seatec.ela.app.controller;

import com.google.gson.Gson;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/cache")
public class CacheController {

  private static org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CacheController.class);

  public static final String SEATEC_PARENT_PACKAGE = "com.seatec";

  @Autowired private CacheManager cacheManager;

  @Autowired private ApplicationContext applicationContext;

  public CacheController() {}

  public CacheController(CacheManager cacheManager, ApplicationContext applicationContext) {
    this.cacheManager = cacheManager;
    this.applicationContext = applicationContext;
  }

  @DeleteMapping()
  public void clearCache() {
    List<String> cacheNames = getCacheNames();
    for (String cacheName : cacheNames) {
      Cache cache = cacheManager.getCache(cacheName);
      if (cache != null) {
        cache.clear();
      }
    }
  }

  @GetMapping
  public String getCachedItem(
      @RequestParam(value = "cache") String cache, @RequestParam(value = "key") String key) {
    Cache namedCache = cacheManager.getCache(cache);
    if (namedCache == null) {
      throw new IllegalArgumentException("Cache " + cache + " not found");
    }
    ValueWrapper val = namedCache.get(key);
    if (val == null) {
      throw new IllegalArgumentException("Cache key " + key + " not found");
    }
    return new Gson().toJson(val.get());
  }

  private List<String> getCacheNames() {
    List<String> cacheNames = new ArrayList<>();
    for (String beanName : applicationContext.getBeanDefinitionNames()) {
      Object obj = applicationContext.getBean(beanName);
      Class<?> objClz = obj.getClass();
      if (objClz != null) {
        if (AopUtils.isAopProxy(obj) || AopUtils.isCglibProxy(obj)) {
          objClz = AopUtils.getTargetClass(obj);
        }
        if (AopUtils.isJdkDynamicProxy(obj)) {
          Advised advised = (Advised) obj;
          try {
            objClz = advised.getTargetSource().getTarget().getClass();
          } catch (Exception e) {
            LOGGER.error(
                "Error getting proxy target class to look for cache annotations " + objClz, e);
          }
        }
        if (objClz.getPackage() != null) {
          if (objClz.getPackage().getName().startsWith(SEATEC_PARENT_PACKAGE)) {
            cacheNames.addAll(findCacheNames(objClz.getDeclaredMethods()));
          } else {
            cacheNames.addAll(getCacheNamesFromProxy(obj));
          }
        } else {
          cacheNames.addAll(getCacheNamesFromProxy(obj));
        }
      }
    }
    return cacheNames;
  }

  private List<String> findCacheNames(Method[] declaredMethods) {
    List<String> cacheNames = new ArrayList<>();
    for (Method m : declaredMethods) {
      if (m.isAnnotationPresent(Cacheable.class)) {
        for (String cacheName : m.getAnnotation(Cacheable.class).value()) {
          cacheNames.add(cacheName);
        }
      }
    }
    return cacheNames;
  }

  private List<String> getCacheNamesFromProxy(Object obj) {
    List<String> cacheNames = new ArrayList<>();
    if (AopUtils.isJdkDynamicProxy(obj)) {
      Advised advised = (Advised) obj;
      Class<?>[] interfaces = advised.getProxiedInterfaces();
      for (Class i : interfaces) {
        if (i.getPackage().getName().startsWith(SEATEC_PARENT_PACKAGE)) {
          cacheNames.addAll(findCacheNames(i.getMethods()));
        }
      }
    }
    return cacheNames;
  }
}
