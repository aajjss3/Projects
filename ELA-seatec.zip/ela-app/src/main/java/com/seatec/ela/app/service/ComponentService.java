package com.seatec.ela.app.service;

import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.service.contract.IComponentService;
import java.util.List;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class ComponentService implements IComponentService {

  @Autowired private ComponentRepository repository;

  @Transactional(readOnly = true)
  public List<Component> findByNodeIds(List<Long> nodeIds) {
    return repository.findByNodeIdIn(nodeIds);
  }

  public Component getComponentByElectIdentAndPhase(
      Node node, String electIdent, ElectricalPhase electricalPhase) {
    return node.getComponents().stream()
        .filter(
            c ->
                c.getElectIdent().equalsIgnoreCase(electIdent)
                    && c.getElectricalPhase().equals(electricalPhase))
        .findFirst()
        .orElseThrow(
            () ->
                new NotFoundException(
                    String.format(
                        "Unable to find Component '%s' on Node/Bus '%s' for Phase '%s'.",
                        electIdent, node.getName(), electricalPhase.toString()),
                    Level.WARN));
  }

  public Load getLoadByOperatingModeAndFlightPhase(
      Component component, String operatingMode, String flightPhase) {
    return component.getLoads().stream()
        .filter(
            l ->
                l.getFlightPhase().equalsIgnoreCase(flightPhase)
                    && l.getOperatingMode().equalsIgnoreCase(operatingMode))
        .findFirst()
        .orElse(null);
  }

  @Transactional
  public void delete(Component component) {
    repository.delete(component);
  }
}
