package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectCommentDTO;
import com.seatec.ela.app.model.project.ProjectComment;
import com.seatec.ela.app.model.repository.ProjectCommentRepo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ProjectDAO {

  @Autowired JdbcTemplate jdbcTemplate;

  @Autowired NamedParameterJdbcTemplate npJdbcTemplate;

  @Autowired ProjectCommentRepo projectCommentRepo;

  @Autowired
  @Qualifier("mapAllFlatProject")
  ModelMapper mapperPartial;

  DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

  public static final String DRAFT = "Draft";
  public static final String IN_REVIEW = "In Review";

  public static final String SQL_MY_PROJECTS =
      "SELECT p.*, string_agg(distinct f.name, ', ' order by f.name) as fleets FROM project p "
          + "LEFT JOIN change_group cg ON cg.project_id = p.id "
          + "LEFT JOIN aircraft_change_group acg ON acg.change_group_id = cg.id "
          + "LEFT JOIN aircraft a ON acg.aircraft_id = a.id "
          + "LEFT JOIN fleet f ON a.fleet_id = f.id "
          + "LEFT JOIN project_coauthor pc ON pc.project_id = p.id "
          + " WHERE p.approved is null and (p.author=:userId OR p.check_engineer =:userId OR p.approval_engineer = :userId OR pc.coauthor =:userId) GROUP BY p.id  ";

  public static final String SQL_APPROVED_PROJECTS =
      "SELECT p.*, string_agg(distinct f.name, ', ' order by f.name) as fleets FROM project p "
          + "LEFT JOIN change_group cg ON cg.project_id = p.id "
          + "LEFT JOIN aircraft_change_group acg ON acg.change_group_id = cg.id "
          + "LEFT JOIN aircraft a ON acg.aircraft_id = a.id "
          + "LEFT JOIN fleet f ON a.fleet_id = f.id "
          + "WHERE p.approved is null GROUP BY p.id ";

  public static final String SQL_COUNT_MY_PROJECTS =
      "SELECT count(distinct p.id) FROM project p "
          + "LEFT JOIN change_group cg ON cg.project_id = p.id "
          + "LEFT JOIN aircraft_change_group acg ON acg.change_group_id = cg.id "
          + "LEFT JOIN aircraft a ON acg.aircraft_id = a.id "
          + "LEFT JOIN fleet f ON a.fleet_id = f.id "
          + "LEFT JOIN project_coauthor pc ON pc.project_id = p.id "
          + "WHERE p.approved is null and (p.author=? OR p.check_engineer =? OR p.approval_engineer =? OR pc.coauthor =?) ";

  public static final String SQL_COUNT_APPROVED_PROJECTS =
      "SELECT count(distinct p.id) FROM project p "
          + "LEFT JOIN change_group cg ON cg.project_id = p.id "
          + "LEFT JOIN aircraft_change_group acg ON acg.change_group_id = cg.id "
          + "LEFT JOIN aircraft a ON acg.aircraft_id = a.id "
          + "LEFT JOIN fleet f ON a.fleet_id = f.id "
          + "LEFT JOIN project_coauthor pc ON pc.project_id = p.id "
          + "WHERE p.approved is null";

  public static final String SQL_PROJECT_COAUTHORS =
      "SELECT pc.coauthor from project_coauthor pc where pc.project_id =:pId";

  public List<AssignedProjectDTO> getMyProjects(String userId) {
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("userId", userId);
    return createAssignedProjectDTO(SQL_MY_PROJECTS, parameters);
  }

  public List<AssignedProjectDTO> findAllByApprovedIsNull() {
    return createAssignedProjectDTO(SQL_APPROVED_PROJECTS, null);
  }

  public Integer findCount(String userId) {
    if (userId == null) {
      return (Integer)
          jdbcTemplate.queryForObject(SQL_COUNT_APPROVED_PROJECTS, null, Integer.class);
    } else {
      return jdbcTemplate.queryForObject(
          SQL_COUNT_MY_PROJECTS, new Object[] {userId, userId, userId, userId}, Integer.class);
    }
  }

  private List<String> findCoauthors(String projectId) {
    MapSqlParameterSource parameters = new MapSqlParameterSource();
    parameters.addValue("pId", UUID.fromString(projectId));
    return npJdbcTemplate.query(
        SQL_PROJECT_COAUTHORS,
        parameters,
        (rs, rowNum) -> {
          return new String(rs.getString("coauthor"));
        });
  }

  private List<AssignedProjectDTO> createAssignedProjectDTO(
      String sql, MapSqlParameterSource parameters) {

    List<AssignedProjectDTO> assignedProjectDTOs =
        npJdbcTemplate.query(
            sql,
            parameters,
            (rs, rowNum) -> {

              // get projects comments
              List<ProjectCommentDTO> commentDTOs = new ArrayList<>();
              List<ProjectComment> comments =
                  projectCommentRepo.findAllByProject_Id(UUID.fromString(rs.getString("id")));
              comments.stream()
                  .forEach(
                      comment ->
                          commentDTOs.add(mapperPartial.map(comment, ProjectCommentDTO.class)));

              // get projects coauthors
              List<String> coauthors = findCoauthors(rs.getString("id"));

              // set the date fields and the display/status fields for the approved, checked and
              // submitted dates
              Instant submitted = getInstantFromResultSet(rs, "submitted");
              Instant checked = getInstantFromResultSet(rs, "checked");
              Instant approved = getInstantFromResultSet(rs, "approved");
              Instant started = getInstantFromResultSet(rs, "started");
              Instant rejected = getInstantFromResultSet(rs, "rejected");
              Instant created = getInstantFromResultSet(rs, "created");
              String submittedStatus = formatDisplayDate(submitted);
              String checkedStatus = formatDisplayDate(checked);
              String approvedStatus = formatDisplayDate(approved);

              if ((started != null && submitted == null) || rejected != null) {
                checkedStatus = DRAFT;
                approvedStatus = DRAFT;
                submittedStatus = null;
              } else if (started != null && submitted != null && checked == null) {
                checkedStatus = IN_REVIEW;
                approvedStatus = null;
              } else if (started != null
                  && submitted != null
                  && checked != null
                  && approved == null) {
                approvedStatus = IN_REVIEW;
              }

              return new AssignedProjectDTO(
                  rs.getString("id"),
                  rs.getString("fleets"),
                  rs.getString("title"),
                  rs.getString("number"),
                  rs.getString("description"),
                  started,
                  submitted,
                  submittedStatus,
                  checked,
                  checkedStatus,
                  approved,
                  approvedStatus,
                  rejected,
                  rs.getString("author"),
                  rs.getString("approval_engineer"),
                  rs.getString("check_engineer"),
                  coauthors,
                  created,
                  commentDTOs);
            });

    return assignedProjectDTOs;
  }

  /**
   * manually create pagination with sorting sql
   *
   * @param sql
   * @param limit
   * @param offset
   * @param sortAscending
   * @param sortField
   * @return
   */
  protected String createPaginationSQL(
      String sql, Integer limit, Integer offset, boolean sortAscending, String sortField) {
    StringBuilder paginationSQL = new StringBuilder(sql + "ORDER BY " + sortField);
    paginationSQL.append((sortAscending) ? " ASC " : " DESC ");
    if (limit != null && offset != null) {
      paginationSQL.append(" LIMIT " + limit + " OFFSET " + offset);
    }
    return paginationSQL.toString();
  }

  private Instant getInstantFromResultSet(ResultSet rs, String field) throws SQLException {
    return rs.getTimestamp(field) == null ? null : rs.getTimestamp(field).toInstant();
  }

  private String formatDisplayDate(Instant date) {
    return date != null ? dateFormatter.withZone(ZoneId.systemDefault()).format(date) : null;
  }
}
