package com.seatec.ela.app.service.project;

import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.repository.project.NodeChangeRepo;
import com.seatec.ela.app.service.contract.project.INodeChangeService;
import java.util.Optional;
import java.util.UUID;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NodeChangeService implements INodeChangeService {

  @Autowired private NodeChangeRepo repository;

  public Optional<NodeChange> findById(UUID id) {
    return repository.findById(id);
  }

  @Transactional
  public NodeChange save(NodeChange nodeChange) {
    return repository.save(nodeChange);
  }
}
