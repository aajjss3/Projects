package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.model.View.SummaryView;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.persistence.*;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.SortNatural;

@Entity
@Table(name = "fleet")
@JsonView(SummaryView.class)
public class Fleet implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "name", unique = true, nullable = false)
  private String name;

  @Column(name = "manufacturer", nullable = false)
  private String manufacturer;

  @Column(name = "bus_structure_bucket")
  private String busStructureBucket;

  @Column(name = "structure_name")
  private String structureName;

  @Column(name = "archived", nullable = false)
  @ColumnDefault("false")
  private boolean archived;

  @ManyToOne
  @JoinColumn(name = "fleet_id")
  @JsonIgnore
  private Fleet parentFleet;

  @OneToMany(mappedBy = "parentFleet", cascade = CascadeType.ALL)
  @OrderBy("name")
  private final List<Fleet> subFleets = new ArrayList<>();

  @OneToMany(mappedBy = "fleet", cascade = CascadeType.ALL)
  @SortNatural
  private SortedSet<Aircraft> aircraft = new TreeSet<>();

  @Column(name = "etops", nullable = false)
  @ColumnDefault("false")
  // ETOPS means "Extended Operation", in general it means an Aircraft can fly over the ocean
  private boolean etops;

  public Fleet() {}

  public Fleet(
      Long id,
      String name,
      String manufacturer,
      String busStructureBucket,
      String structureName,
      boolean archived,
      boolean etops) {
    this.id = id;
    this.name = name;
    this.manufacturer = manufacturer;
    this.busStructureBucket = busStructureBucket;
    this.structureName = structureName;
    this.archived = archived;
    this.etops = etops;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getManufacturer() {
    return manufacturer;
  }

  public void setManufacturer(String manufacturer) {
    this.manufacturer = manufacturer;
  }

  public String getBusStructureBucket() {
    return busStructureBucket;
  }

  public void setBusStructureBucket(String busStructureBucket) {
    this.busStructureBucket = busStructureBucket;
  }

  public String getStructureName() {
    return structureName;
  }

  public void setStructureName(String structureName) {
    this.structureName = structureName;
  }

  public Fleet getParentFleet() {
    return parentFleet;
  }

  public void setParentFleet(Fleet parentFleet) {
    this.parentFleet = parentFleet;
  }

  public List<Fleet> getSubFleets() {
    return subFleets;
  }

  public SortedSet<Aircraft> getAircraft() {
    return aircraft;
  }

  public void setAircraft(SortedSet<Aircraft> aircraft) {
    this.aircraft = aircraft;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public boolean isEtops() {
    return etops;
  }

  public void setEtops(boolean etops) {
    this.etops = etops;
  }

  public List<String> getOperatingModes() {
    return OperatingMode.getOperatingModes(this.manufacturer, this.name);
  }

  public List<FlightPhaseDto> getFlightPhases() {
    return FlightPhase.getFlightPhases(this.manufacturer, this.etops, this.name, false);
  }
}
