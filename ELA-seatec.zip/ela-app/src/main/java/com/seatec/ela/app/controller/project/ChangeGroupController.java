package com.seatec.ela.app.controller.project;

import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.analysis.ProjectAnalysis;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.View;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.project.ProjectAnalysisService;
import com.seatec.ela.app.validator.annotation.IdExists;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/projects/{projectId}/changegroups")
@Validated
public class ChangeGroupController {

  @Autowired IChangeGroupService changeGroupService;

  @Autowired ProjectAnalysisService projectAnalysisService;

  @GetMapping()
  @ResponseStatus(HttpStatus.OK)
  public List<ChangeGroup> findAllByProjectId(
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId) {
    return changeGroupService.findAllByProjectId(projectId);
  }

  @GetMapping("/{changeGroupId}")
  @ResponseStatus(HttpStatus.OK)
  public Optional<ChangeGroup> findById(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    return changeGroupService.findById(changeGroupId);
  }

  @GetMapping("/{changeGroupId}/effectivity")
  @JsonView(View.EffectivitySummaryView.class)
  @ResponseStatus(HttpStatus.OK)
  public List<ChangeGroupNodeDto> findChangeGroupEffectivityByChangeGroupId(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    return changeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(changeGroupId);
  }

  @GetMapping("/{changeGroupId}/nodes/{nodeName}/components")
  @ResponseStatus(HttpStatus.OK)
  public List<ComponentDto> findComponentsByChangeGroupNode(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      @PathVariable String nodeName) {
    Optional<ChangeGroup> changeGroupEntity = findById(changeGroupId);

    return changeGroupEntity.isPresent()
        ? changeGroupService.findComponentsByChangeGroupAndNodeName(
            changeGroupEntity.get(), nodeName)
        : Collections.emptyList();
  }

  @GetMapping("/{changeGroupId}/fleets")
  @ResponseStatus(HttpStatus.OK)
  public List<FleetDto> findParentFleetsByChangeGroup(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    return changeGroupService.findParentFleets(changeGroupId);
  }

  @PatchMapping("/{changeGroupId}/name")
  @ResponseStatus(HttpStatus.OK)
  public void updateChangeGroupName(
      @Validated
          @NotBlank(message = "{field.required}")
          @Size(max = 127, message = "{field.value.max}")
          @RequestBody
          String name,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    changeGroupService.updateChangeGroupName(changeGroupId, name);
  }

  // Create Change Groups based on Effectivities selected
  @PostMapping("/effectivity")
  @ResponseStatus(HttpStatus.OK)
  public void saveByBusStructureBucketUsingAircraftIds(
      @RequestBody List<Long> aircraftIds,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId) {
    changeGroupService.saveByBusStructureBucketUsingAircraftIds(aircraftIds, projectId);
  }

  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public ChangeGroup save(
      @Validated @RequestBody ChangeGroup changeGroup,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId) {
    return changeGroupService.save(changeGroup, projectId);
  }

  @PutMapping("/{changeGroupId}")
  @ResponseStatus(HttpStatus.OK)
  public void update(
      @Validated @RequestBody ChangeGroup changeGroup,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    changeGroupService.update(changeGroup, changeGroupId);
  }

  @PutMapping("/{changeGroupId}/effectivity")
  @ResponseStatus(HttpStatus.OK)
  public void updateEffectivity(
      @RequestBody List<Long> aircraftIds,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    changeGroupService.updateEffectivity(aircraftIds, projectId, changeGroupId);
  }

  @DeleteMapping("/{changeGroupId}")
  @ResponseStatus(HttpStatus.OK)
  public void delete(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    changeGroupService.delete(changeGroupId);
  }

  @GetMapping("{changeGroupId}/analysis")
  @ResponseStatus(HttpStatus.OK)
  public List<ProjectAnalysis> getChangeGroupAnalysis(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupdId) {
    return projectAnalysisService.getAnalysis(changeGroupdId, null, true);
  }

  @GetMapping("{changeGroupId}/aircraft/{aircraftId}/analysis")
  @ResponseStatus(HttpStatus.OK)
  public ProjectAnalysis getAircraftAnalysis(
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupdId,
      @IdExists(entity = Aircraft.class, message = "{id.invalid}") @PathVariable("aircraftId")
          Long aircraftId) {
    return projectAnalysisService.getAnalysis(changeGroupdId, aircraftId, false).get(0);
  }
}
