package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.NodeUtil;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** TruLoadSummaryCalculator calculates load summaries for TRU nodes. */
public class TruLoadSummaryCalculator {
  private static Logger logger = LoggerFactory.getLogger(TruLoadSummaryCalculator.class);

  private static final TruAggregator LOAD_SUMMARY_AGGREGATOR = new TruAggregator();

  // suppress default constructor for noninstantiability
  private TruLoadSummaryCalculator() {
    throw new AssertionError();
  }

  /**
   * Calculate the load summaries for an actual TRU node or a node treated as a TRU.
   *
   * <p>Note: When summing up loads - if a node is a transformer (node type of ATU or TRU), then all
   * child and grandchild nodes under it are considered transformers and will have the same
   * transformer type as the first ancestral transformer parent/grandparent in the node tree
   * (independent of the actual child node's nodeType which might not even be a transformer type)
   *
   * <p>Note: This code assumes that a TRU node does not have an AC3 load.
   *
   * @param loadSummaryMap - map containing the load summaries
   * @param summaryType - the summary type of the load summaries
   * @param loadSummaryOptions - the load summary options
   * @param node - the node
   * @param topMostAncestorTransformer - the first ancestral transformer parent/grandparent in the
   *     node tree
   */
  public static void calculateLoadSummaries(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull SummaryType summaryType,
      @NotNull LoadSummaryOptions loadSummaryOptions,
      @NotNull Node node,
      Node topMostAncestorTransformer) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(summaryType, "summaryType must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");
    Objects.requireNonNull(node, "node must not be null");

    /*
     * When summing up loads - if a node is a transformer (node type of ATU or TRU), then all child
     * and grandchild nodes under it are considered transformers and will have the same transformer
     * type as the first ancestral transformer parent/grandparent in the node tree (independent of the
     * actual child node's nodeType which might not even be a transformer type).
     */
    NodeType actingNodeType = node.getNodeType();
    EfficiencyTable actingEfficiencyTable = node.getEfficiencyTable();
    String rootTransformerNodeIdentifier = null;

    if (topMostAncestorTransformer != null) {
      actingNodeType = topMostAncestorTransformer.getNodeType();
      actingEfficiencyTable = topMostAncestorTransformer.getEfficiencyTable();
      rootTransformerNodeIdentifier = NodeUtil.getNodeIdentifier(topMostAncestorTransformer);
    }

    NodeUtil.validateNodeType(NodeType.TRU, actingNodeType);

    for (Component component : node.getComponents()) {

      DefaultLoadSummaryCalculator.calcNominalLoadSummaries(
          loadSummaryMap, summaryType, loadSummaryOptions, component);

      ElectricalPhase electricalPhase = component.getElectricalPhase();

      switch (electricalPhase) {
        case DC:
          calcLoadSummariesDC(
              loadSummaryMap,
              summaryType,
              loadSummaryOptions,
              component,
              rootTransformerNodeIdentifier,
              actingEfficiencyTable);
          break;
        case AC:
        case ACA:
        case ACB:
        case ACC:
          calcLoadSummaries(
              loadSummaryMap,
              summaryType,
              loadSummaryOptions,
              component,
              rootTransformerNodeIdentifier,
              actingEfficiencyTable);
          break;
        default:
          // NOTE: This code assumes that a transformer node (ie ATU or TRU)
          // does not have an AC3 load. If it does, then this won't work.
          logger.info(
              "Summarized Loads NOT calculated for node: {} nodeType: {}, component: {}, electricalPhase: {}",
              NodeUtil.getNodeIdentifier(node),
              node.getNodeType(),
              component.getName(),
              electricalPhase);
          break;
      }
    }
  }

  private static void calcLoadSummariesDC(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {

    for (Load load : component.getLoads()) {
      createLoadSummaryPlaceholdersDCSplit(loadSummaryMap, summaryType, loadSummaryOptions, load);
      TransformerLoadSummaryUtil.calcLoadSummary(
          loadSummaryMap,
          summaryType,
          loadSummaryOptions,
          component,
          load,
          rootTransformerNodeIdentifier,
          efficiencyTable,
          LOAD_SUMMARY_AGGREGATOR);
    }
  }

  private static void calcLoadSummaries(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {

    for (Load load : component.getLoads()) {
      TransformerLoadSummaryUtil.calcLoadSummary(
          loadSummaryMap,
          summaryType,
          loadSummaryOptions,
          component,
          load,
          rootTransformerNodeIdentifier,
          efficiencyTable,
          LOAD_SUMMARY_AGGREGATOR);
    }
  }

  /* If a node type is a TRU transformer and the electrical phase is DC
   * then ultimately it will be split between ACA, ACB and ACC
   * Create them now and add them to the loadSummaries collection,
   * Otherwise if they are created when they are needed,
   * which is while looping thru the loadSummaries collection,
   * it will cause a ConcurrentModificationException.
   */
  private static void createLoadSummaryPlaceholdersDCSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummaryType summaryType,
      LoadSummaryOptions loadSummaryOptions,
      Load load) {

    String flightPhase = load.getFlightPhase();
    String operatingMode = load.getOperatingMode();

    LoadSummaryUtil.findOrCreateLoadSummariesPhaseSplit(loadSummaryMap, summaryType, load);
    if (loadSummaryOptions.getIncludeAggregateAC3Loads()) {
      LoadSummaryUtil.findOrCreateLoadSummary(
          loadSummaryMap,
          summaryType,
          ElectricalPhase.AC3,
          flightPhase,
          operatingMode,
          false,
          false);
    }
  }

  public static void calcLoadSummariesDCSplitNormal(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(loadSummary, "loadSummary must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");

    LoadSummaryUtil.validateElectricalPhase(ElectricalPhase.DC, loadSummary);

    List<SummarizedLoad> loadSummariesDCSplit =
        findOrCreateLoadSummariesDCSplit(loadSummaryMap, loadSummary);
    LOAD_SUMMARY_AGGREGATOR.aggregateLoadSummariesDCSplitNormal(loadSummary, loadSummariesDCSplit);

    if (loadSummaryOptions.getIncludeAggregateAC3Loads()) {

      // AC3 aggregate
      SummarizedLoad loadSummaryAC3 =
          LoadSummaryUtil.findOrCreateLoadSummary(
              loadSummaryMap,
              loadSummary.getSummaryType(),
              ElectricalPhase.AC3,
              loadSummary.getFlightPhase(),
              loadSummary.getOperatingMode(),
              false,
              false);
      loadSummaryAC3.aggregateW(loadSummary.getW());
      loadSummaryAC3.aggregateVar(loadSummary.getVar());
    }
  }

  public static void calcLoadSummariesDCSplitDegraded(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions) {

    LoadSummaryUtil.validateElectricalPhase(ElectricalPhase.DC, loadSummary);

    List<SummarizedLoad> loadSummariesDCSplit =
        findOrCreateLoadSummariesDCSplit(loadSummaryMap, loadSummary);
    LOAD_SUMMARY_AGGREGATOR.aggregateLoadSummariesDCSplitDegraded(
        loadSummary, loadSummariesDCSplit);

    if (loadSummaryOptions.getIncludeAggregateAC3Loads()) {

      // AC3 aggregate
      SummarizedLoad loadSummaryAC3 =
          LoadSummaryUtil.findOrCreateLoadSummary(
              loadSummaryMap,
              loadSummary.getSummaryType(),
              ElectricalPhase.AC3,
              loadSummary.getFlightPhase(),
              loadSummary.getOperatingMode(),
              false,
              false);
      loadSummaryAC3.aggregateWEssentialLoad(loadSummary.getwEssentialLoad());
      loadSummaryAC3.aggregateVarEssentialLoad(loadSummary.getVarEssentialLoad());
    }
  }

  private static List<SummarizedLoad> findOrCreateLoadSummariesDCSplit(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap, SummarizedLoad loadSummaryDC) {
    SummaryType summaryType = loadSummaryDC.getSummaryType();
    String flightPhase = loadSummaryDC.getFlightPhase();
    String operatingMode = loadSummaryDC.getOperatingMode();

    return LoadSummaryUtil.findOrCreateLoadSummariesPhaseSplit(
        loadSummaryMap, summaryType, flightPhase, operatingMode, false, false);
  }
}
