package com.seatec.ela.app.util.pdf;

import com.lowagie.text.Chapter;
import com.lowagie.text.Chunk;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.awt.Color;
import java.text.DecimalFormat;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PdfFormatUtil {
  // Colors
  public static final Color PRIMARY_COLOR = Color.BLACK;
  public static final Color SECONDARY_COLOR = Color.GRAY;

  // font family
  public static final String FONT_FAMILY = FontFactory.HELVETICA;

  // font size(s)
  private static final float SUB_ROW_FONT_SIZE = 8f;
  private static final int FONT_CELL_SIZE = 10;

  // font style(s)
  public static final Font BOLD_FONT = new Font(-1, FONT_CELL_SIZE, 1);
  public static final Font ITALIC_FONT = new Font(-1, FONT_CELL_SIZE, 2);

  // font variant(s)
  public static final Font PAGE_H1_FONT =
      FontFactory.getFont(FONT_FAMILY, 18, Font.BOLD, PRIMARY_COLOR);
  public static final Font PAGE_H2_FONT = FontFactory.getFont(FONT_FAMILY, 16, SECONDARY_COLOR);

  // cell alignment
  private static final int CELL_VERTICAL_ALIGN_MIDDLE = Element.ALIGN_MIDDLE;
  private static final float PARAGRAPH_EXTRA_SPACE = 4f;

  // text formatter(s)
  public static final DecimalFormat DECIMAL_FORMAT_0_PLACE = new DecimalFormat("#");
  public static final DecimalFormat DECIMAL_FORMAT_1_PLACE_NO_LEAD = new DecimalFormat("#.0");
  public static final DecimalFormat DECIMAL_FORMAT_3_PLACE_NO_LEAD = new DecimalFormat("#.000");
  public static final DecimalFormat DECIMAL_FORMAT_1_PLACE = new DecimalFormat("#0.0");
  public static final DecimalFormat DECIMAL_FORMAT_2_PLACES = new DecimalFormat("#0.00");
  public static final DecimalFormat DECIMAL_FORMAT_3_PLACES = new DecimalFormat("#0.000");
  public static final DecimalFormat DECIMAL_FORMAT_PERCENT = new DecimalFormat("#,##0.0 '%'");

  // date formatter(s)
  public static final DateTimeFormatter DATE_TIME_LONG =
      DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm:ss a z").withZone(ZoneId.systemDefault());
  public static final DateTimeFormatter DATE_TIME_SHORT =
      DateTimeFormatter.ofPattern("MMM dd, yyyy").withZone(ZoneId.systemDefault());

  private static final String BOEING_NAME = "boeing";

  @Autowired ClientConfig clientConfig;

  public static String convertActionTypeText(ActionType actionType) {
    String label;

    switch (actionType) {
      case ADD:
        label = "Added";
        break;
      case EDIT:
        label = "Edited";
        break;
      case DELETE:
        label = "Deleted";
        break;
      default:
        throw new NotFoundException("Unexpected value: " + actionType, Level.WARN);
    }

    return label;
  }

  public static String convertFlightPhaseText(String flightPhase) {
    switch (flightPhase) {
      case "CLIMB":
        return "Climb";
      case "CRUISE":
        return "Cruise";
      case "CRUISE_COLD":
        return "Cruise Cold";
      case "CRUISE_HOT":
        return "Cruise Hot";
      case "DESCENT":
        return "Descent";
      case "DESCENT_LAND":
        return "Descent / Land";
      case "EMERGENCY":
        return "Emergency";
      case "ENGINE_START":
        return "Engine Start";
      case "GROUND":
        return "Ground";
      case "GROUND_SERVICE":
        return "Ground Service";
      case "HOLD_LAND":
        return "Hold / Land";
      case "LANDING":
        return "Land";
      case "LOADING":
        return "Loading";
      case "ROLL":
        return "Roll";
      case "STANDBY":
        return "Standby";
      case "START":
        return "Start";
      case "TAKEOFF_CLIMB":
        return "Takeoff / Climb";
      case "TAXI":
        return "Taxi";
      case "TOFF":
        return "T/Off";
      default:
        return flightPhase;
    }
  }

  public static String convertOperatingModeText(String operatingMode) {
    switch (operatingMode) {
      case "FIVE_SEC":
        return "5 Seconds";
      case "FIVE_MIN":
        return "5 Minutes";
      case "FIFTEEN_MIN":
        return "15 Minutes";
      default:
        return operatingMode;
    }
  }

  public static String getNodeRatingVoltage(Node node) {
    Double busRating = node.getBusRating();
    String unitsSeparator = " AMPS, ";
    Double voltage = node.getVoltage();
    Double downVoltage = null;
    switch (node.getNodeType()) {
      case GENERATOR:
        busRating = node.getNominalPower();
        unitsSeparator = " KVA, ";
        break;
      case TRU:
        busRating = node.getNominalPower();
        unitsSeparator = " AMPS, ";
        downVoltage = node.getInlineVoltage();
        break;
      case ATU:
        busRating = node.getNominalPower();
        unitsSeparator = " VA, ";
        downVoltage = node.getInlineVoltage();
        break;
    }
    if (busRating == null) {
      return DECIMAL_FORMAT_0_PLACE.format(node.getVoltage()) + "V";
    } else if (downVoltage == null) {
      return DECIMAL_FORMAT_0_PLACE.format(busRating)
          + unitsSeparator
          + DECIMAL_FORMAT_0_PLACE.format(voltage)
          + " V";
    } else {
      return DECIMAL_FORMAT_0_PLACE.format(busRating)
          + unitsSeparator
          + DECIMAL_FORMAT_0_PLACE.format(voltage)
          + " V / "
          + DECIMAL_FORMAT_0_PLACE.format(downVoltage)
          + " V";
    }
  }

  public static PdfPTable createBaseTable() {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setSpacingBefore(15f);

    // If true the table will be kept on one page if it fits,
    // by forcing a new page if it doesn't fit on the current page.
    // The default is to split the table over multiple pages.
    pdfPTable.setKeepTogether(true);

    // If true the row will only split if it's the first one in an empty page.
    // It's true by default. It's only meaningful if setSplitRows(true).
    pdfPTable.setSplitLate(false);

    // When set the last row on every page will be extended to fill all the remaining space to the
    // bottom boundary.
    pdfPTable.setExtendLastRow(false);

    return pdfPTable;
  }

  public static PdfPTable createBaseTable(int columns) {
    PdfPTable pdfPTable = new PdfPTable(columns);
    pdfPTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setTotalWidth(100);
    pdfPTable.setSpacingBefore(15f);

    // If true the table will be kept on one page if it fits,
    // by forcing a new page if it doesn't fit on the current page.
    // The default is to split the table over multiple pages.
    pdfPTable.setKeepTogether(true);

    // When set the last row on every page will be extended to fill all the remaining space to the
    // bottom boundary.
    pdfPTable.setExtendLastRow(false);

    return pdfPTable;
  }

  public static PdfPTable createBaseTable(int columns, float[] columnWidths) {
    PdfPTable pdfPTable = new PdfPTable(columns);
    pdfPTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setSpacingBefore(15f);
    pdfPTable.setWidths(columnWidths);

    // If true the table will be kept on one page if it fits,
    // by forcing a new page if it doesn't fit on the current page.
    // The default is to split the table over multiple pages.
    pdfPTable.setKeepTogether(true);

    // When set the last row on every page will be extended to fill all the remaining space to the
    // bottom boundary.
    pdfPTable.setExtendLastRow(false);

    return pdfPTable;
  }

  public static PdfPTable createCoverPageTable() {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setWidths(new int[] {1});
    pdfPTable.setExtendLastRow(false);
    return pdfPTable;
  }

  public static PdfPCell createBlankRow(int columns) {
    PdfPCell pdfPCell = PdfFormatUtil.getBlankCell();
    pdfPCell.setColspan(columns);
    pdfPCell.addElement(Chunk.NEWLINE);
    return pdfPCell;
  }

  public static PdfPTable createTextTable(String phrase) {
    PdfPTable pdfPTable = new PdfPTable(1);
    pdfPTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
    pdfPTable.setWidthPercentage(100f);
    pdfPTable.setSpacingBefore(15f);
    pdfPTable.addCell(new Phrase(phrase));
    return pdfPTable;
  }

  /**
   * creates a Font used in PDF document output (sets size and style) size => 1 (18), 2 (16), 3
   * (14), 4+ (12) style => 1 (BOLD), 2 (ITALIC), 3 (BOLDITALIC)
   *
   * @param size - desired font size of text output
   * @return Font
   */
  public static Font createFont(int size) {
    Font font = new Font();

    // 1 = H1, 2 = H2, 3 = H3, 4+ default
    switch (size) {
      case 1:
        font.setSize(18);
        font.setStyle(3); // bold + italic
        break;
      case 2:
        font.setSize(16);
        font.setStyle(1); // bold
        break;
      case 3:
        font.setSize(14);
        font.setStyle(1); // bold
        break;
      default:
        font.setSize(12);
        break;
    }

    return font;
  }

  public PdfPCell flightPhaseTableBodyRowCell(String val, boolean isHighlighted) {
    PdfPCell cell =
        new PdfPCell(
            new Paragraph(
                val,
                cellFont(
                    8f,
                    isHighlighted ? 1 : 2,
                    isHighlighted ? clientConfig.getPrimaryFontColor() : Color.GRAY)));
    cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setBorder(Rectangle.NO_BORDER);
    return cell;
  }

  public PdfPCell flightPhaseTableBodyRowCellBold(String val) {
    PdfPCell cell =
        new PdfPCell(
            new Paragraph(val, cellFont(SUB_ROW_FONT_SIZE, 3, clientConfig.getPrimaryFontColor())));
    cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setBorder(Rectangle.NO_BORDER);
    return cell;
  }

  public PdfPCell flightPhaseTableBodyRowCellLabel(String val, float fontSize) {
    PdfPCell cell = new PdfPCell(new Paragraph(val, cellFont(fontSize, 3, Color.GRAY)));
    cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);

    // tells system that the borders aren't equal
    cell.setUseVariableBorders(true);
    cell.setBorder(Rectangle.BOTTOM);
    cell.setBorderColorBottom(Color.GRAY);
    return cell;
  }

  public PdfPCell flightPhaseTableHeaderRowCell(String val, float fontSize) {
    PdfPCell cell = new PdfPCell(new Paragraph(val, cellFont(fontSize, 3, Color.GRAY)));
    cell.setHorizontalAlignment(Element.ALIGN_LEFT);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setBorder(Rectangle.NO_BORDER);
    return cell;
  }

  public PdfPCell flightPhaseTableTitleRowCell(String val, int columns) {
    PdfPCell cell =
        new PdfPCell(new Paragraph(val, cellFont(10f, 1, clientConfig.getPrimaryFontColor())));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPaddingTop(10);
    cell.setPaddingRight(5);
    cell.setPaddingBottom(10);
    cell.setPaddingLeft(5);
    cell.setBackgroundColor(clientConfig.getSecondaryBackgroundColor());
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setColspan(columns);
    return cell;
  }

  public PdfPCell createColoredBackgroundTableHeaderRow() {
    Color backgroundColor = clientConfig.getSecondaryBackgroundColor();

    PdfPCell cell = new PdfPCell();
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPaddingTop(10);
    cell.setPaddingRight(5);
    cell.setPaddingBottom(10);
    cell.setPaddingLeft(5);
    cell.setBackgroundColor(backgroundColor);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);

    return cell;
  }

  public PdfPCell pdfPCellBlueBackgroundWithText(String val, int columns) {
    PdfPCell cell =
        new PdfPCell(new Paragraph(val, cellFont(10f, 1, clientConfig.getPrimaryFontColor())));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPaddingTop(10);
    cell.setPaddingRight(5);
    cell.setPaddingBottom(10);
    cell.setPaddingLeft(5);
    cell.setBackgroundColor(clientConfig.getSecondaryBackgroundColor());
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setColspan(columns);
    return cell;
  }

  public static Chapter generateChapter(String title, int pageNbr) {
    Chunk chunk = new Chunk(title, PAGE_H1_FONT).setLocalDestination(title);
    Chapter chapter = new Chapter(new Paragraph(chunk), pageNbr);
    chapter.setNumberDepth(0);
    return chapter;
  }

  public static PdfPCell getBlankCell() {
    PdfPCell cell = new PdfPCell();
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    return cell;
  }

  public static PdfPCell createTextCell(Phrase text) {
    PdfPCell cell = new PdfPCell(text);
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    return cell;
  }

  public PdfPCell getElaCoverPageCellWithParagraph(
      Paragraph paragraph, String preNameHeader, String reportName) {
    String name = reportName;
    Paragraph extraParagraph = null;
    if (preNameHeader != null) {
      name = preNameHeader;
      extraParagraph = new Paragraph(reportName, PAGE_H1_FONT);
    }
    Paragraph elaReportText = new Paragraph(name, PAGE_H1_FONT);
    if (extraParagraph != null) {
      elaReportText.add(new Chunk(Chunk.NEWLINE));
      elaReportText.add(new Chunk(Chunk.NEWLINE));
      elaReportText.add(new Chunk(Chunk.NEWLINE));
      elaReportText.add(extraParagraph);
    }
    elaReportText.add(new Chunk(Chunk.NEWLINE));
    elaReportText.add(paragraph);

    PdfPCell cell = new PdfPCell(elaReportText);
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setHorizontalAlignment(Element.ALIGN_CENTER);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    return cell;
  }

  public PdfPCell getSubTotalLabelCell(String text, int columnSpan) {
    PdfPCell cell =
        new PdfPCell(
            new Paragraph(
                text, cellFont(SUB_ROW_FONT_SIZE, 3, clientConfig.getPrimaryFontColor())));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setColspan(columnSpan);
    return cell;
  }

  public PdfPCell nodeBreadcrumbRowCell(String val, int columns) {
    PdfPCell cell =
        new PdfPCell(new Paragraph(val, cellFont(8f, 3, clientConfig.getSecondaryFontColor())));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPadding(10);
    cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setColspan(columns);
    return cell;
  }

  public PdfPCell nodeTitleRowCell(String val, int columns) {
    PdfPCell cell =
        new PdfPCell(new Paragraph(val, cellFont(14f, 3, clientConfig.getPrimaryFontColor())));
    cell.setBorder(Rectangle.NO_BORDER);
    cell.setPaddingTop(10);
    cell.setPaddingRight(0);
    cell.setPaddingBottom(10);
    cell.setPaddingLeft(0);
    cell.setVerticalAlignment(CELL_VERTICAL_ALIGN_MIDDLE);
    cell.setExtraParagraphSpace(PARAGRAPH_EXTRA_SPACE);
    cell.setColspan(columns);
    return cell;
  }

  public static boolean isBoeingAircraft(String manufacturer) {
    return manufacturer.equalsIgnoreCase(BOEING_NAME);
  }

  private Font cellFont(float fontSize, int style, Color color) {
    return new Font(-1, fontSize, style, color);
  }
}
