package com.seatec.ela.app.aop.userevent;

import com.seatec.ela.app.aop.userevent.LogConfig.Action;

/**
 * Configures the log messages for tracking UserTracked behavior. Log data is sent for controller
 * routes when a configuration is found that matches the sourceClass and sourceMethod of the
 * joinPoint.
 *
 * <ul>
 *   <li>sourceClass: name of Controller that will generate the event
 *   <li>sourceMethod: name of Controller Method that will generate the event
 *   <li>action: summarizes the type of operation performed by the User
 *   <li>concern: A short summary describing what the action operated on. This name is often simply
 *       the name of the entity viewed/created/updated. In other cases, it is often consistent with
 *       the route uri values excluding 'service' and parameters
 *   <li>paramNames: When the variable names used by a method make sense, this value is left null.
 *       In some cases, it is necessary to change a simple name like 'Id' that may be used in the
 *       output to a more descriptive name such as 'FleetId' to either prevent name conflicts or to
 *       improve the readability of the resulting log message. The convention is to capitalize
 *       paramNames.
 *   <li>Entities and Dto will log data based upon the UserTrack Interfaces
 *   <li>Note: In theory if the same userTrack interface is supported by multiple input parameters
 *       and/or the methodReturnObject they could both update the same key. So, the action for the
 *       key would match the last update which would likely be from methodReturnObject. This can be
 *       refactored if it one day becomes problematic.
 * </ul>
 */
public class LogUserTrackConfig {
  private String sourceClass;
  private String sourceMethod;
  private Action action;
  private String concern;
  private String[] paramNames;

  /** @see LogUserTrackConfig */
  LogUserTrackConfig(
      String sourceClass, String sourceMethod, Action action, String concern, String[] paramNames) {
    this.sourceClass = sourceClass;
    this.sourceMethod = sourceMethod;
    this.action = action;
    this.concern = concern;
    this.paramNames = paramNames;
  }

  public String getSourceClass() {
    return sourceClass;
  }

  public String getSourceMethod() {
    return sourceMethod;
  }

  public Action getAction() {
    return action;
  }

  public String getActionString() {
    return action.name();
  }

  public String getConcern() {
    return concern;
  }

  public String[] getParamNames() {
    return paramNames;
  }
}
