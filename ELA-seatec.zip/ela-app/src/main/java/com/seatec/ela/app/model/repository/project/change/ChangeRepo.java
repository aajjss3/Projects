package com.seatec.ela.app.model.repository.project.change;

import com.seatec.ela.app.model.project.change.Change;
import java.util.List;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ChangeRepo extends CrudRepository<Change, UUID> {
  List<Change> findAllByChangeGroupId(@Param("changeGroupId") UUID changeGroupId);
}
