package com.seatec.ela.app.model.repository;

import javax.persistence.Table;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BaseDAO {

  @Autowired JdbcTemplate jdbcTemplate;

  /**
   * Determine if a record exists in the database for the entity(table) and id passed in.
   *
   * @param entity
   * @param id
   * @return
   */
  public boolean isValidId(Class<?> entity, Object id) {
    String tableName =
        (entity.getDeclaredAnnotation(Table.class) != null)
            ? entity.getDeclaredAnnotation(Table.class).name()
            : entity.getSimpleName();
    int count =
        jdbcTemplate.queryForObject(
            "SELECT count(*) FROM " + tableName + " WHERE id = ?",
            new Object[] {id},
            Integer.class);
    return (count > 0) ? true : false;
  }
}
