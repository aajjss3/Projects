package com.seatec.ela.app.model;

public class View {
  public static interface BaseSummaryView {}

  public static interface SummaryView extends BaseSummaryView {}

  public static interface NodeSummaryView extends BaseSummaryView {}

  public static interface EffectivitySummaryView extends SummaryView {}
}
