package com.seatec.ela.app.model.project;

import com.seatec.ela.app.model.base.BaseComponentChange;
import com.seatec.ela.app.validator.annotation.ComponentLoadChange;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "component_change")
@ComponentLoadChange
public class ComponentChange extends BaseComponentChange {

  @OneToMany(cascade = {CascadeType.ALL})
  @JoinColumn(name = "component_change_id", nullable = false, updatable = false)
  private List<LoadChange> loadChanges = new ArrayList<>();

  public void addLoadChange(LoadChange loadChange) {
    loadChanges.add(loadChange);
    loadChange.setComponentChange(this);
  }

  public void removeLoadChange(LoadChange loadChange) {
    loadChanges.remove(loadChange);
    loadChange.setComponentChange(null);
  }

  public List<LoadChange> getLoadChanges() {
    return loadChanges;
  }

  public void setLoadChanges(List<LoadChange> loadChanges) {
    this.loadChanges = loadChanges;
  }
}
