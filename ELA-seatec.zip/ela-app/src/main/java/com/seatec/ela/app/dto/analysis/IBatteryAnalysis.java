package com.seatec.ela.app.dto.analysis;

import com.seatec.ela.app.util.enumeration.BatteryChargeType;

public interface IBatteryAnalysis {

  BatteryChargeType getBatteryCapacity();

  Double getRequiredBatteryLifeInMinutes();

  Double getTotalLoadInAmps();

  Double getActualBatteryLifeInMinutes();
}
