package com.seatec.ela.app.model.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.model.base.BaseEntity;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import com.seatec.ela.app.validator.annotation.ValidateEngineer;
import com.seatec.ela.app.validator.annotation.ValidateProjectDifferentApprovalChecker;
import com.seatec.ela.app.validator.filter.CreateProject;
import com.seatec.ela.app.validator.filter.UpdateProject;
import com.seatec.ela.app.validator.filter.ValidateProject;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "project")
@ValidateProjectDifferentApprovalChecker(groups = {ValidateProject.class})
public class Project extends BaseEntity {
  @NotNull(
      groups = {CreateProject.class, UpdateProject.class},
      message = "{field.required}")
  private Instant started;

  private Instant submitted;

  private Instant checked;

  private Instant approved;

  private Instant retired;

  private Instant rejected;

  @Column(length = 120)
  private String description;

  @Column(length = 20)
  @NotEmpty(
      groups = {CreateProject.class, UpdateProject.class},
      message = "{field.required}")
  private String number;

  @Column(name = "revision_level", length = 20)
  private String revisionLevel;

  @Column(name = "maintenance_description", length = 120)
  private String maintenanceDescription;

  @Column(length = 50)
  @NotEmpty(
      groups = {CreateProject.class, UpdateProject.class},
      message = "{field.required}")
  private String title;

  @Column(name = "check_engineer", length = 127)
  @ValidateEngineer(
      keycloakRole = KeycloakRole.CHECKER,
      groups = {CreateProject.class, UpdateProject.class},
      message = "{invalid.engineer}")
  private String checkEngineer;

  @Column(name = "approval_engineer", length = 127)
  @ValidateEngineer(
      keycloakRole = KeycloakRole.APPROVER,
      groups = {CreateProject.class, UpdateProject.class},
      message = "{invalid.engineer}")
  private String approvalEngineer;

  @OneToMany(
      mappedBy = "project",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<ChangeGroup> changeGroups = new ArrayList<>();

  // the keycloak user id
  @Column(length = 127)
  private String author;

  // the keycloak user id
  @ElementCollection
  @CollectionTable(name = "project_coauthor", joinColumns = @JoinColumn(name = "project_id"))
  @Column(name = "coauthor", length = 127)
  private List<String> coauthors = new ArrayList<>();

  @OneToMany(
      mappedBy = "project",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<ProjectComment> comments = new ArrayList<>();

  @Type(type = "jsonb")
  @Column(columnDefinition = "jsonb")
  @JsonIgnore
  private ProjectReportDTO analysis;

  public void addChangeGroup(ChangeGroup changeGroup) {
    changeGroups.add(changeGroup);
    changeGroup.setProject(this);
  }

  public void removeChangeGroup(ChangeGroup changeGroup) {
    changeGroups.remove(changeGroup);
    changeGroup.setProject(null);
  }

  public void addComment(ProjectComment comment) {
    comments.add(comment);
    comment.setProject(this);
  }

  public void removeComment(ProjectComment comment) {
    comments.remove(comment);
    comment.setProject(null);
  }

  public Instant getStarted() {
    return started;
  }

  public void setStarted(Instant started) {
    this.started = started;
  }

  public Instant getSubmitted() {
    return submitted;
  }

  public void setSubmitted(Instant submitted) {
    this.submitted = submitted;
  }

  public Instant getChecked() {
    return checked;
  }

  public void setChecked(Instant checked) {
    this.checked = checked;
  }

  public Instant getApproved() {
    return approved;
  }

  public void setApproved(Instant approved) {
    this.approved = approved;
  }

  public void setRetired(Instant retired) {
    this.retired = retired;
  }

  public Instant getRetired() {
    return retired;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public String getRevisionLevel() {
    return revisionLevel;
  }

  public void setRevisionLevel(String revisionLevel) {
    this.revisionLevel = revisionLevel;
  }

  public String getMaintenanceDescription() {
    return maintenanceDescription;
  }

  public void setMaintenanceDescription(String maintenanceDescription) {
    this.maintenanceDescription = maintenanceDescription;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public List<ChangeGroup> getChangeGroups() {
    return changeGroups;
  }

  public void setChangeGroups(List<ChangeGroup> changeGroups) {
    this.changeGroups = changeGroups;
  }

  public String getCheckEngineer() {
    return checkEngineer;
  }

  public void setCheckEngineer(String checkEngineer) {
    this.checkEngineer = checkEngineer;
  }

  public String getApprovalEngineer() {
    return approvalEngineer;
  }

  public void setApprovalEngineer(String approvalEngineer) {
    this.approvalEngineer = approvalEngineer;
  }

  public String getAuthor() {
    return author;
  }

  public void setAuthor(String author) {
    this.author = author;
  }

  public List<ProjectComment> getComments() {
    return comments;
  }

  public void setComments(List<ProjectComment> comments) {
    this.comments = comments;
  }

  public List<String> getCoauthors() {
    return coauthors;
  }

  public void setCoauthors(List<String> coauthors) {
    this.coauthors = coauthors;
  }

  public Instant getRejected() {
    return rejected;
  }

  public void setRejected(Instant rejected) {
    this.rejected = rejected;
  }

  public ProjectReportDTO getAnalysis() {
    return analysis;
  }

  public void setAnalysis(ProjectReportDTO analysis) {
    this.analysis = analysis;
  }
}
