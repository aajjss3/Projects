package com.seatec.ela.app.util.csv;

import com.opencsv.bean.CsvToBeanBuilder;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CsvImport {

  private static final Logger logger = LoggerFactory.getLogger(CsvImport.class);

  public CsvData importAirbusCsv(InputStream in) {
    List<AirbusCsv> data = parseCsv(in);
    CsvData csvData = new CsvData();
    Map<String, List<AirbusCsvAggregateKey>> keyMap = csvData.getKeyMap();
    HashMap<AirbusCsvAggregateKey, AirbusCsvAggregate> dataMap = csvData.getDataMap();
    int rowIndex = 0;
    for (AirbusCsv row : data) {
      rowIndex++;
      AirbusCsvAggregateKey key =
          new AirbusCsvAggregateKey(row.getBusBar(), row.getPhase(), row.getIdentifier());
      List<AirbusCsvAggregateKey> keyMapValue = keyMap.get(row.getBusBar());
      if (keyMapValue == null) {
        keyMapValue = new ArrayList<>();
      }
      if (!keyMapValue.contains(key)) {
        keyMapValue.add(key);
      }
      keyMap.put(row.getBusBar(), keyMapValue);
      AirbusCsvAggregate value = dataMap.get(key);
      if (value == null) {
        dataMap.put(key, new AirbusCsvAggregate(row, rowIndex));
      } else {
        dataMap.put(key, value.updateAirbusCsvAggregate(row));
      }
    }
    return csvData;
  }

  private List<AirbusCsv> parseCsv(InputStream in) {
    Reader reader = new InputStreamReader(in);
    CsvToBeanBuilder<AirbusCsv> beanBuilder = new CsvToBeanBuilder<>(reader);
    beanBuilder.withType(AirbusCsv.class);
    beanBuilder.withVerifier(new CsvVerifier());
    beanBuilder.withSeparator(';');
    return beanBuilder.build().parse();
  }
}
