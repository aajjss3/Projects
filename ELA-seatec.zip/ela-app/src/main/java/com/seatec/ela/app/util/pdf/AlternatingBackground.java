package com.seatec.ela.app.util.pdf;

import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPTableEvent;
import java.awt.Color;

public class AlternatingBackground implements PdfPTableEvent {
  private static final Color BACKGROUND_COLOR = new Color(245, 245, 245, 1);

  public void tableLayout(
      PdfPTable pdfPTable,
      float[][] widths,
      float[] heights,
      int headerRows,
      int rowStart,
      PdfContentByte[] canvases) {

    int columns;
    Rectangle rect;
    int footer = widths.length - pdfPTable.getFooterRows();
    int header = pdfPTable.getHeaderRows() - pdfPTable.getFooterRows() + 1;

    for (int row = header; row < footer; row += 2) {
      columns = widths[row].length - 1;
      rect =
          new Rectangle(
              widths[row][0], heights[row],
              widths[row][columns], heights[row + 1]);

      rect.setBackgroundColor(BACKGROUND_COLOR);
      rect.setBorder(Rectangle.NO_BORDER);
      canvases[PdfPTable.BASECANVAS].rectangle(rect);
    }
  }
}
