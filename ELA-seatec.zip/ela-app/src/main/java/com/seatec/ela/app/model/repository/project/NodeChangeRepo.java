package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.model.project.NodeChange;
import java.util.UUID;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NodeChangeRepo extends CrudRepository<NodeChange, UUID> {}
