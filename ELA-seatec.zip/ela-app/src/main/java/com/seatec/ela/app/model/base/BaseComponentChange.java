package com.seatec.ela.app.model.base;

import com.seatec.ela.app.model.ElectricalPhase;
import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@MappedSuperclass
public class BaseComponentChange extends BaseChange {

  @Column(length = 127)
  private String ata;

  @Transient private Integer displayOrder;

  @Column(name = "clipsed")
  private Boolean clipsed;

  @Column(name = "sheddable")
  private Boolean sheddable;

  @NotNull(message = "{field.required}")
  @Column(name = "intermittent")
  private Boolean intermittent;

  @NotBlank(message = "{field.required}")
  @Column(name = "elect_ident", length = 127)
  private String electIdent;

  @Column(length = 127)
  private String panel;

  @NotNull(message = "{field.required}")
  @Enumerated(EnumType.STRING)
  @Column(name = "electrical_phase", length = 10)
  private ElectricalPhase electricalPhase;

  @Column(name = "connected_load_va")
  private Double connectedLoadVa;

  @Column(name = "connected_load_pf")
  private Double connectedLoadPf;

  public String getAta() {
    return ata;
  }

  public void setAta(String ata) {
    this.ata = ata;
  }

  public Integer getDisplayOrder() {
    return displayOrder;
  }

  public void setDisplayOrder(Integer displayOrder) {
    this.displayOrder = displayOrder;
  }

  public Boolean getClipsed() {
    return clipsed;
  }

  public void setClipsed(Boolean clipsed) {
    this.clipsed = clipsed;
  }

  public Boolean getSheddable() {
    return sheddable;
  }

  public void setSheddable(Boolean sheddable) {
    this.sheddable = sheddable;
  }

  public Boolean getIntermittent() {
    return intermittent;
  }

  public void setIntermittent(Boolean intermittent) {
    this.intermittent = intermittent;
  }

  public String getElectIdent() {
    return electIdent;
  }

  public void setElectIdent(String electIdent) {
    this.electIdent = electIdent;
  }

  public String getPanel() {
    return panel;
  }

  public void setPanel(String panel) {
    this.panel = panel;
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public Double getConnectedLoadVa() {
    return connectedLoadVa;
  }

  public void setConnectedLoadVa(Double connectedLoadVa) {
    this.connectedLoadVa = connectedLoadVa;
  }

  public Double getConnectedLoadPf() {
    return connectedLoadPf;
  }

  public void setConnectedLoadPf(Double connectedLoadPf) {
    this.connectedLoadPf = connectedLoadPf;
  }
}
