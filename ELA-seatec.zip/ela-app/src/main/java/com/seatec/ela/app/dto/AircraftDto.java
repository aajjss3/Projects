package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackIdLong;
import com.seatec.ela.app.aop.userevent.UserTrackShipNo;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.validator.annotation.BatteryChargeTypeRequiredIfBoeing;
import com.seatec.ela.app.validator.filter.CreateAircraft;
import com.seatec.ela.app.validator.filter.UpdateAircraft;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@BatteryChargeTypeRequiredIfBoeing(groups = {CreateAircraft.class, UpdateAircraft.class})
public class AircraftDto implements UserTrackIdLong, UserTrackShipNo {
  private Long id;

  @NotEmpty(
      groups = {CreateAircraft.class},
      message = "{field.required}")
  private String aircraftShipNo;

  @NotEmpty(
      groups = {CreateAircraft.class, UpdateAircraft.class},
      message = "{field.required}")
  private String serialNumber;

  @NotEmpty(
      groups = {CreateAircraft.class, UpdateAircraft.class},
      message = "{field.required}")
  private String registrationNumber;

  private String lineNumber;

  private String variableNumber;

  private boolean archived;

  private BatteryChargeType batteryCharge;

  @NotNull(
      groups = {CreateAircraft.class},
      message = "{field.required}")
  private Long fleetId;

  public AircraftDto() {}

  public AircraftDto(Aircraft aircraft) {
    this.id = aircraft.getId();
    this.aircraftShipNo = aircraft.getAircraftShipNo();
    this.serialNumber = aircraft.getSerialNumber();
    this.registrationNumber = aircraft.getRegistrationNumber();
    this.lineNumber = aircraft.getLineNumber();
    this.variableNumber = aircraft.getVariableNumber();
    this.archived = aircraft.isArchived();
    if (aircraft.getFleet() != null) {
      this.fleetId = aircraft.getFleet().getId();
    }
    this.batteryCharge = aircraft.getBatteryCharge();
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAircraftShipNo() {
    return aircraftShipNo;
  }

  public void setAircraftShipNo(String aircraftShipNo) {
    this.aircraftShipNo = aircraftShipNo;
  }

  public String getSerialNumber() {
    return serialNumber;
  }

  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public String getRegistrationNumber() {
    return registrationNumber;
  }

  public void setRegistrationNumber(String registrationNumber) {
    this.registrationNumber = registrationNumber;
  }

  public String getLineNumber() {
    return lineNumber;
  }

  public void setLineNumber(String lineNumber) {
    this.lineNumber = lineNumber;
  }

  public String getVariableNumber() {
    return variableNumber;
  }

  public void setVariableNumber(String variableNumber) {
    this.variableNumber = variableNumber;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public Long getFleetId() {
    return fleetId;
  }

  public void setFleetId(Long fleetId) {
    this.fleetId = fleetId;
  }

  public BatteryChargeType getBatteryCharge() {
    return batteryCharge;
  }

  public void setBatteryCharge(BatteryChargeType batteryCharge) {
    this.batteryCharge = batteryCharge;
  }
}
