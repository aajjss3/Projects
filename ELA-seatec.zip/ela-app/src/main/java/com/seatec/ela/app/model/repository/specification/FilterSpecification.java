package com.seatec.ela.app.model.repository.specification;

import com.seatec.ela.app.util.enumeration.QueryOperation;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

@SuppressWarnings("serial")
public class FilterSpecification<T> implements Specification<T> {

  private QueryOperation operation;
  private String field;
  private Object value;

  public FilterSpecification(QueryOperation operation, String field, Object value) {
    this.operation = operation;
    this.field = field;
    this.value = value;
  }

  public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
    if (field == null) {
      return null;
    }
    if (this.operation == QueryOperation.EQUAL) {
      return builder.equal(root.get(field), value);
    } else if (this.operation == QueryOperation.LIKE && value != null) {
      return builder.like(
          builder.upper(root.get(field)),
          "%" + ((String) value).trim().toUpperCase() + "%"); // case insensitive partial match
    } else if (this.operation == QueryOperation.NOT_NULL) {
      return builder.isNotNull(root.get(field));
    } else if (this.operation == QueryOperation.IN) {
      return root.join(field).in(value);
    }
    return null;
  }
}
