package com.seatec.ela.app.util.enumeration;

import static com.seatec.ela.app.util.enumeration.FlightPhase.BOEING_717_FLEET;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class OperatingMode {

  private static final String AIRBUS_MANUFACTURER = "airbus";
  private static final String BOEING_MANUFACTURER = "boeing";

  public enum Airbus {
    MAXI,
    OPERATIONAL
  }

  public enum Boeing {
    LOAD
  }

  public enum Boeing717 {
    FIVE_SEC,
    FIVE_MIN,
    FIFTEEN_MIN
  }

  public static List<String> getOperatingModes(String manufacturer, String fleet) {
    if (manufacturer.equalsIgnoreCase(AIRBUS_MANUFACTURER)) {
      return Arrays.stream(OperatingMode.Airbus.values())
          .map(Enum::toString)
          .collect(Collectors.toList());
    } else if (manufacturer.equalsIgnoreCase(BOEING_MANUFACTURER)) {
      if (fleet.startsWith(BOEING_717_FLEET)) {
        return Arrays.stream(OperatingMode.Boeing717.values())
            .map(Enum::toString)
            .collect(Collectors.toList());
      } else {
        return Arrays.stream(OperatingMode.Boeing.values())
            .map(Enum::toString)
            .collect(Collectors.toList());
      }
    } else {
      return Collections.emptyList();
    }
  }
}
