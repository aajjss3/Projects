package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.PaginationDTO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Build the HTTP Response Header
 *
 * @author asparago
 */
public class HttpResponseHeaderBuilder {

  /**
   * If server side pagination was requested then create a 'Link' HTTP Request Header and set it on
   * the Http Response.
   *
   * @param response
   * @param request
   * @param dto
   */
  public static void addLinkHeaderToHttpResponse(
      HttpServletResponse response, HttpServletRequest request, PaginationDTO<?> dto) {

    // if pagination is requested
    if (dto.getPage() != null && dto.getSize() != null && dto.getPage() <= dto.getTotalPages()) {

      UriComponentsBuilder uriBuilder =
          UriComponentsBuilder.fromHttpUrl(request.getRequestURL().toString());

      // place any query string parameters other than 'page' and 'size' on the url in the link
      // header
      String queryString = request.getQueryString();
      if (queryString != null && queryString.length() > 0) {
        String[] parameters = queryString.split("&");
        if (parameters.length > 0) {
          for (String parameter : parameters) {
            String[] param = parameter.split("=");
            if (!param[0].equalsIgnoreCase("page") && !param[0].equalsIgnoreCase("size")) {
              uriBuilder = uriBuilder.queryParam(param[0], param[1]);
            }
          }
        }
      }

      // place 'page' and 'size' query string parameters on the url in the link header
      StringBuilder linkHeader = new StringBuilder();
      if (dto.getPage() < dto.getTotalPages()) {
        String uriForNextPage =
            uriBuilder
                .replaceQueryParam("page", dto.getPage() + 1)
                .replaceQueryParam("size", dto.getSize())
                .build()
                .encode()
                .toUriString();
        linkHeader.append(createLinkHeader(uriForNextPage, "next"));
      }
      if (dto.getPage() > 1) {
        String uriForPrevPage =
            uriBuilder
                .replaceQueryParam("page", dto.getPage() - 1)
                .replaceQueryParam("size", dto.getSize())
                .build()
                .encode()
                .toUriString();
        appendComma(linkHeader);
        linkHeader.append(createLinkHeader(uriForPrevPage, "prev"));
      }
      String uriForFirstPage =
          uriBuilder
              .replaceQueryParam("page", 1)
              .replaceQueryParam("size", dto.getSize())
              .build()
              .encode()
              .toUriString();
      appendComma(linkHeader);
      linkHeader.append(createLinkHeader(uriForFirstPage, "first"));

      String uriForLastPage =
          uriBuilder
              .replaceQueryParam("page", dto.getTotalPages())
              .replaceQueryParam("size", dto.getSize())
              .build()
              .encode()
              .toUriString();
      appendComma(linkHeader);
      linkHeader.append(createLinkHeader(uriForLastPage, "last"));

      response.addHeader("Link", linkHeader.toString());
    }
  }

  private static void appendComma(StringBuilder linkHeader) {
    if (linkHeader.length() > 0) {
      linkHeader.append(", ");
    }
  }

  private static String createLinkHeader(String uri, String rel) {
    return "<" + uri + ">; rel=\"" + rel + "\"";
  }
}
