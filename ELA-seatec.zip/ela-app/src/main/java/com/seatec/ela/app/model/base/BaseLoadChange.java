package com.seatec.ela.app.model.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseLoadChange extends BaseEntity {

  @Column(name = "operating_mode", length = 20)
  private String operatingMode;

  private Double va;

  @Column(name = "flight_phase", length = 127)
  private String flightPhase;

  @Column(name = "power_factor")
  private Double powerFactor;

  public String getOperatingMode() {
    return operatingMode;
  }

  public void setOperatingMode(String operatingMode) {
    this.operatingMode = operatingMode;
  }

  public Double getVa() {
    return va;
  }

  public void setVa(Double va) {
    this.va = va;
  }

  public String getFlightPhase() {
    return flightPhase;
  }

  public void setFlightPhase(String flightPhase) {
    this.flightPhase = flightPhase;
  }

  public Double getPowerFactor() {
    return powerFactor;
  }

  public void setPowerFactor(Double powerFactor) {
    this.powerFactor = powerFactor;
  }
}
