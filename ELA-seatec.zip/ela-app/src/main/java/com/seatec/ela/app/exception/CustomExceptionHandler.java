package com.seatec.ela.app.exception;

import static org.springframework.core.annotation.AnnotatedElementUtils.findMergedAnnotation;

import com.google.gson.Gson;
import com.seatec.ela.app.exception.error.ErrorDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Customize exception handling - log the exception if desired, and return a properly formatted json
 * response to the client.
 *
 * @author alan
 */
@RestControllerAdvice
public class CustomExceptionHandler {

  Logger logger;

  @PostConstruct
  public void init() {
    logger = LoggerFactory.getLogger(CustomExceptionHandler.class);
  }

  @ExceptionHandler
  ResponseEntity<ErrorWrapperDTO> handle(Exception exception) {

    ResponseEntity<ErrorWrapperDTO> response = null;

    // if CustomException, or any subclass of it, is thrown
    if (exception instanceof CustomException) {
      if (((CustomException) exception).isLoggable) {
        if (((CustomException) exception).rootCause != null) {
          log((CustomException) exception, true);
        } else {
          log((CustomException) exception, false);
        }
      }
      // get the HTTP status code annotated on the CustomException, or if one isn't present, then
      // set to HTTP status code to INTERNAL_SERVER_ERROR as default
      ResponseStatus annotation = findMergedAnnotation(exception.getClass(), ResponseStatus.class);
      HttpStatus responseStatus =
          (annotation != null) ? annotation.value() : HttpStatus.INTERNAL_SERVER_ERROR;
      response =
          new ResponseEntity<ErrorWrapperDTO>(
              new ErrorWrapperDTO(new ErrorDTO(null, exception.getLocalizedMessage())),
              responseStatus);
    }
    // if Bean Validation annotation fails on either @PathVariable or @RequestParam
    else if (exception instanceof ConstraintViolationException) {
      List<ErrorDTO> errors = new ArrayList<ErrorDTO>();
      Set<ConstraintViolation<?>> violations =
          ((ConstraintViolationException) exception).getConstraintViolations();
      for (ConstraintViolation<?> violation : violations) {
        Iterator<?> nodes = violation.getPropertyPath().iterator();
        String fieldName = null;
        while (nodes.hasNext()) {
          fieldName = ((Path.Node) nodes.next()).getName();
        }
        errors.add(new ErrorDTO(fieldName, violation.getMessage()));
      }
      ErrorWrapperDTO body = new ErrorWrapperDTO(errors);
      response = new ResponseEntity<ErrorWrapperDTO>(body, HttpStatus.BAD_REQUEST);
      String json = new Gson().toJson(body);
      logger.warn("Input validation failed. JSON returned to the client is: " + json);
    }
    // if @Validated or @Valid fails
    else if (exception instanceof MethodArgumentNotValidException) {
      List<ErrorDTO> errors = new ArrayList<ErrorDTO>();
      for (FieldError error :
          ((MethodArgumentNotValidException) exception).getBindingResult().getFieldErrors()) {
        errors.add(new ErrorDTO(error.getField(), error.getDefaultMessage()));
      }
      for (ObjectError error :
          ((MethodArgumentNotValidException) exception).getBindingResult().getGlobalErrors()) {
        errors.add(new ErrorDTO(error.getObjectName(), error.getDefaultMessage()));
      }
      ErrorWrapperDTO body = new ErrorWrapperDTO(errors);
      response = new ResponseEntity<ErrorWrapperDTO>(body, HttpStatus.BAD_REQUEST);
      String json = new Gson().toJson(body);
      logger.warn("Input validation failed. JSON returned to the client is: " + json);
    }
    // if input JSON in request body is malformed
    else if (exception instanceof HttpMessageNotReadableException) {
      String message =
          (exception.getCause() != null)
              ? exception.getCause().getMessage()
              : exception.getLocalizedMessage();
      response =
          new ResponseEntity<ErrorWrapperDTO>(
              new ErrorWrapperDTO(
                  new ErrorDTO(null, "Failed to process input. The reason is: " + message)),
              HttpStatus.BAD_REQUEST);
      logger.warn("The input JSON in the requests body is malformed. " + message);
    }
    // if any other exception not listed above is thrown
    else {
      String message =
          (exception.getCause() != null)
              ? exception.getCause().getMessage()
              : exception.getLocalizedMessage();
      response =
          new ResponseEntity<ErrorWrapperDTO>(
              new ErrorWrapperDTO(new ErrorDTO(null, message)), HttpStatus.INTERNAL_SERVER_ERROR);
      logger.error("Uncaught exception was thrown.", exception);
    }
    return response;
  }

  private void log(CustomException exception, boolean isRootCause) {
    if (Level.WARN.equals(exception.logLevel)) {
      if (isRootCause) {
        logger.warn(exception.getLocalizedMessage(), exception.rootCause);
      } else {
        logger.warn(exception.getLocalizedMessage());
      }
    } else if (Level.INFO.equals(exception.logLevel)) {
      if (isRootCause) {
        logger.info(exception.getLocalizedMessage(), exception.rootCause);
      } else {
        logger.info(exception.getLocalizedMessage());
      }
    } else if (Level.DEBUG.equals(exception.logLevel)) {
      if (isRootCause) {
        logger.debug(exception.getLocalizedMessage(), exception.rootCause);
      } else {
        logger.debug(exception.getLocalizedMessage());
      }
    } else if (Level.TRACE.equals(exception.logLevel)) {
      if (isRootCause) {
        logger.trace(exception.getLocalizedMessage(), exception.rootCause);
      } else {
        logger.trace(exception.getLocalizedMessage());
      }
    } else {
      if (isRootCause) {
        logger.error(exception.getLocalizedMessage(), exception.rootCause);
      } else {
        logger.error(exception.getLocalizedMessage());
      }
    }
  }
}
