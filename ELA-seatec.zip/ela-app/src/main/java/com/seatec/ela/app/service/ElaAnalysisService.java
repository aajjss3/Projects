package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.AutoLandFleetConfigDto;
import com.seatec.ela.app.dto.analysis.*;
import com.seatec.ela.app.dto.analysis.AnalysisLoad.Units;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.service.contract.IEfficiencyTableService;
import com.seatec.ela.app.util.BatteryDischargeCalculation;
import com.seatec.ela.app.util.FieldValidator;
import com.seatec.ela.app.util.LoadUtil;
import com.seatec.ela.app.util.NodeUtil;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import java.util.*;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * There are 2 types of analysis performed on electrical loads. Determine these analysis loads for
 * the ELA passed in and return them. The 2 types of analysis are:
 *
 * <ul>
 *   <li>Normal Analysis
 *   <li>Degraded (also called Abnormal) Analysis
 * </ul>
 */
@Service
public class ElaAnalysisService {
  public static final String AIRBUS = "airbus";
  public static final String BOEING = "boeing";

  // flight phases where battery (not generator) is supplying load
  private static final List<String> BATTERY_SUPPLIED_FLIGHT_PHASES =
      new ArrayList<>(Arrays.asList("STANDBY", "HMG"));

  @Autowired private NodeService nodeService;

  @Autowired private FleetRepository fleetRepository;

  @Autowired private ElaRepository elaRepository;

  @Autowired private IEfficiencyTableService efficiencyTableService;

  @Autowired private LoadSummaryService loadSummaryService;

  @Autowired private AutoLandAnalysisService autoLandAnalysisService;

  @Autowired private TRUAutoLandAnalysisService truAutoLandAnalysisService;

  @Autowired private HMGAnalysisService hmgAnalysisService;

  @Autowired private TRU3OutAnalysisService tru3OutAnalysisService;

  private static final String STANDBY_OPERATION_FLIGHT_PHASE = "STANDBY";
  public static final double REQUIRED_BATTERY_LIFE_IN_MIN = 30d;
  public static final String AIRBUS_NORMAL_CALCULATION = "MAXI";
  public static final String AIRBUS_DEGRADED_CALCULATION = "OPERATIONAL";
  public static final String BOEING_NORMAL_CALCULATION = "LOAD";
  public static final String BOEING_DEGRADED_CALCULATION = "LOAD";
  public static final String BOEING_717_NORMAL_CALCULATION = "FIFTEEN_MIN";
  public static final String BOEING_717_DEGRADED_CALCULATION = "FIFTEEN_MIN";
  public static final double GENERATOR_VOLTAGE_DEFAULT_US = 115.0d;
  public static final double INVERTER_VOLTAGE_DEFAULT = 24d;
  public static final double INVERTER_RATING_DEFAULT = 1000.0;
  public static final double EFFICIENCY_FACTOR_DEFAULT = 0.95d;
  // B737-700, B737-800, B757-200, B757-200ETOPS, B757-300, B767-300, B767-400 all use 00.82
  public static final double INVERTER_EFFICIENCY = 0.82d;
  public static final double INVERTER_B777_200_EFFICIENCY = 0.85d;
  private static final String B777_200ER = "B777-200ER";
  private static final String B777_200LR = "B777-200LR";
  private static final String FUEL_JETTISON_B767_300 = "B767-300";
  private static final String FUEL_JETTISON_B767_400 = "B767-400";
  private static final double B777_RAT_CAPACITY = 216.0;
  private static final double B777_RAT_EFFICIENCY = 0.85;

  private static final List<String> HMG_FLEETS =
      Arrays.asList("B767-300", "B767-400", "B757-200ETOPS", "B757-300");

  private static Logger logger = LoggerFactory.getLogger(ElaAnalysisService.class);

  // constants used for fuel jettison
  // ---------------------------------
  // 767-300 additions without fuel jettison
  private final double takeoff767300AddWithoutInW = 13.130;
  private final double takeoff767300AddWithoutInVAR = 7.882;

  private final double cruise767300AddWithoutInW = 13.130;
  private final double cruise767300AddWithoutInVAR = 7.882;

  private final double holdLand767300AddWithoutInW = 13.130;
  private final double holdLand767300AddWithoutInVAR = 7.882;

  // 767-300 subtractions without fuel jettison
  private final double takeoff767300SubtractWithoutInW = 6.637;
  private final double takeoff767300SubtractWithoutInVAR = 2.745;

  private final double cruise767300SubtractWithoutInW = 6.888;
  private final double cruise767300SubtractWithoutInVAR = 2.786;

  private final double holdLand767300SubtractWithoutInW = 3.251;
  private final double holdLand767300SubtractWithoutInVAR = 1.297;

  // 767-300 additions with fuel jettison
  private final double takeoff767300AddWithInW = 3.496;
  private final double takeoff767300AddWithInVAR = 1.660;

  private final double cruise767300AddWithInW = 3.496;
  private final double cruise767300AddWithInVAR = 1.660;

  private final double holdLand767300AddWithInW = 3.496;
  private final double holdLand767300AddWithInVAR = 1.660;

  // 767-300 subtractions with fuel jettison
  private final double takeoff767300SubtractWithInW = 6.370;
  private final double takeoff767300SubtractWithInVAR = 2.598;

  private final double cruise767300SubtractWithInW = 6.568;
  private final double cruise767300SubtractWithInVAR = 2.598;

  private final double holdLand767300SubtractWithInW = 6.568;
  private final double holdLand767300SubtractWithInVAR = 2.598;

  // 767-400 additions without fuel jettison
  private final double takeoff767400AddWithoutInW = 11.676;
  private final double takeoff767400AddWithoutInVAR = 7.542;

  private final double cruise767400AddWithoutInW = 11.676;
  private final double cruise767400AddWithoutInVAR = 7.542;

  private final double holdLand767400AddWithoutInW = 11.676;
  private final double holdLand767400AddWithoutInVAR = 7.542;

  // 767-400 subtractions without fuel jettison
  private final double takeoff767400SubtractWithoutInW = 3.496;
  private final double takeoff767400SubtractWithoutInVAR = 1.489;

  private final double cruise767400SubtractWithoutInW = 3.496;
  private final double cruise767400SubtractWithoutInVAR = 1.489;

  private final double holdLand767400SubtractWithoutInW = 3.496;
  private final double holdLand767400SubtractWithoutInVAR = 1.489;

  // 767-400 additions with fuel jettison
  private final double takeoff767400AddWithInW = 10.488;
  private final double takeoff767400AddWithInVAR = 4.565;

  private final double cruise767400AddWithInW = 10.488;
  private final double cruise767400AddWithInVAR = 4.565;

  private final double holdLand767400AddWithInW = 10.488;
  private final double holdLand767400AddWithInVAR = 4.565;

  // 767-400 subtractions with fuel jettison
  private final double takeoff767400SubtractWithInW = 5.894;
  private final double takeoff767400SubtractWithInVAR = 3.693;

  private final double cruise767400SubtractWithInW = 5.405;
  private final double cruise767400SubtractWithInVAR = 3.313;

  private final double holdLand767400SubtractWithInW = 5.405;
  private final double holdLand767400SubtractWithInVAR = 3.313;
  // end constants used for fuel jettison

  /**
   * retrieve the analysis (normal and degraded) for the ela passed in.
   *
   * @param elaId
   * @return
   */
  @Transactional(readOnly = true)
  public Analysis getAnalysis(Long elaId) {
    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

    LoadSummaryOptions loadSummaryOptions =
        new LoadSummaryOptions(false, false, false, false, true);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<Node> topLevelNodesWithSummarizedLoads =
        nodeService.hydrateNodes(elaId, loadSummaryRequest);

    // get the complete list of nodes. each node contains a collection of summarized loads.
    List<Node> allNodesWithSummarizedLoads =
        NodeUtil.flattenNodeTrees(topLevelNodesWithSummarizedLoads);

    Fleet fleet = fleetRepository.findByElaId(elaId);

    Analysis analysis = getNormalAndDegradedAnalysis(allNodesWithSummarizedLoads, fleet, false);

    // if the analysis is for Boeing, then also perform a standby operation analysis on the battery
    if (fleet.getManufacturer().equalsIgnoreCase(BOEING)) {
      updateStaticInverterAndStandbyOperation(elaId, allNodesWithSummarizedLoads, fleet, analysis);

      // if the Boeing fleet is an HMG fleet then also perform HMG analysis
      if (HMG_FLEETS.contains(fleet.getName())) {
        updateHMGAnalysis(elaId, analysis);
      }
    }

    // if the analysis is for B767, B757, B757ETOPS, B737 then also perform auto land analysis
    String autoLandCalculationType = getAutoLandCalculationType(fleet.getName());
    if (autoLandCalculationType != null) {
      setAutoLandAnalysis(
          autoLandCalculationType, elaId, allNodesWithSummarizedLoads, fleet, analysis);
    }

    // if the fleet is Boeing 737 then also perform `TRU3 Out` analysis
    if (fleet.getName().startsWith("B737")) {
      tru3OutAnalysisService.setTRU3OutAnalysis(analysis, allNodesWithSummarizedLoads, elaId);
    }

    return analysis;
  }

  public void updateHMGAnalysis(long elaId, Analysis analysis) {

    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();
    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, false, false, false, true);

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<Node> topLevelNodesWithSummarizedLoads =
        nodeService.hydrateNodes(elaId, loadSummaryRequest);

    // get the complete list of nodes. each node contains a collection of summarized loads.
    List<Node> allNodesWithSummarizedLoads =
        NodeUtil.flattenNodeTrees(topLevelNodesWithSummarizedLoads);

    Optional<HMGAnalysis> result =
        hmgAnalysisService.calculate(allNodesWithSummarizedLoads, analysis);
    if (result.isPresent()) {
      HMGAnalysis hmgAnalysis = result.get();

      AnalysisType degradedAnalysis = analysis.getDegradedAnalysis();
      degradedAnalysis.addHmgAnalysis(hmgAnalysis);
      AnalysisStatus degradedStatus =
          getWorstCaseStatus(analysis.getDegradedStatus(), hmgAnalysis.getDcStatus());
      degradedStatus = getWorstCaseStatus(degradedStatus, hmgAnalysis.getAcStatus());
      analysis.setDegradedStatus(degradedStatus);
    }
  }

  public void updateStaticInverterAndStandbyOperation(
      Long elaId, List<Node> allNodesWithSummarizedLoads, Fleet fleet, Analysis analysis) {
    StandbyOperation standbyOperationAnalysis = new StandbyOperation();
    StaticInverter staticInverterAnalysis = new StaticInverter();
    calculateStaticInverterAndStandbyOperation(
        elaId,
        allNodesWithSummarizedLoads,
        staticInverterAnalysis,
        standbyOperationAnalysis,
        fleet,
        analysis.getThresholdLowerLimit(),
        analysis.getThresholdUpperLimit());

    analysis.setStandbyOperation(standbyOperationAnalysis);
    AnalysisType degradedAnalysis = analysis.getDegradedAnalysis();
    degradedAnalysis.addStaticInverterAnalysis(staticInverterAnalysis);

    AnalysisStatus degradedStatus =
        getWorstCaseStatus(analysis.getDegradedStatus(), staticInverterAnalysis.getStatus());
    analysis.setDegradedStatus(degradedStatus);

    analysis.setDegradedAnalysis(degradedAnalysis);
  }

  public static String getAutoLandCalculationType(String fleetName) {
    if (fleetName.startsWith("B767") || fleetName.startsWith("B757")) {
      return "BATTERY";
    } else if (fleetName.startsWith("B737")) {
      return "TRU";
    } else {
      return null;
    }
  }

  /**
   * Calculate the aircraft batteries standby operation analysis. Currently this is only performed
   * on Boeing aircraft (@see BatteryDischargeCalculation class).
   *
   * @param elaId
   * @param nodes
   * @param standbyOperationAnalysis
   * @param staticInverterAnalysis
   * @return
   */
  public void calculateStaticInverterAndStandbyOperation(
      Long elaId,
      List<Node> nodes,
      StaticInverter staticInverterAnalysis,
      StandbyOperation standbyOperationAnalysis,
      Fleet fleet,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {
    Ela ela =
        elaRepository
            .findById(elaId)
            .orElseThrow(
                () -> new NotFoundException("Unable to find the ela : " + elaId, Level.ERROR));

    Aircraft aircraft = ela.getAircraft();
    if (aircraft == null) {
      throw new NotFoundException(
          "Unable to find an aircraft for the ela id of: " + elaId, Level.ERROR);
    }
    if (aircraft.getBatteryCharge() == null) {
      throw new NotFoundException(
          "Unable to find a battery type for the aircraft: " + aircraft.getAircraftShipNo(),
          Level.ERROR);
    }

    // determine the generators voltage - used to determine if a single phase AC load should be
    // adjusted by a transformers efficiency factor.
    // only single phase AC loads assigned to a Bus whose voltage is not equal to the generators
    // voltage should be adjusted by the
    // transformer efficiency factor.
    Double generatorVoltage =
        GENERATOR_VOLTAGE_DEFAULT_US; // in volts. in US this will be 115, for europe it will be
    // 220.
    Node generatorNode =
        nodes.stream()
            .filter(n -> n.getNodeType() == NodeType.GENERATOR && !n.getSubNodes().isEmpty())
            .findFirst()
            .orElse(null);
    if (generatorNode != null) {
      generatorVoltage = generatorNode.getVoltage();
    }

    double inverterVoltage = INVERTER_VOLTAGE_DEFAULT; // in volts. default to 24 volts
    double inverterRatingVA = INVERTER_RATING_DEFAULT; // in va, default to 1000 va
    UUID efficiencyTableId = null;
    // buckets to hold aggregate loads.
    double aggregateDCinAmp = 0d,
        aggregateACNeedsAdjusinginVar = 0d,
        aggregateACNeedsAdjusinginWatt = 0d,
        aggregateACNoAdjustinginWatt = 0d,
        aggregateACNoAdjustinginVar = 0d;

    for (Node node : nodes) {
      // only BUS nodes have loads directly associated with them.
      if (node.getNodeType() == NodeType.BUS) {
        for (Component component : node.getComponents()) {
          for (Load load : component.getLoads()) {
            if (load.getFlightPhase().equalsIgnoreCase(STANDBY_OPERATION_FLIGHT_PHASE)
                && load.getOperatingMode()
                    .equalsIgnoreCase(getDegradedCalculationOperatingMode(aircraft.getFleet()))) {
              if (node.getVoltageType() == ElectricalPhase.DC) {
                aggregateDCinAmp += load.getVa() / node.getVoltage();
              } else if (node.getVoltageType() == ElectricalPhase.AC) { // single phase AC
                if (node.getVoltage().doubleValue() == generatorVoltage.doubleValue()) {
                  aggregateACNoAdjustinginVar +=
                      LoadUtil.getVar(load.getVa(), load.getPowerFactor());
                  aggregateACNoAdjustinginWatt +=
                      LoadUtil.getW(load.getVa(), load.getPowerFactor());
                } else {
                  aggregateACNeedsAdjusinginVar +=
                      LoadUtil.getVar(load.getVa(), load.getPowerFactor());
                  aggregateACNeedsAdjusinginWatt +=
                      LoadUtil.getW(load.getVa(), load.getPowerFactor());
                }
              } else if (node.getVoltageType() == ElectricalPhase.AC3) { // three phase AC
                aggregateACNoAdjustinginWatt += LoadUtil.getW(load.getVa(), load.getPowerFactor());
                aggregateACNoAdjustinginVar += LoadUtil.getVar(load.getVa(), load.getPowerFactor());
              }
            }
          }
        }
      } else if (node.getNodeType() == NodeType.INVERTER) {
        // used to convert watts to amps
        inverterVoltage = node.getVoltage();
        inverterRatingVA = node.getNominalPower();
      } else if (node.getNodeType() == NodeType.ATU) {
        // used to determine the efficiency factor
        efficiencyTableId = node.getEfficiencyTable().getId();
      }
    }

    // adjust the single phase AC loads that require adjusting by the ATU transformer efficiency
    double efficiencyFactor = EFFICIENCY_FACTOR_DEFAULT; // default to .95
    if (efficiencyTableId != null) {
      double aggregateACNeedsAdjustinginVA =
          LoadUtil.getVa(aggregateACNeedsAdjusinginWatt, aggregateACNeedsAdjusinginVar);

      Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

      EfficiencyLoad efficiencyLoad =
          loadSummaryService.retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
              "standby operation",
              NodeType.ATU,
              aggregateACNeedsAdjustinginVA,
              efficiencyTableId,
              efficiencyTableMap);
      if (efficiencyLoad != null) {
        efficiencyFactor = efficiencyLoad.getExPF();
      }
    }

    double inverterEfficiency = INVERTER_EFFICIENCY;
    boolean addRatData = false;
    if ((B777_200ER.equalsIgnoreCase(fleet.getName())
        || B777_200LR.equalsIgnoreCase(fleet.getName()))) {
      inverterEfficiency = INVERTER_B777_200_EFFICIENCY;
      addRatData = true;
    }

    double totalWatts =
        (aggregateACNeedsAdjusinginWatt / efficiencyFactor) + aggregateACNoAdjustinginWatt;
    double totalVar =
        (aggregateACNeedsAdjusinginVar / efficiencyFactor) + aggregateACNoAdjustinginVar;
    double aggregateACTotalInKVA = LoadUtil.getVa(totalWatts / 1000, totalVar / 1000);

    double totalStaticInverterLoadInAmps = totalWatts / inverterVoltage / inverterEfficiency;

    staticInverterAnalysis.setMaxLoadInKVA(inverterRatingVA / 1000);
    staticInverterAnalysis.setTotalLoadInKVA(aggregateACTotalInKVA);
    staticInverterAnalysis.setTotalLoadInAmps(totalStaticInverterLoadInAmps);
    double percentageStaticInverterKVA = 100d * (aggregateACTotalInKVA / (inverterRatingVA / 1000));
    staticInverterAnalysis.setPercentKVAUsed(percentageStaticInverterKVA);
    AnalysisStatus staticInverterStatus =
        determineStatus(percentageStaticInverterKVA, thresholdLowerLimit, thresholdUpperLimit);
    staticInverterAnalysis.setStatus(staticInverterStatus);

    double totalLoadInAmps = totalStaticInverterLoadInAmps + aggregateDCinAmp;
    standbyOperationAnalysis.setBatteryCapacity(aircraft.getBatteryCharge());
    standbyOperationAnalysis.setTotalLoadInAmps(totalLoadInAmps);

    // if a Single 75 AH battery then there is no battery discharge calculation, its just a straight
    // percentage.
    // for any other battery type there is a battery discharge calculation.
    if (aircraft.getBatteryCharge() == BatteryChargeType.SINGLE_75AH) {
      Double single75Amp = 75d;
      standbyOperationAnalysis.setMaxBatteryLoad(single75Amp);
      standbyOperationAnalysis.setPercentAmpsUsed((totalLoadInAmps / single75Amp) * 100d);
      AnalysisStatus batteryStatus =
          (totalLoadInAmps <= single75Amp ? AnalysisStatus.PASS : AnalysisStatus.FAIL);
      standbyOperationAnalysis.setBatteryStatus(batteryStatus);
      standbyOperationAnalysis.setStatus(batteryStatus);
    } else {
      Double calculatedBatteryLife =
          BatteryDischargeCalculation.boeingEquation(aircraft.getBatteryCharge(), totalLoadInAmps);
      standbyOperationAnalysis.setActualBatteryLifeInMinutes(calculatedBatteryLife);
      standbyOperationAnalysis.setRequiredBatteryLifeInMinutes(REQUIRED_BATTERY_LIFE_IN_MIN);
      AnalysisStatus batteryStatus =
          (calculatedBatteryLife > REQUIRED_BATTERY_LIFE_IN_MIN)
              ? AnalysisStatus.PASS
              : AnalysisStatus.FAIL;
      standbyOperationAnalysis.setBatteryStatus(batteryStatus);
      standbyOperationAnalysis.setStatus(batteryStatus);
    }

    if (addRatData) {
      standbyOperationAnalysis.setRatCapacity(B777_RAT_CAPACITY);
      standbyOperationAnalysis.setRatAdjustedCapacity(B777_RAT_CAPACITY * B777_RAT_EFFICIENCY);
      standbyOperationAnalysis.setRatEfficiency(B777_RAT_EFFICIENCY);
      standbyOperationAnalysis.setRatLoadInAmps(totalLoadInAmps);
      double percentageRatAmps =
          totalLoadInAmps / standbyOperationAnalysis.getRatAdjustedCapacity() * 100.0d;
      AnalysisStatus ratStandbyStatus =
          determineStatus(percentageRatAmps, thresholdLowerLimit, thresholdUpperLimit);
      standbyOperationAnalysis.setRatStatus(ratStandbyStatus);
      standbyOperationAnalysis.setStatus(
          getWorstCaseStatus(
              standbyOperationAnalysis.getBatteryStatus(),
              standbyOperationAnalysis.getRatStatus()));
    }
  }

  /**
   * Determine the normal and degraded analysis for the nodes passed in (these nodes belong to a
   * single ela)
   *
   * @param nodesWithAllSummarizedLoads - the nodes to run analysis against.
   * @param fleet - the fleet the ela belongs to.
   * @param isSummary - if the analysis should include AnalysisLoad's then 'false'. if the analysis
   *     should not include AnalysisLoad's then 'true'.
   * @return Analysis DTO
   */
  public Analysis getNormalAndDegradedAnalysis(
      List<Node> nodesWithAllSummarizedLoads, Fleet fleet, boolean isSummary) {
    Analysis analysis = new Analysis();
    setNormalAnalysisNodes(
        nodesWithAllSummarizedLoads,
        analysis,
        fleet,
        isSummary,
        analysis.getThresholdLowerLimit(),
        analysis.getThresholdUpperLimit());
    setDegradedAnalysis(
        nodesWithAllSummarizedLoads,
        analysis,
        fleet,
        isSummary,
        analysis.getThresholdLowerLimit(),
        analysis.getThresholdUpperLimit());
    return analysis;
  }

  /**
   * determine the degraded analysis for the nodes passed in and set it on the analysis object
   * passed in. Degraded analysis is only performed on essential loads, not sheddable loads. Only
   * perform degraded analysis on generators and tru transformers. On a summarizedload object, the
   * fields 'valEssentialLoad' and 'originalValEssentialLoad' contain the aggregate of only
   * essential loads. First aggregate all similar nodes by combining all generator nodes and tru
   * transformer nodes into separate buckets. Need to aggregate all similar loads first for the
   * degraded analysis logic. Only perform an analysis on a node if it contains a valid nominal
   * power (ie. node.nominalPower is > 0). Also, if its a TRU transformer, then only perform an
   * analysis on it if its considered a 'Normal' transformer (ie. Node.normalTr == true) or if the
   * Manufacturer is BOEING.
   *
   * @param nodes
   * @param analysis
   * @param fleet
   * @param isSummary - if the analysis should include AnalysisLoad's then 'false'. if the analysis
   *     should not include AnalysisLoad's then 'true'.
   * @param thresholdLowerLimit - used to determine analysis status
   * @param thresholdUpperLimit - used to determine analysis status
   */
  private void setDegradedAnalysis(
      List<Node> nodes,
      Analysis analysis,
      Fleet fleet,
      boolean isSummary,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {

    Set<Node> truTransformers = new HashSet<>();
    Set<Node> generators = new HashSet<>();

    // separate nodes into TRU and GENERATOR buckets
    for (Node node : nodes) {
      if (node.getNodeType() == NodeType.TRU) {
        if (FieldValidator.isDoubleGreaterZero(node.getNominalPower())
            && (node.isNormalTr() || BOEING.equalsIgnoreCase(fleet.getManufacturer()))) {
          truTransformers.add(node);
        }
      } else if (node.getNodeType() == NodeType.GENERATOR) {
        if (FieldValidator.isDoubleGreaterZero(node.getNominalPower())) {
          generators.add(node);
        }
      }
    }

    AnalysisStatus generatorStatus =
        setDegradedAnalysisNodes(
            generators,
            analysis,
            NodeType.GENERATOR,
            fleet,
            isSummary,
            thresholdLowerLimit,
            thresholdUpperLimit);

    AnalysisStatus truStatus =
        setDegradedAnalysisNodes(
            truTransformers,
            analysis,
            NodeType.TRU,
            fleet,
            isSummary,
            thresholdLowerLimit,
            thresholdUpperLimit);

    // set the rolled up degraded status
    if (generatorStatus == AnalysisStatus.FAIL || truStatus == AnalysisStatus.FAIL) {
      analysis.setDegradedStatus(AnalysisStatus.FAIL);
    } else if (generatorStatus == AnalysisStatus.WARN || truStatus == AnalysisStatus.WARN) {
      analysis.setDegradedStatus(AnalysisStatus.WARN);
    } else {
      analysis.setDegradedStatus(AnalysisStatus.PASS);
    }

    Collections.sort(analysis.getDegradedAnalysis().getTruNodes());
    Collections.sort(analysis.getDegradedAnalysis().getGeneratorNodes());
  }

  /**
   * Set the degraded analysis for TRU transformers and generators. The collection of nodes passed
   * in are all one type (ie. all TRU transformers or all Generators). Loop thru all nodes passed in
   * and assume each one fails one at a time. then split and add the loads of the failed nodes to
   * the other (working) nodes load by matching similar flight phase and electrical phase. Then
   * create an AnalysisLoad to hold that analysis load data.
   *
   * @param nodes - either ATU transformers nodes or generator nodes
   * @param analysis
   * @param nodeType
   * @param isSummary - if the analysis should include AnalysisLoad's then 'false'. if the analysis
   *     should not include AnalysisLoad's then 'true'
   * @param thresholdLowerLimit - used to determine analysis status
   * @param thresholdUpperLimit - used to determine analysis status
   * @return overall worst case analysis status of all the nodes passed in
   */
  private AnalysisStatus setDegradedAnalysisNodes(
      Set<Node> nodes,
      Analysis analysis,
      NodeType nodeType,
      Fleet fleet,
      boolean isSummary,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {

    AnalysisStatus degradedStatus = AnalysisStatus.PASS; // set default value

    // create an AnalysisNode for each node and group by node type(GENERATOR or TRU). Degraded
    // Analysis is not performed on a BUS or an ATU transformer.
    // loop thru all nodes and assume each one fails one at a time
    for (Node failedNode : nodes) {
      if (nodeType == NodeType.GENERATOR) {
        analysis
            .getDegradedAnalysis()
            .addGeneratorNode(
                new AnalysisNode(
                    failedNode.getId(),
                    failedNode.getNominalPower() / 1000d,
                    failedNode.getName()));
      } else if (nodeType == NodeType.TRU) {
        // the total degraded nominal power is equal to the sum of nominal power of all transformers
        // minus the nominal power of the failed transformer.
        double totalNominalPower =
            nodes.stream().collect(Collectors.summingDouble(Node::getNominalPower))
                - failedNode.getNominalPower();
        AnalysisNode failedAnalysisNode =
            new AnalysisNode(failedNode.getId(), totalNominalPower, failedNode.getName());
        analysis.getDegradedAnalysis().addTruNode(failedAnalysisNode);

        Set<String> flightPhases = getFlightPhasesFromSummarizedLoads(failedNode);

        setTRUDegradedAnalysisLoads(
            flightPhases,
            nodes,
            failedAnalysisNode,
            fleet,
            totalNominalPower,
            thresholdLowerLimit,
            thresholdUpperLimit);
        degradedStatus = getWorstCaseStatus(degradedStatus, failedAnalysisNode.getStatus());
      }
    }

    int numberTotalNodes = nodes.size();
    if (numberTotalNodes >= 2) {

      // loop thru each node and assume it fails.
      for (Node failedNode : nodes) {
        Set<ElectricalPhase> failedElectricalPhases =
            failedNode.getSummarizedLoads().stream()
                .map(SummarizedLoad::getElectricalPhase)
                .collect(Collectors.toSet());

        Set<String> failedFlightPhases = getFlightPhasesFromSummarizedLoads(failedNode);

        // all other nodes (beside the failed node) are considered operating/working nodes
        // (generators or transformers).
        Set<Node> operatingNodes =
            nodes.stream()
                .filter(node -> !node.getId().equals(failedNode.getId()))
                .collect(Collectors.toSet());

        for (Node operatingNode : operatingNodes) {
          AnalysisNode analysisNode = null;
          if (nodeType == NodeType.GENERATOR) {
            analysisNode =
                analysis.getDegradedAnalysis().getGeneratorNodes().stream()
                    .filter(node -> node.getNodeId().equals(operatingNode.getId()))
                    .findFirst()
                    .orElse(null);
          }

          if (analysisNode != null) {
            // degraded generator rating is the sum of all the individual generator ratings minus
            // the rating of the failed generator.
            double degradedGeneratorRating =
                analysis.getDegradedAnalysis().getGeneratorNodes().stream()
                        .collect(Collectors.summingDouble(AnalysisNode::getRating))
                    - analysisNode.getRating();

            setGeneratorDegradedAnalysisLoads(
                failedElectricalPhases,
                failedFlightPhases,
                analysisNode,
                analysisNode.getRating(),
                failedNode,
                operatingNode,
                (double) numberTotalNodes - 1d,
                nodeType,
                fleet,
                isSummary,
                thresholdLowerLimit,
                thresholdUpperLimit,
                analysis,
                degradedGeneratorRating);

            // determine the degraded analysis status which is the worst case status between this
            // node and previous nodes.
            degradedStatus = getWorstCaseStatus(degradedStatus, analysisNode.getStatus());
          }
        }
      }
    }
    return degradedStatus;
  }

  private void setTRUDegradedAnalysisLoads(
      Set<String> flightPhases,
      Set<Node> allTRUNodes,
      AnalysisNode failedAnalysisNode,
      Fleet fleet,
      double totalNominalPower,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {

    AnalysisStatus status = AnalysisStatus.PASS; // default to pass
    String degradedCalculationOperatingMode = getDegradedCalculationOperatingMode(fleet);

    for (String flightPhase : flightPhases) {
      double totalLoad = 0d;

      for (Node node : allTRUNodes) {
        List<SummarizedLoad> summarizedLoads =
            node.getSummarizedLoads().stream()
                .filter(
                    load ->
                        load.getOperatingMode().equalsIgnoreCase(degradedCalculationOperatingMode)
                            && load.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN
                            && load.getFlightPhase().equalsIgnoreCase(flightPhase))
                .collect(Collectors.toList());

        totalLoad +=
            (summarizedLoads.stream()
                    .collect(Collectors.summingDouble(SummarizedLoad::getOriginalWEssentialLoad)))
                / node.getInlineVoltage();
      }

      double result = (totalLoad / totalNominalPower) * 100d;
      failedAnalysisNode.addAnalysisLoad(
          new AnalysisLoad(result, flightPhase, totalLoad, "TOTAL", Units.AMPS));
      status = getWorstCaseStatusForLoads(status, result, thresholdUpperLimit, thresholdLowerLimit);
    }

    failedAnalysisNode.setStatus(status);
  }

  /**
   * set the degraded analysis loads. divide the failed node's load by the number of working nodes
   * and then add that load to all the matching working nodes load. (by matching the electrical
   * phase and flight phase). The degraded analysis load is the value located on
   * SummarizedLoad.valDegradedAnalysis and SummarizedLoad.originalValDegradedAnalysis
   *
   * @param failedElectricalPhases
   * @param failedFlightPhases
   * @param analysisNode
   * @param nominalPower
   * @param failedNode
   * @param operatingNode
   * @param numberWorkingNodes
   * @param nodeType
   * @param fleet the fleet for this ELA
   * @param isSummary - if the analysis should include AnalysisLoad's then 'false'. if the analysis
   *     should not include AnalysisLoad's then 'true'
   */
  private void setGeneratorDegradedAnalysisLoads(
      Set<ElectricalPhase> failedElectricalPhases,
      Set<String> failedFlightPhases,
      AnalysisNode analysisNode,
      Double nominalPower,
      Node failedNode,
      Node operatingNode,
      double numberWorkingNodes,
      NodeType nodeType,
      Fleet fleet,
      boolean isSummary,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit,
      Analysis analysis,
      double degradedGeneratorRating) {

    AnalysisStatus status = AnalysisStatus.PASS; // default to pass

    for (ElectricalPhase failedElectricalPhase : failedElectricalPhases) {
      for (String failedFlightPhase : failedFlightPhases) {
        SummarizedLoad failedNodeLoad =
            getSummarizedLoadForDegradedAnalysis(
                failedNode.getSummarizedLoads(), failedElectricalPhase, failedFlightPhase, fleet);
        SummarizedLoad operatingNodeLoad =
            getSummarizedLoadForDegradedAnalysis(
                operatingNode.getSummarizedLoads(),
                failedElectricalPhase,
                failedFlightPhase,
                fleet);
        if (operatingNodeLoad != null && failedNodeLoad != null) {
          Double valueDegradedAnalysisVa = 0d;
          double resultDegradedAnalysis = 0d;

          if (nodeType == NodeType.GENERATOR) {
            // operatingNode
            double wOperatingNode = operatingNodeLoad.getwEssentialLoad();
            double vaOperatingNode = operatingNodeLoad.getVarEssentialLoad();

            // convert to KVA
            double sumOperatingNode = LoadUtil.getVa(wOperatingNode, vaOperatingNode);

            // failedNode
            double wFailedNode = failedNodeLoad.getwEssentialLoad();
            double vaFailedNode = failedNodeLoad.getVarEssentialLoad();

            // convert to KVA
            double sumFailedNode = LoadUtil.getVa(wFailedNode, vaFailedNode);

            valueDegradedAnalysisVa =
                (sumOperatingNode + (sumFailedNode / numberWorkingNodes)) / 1000d;
            // divide by 3 because we're grouping by A/B/C phases
            resultDegradedAnalysis =
                nominalPower == null || nominalPower == 0d
                    ? 0
                    : valueDegradedAnalysisVa / (nominalPower / 3);
          } else if (nodeType == NodeType.TRU
              && FieldValidator.isDoubleGreaterZero(failedNode.getInlineVoltage())) {
            valueDegradedAnalysisVa =
                (operatingNodeLoad.getOriginalWEssentialLoad()
                        + (failedNodeLoad.getOriginalWEssentialLoad() / numberWorkingNodes))
                    / failedNode.getInlineVoltage();
            resultDegradedAnalysis =
                nominalPower == null || nominalPower == 0d
                    ? 0
                    : valueDegradedAnalysisVa / nominalPower;
          }

          if (!isSummary) {
            analysisNode.addAnalysisLoad(
                new AnalysisLoad(
                    resultDegradedAnalysis * 100d,
                    failedFlightPhase,
                    valueDegradedAnalysisVa,
                    failedElectricalPhase.name(),
                    Units.KVA));
          }

          // determine the nodes analysis status which is the worst case status between this load
          // and previous loads.
          status =
              getWorstCaseStatusForLoads(
                  status, resultDegradedAnalysis * 100d, thresholdUpperLimit, thresholdLowerLimit);
        }
      }
    }

    // if a generator AND not summary then create additional psuedo
    // AnalysisLoad objects containing the total load value for a flight phase.
    if (!isSummary && nodeType == NodeType.GENERATOR) {
      for (String flightPhase : failedFlightPhases) {
        List<SummarizedLoad> failedNodeLoads =
            failedNode.getSummarizedLoads().stream()
                .filter(
                    load ->
                        load.getOperatingMode()
                                .equalsIgnoreCase(getDegradedCalculationOperatingMode(fleet))
                            && load.getFlightPhase().equalsIgnoreCase(flightPhase)
                            && (load.getElectricalPhase() == ElectricalPhase.ACA
                                || load.getElectricalPhase() == ElectricalPhase.ACB
                                || load.getElectricalPhase() == ElectricalPhase.ACC))
                .collect(Collectors.toList());

        List<SummarizedLoad> operatingNodeLoads =
            operatingNode.getSummarizedLoads().stream()
                .filter(
                    load ->
                        load.getOperatingMode()
                                .equalsIgnoreCase(getDegradedCalculationOperatingMode(fleet))
                            && load.getFlightPhase().equalsIgnoreCase(flightPhase)
                            && (load.getElectricalPhase() == ElectricalPhase.ACA
                                || load.getElectricalPhase() == ElectricalPhase.ACB
                                || load.getElectricalPhase() == ElectricalPhase.ACC))
                .collect(Collectors.toList());

        if (!operatingNodeLoads.isEmpty() && !failedNodeLoads.isEmpty()) {
          double valueDegradedAnalysisVa;
          double resultDegradedAnalysis;

          double sumWattsOperatingNode =
              operatingNodeLoads.stream()
                  .filter(sl -> sl.getwEssentialLoad() != null)
                  .mapToDouble(SummarizedLoad::getwEssentialLoad)
                  .sum();
          double sumVarsOperatingNode =
              operatingNodeLoads.stream()
                  .filter(sl -> sl.getVarEssentialLoad() != null)
                  .mapToDouble(SummarizedLoad::getVarEssentialLoad)
                  .sum();

          // convert to KVA
          double sumOperatingNodesVa =
              LoadUtil.getVa(sumWattsOperatingNode, sumVarsOperatingNode) / 1000d;

          double sumWattsFailedNode =
              failedNodeLoads.stream()
                  .filter(sl -> sl.getwEssentialLoad() != null)
                  .mapToDouble(SummarizedLoad::getwEssentialLoad)
                  .sum();
          double sumVarsFailedNode =
              failedNodeLoads.stream()
                  .filter(sl -> sl.getVarEssentialLoad() != null)
                  .mapToDouble(SummarizedLoad::getVarEssentialLoad)
                  .sum();

          // convert to KVA
          double sumFailedNodesVa = LoadUtil.getVa(sumWattsFailedNode, sumVarsFailedNode) / 1000d;

          valueDegradedAnalysisVa =
              (numberWorkingNodes == 0)
                  ? sumOperatingNodesVa
                  : sumOperatingNodesVa + (sumFailedNodesVa / numberWorkingNodes);
          // NOTE: do not divide by 3 because we're summarizing all phases

          // calculate the ratio of valueDegradedAnalysisVa divided by generators nominal power
          resultDegradedAnalysis =
              nominalPower == null || nominalPower == 0d
                  ? 0
                  : valueDegradedAnalysisVa / nominalPower;

          // add "TOTAL" flightPhase - this is a sum of the generators loads by flight phase.
          // store it with an electrical phase value of 'TOTAL'
          // NOTE: determine an overall effective power factor based on the total load, its
          // used for Boeing's fuel jettison analysis calculated below.
          double sumWatts =
              (numberWorkingNodes == 0)
                  ? sumWattsOperatingNode
                  : sumWattsOperatingNode + (sumWattsFailedNode / numberWorkingNodes);
          double sumVars =
              (numberWorkingNodes == 0)
                  ? sumVarsOperatingNode
                  : sumVarsOperatingNode + (sumVarsFailedNode / numberWorkingNodes);
          double powerFactor = LoadUtil.getPowerFactor(sumWatts, sumVars);
          analysisNode.addAnalysisLoad(
              new AnalysisLoad(
                  resultDegradedAnalysis * 100d,
                  flightPhase,
                  valueDegradedAnalysisVa,
                  "TOTAL",
                  Units.KVA,
                  powerFactor));
        }
      }

      // For Boeing fleets 767-300 and 767-400 perform an additional fuel jettison analysis on each
      // generator node and its loads
      if ((FUEL_JETTISON_B767_300.equalsIgnoreCase(fleet.getName())
          || FUEL_JETTISON_B767_400.equalsIgnoreCase(fleet.getName()))) {
        AnalysisStatus jettisionStatus =
            setFuelJettisonAnalysis(
                fleet.getName(),
                analysis.getDegradedAnalysis(),
                analysisNode,
                thresholdLowerLimit,
                thresholdUpperLimit,
                degradedGeneratorRating);
        status = getWorstCaseStatus(status, jettisionStatus);
      }
    }

    analysisNode.setStatus(status);
  }

  /**
   * perform fuel jettison analysis. Fuel jettison only applies to Boeing 767-300 and 767-400 fleets
   * and only to flight phases; take-off, cruise, and hold/land. Only watts and vars can be summed
   * (added and subtracted), va values can NOT be summed. so convert all va values to watts and vars
   * before performing any calculations.
   *
   * <p>See the JIRA EPP-1275 for an explanation of the constant numbers used in this calculation
   *
   * @param fleet
   * @param analysisType
   * @param node
   * @return
   */
  private AnalysisStatus setFuelJettisonAnalysis(
      String fleet,
      AnalysisType analysisType,
      AnalysisNode node,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit,
      double degradedGeneratorRating) {

    AnalysisStatus status = AnalysisStatus.PASS;

    FuelJettisonGenerator fuelJettisonGenerator = new FuelJettisonGenerator();
    fuelJettisonGenerator.setGeneratorStatus(AnalysisStatus.PASS); // default to pass
    fuelJettisonGenerator.setWithJettisonStatus(AnalysisStatus.PASS); // default to pass
    fuelJettisonGenerator.setWithoutJettisonStatus(AnalysisStatus.PASS); // default to pass
    fuelJettisonGenerator.setGeneratorName(node.getName());
    fuelJettisonGenerator.setRating(node.getRating());
    analysisType.addFuelJettisonGenerator(fuelJettisonGenerator);

    for (AnalysisLoad load : node.getAnalysisLoads()) {
      if ("TOTAL".equalsIgnoreCase(load.getElectricalPhase())
          && (("CRUISE".equalsIgnoreCase(load.getFlightPhase())
              || "TAKEOFF_CLIMB".equalsIgnoreCase(load.getFlightPhase())
              || "HOLD_LAND".equalsIgnoreCase(load.getFlightPhase())))) {

        FuelJettisonLoad fuelJettisonLoad = new FuelJettisonLoad();
        fuelJettisonLoad.setFlightPhase(load.getFlightPhase());

        double totalGeneratorLoadVar = LoadUtil.getVar(load.getValue(), load.getPowerFactor());
        double totalGeneratorLoadW = LoadUtil.getW(load.getValue(), load.getPowerFactor());

        double loadWithoutJettisonW = 0d,
            loadWithoutJettisonVar = 0d,
            loadWithJettisonW = 0d,
            loadWithJettisonVar = 0d;

        if (fleet.equalsIgnoreCase(FUEL_JETTISON_B767_300)) {

          switch (load.getFlightPhase()) {
            case "TAKEOFF_CLIMB":
              loadWithoutJettisonW =
                  totalGeneratorLoadW
                      + takeoff767300AddWithoutInW
                      - takeoff767300SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + takeoff767300AddWithoutInVAR
                      - takeoff767300SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + takeoff767300AddWithInW - takeoff767300SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar
                      + takeoff767300AddWithInVAR
                      - takeoff767300SubtractWithInVAR;
              break;
            case "CRUISE":
              loadWithoutJettisonW =
                  totalGeneratorLoadW + cruise767300AddWithoutInW - cruise767300SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + cruise767300AddWithoutInVAR
                      - cruise767300SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + cruise767300AddWithInW - cruise767300SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar + cruise767300AddWithInVAR - cruise767300SubtractWithInVAR;
              break;
            case "HOLD_LAND":
              loadWithoutJettisonW =
                  totalGeneratorLoadW
                      + holdLand767300AddWithoutInW
                      - holdLand767300SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + holdLand767300AddWithoutInVAR
                      - holdLand767300SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + holdLand767300AddWithInW - holdLand767300SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar
                      + holdLand767300AddWithInVAR
                      - holdLand767300SubtractWithInVAR;
              break;
          }
        } else if (fleet.equalsIgnoreCase(FUEL_JETTISON_B767_400)) {
          switch (load.getFlightPhase()) {
            case "TAKEOFF_CLIMB":
              loadWithoutJettisonW =
                  totalGeneratorLoadW
                      + takeoff767400AddWithoutInW
                      - takeoff767400SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + takeoff767400AddWithoutInVAR
                      - takeoff767400SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + takeoff767400AddWithInW - takeoff767400SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar
                      + takeoff767400AddWithInVAR
                      - takeoff767400SubtractWithInVAR;
              break;
            case "CRUISE":
              loadWithoutJettisonW =
                  totalGeneratorLoadW + cruise767400AddWithoutInW - cruise767400SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + cruise767400AddWithoutInVAR
                      - cruise767400SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + cruise767400AddWithInW - cruise767400SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar + cruise767400AddWithInVAR - cruise767400SubtractWithInVAR;
              break;
            case "HOLD_LAND":
              loadWithoutJettisonW =
                  totalGeneratorLoadW
                      + holdLand767400AddWithoutInW
                      - holdLand767400SubtractWithoutInW;
              loadWithoutJettisonVar =
                  totalGeneratorLoadVar
                      + holdLand767400AddWithoutInVAR
                      - holdLand767400SubtractWithoutInVAR;

              loadWithJettisonW =
                  loadWithoutJettisonW + holdLand767400AddWithInW - holdLand767400SubtractWithInW;
              loadWithJettisonVar =
                  loadWithoutJettisonVar
                      + holdLand767400AddWithInVAR
                      - holdLand767400SubtractWithInVAR;
              break;
          }
        }

        double loadWithJettison = LoadUtil.getVa(loadWithJettisonW, loadWithJettisonVar);
        double loadWithoutJettison = LoadUtil.getVa(loadWithoutJettisonW, loadWithoutJettisonVar);

        fuelJettisonLoad.setLoadWithJettison(loadWithJettison);
        fuelJettisonLoad.setLoadWithoutJettison(loadWithoutJettison);
        double percentageWithJettison = 100d * (loadWithJettison / degradedGeneratorRating);
        fuelJettisonLoad.setPercentageWithJettison(percentageWithJettison);
        double percentageWithoutJettison = 100d * (loadWithoutJettison / degradedGeneratorRating);
        fuelJettisonLoad.setPercentageWithoutJettison(percentageWithoutJettison);

        fuelJettisonGenerator.addFuelJettisonLoad(fuelJettisonLoad);

        // determine the 3 fuel jettison statuses: status of generator, status with jettison, and
        // status
        // without jettison
        AnalysisStatus statusWithJettison =
            determineStatus(percentageWithJettison, thresholdUpperLimit, thresholdLowerLimit);
        AnalysisStatus statusWithoutJettison =
            determineStatus(percentageWithoutJettison, thresholdUpperLimit, thresholdLowerLimit);

        AnalysisStatus worstCaseWithJettisonStatus =
            getWorstCaseStatus(statusWithJettison, fuelJettisonGenerator.getWithJettisonStatus());
        AnalysisStatus worstCaseWithoutJettisonStatus =
            getWorstCaseStatus(
                statusWithoutJettison, fuelJettisonGenerator.getWithoutJettisonStatus());
        AnalysisStatus worstCaseJettisonStatus =
            getWorstCaseStatus(worstCaseWithJettisonStatus, worstCaseWithoutJettisonStatus);

        fuelJettisonGenerator.setWithJettisonStatus(worstCaseWithJettisonStatus);
        status = getWorstCaseStatus(status, worstCaseWithJettisonStatus);
        fuelJettisonGenerator.setWithoutJettisonStatus(worstCaseWithoutJettisonStatus);
        status = getWorstCaseStatus(status, worstCaseWithoutJettisonStatus);
        fuelJettisonGenerator.setGeneratorStatus(
            getWorstCaseStatus(
                worstCaseJettisonStatus, fuelJettisonGenerator.getGeneratorStatus()));
        status = getWorstCaseStatus(status, fuelJettisonGenerator.getGeneratorStatus());
        // end status
      }
    }
    return status;
  }

  public static AnalysisStatus determineStatus(
      double percentage, double thresholdUpperLimit, double thresholdLowerLimit) {
    if (percentage >= thresholdUpperLimit) {
      return AnalysisStatus.FAIL;
    } else if (percentage >= thresholdLowerLimit) {
      return AnalysisStatus.WARN;
    } else {
      return AnalysisStatus.PASS;
    }
  }

  private SummarizedLoad getSummarizedLoadForDegradedAnalysis(
      List<SummarizedLoad> loads,
      ElectricalPhase electricalPhase,
      String flightPhase,
      Fleet fleet) {
    return loads.stream()
        .filter(
            load ->
                load.getOperatingMode().equalsIgnoreCase(getDegradedCalculationOperatingMode(fleet))
                    && load.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN
                    && load.getElectricalPhase() == electricalPhase
                    && load.getFlightPhase().equalsIgnoreCase(flightPhase))
        .findFirst()
        .orElse(null);
  }

  /**
   * determine the normal analysis for the nodes passed in and set it on the analysis object passed
   * in. The normal analysis is performed on all loads (essential and sheddable). On a
   * summarizedload object, the fields 'val' and 'originalVal' contain the aggregate of both
   * essential and sheddable loads.
   *
   * @param nodes
   * @param analysis
   * @param fleet the fleet this ELA is associated with
   * @param isSummary - if the analysis should include AnalysisLoad's then false. if the analysis
   *     should not include AnalysisLoad's then true.
   */
  private void setNormalAnalysisNodes(
      List<Node> nodes,
      Analysis analysis,
      Fleet fleet,
      boolean isSummary,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {

    AnalysisStatus normalStatus = AnalysisStatus.PASS; // set default value

    for (Node node : nodes) {
      List<SummarizedLoad> summarizedLoads = node.getSummarizedLoads();

      // business rule: for normal analysis
      // remove standby and hmg flight phases (boeing)
      // from summarizedLoads collection
      // so the analysis doesn't include in calculations
      // nor does the client-side display
      if (fleet.getManufacturer().equalsIgnoreCase(BOEING)) {
        summarizedLoads =
            summarizedLoads.stream()
                .filter(f -> !Arrays.asList("STANDBY", "HMG").contains(f.getFlightPhase()))
                .collect(Collectors.toList());
      }

      if (node.getNodeType() == NodeType.TRU) {
        if (FieldValidator.isDoubleGreaterZero(node.getNominalPower())
            && FieldValidator.isDoubleGreaterZero(node.getInlineVoltage())) {
          Double nominalPower = node.getNominalPower();
          AnalysisNode analysisNode = new AnalysisNode(node.getId(), nominalPower, node.getName());
          analysis.getNormalAnalysis().addTruNode(analysisNode);
          NodeType nodeType = NodeType.TRU;
          Units units = Units.AMPS;
          Double voltage = node.getInlineVoltage();
          setNormalAnalysisLoads(
              summarizedLoads,
              analysisNode,
              null,
              nominalPower,
              voltage,
              nodeType,
              units,
              fleet,
              isSummary,
              thresholdLowerLimit,
              thresholdUpperLimit);
          // determine the normal analysis status which is the worst case status between this node
          // and previous nodes.
          normalStatus = getWorstCaseStatus(normalStatus, analysisNode.getStatus());
        } else {
          logger.warn(
              "The nominal power for the TRU Transformer is null or zero. The TRU node ID is: "
                  + node.getId());
        }
      } else if (node.getNodeType() == NodeType.ATU) {
        if (FieldValidator.isDoubleGreaterZero(node.getNominalPower())
            && FieldValidator.isDoubleGreaterZero(node.getInlineVoltage())) {
          Double nominalPower = node.getNominalPower() / node.getInlineVoltage();
          AnalysisNode analysisNode = new AnalysisNode(node.getId(), nominalPower, node.getName());
          analysis.getNormalAnalysis().addAtuNode(analysisNode);
          NodeType nodeType = NodeType.ATU;
          Units units = Units.AMPS;
          Double voltage = node.getInlineVoltage();
          setNormalAnalysisLoads(
              summarizedLoads,
              analysisNode,
              null,
              nominalPower,
              voltage,
              nodeType,
              units,
              fleet,
              isSummary,
              thresholdLowerLimit,
              thresholdUpperLimit);
          // determine the normal analysis status which is the worst case status between this node
          // and previous nodes.
          normalStatus = getWorstCaseStatus(normalStatus, analysisNode.getStatus());
        } else {
          logger.warn(
              "The nominal power for the ATU Transformer is null or zero. The ATU node ID is: "
                  + node.getId());
        }
      } else if (node.getNodeType() == NodeType.BUS) {
        if (FieldValidator.isDoubleGreaterZero(node.getBusRating())) {
          Double busRating = node.getBusRating();
          AnalysisNode analysisNode = new AnalysisNode(node.getId(), busRating, node.getName());
          analysisNode.setVoltageType(node.getVoltageType().name());
          analysis.getNormalAnalysis().addBusNode(analysisNode);
          Double voltage = node.getVoltage();
          NodeType nodeType = NodeType.BUS;
          Units units = Units.AMPS;
          setNormalAnalysisLoads(
              summarizedLoads,
              analysisNode,
              busRating,
              null,
              voltage,
              nodeType,
              units,
              fleet,
              isSummary,
              thresholdLowerLimit,
              thresholdUpperLimit);
          // determine the normal analysis status which is the worst case status between this node
          // and previous nodes.
          normalStatus = getWorstCaseStatus(normalStatus, analysisNode.getStatus());
        } else {
          // do not log this case since it clutters up the log file
        }
      } else if (node.getNodeType() == NodeType.GENERATOR) {
        if (FieldValidator.isDoubleGreaterZero(node.getNominalPower())) {
          Double nominalPower = node.getNominalPower() / 1000d;
          AnalysisNode analysisNode = new AnalysisNode(node.getId(), nominalPower, node.getName());
          analysis.getNormalAnalysis().addGeneratorNode(analysisNode);
          NodeType nodeType = NodeType.GENERATOR;
          Units units = Units.KVA;
          setNormalAnalysisLoads(
              summarizedLoads,
              analysisNode,
              null,
              nominalPower,
              null,
              nodeType,
              units,
              fleet,
              isSummary,
              thresholdLowerLimit,
              thresholdUpperLimit);
          // determine the normal analysis status which is the worst case status between this node
          // and previous nodes.
          normalStatus = getWorstCaseStatus(normalStatus, analysisNode.getStatus());
        } else {
          logger.warn(
              "The nominal power for the Generator is null or zero. The Generator node ID is: "
                  + node.getId());
        }
      }
    }
    analysis.setNormalStatus(normalStatus);

    Collections.sort(analysis.getNormalAnalysis().getTruNodes());
    Collections.sort(analysis.getNormalAnalysis().getAtuNodes());
    Collections.sort(analysis.getNormalAnalysis().getBusNodes());
    Collections.sort(analysis.getNormalAnalysis().getGeneratorNodes());
  }

  /**
   * Create the normal analysis loads. For each SummarizedLoad passed in that is for normal
   * operating conditions (ie. MAXI), create an AnalysisLoad object and set it on the AnalysisNode
   * object passed in.
   *
   * @param summarizedLoads - an aggregate of all loads for a node. a different aggregate load
   *     exists for each unique combination of flight phase and electrical phase.
   * @param analysisNode
   * @param busRating - used if a bus. otherwise null
   * @param nominalPower - used if a transformer or generator. otherwise null
   * @param voltage - used for buses and transformers. converts VA (voltage amps) to Amps
   * @param nodeType
   * @param units
   * @param isSummary - if the analysis should include AnalysisLoad's then false. if the analysis
   *     should not include AnalysisLoad's then true.
   */
  private void setNormalAnalysisLoads(
      List<SummarizedLoad> summarizedLoads,
      AnalysisNode analysisNode,
      Double busRating,
      Double nominalPower,
      Double voltage,
      NodeType nodeType,
      Units units,
      Fleet fleet,
      boolean isSummary,
      Double thresholdLowerLimit,
      Double thresholdUpperLimit) {

    AnalysisStatus status = AnalysisStatus.PASS; // set default value
    if (summarizedLoads != null && !summarizedLoads.isEmpty()) {

      // used for generator analysis
      Set<String> flightPhases = new HashSet<>();

      for (SummarizedLoad summarizedLoad : summarizedLoads) {
        if (logger.isDebugEnabled()) {
          logger.debug(
              "Analysis Summarized load for "
                  + nodeType
                  + " "
                  + analysisNode.getName()
                  + " flight phase "
                  + summarizedLoad.getFlightPhase()
                  + " electrical phase: "
                  + summarizedLoad.getElectricalPhase()
                  + " operating mode: "
                  + summarizedLoad.getOperatingMode()
                  + " "
                  + summarizedLoad.getW()
                  + " "
                  + summarizedLoad.getVar()
                  + " "
                  + summarizedLoad.getVa()
                  + " "
                  + summarizedLoad.getPowerFactor());
        }
        if (summarizedLoad
            .getOperatingMode()
            .equalsIgnoreCase(getNormalCalculationOperatingMode(fleet))) {
          Double value = 0d;
          Double result = 0d;
          if (nodeType == NodeType.BUS) {
            value =
                LoadUtil.getAmps(
                    summarizedLoad.getVa(), summarizedLoad.getPowerFactor(), voltage); // in AMPS
            result = busRating == null || busRating == 0d ? 0 : value / busRating; // in AMPS
          } else if (nodeType == NodeType.TRU || nodeType == NodeType.ATU) {
            value = LoadUtil.getAmps(summarizedLoad.getOriginalW(), voltage); // in AMPS
            result =
                nominalPower == null || nominalPower == 0d ? 0 : value / nominalPower; // in AMPS
          } else if (nodeType == NodeType.GENERATOR) {
            value = summarizedLoad.getVa() / 1000d; // in KVA
            // divide by 3 because we're grouping by A/B/C phases
            result =
                nominalPower == null || nominalPower == 0d
                    ? 0
                    : value / (nominalPower / 3); // in KVA
          }
          if (!isSummary) {
            analysisNode.addAnalysisLoad(
                new AnalysisLoad(
                    result * 100d,
                    summarizedLoad.getFlightPhase(),
                    value,
                    summarizedLoad.getElectricalPhase().name(),
                    units));
          }

          flightPhases.add(summarizedLoad.getFlightPhase());

          // determine the nodes analysis status which is the worst case status between this load
          // and previous loads.
          status =
              getWorstCaseStatusForLoads(
                  status, result * 100d, thresholdUpperLimit, thresholdLowerLimit);
        }
      }

      // if a generator then create 2 additional psuedo AnalysisLoad objects per flight phase. one
      // contains the total load value for a flight phase,
      // and the other contains the max imbalance for a flight phase.
      if (!isSummary && nodeType == NodeType.GENERATOR) {
        for (String flightPhase : flightPhases) {
          List<SummarizedLoad> generatorLoadsFilteredByFlightPhase =
              summarizedLoads.stream()
                  .filter(
                      load ->
                          load.getOperatingMode()
                                  .equalsIgnoreCase(getNormalCalculationOperatingMode(fleet))
                              && load.getFlightPhase().equalsIgnoreCase(flightPhase)
                              && (load.getElectricalPhase() == ElectricalPhase.ACA
                                  || load.getElectricalPhase() == ElectricalPhase.ACB
                                  || load.getElectricalPhase() == ElectricalPhase.ACC))
                  .collect(Collectors.toList());
          if (!generatorLoadsFilteredByFlightPhase.isEmpty()) {
            Double sumWatts =
                generatorLoadsFilteredByFlightPhase.stream()
                    .mapToDouble(SummarizedLoad::getW)
                    .sum();
            Double sumVar =
                generatorLoadsFilteredByFlightPhase.stream()
                    .mapToDouble(SummarizedLoad::getVar)
                    .sum();
            Double sum = 0d;
            if (sumWatts != null && sumVar != null) {
              sum = LoadUtil.getVa(sumWatts, sumVar) / 1000d;
            }
            SummarizedLoad max =
                generatorLoadsFilteredByFlightPhase.stream()
                    .max(Comparator.comparing(SummarizedLoad::getW))
                    .get();
            Double maxValue = LoadUtil.getVa(max.getW(), max.getVar());

            SummarizedLoad min =
                generatorLoadsFilteredByFlightPhase.stream()
                    .min(Comparator.comparing(SummarizedLoad::getW))
                    .get();
            Double minValue = LoadUtil.getVa(min.getW(), min.getVar());
            Double diff =
                (maxValue != null && minValue != null)
                    ? (maxValue - minValue) / 1000d
                    : 0d; // diff in KVA
            analysisNode.addAnalysisLoad(
                new AnalysisLoad(null, flightPhase, sum, "TOTAL", Units.KVA));
            analysisNode.addAnalysisLoad(
                new AnalysisLoad(null, flightPhase, diff, "IMBALANCE", Units.KVA));
          }
        }
      }

      Collections.sort(analysisNode.getAnalysisLoads());
    }

    analysisNode.setStatus(status);
  }

  private String getNormalCalculationOperatingMode(Fleet fleet) {
    if (fleet.getManufacturer().equalsIgnoreCase(AIRBUS)) {
      return AIRBUS_NORMAL_CALCULATION;
    } else if (fleet.getName().startsWith(FlightPhase.BOEING_717_FLEET)) {
      return BOEING_717_NORMAL_CALCULATION;
    } else if (fleet.getManufacturer().equalsIgnoreCase(BOEING)) {
      return BOEING_NORMAL_CALCULATION;
    }
    throw new IllegalArgumentException(
        "Unrecognized fleet manufacturer: " + fleet.getManufacturer());
  }

  private String getDegradedCalculationOperatingMode(Fleet fleet) {
    if (fleet.getManufacturer().equalsIgnoreCase(AIRBUS)) {
      return AIRBUS_DEGRADED_CALCULATION;
    } else if (fleet.getName().startsWith(FlightPhase.BOEING_717_FLEET)) {
      return BOEING_717_DEGRADED_CALCULATION;
    } else if (fleet.getManufacturer().equalsIgnoreCase(BOEING)) {
      return BOEING_DEGRADED_CALCULATION;
    }
    throw new IllegalArgumentException(
        "Unrecognized fleet manufacturer: " + fleet.getManufacturer());
  }

  // Determine the worst case analysis status (PASS, WARN, FAIL) for a load
  private AnalysisStatus getWorstCaseStatusForLoads(
      AnalysisStatus currentStatus,
      Double value,
      Double thresholdUpperLimit,
      Double thresholdLowerLimit) {
    if (currentStatus == AnalysisStatus.WARN) {
      if (value >= thresholdUpperLimit) {
        currentStatus = AnalysisStatus.FAIL;
      }
    }
    if (currentStatus == AnalysisStatus.PASS) {
      if (value >= thresholdUpperLimit) {
        currentStatus = AnalysisStatus.FAIL;
      } else if (value >= thresholdLowerLimit) {
        currentStatus = AnalysisStatus.WARN;
      }
    }
    return currentStatus;
  }

  // Determine the worst case analysis status (PASS, WARN, FAIL) between the two statuses passed in
  public static AnalysisStatus getWorstCaseStatus(AnalysisStatus status1, AnalysisStatus status2) {
    if (status1 == AnalysisStatus.FAIL || status2 == AnalysisStatus.FAIL) {
      return AnalysisStatus.FAIL;
    } else if (status1 == AnalysisStatus.WARN || status2 == AnalysisStatus.WARN) {
      return AnalysisStatus.WARN;
    } else {
      return AnalysisStatus.PASS;
    }
  }

  /**
   * returns all non-battery supplied flight phases
   *
   * @param node - Node Entity
   * @return Set of strings
   */
  private Set<String> getFlightPhasesFromSummarizedLoads(Node node) {
    // business rule: exclude Battery Supplied flight phases (ie. standby/hmg)
    return node.getSummarizedLoads().stream()
        .filter(
            summarizedLoad ->
                !BATTERY_SUPPLIED_FLIGHT_PHASES.contains(summarizedLoad.getFlightPhase()))
        .map(SummarizedLoad::getFlightPhase)
        .collect(Collectors.toSet());
  }

  public void setAutoLandAnalysis(
      String autoLandCalculationType,
      Long elaId,
      List<Node> nodes,
      Fleet fleet,
      Analysis analysis) {

    Ela ela = elaRepository.findById(elaId).get();
    AutoLandCondition autoLandCondition = null;
    if (autoLandCalculationType.equals("BATTERY")) {
      AutoLandFleetConfigDto autoLandFleetConfig = autoLandAnalysisService.loadFleetConfig(fleet);
      autoLandCondition = autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);
    } else if (autoLandCalculationType.equals("TRU")) {
      autoLandCondition =
          truAutoLandAnalysisService.getAutoLandCondition(
              ela.getAircraft().getAircraftShipNo(),
              nodes,
              analysis.getThresholdLowerLimit(),
              analysis.getThresholdUpperLimit());
    }
    analysis.getNormalAnalysis().setAutoLandCondition(autoLandCondition);

    if (autoLandCondition != null) {
      // The overall normal status includes the overall autoland status
      AnalysisStatus normalStatusInitial = analysis.getNormalStatus();
      AnalysisStatus normalStatusUpdated =
          getWorstCaseStatus(normalStatusInitial, autoLandCondition.getStatus());
      analysis.setNormalStatus(normalStatusUpdated);
    }
  }
}
