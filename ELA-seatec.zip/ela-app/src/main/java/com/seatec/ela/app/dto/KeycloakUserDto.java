package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackIdString;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;

public class KeycloakUserDto implements UserTrackIdString {

  private String id;

  @NotEmpty(message = "{field.required}")
  private String firstName;

  @NotEmpty(message = "{field.required}")
  private String lastName;

  private Boolean enabled;

  @NotEmpty(message = "{field.required}")
  @Email(message = "{invalid.email}")
  private String email;

  private Boolean emailVerified;

  @NotEmpty(message = "{field.required}")
  private String role;

  public KeycloakUserDto(
      String id,
      String firstName,
      String lastName,
      Boolean enabled,
      String email,
      Boolean emailVerified,
      String role) {
    this.id = id;
    this.firstName = firstName;
    this.lastName = lastName;
    this.enabled = enabled;
    this.email = email;
    this.emailVerified = emailVerified;
    this.role = role;
  }

  public KeycloakUserDto() {}

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public Boolean getEnabled() {
    return this.enabled;
  }

  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  public String getEmail() {
    return this.email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Boolean getEmailVerified() {
    return this.emailVerified;
  }

  public void setEmailVerified(Boolean emailVerified) {
    this.emailVerified = emailVerified;
  }

  public String getRole() {
    return role;
  }

  public void setRole(String role) {
    this.role = role;
  }
}
