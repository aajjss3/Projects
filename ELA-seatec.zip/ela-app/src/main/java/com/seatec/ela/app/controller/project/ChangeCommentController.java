package com.seatec.ela.app.controller.project;

import com.seatec.ela.app.dto.project.change.ChangeCommentDTO;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.project.change.ChangeComment;
import com.seatec.ela.app.service.contract.project.change.IChangeCommentService;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.annotation.IdExists;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(
    "/service/projects/{projectId}/changegroups/{changeGroupId}/change/{changeId}/comment")
@Validated
public class ChangeCommentController {

  @Autowired private IChangeCommentService changeCommentService;

  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public ChangeComment create(
      @Validated @RequestBody ChangeCommentDTO changeCommentDTO,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      @IdExists(entity = Change.class, message = "{id.invalid}") @PathVariable("changeId")
          UUID changeId,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    return changeCommentService.create(
        changeCommentDTO, projectId, changeGroupId, changeId, userId);
  }
}
