package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.ComponentUtil;

/** AtuAggregator aggregates the loads for a component on an ATU node */
class AtuAggregator implements ITransformerAggregator {

  public void aggregateLoadSummary(
      SummarizedLoad loadSummary,
      LoadSummaryOptions loadSummaryOptions,
      Component component,
      Load load,
      String rootTransformerNodeIdentifier,
      EfficiencyTable efficiencyTable) {

    if (loadSummaryOptions.getIncludeEssentialLoadAggregate()
        && ComponentUtil.isEssential(component)) {
      // Essential Only
      loadSummary.aggregateAtuWsEssentialLoad(rootTransformerNodeIdentifier, load.getW());
      loadSummary.aggregateAtuVarsEssentialLoad(rootTransformerNodeIdentifier, load.getVar());
    }
    // Essential and Sheddable
    loadSummary.aggregateAtuWs(rootTransformerNodeIdentifier, load.getW());
    loadSummary.aggregateAtuVars(rootTransformerNodeIdentifier, load.getVar());
    loadSummary
        .getNodeToEfficiencyTableMap()
        .put(rootTransformerNodeIdentifier, efficiencyTable.getId());
  }
}
