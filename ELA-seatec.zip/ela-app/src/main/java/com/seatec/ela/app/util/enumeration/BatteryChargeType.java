package com.seatec.ela.app.util.enumeration;

/** The aircraft battery's electrical charge and quantity */
public enum BatteryChargeType {
  SINGLE_40AH,
  DUAL_40AH,
  SINGLE_48AH,
  DUAL_48AH,
  SINGLE_47AH,
  SINGLE_75AH
}
