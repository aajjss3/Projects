package com.seatec.ela.app.model;

public enum NodeType {
  GENERATOR,
  TRU,
  ATU,
  BUS,
  BATTERY,
  APU,
  STANDBY_GEN,
  INVERTER
}
