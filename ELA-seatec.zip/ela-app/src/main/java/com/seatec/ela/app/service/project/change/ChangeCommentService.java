package com.seatec.ela.app.service.project.change;

import com.seatec.ela.app.dto.project.change.ChangeCommentDTO;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.project.change.ChangeComment;
import com.seatec.ela.app.model.repository.project.change.ChangeCommentRepo;
import com.seatec.ela.app.service.contract.IKeycloakService;
import com.seatec.ela.app.service.contract.project.change.IChangeCommentService;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import java.util.Optional;
import java.util.UUID;
import javax.transaction.Transactional;
import org.keycloak.representations.idm.UserRepresentation;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ChangeCommentService implements IChangeCommentService {

  @Autowired private IChangeService changeService;

  @Autowired private IKeycloakService keycloakService;

  @Autowired private ChangeCommentRepo changeCommentRepo;

  @Autowired
  @Qualifier("mapAll")
  ModelMapper mapper;

  public ChangeCommentService() {}

  public ChangeCommentService(
      IChangeService changeService,
      IKeycloakService keycloakService,
      ChangeCommentRepo changeRepo,
      @Qualifier("mapAll") ModelMapper mapper) {
    this.changeService = changeService;
    this.keycloakService = keycloakService;
    this.changeCommentRepo = changeRepo;
    this.mapper = mapper;
  }

  public Optional<ChangeComment> findById(UUID id) {
    return changeCommentRepo.findById(id);
  }

  /**
   * Save ChangeComment record for a given Project, Change Group, and Change
   *
   * @param comment Represents ChangeComment DTO
   * @param projectId Represents Project Entity unique identifier (UUID)
   * @param changeGroupId Represents unique ChangeGroup identifier (UUID)
   * @param changeId Represents Change Entity unique identifier (UUID)
   * @return ChangeComment Entity
   */
  @Transactional
  public ChangeComment create(
      ChangeCommentDTO comment, UUID projectId, UUID changeGroupId, UUID changeId, String userId) {
    // get Change Entity
    Change changeEntity =
        findChangeByProjectIdAndChangeGroupIdAndChangeId(projectId, changeGroupId, changeId);

    // convert changeCommentDTO to changeComment Entity
    ChangeComment changeCommentEntity =
        setAndConvertChangeCommentDTOToChangeComment(comment, userId);

    // add changeComment Entity to change Entity
    changeEntity.addComment(changeCommentEntity);

    // save
    return changeCommentRepo.save(changeCommentEntity);
  }

  public void deleteAllByChangeId(UUID projectId, UUID changeGroupId, UUID changeId) {
    // get Change Entity
    Change changeEntity =
        findChangeByProjectIdAndChangeGroupIdAndChangeId(projectId, changeGroupId, changeId);

    // delete
    changeCommentRepo.deleteByChangeId(changeEntity.getId());
  }

  private Change findChangeByProjectIdAndChangeGroupIdAndChangeId(
      UUID projectId, UUID changeGroupId, UUID changeId) {

    // get matching change
    Change changeEntity =
        changeService
            .findById(changeId)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Unable to complete. Change (" + changeId + ")" + " not found.",
                        Level.WARN));

    // verify Change Group matches
    if (!changeEntity.getChangeGroup().getId().equals(changeGroupId)) {
      throw new NotFoundException(
          "Unable to complete. Change Group (" + changeGroupId + ") " + "not found.", Level.WARN);
    }

    // verify project matches
    if (!changeEntity.getChangeGroup().getProject().getId().equals(projectId)) {
      throw new NotFoundException(
          "Unable to complete. Project (" + projectId + ") " + "not found.", Level.WARN);
    }

    return changeEntity;
  }

  private ChangeComment setAndConvertChangeCommentDTOToChangeComment(
      ChangeCommentDTO comment, String userId) {
    comment.setAuthor(userId);
    UserRepresentation user = keycloakService.findUser(userId);
    comment.setDisplayName(user.getFirstName() + " " + user.getLastName());

    return mapper.map(comment, ChangeComment.class);
  }
}
