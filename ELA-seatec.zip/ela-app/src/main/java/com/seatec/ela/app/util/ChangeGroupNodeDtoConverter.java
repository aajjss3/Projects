package com.seatec.ela.app.util;

import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.model.project.NodeChange;

public class ChangeGroupNodeDtoConverter {

  public static ChangeGroupNodeDto convertNodeChangeToDto(NodeChange nodeChange) {
    if (nodeChange == null) {
      return null;
    }

    return new ChangeGroupNodeDto(
        nodeChange.getName(),
        nodeChange.getDescription(),
        nodeChange.getNominalPower(),
        nodeChange.getVoltage(),
        nodeChange.getVoltageType(),
        nodeChange.getNodeType(),
        nodeChange.isRequiresApproval(),
        nodeChange.getBusRating(),
        nodeChange.isSheddable(),
        nodeChange.getElectricalPhase());
  }
}
