package com.seatec.ela.app.model.repository.project;

import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ChangeGroupRepo extends CrudRepository<ChangeGroup, UUID> {
  List<ChangeGroup> findAllByProjectId(UUID projectId);

  @Query(
      "SELECT COUNT(id) FROM ChangeGroup WHERE project = (SELECT project FROM ChangeGroup WHERE id = :id)")
  int findTotalCountById(@Param("id") UUID id);

  @Query("SELECT cg FROM ChangeGroup cg WHERE cg.name = :name AND cg.project = :project")
  Optional<ChangeGroup> findByProjectIdAndChangeGroupName(
      @Param("project") Project project, @Param("name") String name);

  List<ChangeGroup> findByProjectIdAndIdNotIn(UUID projectId, UUID Id);

  @Query(
      value =
          "select cg.* from change_group cg inner join aircraft_change_group acg ON acg.change_group_id = cg.id where acg.aircraft_id in :aircraftIds",
      nativeQuery = true)
  List<ChangeGroup> findAllByAircrafts(@Param("aircraftIds") List<Long> aircraftIds);
}
