package com.seatec.ela.app.service.project;

import static com.seatec.ela.app.util.ChangeGroupNodeDtoConverter.convertNodeChangeToDto;
import static com.seatec.ela.app.util.ComponentDtoConverter.convertComponentChangeToComponentDto;
import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;
import static java.util.Comparator.nullsLast;

import com.google.common.collect.Lists;
import com.seatec.ela.app.dto.AircraftBusStructureBucketDto;
import com.seatec.ela.app.dto.ChangeGroupMappedNodeDto;
import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.dto.changeGroup.LoadDto;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotAcceptableException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeStructureRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupEffectivityDao;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.structure.NodeStructure;
import com.seatec.ela.app.model.structure.VoltageType;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.service.contract.IComponentService;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.service.contract.project.IAircraftChangeGroupService;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.util.ComponentDtoConverter;
import com.seatec.ela.app.util.FieldValidator;
import com.seatec.ela.app.util.FleetDtoConverter;
import com.seatec.ela.app.util.LoadDtoConverter;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChangeGroupService implements IChangeGroupService {

  private static final String DEFAULT_CHANGE_GROUP_BUCKET_NAME = "Default Change Group 1";

  private static final Pattern CHANGE_GROUP_NAME_REGEX = Pattern.compile("(.*)([0-9]+)");

  @Autowired private IProjectService projectService;

  @Autowired private IAircraftService aircraftService;

  @Autowired private IAircraftChangeGroupService aircraftChangeGroupService;

  @Autowired private IComponentService componentService;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private IElaService elaService;

  @Autowired private ChangeGroupEffectivityDao changeGroupEffectivityDao;

  @Autowired private LoadRepository loadRepository;

  @Autowired private INodeService nodeService;

  @Autowired private NodeStructureRepository nodeStructureRepository;

  public ChangeGroupService() {}

  public ChangeGroupService(
      IAircraftService aircraftService,
      IProjectService projectService,
      IAircraftChangeGroupService aircraftChangeGroupService,
      ChangeGroupRepo changeGroupRepo,
      LoadRepository loadRepository,
      IElaService elaService,
      ChangeGroupEffectivityDao changeGroupEffectivityDao,
      IComponentService componentService,
      INodeService nodeService,
      NodeStructureRepository nodeStructureRepository) {
    this.aircraftService = aircraftService;
    this.projectService = projectService;
    this.aircraftChangeGroupService = aircraftChangeGroupService;
    this.changeGroupRepo = changeGroupRepo;
    this.loadRepository = loadRepository;
    this.elaService = elaService;
    this.changeGroupEffectivityDao = changeGroupEffectivityDao;
    this.componentService = componentService;
    this.nodeService = nodeService;
    this.nodeStructureRepository = nodeStructureRepository;
  }

  /**
   * Search for ChangeGroups by Project Id
   *
   * @param projectId Represents unique identifier for Project Entity
   * @return Collection of ChangeGroup Entity
   */
  public List<ChangeGroup> findAllByProjectId(UUID projectId) {
    return changeGroupRepo.findAllByProjectId(projectId);
  }

  /**
   * Search for ChangeGroupNodes by Change Group Id
   *
   * @param changeGroupId Represents unique identifier for ChangeGroup Entity
   * @return Collection of ChangeGroupNodeDto
   */
  @Transactional
  public List<ChangeGroupNodeDto> findChangeGroupEffectivityBusStructureByChangeGroupId(
      UUID changeGroupId) {
    ChangeGroup changeGroupEntity =
        findById(changeGroupId)
            .orElseThrow(
                () ->
                    new NotFoundException(
                        "Change Group (" + changeGroupId + ") not found.", Level.ERROR));

    // generate effectivity bus structure
    List<ChangeGroupNodeDto> nodeList = findChangeGroupNodeDtosByChangeGroupId(changeGroupEntity);

    // must process Node Changes first in case a Component Change is based on a new Node
    // add Node Changes to existing bus structure
    addNodeChangesToChangeGroupNodeDtos(changeGroupEntity.getChanges(), nodeList);

    // add Component Changes to existing bus structure
    addComponentChangesToChangeGroupNodeDtos(changeGroupEntity.getChanges(), nodeList);

    return nodeList;
  }

  /**
   * Search for ChangeGroups by Change Group Id
   *
   * @param id Represents unique identifier for ChangeGroup Entity
   * @return Optional ChangeGroup Entity
   */
  public Optional<ChangeGroup> findById(UUID id) {
    return changeGroupRepo.findById(id);
  }

  /**
   * Save ChangeGroup to Project Entity
   *
   * @param entity Represents ChangeGroup Entity
   * @param projectId Represents unique identifier for Project Entity
   * @return ChangeGroup Entity
   */
  @Transactional
  public ChangeGroup save(ChangeGroup entity, UUID projectId) {
    Project projectEntity =
        projectService
            .findById(projectId)
            .orElseThrow(
                () ->
                    new BadRequestException(
                        "Unable to save the change group. A project does not exist with Project Id "
                            + projectId,
                        Level.WARN));

    Optional<ChangeGroup> existsAlready =
        changeGroupRepo.findByProjectIdAndChangeGroupName(projectEntity, entity.getName());

    // verify change group (name) does not exist
    if (!existsAlready.isPresent()) {
      entity.setProject(projectEntity);
      return changeGroupRepo.save(entity);
    } else {
      throw new BadRequestException(
          "Unable to save. The ChangeGroup Name '"
              + entity.getName()
              + "' already exists for Project Id "
              + projectId,
          Level.WARN);
    }
  }

  /**
   * Save Change Group and Aircraft Change Group to Project Entity
   *
   * @param aircraftIds: Represents collection of unique Aircraft identifiers (Long)
   * @param projectId: Represents unique identifier for Project Entity
   * @return Collection of ChangeGroups Entity
   */
  @Transactional
  public void saveByBusStructureBucketUsingAircraftIds(List<Long> aircraftIds, UUID projectId) {
    Project projectEntity =
        projectService
            .findById(projectId)
            .orElseThrow(
                () -> new NotFoundException("Project (" + projectId + ") not found.", Level.ERROR));
    List<Aircraft> aircrafts = aircraftService.findByIdIn(aircraftIds);

    if (aircrafts.isEmpty()) {
      Long[] foundAircraftId = aircraftIds.toArray(new Long[0]);
      throw new BadRequestException(
          "Aircraft not found for Ids " + Arrays.toString(foundAircraftId));
    } else if (aircrafts.stream().anyMatch(Aircraft::isCloaked)) {
      throw new NotFoundException(
          "Invalid Aircraft found in Effectivity on Project Id " + projectId, Level.WARN);
    }

    List<ChangeGroup> projectChangeGroups = changeGroupRepo.findAllByProjectId(projectId);
    Set<String> duplicateAircraftShipNo =
        findDuplicateAircraftsInChangeGroups(projectChangeGroups, aircrafts);

    if (!duplicateAircraftShipNo.isEmpty()) {
      String[] shipNos = duplicateAircraftShipNo.toArray(new String[0]);
      throw new NotAcceptableException(
          "Cannot complete request. The following Effectivities are found in another Change Group. "
              + Arrays.toString(shipNos),
          Level.ERROR);
    }
    saveAircraftChangeGroups(createAircraftBusStructureBucketDtos(null, aircrafts), projectEntity);
  }

  @Transactional
  public void update(ChangeGroup entity, UUID id) {
    Optional<ChangeGroup> changeGroupEntity = changeGroupRepo.findById(id);

    if (changeGroupEntity.isPresent()) {
      ChangeGroup changeGroup = changeGroupEntity.get();
      changeGroup.setName(entity.getName());
      updateAircraftChangeGroup(changeGroup, entity.getAircraftChangeGroups());
    } else {
      throw new NotFoundException("ChangeGroup (" + id + ") not found.", Level.ERROR);
    }
  }

  /**
   * Merge in desired AircraftChangeGroups by adding new ones and removing those no longer on the
   * list.
   *
   * @param changeGroup the change group
   * @param updated the new list of aircraft change groups
   */
  private void updateAircraftChangeGroup(
      ChangeGroup changeGroup, List<AircraftChangeGroup> updated) {
    List<AircraftChangeGroup> currentList = changeGroup.getAircraftChangeGroups();

    Set<Long> existingAircraftIds =
        currentList.stream()
            .map(acg -> acg.getAircraft().getId())
            .collect(Collectors.toCollection(HashSet::new));
    Set<Long> newAircraftIds =
        updated.stream()
            .map(acg -> acg.getAircraft().getId())
            .collect(Collectors.toCollection(HashSet::new));

    // add any aircraft that are new
    for (AircraftChangeGroup acg : updated) {
      if (!existingAircraftIds.contains(acg.getAircraft().getId())) {
        currentList.add(acg);
      }
    }

    // remove any aircraft that aren't in the new list
    currentList.removeIf(acg -> !newAircraftIds.contains(acg.getAircraft().getId()));
    changeGroup.setAircraftChangeGroups(currentList);
  }

  @Transactional
  public void updateEffectivity(List<Long> aircraftIds, UUID projectId, UUID changeGroupId) {
    // get change groups related to project
    List<ChangeGroup> projectChangeGroups = changeGroupRepo.findAllByProjectId(projectId);

    // get Aircraft Entity list from aircraftIds passed in
    List<Aircraft> newChangeGroupAircrafts = aircraftService.findByIdIn(aircraftIds);

    // returns list of Aircrafts already in-use in other Change Groups for this project
    Set<String> duplicateAircraftShipNo =
        findDuplicateAircraftsInOtherChangeGroups(
            projectChangeGroups, newChangeGroupAircrafts, changeGroupId);

    // do we have any duplicate Aircraft usage
    if (duplicateAircraftShipNo.isEmpty()) {
      ChangeGroup currentChangeGroup =
          projectChangeGroups.stream()
              .filter(changeGroup -> changeGroup.getId().equals(changeGroupId))
              .findFirst()
              .orElseThrow(
                  () ->
                      new NotFoundException(
                          "Change Group (" + changeGroupId + ") not found.", Level.ERROR));

      // convert new Aircraft list to AircraftBusStructureBucketDto collection
      // allows us to correctly map Aircraft to each Change Group
      List<AircraftBusStructureBucketDto> aircraftBusStructureBucketDtos =
          createAircraftBusStructureBucketDtos(currentChangeGroup, newChangeGroupAircrafts);

      // business rule: do not allow user to remove ALL Effectivities in Change Group
      // throws an NotAcceptableException error if true
      isRemovingAllEffectivityFromChangeGroup(aircraftBusStructureBucketDtos, currentChangeGroup);

      // update current and associated Change Groups
      updateChangeGroups(
          aircraftBusStructureBucketDtos, projectChangeGroups, changeGroupId, projectId);
    } else {
      String[] shipNos = duplicateAircraftShipNo.stream().toArray(String[]::new);
      throw new NotAcceptableException(
          "Cannot complete request. The following Effectivities are found in another Change Group. "
              + Arrays.toString(shipNos),
          Level.ERROR);
    }
  }

  /** Business Rule: Project has to contain at least one Change Group in order to delete */
  @Transactional
  public void delete(UUID id) {

    int changeGroupCount = changeGroupRepo.findTotalCountById(id);

    // do not delete if ONLY 1 Change Group exists
    if (changeGroupCount == 1) {
      ChangeGroup changeGroupEntity =
          changeGroupRepo
              .findById(id)
              .orElseThrow(
                  () ->
                      new NotFoundException(
                          String.format("Cannot locate Change Group by id '%s'", id), Level.ERROR));

      throw new NotAcceptableException(
          "Cannot delete Change Group '"
              + changeGroupEntity.getName()
              + "'. Project must contain at least one Change Group.",
          Level.WARN);
    } else {
      changeGroupRepo.deleteById(id);
    }
  }

  public List<ComponentDto> findComponentsByChangeGroupAndNodeName(
      ChangeGroup changeGroup, String nodeName) {
    int numberOfAircraftsInChangeGroup = changeGroup.getAircraftChangeGroups().size();
    List<Component> components = componentService.findByNodeIds(getNodeIds(changeGroup, nodeName));
    List<ComponentDto> componentDtos = new ArrayList<>();

    // verify Node Name exists
    if (nodeName == null || nodeName.isEmpty()) {
      throw new BadRequestException("Node Name cannot be empty.", Level.ERROR);
    }

    boolean isExistingNonDeletedNode =
        changeGroup.getChanges().stream()
            .anyMatch(
                change ->
                    change.getNodeChange() != null
                        && change.getNodeChange().getName().equalsIgnoreCase(nodeName)
                        && !change.getAction().equals(ActionType.DELETE));

    // no components exist
    if (isExistingNonDeletedNode || components.isEmpty()) {
      // check if any component changes exists for this node
      List<Change> matchingComponentChanges =
          changeGroup.getChanges().stream()
              .filter(
                  change ->
                      change.getComponentChange() != null
                          && change.getNodeName() != null
                          && change.getNodeName().equalsIgnoreCase(nodeName)
                          && !change.getAction().equals(ActionType.DELETE))
              .collect(Collectors.toList());

      // if matching component change(s) then merge into response
      if (!matchingComponentChanges.isEmpty()) {
        appendComponentChangesToComponentDtos(componentDtos, matchingComponentChanges);
        return componentDtos;
      }

      return Collections.emptyList();
    }

    // get total count of each component to determine "isGlobal" checker
    Map<String, Long> componentCounts =
        components.stream()
            .collect(
                Collectors.groupingBy(
                    this::getUniqueComponentKey, Collectors.summingLong(x -> 1L)));

    // reduce to distinct components
    Set<String> distinctComps = new HashSet<>();
    componentDtos =
        components.stream()
            .filter(c -> distinctComps.add(getUniqueComponentKey(c)))
            .map(
                c -> {
                  ComponentDto dto = ComponentDtoConverter.convertComponentToComponentDto(c);
                  dto.setIsGlobal(
                      numberOfAircraftsInChangeGroup
                          == componentCounts.get(getUniqueComponentKey(c)).intValue());
                  return dto;
                })
            .collect(Collectors.toList());

    // add loads to components
    addLoadsToComponentDtos(componentDtos, components);

    // merge changes to list
    addChangesToComponentDtos(changeGroup, nodeName, componentDtos);

    componentDtos.sort(comparing(ComponentDto::getDisplayOrder, nullsLast(naturalOrder())));
    return componentDtos;
  }

  @Override
  public List<FleetDto> findParentFleets(UUID changeGroupId) {
    Optional<ChangeGroup> changeGroupEntity = findById(changeGroupId);
    if (changeGroupEntity.isPresent()) {
      List<FleetDto> fleetDtos =
          changeGroupEntity.get().getAircraftChangeGroups().stream()
              .map(acg -> findParentFleet(acg.getAircraft().getFleet()))
              .distinct()
              .map(FleetDtoConverter::convertToDto)
              .collect(Collectors.toList());

      // add fleet metadata
      fleetDtos.forEach(
          fleet -> {
            Map<String, Set<String>> metadata = new HashMap<>();

            nodeStructureRepository
                .findByStructureNameAndParentNodeStructure(fleet.getStructureName(), null).stream()
                .flatMap(NodeStructure::streamNodeStructures)
                .forEach(
                    sn -> {
                      NodeType nodeType = sn.getNodeType();
                      if (nodeType != null) {
                        if (!metadata.containsKey("nodeTypes")) {
                          metadata.put("nodeTypes", new HashSet<>());
                        }
                        metadata.get("nodeTypes").add(sn.getNodeType().toString());
                      }
                      VoltageType voltageType = sn.getVoltageType();
                      if (voltageType != null) {
                        if (!metadata.containsKey("voltageTypes")) {
                          metadata.put("voltageTypes", new HashSet<>());
                        }
                        metadata.get("voltageTypes").add(voltageType.toString());
                        Double voltage = sn.getVoltage();
                        if (voltage != null) {
                          if (!metadata.containsKey("voltages" + voltageType)) {
                            metadata.put("voltages" + voltageType, new HashSet<>());
                          }
                          metadata.get("voltages" + voltageType).add(voltage.toString());
                        }
                      }
                    });
            fleet.setMetadata(metadata);
          });
      return fleetDtos;
    }
    return Collections.emptyList();
  }

  /**
   * Updates the change group alias name (user-friendly version)
   *
   * @param id - Unique ChangeGroup Entity identifier
   * @param name - User Friendly name of Change Group
   */
  @Transactional
  public void updateChangeGroupName(UUID id, String name) {
    ChangeGroup changeGroup =
        changeGroupRepo
            .findById(id)
            .orElseThrow(
                () -> new NotFoundException("Change Group '" + id + "' not found.", Level.ERROR));

    // verify name exists and is not empty
    if (name == null || name.isEmpty()) {
      throw new BadRequestException("Change Group Name cannot be blank.", Level.ERROR);
    }

    // verify name is unique
    boolean isDuplicate =
        changeGroup.getProject().getChangeGroups().stream()
            .anyMatch(cg -> cg.getName().equalsIgnoreCase(name));

    if (isDuplicate) {
      throw new ConflictException(
          "Change Group name already exists, please enter a unique name for the Change Group.",
          Level.ERROR);
    }

    // save
    changeGroup.setName(name);
  }

  private void appendComponentChangesToComponentDtos(
      List<ComponentDto> componentDtos, List<Change> matchingChanges) {
    for (Change change : matchingChanges) {
      ActionType action = change.getAction();

      // add new changes
      if (action == ActionType.ADD) {
        ComponentDto componentDto =
            convertComponentChangeToComponentDto(change.getComponentChange());
        componentDto.setIsGlobal(true);
        componentDtos.add(componentDto);
      }

      // verify a matching component exists
      ComponentDto matchingComponentDto =
          componentDtos.stream()
              .filter(
                  componentDto ->
                      getUniqueComponentKey(componentDto).equals(getUniqueComponentKey(change)))
              .findFirst()
              .orElseThrow(
                  () ->
                      new NotFoundException(
                          "Could not locate a matching Component ("
                              + change.getComponentChange().getElectricalPhase()
                              + " "
                              + change.getComponentElectIdent()
                              + ").",
                          Level.ERROR));

      addComponentAndLoadChangesToComponentDto(matchingComponentDto, change);
    }
  }

  private void addChangesToComponentDtos(
      ChangeGroup changeGroup, String nodeName, List<ComponentDto> componentDtos) {

    // get changes by nodeName
    List<Change> matchingChanges =
        changeGroup.getChanges().stream()
            .filter(
                change ->
                    change.getComponentChange() != null
                        && change.getNodeName() != null
                        && change.getNodeName().equalsIgnoreCase(nodeName))
            .collect(Collectors.toList());

    // add matching changes to dto
    appendComponentChangesToComponentDtos(componentDtos, matchingChanges);
  }

  private void addComponentAndLoadChangesToComponentDto(ComponentDto componentDto, Change change) {
    // is component change
    if (change.getComponentChange() == null) {
      throw new NotAcceptableException(
          "No Component Change found for Change (" + change.getId() + ").", Level.ERROR);
    }

    // update fields from change record
    ComponentChange componentChange = change.getComponentChange();

    // set action for all actionTypes
    componentDto.setAction(change.getAction());
    componentDto.setChangeId(change.getId());

    // apply component changes
    if (componentDto.getAction() == ActionType.EDIT) {
      applyComponentChangesToComponentDto(componentDto, componentChange);
    }

    // check if LoadChanges exist
    if (!componentChange.getLoadChanges().isEmpty()) {
      // if EDIT component and Component Entity was intermittent but is no longer
      // and Loads is empty then copy change Loads to ComponentDto
      if (componentDto.getAction() == ActionType.EDIT
          && componentDto.getLoads().isEmpty()
          && !componentDto.getIntermittent()) {
        componentDto.setLoads(
            LoadDtoConverter.convertLoadChangesToLoadDtos(componentChange.getLoadChanges()));
      }

      for (LoadChange loadChange : change.getComponentChange().getLoadChanges()) {
        LoadDto loadDto =
            componentDto.getLoads().stream()
                .filter(
                    cdto ->
                        cdto.getFlightPhase().equalsIgnoreCase(loadChange.getFlightPhase())
                            && cdto.getOperatingMode()
                                .equalsIgnoreCase(loadChange.getOperatingMode()))
                .findFirst()
                .orElseThrow(
                    () ->
                        new NotFoundException(
                            "Load not found based on Flight Phase ("
                                + loadChange.getFlightPhase()
                                + ") and Operating Mode ("
                                + loadChange.getOperatingMode()
                                + ").",
                            Level.ERROR));

        // Loads should ALWAYS be present (business rule)
        loadDto.setAction(componentDto.getAction());

        // update existing load object with loadChange values
        if (loadDto.getAction() == ActionType.EDIT) {
          if (!loadDto.getVa().equals(loadChange.getVa())
              || !loadDto.getPowerFactor().equals(loadChange.getPowerFactor())) {
            loadDto.setVa(loadChange.getVa());
            loadDto.setPowerFactor(loadChange.getPowerFactor());
            loadDto.setEdited(true);
          }
        }
      }
    }
  }

  private void addLoadsToComponentDtos(
      List<ComponentDto> componentDtos, List<Component> components) {
    List<Load> loads =
        loadRepository.getLoadsInComponents(
            components.stream().map(Component::getId).collect(Collectors.toList()));

    Map<Component, List<Load>> loadsByComponent = nodeService.getLoadsByComponent(loads);
    Map<String, List<Load>> loadsByElectIdent = new HashMap<>();
    for (Map.Entry<Component, List<Load>> entry : loadsByComponent.entrySet()) {
      loadsByElectIdent
          .computeIfAbsent(entry.getKey().getElectIdent(), (x -> new ArrayList<>()))
          .addAll(entry.getValue());
    }

    componentDtos.forEach(
        c -> {
          List<Load> loadsByComp = loadsByElectIdent.get(c.getElectIdent());
          if (loadsByComp != null) {
            Map<String, Load> loadMap = new HashMap<>();

            // filter list to only include loads related to electrical phase
            loadsByComp =
                loadsByComp.stream()
                    .filter(
                        l -> l.getComponent().getElectricalPhase().equals(c.getElectricalPhase()))
                    .collect(Collectors.toList());

            // remove duplicate loads for same flight phase / operating mode
            for (Iterator<Load> iter = loadsByComp.iterator(); iter.hasNext(); ) {
              Load load = iter.next();

              // generate unique key
              String key = getUniqueLoadKey(load);

              // check if key exists already
              if (loadMap.containsKey(key)) {
                Load savedLoad = loadMap.get(key);

                // in order for UI to safely allow editing of components,
                // API must return the lowest VA value to assure
                // its below the components nominalPower total
                // (existing validation checks VA <= nominalPower)
                if (load.getVa() < savedLoad.getVa()) {
                  loadMap.replace(key, load);
                }
              } else {
                loadMap.put(key, load);
              }
            }

            // get list of loads from HashMap
            List<Load> finalLoads = new ArrayList<>(loadMap.values());

            c.setLoads(LoadDtoConverter.convertLoadToLoadDto(finalLoads));
          }
        });
  }

  private void addComponentChangesToChangeGroupNodeDtos(
      List<Change> changes, List<ChangeGroupNodeDto> nodeList) {
    List<Change> matchingComponentChanges =
        changes.stream()
            .filter(change -> change.getComponentChange() != null)
            .collect(Collectors.toList());

    // iterate Component Changes
    for (Change change : matchingComponentChanges) {
      ActionType action = change.getAction();

      // verify ActionType is not empty
      if (action.toString().isEmpty()) {
        throw new NotFoundException("ActionType ( " + action + " ) not found.", Level.ERROR);
      }

      // get matching Node
      String matchingNodeName = change.getNodeName();
      ChangeGroupNodeDto matchingNode = findNode(nodeList, matchingNodeName);

      // verify node is found
      if (matchingNode == null) {
        throw new NotFoundException("No match found for Node name (" + matchingNodeName + ").");
      }

      // convert ComponentChange to ComponentDto
      String matchingComponentElectIdent = change.getComponentElectIdent();
      ComponentChange componentChange = change.getComponentChange();
      ComponentDto componentDto = convertComponentChangeToComponentDto(componentChange);

      // set action
      componentDto.setAction(action);

      switch (action) {
        case ADD:
          matchingNode.addComponentDto(componentDto);
          break;
        case EDIT:
        case DELETE:
          // find matching ComponentDto
          ComponentDto matchingComponentDto =
              nodeList.stream()
                  .flatMap(ChangeGroupNodeDto::streamNodes)
                  .filter(x -> x.getName().equals(matchingNodeName))
                  .map(ChangeGroupNodeDto::getComponentDtos)
                  .filter(Objects::nonNull)
                  .flatMap(Collection::stream)
                  .filter(
                      componentDto2 ->
                          componentDto2
                              .getElectIdent()
                              .equalsIgnoreCase(matchingComponentElectIdent))
                  .findFirst()
                  .orElseThrow(
                      () ->
                          new NotFoundException(
                              "Cannot locate Component (" + matchingComponentElectIdent + ")",
                              Level.ERROR));

          matchingComponentDto.setAction(action);

          // update edited component values
          if (action == ActionType.EDIT) {
            applyComponentChangesToComponentDto(matchingComponentDto, componentChange);
          }
          break;
        default:
          // should never hit this section bc a change should contain an action but track just in
          // case
          throw new BadRequestException("No action (ADD, EDIT, DELETE) found Change.", Level.ERROR);
      }
    }
  }

  private void addNodeChangesToChangeGroupNodeDtos(
      List<Change> changes, List<ChangeGroupNodeDto> nodeList) {
    List<Change> matchingNodeChanges =
        changes.stream()
            .filter(change -> change.getNodeChange() != null)
            .sorted(Comparator.comparing(Change::getCreated))
            .collect(Collectors.toList());

    // iterate Node Changes
    for (Change change : matchingNodeChanges) {
      ActionType action = change.getAction();

      // verify ActionType is not empty
      if (action.toString().isEmpty()) {
        throw new NotFoundException("ActionType ( " + action + " ) not found.", Level.ERROR);
      }

      String matchingNodeName = change.getNodeName(); // will be blank for root level nodes
      NodeChange nodeChange = change.getNodeChange();

      // check if matching Node is found
      ChangeGroupNodeDto matchingNode = new ChangeGroupNodeDto();

      boolean isRootLevelNode = matchingNodeName == null || matchingNodeName.isEmpty();

      if (!isRootLevelNode) {
        matchingNode = findNode(nodeList, matchingNodeName);
      }

      if (action == ActionType.ADD) {
        ChangeGroupNodeDto newChangeGroupNodeDto = convertNodeChangeToDto(nodeChange);

        // set action
        newChangeGroupNodeDto.setAction(action);
        newChangeGroupNodeDto.setChangeId(change.getId());

        // non-root level node
        if (!isRootLevelNode) {
          newChangeGroupNodeDto.setIsGlobal(matchingNode.getIsGlobal());
          matchingNode.addChangeGroupNodeDto(newChangeGroupNodeDto);
        } else {
          newChangeGroupNodeDto.setIsGlobal(true);
          nodeList.add(newChangeGroupNodeDto);
        }
      } else if (action == ActionType.EDIT) {
        if (matchingNode == null) {
          throw new NotFoundException("No match found for Node name (" + matchingNodeName + ").");
        }

        // set action
        matchingNode.setAction(action);
        matchingNode.setChangeId(change.getId());

        // updated changed fields to matching node
        applyNodeChangesToDto(matchingNode, nodeChange);
      } else if (action == ActionType.DELETE) {
        if (matchingNode == null) {
          throw new NotFoundException("No match found for Node name (" + matchingNodeName + ").");
        }

        // set action
        matchingNode.setAction(action);
        matchingNode.setChangeId(change.getId());
      } else {
        throw new BadRequestException("No action (ADD, EDIT, DELETE) found Change.", Level.ERROR);
      }
    }
  }

  private void applyComponentChangesToComponentDto(
      ComponentDto componentDto, ComponentChange componentChangeEntity) {
    if (!componentDto.getElectIdent().equalsIgnoreCase(componentChangeEntity.getElectIdent())) {
      componentDto.setElectIdent(componentChangeEntity.getElectIdent());
      componentDto.addEditedField("electIdent");
    }

    if (!componentDto.getAta().equalsIgnoreCase(componentChangeEntity.getAta())) {
      componentDto.setAta(componentChangeEntity.getAta());
      componentDto.addEditedField("ata");
    }

    if (componentDto.getClipsed() != componentChangeEntity.getClipsed()) {
      componentDto.setClipsed(componentChangeEntity.getClipsed());
      componentDto.addEditedField("clipsed");
    }

    if (componentDto.getIntermittent() != componentChangeEntity.getIntermittent()) {
      componentDto.setIntermittent(componentChangeEntity.getIntermittent());
      componentDto.addEditedField("intermittent");
    }

    if (FieldValidator.isDoublesChanged(
        componentDto.getNominalPower(), componentChangeEntity.getNominalPower())) {
      componentDto.setNominalPower(componentChangeEntity.getNominalPower());
      componentDto.addEditedField("nominalPower");
    }

    if (FieldValidator.isDoublesChanged(
        componentDto.getConnectedLoadVa(), componentChangeEntity.getConnectedLoadVa())) {
      componentDto.setConnectedLoadVa(componentChangeEntity.getConnectedLoadVa());
      componentDto.addEditedField("connectedLoadVa");
    }

    if (FieldValidator.isDoublesChanged(
        componentDto.getConnectedLoadPf(), componentChangeEntity.getConnectedLoadPf())) {
      componentDto.setConnectedLoadPf(componentChangeEntity.getConnectedLoadPf());
      componentDto.addEditedField("connectedLoadPf");
    }

    if (!componentDto.getPanel().equalsIgnoreCase(componentChangeEntity.getPanel())) {
      componentDto.setPanel(componentChangeEntity.getPanel());
      componentDto.addEditedField("panel");
    }

    if (!componentDto.getName().equalsIgnoreCase(componentChangeEntity.getName())) {
      componentDto.setName(componentChangeEntity.getName());
      componentDto.addEditedField("name");
    }

    if (componentDto.getElectricalPhase() != componentChangeEntity.getElectricalPhase()) {
      componentDto.setElectricalPhase(componentChangeEntity.getElectricalPhase());
      componentDto.addEditedField("electricalPhase");
    }

    if (componentDto.getSheddable() != componentChangeEntity.getSheddable()) {
      componentDto.setSheddable(componentChangeEntity.getSheddable());
      componentDto.addEditedField("sheddable");
    }
  }

  private void applyNodeChangesToDto(ChangeGroupNodeDto matchingNode, NodeChange nodeChange) {
    if (!matchingNode.getName().equalsIgnoreCase(nodeChange.getName())) {
      matchingNode.setName(nodeChange.getName());
      matchingNode.addEditedField("name");
    }

    if ((matchingNode.getBusRating() == null && nodeChange.getBusRating() != null)
        || !matchingNode.getBusRating().equals(nodeChange.getBusRating())) {
      matchingNode.setBusRating(nodeChange.getBusRating());
      matchingNode.addEditedField("busRating");
    }

    if ((matchingNode.getNominalPower() == null && nodeChange.getNominalPower() != null)
        || !matchingNode.getNominalPower().equals(nodeChange.getNominalPower())) {
      matchingNode.setNominalPower(nodeChange.getNominalPower());
      matchingNode.addEditedField("nominalPower");
    }

    if (!matchingNode.getNodeType().equals(nodeChange.getNodeType())) {
      matchingNode.setNodeType(nodeChange.getNodeType());
      matchingNode.addEditedField("nodeType");
    }

    if (!matchingNode.getVoltage().equals(nodeChange.getVoltage())) {
      matchingNode.setVoltage(nodeChange.getVoltage());
      matchingNode.addEditedField("voltage");
    }

    if (!matchingNode.getVoltageType().equals(nodeChange.getVoltageType())) {
      matchingNode.setVoltageType(nodeChange.getVoltageType());
      matchingNode.addEditedField("voltageType");
    }

    if ((matchingNode.getElectricalPhase() == null && nodeChange.getElectricalPhase() != null)
        || !matchingNode.getElectricalPhase().equals(nodeChange.getElectricalPhase())) {
      matchingNode.setElectricalPhase(nodeChange.getElectricalPhase());
      matchingNode.addEditedField("electricalPhase");
    }

    if (matchingNode.isSheddable() != nodeChange.isSheddable()) {
      matchingNode.setSheddable(nodeChange.isSheddable());
      matchingNode.addEditedField("sheddable");
    }

    if (matchingNode.isRequiresApproval() != nodeChange.isRequiresApproval()) {
      matchingNode.setRequiresApproval(nodeChange.isRequiresApproval());
      matchingNode.addEditedField("requiresApproval");
    }
  }

  /**
   * this method is called when we update effectivity for a change group.
   *
   * @param currentChangeGroup if null, we're setting effectivity for a new change group
   * @param aircrafts list of aircraft, can be a super/sub-set of the aircraft in the change groups,
   *     represents the effectivity of the change group as a whole pre-bucketing.
   * @return
   */
  private List<AircraftBusStructureBucketDto> createAircraftBusStructureBucketDtos(
      ChangeGroup currentChangeGroup, List<Aircraft> aircrafts) {
    Map<String, AircraftBusStructureBucketDto> buckets = new HashMap<>();

    // This list will contain aircraft to add to the change group effectivity.
    // Initially, it's just a shallow copy of the total effectivity.
    List<Aircraft> newAircraft = new ArrayList<>(aircrafts);
    // if the passed-in change group is non-null, we'll pre-fill one
    // bucket with the aircraft in that change group
    if (currentChangeGroup != null) {
      // prepopulate a bucket with the passed-in change group
      currentChangeGroup
          .getAircraftChangeGroups()
          .forEach(
              acg -> {
                // we'll prune out existing aircraft already in the change
                // group from the aircraft to add.  If the change group
                // contains an aircraft that's *not* in the updated effectivity,
                // it indicates it's been removed and we'll exclude it from being put
                // into a bucket.
                if (newAircraft.remove(acg.getAircraft())) {
                  // note here how we always use the fleet's bus structure bucket name
                  // as the bucket map *key*, but we'll preserve the change group
                  // name (in the case where it's custom) for naming the bucket map *value*
                  putAircraftInBucket(
                      buckets,
                      getBusStructureBucketName(acg.getAircraft().getFleet()),
                      currentChangeGroup.getName(),
                      acg.getAircraft());
                }
              });
    }
    for (Aircraft aircraft : newAircraft) {
      // new buckets get created with the fleet naming convention
      String bucketName = getBusStructureBucketName(aircraft.getFleet());
      // note here how any *new* bucket that is made, the resulting change group
      // name will be the same as the bucket name.
      putAircraftInBucket(buckets, bucketName, bucketName, aircraft);
    }
    return new ArrayList<>(buckets.values());
  }

  private void putAircraftInBucket(
      Map<String, AircraftBusStructureBucketDto> buckets,
      String bucketName,
      String changeGroupName,
      Aircraft aircraft) {
    buckets.compute(
        bucketName,
        (k, v) -> {
          if (v == null) {
            // new bucket
            return createAircraftBusStructureBucketDto(aircraft, changeGroupName);
          } else {
            // existing bucket just add the aircraft to the list
            v.getAircrafts().add(aircraft);
            return v;
          }
        });
  }

  private AircraftBusStructureBucketDto createAircraftBusStructureBucketDto(
      Aircraft aircraft, String bucketName) {
    AircraftBusStructureBucketDto newItem = new AircraftBusStructureBucketDto();
    newItem.setName(bucketName);

    List<Aircraft> newAircraft = Lists.newArrayList(aircraft);
    newItem.setAircraft(newAircraft);

    return newItem;
  }

  private ChangeGroupNodeDto findNode(List<ChangeGroupNodeDto> changeGroupNodeDtos, String name) {
    return changeGroupNodeDtos.stream()
        .flatMap(ChangeGroupNodeDto::streamNodes)
        .filter(x -> x.getName().equals(name))
        .findFirst()
        .orElse(null);
  }

  private Set<String> findDuplicateAircraftsInChangeGroups(
      List<ChangeGroup> projectChangeGroups, List<Aircraft> changeGroupAircrafts) {

    List<UUID> projectChangeGroupIds =
        projectChangeGroups.stream().map(ChangeGroup::getId).collect(Collectors.toList());

    List<Aircraft> existingChangeGroupEffectivies =
        aircraftChangeGroupService.findAllByChangeGroupIdIn(projectChangeGroupIds).stream()
            .map(AircraftChangeGroup::getAircraft)
            .collect(Collectors.toList());

    return findAircraftShipNoForDuplicateAircraftsInAircraftList(
        existingChangeGroupEffectivies, changeGroupAircrafts);
  }

  private Set<String> findDuplicateAircraftsInOtherChangeGroups(
      List<ChangeGroup> projectChangeGroups,
      List<Aircraft> changeGroupAircrafts,
      UUID changeGroupId) {
    List<UUID> projectChangeGroupIds =
        projectChangeGroups.stream()
            .filter(changeGroup -> !changeGroup.getId().equals(changeGroupId))
            .map(ChangeGroup::getId)
            .collect(Collectors.toList());

    List<Aircraft> existingChangeGroupEffectivies =
        aircraftChangeGroupService.findAllByChangeGroupIdIn(projectChangeGroupIds).stream()
            .map(AircraftChangeGroup::getAircraft)
            .collect(Collectors.toList());

    return findAircraftShipNoForDuplicateAircraftsInAircraftList(
        existingChangeGroupEffectivies, changeGroupAircrafts);
  }

  private Set<String> findAircraftShipNoForDuplicateAircraftsInAircraftList(
      List<Aircraft> existingChangeGroupEffectivies, List<Aircraft> newAircrafts) {
    return existingChangeGroupEffectivies.stream()
        .distinct()
        .filter(newAircrafts::contains)
        .map(Aircraft::getAircraftShipNo)
        .collect(Collectors.toSet());
  }

  /**
   * Performs mapping from SQL Dto response to Dto for ChangeGroup Effectivities
   *
   * @param changeGroup - Entity used to filter resultset
   * @return Unique List of Nodes for a ChangeGroup in the form of [ChangeGroupNodeDto] Dto
   */
  private List<ChangeGroupNodeDto> findChangeGroupNodeDtosByChangeGroupId(ChangeGroup changeGroup) {
    List<ChangeGroupNodeDto> result = new ArrayList<>();

    // verify aircraft count matches ELA count
    List<Long> elaIds =
        elaService.findDistinctElaIdByAircraftChangeGroups(changeGroup.getAircraftChangeGroups());
    int numberOfAircraftsInChangeGroup = changeGroup.getAircraftChangeGroups().size();

    if (elaIds.isEmpty()) {
      throw new BadRequestException(
          "Cannot locate any ELAs for Change Group (" + changeGroup.getId() + ")", Level.ERROR);
    } else if (elaIds.size() != numberOfAircraftsInChangeGroup) {
      // TODO: Do we need to return the exact effectivities that are not found as matching ELA??
      throw new NotAcceptableException(
          "Change Group Effectivity count ("
              + numberOfAircraftsInChangeGroup
              + ") does not match ELA count ("
              + elaIds.size()
              + "). Please adjust selected Effectivities.",
          Level.ERROR);
    } else {
      // contains all nodes for each aircraft (likely has duplicates)
      List<ChangeGroupMappedNodeDto> rawNodeList = getAllNodeDtoByElaId(elaIds);

      // get total count of each node to determine "isGlobal" checker
      Map<String, Long> valueCounts =
          rawNodeList.stream()
              .collect(
                  Collectors.groupingBy(
                      ChangeGroupMappedNodeDto::getFullName, Collectors.summingLong(x -> 1L)));

      // set isGlobal value
      for (ChangeGroupMappedNodeDto changeGroupMappedNodeDto : rawNodeList) {
        if (valueCounts.containsKey(changeGroupMappedNodeDto.getFullName())) {
          Long occurrences = valueCounts.get(changeGroupMappedNodeDto.getFullName());

          changeGroupMappedNodeDto.setIsGlobal(
              numberOfAircraftsInChangeGroup == occurrences.intValue());
        }
      }

      // get all related components	across every node (by nodeId)
      List<Component> components =
          componentService.findByNodeIds(
              rawNodeList.stream()
                  .map(ChangeGroupMappedNodeDto::getId)
                  .collect(Collectors.toList()));

      // get total count of each component to determine "isGlobal" checker
      Map<String, Long> componentCounts =
          components.stream()
              .collect(
                  Collectors.groupingBy(
                      this::getUniqueComponentKey, Collectors.summingLong(x -> 1L)));

      // get distinct nodes
      Map<String, List<ChangeGroupMappedNodeDto>> nodes =
          rawNodeList.stream()
              .filter(distinctByKey(ChangeGroupMappedNodeDto::getFullName))
              .collect(Collectors.groupingBy(ChangeGroupMappedNodeDto::getName));

      // flatten map (unordered list)
      List<ChangeGroupMappedNodeDto> nodeListFlat = new ArrayList<>();
      nodes.values().forEach(nodeListFlat::addAll);

      // re-order collection by hierarchy levels
      List<ChangeGroupMappedNodeDto> nodeList =
          nodeListFlat.stream()
              .sorted(
                  Comparator.comparing(ChangeGroupMappedNodeDto::getLevel)
                      .thenComparing(ChangeGroupMappedNodeDto::getDisplayOrder)
                      .thenComparing(ChangeGroupMappedNodeDto::getFullName))
              .collect(Collectors.toList());

      if (!nodeList.isEmpty()) {
        // iterate over rawNodeList
        for (ChangeGroupMappedNodeDto node : nodeList) {
          String[] levels = node.getFullName().split("\\|");
          int levelCount = levels.length;

          if (levelCount == 1) {
            result.add(
                new ChangeGroupNodeDto(
                    levels[0],
                    Lists.newArrayList(),
                    Lists.newArrayList(),
                    node.getDescription(),
                    node.getIsGlobal(),
                    node.getVoltage(),
                    node.getNominalPower(),
                    node.getNodeType(),
                    node.isRequiresApproval(),
                    node.getBusRating(),
                    node.isSheddable(),
                    node.getVoltageType(),
                    node.isNormalTr(),
                    node.getElectricalPhase()));
          } else {
            List<ChangeGroupNodeDto> localChangeGroups = result;

            // iterate over levels
            for (int i = 0; i < levelCount; i++) {
              String level = levels[i];

              if (i + 1 == levelCount) {

                List<ComponentDto> componentDtos =
                    components.stream()
                        .filter(
                            component ->
                                component.getNode().getName().equalsIgnoreCase(node.getName()))
                        .map(
                            c -> {
                              ComponentDto dto =
                                  ComponentDtoConverter.convertComponentToComponentDto(c);
                              dto.setIsGlobal(
                                  numberOfAircraftsInChangeGroup
                                      == componentCounts.get(getUniqueComponentKey(c)).intValue());
                              // clear loads
                              dto.setLoads(Collections.emptyList());
                              return dto;
                            })
                        .collect(Collectors.toList());

                localChangeGroups.add(
                    new ChangeGroupNodeDto(
                        node.getName(),
                        Lists.newArrayList(),
                        componentDtos,
                        node.getDescription(),
                        node.getIsGlobal(),
                        node.getVoltage(),
                        node.getNominalPower(),
                        node.getNodeType(),
                        node.isRequiresApproval(),
                        node.getBusRating(),
                        node.isSheddable(),
                        node.getVoltageType(),
                        node.isNormalTr(),
                        node.getElectricalPhase()));
                break;
              }

              // find matching Change Group
              Optional<ChangeGroupNodeDto> match =
                  localChangeGroups.stream()
                      .filter(f -> f.getName().equalsIgnoreCase(level))
                      .findFirst();

              if (match.isPresent()) {
                localChangeGroups = match.get().getChangeGroupNodeDto();
              }
            }
          }
        }
      }

      return result;
    }
  }

  private Fleet findParentFleet(Fleet fleet) {
    if (fleet.getParentFleet() == null) {
      return fleet;
    }
    return findParentFleet(fleet.getParentFleet());
  }

  private List<ChangeGroupMappedNodeDto> getAllNodeDtoByElaId(List<Long> elaIds) {
    return elaIds.isEmpty()
        ? Collections.emptyList()
        : changeGroupEffectivityDao.findChangeGroupEffectivities(elaIds);
  }

  private String getBusStructureBucketName(Fleet fleet) {
    while (fleet != null) {
      if (fleet.getBusStructureBucket() != null && !fleet.getBusStructureBucket().isEmpty()) {
        return fleet.getBusStructureBucket();
      }
      fleet = fleet.getParentFleet();
    }
    return DEFAULT_CHANGE_GROUP_BUCKET_NAME;
  }

  private List<Long> getNodeIds(ChangeGroup changeGroup, String nodeName) {
    List<Long> elaIds =
        elaService.findDistinctElaIdByAircraftChangeGroups(changeGroup.getAircraftChangeGroups());
    return getAllNodeDtoByElaId(elaIds).stream()
        .filter(n -> n.getName().equals(nodeName))
        .map(ChangeGroupMappedNodeDto::getId)
        .collect(Collectors.toList());
  }

  private void isRemovingAllEffectivityFromChangeGroup(
      List<AircraftBusStructureBucketDto> aircraftBusStructureBucketDtos,
      ChangeGroup currentChangeGroup) {

    if (aircraftBusStructureBucketDtos.stream()
        .noneMatch(
            aircraftBusStructureBucketDto ->
                aircraftBusStructureBucketDto.getName().contains(currentChangeGroup.getName()))) {
      throw new NotAcceptableException(
          "Cannot remove all Effectivities from ChangeGroup.", Level.ERROR);
    }
  }

  private ChangeGroup createAndSaveChangeGroup(Project project, String name) {
    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setProject(project);
    newChangeGroup.setName(name);
    return changeGroupRepo.save(newChangeGroup);
  }

  private void saveAircraftChangeGroups(
      List<AircraftBusStructureBucketDto> aircraftBusStructureBucketDtos, Project project) {
    aircraftBusStructureBucketDtos.forEach(
        aircraftBusStructureBucketDto -> {
          String changeGroupName = aircraftBusStructureBucketDto.getName();

          // make change group name unique
          Optional<ChangeGroup> changeGroupEntity =
              changeGroupRepo.findByProjectIdAndChangeGroupName(project, changeGroupName);
          while (changeGroupEntity.isPresent()) {
            // make the new change group name unique
            changeGroupName = incrementChangeGroupName(changeGroupName);
            changeGroupEntity =
                changeGroupRepo.findByProjectIdAndChangeGroupName(project, changeGroupName);
          }

          // save change group
          ChangeGroup newChangeGroup = createAndSaveChangeGroup(project, changeGroupName);

          List<AircraftChangeGroup> aircraftChangeGroups =
              aircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
                  aircraftBusStructureBucketDto, newChangeGroup);
          updateAircraftChangeGroup(newChangeGroup, aircraftChangeGroups);
        });
  }

  private String incrementChangeGroupName(String name) {
    Matcher m = CHANGE_GROUP_NAME_REGEX.matcher(name);
    if (m.matches()) {
      int num = Integer.parseInt(m.group(2));
      num++;
      return m.replaceFirst("$1" + num);
    }
    return name + " 1";
  }

  private String getChangeGroupManufacturer(String name) {
    Matcher m = CHANGE_GROUP_NAME_REGEX.matcher(name);
    if (m.lookingAt()) {
      return m.group(1).trim();
    }

    return name;
  }

  private void updateChangeGroups(
      List<AircraftBusStructureBucketDto> aircraftBusStructureBucketDtos,
      List<ChangeGroup> projectChangeGroups,
      UUID changeGroupId,
      UUID projectId) {
    // Loop through buckets and apply update
    for (AircraftBusStructureBucketDto aircraftBusStructureBucketDto :
        aircraftBusStructureBucketDtos) {
      ChangeGroup changeGroupResult =
          projectChangeGroups.stream()
              .filter(
                  changeGroup ->
                      changeGroup
                          .getName()
                          .equalsIgnoreCase(aircraftBusStructureBucketDto.getName()))
              .findFirst()
              .orElseGet(
                  () ->
                      createAndSaveChangeGroup(
                          projectService.findById(projectId).get(),
                          aircraftBusStructureBucketDto.getName()));

      updateAircraftChangeGroups(aircraftBusStructureBucketDto, changeGroupResult, changeGroupId);
    }
  }

  private void updateAircraftChangeGroups(
      AircraftBusStructureBucketDto aircraftBusStructureBucketDto,
      ChangeGroup matchingChangeGroup,
      UUID changeGroupId) {
    List<AircraftChangeGroup> newAircraftChangeGroups =
        aircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDto, matchingChangeGroup);

    // is this the actual Change Group from uri
    if (matchingChangeGroup.getId().equals(changeGroupId)) {
      // override existing list
      updateAircraftChangeGroup(matchingChangeGroup, newAircraftChangeGroups);
    } else {
      // append to existing ChangeGroup Aircrafts
      // otherwise it will override the existing list
      List<AircraftChangeGroup> aircraftChangeGroups =
          matchingChangeGroup.getAircraftChangeGroups();
      aircraftChangeGroups.addAll(newAircraftChangeGroups);

      // save
      for (AircraftChangeGroup aircraftChangeGroup :
          matchingChangeGroup.getAircraftChangeGroups()) {
        aircraftChangeGroupService.save(aircraftChangeGroup);
      }
    }
  }

  private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
    Set<Object> seen = ConcurrentHashMap.newKeySet();
    return t -> seen.add(keyExtractor.apply(t));
  }

  private String getUniqueComponentKey(Component c) {
    return c.getNode().getName() + "_" + c.getElectricalPhase() + "_" + c.getElectIdent();
  }

  private String getUniqueComponentKey(ComponentDto c) {
    return c.getElectricalPhase() + "_" + c.getElectIdent();
  }

  private String getUniqueComponentKey(Change c) {
    return c.getComponentChange().getElectricalPhase() + "_" + c.getComponentElectIdent();
  }

  private String getUniqueLoadKey(Load load) {
    return load.getFlightPhase()
        + "|"
        + load.getComponent().getElectricalPhase()
        + "|"
        + load.getOperatingMode();
  }
}
