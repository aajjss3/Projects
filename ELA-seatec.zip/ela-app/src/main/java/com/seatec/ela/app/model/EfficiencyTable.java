package com.seatec.ela.app.model;

import com.seatec.ela.app.model.base.BaseEntity;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "efficiency_table")
public class EfficiencyTable extends BaseEntity {

  @Column(name = "name", nullable = false)
  private String name;

  @Enumerated(EnumType.STRING)
  @Column(name = "efficiency_type")
  private EfficiencyType efficiencyType;

  @ElementCollection(fetch = FetchType.EAGER)
  @CollectionTable(
      name = "efficiency_table_efficiency_load",
      joinColumns = @JoinColumn(name = "id"))
  @OrderBy("current ASC")
  private List<EfficiencyLoad> loads = new ArrayList<>();

  @OneToMany(
      mappedBy = "efficiencyTable",
      cascade = {CascadeType.ALL})
  private List<Node> nodes = new ArrayList<>();

  public EfficiencyTable() {}

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public EfficiencyType getEfficiencyType() {
    return efficiencyType;
  }

  public void setEfficiencyType(EfficiencyType efficiencyType) {
    this.efficiencyType = efficiencyType;
  }

  public List<EfficiencyLoad> getLoads() {
    return loads;
  }

  public void setLoads(List<EfficiencyLoad> loads) {
    this.loads = loads;
  }

  public List<Node> getNodes() {
    return nodes;
  }

  public void setNodes(List<Node> nodes) {
    this.nodes = nodes;
  }

  public void addNode(Node node) {
    nodes.add(node);
    node.setEfficiencyTable(this);
  }

  public void removeNode(Node node) {
    nodes.remove(node);
    node.setEfficiencyTable(null);
  }
}
