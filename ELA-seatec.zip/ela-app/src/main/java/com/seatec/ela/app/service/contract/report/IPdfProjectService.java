package com.seatec.ela.app.service.contract.report;

import com.lowagie.text.pdf.PdfPTable;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import java.util.List;

/** Service for dealing with Reporting Service. */
public interface IPdfProjectService {
  PdfPTable generateCoverPageForProject(Project project);

  PdfPTable generateEffectivitySummary(List<ChangeGroup> changeGroups);
}
