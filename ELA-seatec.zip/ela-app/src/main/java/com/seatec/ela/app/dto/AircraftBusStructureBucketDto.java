package com.seatec.ela.app.dto;

import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.base.BaseEntity;
import java.util.List;
import javax.persistence.*;

public class AircraftBusStructureBucketDto extends BaseEntity implements UserTrackName {

  private String name;

  private List<Aircraft> aircrafts;

  public List<Aircraft> getAircrafts() {
    return aircrafts;
  }

  public void setAircraft(List<Aircraft> aircrafts) {
    this.aircrafts = aircrafts;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
