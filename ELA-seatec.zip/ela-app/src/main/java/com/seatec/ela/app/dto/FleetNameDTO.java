package com.seatec.ela.app.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FleetNameDTO implements Comparable<FleetNameDTO> {

  @JsonIgnore private Long id;
  @JsonIgnore private Long parentId;
  private String name;

  @JsonInclude(Include.NON_EMPTY)
  private List<FleetNameDTO> subFleets = new ArrayList<>();

  public FleetNameDTO(String name, Long id, Long parentId) {
    this.id = id;
    this.parentId = parentId;
    this.name = name;
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getParentId() {
    return parentId;
  }

  public void setParentId(Long parentId) {
    this.parentId = parentId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<FleetNameDTO> getSubFleets() {
    return subFleets;
  }

  public void setSubFleets(List<FleetNameDTO> subFleets) {
    this.subFleets = subFleets;
  }

  public void addSubFleet(FleetNameDTO dto) {
    subFleets.add(dto);
    Collections.sort(subFleets);
  }

  public int compareTo(FleetNameDTO o) {
    return this.getName().compareTo(((FleetNameDTO) o).getName());
  }
}
