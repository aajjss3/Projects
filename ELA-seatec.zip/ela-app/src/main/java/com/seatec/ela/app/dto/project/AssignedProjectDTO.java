package com.seatec.ela.app.dto.project;

import com.seatec.ela.app.util.enumeration.AssignedProjectRole;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class AssignedProjectDTO extends ProjectDTO {

  private AssignedProjectRole role;

  private String fleets;

  public AssignedProjectDTO(
      String id,
      String fleets,
      String title,
      String number,
      String description,
      Instant started,
      Instant submitted,
      String submittedStatus,
      Instant checked,
      String checkedStatus,
      Instant approved,
      String approvedStatus,
      Instant rejected,
      String author,
      String approvalEngineer,
      String checkEngineer,
      List<String> coauthors,
      Instant created,
      List<ProjectCommentDTO> comments) {
    setId(UUID.fromString(id));
    setFleets(fleets);
    setTitle(title);
    setNumber(number);
    setDescription(description);
    setStarted(started);
    setSubmitted(submitted);
    setSubmittedStatus(submittedStatus);
    setChecked(checked);
    setCheckedStatus(checkedStatus);
    setApproved(approved);
    setApprovedStatus(approvedStatus);
    setRejected(rejected);
    setAuthor(author);
    setApprovalEngineer(approvalEngineer);
    setCheckEngineer(checkEngineer);
    setCreated(created);
    setCoauthors(coauthors);
    setComments(comments);
  }

  public AssignedProjectDTO() {}

  public AssignedProjectRole getRole() {
    return role;
  }

  public void setRole(AssignedProjectRole role) {
    this.role = role;
  }

  public String getFleets() {
    return fleets;
  }

  public void setFleets(String fleets) {
    this.fleets = fleets;
  }
}
