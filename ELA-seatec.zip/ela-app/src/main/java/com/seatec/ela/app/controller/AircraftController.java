package com.seatec.ela.app.controller;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.util.AircraftDtoConverter;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.annotation.IdExists;
import com.seatec.ela.app.validator.filter.CreateAircraft;
import com.seatec.ela.app.validator.filter.UpdateAircraft;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/aircrafts")
@Validated
public class AircraftController implements IConstraintViolation {

  @Autowired IAircraftService aircraftService;

  @Autowired
  @Qualifier("mapAll")
  ModelMapper mapper;

  @ExceptionHandler(DataIntegrityViolationException.class)
  ResponseEntity<ErrorWrapperDTO> handle(DataIntegrityViolationException exception) {
    return handleDataIntegrityViolationException(
        exception, "Constraint Violation: Check for Unique aircraftShipNo");
  }

  @GetMapping()
  public List<Aircraft> findAircraft(
      @RequestParam(value = "aircraftShipNo", required = false) String aircraftShipNo,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    return aircraftShipNo == null
        ? aircraftService.findAll(userId)
        : aircraftService.findByAircraftShipNo(aircraftShipNo, userId);
  }

  @GetMapping("/{id}")
  @ResponseStatus(HttpStatus.OK)
  public AircraftDto getAircraftById(@PathVariable("id") Long id) {
    Optional<Aircraft> result = aircraftService.findById(id);
    Aircraft entity = result.orElse(null);
    return AircraftDtoConverter.convertToDto(entity);
  }

  /**
   * Handles creating a new Aircraft
   *
   * @param aircraftDto Represents the new Aircraft and associated values
   * @return AircraftDto
   */
  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public AircraftDto createAircraft(
      @Validated(value = {CreateAircraft.class}) @RequestBody AircraftDto aircraftDto) {
    return AircraftDtoConverter.convertToDto(
        aircraftService.create(
            AircraftDtoConverter.convertToEntity(aircraftDto), aircraftDto.getFleetId()));
  }

  /**
   * Handles updating an existing Aircraft
   *
   * @param aircraftDto Represents the Aircraft and associated values
   * @return AircraftDto
   */
  @PutMapping("/{aircraftId}")
  @ResponseStatus(HttpStatus.OK)
  public AircraftDto updateAircraft(
      @IdExists(entity = Aircraft.class, message = "aircraft id does not exist")
          @PathVariable("aircraftId")
          Long aircraftId,
      @Validated(value = {UpdateAircraft.class}) @RequestBody AircraftDto aircraftDto) {
    return mapper.map(
        aircraftService.update(mapper.map(aircraftDto, Aircraft.class), aircraftId),
        AircraftDto.class);
  }

  @DeleteMapping("/{aircraftId}")
  @ResponseStatus(HttpStatus.OK)
  public void deleteAircraft(
      @IdExists(entity = Aircraft.class, message = "aircraft id does not exist")
          @PathVariable("aircraftId")
          Long aircraftId) {
    aircraftService.deleteById(aircraftId);
  }

  @GetMapping("/cloak")
  public List<Aircraft> findCloakedAircraft(
      @RequestParam(value = "aircraftShipNo", required = false) String aircraftShipNo) {
    return aircraftShipNo == null
        ? aircraftService.findAllCloaked()
        : aircraftService.findCloakedByAircraftShipNoAsc(aircraftShipNo);
  }

  /**
   * cloak or uncloak an aircraft.
   *
   * @param aircraftId
   * @param request
   */
  @PatchMapping({"/{aircraftId}/cloak", "/{aircraftId}/uncloak"})
  @ResponseStatus(HttpStatus.OK)
  public void aircraftCloakOperation(
      @IdExists(entity = Aircraft.class, message = "aircraft id does not exist")
          @PathVariable("aircraftId")
          Long aircraftId,
      HttpServletRequest request) {
    if (request.getServletPath().endsWith("/cloak")) {
      aircraftService.cloak(aircraftId);
    } else if (request.getServletPath().endsWith("/uncloak")) {
      aircraftService.uncloak(aircraftId);
    }
  }
}
