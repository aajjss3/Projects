package com.seatec.ela.app.util;

public class StaticInverterCalculator {

  // suppress default constructor for noninstantiability
  private StaticInverterCalculator() {
    throw new AssertionError();
  }

  /**
   * Convert an AC load on a static inverter to a DC load in Amps.
   *
   * @param voltAmperes - voltAmperes of the AC load to be converted
   * @param powerFactor - power factor of the AC load to be converted
   * @param deratedDCVoltage - derated DC Voltage, depends on the fleet model
   * @param powerEfficiency - power efficiency of the static inverter, depends on the fleet model
   * @return the DC load in Amps
   */
  public static Double calcLoadInAmps(
      Double voltAmperes, Double powerFactor, Double deratedDCVoltage, Double powerEfficiency) {
    return voltAmperes * powerFactor / (deratedDCVoltage * powerEfficiency);
  }
}
