package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummarizedLoad.Units;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.enumeration.PseudoFlightPhase;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.constraints.NotNull;

/** GeneratorLoadSummaryCalculator calculates load summaries for GENERATOR nodes. */
public class GeneratorLoadSummaryCalculator {
  private static final String NOMINAL_POWER = PseudoFlightPhase.NominalPower.toString();
  private static final String CONNECTED_LOAD = PseudoFlightPhase.ConnectedLoad.toString();

  // suppress default constructor for noninstantiability
  private GeneratorLoadSummaryCalculator() {
    throw new AssertionError();
  }

  /**
   * Phase Summary calculations are determined for all flight phases associated with a particular
   * operatingMode and summaryType. Do this for each unique combination of operatingMode and
   * summaryType. Create a SummarizedLoad object for the flight phase with the max imbalance between
   * ACA, ACB and ACC loads. This objects value will be the difference between the max and min
   * loads. Also create a SummarizedLoad object for the flight phase with the max load value for ACA
   * or ACB or ACC and create 2 additional SummarizedLoad objects for the same flight phase but
   * containing the load value associated with its 2 sibling electrical phases. In total Phase
   * Summary calculations will encompass these newly created 4 SummarizedLoad objects for each
   * unique combination of operatingMode and summaryType. NOTE: phase summary calculations are only
   * performed on Generators.
   *
   * @param loadSummaryMap - map containing the load summaries
   * @param loadSummaryOptions - the load summary options
   */
  public static void addPhaseSummariesToLoadSummaries(
      @NotNull Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      @NotNull LoadSummaryOptions loadSummaryOptions) {

    Objects.requireNonNull(loadSummaryMap, "loadSummaryMap must not be null");
    Objects.requireNonNull(loadSummaryOptions, "loadSummaryOptions must not be null");

    // contains all the valid (non null and not for Nominal Power) operatingModes and flightPhases.
    // used by Phase Summary calculations below
    Set<String> flightPhases = new HashSet<>();
    Set<String> operatingModes = new HashSet<>();
    findValidFlightPhasesAndOperatingModes(loadSummaryMap, flightPhases, operatingModes);

    for (String operatingMode : operatingModes) {

      if (loadSummaryOptions.getIncludeComponentsWithoutChildren()) {
        addPhaseSummariesToLoadSummaries(
            loadSummaryMap, operatingMode, flightPhases, SummaryType.COMPONENTS);
      }
      addPhaseSummariesToLoadSummaries(
          loadSummaryMap, operatingMode, flightPhases, SummaryType.COMPONENTS_AND_CHILDREN);
    }
  }

  private static void findValidFlightPhasesAndOperatingModes(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      Set<String> flightPhases,
      Set<String> operatingModes) {

    for (SummarizedLoad loadSummary : loadSummaryMap.values()) {

      String flightPhase = loadSummary.getFlightPhase();
      String operatingMode = loadSummary.getOperatingMode();

      // operatingMode will be null for Nominal Power loadSummaries
      if (operatingMode != null) {
        operatingModes.add(operatingMode);
      }
      if (flightPhase != null
          && !NOMINAL_POWER.equals(flightPhase)
          && !CONNECTED_LOAD.equals(flightPhase)) {
        flightPhases.add(flightPhase);
      }
    }
  }

  private static void addPhaseSummariesToLoadSummaries(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      String operatingMode,
      Set<String> flightPhases,
      SummaryType summaryType) {
    List<SummarizedLoad> filteredSummarizedLoads =
        findAllSummarizedLoadsFor3PhaseElectricalPhases(loadSummaryMap, operatingMode, summaryType);

    List<SummarizedLoad> phaseSummaryMaxSingleLoad =
        createSummarizedLoadsForPhaseSummaryMaxSingleLoad(
            filteredSummarizedLoads, operatingMode, summaryType);

    if (!phaseSummaryMaxSingleLoad.isEmpty()) {
      phaseSummaryMaxSingleLoad.forEach(
          summarizedLoad ->
              loadSummaryMap.put(LoadSummaryBucketKey.from(summarizedLoad), summarizedLoad));
    }
    SummarizedLoad phaseSummaryMaxImbalance =
        createSummarizedLoadForPhaseSummaryMaxLoadImbalance(
            filteredSummarizedLoads, operatingMode, summaryType, flightPhases);
    if (phaseSummaryMaxImbalance != null) {
      loadSummaryMap.put(
          LoadSummaryBucketKey.from(phaseSummaryMaxImbalance), phaseSummaryMaxImbalance);
    }
  }

  /**
   * Find all SummarizedLoad objects for the given operatingMode and summaryType that are either
   * ACA, ACB, ACC. Exclude any SummarizedLoad objects for Nominal Power / Connected Load because
   * their operating modes are null.
   *
   * @param loadSummaryMap - map containing the load summaries
   * @param operatingMode - the operating mode
   * @param summaryType - the summary type of the load summaries
   * @return a list of summarized loads filtered to be ACA, ACB, ACC for the given operating mode
   *     and summary type
   */
  private static List<SummarizedLoad> findAllSummarizedLoadsFor3PhaseElectricalPhases(
      Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap,
      String operatingMode,
      SummaryType summaryType) {
    return loadSummaryMap.values().stream()
        .filter(
            loadSummary ->
                !loadSummary.getFlightPhase().equals(NOMINAL_POWER)
                    && !loadSummary.getFlightPhase().equals(CONNECTED_LOAD)
                    && loadSummary.getSummaryType() == summaryType
                    && (ElectricalPhase.ACA.equals(loadSummary.getElectricalPhase())
                        || ElectricalPhase.ACB.equals(loadSummary.getElectricalPhase())
                        || ElectricalPhase.ACC.equals(loadSummary.getElectricalPhase()))
                    && operatingMode.equalsIgnoreCase(loadSummary.getOperatingMode()))
        .collect(Collectors.toList());
  }

  /**
   * Create 3 SummarizedLoad objects used by the phase summary calculations above for the
   * operatingMode and summaryType passed in. Each of these 3 SummarizedLoad objects holds an ACA,
   * ACB and ACC load for the same flight phase. This flight phase has the max ACA, ACB or ACC load
   * among all flight phases for the given operatingMode and summaryType. The created SummarizedLoad
   * object's value is in Amps
   *
   * @param filteredSummarizedLoads - a list of summarized loads filtered to be ACA, ACB, ACC for
   *     the given operating mode and summary type
   * @param operatingMode - the operating mode
   * @param summaryType - the summary type of the load summaries
   * @return a list of summarized loads
   */
  private static List<SummarizedLoad> createSummarizedLoadsForPhaseSummaryMaxSingleLoad(
      List<SummarizedLoad> filteredSummarizedLoads, String operatingMode, SummaryType summaryType) {

    List<SummarizedLoad> createdPhaseSummaries = new ArrayList<>();

    // find the SummarizedLoad with the greatest single ACA or ACB or ACC load value
    Optional<SummarizedLoad> maxLoad =
        filteredSummarizedLoads.stream().max(Comparator.comparing(SummarizedLoad::getW));

    if (maxLoad.isPresent()) {
      // create a new SummarizedLoad for this flight phase and electrical phase and add it to the
      // collection
      createdPhaseSummaries.add(
          new SummarizedLoad(
              maxLoad.get().getFlightPhase(),
              operatingMode,
              maxLoad.get().getElectricalPhase(),
              summaryType,
              false,
              true,
              maxLoad.get().getW(),
              maxLoad.get().getVar(),
              Units.KVA));

      // find the sibling electrical phases (ex if the electrical phase of the max load is ACA then
      // its siblings will be ACB and ACC)
      List<ElectricalPhase> siblingElectricalPhases =
          Stream.of(ElectricalPhase.ACA, ElectricalPhase.ACB, ElectricalPhase.ACC)
              .filter(phase -> phase != maxLoad.get().getElectricalPhase())
              .collect(Collectors.toList());

      for (ElectricalPhase siblingElectricalPhase : siblingElectricalPhases) {
        // find the SummarizedLoad object with the same flight phase as the max SummaryLoad found
        // above and the sibling electrical phase
        Optional<SummarizedLoad> siblingSummarizedLoad =
            filteredSummarizedLoads.stream()
                .filter(
                    loadSummary ->
                        !loadSummary.getFlightPhase().equals(NOMINAL_POWER)
                            && !loadSummary.getFlightPhase().equals(CONNECTED_LOAD)
                            && loadSummary.getSummaryType() == summaryType
                            && loadSummary.getElectricalPhase() == siblingElectricalPhase
                            && loadSummary
                                .getFlightPhase()
                                .equalsIgnoreCase(maxLoad.get().getFlightPhase())
                            && operatingMode.equalsIgnoreCase(loadSummary.getOperatingMode()))
                .findFirst();

        // create a new SummarizedLoad for this flight phase and sibling electrical phase and add it
        // to the collection
        if (siblingSummarizedLoad.isPresent()) {
          createdPhaseSummaries.add(
              new SummarizedLoad(
                  siblingSummarizedLoad.get().getFlightPhase(),
                  operatingMode,
                  siblingElectricalPhase,
                  summaryType,
                  false,
                  true,
                  siblingSummarizedLoad.get().getW(),
                  siblingSummarizedLoad.get().getVar(),
                  Units.KVA));
        }
      }
    }
    return createdPhaseSummaries;
  }

  /**
   * Create 1 SummarizedLoad object used by the phase summary calculations above for the
   * operatingMode and summaryType passed in. This SummarizedLoad object contains the flight phase
   * for a given operatingMode and summaryType with the largest different between the max and min
   * ACA, ACB and ACC loads. The SummarizedLoad object's value is that difference between max and
   * min.
   *
   * @param filteredSummarizedLoads - a list of summarized loads filtered to be ACA, ACB, ACC for
   *     the given operating mode and summary type * @param operatingMode - the operating mode
   * @param summaryType - the summary type of the load summaries
   * @param flightPhases - collection of all flight phases
   * @return a summarized load containing the flight phase with the max load imbalance
   */
  private static SummarizedLoad createSummarizedLoadForPhaseSummaryMaxLoadImbalance(
      List<SummarizedLoad> filteredSummarizedLoads,
      String operatingMode,
      SummaryType summaryType,
      Set<String> flightPhases) {

    // store the max imbalance for each flightPhase. map key is the flight phase, map value is the
    // max imbalance for that flight phase.
    Map<String, Double> flightPhaseMap = new HashMap<>();
    Map<String, Double> flightPhaseVarMap = new HashMap<>();
    // loop for each flight phase
    for (String flightPhase : flightPhases) {
      // get the all the SummarizedLoads for the flight phase, operatingMode, summaryType and
      // electrical phase of ACA, ACB or ACC
      List<SummarizedLoad> flightPhaseSummarizedLoads =
          filteredSummarizedLoads.stream()
              .filter(
                  loadSummary ->
                      loadSummary.getFlightPhase().equals(flightPhase)
                          && loadSummary.getSummaryType() == summaryType
                          && (ElectricalPhase.ACA.equals(loadSummary.getElectricalPhase())
                              || ElectricalPhase.ACB.equals(loadSummary.getElectricalPhase())
                              || ElectricalPhase.ACC.equals(loadSummary.getElectricalPhase()))
                          && operatingMode.equalsIgnoreCase(loadSummary.getOperatingMode()))
              .collect(Collectors.toList());
      if (!flightPhaseSummarizedLoads.isEmpty()) {
        Optional<SummarizedLoad> maxLoad =
            flightPhaseSummarizedLoads.stream().max(Comparator.comparing(SummarizedLoad::getW));
        Optional<SummarizedLoad> minLoad =
            flightPhaseSummarizedLoads.stream().min(Comparator.comparing(SummarizedLoad::getW));
        flightPhaseMap.put(flightPhase, maxLoad.get().getW() - minLoad.get().getW());

        Optional<SummarizedLoad> maxLoadVar =
            flightPhaseSummarizedLoads.stream().max(Comparator.comparing(SummarizedLoad::getVar));
        Optional<SummarizedLoad> minLoadVar =
            flightPhaseSummarizedLoads.stream().min(Comparator.comparing(SummarizedLoad::getVar));
        flightPhaseVarMap.put(flightPhase, maxLoadVar.get().getVar() - minLoadVar.get().getVar());
      }
    }

    // get the largest imbalance among all flight phases and create a SummarizedLoad object for it.
    if (!flightPhaseMap.isEmpty()) {
      Map.Entry<String, Double> maxImbalance =
          flightPhaseMap.entrySet().stream().max(Map.Entry.comparingByValue()).get();
      Double maxImbalanceVar = flightPhaseVarMap.get(maxImbalance.getKey());
      return new SummarizedLoad(
          maxImbalance.getKey(),
          operatingMode,
          null,
          summaryType,
          true,
          false,
          maxImbalance.getValue(),
          maxImbalanceVar);
    } else {
      return null;
    }
  }
}
