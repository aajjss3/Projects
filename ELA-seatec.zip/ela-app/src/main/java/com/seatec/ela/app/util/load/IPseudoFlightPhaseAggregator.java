package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.enumeration.PseudoFlightPhase;
import java.util.List;

public interface IPseudoFlightPhaseAggregator {
  PseudoFlightPhase getPseudoFlightPhase();

  void aggregateLoadSummary(SummarizedLoad loadSummary, Component component);

  void aggregateLoadSummariesPhaseSplit(List<SummarizedLoad> loadSummaries, Component component);
}
