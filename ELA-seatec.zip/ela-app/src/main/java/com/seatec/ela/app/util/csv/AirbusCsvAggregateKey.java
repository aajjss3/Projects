package com.seatec.ela.app.util.csv;

public class AirbusCsvAggregateKey {
  final String busBar;
  final String phase;
  final String identifier;

  AirbusCsvAggregateKey(String busBar, String phase, String identifier) {
    this.busBar = busBar;
    this.phase = phase;
    this.identifier = identifier;
  }

  public String getBusBar() {
    return busBar;
  }

  public String getPhase() {
    return phase;
  }

  public String getIdentifier() {
    return identifier;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof AirbusCsvAggregateKey)) {
      return false;
    }

    AirbusCsvAggregateKey that = (AirbusCsvAggregateKey) o;

    if (busBar != null ? !busBar.equals(that.busBar) : that.busBar != null) {
      return false;
    }
    if (phase != null ? !phase.equals(that.phase) : that.phase != null) {
      return false;
    }
    return identifier != null ? identifier.equals(that.identifier) : that.identifier == null;
  }

  @Override
  public int hashCode() {
    int result = busBar != null ? busBar.hashCode() : 0;
    result = 31 * result + (phase != null ? phase.hashCode() : 0);
    result = 31 * result + (identifier != null ? identifier.hashCode() : 0);
    return result;
  }
}
