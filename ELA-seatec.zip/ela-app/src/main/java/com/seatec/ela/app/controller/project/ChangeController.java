package com.seatec.ela.app.controller.project;

import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import com.seatec.ela.app.util.RequestUtil;
import com.seatec.ela.app.validator.annotation.IdExists;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/service/projects/{projectId}/changegroups/{changeGroupId}/change")
@Validated
public class ChangeController {

  @Autowired private IChangeService changeService;

  @GetMapping()
  @ResponseStatus(HttpStatus.OK)
  public List<Change> findAllByProjectAndChangeGroupId(
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId) {
    return changeService.findAllByProjectAndChangeGroupId(changeGroupId, projectId);
  }

  @GetMapping("{changeId}")
  @ResponseStatus(HttpStatus.OK)
  public Optional<Change> findById(
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      @IdExists(entity = Change.class, message = "{id.invalid}") @PathVariable("changeId")
          UUID changeId) {
    return changeService.findById(changeId);
  }

  @PostMapping()
  @ResponseStatus(HttpStatus.OK)
  public Change create(
      @Validated @RequestBody Change change,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      HttpServletRequest request) {
    String userId = RequestUtil.getUserIdFromRequest(request);
    change.setChanger(userId);
    return changeService.create(change, changeGroupId, projectId);
  }

  @PutMapping("/{changeId}")
  @ResponseStatus(HttpStatus.OK)
  public void update(
      @Validated @RequestBody Change change,
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      @IdExists(entity = Change.class, message = "{id.invalid}") @PathVariable("changeId")
          UUID changeId) {
    changeService.update(change, changeId);
  }

  @DeleteMapping("/{changeId}")
  @ResponseStatus(HttpStatus.OK)
  public void delete(
      @IdExists(entity = Project.class, message = "{id.invalid}") @PathVariable("projectId")
          UUID projectId,
      @IdExists(entity = ChangeGroup.class, message = "{id.invalid}") @PathVariable("changeGroupId")
          UUID changeGroupId,
      @IdExists(entity = Change.class, message = "{id.invalid}") @PathVariable("changeId")
          UUID changeId) {
    changeService.delete(changeId, changeGroupId, projectId);
  }
}
