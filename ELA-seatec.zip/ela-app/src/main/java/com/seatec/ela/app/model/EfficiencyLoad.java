package com.seatec.ela.app.model;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EfficiencyLoad implements Serializable {

  @Column(name = "current", nullable = false)
  private double current;

  @Column(name = "active_power")
  private Double activePower;

  @Column(name = "power_factor")
  private Double powerFactor;

  @Column(name = "efficiency")
  private Double efficiency;

  @Column(name = "expf")
  private Double exPF;

  public double getCurrent() {
    return current;
  }

  public void setCurrent(double current) {
    this.current = current;
  }

  public Double getActivePower() {
    return activePower;
  }

  public void setActivePower(Double activePower) {
    this.activePower = activePower;
  }

  public Double getPowerFactor() {
    return powerFactor;
  }

  public void setPowerFactor(Double powerFactor) {
    this.powerFactor = powerFactor;
  }

  public Double getEfficiency() {
    return efficiency;
  }

  public void setEfficiency(Double efficiency) {
    this.efficiency = efficiency;
  }

  public Double getExPF() {
    return exPF;
  }

  public void setExPF(Double exPF) {
    this.exPF = exPF;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    EfficiencyLoad that = (EfficiencyLoad) o;
    return Objects.equals(current, that.current)
        && Objects.equals(activePower, that.activePower)
        && Objects.equals(powerFactor, that.powerFactor)
        && Objects.equals(efficiency, that.efficiency)
        && Objects.equals(exPF, that.exPF);
  }

  @Override
  public int hashCode() {

    return Objects.hash(current, activePower, powerFactor, efficiency, exPF);
  }

  public EfficiencyLoad() {}

  public EfficiencyLoad(
      double current, Double activePower, Double powerFactor, Double efficiency, Double exPF) {
    this.current = current;
    this.activePower = activePower;
    this.powerFactor = powerFactor;
    this.efficiency = efficiency;
    this.exPF = exPF;
  }
}
