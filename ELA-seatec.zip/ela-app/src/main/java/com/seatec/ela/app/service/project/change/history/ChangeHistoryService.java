package com.seatec.ela.app.service.project.change.history;

import com.seatec.ela.app.dto.ChangeGroupMappedNodeDto;
import com.seatec.ela.app.dto.ElaComponentsDto;
import com.seatec.ela.app.dto.project.AircraftChangeGroupDTO;
import com.seatec.ela.app.dto.project.AircraftDTO;
import com.seatec.ela.app.dto.project.ChangeGroupDTO;
import com.seatec.ela.app.dto.project.LoadChangeDTO;
import com.seatec.ela.app.dto.project.change.ChangeDTO;
import com.seatec.ela.app.dto.project.change.history.ChangeHistoryDTO;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.project.change.history.ComponentChangeHistory;
import com.seatec.ela.app.model.project.change.history.LoadChangeHistory;
import com.seatec.ela.app.model.project.change.history.NodeChangeHistory;
import com.seatec.ela.app.model.repository.project.ChangeGroupEffectivityDao;
import com.seatec.ela.app.model.repository.project.change.history.ComponentChangeHistoryRepo;
import com.seatec.ela.app.model.repository.project.change.history.LoadChangeHistoryRepo;
import com.seatec.ela.app.model.repository.project.change.history.NodeChangeHistoryRepo;
import com.seatec.ela.app.service.contract.IComponentService;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import com.seatec.ela.app.service.contract.project.change.history.IChangeHistoryService;
import com.seatec.ela.app.util.FieldValidator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class ChangeHistoryService implements IChangeHistoryService {
  @Autowired private ComponentChangeHistoryRepo componentChangeHistoryRepo;
  @Autowired private LoadChangeHistoryRepo loadChangeHistoryRepo;
  @Autowired private NodeChangeHistoryRepo nodeChangeHistoryRepo;

  @Autowired
  @Qualifier("mapAll")
  private ModelMapper mapper;

  @Autowired private IChangeService changeService;

  @Autowired private IComponentService componentService;

  @Autowired private IElaService elaService;

  @Autowired private ChangeGroupEffectivityDao changeGroupEffectivityDao;

  public List<ChangeHistoryDTO> findAllByChangeGroupDTO(
      ChangeGroupDTO changeGroupDTO, boolean isApproved) {
    List<ChangeHistoryDTO> changeHistoryDTOS = new ArrayList<>();

    // get change DTOs for change group DTO
    List<ChangeDTO> changeDTOS = changeGroupDTO.getChanges();

    // iterate over changeDTOS
    for (ChangeDTO changeDTO : changeDTOS) {
      ChangeHistoryDTO changeHistoryDTO =
          getChangeHistoryDTOByChangeDTO(changeGroupDTO, changeDTO, isApproved);

      // add new item
      changeHistoryDTOS.add(changeHistoryDTO);
    }

    return changeHistoryDTOS;
  }

  public void saveOriginalNodeValues(Change change, Ela ela, Node node) {
    NodeChangeHistory changeHistoryNodeChange = new NodeChangeHistory();

    // auto-mapper
    mapper.map(node, changeHistoryNodeChange);
    changeHistoryNodeChange.setChange(change);
    changeHistoryNodeChange.setAircraft(ela.getAircraft());
    changeHistoryNodeChange.setEla(ela);

    // save
    nodeChangeHistoryRepo.save(changeHistoryNodeChange);
  }

  public void saveOriginalComponentValues(Change change, Ela ela, Component component) {
    // only save component history if component metadata was edited
    if (isComponentChange(change, component)) {
      ComponentChangeHistory componentChangeHistory = new ComponentChangeHistory();

      // auto-mapper
      mapper.map(component, componentChangeHistory);
      componentChangeHistory.setChange(change);
      componentChangeHistory.setAircraft(ela.getAircraft());
      componentChangeHistory.setEla(ela);

      // save component
      componentChangeHistoryRepo.save(componentChangeHistory);
    }

    // save component > loads
    saveOriginalLoadValues(change, ela, component.getLoads());
  }

  private List<LoadChangeHistory> findLoadChangeHistoryByChangeId(UUID changeId) {
    return loadChangeHistoryRepo.findByChangeId(changeId);
  }

  private List<ComponentChangeHistory> findComponentChangeHistoryByChangeId(UUID changeId) {
    return componentChangeHistoryRepo.findAllByChangeId(changeId);
  }

  private List<NodeChangeHistory> findNodeChangeHistoryByChangeId(UUID changeId) {
    return nodeChangeHistoryRepo.findAllByChangeId(changeId);
  }

  private void saveOriginalLoadValues(Change change, Ela ela, List<Load> loads) {
    List<LoadChangeHistory> loadChangeHistories = new ArrayList<>();

    for (Load load : loads) {
      LoadChangeHistory changeHistoryLoadChange = new LoadChangeHistory();

      // auto-mapper
      mapper.map(load, changeHistoryLoadChange);
      changeHistoryLoadChange.setChange(change);
      changeHistoryLoadChange.setAircraft(ela.getAircraft());
      changeHistoryLoadChange.setEla(ela);

      // append to collection
      loadChangeHistories.add(changeHistoryLoadChange);
    }

    // save
    loadChangeHistoryRepo.saveAll(loadChangeHistories);
  }

  private boolean isComponentChange(Change change, Component component) {
    if (change.getComponentChange() == null) {
      return false;
    }

    // get component change
    ComponentChange cc = change.getComponentChange();

    return (cc.getIntermittent() != component.getIntermittent()
        || cc.getClipsed() != component.getClipsed()
        || cc.getSheddable() != component.getSheddable()
        || !cc.getElectIdent().equalsIgnoreCase(component.getElectIdent())
        || cc.getElectricalPhase() != component.getElectricalPhase()
        || !cc.getAta().equalsIgnoreCase(component.getAta())
        || FieldValidator.isDoublesChanged(cc.getNominalPower(), component.getNominalPower())
        || FieldValidator.isDoublesChanged(cc.getConnectedLoadPf(), component.getConnectedLoadPf())
        || FieldValidator.isDoublesChanged(cc.getConnectedLoadVa(), component.getConnectedLoadVa())
        || !cc.getPanel().equalsIgnoreCase(component.getPanel())
        || !cc.getName().equalsIgnoreCase(component.getName()));
  }

  private List<Long> getNodeIds(ChangeGroupDTO changeGroupDTO, String nodeName) {
    ChangeGroup changeGroup = new ChangeGroup();
    mapper.map(changeGroupDTO, changeGroup);

    List<Long> elaIds =
        elaService.findDistinctElaIdByAircraftChangeGroups(changeGroup.getAircraftChangeGroups());
    return getAllNodeDtoByElaId(elaIds).stream()
        .filter(n -> n.getName().equals(nodeName))
        .map(ChangeGroupMappedNodeDto::getId)
        .collect(Collectors.toList());
  }

  private List<ChangeGroupMappedNodeDto> getAllNodeDtoByElaId(List<Long> elaIds) {
    return elaIds.isEmpty()
        ? Collections.emptyList()
        : changeGroupEffectivityDao.findChangeGroupEffectivities(elaIds);
  }

  private ChangeHistoryDTO getChangeHistoryDTOByChangeDTO(
      ChangeGroupDTO changeGroupDTO, ChangeDTO changeDTO, boolean isApproved) {
    UUID changeId = changeDTO.getId();
    ChangeHistoryDTO changeHistoryDTO = new ChangeHistoryDTO(changeId);

    // if Component Change then append load values.
    // Does not append node/component values as they are
    // not required for display purposes at this time but
    // could be in future.
    if (changeDTO.getComponentChange() != null) {
      switch (changeDTO.getAction()) {
        case ADD:
          changeHistoryDTO = getChangeHistoryDTOForAddAction(changeGroupDTO, changeDTO);
          break;
        case DELETE:
        case EDIT:
          changeHistoryDTO =
              getChangeHistoryDTOForEditOrDeleteAction(changeGroupDTO, changeDTO, isApproved);
          break;
        default:
          throw new BadRequestException(
              "Invalid action ('"
                  + changeDTO.getAction()
                  + "') found for changeId: "
                  + changeDTO.getId(),
              Level.ERROR);
      }
    }

    return changeHistoryDTO;
  }

  private ChangeHistoryDTO getChangeHistoryDTOForAddAction(
      ChangeGroupDTO changeGroupDTO, ChangeDTO changeDTO) {
    ChangeHistoryDTO changeHistoryDTO = new ChangeHistoryDTO(changeDTO.getId());

    // get all aircraftDTOs in change group
    List<AircraftDTO> aircraftDTOS =
        changeGroupDTO.getAircraftChangeGroups().stream()
            .map(AircraftChangeGroupDTO::getAircraft)
            .collect(Collectors.toList());

    // get ElaComponentDtos list
    List<ElaComponentsDto> elaComponentsDtos =
        elaService.findElaComponentDtosByAircraftDTOS(aircraftDTOS);

    List<LoadChangeDTO> loadChanges = changeDTO.getComponentChange().getLoadChanges();
    List<Load> loads = new ArrayList<>();

    for (ElaComponentsDto elaComponentsDto : elaComponentsDtos) {
      for (Long componentId : elaComponentsDto.getComponentIds()) {
        for (LoadChangeDTO loadChangeDTO : loadChanges) {
          Load newLoad = new Load();
          newLoad.setOperatingMode(loadChangeDTO.getOperatingMode());
          newLoad.setVa(loadChangeDTO.getVa());
          newLoad.setFlightPhase(loadChangeDTO.getFlightPhase());
          newLoad.setPowerFactor(loadChangeDTO.getPowerFactor());

          Component newComponent = new Component();
          newComponent.setId(componentId);
          newLoad.setComponent(newComponent);

          // append new load
          loads.add(newLoad);
        }
      }
    }

    List<LoadChangeHistory> loadChangeHistories =
        getLoadChangeHistories(changeDTO, elaComponentsDtos, loads);

    // map load data
    changeHistoryDTO.setLoadChanges(loadChangeHistories);

    return changeHistoryDTO;
  }

  private ChangeHistoryDTO getChangeHistoryDTOForEditOrDeleteAction(
      ChangeGroupDTO changeGroupDTO, ChangeDTO changeDTO, boolean isApproved) {
    return isApproved
        ? getChangeHistoryDTOForApprovedProject(changeDTO.getId())
        : getChangeHistoryDTOForNonApprovedProject(changeGroupDTO, changeDTO);
  }

  private ChangeHistoryDTO getChangeHistoryDTOForApprovedProject(UUID changeId) {
    List<NodeChangeHistory> nodeChangeHistories = findNodeChangeHistoryByChangeId(changeId);
    List<ComponentChangeHistory> componentChangeHistories =
        findComponentChangeHistoryByChangeId(changeId);
    List<LoadChangeHistory> loadChangeHistories = findLoadChangeHistoryByChangeId(changeId);

    return new ChangeHistoryDTO(
        changeId, nodeChangeHistories, componentChangeHistories, loadChangeHistories);
  }

  private ChangeHistoryDTO getChangeHistoryDTOForNonApprovedProject(
      ChangeGroupDTO changeGroupDTO, ChangeDTO changeDTO) {
    ChangeHistoryDTO changeHistoryDTO = new ChangeHistoryDTO(changeDTO.getId());

    List<Long> getNodeIds = getNodeIds(changeGroupDTO, changeDTO.getNodeName());

    // get all components (possible duplicate elect ident / name)
    List<Component> components = componentService.findByNodeIds(getNodeIds);

    // get unique componentId list
    List<Long> componentIds;
    List<ElaComponentsDto> elaComponentsDtos;

    // get all loads based on component elect ident (name)
    // could include loads across multiple components (when multiple ships
    // with same component elect ident)
    List<Load> loads =
        components.stream()
            .filter(f -> f.getElectIdent().equalsIgnoreCase(changeDTO.getComponentElectIdent()))
            .flatMap(c -> c.getLoads().stream())
            .collect(Collectors.toList());

    componentIds =
        loads.stream().map(l -> l.getComponent().getId()).distinct().collect(Collectors.toList());

    // get DTO list based on componentId
    elaComponentsDtos = elaService.findElaComponentDtosByComponentIds(componentIds);

    List<LoadChangeHistory> loadChangeHistories =
        getLoadChangeHistories(changeDTO, elaComponentsDtos, loads);

    // map load data
    changeHistoryDTO.setLoadChanges(loadChangeHistories);

    return changeHistoryDTO;
  }

  private List<LoadChangeHistory> getLoadChangeHistories(
      ChangeDTO changeDTO, List<ElaComponentsDto> elaComponentsDtos, List<Load> loads) {
    List<LoadChangeHistory> loadChangeHistories = new ArrayList<>();

    // convert ChangeDTO to Change
    Change change = new Change();
    mapper.map(changeDTO, change);

    // iterate over loads and populate LoadChangeHistory manually
    for (Load load : loads) {
      Long id = load.getComponent().getId();

      // find matching ela
      Ela ela =
          elaComponentsDtos.stream()
              .filter(f -> f.getComponentIds().contains(id))
              .map(ElaComponentsDto::getEla)
              .findFirst()
              .orElseThrow(
                  () ->
                      new NotFoundException(
                          "Unable to locate ELA for component id '" + id + "'", Level.WARN));

      LoadChangeHistory loadChangeHistory = new LoadChangeHistory();
      loadChangeHistory.setChange(change);
      loadChangeHistory.setFlightPhase(load.getFlightPhase());
      loadChangeHistory.setOperatingMode(load.getOperatingMode());
      loadChangeHistory.setPowerFactor(load.getPowerFactor());
      loadChangeHistory.setVa(load.getVa());
      loadChangeHistory.setEla(ela);
      loadChangeHistory.setAircraft(ela.getAircraft());

      loadChangeHistories.add(loadChangeHistory);
    }

    return loadChangeHistories;
  }
}
