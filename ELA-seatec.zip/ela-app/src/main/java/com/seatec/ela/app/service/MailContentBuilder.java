package com.seatec.ela.app.service;

import com.seatec.ela.app.dto.email.ProjectChange;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.ITemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class MailContentBuilder {
  private ITemplateEngine templateEngine;

  // template names that are in use
  private final String loginSubjectTemplateName = "mailSubjectNewLoginTemplate";
  private final String mailNewLoginTemplateName = "mailNewLoginTemplate";

  private final String projectSubjectTemplateName = "mailSubjectProjectNotificationTemplate";
  private final String mailProjectNotificationTemplateName = "mailProjectNotificationTemplate";
  private final String mailProjectApprovalTemplateName = "mailProjectApprovalTemplate";
  private final String mailProjectChangeNotificationTemplateName =
      "mailProjectChangeNotificationTemplate";
  private final String mailSubjectProjectChangeNotificationTemplateName =
      "mailSubjectProjectChangeNotificationTemplate";

  // context Parameters Available for Templates
  private final String contextName = "name";
  private final String contextUserName = "userLoginName";
  private final String contextUserPassword = "userPassword";
  private final String contextLoginUrl = "loginUrl";
  private final String contextSupportEmail = "supportEmail";
  private final String contextCustomerName = "customerName";
  private final String contextProjectNumber = "projectNumber";
  private final String contextProjectRevision = "projectRevision";
  private final String contextProjectTitle = "projectTitle";

  @Autowired
  public MailContentBuilder(ITemplateEngine templateEngine) {
    this.templateEngine = templateEngine;
  }

  public String buildLoginSubject(String customerName) {
    Context context = new Context();
    context.setVariable(contextCustomerName, customerName);
    return templateEngine.process(loginSubjectTemplateName, context);
  }

  public String buildLoginText(
      String name,
      String userLoginName,
      String userPassword,
      String loginUrl,
      String supportEmail,
      String customerName) {
    Context context = new Context();
    context.setVariable(contextName, name);
    context.setVariable(contextUserName, userLoginName);
    context.setVariable(contextUserPassword, userPassword);
    context.setVariable(contextLoginUrl, loginUrl);
    context.setVariable(contextSupportEmail, supportEmail);
    context.setVariable(contextCustomerName, customerName);
    return templateEngine.process(mailNewLoginTemplateName, context);
  }

  public String buildProjectSubject(
      String customerName, String projectNumber, String projectRevision, String projectTitle) {
    Context context = new Context();
    context.setVariable(contextCustomerName, customerName);
    context.setVariable(contextProjectNumber, projectNumber);
    context.setVariable(contextProjectRevision, projectRevision);
    context.setVariable(contextProjectTitle, projectTitle);
    return templateEngine.process(projectSubjectTemplateName, context);
  }

  public String buildProjectChangeSubject(
      String customerName, String projectNumber, String projectRevision, String projectTitle) {
    Context context = new Context();
    context.setVariable(contextCustomerName, customerName);
    context.setVariable(contextProjectNumber, projectNumber);
    context.setVariable(contextProjectRevision, projectRevision);
    context.setVariable(contextProjectTitle, projectTitle);
    return templateEngine.process(mailSubjectProjectChangeNotificationTemplateName, context);
  }

  public String buildProjectNotificationText(
      String name,
      String loginUrl,
      String supportEmail,
      String customerName,
      String projectNumber,
      String projectRevision,
      String projectTitle) {
    Context context = new Context();
    context.setVariable(contextName, name);
    context.setVariable(contextLoginUrl, loginUrl);
    context.setVariable(contextSupportEmail, supportEmail);
    context.setVariable(contextCustomerName, customerName);
    context.setVariable(contextProjectNumber, projectNumber);
    context.setVariable(contextProjectRevision, projectRevision);
    context.setVariable(contextProjectTitle, projectTitle);
    return templateEngine.process(mailProjectNotificationTemplateName, context);
  }

  public String buildProjectApprovalText(
      String name,
      String loginUrl,
      String supportEmail,
      String customerName,
      String projectNumber,
      String projectRevision,
      String projectTitle) {
    Context context = new Context();
    context.setVariable(contextName, name);
    context.setVariable(contextLoginUrl, loginUrl);
    context.setVariable(contextSupportEmail, supportEmail);
    context.setVariable(contextCustomerName, customerName);
    context.setVariable(contextProjectNumber, projectNumber);
    context.setVariable(contextProjectRevision, projectRevision);
    context.setVariable(contextProjectTitle, projectTitle);
    return templateEngine.process(mailProjectApprovalTemplateName, context);
  }

  public String buildProjectChangeNotificationText(
      String loginUrl,
      String supportEmail,
      String customerName,
      List<ProjectChange> projectChanges) {
    Context context = new Context();
    context.setVariable(contextCustomerName, customerName);
    context.setVariable(contextLoginUrl, loginUrl);
    context.setVariable("projectChanges", projectChanges);
    context.setVariable(contextSupportEmail, supportEmail);

    return templateEngine.process(mailProjectChangeNotificationTemplateName, context);
  }
}
