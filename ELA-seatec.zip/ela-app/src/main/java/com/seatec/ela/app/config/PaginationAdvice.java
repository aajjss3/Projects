package com.seatec.ela.app.config;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.util.HttpResponseHeaderBuilder;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * If the response body contains a PaginationDTO object then add pagination metadata to the http
 * response header
 *
 * @author asparago
 */
@ControllerAdvice
public class PaginationAdvice implements ResponseBodyAdvice<Object> {

  public boolean supports(
      MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
    return true;
  }

  public Object beforeBodyWrite(
      Object body,
      MethodParameter returnType,
      MediaType selectedContentType,
      Class<? extends HttpMessageConverter<?>> selectedConverterType,
      ServerHttpRequest request,
      ServerHttpResponse response) {
    if (body != null
        && body instanceof PaginationDTO
        && request instanceof ServletServerHttpRequest
        && response instanceof ServletServerHttpResponse) {
      HttpResponseHeaderBuilder.addLinkHeaderToHttpResponse(
          ((ServletServerHttpResponse) response).getServletResponse(),
          ((ServletServerHttpRequest) request).getServletRequest(),
          (PaginationDTO<?>) body);
    }
    return body;
  }
}
