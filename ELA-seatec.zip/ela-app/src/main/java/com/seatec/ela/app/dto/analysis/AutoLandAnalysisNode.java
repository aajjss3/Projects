package com.seatec.ela.app.dto.analysis;

import java.io.Serializable;

public class AutoLandAnalysisNode implements Serializable {

  private static final long serialVersionUID = 1L;

  private final String name;
  private final Double totalLoadInAmps;

  public AutoLandAnalysisNode(String name, Double totalLoadInAmps) {
    this.name = name;
    this.totalLoadInAmps = totalLoadInAmps;
  }

  public String getName() {
    return name;
  }

  public Double getTotalLoadInAmps() {
    return totalLoadInAmps;
  }
}
