package com.seatec.ela.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import org.hibernate.annotations.ColumnDefault;

@Entity
@Table(name = "aircraft")
public class Aircraft implements Serializable, Comparable<Aircraft> {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false, name = "aircraftshipno", unique = true)
  private String aircraftShipNo;

  @Column(nullable = false, name = "serialnumber")
  private String serialNumber;

  @Column(nullable = false, name = "registrationnumber")
  private String registrationNumber;

  @Column(name = "linenumber")
  private String lineNumber;

  @Column(name = "variablenumber")
  private String variableNumber;

  @Column(name = "origworkbookname")
  private String origWorkbookFilename;

  @Column(name = "origworkbookcksum")
  private String origWorkBookchecksum;

  @Column(name = "archived", nullable = false)
  @ColumnDefault("false")
  private boolean archived;

  @Column(name = "cloaked", nullable = false)
  @ColumnDefault("false")
  private boolean cloaked;

  // the aircraft battery's electrical capacity
  @Column(name = "battery_charge", length = 31)
  @Enumerated(EnumType.STRING)
  private BatteryChargeType batteryCharge;

  @ManyToOne
  @JoinColumn(name = "fleet_id")
  @JsonIgnore
  private Fleet fleet;

  @OneToMany(mappedBy = "aircraft", cascade = CascadeType.ALL)
  @JsonIgnore
  private List<Ela> elas = new ArrayList<>();

  @JsonIgnore
  @OneToMany(
      mappedBy = "aircraft",
      cascade = {CascadeType.ALL},
      orphanRemoval = true)
  private List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<AircraftChangeGroup>();

  public Aircraft() {}

  public Aircraft(
      String aircraftShipNo,
      String serialNumber,
      String registrationNumber,
      String lineNumber,
      String variableNumber,
      String origWorkbookFilename,
      String origWorkBookchecksum,
      Fleet fleet) {
    this.aircraftShipNo = aircraftShipNo;
    this.serialNumber = serialNumber;
    this.registrationNumber = registrationNumber;
    this.lineNumber = lineNumber;
    this.variableNumber = variableNumber;
    this.origWorkbookFilename = origWorkbookFilename;
    this.origWorkBookchecksum = origWorkBookchecksum;
    this.fleet = fleet;
  }

  public Aircraft(
      String aircraftShipNo,
      String serialNumber,
      String registrationNumber,
      String lineNumber,
      String variableNumber,
      Fleet fleet) {
    this.aircraftShipNo = aircraftShipNo;
    this.serialNumber = serialNumber;
    this.registrationNumber = registrationNumber;
    this.lineNumber = lineNumber;
    this.variableNumber = variableNumber;
    this.fleet = fleet;
  }

  public Aircraft(
      Long id,
      String aircraftShipNo,
      String serialNumber,
      String registrationNumber,
      String lineNumber,
      String variableNumber,
      Fleet fleet,
      boolean archived,
      BatteryChargeType batteryCharge) {
    this.id = id;
    this.aircraftShipNo = aircraftShipNo;
    this.serialNumber = serialNumber;
    this.registrationNumber = registrationNumber;
    this.lineNumber = lineNumber;
    this.variableNumber = variableNumber;
    this.fleet = fleet;
    this.archived = archived;
    this.batteryCharge = batteryCharge;
  }

  public void addAircraftChangeGroup(AircraftChangeGroup aircraftChangeGroup) {
    aircraftChangeGroups.add(aircraftChangeGroup);
    aircraftChangeGroup.setAircraft(this);
  }

  public void removeAircraftChangeGroup(AircraftChangeGroup aircraftChangeGroup) {
    aircraftChangeGroups.remove(aircraftChangeGroup);
    aircraftChangeGroup.setAircraft(null);
  }

  public void addEla(Ela child) {
    this.elas.add(child);
    child.setAircraft(this);
  }

  public void removeEla(Ela child) {
    this.elas.remove(child);
    child.setAircraft(null);
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getId() {
    return id;
  }

  public void setAircraftShipNo(String aircraftShipNo) {
    this.aircraftShipNo = aircraftShipNo;
  }

  public String getAircraftShipNo() {
    return aircraftShipNo;
  }

  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }

  public String getSerialNumber() {
    return serialNumber;
  }

  public void setRegistrationNumber(String registrationNumber) {
    this.registrationNumber = registrationNumber;
  }

  public String getRegistrationNumber() {
    return registrationNumber;
  }

  public void setLineNumber(String lineNumber) {
    this.lineNumber = lineNumber;
  }

  public String getLineNumber() {
    return lineNumber;
  }

  public void setVariableNumber(String variableNumber) {
    this.variableNumber = variableNumber;
  }

  public String getVariableNumber() {
    return variableNumber;
  }

  public String getOrigWorkbookFilename() {
    return origWorkbookFilename;
  }

  public String getOrigWorkBookchecksum() {
    return origWorkBookchecksum;
  }

  public BatteryChargeType getBatteryCharge() {
    return batteryCharge;
  }

  public void setBatteryCharge(BatteryChargeType batteryCharge) {
    this.batteryCharge = batteryCharge;
  }

  public void setFleet(Fleet fleet) {
    this.fleet = fleet;
  }

  public Fleet getFleet() {
    return fleet;
  }

  public List<Ela> getElas() {
    return elas;
  }

  public void setOrigWorkbookFilename(String origWorkbookFilename) {
    this.origWorkbookFilename = origWorkbookFilename;
  }

  public void setOrigWorkBookchecksum(String origWorkBookchecksum) {
    this.origWorkBookchecksum = origWorkBookchecksum;
  }

  public List<AircraftChangeGroup> getAircraftChangeGroups() {
    return aircraftChangeGroups;
  }

  public void setAircraftChangeGroups(List<AircraftChangeGroup> aircraftChangeGroups) {
    this.aircraftChangeGroups = aircraftChangeGroups;
  }

  public boolean isArchived() {
    return archived;
  }

  public void setArchived(boolean archived) {
    this.archived = archived;
  }

  public boolean isCloaked() {
    return cloaked;
  }

  public void setCloaked(boolean cloaked) {
    this.cloaked = cloaked;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Aircraft aircraft = (Aircraft) o;
    return Objects.equals(aircraftShipNo, aircraft.aircraftShipNo);
  }

  @Override
  public int hashCode() {
    return Objects.hash(aircraftShipNo);
  }

  @Override
  public int compareTo(@NotNull Aircraft o) {
    Integer[] shipnums = new Integer[2];
    if (this.equals(o)) {
      return 0;
    } else if (o.getAircraftShipNo() == null) {
      return 1;
    } else if (aircraftShipNo == null) {
      return -1;
    }
    int result;
    if (updatedInteger(aircraftShipNo, shipnums, 0)) {
      if (updatedInteger(o.aircraftShipNo, shipnums, 1)) {
        // both numbers so compare
        result = shipnums[0].compareTo(shipnums[1]);
        if (result == 0) {
          // differentiate variations that have the same numeric value
          result = aircraftShipNo.compareTo(o.getAircraftShipNo());
        }
      } else {
        // first number, second not-number
        result = -1;
      }
    } else {
      if (updatedInteger(o.aircraftShipNo, shipnums, 1)) {
        // first not number, second is number
        result = 1;
      } else {
        // both alpha so compare
        result = aircraftShipNo.compareTo(o.getAircraftShipNo());
      }
    }
    return result;
  }

  private boolean updatedInteger(String sourceData, Integer[] result, int offset) {
    try {
      result[offset] = Integer.parseInt(sourceData);
    } catch (NumberFormatException e) {
      return false;
    }
    return true;
  }
}
