package com.seatec.ela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableAsync
@EnableCaching
public class ElaApplication {

  public static void main(String[] args) {
    SpringApplication app = new SpringApplication(ElaApplication.class);
    app.run(args);
  }
}
