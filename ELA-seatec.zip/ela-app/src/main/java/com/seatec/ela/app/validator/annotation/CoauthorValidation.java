package com.seatec.ela.app.validator.annotation;

import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.service.KeycloakService;
import com.seatec.ela.app.service.project.ProjectService;
import com.seatec.ela.app.util.RequestUtil;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;
import org.springframework.beans.factory.annotation.Autowired;

@Target({ElementType.METHOD, ElementType.CONSTRUCTOR})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CoauthorValidation.Validator.class)
@Documented
public @interface CoauthorValidation {

  String message() default "invalid";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};

  // required since validating a methods input parameters using cross-parameter constraints
  @SupportedValidationTarget({ValidationTarget.PARAMETERS})
  class Validator extends CustomValidation
      implements ConstraintValidator<CoauthorValidation, Object[]> {

    @Autowired ProjectRepo projectRepo;
    @Autowired private KeycloakService keycloakService;

    @SuppressWarnings("unchecked")
    @Override
    public boolean isValid(Object[] value, ConstraintValidatorContext context) {

      // methods input parameters
      UUID projectId = (UUID) value[0];
      List<String> coauthors = (List<String>) value[1];
      HttpServletRequest request = (HttpServletRequest) value[2];

      Optional<Project> project = projectRepo.findById(projectId);
      if (!project.isPresent()) {
        // project validation is handled elsewhere so return true
        return true;
      }

      // only a projects author can set the coauthors
      String userId = RequestUtil.getUserIdFromRequest(request);
      if (!project.get().getAuthor().equals(userId)) {
        return buildCustomConstraint(
            "Unable to Assign Co-Authors: Only the project's author can set its co-authors.",
            "coauthors",
            context);
      }

      for (String coauthor : coauthors) {
        // the coauthor cannot be the same person as either the checker or approver or author
        if (coauthor.equalsIgnoreCase(project.get().getCheckEngineer())
            || coauthor.equalsIgnoreCase(project.get().getApprovalEngineer())
            || coauthor.equalsIgnoreCase(project.get().getAuthor())) {
          return buildCustomConstraint(
              "Coauthor cannot be a checker, approver or author.", "coauthors", context);
        }

        // validate the coauthor exists and has the proper role
        if (!keycloakService.isUserValidAndInRoles(
            coauthor, ProjectService.ALL_ROLES_EXCEPT_VIEWER)) {
          return buildCustomConstraint(
              "Unable to Assign Co-Authors: The Co-Author "
                  + coauthor
                  + "  does not have a valid role.",
              "coauthor",
              context);
        }
      }
      return true;
    }
  }
}
