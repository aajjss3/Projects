package com.seatec.ela.app.dto;

import com.fasterxml.jackson.annotation.JsonView;
import com.seatec.ela.app.aop.userevent.UserTrackName;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.View;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

@JsonView(View.EffectivitySummaryView.class)
public class ChangeGroupNodeDto implements UserTrackName {

  private ActionType action;

  private String name;

  private List<ChangeGroupNodeDto> changeGroupNode = new ArrayList<>();

  private List<ComponentDto> componentDtos = new ArrayList<>();

  // UI specific - determines if a node is present across all ships in ChangeGroup
  private Boolean isGlobal;

  private Double voltage;

  private Double nominalPower;

  private NodeType nodeType;

  private boolean requiresApproval;

  private String description;

  private Double busRating;

  private boolean sheddable;

  private ElectricalPhase voltageType;

  private boolean normalTr;

  private ElectricalPhase electricalPhase;

  private List<String> editedFields = new ArrayList<>();

  private UUID changeId;

  public ChangeGroupNodeDto() {}

  public ChangeGroupNodeDto(String name, Boolean isGlobal) {
    this.name = name;
    this.isGlobal = isGlobal;
  }

  public ChangeGroupNodeDto(
      String name,
      String description,
      Double nominalPower,
      Double voltage,
      ElectricalPhase voltageType,
      NodeType nodeType,
      boolean requiresApproval,
      Double busRating,
      boolean sheddable,
      ElectricalPhase electricalPhase) {
    this.name = name;
    this.description = description;
    this.nominalPower = nominalPower;
    this.nodeType = nodeType;
    this.requiresApproval = requiresApproval;
    this.voltage = voltage;
    this.voltageType = voltageType;
    this.busRating = busRating;
    this.sheddable = sheddable;
    this.electricalPhase = electricalPhase;
  }

  public ChangeGroupNodeDto(
      String name,
      List<ChangeGroupNodeDto> changeGroupNode,
      List<ComponentDto> componentDtos,
      String description,
      Boolean isGlobal,
      Double voltage,
      Double nominalPower,
      NodeType nodeType,
      boolean requiresApproval,
      Double busRating,
      boolean sheddable,
      ElectricalPhase voltageType,
      boolean normalTr,
      ElectricalPhase electricalPhase) {
    this.name = name;
    this.changeGroupNode = changeGroupNode;
    this.componentDtos = componentDtos;
    this.description = description;
    this.isGlobal = isGlobal;
    this.voltage = voltage;
    this.nominalPower = nominalPower;
    this.nodeType = nodeType;
    this.requiresApproval = requiresApproval;
    this.busRating = busRating;
    this.sheddable = sheddable;
    this.voltageType = voltageType;
    this.normalTr = normalTr;
    this.electricalPhase = electricalPhase;
  }

  public ActionType getAction() {
    return action;
  }

  public void setAction(ActionType action) {
    this.action = action;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<ChangeGroupNodeDto> getChangeGroupNodeDto() {
    return changeGroupNode;
  }

  public void setChangeGroupNodeDto(List<ChangeGroupNodeDto> changeGroupNode) {
    this.changeGroupNode = changeGroupNode;
  }

  public void addChangeGroupNodeDto(ChangeGroupNodeDto changeGroupNodeDto) {
    this.changeGroupNode.add(changeGroupNodeDto);
  }

  public void removeChangeGroupNodeDto(ChangeGroupNodeDto changeGroupNodeDto) {
    this.changeGroupNode.remove(changeGroupNodeDto);
  }

  public List<ComponentDto> getComponentDtos() {
    return componentDtos;
  }

  public void setComponentDtos(List<ComponentDto> componentDtos) {
    this.componentDtos = componentDtos;
  }

  public void addComponentDto(ComponentDto componentDto) {
    this.componentDtos.add(componentDto);
  }

  public void removeComponentDto(ComponentDto componentDto) {
    this.componentDtos.remove(componentDto);
  }

  public Boolean getIsGlobal() {
    return isGlobal;
  }

  public void setIsGlobal(Boolean isGlobal) {
    this.isGlobal = isGlobal;
  }

  public Double getVoltage() {
    return voltage;
  }

  public void setVoltage(Double voltage) {
    this.voltage = voltage;
  }

  public Double getNominalPower() {
    return nominalPower;
  }

  public void setNominalPower(Double nominalPower) {
    this.nominalPower = nominalPower;
  }

  public NodeType getNodeType() {
    return nodeType;
  }

  public void setNodeType(NodeType nodeType) {
    this.nodeType = nodeType;
  }

  public boolean isRequiresApproval() {
    return requiresApproval;
  }

  public void setRequiresApproval(boolean requiresApproval) {
    this.requiresApproval = requiresApproval;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Double getBusRating() {
    return busRating;
  }

  public void setBusRating(Double busRating) {
    this.busRating = busRating;
  }

  public boolean isSheddable() {
    return sheddable;
  }

  public void setSheddable(boolean sheddable) {
    this.sheddable = sheddable;
  }

  public ElectricalPhase getVoltageType() {
    return voltageType;
  }

  public void setVoltageType(ElectricalPhase voltageType) {
    this.voltageType = voltageType;
  }

  public boolean isNormalTr() {
    return normalTr;
  }

  public void setNormalTr(boolean normalTr) {
    this.normalTr = normalTr;
  }

  public List<String> getEditedFields() {
    return editedFields;
  }

  public void setEditedFields(List<String> editedFields) {
    this.editedFields = editedFields;
  }

  public void addEditedField(String editedFields) {
    this.editedFields.add(editedFields);
  }

  public void removeEditedField(String editedFields) {
    this.editedFields.remove(editedFields);
  }

  public ElectricalPhase getElectricalPhase() {
    return electricalPhase;
  }

  public void setElectricalPhase(ElectricalPhase electricalPhase) {
    this.electricalPhase = electricalPhase;
  }

  public UUID getChangeId() {
    return changeId;
  }

  public void setChangeId(UUID changeId) {
    this.changeId = changeId;
  }

  public Stream<ChangeGroupNodeDto> streamNodes() {
    return Stream.concat(
        Stream.of(this), changeGroupNode.stream().flatMap(ChangeGroupNodeDto::streamNodes));
  }
}
