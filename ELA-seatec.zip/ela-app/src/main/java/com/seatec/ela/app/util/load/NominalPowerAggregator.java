package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.util.enumeration.PseudoFlightPhase;
import java.util.List;

/** NominalPowerAggregator aggregates the component's nominal power */
public class NominalPowerAggregator implements IPseudoFlightPhaseAggregator {

  private static final PseudoFlightPhase NOMINAL_POWER = PseudoFlightPhase.NominalPower;

  public PseudoFlightPhase getPseudoFlightPhase() {
    return NOMINAL_POWER;
  }

  public void aggregateLoadSummary(SummarizedLoad loadSummary, Component component) {
    loadSummary.aggregateW(component.getNominalPower());
  }

  public void aggregateLoadSummariesPhaseSplit(
      List<SummarizedLoad> loadSummaries, Component component) {

    Double splitNominalPower =
        (component.getNominalPower() != null && component.getNominalPower() > 0d)
            ? component.getNominalPower() / LoadSummaryUtil.THREE_PHASE_SPLIT
            : 0d;

    for (SummarizedLoad loadSummary : loadSummaries) {
      loadSummary.aggregateW(splitNominalPower);
    }
  }
}
