#!/usr/bin/env bash

CURRENT_DIR=`pwd`

if [[ $# -ne 0 ]] && [[ $# -ne 2 ]] ; then
  echo "usage: load-efficiency-data.sh [remote IP]"
  exit 1
fi

# remote usage assumes you have a tunnel on local port 5433 to RDS 5432

if [[ "$1" == "remote" ]] ; then
  psql -d elaappdb -U elamaster -h $2 -p 5433 -c "truncate table efficiency_table; truncate table efficiency_table_efficiency_load;"
  psql -d elaappdb -U elamaster -h $2 -p 5433 -c "\COPY efficiency_table(id, name, efficiency_type, version, created, updated) from '${CURRENT_DIR}/efficiency-tables.csv' DELIMITER ',' CSV HEADER"
  psql -d elaappdb -U elamaster -h $2 -p 5433 -c "\COPY efficiency_table_efficiency_load(id, current, active_power, power_factor, efficiency, expf) from '${CURRENT_DIR}/efficiency-loads.csv' DELIMITER ',' CSV HEADER"
else
  psql -d elaappdb -c "truncate table efficiency_table cascade;"
  psql -d elaappdb -c "COPY efficiency_table(id, name, efficiency_type, version, created, updated) from '${CURRENT_DIR}/efficiency-tables.csv' DELIMITER ',' CSV HEADER"
  psql -d elaappdb -c "COPY efficiency_table_efficiency_load(id, current, active_power, power_factor, efficiency, expf) from '${CURRENT_DIR}/efficiency-loads.csv' DELIMITER ',' CSV HEADER"
fi
