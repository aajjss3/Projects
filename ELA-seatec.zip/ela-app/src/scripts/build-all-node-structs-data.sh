#!/bin/bash
echo "Typically only a single node structure is needed."
echo "Examine this command to see specific correct syntax and the naming you may need"
echo "By default script will now building all existing node structure sql"

./build-node-structure-data.sh data-node-struct-320.sql A320-Node-Structure node_struct_320.csv

./build-node-structure-data.sh data-node-struct-330.sql A330-Node-Structure node_struct_330.csv

./build-node-structure-data.sh data-node-struct-737.sql B737-Node-Structure node_struct_737.csv

./build-node-structure-data.sh data-node-struct-737-3701-3771.sql B737-Two-Node-Structure node_struct_737.csv

./build-node-structure-data.sh data-node-struct-757-300.sql B757-300-Node-Structure node_struct_757-300.csv

./build-node-structure-data.sh data-node-struct-767-400.sql B767-400-Node-Structure node_struct_767-400.csv

./build-node-structure-data.sh data-node-struct-757-200-one.sql B757-200-One-Node-Structure node_struct_757-200-5635-5657,6801-6823.csv

#Note; below node structure loaded but seems to be currently unused
./build-node-structure-data.sh data-node-struct-757-200-two.sql B757-200-Two-Node-Structure node_struct_757-200-649-657,685-699,6700-6717.csv

./build-node-structure-data.sh data-node-struct-757-200-three.sql B757-200-Three-Node-Structure node_struct_757-200-658-684.csv

./build-node-structure-data.sh data-node-struct-767-300.sql B767-300-Node-Structure node_struct_767-300.csv

./build-node-structure-data.sh data-node-struct-767-3002.sql B767-300-Two-Node-Structure node_struct_767-300-1607-1613.csv

./build-node-structure-data.sh data-node-struct-767-400.sql B767-400-Node-Structure node_struct_767-400.csv

./build-node-structure-data.sh data-node-struct-777.sql B777-Node-Structure node_struct_777.csv

./build-node-structure-data.sh data-node-struct-717.sql B717-Node-Structure node_struct_717.csv
