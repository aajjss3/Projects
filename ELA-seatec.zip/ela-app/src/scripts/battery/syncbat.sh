#/bin/bash
BASE_FILENAME="data-battery.sql"
QUERY_BASE_FILENAME="query-$BASE_FILENAME"
UPDATE_BASE_FILENAME="update-$BASE_FILENAME"
AIRCRAFT_LIST=""
QUERY_VALUES="values "
QUERY_INITIAL_SIZE=${#QUERY_VALUES}

{

echo "removing base FILES query-$BASE_FILENAME and update-$BASE_FILENAME"
rm "$QUERY_BASE_FILENAME"
rm "update-$BASE_FILENAME"
echo "skipping first line header $line"
read
  echo "writing to new base files using  $QUERY_BASE_FILENAME" 
  echo "creating sql file from ela_battery_config_4.csv"
  echo "BEGIN WORK;" >$QUERY_BASE_FILENAME
  read line
  echo "skipping second line header $line"
while read line || [ "$line" ]; do
  for COLUMN in 1 4 7 10 13 16
  do
    chargeColumn=$((COLUMN+1))
#    echo "$line"
#    echo "$shipNo"
    
    shipNo=`echo $line | cut -d, -f$COLUMN | sed 's/^0*//'`
    battery_dual=`echo $line | cut -d, -f$chargeColumn | grep -i dual | sed 's/[^0-9\.]//g'`
    battery_value=`echo $line | cut -d, -f$chargeColumn | grep -v -i dual | grep -i ah | sed 's/[^0-9\.]//g'`
#    echo "$COLUMN"
#    echo "DEBUG $shipNo $battery_value $battery_dual" 
#    echo $battery_dual
#    echo $battery_value

    battery_charge=
    if [[ ! -z "$battery_dual" ]] ; then
      battery_charge=$battery_dual
      if [[ $battery_dual =~ "40" ]] ; then
        battery_charge="DUAL_40AH"
      elif [[ $battery_dual =~ "48" ]] ; then
        battery_charge="DUAL_48AH"
      fi
    elif [[ ! -z "$battery_value" ]] ; then
      if [[ $battery_value =~ "40" ]] ; then
        battery_charge="SINGLE_40AH"
      elif [[ $battery_value =~ "47" ]] ; then
        battery_charge="SINGLE_47AH"
      elif [[ $battery_value =~ "48" ]] ; then
        battery_charge="SINGLE_48AH"
      elif [[ $battery_value =~ "75" ]] ; then
        battery_charge="SINGLE_75AH"
      fi
    fi


    if [[ ! -z "$shipNo" ]] ; then
      case $battery_charge in
        SINGLE_47AH | SINGLE_75AH | SINGLE_40AH | SINGLE_48AH)
          ;;
        DUAL_48AH | DUAL_40AH)
          ;;

        *)
          data=`echo $line | cut -d, -f2 `
          echo "Unexpected shipno $shipNo with charge $battery_charge new battery charge defined $data please update script as appropriate"
          exit
          ;;
      esac

      #echo "$shipNo, $battery"
      if [[ "${#QUERY_VALUES}" -gt $QUERY_INITIAL_SIZE ]] ; then
        QUERY_VALUES="$QUERY_VALUES, ('$shipNo','$battery_charge')"
        AIRCRAFT_LIST="$AIRCRAFT_LIST, '$shipNo'"
      else
        QUERY_VALUES="$QUERY_VALUES ('$shipNo','$battery_charge')"
        AIRCRAFT_LIST="$AIRCRAFT_LIST '$shipNo'"
      fi
#      echo "$QUERY_VALUES"
#       echo "$AIRCRAFT_LIST"
    fi

  done
done
} < "ela_battery_config_4.csv"

QUERY_VALUES="$QUERY_VALUES "
echo ""
echo "$QUERY_VALUES"
echo ""
echo "$AIRCRAFT_LIST"
echo ""

# write the query sql file
echo "writing to new base files using  $QUERY_BASE_FILENAME" 
echo "creating sql file from ela_battery_config_4.csv"
echo "select aircraftshipno, battery_charge from ($QUERY_VALUES) as t (aircraftshipno, battery_charge)" >$QUERY_BASE_FILENAME
echo "except" >>$QUERY_BASE_FILENAME
echo "(select aircraftshipno, battery_charge from aircraft where aircraftshipno in ($AIRCRAFT_LIST) order by aircraftshipno)" >>$QUERY_BASE_FILENAME

# write to update sql file
echo "writing to new base files using  $UPDATE_BASE_FILENAME" 
echo "update aircraft as a set battery_charge = correct.battery_charge from ( " > $UPDATE_BASE_FILENAME
echo "select aircraftshipno, battery_charge from ($QUERY_VALUES) as t (aircraftshipno, battery_charge)" >>$UPDATE_BASE_FILENAME
echo "except" >>$UPDATE_BASE_FILENAME
echo "(select aircraftshipno, battery_charge from aircraft where aircraftshipno in ($AIRCRAFT_LIST) order by aircraftshipno)" >>$UPDATE_BASE_FILENAME
echo ") as correct where a.aircraftshipno=correct.aircraftshipno;" >> $UPDATE_BASE_FILENAME

# explain usage to the user
echo "to update elappdb run 'psql -d elaappdb -p 1532 -f $QUERY_BASE_FILENAME'"
echo "Use $UPDATE_BASE_FILENAME to perform the update"
echo "You may modify port and db name as appropriate"
echo "you may need to set the password as appropriate (i.e., PGPASSWORD=...)"

