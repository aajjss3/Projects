#!/bin/bash

if [[ $# -eq 0 ]] || [[ $# -ne 3 ]] ; then
  echo "   usage: ./full_response_time.sh [dev|uat|prod] start-date end-date"
  exit 1
fi

if [[ "$1" == "dev" ]] ; then
  LOGS="awslogs-nonprod-ela-ui awslogs-nonprod-ela-api"
elif [[ "$1" == "uat" ]] ; then
  LOGS="awslogs-nonprod-uat-ela-ui awslogs-nonprod-uat-ela-api"
else
  export AWS_PROFILE="prod"
  LOGS="awslogs-prod-ela-ui awslogs-prod-ela-api"
fi

QUERY_ID=$(aws logs start-query --log-group-names $LOGS --start-time $(date -j -f "%m/%d/%Y" "$2" "+%s") --end-time $(date -j -f "%m/%d/%Y" "$3" "+%s") --query-string 'fields @message| stats count(), avg(request_time), max(request_time)' --output text)

STATUS=$(aws logs get-query-results --query-id $QUERY_ID --query status --output text)
echo "status is $STATUS"
while [[ "$STATUS" != "Complete" ]] ; do
  sleep 5
  STATUS=$(aws logs get-query-results --query-id $QUERY_ID --query status --output text)
  echo "status is $STATUS"
done

aws logs get-query-results --query-id $QUERY_ID --output table
