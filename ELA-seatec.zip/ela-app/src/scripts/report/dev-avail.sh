#/bin/bash
PWD=`pwd`

CONFIG_FILENAME=data.json
DATA_FILENAME=dev_data.dat
CONFIG_OUT=data1.djson
DATA_OUT=dev_data1.dat

if [[ $# -eq 0 ]] || [[ $# -ne 1 ]] ; then
  echo "Usage:"
  echo " Obtains availability for dev or uat:"
  echo "   usage: ./dev-avail [dev|uat|prod]"
  exit 1
fi

if [[ "$1" == "dev" ]] ; then
  # already default to dev
  echo "using dev"
elif [[ "$1" == "uat" ]] ; then
  echo "using uat"
  CONFIG_FILENAME=uat_data.json
  DATA_FILENAME=uat_data.dat
  CONFIG_OUT=uat_data1.djson
  DATA_OUT=uat_data1.dat
elif [[ "$1" == "prod" ]] ; then
  echo "using prod"
  CONFIG_FILENAME=prod_data.json
  DATA_FILENAME=prod_data.dat
  CONFIG_OUT=prod_data1.djson
  DATA_OUT=prod_data1.dat
  export AWS_PROFILE=prod
else
  echo "invalid option: $1"
  exit 1
fi

#remove possible stale data before running
rm $CONFIG_OUT
rm $DATA_OUT

echo "using data.json configuration for AWS metrics"
grep StartTime data.json
grep EndTime data.json
echo "Requesting metrics for dev from AWS using $CONFIG_FILENAME saving to $DATA_FILENAME"
aws cloudwatch get-metric-data --cli-input-json file://./$CONFIG_FILENAME > $DATA_FILENAME

tr -d '[:space:]' < $DATA_FILENAME >$DATA_OUT
tr -d '[:space:]' < $CONFIG_FILENAME > $CONFIG_OUT
echo "Save Results to db and calculate sum"
echo "assuming success so loading into postgres"
DATA_FILE=$PWD/$DATA_OUT
CONFIG_FILE=$PWD/$CONFIG_OUT
psql -d reports -v D_FILE=$DATA_FILE -v C_FILE=$CONFIG_FILE -v DEPLOY=$1 < dev.sql

