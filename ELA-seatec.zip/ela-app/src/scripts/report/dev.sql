
create temp table foo1(data jsonb);

copy foo1(data) from :'D_FILE' csv quote e'\x01' delimiter e'\x02';

create temp table goo1(data jsonb);

copy goo1(data) from :'C_FILE' csv quote e'\x01' delimiter e'\x02';

CREATE SEQUENCE if not exists dev_avail_hist_id_seq start WITH 1 increment by 1 no minvalue no maxvalue CACHE 1;

CREATE TABLE if not exists dev_avail_hist (
  id integer NOT NULL DEFAULT nextval('dev_avail_hist_id_seq'),
  created timestamp,
  environment varchar(30),
  config jsonb,
  result jsonb
);

ALTER sequence dev_avail_hist_id_seq owned BY dev_avail_hist.id;

insert into dev_avail_hist (created, environment, config, result) values ( current_timestamp, :'DEPLOY', (select goo1.data from goo1), (select foo1.data from foo1));

with e1results as(
select jsonb_array_elements(data->'MetricDataResults'->0->'Values')::text ::float as ut from foo1
)
select count(ut), sum(ut), avg(ut), avg(ut)/5.0*100 from e1results;

with e3results as(
select jsonb_array_elements(data->'MetricDataResults'->2->'Values')::text ::float as ut from foo1
)
select count(ut), sum(ut), avg(ut) from e3results;
