#!/bin/bash

if [[ $# -eq 0 ]] || [[ $# -ne 3 ]] ; then
  echo "   usage: ./response_time_under_t.sh [dev|uat|prod] start-date end-date"
  exit 1
fi

if [[ "$1" == "dev" ]] ; then
  LOGS="awslogs-nonprod-ela-ui awslogs-nonprod-ela-api"
elif [[ "$1" == "uat" ]] ; then
  LOGS="awslogs-nonprod-uat-ela-ui awslogs-nonprod-uat-ela-api"
else
  export AWS_PROFILE="prod"
  LOGS="awslogs-prod-ela-ui awslogs-prod-ela-api"
fi

QUERY_ID=$(aws logs start-query --log-group-names $LOGS --start-time $(date -j -f "%m/%d/%Y" "$2" "+%s") --end-time $(date -j -f "%m/%d/%Y" "$3" "+%s") --query-string 'fields @message| filter @message not like /Exception/| filter ispresent(request)| filter http_user_agent not like /ELB-HealthChecker/| filter request not like /ela\\/service\\/keycloak/| filter request not like /\\/approve/| filter request not like /\\/analysis/| filter request not like /POST/ and request not like /\\/service\\/elas/| filter request_time < 5| stats count(), avg(request_time), max(request_time)' --output text)

STATUS=$(aws logs get-query-results --query-id $QUERY_ID --query status --output text)
echo "status is $STATUS"
while [[ "$STATUS" != "Complete" ]] ; do
  sleep 5
  STATUS=$(aws logs get-query-results --query-id $QUERY_ID --query status --output text)
  echo "status is $STATUS"
done

aws logs get-query-results --query-id $QUERY_ID --output table
