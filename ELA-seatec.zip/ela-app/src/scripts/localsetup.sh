#!/bin/bash

echo "Running localsetup.sh to initialize a db that has schema present"
echo "Existing Ela will be corrupted so you will need to re-run ETL"
echo "Building sql scripts"
./build-aircraft-data.sh
./build-node-structure-data.sh
./build-node-structure-data.sh data-node-struct-320.sql A320-Node-Structure node_struct_320.csv
./build-update-nodestruct-relations.sh
echo "loading efficiency tables (truncate impacts node/load of existing ela)"
./load-efficiency-data.sh
echo "loading fleet and aircraft"
psql -d elaappdb -f data-aircraft.sql
echo "loading node structure"
psql -d elaappdb -f data-node-struct.sql
psql -d elaappdb -f data-node-struct-320.sql
echo "updating fleet and node_structure relationships (fleet, aircraft, node_structure should be good now)"
psql -d elaappdb -f data-update-nodestruct-relations.sql
echo "if there were no errors you should be good to run etl which will re-generate ela"

