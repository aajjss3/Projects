#!/bin/bash

DB="elaappdb"

if [ $# -lt 3 ] ; then
  echo "export-test-data.sh table-name id-number filename [user]"
  echo "sample usage: ./export-test-data.sh templates 1 ../test/resources/datasets/templateA1.sql"
  exit 1
else
  TABLE=$1
  ID=$2
  OUTPUT_FILE=$3
fi

if [ $# -lt 4 ] ; then
  USER="clawrence"
else
  USER=$4
fi

EXPORT_TABLE="${TABLE}_export"

# create a temp table for export
psql -a -d ${DB} -c "DROP TABLE IF EXISTS ${EXPORT_TABLE}"
psql -a -d ${DB} -c "create table ${EXPORT_TABLE} as select * from ${TABLE} where id = ${ID}"
pg_dump -a -t ${EXPORT_TABLE} --column-inserts -d ${DB} > $OUTPUT_FILE
sed -i.bak -e "s/${EXPORT_TABLE}/${TABLE}/g" -e "s/^SET/--SET/" -e "s/^SELECT/--SELECT/" $OUTPUT_FILE
psql -a -d ${DB} -c "DROP TABLE ${EXPORT_TABLE}"
rm -f ${OUTPUT_FILE}.bak
