#!/usr/bin/env bash

CURRENT_DIR=`pwd`

if [[ $# -ne 0 ]] && [[ $# -ne 3 ]] && [[ $# -ne 4 ]] ; then
  echo "Can be used to load dev:"
  echo "  usage: import-ela-csv.sh [aircraftShipNo] [ElaName] [csvFile.csv] [(any data to go to dev)"
  echo "Can be use to load local:"
  echo "  usage: import-ela-csv.sh [aircraftShipNo] [ElaName] [csvFile.csv]"
  echo "  usage: import-ela-csv.sh "
  echo "Example: (import locally)"
  echo "  ./import-ela-csv.sh 3009 IMPORT_API_A321_7268_201607_3009_ELA ela3009.csv"
  echo "Example: (import aws)"
  echo "  ./import-ela-csv.sh 3009 IMPORT_API_A321_7268_201607_3009_ELA ela3009.csv aws"
  exit 1
fi

if [[ $# -eq 0 ]] ; then
  export DTO_ELA_NAME='IMPORT_API_A321_7268_201607_3009_ELA'
  export AIRCRAFT_SHIPNO='3009'
  export CSV_FILE='ela3009.csv'
  export HTTP=http://
  export HOSTURL=localhost:8086
fi
if [[ $# -eq 3 ]] ; then
  export AIRCRAFT_SHIPNO=$1
  export DTO_ELA_NAME=$2
  export CSV_FILE=$3
  export HTTP=http://
  export HOSTURL=localhost:8086
fi
if [[ $# -eq 4 ]] ; then
  export AIRCRAFT_SHIPNO=$1
  export DTO_ELA_NAME=$2
  export CSV_FILE=$3
  export HTTP=https://
  export HOSTURL=apps-sandbox.seatec.com
fi

export KK_CLIENT_ID=ela
export KK_USERNAME=elaitadminuser
export KK_PASSWORD=Abc123!!
export KK_CLIENT_SECRET=5e061925-4982-46bc-85e4-7615d4ac8a18
export KK_URL=https://apps-sandbox.seatec.com/auth/realms/appstore/protocol/openid-connect/token

echo "Getting Token"
export BEARER_TOKEN=`curl -s -H 'Content-Type: application/x-www-form-urlencoded' -d "grant_type=password&client_id=$KK_CLIENT_ID&username=$KK_USERNAME&password=$KK_PASSWORD&client_secret=$KK_CLIENT_SECRET" "$KK_URL" | grep access_token | jq -r '.access_token'`

#echo $TOKEN
export TOKEN="Authorization: Bearer $BEARER_TOKEN"
export CMD_URL=$HTTP$HOSTURL/ela/service/elas
export AIRCRAFT_URL=$HTTP$HOSTURL/ela/service/aircrafts?aircraftShipNo\=

echo "Getting AircraftId for ShipNo $AIRCRAFT_SHIPNO"
export DTO_AIRCRAFT_ID=`curl -s -X GET -H "Content-Type: application/json" -H "accept: */*"  -H "$TOKEN" "$AIRCRAFT_URL$AIRCRAFT_SHIPNO" | grep id | jq '.[] | .id'`

echo "Sending Import Request for $DTO_AIRCRAFT_ID, $DTO_ELA_NAME, $CSV_FILE"
curl -s -H "Content-Type: multipart/mixed" \
 -H "$TOKEN" \
 -F "elaDto={\"name\":\"$DTO_ELA_NAME\",\"aircraftId\":$DTO_AIRCRAFT_ID};type=application/json" \
 -F "file=@$CSV_FILE" "$CMD_URL"




