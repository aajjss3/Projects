This readme documents the steps taken to load a full list of
A321 csv files.  It is an alternative to manually doing them one by 
one on the UI.  

The advantage to this approach is that it only took about 11 minutes
to load 90 csv. Also, there is a single log file that 
allows 'grep error logfile' or individual searching to 
examine the status of each import.

Initially the files may not be on a linux system.

If necessary, tar up the existing files. With sharepoint this was a bit
painful.  I ended up syncing the drives with the windows running on mac.
Then, windows 10 I had installed a bash shell so I could go to the windows
directory and do the tar.  Then I synced the tar back.  Then I downloaded
it to the mac file space.  I hope there is an easier way as this step
is trivial with drop box that mounts to mac file system.

In any case, be sure to have the latest csv content.  The files were 
organzied with shipno as the directory and the script is based upon
the current directory/file naming method.

We used files at https://seatecshared.sharepoint.com/sites/ELATool/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FELATool%2FShared%20Documents%2FELA%20Source%20data%20files&p=true.

I did the work in ~/landing/back.

1) down load a321.tar to linux/mac clean working dirctory

2) untar the file
  tar xvf a321.tar

3) create clist list of csv files
  find . | grep csv > clist
  -inspect the list and check that there are not 2 csv files for the same aircraft then determine which to use

4) run build-import.sh to get import script
  ./build-import.sh >runIt
  chmod a+x runIt

5) Perhaps run local and one line from runIt

6) run the import list with results to log file
  ./runIt >logResult

7) Check logResult for errors to correct
    -ela may already exist in that case may have to delete prior ela to import
     (on bastion there is ./delete-ela.sh script that differs from dev it takes shipno rather than id)
    -aircraft may not exist in that case may get bad json error until you add an aircraft
     (you can load new aircraft if they have an updated list that includes it)
    -on rare occasion the csv data has issues such as maxi 40.0 nominal power and operational having
    40.1 nominal power for the same component.  They should be the same.

8) After checking out contents modify the build script to import to dev

9) Before running on dev it is a good idea to make a db backup.

10) If you want to delete the existing aircraft shipno you can create a list as follows
   ls -1 >removeShipno
   vi removeShipno
   -edit the file to remove non-shipno; then search/replace to insert './delete-shipno.sh ' at front of each line
   -save and confirm all is correct with contents of file
   chmod a+x removeShipno 






