#!/usr/bin/env bash

CURRENT_DIR=`pwd`

if [[ $# -ne 1 ]] && [[ $# -ne 2 ]] ; then
  echo "Note: Be sure to use elaId that matches DB that will be used"
  echo "Delete Ela locally"
  echo "  usage: delete-ela.sh [elaId] [optional if dev]"
  echo "Delete Ela on dev (requires tunnel in place)"
  echo "  usage: delete-ela.sh [elaId] [any if dev]"
  exit 1
fi

if [[ $# -eq 1  ]] ; then
  ELA_ID=$1
  PORT=5432
  MASTER=clawrence
fi

if [[ $# -eq 2  ]] ; then
  ELA_ID=$1
  PORT=5433
  MASTER=elamaster
  echo "Note: Script assumes rds-tunnel in use"
  echo "Note: Don't forget to clear redis cache"
fi

#PGPASSWORD should already be set.

RUN_SQL="psql -h localhost -p $PORT -U $MASTER -d elaappdb --set ON_ERROR_STOP=on --set AUTOCOMMIT=off "
#RUN_SQL="cat "

$RUN_SQL <<SQL
update node set efficiency_table_id = null where  id= ANY (
WITH RECURSIVE nodetree AS
          (SELECT id
          FROM node n
          WHERE node_id IS NULL AND ela_id = $ELA_ID 
          UNION ALL
          SELECT ni.id
          FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id)
          ) 
          SELECT * FROM nodetree);
delete from load where component_id= ANY (
select id from component where node_id= ANY (
WITH RECURSIVE nodetree AS
          (SELECT id
          FROM node n
          WHERE node_id IS NULL AND ela_id = $ELA_ID 
          UNION ALL
          SELECT ni.id
          FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id)
          ) 
          SELECT * FROM nodetree)
          );
delete from component where node_id= ANY (
WITH RECURSIVE nodetree AS
          (SELECT id
          FROM node n
          WHERE node_id IS NULL AND ela_id = $ELA_ID 
          UNION ALL
          SELECT ni.id
          FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id)
          ) 
          SELECT * FROM nodetree);
delete from node where  id= ANY (
WITH RECURSIVE nodetree AS
          (SELECT id
          FROM node n
          WHERE node_id IS NULL AND ela_id = $ELA_ID 
          UNION ALL
          SELECT ni.id
          FROM node AS ni INNER JOIN nodetree AS np ON (ni.node_id = np.id)
          ) 
          SELECT * FROM nodetree);
delete from ela where id = $ELA_ID;
commit;
SQL


