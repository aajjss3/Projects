#!/usr/bin/env bash

CURRENT_DIR=`pwd`
PORT=5432
MASTER=clawrence
#MASTER=elamaster
SHIPNO="all"
ACTION="show"
RUN_SQL="psql -h localhost -p $PORT -U $MASTER -d elaappdb --set ON_ERROR_STOP=on --set AUTOCOMMIT=off "

if [[ $# -ne 1 ]] && [[ $# -ne 2 ]] ; then
  echo "Usage: remove-stale-project-hist.sh [shipno or 'all'] ['show'(default) or 'delete']"
  echo "  Examples:"
  echo "    Show data for a particular aircraftshipno:"
  echo "      usage: remove-stale-project-hist.sh 3760 show"
  echo "    Show data for a particular all aircraft with stale project history:"
  echo "      usage: remove-stale-project-hist.sh all show"
  echo "        or"
  echo "      usage: remove-stale-project-hist.sh" all
  echo "    Delete for a particular aircraftshipno:"
  echo "      usage: remove-stale-project-hist.sh 3760 delete"
  echo "    Delete for all matching aircraftshipno:"
  echo "      usage: remove-stale-project-hist.sh all delete"
  exit 1
fi


if [[ $# -eq 1 ]] ; then
  SHIPNO=$1
fi
if [[ $# -eq 2 ]] ; then
  SHIPNO=$1
  ACTION=$2
fi
Q_SHIPNO="'$SHIPNO'"
#echo "$SHIPNO, $Q_SHIPNO, $ACTION"

if [[ $ACTION == "delete" ]] ; then
  if [[ $SHIPNO == "all" ]] ; then
    #delete for all
      SQL_CMD=" DELETE FROM aircraft_change_group WHERE id in ( select distinct(acg.id) from aircraft_change_group acg join aircraft a on a.id=acg.aircraft_id join ela e on e.aircraft_id=a.id join change_group cg on cg.id=acg.change_group_id join project p on p.id = cg.project_id where acg.aircraft_id in (select aircraft_id from ela group by aircraft_id having count(*)=1) and p.approved is not null and p.approved < e.created_date ); "
  else
    #delete for shipno 
      SQL_CMD=" DELETE FROM aircraft_change_group WHERE id in ( select distinct(acg.id) from aircraft_change_group acg join aircraft a on a.id=acg.aircraft_id join ela e on e.aircraft_id=a.id join change_group cg on cg.id=acg.change_group_id join project p on p.id = cg.project_id where acg.aircraft_id in (select aircraft_id from ela group by aircraft_id having count(*)=1) and p.approved is not null and p.approved < e.created_date and a.aircraftshipno=$Q_SHIPNO); "
  fi
else
  if [[ $SHIPNO == "all" ]] ; then
    #show for all
    SQL_CMD=" SELECT a.id, a.aircraftshipno, e.id, e.created_date, cg.name, cg.id, p.approved, p.title, p.id FROM aircraft_change_group acg join aircraft a on a.id=acg.aircraft_id join ela e on e.aircraft_id=a.id join change_group cg on cg.id=acg.change_group_id join project p on p.id = cg.project_id WHERE acg.aircraft_id in (select aircraft_id from ela group by aircraft_id having count(*)=1) and p.approved is not null and p.approved < e.created_date; "
    SQL
  else
    #show for shipno 
    SQL_CMD=" SELECT a.id, a.aircraftshipno, e.id, e.created_date, cg.name, cg.id, p.approved, p.title, p.id FROM aircraft_change_group acg join aircraft a on a.id=acg.aircraft_id join ela e on e.aircraft_id=a.id join change_group cg on cg.id=acg.change_group_id join project p on p.id = cg.project_id WHERE acg.aircraft_id in (select aircraft_id from ela group by aircraft_id having count(*)=1) and p.approved is not null and p.approved < e.created_date and a.aircraftshipno=$Q_SHIPNO; "
  fi
fi

#echo $SQL_CMD
$RUN_SQL <<SQL
begin;
$SQL_CMD
commit;
SQL


