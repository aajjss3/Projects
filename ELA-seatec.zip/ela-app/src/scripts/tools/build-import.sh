#!/bin/bash

IN_FILENAME="./clist"

{
  while read line || [ "$line" ]; do
    #echo "line: $line"
    file_name=$(echo "$line")
    ship_no=`echo $line | cut -d/ -f2`
    short_name=`echo $line | cut -d/ -f3 | sed 's/\.csv//g'`
    ela_name=$(echo "IMPORT_API_${short_name}_ELA")
    ship=$(echo "$ship_no")
    echo "./import-ela-csv.sh $ship $ela_name $file_name"
  done
  } < "$IN_FILENAME"
