#!/usr/bin/env bash

CURRENT_DIR=`pwd`

if [[ $# -eq 0 ]] || [[ $# -ne 3 ]] && [[ $# -ne 4 ]] ; then
  echo "Usage:"
  echo "  Can be used to clone on dev:"
  echo "    usage: clone-ela.sh [aircraftShipNo] [cloneShipNo] [elaName] [(any data to go to dev)"
  echo "  Can be use to clone local:"
  echo "    usage: clone-ela.sh [aircraftShipNo] [cloneShipNo] [elaName]"
  echo "    usage: clone-ela.sh "
  echo "  Example: (clone new 3011 shipno using 3001 shipno on local)"
  echo "    ./clone-ela.sh 3011 3001 CLONE_FROM_3001_API_3011_ELA "
  echo "  Example: (clone new 3010 shipno using 3001 shipno on aws dev)"
  echo "    ./clone-ela.sh 3011 3001 CLONE_FROM_3001_API_3011_ELA aws"
  if [[ $# -ne 0 ]] ; then
    exit 1
  fi
fi

if [[ $# -eq 0 ]] ; then
  export AIRCRAFT_SHIPNO='3011'
  export CLONE_AIRCRAFT_SHIPNO='3001'
  export DTO_ELA_NAME='CLONE_FROM_3001_API_3011_ELA'
  export HTTP=http://
  export HOSTURL=localhost:8086
  echo 
  echo "You can run ./clone-ela.sh -q for usage."
  echo "Default Behavior is to clone $AIRCRAFT_SHIP using $CLONE_AIRCRAFT_SHIPNO locally"
  echo "Now running same as if:  ./clone-ela.sh 3011 3001"
fi
if [[ $# -eq 3 ]] ; then
  export AIRCRAFT_SHIPNO=$1
  export CLONE_AIRCRAFT_SHIPNO=$2
  export DTO_ELA_NAME=$3
  export HTTP=http://
  export HOSTURL=localhost:8086
fi
if [[ $# -eq 4 ]] ; then
  export AIRCRAFT_SHIPNO=$1
  export CLONE_AIRCRAFT_SHIPNO=$2
  export DTO_ELA_NAME=$3
  export HTTP=https://
  export HOSTURL=apps-sandbox.seatec.com
fi

export KK_CLIENT_ID=ela
export KK_USERNAME=elaitadminuser
export KK_PASSWORD=abc123
export KK_CLIENT_SECRET=5e061925-4982-46bc-85e4-7615d4ac8a18
export KK_URL=https://apps-sandbox.seatec.com/auth/realms/appstore/protocol/openid-connect/token

echo "Getting Token"
export BEARER_TOKEN=`curl -s -i -H 'Content-Type: application/x-www-form-urlencoded' -d "grant_type=password&client_id=$KK_CLIENT_ID&username=$KK_USERNAME&password=$KK_PASSWORD&client_secret=$KK_CLIENT_SECRET" "$KK_URL" | grep access_token | jq -r '.access_token'`

#echo $TOKEN
export TOKEN="Authorization: Bearer $BEARER_TOKEN"
export CMD_URL=$HTTP$HOSTURL/ela/service/elas
export AIRCRAFT_URL=$HTTP$HOSTURL/ela/service/aircrafts?aircraftShipNo\=

echo "Getting AircraftId for ShipNo $AIRCRAFT_SHIPNO"
export DTO_AIRCRAFT_ID=`curl -s -i -X GET -H "Content-Type: application/json" -H "accept: */*"  -H "$TOKEN" "$AIRCRAFT_URL$AIRCRAFT_SHIPNO" | grep id | jq '.[] | .id'`
export DTO_CLONE_AIRCRAFT_ID=`curl -s -i -X GET -H "Content-Type: application/json" -H "accept: */*"  -H "$TOKEN" "$AIRCRAFT_URL$CLONE_AIRCRAFT_SHIPNO" | grep id | jq '.[] | .id'`

echo "Sending Import Request for $DTO_AIRCRAFT_ID, $DTO_CLONE_AIRCRAFT_ID,  $DTO_ELA_NAME"
curl -s -i -H "Content-Type: multipart/mixed" \
 -H "$TOKEN" \
 -F "elaDto={\"name\":\"$DTO_ELA_NAME\",\"aircraftId\":$DTO_AIRCRAFT_ID,\"cloneAircraftId\":$DTO_CLONE_AIRCRAFT_ID};type=application/json" "$CMD_URL"




