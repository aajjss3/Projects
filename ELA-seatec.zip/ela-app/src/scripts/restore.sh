#!/bin/bash

SCHEMA=`ls -tr ~/Dropbox/ELA\ Source\ Docs/db_backup/rds-dump-schema-*gz | tail -1`
DATA=`ls -tr ~/Dropbox/ELA\ Source\ Docs/db_backup/rds-dump-data-*gz | tail -1`
DB="elaappdb"

if [ $# -lt 3 ] ; then
  USER="clawrence"
else
  USER=$3
fi

if [ ! -f "${SCHEMA}" ] ; then
  echo "No schema backup found at ${SCHEMA}"
  exit 1
fi

if [ ! -f "${DATA}" ] ; then
  echo "No data backup found at ${DATA}"
  exit 1
fi

#set -x

cp "${SCHEMA}" .
SCHEMA_FILENAME=$(basename "${SCHEMA}")
SCHEMA_FILENAME_NOGZ=`echo "${SCHEMA_FILENAME}" | sed 's/\.gz//'`
rm -f ${SCHEMA_FILENAME_NOGZ}
gunzip ${SCHEMA_FILENAME}


# remove any revokes to rdsadmin
sed -i.bak 's/^.*rdsadmin.*//' ${SCHEMA_FILENAME_NOGZ}
# replace elamaster user with specified local user
sed -i.bak "s/elamaster/${USER}/g" ${SCHEMA_FILENAME_NOGZ}

cp "${DATA}" .
DATA_FILENAME=$(basename "${DATA}")
DATA_FILENAME_NOGZ=`echo "${DATA_FILENAME}" | sed 's/\.gz//'`
rm -f ${DATA_FILENAME_NOGZ}
gunzip ${DATA_FILENAME}

psql -a -d ${DB} < ${SCHEMA_FILENAME_NOGZ}

psql -a -d ${DB} < ${DATA_FILENAME_NOGZ}

rm ${SCHEMA_FILENAME_NOGZ}
rm ${SCHEMA_FILENAME_NOGZ}.bak
rm ${DATA_FILENAME_NOGZ}
