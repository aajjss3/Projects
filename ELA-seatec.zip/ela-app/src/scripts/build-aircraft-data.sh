#!/bin/bash

if [ $# -gt 0 ] ; then
  if [ $# -eq 1 ] ; then
    FILENAME=$1
  else
    echo "usage: build-aircraft-data.sh [filename]"
    exit 1
  fi
else
  echo "usage: build-aircraft-data.sh [filename]"
  FILENAME=data-aircraft.sql
fi

MAPFILENAME=aircraftmap.txt
echo "writing $MAPFILENAME for aircraft map information"
echo "" >$MAPFILENAME

{
# skip header line
read
  echo "writing to $FILENAME" 
  echo "creating sql file from aircraft.csv"
  echo "BEGIN WORK;" >$FILENAME
while read line || [ "$line" ]; do
  #echo "line: $line"
  shipNo=`echo $line | cut -d, -f1 | sed 's/^0*//'`
  group=`echo $line | cut -d, -f17`
  serial=`echo $line | cut -d, -f4`
  registrationnumber=`echo $line | cut -d, -f5`
  linenumber=`echo $line | cut -d, -f12`
  variablenumber=`echo $line | cut -d, -f13`
  etopsfield=`echo $line | cut -d, -f15`

  original_group=$group
  #fix typos and support desired mapping
  if [ "$group" == "A-321-211" ] ; then
    group="A321-200"
  elif [ "$group" == "A321-211" ] ; then
    group="A321-200"
  elif [ "$group" == "A200-100" ] ; then
    group="A220-100"
  elif [ "$group" == "A330-302" ] ; then
    group="A330-300"
  elif [ "$group" == "A-350-941" ] ; then
    group="A350-900"
  elif [ "$group" == "A350-941" ] ; then
    group="A350-900"
  elif [ "$group" == "A330-941" ] ; then
    group="A330-900"
  elif [ "$group" == "E767" ] ; then
    group="B767"
  elif [ "$group" == "B-737-900ER" ] ; then
    group="B737-900"
  elif [ "$group" == "B737-932ER" ] ; then
    group="B737-900"
  elif [ "$group" == "B737-900ER" ] ; then
    group="B737-900"
  elif [ "$group" == "767-300ER" ] ; then
    group="B767-300"
  elif [ "$group" == "B767-400ER" ] ; then
    group="B767-400"
  elif [ "$group" == "B757-200" ] ; then
    if [ "$etopsfield" == "ETOPS" ] ; then
      group="B757-200ETOPS"
    else
      group="B757-200"
    fi
  elif [ "$group" == "E767-300ER" ] ; then
    group="B767-300"
  elif [ "$group" == "B767-300ER" ] ; then
    group="B767-300"
  elif [ "$group" == "MD-88" ] ; then
    group="MD88"
  elif [ "$group" == "MD-90" ] ; then
    group="MD90"
  fi
  
  echo "map shipno: $shipNo, groups: $original_group  now $group" >>$MAPFILENAME

  case $group in
    A220-100 | A319-100 | A320-200 | A321-200 | A330-200 | A330-300 | A330-900 | A350-900)
      ;;

    B717-200 | B737-700 | B737-800 | B737-900 | B747-400)
      ;;

    B757-200 | B757-200ETOPS | B757-300 | B767-300 | B767-400)
      ;;

    B777-200ER | B777-200LR | MD88 | MD90)
      ;;

    *)
      echo "Unexpected new fleet defined $group please update script as appropriate"
      exit
      ;;
  esac

  manu=""
  if [[ $group == A* ]] ; then
    manu="Airbus"
  elif [[ $group == B* ]] ; then
    manu="Boeing"
  elif [[ $group == E* ]] ; then
    manu="Boeing"
  elif [[ $group == M* ]] ; then
    manu="McDonnell Douglas"
  fi

  topgroup=`echo $group | cut -d- -f1`
  echo "INSERT INTO fleet(name, manufacturer) SELECT '$topgroup','$manu' WHERE NOT EXISTS (select 1 from fleet where name='$topgroup');" >>$FILENAME
  echo "INSERT INTO fleet(fleet_id, name, manufacturer) SELECT id, '$group','$manu' FROM fleet WHERE name='$topgroup' AND NOT EXISTS (select 1 from fleet where name='$group');" >>$FILENAME
  echo "INSERT INTO aircraft(fleet_id, aircraftshipno, serialnumber, registrationnumber, linenumber, variablenumber) SELECT id, '$shipNo', '$serial', '$registrationnumber', '$linenumber', '$variablenumber' FROM fleet WHERE name='$group' AND NOT EXISTS (select 1 from aircraft where aircraftshipno='$shipNo');" >>$FILENAME
  echo "UPDATE aircraft SET fleet_id = fleet.id, serialnumber = '$serial', registrationnumber = '$registrationnumber', linenumber = '$linenumber', variablenumber = '$variablenumber' FROM fleet WHERE aircraftshipno = '$shipNo' AND name='$group';" >>$FILENAME
done
} < "aircraft.csv"

### -- From: V2_0_25__add_batteru_charge_to_aircraft.sql
### -- only updating if null
echo "update aircraft set battery_charge = 'SINGLE_48AH' where battery_charge is null and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-900');" >>$FILENAME
echo "update aircraft set battery_charge = 'SINGLE_48AH' where battery_charge is null and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-700');" >>$FILENAME
echo "update aircraft set battery_charge = 'DUAL_48AH' where battery_charge is null and (aircraftshipno != '3372' or aircraftshipno != '3373') and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-800');" >>$FILENAME
echo "update aircraft set battery_charge = 'SINGLE_48AH' where battery_charge is null and (aircraftshipno = '3772' or aircraftshipno = '3773') and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B737-800');" >>$FILENAME

### -- From: V2_0_38__fix_battery_charges_boeing.sql
echo "update aircraft set battery_charge = 'SINGLE_48AH' where battery_charge is null and ((aircraftshipno like '6%' and length(aircraftshipno) = 3) or ((aircraftshipno like '67%' and length(aircraftshipno) = 4))) and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-200');" >>$FILENAME
echo "update aircraft set battery_charge = 'SINGLE_40AH' where battery_charge is null and (aircraftshipno like '56%' and length(aircraftshipno) = 4) and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-200');" >>$FILENAME

### -- From: V2_0_38__fix_battery_charges_boeing.sql
echo "update aircraft set battery_charge = 'SINGLE_40AH' where battery_charge is null and ((aircraftshipno like '56%' and length(aircraftshipno) = 4) or ((aircraftshipno like '68%' and length(aircraftshipno) = 4))) and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-200ETOPS');" >>$FILENAME

### -- From: V2_0_38__fix_battery_charges_boeing.sql
echo "update aircraft set battery_charge = 'DUAL_40AH' where battery_charge is null and aircraftshipno like '58%' and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and f.name = 'B757-300');" >>$FILENAME

### From: V2_0_31__add_battery_for_767.sql
### Update: V2_0_35__fix_battery_config_value.sql (set 53/54 values to SINGLE_48AH)
echo "update aircraft set battery_charge = 'SINGLE_48AH' where battery_charge is null and id in (select distinct a.id from aircraft a, fleet f where a.fleet_id=f.id and (f.name = 'B767-300' or f.name = 'B767-400'));" >>$FILENAME
### -- end section added to address EPP-503, EPP-888 schema migration, EPP-1038


### -- From V2_0_40__add_battery_FOR_777.sql
echo "update aircraft set battery_charge = 'SINGLE_47AH' from aircraft a INNER JOIN fleet f ON a.fleet_id = f.id where  f.name in ('B777-200ER', 'B777-200LR') ;" >>$FILENAME

### -- From V2_0_41__correct_battery_charge.sql
### 757
echo "update aircraft set battery_charge='SINGLE_48AH' where aircraftshipno in 
('649', '650','651','652','653','654','655','658','659','660','661','662',
'663','664','665','666','667','668','669','670','671','672','673','674',
'675','676','677','678','679','670','671','672','673','674','675','676',
'678','679','680','681','682','683','684','685','686','687','688','689',
'690','691','692','693','694','695','696','697','698','699',
'6700','6701','6702','6703','6704','6705','6706','6707','6708','6709',
'6710','6711','6712','6713','6714','6715','6716','6717' ) ; " >>$FILENAME

echo "update aircraft set battery_charge='SINGLE_40AH' where aircraftshipno in 
('5635','5636','5637','5638','5639','5640','5641','5642','5643','5644','5645',
'5646','5647','5648','5649','5650','5651','5652','5653','5654','5655', '5656', 
'5657', '6801', '6802', '6803', '6804', '6805', '6806', '6807', '6808', '6809'
, '6810', '6811', '6812', '6813', '6814', '6815', '6816', '6817', '6818', '6819'
, '6820', '6821', '6822', '6823') ;" >> $FILENAME

echo "update aircraft set battery_charge='DUAL_48AH' where aircraftshipno in 
('5801', '5802','5803','5804','5805','5806','5807','5808','5809','5810',
'5811','5812','5813','5814','5815','5816') ;" >> $FILENAME

### 767
echo "update aircraft set battery_charge='SINGLE_48AH' where aircraftshipno in (
'171','172', '174', '175', '176', '177', '178', '179', '180', '181', '182', 
'183', '184', '185', '186', '187', '188', '189', '190', '191', '192', '193', 
'194', '195', '196', '197', '198', '199', '1200', '1201', '1401', '1402', '1502'
'1503', '1504', '1505', '1506', '1521', '1601', '1602', '1603', '1604', '1605', 
'1606','1607','1608','1609','1610','1611','1612','1613','1701','1702','1703',
'1704','1705','1706','1707','1708','1801','1802','1803','1804','1805','1806','1807',
'1808','1809','1810','1811','1812','1813','1814','1815','1816','1817','1818',
'1819','1820','1821') ;" >> $FILENAME

### -- From  V2_0_42__717_battery_charge.sql
echo "update aircraft set battery_charge='SINGLE_75AH' where fleet_id in (select id from fleet where name = 'B717-200');" >> $FILENAME

echo ""
echo "--- If necessary to check for stale fleet after running the script use the following sql commands:"
echo "select name from fleet where fleet.name='A200-100';"
echo "select name from fleet where fleet.name='A200';"
echo "select name from fleet where fleet.name='A321-100';"
echo "select name from fleet where fleet.name='A321-211';"
echo "select name from fleet where fleet.name='A330-941';"
echo "select name from fleet where fleet.name='B737-900ER';"
echo "select name from fleet where fleet.name='B737-932ER';"
echo "select name from fleet where fleet.name='B767-300ER';"
echo "select name from fleet where fleet.name='B767-400ER';"
echo "---- end of sql to check for stale fleets"
echo ""
echo "--- If necessary to remove stale fleet data after running script use the following sql commands:"
echo "---- performs delete only if fleet has no aircraft and no subfleet"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='A200-100' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='A200' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='A321-100' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='A321-211' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='A330-941' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='B737-900ER' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='B737-932ER' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='B767-300ER' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "delete from fleet where id in ( select fleet.id from fleet full outer join aircraft on aircraft.fleet_id = fleet.id where fleet.name='B767-400ER' and aircraft.id is null) and not exists (select * from fleet f where f.fleet_id=fleet.id);"
echo "---- end of sql to remove stale fleets"
echo ""
echo "--- run latest data-aircraft.sql to refresh aircraft (above manual sql afterwards only if required)"


echo "UPDATE fleet SET bus_structure_bucket = 'Airbus 1' WHERE name LIKE 'A3%' AND fleet_id IS NULL;" >>$FILENAME
echo "UPDATE fleet SET bus_structure_bucket = 'Airbus 2' WHERE name LIKE 'A35%' AND fleet_id IS NULL;" >>$FILENAME
echo "UPDATE fleet SET bus_structure_bucket = 'Boeing 1' WHERE name LIKE 'B7%' AND fleet_id IS NULL;" >>$FILENAME
echo "UPDATE fleet SET bus_structure_bucket = 'MD 1' WHERE name LIKE 'MD%' AND fleet_id IS NULL;" >>$FILENAME
echo "UPDATE fleet SET bus_structure_bucket = 'MD 1' WHERE name LIKE 'A7%' AND fleet_id IS NULL;" >>$FILENAME
echo "UPDATE fleet SET bus_structure_bucket = 'Boeing ETOPS 1' where name IN ('B767-300', 'B777-200ER', 'B757-300', 'B777-200LR', 'B767-400');" >>$FILENAME
echo "UPDATE fleet set etops = true where name IN ('B767-300', 'B777-200ER', 'B757-300', 'B777-200LR', 'B767-400');" >>$FILENAME

#unset B767 and B757 structure_name
echo "UPDATE fleet SET structure_name = null where name = 'B767' or name = 'B757';" >>$FILENAME

echo "COMMIT WORK;" >>$FILENAME

echo "--- Note: before executing $FILENAME confirm battery configuration in sql is as desired"
echo "--- The battery config should be consistend with flyway migrations, but there could have been manual edits"
echo "--- One option it to run on a clean db and compare battery types to existing dev system"
echo "--- (or at least run a backup before so you can recover the prior state)"
