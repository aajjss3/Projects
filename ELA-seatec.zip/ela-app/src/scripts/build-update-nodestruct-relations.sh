#!/bin/bash

if [ $# -gt 0 ] ; then
  if [ $# -eq 1 ] ; then
    FILENAME=$1
  else
    echo "usage: build-update-nodestruct-relations.sh [filename]"
    exit 1
  fi
else
  FILENAME=data-update-nodestruct-relations.sql
fi



STRUCTNAME320=A320-Node-Structure
STRUCTNAME330=A330-Node-Structure
STRUCTNAME737=B737-Node-Structure
STRUCTNAME7372=B737-Two-Node-Structure
STRUCTNAME757200=B757-200-One-Node-Structure
STRUCTNAME7572002=B757-200-Two-Node-Structure
STRUCTNAME7572003=B757-200-Three-Node-Structure
STRUCTNAME757300=B757-300-Node-Structure
STRUCTNAME767300=B767-300-Node-Structure
STRUCTNAME7673002=B767-300-Two-Node-Structure
STRUCTNAME767400=B767-400-Node-Structure
STRUCTNAME777=B777-Node-Structure
STRUCTNAME717=B717-Node-Structure

echo "Writing to $FILENAME"
echo "Using ${STRUCTNAME330}, ${STRUCTNAME320}, ${STRUCTNAME737}, ${STRUCTNAME7372}, ${STRUCTNAME767300}, ${STRUCTNAME7673002}, ${STRUCTNAME767400}, ${STRUCTNAME757200}, ${STRUCTNAME757300}, ${STRUCTNAME777, $STRUCTNAME717} for Node Structure Names"
echo "Using A330TRUTable, A330ATUTable, A320TRUTable, A320TRUESSTable, A320ATUTable, B737TRUTable, B737ATUTable for Efficiency Table Names"
echo "Update the script whenever adding new Node Structure Names or Efficiency Table Names"
echo "Run the generated sql after loading new aircraft or new node_structure changes and before doing ETL"
echo "BEGIN WORK;" >$FILENAME

echo "update fleet set structure_name = '${STRUCTNAME330}' where name like 'A330%' and name != 'A330-900';" >>$FILENAME

echo "update fleet set structure_name = '${STRUCTNAME320}' where name like 'A32%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME320}' where name like 'A31%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME737}' where name like 'B737%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME757200}' where name like 'B757-200%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME757300}' where name like 'B757-300%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME767300}' where name like 'B767-300%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME767400}' where name like 'B767-400%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME777}' where name like 'B777%';" >>$FILENAME
echo "update fleet set structure_name = '${STRUCTNAME717}' where name like 'B717%';" >>$FILENAME

echo "update node_structure set efficiency_table_name = 'A330TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME330}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'A330ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME330}';" >>$FILENAME

echo "update node_structure set efficiency_table_name = 'A320TRUTable' where node_type='TRU' and node_name not ilike '%EFF' and structure_name='${STRUCTNAME320}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'A320TRUESSTable' where node_type='TRU' and node_name ilike '%ESS' and structure_name='${STRUCTNAME320}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'A320ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME320}';" >>$FILENAME

echo "update node_structure set efficiency_table_name = 'B737TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME737}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B737ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME737}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B737TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME7372}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B737ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME7372}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME757200}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME757200}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME7572002}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME7572002}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME7572003}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME7572003}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME757300}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME757300}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME767300}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME767300}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME7673002}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME7673002}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME767400}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME767400}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME777}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME777}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B757TRUTable' where node_type='TRU' and structure_name='${STRUCTNAME717}';" >>$FILENAME
echo "update node_structure set efficiency_table_name = 'B717ATUTable' where node_type='ATU' and structure_name='${STRUCTNAME717}';" >>$FILENAME

echo "COMMIT WORK;" >>$FILENAME

# Below outputs clean up SQL that may be required at the discretion of the user. 
echo ""
echo "--- If necessary to check for stale node_structure after running the script use the following sql commands:"
echo "select distinct(structure_name) from node_structure where structure_name='B757-Node-Structure';"
echo "select distinct(structure_name) from node_structure where structure_name='B767-Node-Structure';"
echo ""
echo "--- If necessary to remove stale node_structure data after running script use the following sql commands:"
echo "---- performs delete on B757-Node-Structure and B767-Node-Structure"
echo "delete from node_structure where structure_name='B757-Node-Structure';"
echo "delete from node_structure where structure_name='B767-Node-Structure';"
echo ""







