#!/bin/bash

function result_or_null {
  if [[ -z "$1" ]] ; then
    echo "null"
  else
    if [[ -z "$2" ]]; then
      echo "'$1'"
    else
      echo "'$1 $2'"
    fi
  fi
} 


if [ $# -gt 0 ] ; then
  if [ $# -eq 3 ] ; then
    FILENAME=$1
    STRUCT_NAME=$2
    IN_FILENAME=$3
  else
    echo "usage: build-node-structure-data.sh [output filename] [struct_name] [input csv filename]"
    echo "example: ./build-node-structure-data.sh data-node-struct-320.sql A320-Node-Structure node_struct_320.csv" 
    exit 1
  fi
else
  echo "usage: build-node-structure-data.sh [filename] [struct_name] [input csv filename]"
  FILENAME=data-node-struct.sql
  IN_FILENAME=node_struct.csv
  STRUCT_NAME="A330-Node-Structure"
fi

{
# skip header line
read
  echo "writing to $FILENAME"
  echo "using struct_name $STRUCT_NAME"
  echo "creating sql file from $IN_FILENAME"
  echo 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp";' >$FILENAME
  echo "BEGIN WORK;" >>$FILENAME
  echo "DELETE from node_structure where structure_name='$STRUCT_NAME';">>$FILENAME
  row=0
while read line || [ "$line" ]; do
  #echo "line: $line"
  row=$((row+1))
  if [[ "${STRUCT_NAME}" == A* ]] ; then
    bus1=`echo $line | cut -d, -f1`
    bus2=`echo $line | cut -d, -f2`
    bus3=`echo $line | cut -d, -f3`
    bus4=`echo $line | cut -d, -f4`
    bus5=`echo $line | cut -d, -f5`
    bus6=`echo $line | cut -d, -f6`
    bus7=`echo $line | cut -d, -f7`
    nodetype=`echo $line | cut -d, -f8`
    volttype=`echo $line | cut -d, -f9`
    voltage=`echo $line | cut -d, -f10 | sed 's/[^0-9\.]//g'`
    busratingkva=`echo $line | cut -d, -f11 | grep -i kva | sed 's/[^0-9\.]//g'`
    if [[ $busratingkva == "" ]] ; then
      busratingva=`echo $line | cut -d, -f11 | grep -i VA | grep -v -i kVA | sed 's/1ph//g' | sed 's/[^0-9\.]//g'`
    else
      busratingva=$(echo "${busratingkva} * 1000" | bc)
    fi
    busratingamps=`echo $line | cut -d, -f11 | grep A | grep -v -i va | sed 's/\//~/g' |  sed 's/or/~/g' | sed 's/ //g' | sed 's/[^0-9\.|~]//g'`

    line11=`echo $line | cut -d, -f11 | tr [:lower:] [:upper:]`
    if [[ -n $busratingamps ]] && [[ $line11 =~ .*SHARE.* ]] ; then
      busratingamps="${busratingamps} SHARED"
    fi

    restricted=`echo $line | cut -d, -f12 | tr [:lower:] [:upper:]`
    if [[ -z $restricted ]] ; then
      restricted="FALSE"
    fi
    sheddable=`echo $line | cut -d, -f14 | tr [:lower] [:upper]`
    if [[ -z $sheddable ]] || [[ $sheddable =~ "NO" ]] || [[ $sheddable =~ "FALSE" ]] ; then
      sheddable="FALSE"
    else
      sheddable="TRUE"
    fi
    normaltr=`echo $line | cut -d, -f15 | tr [:lower:] [:upper]`
    if [[ -z $normaltr ]] || [[ $normaltr =~ "NO" ]] || [[ $normaltr =~ "FALSE" ]] ; then
      normaltr="FALSE"
    else
      normaltr="TRUE"
    fi
    notes=`echo $line | cut -d, -f16 | grep installed | tr [:upper:] [:lower:]`
    if [[ $notes =~ "if installed" ]] ; then
      optional="TRUE"
    else
      optional="FALSE"
    fi

    nomenclature=""
    if [[ -z $bus1  && -z $bus2 && -z $bus3 && -z $bus4 && -z $bus5 && -z $bus6 && -z $bus7 ]] ; then
      echo "skipping row ${row} no bus found"
      continue
    fi

  elif [[ "${STRUCT_NAME}" == B* ]] ; then
    #echo "line: $line"
    bus1=`echo $line | cut -d, -f1`
    bus2=`echo $line | cut -d, -f2`
    bus3=`echo $line | cut -d, -f3`
    bus4=`echo $line | cut -d, -f4`
    bus5=`echo $line | cut -d, -f5`
    bus6=`echo $line | cut -d, -f6`
    bus7=`echo $line | cut -d, -f7`
    nomenclature=`echo $line | cut -d, -f8`
    nodetype=`echo $line | cut -d, -f9`
    volttype=`echo $line | cut -d, -f10`
    voltage=`echo $line | cut -d, -f11 | sed 's/[^0-9]//g'`
    busratingkva=`echo $line | cut -d, -f12 | grep -i kva | sed 's/[^0-9\.]//g'`
    if [[ $busratingkva == "" ]] ; then
      busratingva=`echo $line | cut -d, -f12 | grep -i VA | grep -v -i kVA | sed 's/1ph//g' | sed 's/[^0-9\.]//g'`
    else
      busratingva=$(echo "${busratingkva} * 1000" | bc)
    fi
    busratingamps=`echo $line | cut -d, -f12 | grep A | grep -v -i va | sed 's/\//~/g' |  sed 's/or/~/g' | sed 's/ //g' | sed 's/[^0-9\.|~]//g'`

    line10=`echo $line | cut -d, -f12 | tr [:lower:] [:upper:]`
    if [[ -n $busratingamps ]] && [[ $line10 =~ .*SHARE.* ]] ; then
      busratingamps="${busratingamps} SHARED"
    fi

    restricted=`echo $line | cut -d, -f14 | tr [:lower:] [:upper:]`
    if [[ -z $restricted ]] ; then
      restricted="FALSE"
    fi
    sheddable=`echo $line | cut -d, -f16 | tr [:lower] [:upper]`
    if [[ -z $sheddable ]] || [[ $sheddable =~ "NO" ]] || [[ $sheddable =~ "FALSE" ]] ; then
      sheddable="FALSE"
    else
      sheddable="TRUE"
    fi
    normaltr="FALSE"
    notes=`echo $line | cut -d, -f17 | grep installed | tr [:upper:] [:lower:]`
    if [[ $notes =~ "if installed" ]] ; then
      optional="TRUE"
    else
      optional="FALSE"
    fi

    if [[ -z $bus1  && -z $bus2 && -z $bus3 && -z $bus4 && -z $bus5 && -z $bus6 && -z $bus7 ]] ; then
      echo "skipping row ${row} no bus found"
      continue
    fi
  fi

  if [[ $volttype =~ [3] ]]; then
    threephase="TRUE"
  else
    threephase="FALSE"
  fi

  #echo "result: '$bus1' '$bus2' '$bus3' '$bus4' '$bus5' '$bus6' '$nodetype' '$threephase' '$volttype' '$voltage' '$busratingva' '$busratingamps' '$sheddable' '$optional'"
  #echo "result: '$bus1' '$bus2' '$bus3' '$bus4' '$bus5' '$bus6' '$nodetype' '$volttype' '$voltage'"
  #echo "result:       '$busratingva' '$busratingamps' '$sheddable' '$optional' '$normaltr"

  if [[ !  -z $bus1 &&  $bus1 = *[!\ ]*  ]] ; then
    parent1=$bus1
    parent=""
    child=$bus1
  elif [[ !  -z $bus2 &&  $bus2 = *[!\ ]*  ]] ; then
    parent2=$bus2
    parent=$parent1
    child=$bus2
  elif [[ !  -z $bus3 &&  $bus3 = *[!\ ]*  ]] ; then
    parent3=$bus3
    parent=$parent2
    child=$bus3
  elif [[ !  -z $bus4 &&  $bus4 = *[!\ ]*  ]] ; then
    parent4=$bus4
    parent=$parent3
    child=$bus4
  elif [[ !  -z $bus5 &&  $bus5 = *[!\ ]*  ]] ; then
    parent5=$bus5
    parent=$parent4
    child=$bus5
  elif [[ !  -z $bus6 &&  $bus6 = *[!\ ]*  ]] ; then
    parent6=$bus6
    parent=$parent5
    child=$bus6
  elif [[ !  -z $bus7 &&  $bus7 = *[!\ ]*  ]] ; then
    parent=$parent6
    child=$bus7
  fi
  fvoltage=$( result_or_null $voltage )
  fbusratingva=$( result_or_null $busratingva )
  fbusratingamps=$( result_or_null $busratingamps )

  electricalphase="$volttype"
  if [[ "$volttype" == "ACA" || "$volttype" == "ACB" || "$volttype" == "ACC" ]] ; then
    volttype="AC"
  fi

  #echo "parent $parent  child $child"
  if [[ -z $parent ]] ; then
    echo "INSERT INTO node_structure(id, structure_name, node_name, node_id, display_order, node_type, three_phase, voltage_type, electrical_phase, voltage, bus_rating_va, bus_rating_amp, sheddable, requires_approval, optional, normal_tr, description) VALUES(uuid_generate_v4(), '$STRUCT_NAME', '$child', null, $row, '$nodetype', '$threephase', '$volttype', '$electricalphase', $fvoltage, $fbusratingva, $fbusratingamps, '$sheddable','$restricted', '$optional','$normaltr', '$nomenclature');" >>$FILENAME
  else
    echo "INSERT INTO node_structure(id, structure_name, node_name, node_id, display_order, node_type, three_phase, voltage_type, electrical_phase, voltage, bus_rating_va, bus_rating_amp, sheddable, requires_approval, optional, normal_tr, description) (SELECT uuid_generate_v4(), '$STRUCT_NAME', '$child', id, $row, '$nodetype', '$threephase', '$volttype', '$electricalphase', $fvoltage, $fbusratingva, $fbusratingamps, '$sheddable','$restricted', '$optional', '$normaltr', '$nomenclature' FROM node_structure WHERE structure_name='$STRUCT_NAME' AND node_name='$parent');" >>$FILENAME
  fi
done
} < "$IN_FILENAME"

echo "COMMIT WORK;" >>$FILENAME
