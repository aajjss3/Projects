--
-- PostgreSQL database dump
--

-- Dumped from database version 10.3
-- Dumped by pg_dump version 10.3

-- SET statement_timeout = 0;
-- SET lock_timeout = 0;
-- SET idle_in_transaction_session_timeout = 0;
-- SET client_encoding = 'UTF8';
-- SET standard_conforming_strings = on;
-- SELECT pg_catalog.set_config('search_path', '', false);
-- SET check_function_bodies = false;
-- SET client_min_messages = warning;
-- SET row_security = off;

--
-- Data for Name: ela; Type: TABLE DATA; Schema: public; Owner: clawrence
--

INSERT INTO public.ela (id, aircraft_id, name, created_date, created_by) VALUES (1, 1148, '30-545767-20_ELA_AppendixA_3001-3008_ELA', '2019-03-06 07:30:43.92724', 'SYSTEM');


--
-- Name: ela_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clawrence
--

SELECT pg_catalog.setval('public.ela_id_seq', 4012, true);


--
-- PostgreSQL database dump complete
--

