--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

-- SET statement_timeout = 0;
-- SET lock_timeout = 0;
-- SET idle_in_transaction_session_timeout = 0;
-- SET client_encoding = 'UTF8';
-- SET standard_conforming_strings = on;
-- SELECT pg_catalog.set_config('search_path', '', false);
-- SET check_function_bodies = false;
-- SET client_min_messages = warning;
-- SET row_security = off;

--
-- Data for Name: efficiency_table; Type: TABLE DATA; Schema: public; Owner: clawrence
--

INSERT INTO efficiency_table (id, efficiency_type, name, created, updated, version) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 'TRU', 'A330TRUTable', '2019-11-20 00:00:00', NULL, 1);
INSERT INTO efficiency_table (id, efficiency_type, name, created, updated, version) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', 'ATU', 'A330ATUTable', '2019-11-20 00:00:00', NULL, 1);


INSERT INTO efficiency_table (id, efficiency_type, name, created, updated, version) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 'TRU', 'A320TRUTable', '2019-11-20 00:00:00', NULL, 1);
INSERT INTO efficiency_table (id, efficiency_type, name, created, updated, version) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', 'ATU', 'A320ATUTable', '2019-11-20 00:00:00', NULL, 1);
INSERT INTO efficiency_table (id, efficiency_type, name, created, updated, version) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 'TRU_ESS', 'A320TRUESSTable', '2019-11-20 00:00:00', NULL, 1);
--
-- PostgreSQL database dump complete
--

