--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

-- SET statement_timeout = 0;
-- SET lock_timeout = 0;
-- SET idle_in_transaction_session_timeout = 0;
-- SET client_encoding = 'UTF8';
-- SET standard_conforming_strings = on;
-- SELECT pg_catalog.set_config('search_path', '', false);
-- SET check_function_bodies = false;
-- SET client_min_messages = warning;
-- SET row_security = off;

--
-- Data for Name: efficiency_table_efficiency_load; Type: TABLE DATA; Schema: public; Owner: clawrence
--

INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 280, 10, 0.630000000000000004, 0.554400000000000004, 0.880000000000000004);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 560, 20, 0.67000000000000004, 0.60970000000000002, 0.910000000000000031);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 840, 30, 0.910000000000000031, 0.873600000000000043, 0.959999999999999964);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 1120, 40, 0.910000000000000031, 0.873600000000000043, 0.959999999999999964);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 1400, 50, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 1680, 60, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 1960, 70, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 2240, 80, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 2520, 90, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 2800, 100, 0.92000000000000004, 0.892399999999999971, 0.969999999999999973);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 3080, 110, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 3360, 120, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 3640, 130, 0.930000000000000049, 0.911399999999999988, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 3920, 140, 0.930000000000000049, 0.911399999999999988, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 4200, 150, 0.930000000000000049, 0.911399999999999988, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 4480, 160, 0.930000000000000049, 0.911399999999999988, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 4760, 170, 0.930000000000000049, 0.911399999999999988, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 5040, 180, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 5320, 190, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 5600, 200, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 5880, 210, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('1f345933-72d8-432c-a30a-1e792386f2cb', 6160, 220, 0.92000000000000004, 0.901599999999999957, 0.979999999999999982);

INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 3, NULL, 0.489999999999999991, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 6, NULL, 0.609999999999999987, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 9, NULL, 0.709999999999999964, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 12, NULL, 0.770000000000000018, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 15, NULL, 0.810000000000000053, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 18, NULL, 0.82999999999999996, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 21, NULL, 0.849999999999999978, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 24, NULL, 0.869999999999999996, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 27, NULL, 0.890000000000000013, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 30, NULL, 0.900000000000000022, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 33, NULL, 0.910000000000000031, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 36, NULL,  0.910000000000000031, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 39, NULL, 0.92000000000000004, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 42, NULL,  0.92000000000000004, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 45, NULL,  0.92000000000000004, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 48, NULL,  0.930000000000000049, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 51, NULL, 0.930000000000000049, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 54, NULL, 0.930000000000000049, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 57, NULL, 0.930000000000000049, NULL);
INSERT INTO efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('d4f01850-639e-4592-a860-dcb0419a6d42', NULL, 60, NULL, 0.930000000000000049, NULL);


INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 140, 5, 0.699999999999999956, 0.441000000000000003, 0.630000000000000004);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 280, 10, 0.800000000000000044, 0.640000000000000013, 0.800000000000000044);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 420, 15, 0.819999999999999951, 0.713400000000000034, 0.869999999999999996);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 560, 20, 0.839999999999999969, 0.764399999999999968, 0.910000000000000031);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 700, 25, 0.849999999999999978, 0.79049999999999998, 0.930000000000000049);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 840, 30, 0.859999999999999987, 0.816999999999999948, 0.949999999999999956);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 980, 35, 0.869999999999999996, 0.835200000000000053, 0.959999999999999964);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1120, 40, 0.880000000000000004, 0.853600000000000025, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1260, 45, 0.890000000000000013, 0.863299999999999956, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1400, 50, 0.900000000000000022, 0.872999999999999998, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1540, 55, 0.900000000000000022, 0.872999999999999998, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1680, 60, 0.890000000000000013, 0.863299999999999956, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1820, 65, 0.890000000000000013, 0.872199999999999975, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 1960, 70, 0.880000000000000004, 0.862400000000000055, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2100, 75, 0.880000000000000004, 0.862400000000000055, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2240, 80, 0.869999999999999996, 0.852600000000000025, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2380, 85, 0.869999999999999996, 0.852600000000000025, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2520, 90, 0.859999999999999987, 0.834200000000000053, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2660, 95, 0.859999999999999987, 0.834200000000000053, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('0a279954-2671-49bf-8edd-abd34de8c8f4', 2800, 100, 0.849999999999999978, 0.824500000000000011, 0.969999999999999973);


INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 7.5, NULL, 0.489999999999999991, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 15, NULL, 0.609999999999999987, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 22.5, NULL, 0.709999999999999964, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 30, NULL, 0.770000000000000018, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 37.5, NULL, 0.810000000000000053, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 45, NULL, 0.82999999999999996, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 52.5, NULL, 0.849999999999999978, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 60, NULL, 0.869999999999999996, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 67.5, NULL, 0.890000000000000013, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 75, NULL, 0.900000000000000022, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 82.5, NULL, 0.910000000000000031, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 90, NULL, 0.92000000000000004, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 97.5, NULL, 0.92000000000000004, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 105, NULL, 0.92000000000000004, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 112.5, NULL, 0.92000000000000004, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 120, NULL, 0.930000000000000049, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 127.5, NULL, 0.930000000000000049, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 135, NULL, 0.930000000000000049, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 142.5, NULL, 0.930000000000000049, NULL);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('e73121cb-eef5-43d0-a9cb-02b13730fdf5', NULL, 150, NULL, 0.930000000000000049, NULL);

INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 280, 10, 0.699999999999999956, 0.441000000000000003, 0.630000000000000004);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 560, 20, 0.800000000000000044, 0.640000000000000013, 0.800000000000000044);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 840, 30, 0.819999999999999951, 0.713400000000000034, 0.869999999999999996);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 1120, 40, 0.839999999999999969, 0.764399999999999968, 0.910000000000000031);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 1400, 50, 0.849999999999999978, 0.79049999999999998, 0.930000000000000049);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 1680, 60, 0.859999999999999987, 0.816999999999999948, 0.949999999999999956);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 1960, 70, 0.869999999999999996, 0.835200000000000053, 0.959999999999999964);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 2240, 80, 0.880000000000000004, 0.853600000000000025, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 2520, 90, 0.890000000000000013, 0.863299999999999956, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 2800, 100, 0.900000000000000022, 0.872999999999999998, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 3080, 110, 0.900000000000000022, 0.872999999999999998, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 3360, 120, 0.890000000000000013, 0.863299999999999956, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 3640, 130, 0.890000000000000013, 0.872199999999999975, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 3920, 140, 0.880000000000000004, 0.862400000000000055, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 4200, 150, 0.880000000000000004, 0.862400000000000055, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 4480, 160, 0.869999999999999996, 0.852600000000000025, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 4760, 170, 0.869999999999999996, 0.852600000000000025, 0.979999999999999982);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 5040, 180, 0.859999999999999987, 0.834200000000000053, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 5320, 190, 0.859999999999999987, 0.834200000000000053, 0.969999999999999973);
INSERT INTO public.efficiency_table_efficiency_load (id, active_power, current, efficiency, expf, power_factor) VALUES ('c8ee0963-f1ce-47e9-94c9-4362cb7ed39b', 5600, 200, 0.849999999999999978, 0.824500000000000011, 0.969999999999999973);


--
-- PostgreSQL database dump complete
--

