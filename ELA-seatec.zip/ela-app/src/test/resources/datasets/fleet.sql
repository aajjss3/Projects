--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.8
-- Dumped by pg_dump version 9.6.8

-- SET statement_timeout = 0;
-- SET lock_timeout = 0;
-- SET idle_in_transaction_session_timeout = 0;
-- SET client_encoding = 'UTF8';
-- SET standard_conforming_strings = on;
-- SELECT pg_catalog.set_config('search_path', '', false);
-- SET check_function_bodies = false;
-- SET client_min_messages = warning;
-- SET row_security = off;

--
-- Data for Name: fleet; Type: TABLE DATA; Schema: public; Owner: clawrence
--

INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (36, 'B767', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (37, 'B767-300', 'Boeing', 36, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (38, 'B767-300ER', 'Boeing', 36, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (39, 'B757', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (40, 'B757-200', 'Boeing', 39, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (41, 'MD88', 'McDonnell Douglas', NULL, 'MD 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (44, 'B767-400ER', 'Boeing', 36, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (45, 'A321', 'Airbus', NULL, 'Airbus 1', 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (46, 'A321-211', 'Airbus', 45, NULL, 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (47, 'A319', 'Airbus', NULL, 'Airbus 1', 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (48, 'A319-100', 'Airbus', 47, NULL, 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (49, 'A320', 'Airbus', NULL, 'Airbus 1', 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (50, 'A320-200', 'Airbus', 49, NULL, 'A320-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (51, 'A330', 'Airbus', NULL, 'Airbus 1', 'A330-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (52, 'A330-300', 'Airbus', 51, NULL, 'A330-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (53, 'A330-200', 'Airbus', 51, NULL, 'A330-Node-Structure', false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (54, 'A350', 'Airbus', NULL, 'Airbus 2', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (55, 'A350-941', 'Airbus', 54, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (56, 'B737', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (57, 'B737-700', 'Boeing', 56, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (58, 'B737-800', 'Boeing', 56, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (59, 'B737-932ER', 'Boeing', 56, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (60, 'B737-900ER', 'Boeing', 56, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (61, 'B757-300', 'Boeing', 39, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (62, 'B747', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (63, 'B747-400', 'Boeing', 62, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (64, 'B777', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (65, 'B777-200ER', 'Boeing', 64, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (66, 'B777-200LR', 'Boeing', 64, NULL, NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (67, 'MD90', 'McDonnell Douglas', NULL, 'MD 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (68, 'B717', 'Boeing', NULL, 'Boeing 1', NULL, false);
INSERT INTO fleet (id, name, manufacturer, fleet_id, bus_structure_bucket, structure_name, archived) VALUES (69, 'B717-200', 'Boeing', 68, NULL, NULL, false);

--
-- Name: fleet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: clawrence
--

SELECT pg_catalog.setval('fleet_id_seq', 170, true);


--
-- PostgreSQL database dump complete
--

