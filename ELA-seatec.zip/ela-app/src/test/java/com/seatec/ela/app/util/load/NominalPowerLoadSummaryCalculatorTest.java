package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;

public class NominalPowerLoadSummaryCalculatorTest {

  @Test(expected = NullPointerException.class)
  public void testCalcLoadSummary_loadSummaryMap_null() {
    SummaryType summaryType = SummaryType.COMPONENTS;

    Component component = new Component();
    component.setId(4236484);
    component.setName("BTC 1 GND SPLY INTERMITTENT");
    component.setAta("2422");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("8XU1");
    component.setPanel("721VU");
    component.setNominalPower(690d);
    component.setElectricalPhase(ElectricalPhase.AC3);
    component.setIntermittent(true);

    NominalPowerLoadSummaryCalculator.calcLoadSummary(null, summaryType, component);
  }

  @Test(expected = NullPointerException.class)
  public void testCalcLoadSummary_summaryType_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    Component component = new Component();
    component.setId(4236484);
    component.setName("BTC 1 GND SPLY INTERMITTENT");
    component.setAta("2422");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("8XU1");
    component.setPanel("721VU");
    component.setNominalPower(690d);
    component.setElectricalPhase(ElectricalPhase.AC3);
    component.setIntermittent(true);

    NominalPowerLoadSummaryCalculator.calcLoadSummary(loadSummaryMap, null, component);
  }

  @Test(expected = NullPointerException.class)
  public void testCalcLoadSummary_component_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    SummaryType summaryType = SummaryType.COMPONENTS;

    NominalPowerLoadSummaryCalculator.calcLoadSummary(loadSummaryMap, summaryType, null);
  }
}
