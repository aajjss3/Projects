package com.seatec.ela.app.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class StaticInverterCalculatorTest {

  @Test
  public void testCalcLoadInAmps_batteryOnly() {
    Double voltAmperes = 12.0d;
    Double powerFactor = 0.82d;
    Double deratedDCVoltage = 24.0d;
    Double powerEfficiency = 0.82d;

    Double actualLoadInAmps =
        StaticInverterCalculator.calcLoadInAmps(
            voltAmperes, powerFactor, deratedDCVoltage, powerEfficiency);

    assertEquals(0.5d, actualLoadInAmps, 0.0d);
  }

  @Test
  public void testCalcLoadInAmps_batteryCharger() {
    Double voltAmperes = 52.0d;
    Double powerFactor = 0.82d;
    Double deratedDCVoltage = 26.0d;
    Double powerEfficiency = 0.82d;

    Double actualLoadInAmps =
        StaticInverterCalculator.calcLoadInAmps(
            voltAmperes, powerFactor, deratedDCVoltage, powerEfficiency);

    assertEquals(2.0d, actualLoadInAmps, 0.0d);
  }
}
