package com.seatec.ela.app.service.project;

import static org.junit.Assert.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.time.Instant;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ProjectServiceIT extends AbstractControllerIntegrationTest {

  @Autowired private ProjectService projectService;

  @Autowired private AircraftRepository aircraftRepo;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private AircraftChangeGroupRepo aircraftChangeGroupRepo;

  @Autowired private ProjectRepo projectRepo;

  Aircraft aircraft1;

  Aircraft aircraft2;

  Project projectApproved;

  Project projectNotApproved;

  Fleet fleetAirbus;

  Fleet fleetBoeing;

  Ela elaAirbus;

  Ela elaBoeing;

  ChangeGroup changeGroupApproved;

  ChangeGroup changeGroupNotApproved;

  AircraftChangeGroup aircraftChangeGroupApproved;

  AircraftChangeGroup aircraftChangeGroupNotApproved;

  @Before
  public void setup() {
    initializeDatabase();
  }

  @Test
  public void shouldGetProjectAnalysisForChangeGroupWhenEditNode() throws JsonProcessingException {
    List<AssignedProjectDTO> projects =
        projectService
            .getApprovedProjects(
                aircraft2.getAircraftShipNo(),
                null,
                null,
                null,
                null,
                null,
                false,
                null,
                null,
                "approved",
                true)
            .getContents();
    assertEquals(projects.size(), 1);
    assertEquals(projects.get(0).getTitle(), "project Boeing");
    assertEquals(projects.get(0).getNumber(), "100");
  }

  private void initializeDatabase() {
    // fleet(s)
    fleetAirbus = createAndSaveFleet(1);
    fleetBoeing = createAndSaveFleet(2);

    // aircraft(s)
    aircraft1 = createAndSaveAircraft(111111, fleetAirbus);
    aircraft2 = createAndSaveAircraft(222222, fleetBoeing);

    // ela(s)
    elaAirbus = createAndSaveEla("Ela Airbus", aircraft1);
    elaBoeing = createAndSaveEla("Ela Boeing", aircraft2);

    // nodes (airbus)
    Node parentNode1 =
        createAndSaveNode(
            false,
            "GEN 1",
            5d,
            10d,
            NodeType.GENERATOR,
            300d,
            ElectricalPhase.AC,
            1,
            null,
            elaAirbus);
    Node parentNode2 =
        createAndSaveNode(
            false,
            "GEN 2",
            10d,
            100d,
            NodeType.GENERATOR,
            300d,
            ElectricalPhase.DC,
            11,
            null,
            elaAirbus);
    Node childNode1 =
        createAndSaveNode(
            false, "BUS 1", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.AC, 1, parentNode1, null);
    Node childNode2 =
        createAndSaveNode(
            false,
            "BUS 2",
            50d,
            100d,
            NodeType.BUS,
            30d,
            ElectricalPhase.AC,
            11,
            parentNode1,
            null);
    Node childNode3 =
        createAndSaveNode(
            false,
            "TRU 1",
            15d,
            120d,
            NodeType.TRU,
            100d,
            ElectricalPhase.DC,
            1,
            parentNode2,
            null);

    // component(s)
    addComponentsAndLoadsToNode(childNode1);
    addComponentsAndLoadsToNode(childNode2);

    // approved project
    projectApproved = createNewProject("project Boeing", "100", true, true);

    // not approved project
    projectNotApproved = createNewProject("project Airbus", "200", false, false);

    // change group (approved project)
    changeGroupApproved = createAndSaveChangeGroup("change group", projectApproved);

    // change group (not approved project)
    changeGroupNotApproved = createAndSaveChangeGroup("change group", projectNotApproved);

    // aircraft change group (approved project)
    aircraftChangeGroupApproved = createAndSaveAircraftChangeGroup(aircraft2, changeGroupApproved);

    // aircraft change group (not approved project)
    aircraftChangeGroupNotApproved =
        createAndSaveAircraftChangeGroup(aircraft1, changeGroupNotApproved);

    // add change to Not Approved project
    NodeChange nc = new NodeChange();
    nc.setName("GEN 1");
    nc.setVoltage(10d);
    nc.setVoltageType(ElectricalPhase.AC3);
    nc.setNodeType(NodeType.GENERATOR);
    nc.setNominalPower(100d);

    Change notApprovedChangeChange = createChange();
    notApprovedChangeChange.setAction(ActionType.DELETE);
    notApprovedChangeChange.setChangeGroup(changeGroupNotApproved);
    notApprovedChangeChange.setNodeName("GEN 1");
    notApprovedChangeChange.setChanger(DEFAULT_USER_ID);
    notApprovedChangeChange.setNodeChange(nc);
    saveChange(notApprovedChangeChange);
  }

  private void addComponentsAndLoadsToNode(Node node) {
    Component component4 = createAndSaveComponent(node, "component4", ElectricalPhase.AC, 20d, 2);
    createAndSaveLoad(component4, "roll");

    Component component5 = createAndSaveComponent(node, "component5", ElectricalPhase.AC, 20d, 3);
    createAndSaveLoad(component5, "roll");
  }

  private Project createNewProject(
      String title, String nbr, boolean isChecked, boolean isApproved) {
    Project project = new Project();
    project.setApprovalEngineer(DEFAULT_USER_ID);
    project.setTitle(title);
    project.setSubmitted(Instant.now());
    project.setStarted(Instant.now());
    project.setRevisionLevel("revision level");
    project.setRetired(Instant.now());
    project.setNumber(nbr);
    project.setMaintenanceDescription("maintenance Desc");
    project.setDescription("description");
    project.setCheckEngineer("check engineer");
    project.setChecked(Instant.now());
    project.setAuthor("0");

    if (isChecked) {
      project.setChecked(Instant.now());
    }

    if (isApproved) {
      project.setApproved(Instant.now());
    }

    return projectRepo.save(project);
  }
}
