package com.seatec.ela.app.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class AircraftTest {
  @Test
  public void comparatorWithAlphaAndNumericOrder() {
    // numeric data
    Aircraft a1 = new Aircraft();
    a1.setAircraftShipNo("1");
    Aircraft a2 = new Aircraft();
    a2.setAircraftShipNo("2");
    Aircraft a1duplicate = new Aircraft();
    a1duplicate.setAircraftShipNo("1");
    Aircraft shortNumber = new Aircraft();
    shortNumber.setAircraftShipNo("10102");
    Aircraft shortNumberBig = new Aircraft();
    shortNumberBig.setAircraftShipNo("99999");
    Aircraft longNumber = new Aircraft();
    longNumber.setAircraftShipNo("101020");

    // alpha data
    Aircraft alpha1 = new Aircraft();
    alpha1.setAircraftShipNo("A");
    Aircraft alpha2 = new Aircraft();
    alpha2.setAircraftShipNo("B");
    Aircraft alpha1duplicate = new Aircraft();
    alpha1duplicate.setAircraftShipNo("A");
    Aircraft alphaAA = new Aircraft();
    alphaAA.setAircraftShipNo("AA");

    // variations of number 0
    Aircraft zero1 = new Aircraft();
    zero1.setAircraftShipNo("0");
    Aircraft zero2 = new Aircraft();
    zero2.setAircraftShipNo("00");
    Aircraft zero3 = new Aircraft();
    zero3.setAircraftShipNo("000");

    // Numeric check
    assertEquals(-1, a1.compareTo(a2));
    assertEquals(1, a2.compareTo(a1));
    assertEquals(0, a1.compareTo(a1duplicate));
    assertEquals(0, a1duplicate.compareTo(a1));
    assertEquals(-1, shortNumber.compareTo(longNumber));
    assertEquals(1, longNumber.compareTo(shortNumber));
    assertEquals(-1, shortNumber.compareTo(shortNumberBig));
    assertEquals(1, shortNumberBig.compareTo(shortNumber));
    // alpha check
    assertEquals(-1, alpha1.compareTo(alpha2));
    assertEquals(1, alpha2.compareTo(alpha1));
    assertEquals(0, alpha1.compareTo(alpha1duplicate));
    assertEquals(0, alpha1duplicate.compareTo(alpha1));
    // short alpha before long alpha
    assertEquals(-1, alpha1.compareTo(alphaAA));
    assertEquals(1, alphaAA.compareTo(alpha1));
    assertEquals(1, alpha2.compareTo(alphaAA));
    assertEquals(-1, alphaAA.compareTo(alpha2));
    // numeric before alpha
    assertEquals(-1, a1.compareTo(alpha1));
    assertEquals(1, alpha1.compareTo(a1));
    assertEquals(-1, a1.compareTo(alpha2));
    assertEquals(1, alpha2.compareTo(a1));
    assertEquals(-1, a1.compareTo(alpha2));
    assertEquals(1, alpha2.compareTo(a1));

    // Note: When compareTo and equals are not consistent it can
    // lead it issues with HashSet and TreeSet getting different
    // results
    assertFalse(zero1.equals(zero2));
    assertNotEquals(0, zero1.compareTo(zero2));
    assertFalse(zero1.equals(zero3));
    assertNotEquals(0, zero1.compareTo(zero3));
    assertEquals(-1, zero1.compareTo(zero2));
    assertEquals(1, zero2.compareTo(zero1));
    assertEquals(-2, zero1.compareTo(zero3));
    assertEquals(2, zero3.compareTo(zero1));
  }
}
