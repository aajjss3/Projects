package com.seatec.ela.app.service.project;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.enumeration.ActionType;
import edu.emory.mathcs.backport.java.util.Collections;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ChangeGroupServiceIT extends AbstractControllerIntegrationTest {

  private static final String AIRBUS = "Airbus";
  private static final String BOEING = "Boeing";

  @Autowired private ChangeGroupService subject;

  @Autowired private ElaRepository elaRepo;

  @Autowired private NodeRepository nodeRepo;

  @Autowired private AircraftRepository aircraftRepo;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private ProjectRepo projectRepo;

  private List<Long> elaIds = new ArrayList<>();

  private Node nodeA;
  private Node nodeB;

  private Fleet airbusFleet;
  private Fleet boeingFleet;

  private Ela airbusEla1;
  private Ela airbusEla2;

  private Aircraft airbusAircraft;
  private Aircraft boeingAircraft;

  private ChangeGroup airbusChangeGroup1;
  private ChangeGroup airbusChangeGroup2;

  private AircraftChangeGroup airbusAircraftChangeGroup1;
  private AircraftChangeGroup airbusAircraftChangeGroup2;

  private Project project1;

  @Before
  public void setup() {
    initializeDatabase();
  }

  @Test(expected = BadRequestException.class)
  public void
      when_findComponentsByChangeGroupAndNodeName_with_NullNodeName_then_throwBadRequestException() {
    // act
    subject.findComponentsByChangeGroupAndNodeName(airbusChangeGroup1, null);
  }

  @Test(expected = BadRequestException.class)
  public void
      when_findComponentsByChangeGroupAndNodeName_with_EmptyNodeName_then_throwBadRequestException() {
    // act
    subject.findComponentsByChangeGroupAndNodeName(airbusChangeGroup1, "");
  }

  @Test
  public void
      when_findComponentsByChangeGroupAndNodeName_with_NewNodeChangeAndComponentChange_then_return_success() {
    // arrange
    // GEN 1 => ela.getNodes().get(0)
    // 1WXP => ela.getNodes().get(0).getSubNodes().get(0)
    // 1XP => ela.getNodes().get(0).getSubNodes().get(1)
    Node existingNodeToDelete = airbusEla1.getNodes().get(0).getSubNodes().get(0);
    String existingNodeNameToDelete = existingNodeToDelete.getName();
    String existingNodeNameToAddChildNode =
        airbusEla1.getNodes().get(0).getSubNodes().get(1).getName();
    String parentNodeNameToDelete = existingNodeToDelete.getName();
    List<Change> existingChanges = new ArrayList<>();

    // node change (delete)
    NodeChange nodeChangeDelete =
        createNodeChange(
            10d,
            existingNodeNameToDelete,
            115d,
            existingNodeToDelete.getVoltageType(),
            existingNodeToDelete.getNodeType(),
            existingNodeToDelete.getNominalPower(),
            existingNodeToDelete.isRequiresApproval(),
            existingNodeToDelete.isSheddable(),
            existingNodeToDelete.isNormalTr(),
            existingNodeToDelete.getElectricalPhase());

    Change nodeToDelete =
        createAndSaveChange(
            parentNodeNameToDelete,
            null,
            ActionType.DELETE,
            DEFAULT_USER_ID,
            nodeChangeDelete,
            null,
            airbusChangeGroup1);

    // component change (delete)
    for (Component component : existingNodeToDelete.getComponents()) {
      List<LoadChange> loadChanges = java.util.Collections.emptyList();

      ComponentChange componentChange =
          createComponentChange(
              loadChanges,
              component.getElectricalPhase(),
              false,
              component.getElectIdent(),
              component.getNominalPower());
      Change componentToDelete =
          createAndSaveChange(
              existingNodeToDelete.getName(),
              component.getElectIdent(),
              ActionType.DELETE,
              DEFAULT_USER_ID,
              null,
              componentChange,
              airbusChangeGroup1);

      existingChanges.add(componentToDelete);
    }

    existingChanges.add(nodeToDelete);

    // node change (add)
    NodeChange nodeChangeToAdd =
        createNodeChange(
            10d,
            existingNodeNameToDelete,
            115d,
            existingNodeToDelete.getVoltageType(),
            existingNodeToDelete.getNodeType(),
            existingNodeToDelete.getNominalPower(),
            existingNodeToDelete.isRequiresApproval(),
            existingNodeToDelete.isSheddable(),
            existingNodeToDelete.isNormalTr(),
            existingNodeToDelete.getElectricalPhase());
    Change nodeToAdd =
        createAndSaveChange(
            existingNodeNameToAddChildNode,
            null,
            ActionType.ADD,
            DEFAULT_USER_ID,
            nodeChangeToAdd,
            null,
            airbusChangeGroup1);

    existingChanges.add(nodeToAdd);

    // component change (add)
    List<LoadChange> loadChanges = java.util.Collections.emptyList();
    String componentElecIdent = "test";

    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, componentElecIdent, 0d);
    Change componentToAdd =
        createAndSaveChange(
            existingNodeToDelete.getName(),
            componentElecIdent,
            ActionType.ADD,
            DEFAULT_USER_ID,
            null,
            componentChange,
            airbusChangeGroup1);

    existingChanges.add(componentToAdd);

    airbusChangeGroup1.setChanges(existingChanges);
    changeGroupRepo.save(airbusChangeGroup1);

    // act
    List<ComponentDto> result =
        subject.findComponentsByChangeGroupAndNodeName(
            airbusChangeGroup1, existingNodeNameToDelete);

    // assert
    Assert.assertFalse(result.isEmpty());
  }

  @Test
  public void givenChangeGroup_whenFindNodesByChangeGroupId_thenCorrect() {
    Assert.assertEquals("Should contain 2 ELAs", 2, elaIds.size());

    Assert.assertNotNull(airbusChangeGroup1);

    List<ChangeGroupNodeDto> results =
        subject.findChangeGroupEffectivityBusStructureByChangeGroupId(airbusChangeGroup1.getId());

    Assert.assertNotNull("Should contain at least 1 item in collection", results);
    Assert.assertFalse("Should contain root node(s)", results.isEmpty());
    Assert.assertEquals("Should contain 2 parent nodes", 2, results.size());

    // GEN 1
    ChangeGroupNodeDto firstNode = results.get(0);
    Assert.assertTrue(
        "First node should contain name == 'GEN 1'", firstNode.getName().equalsIgnoreCase("GEN 1"));
    Assert.assertTrue("First node should contain isGlobal == true", firstNode.getIsGlobal());
    Assert.assertEquals(
        "First node should contain 2 child nodes", 2, firstNode.getChangeGroupNodeDto().size());

    // GEN 1 > [CHILDREN]
    List<ChangeGroupNodeDto> firstNodeChildren = firstNode.getChangeGroupNodeDto();

    // GEN 1 > 1WXP
    ChangeGroupNodeDto firstChildNode = firstNodeChildren.get(0);
    Assert.assertTrue(
        "firstChildNode node should contain name == '1WXP'",
        firstChildNode.getName().equalsIgnoreCase("1WXP"));
    Assert.assertTrue(
        "firstChildNode node should contain isGlobal == true", firstChildNode.getIsGlobal());
    Assert.assertTrue(
        "firstChildNode node should contain 0 child nodes",
        firstChildNode.getChangeGroupNodeDto().isEmpty());

    // GEN 1 > 1XP
    ChangeGroupNodeDto secondChildNode = firstNodeChildren.get(1);
    Assert.assertTrue(
        "secondChildNode node should contain name == '1XP'",
        secondChildNode.getName().equalsIgnoreCase("1XP"));
    Assert.assertTrue(
        "secondChildNode node should contain isGlobal == true", secondChildNode.getIsGlobal());
    Assert.assertEquals(
        "secondChildNode node should contain 1 child nodes",
        1,
        secondChildNode.getChangeGroupNodeDto().size());

    // GEN 1 > 1XP > [CHILDREN]
    List<ChangeGroupNodeDto> secondNodeChildChildren = secondChildNode.getChangeGroupNodeDto();

    // GEN 1 > 1XP > 101XP
    ChangeGroupNodeDto secondNodeChildChildrenNode = secondNodeChildChildren.get(0);
    Assert.assertTrue(
        "secondNodeChildChildrenNode node should contain name == '101XP'",
        secondNodeChildChildrenNode.getName().equalsIgnoreCase("101XP"));
    Assert.assertFalse(
        "secondNodeChildChildrenNode node should contain isGlobal == false",
        secondNodeChildChildrenNode.getIsGlobal());
    Assert.assertTrue(
        "secondNodeChildChildrenNode node should contain 0 child nodes",
        secondNodeChildChildrenNode.getChangeGroupNodeDto().isEmpty());

    // GEN 2
    ChangeGroupNodeDto secondNode = results.get(1);
    Assert.assertTrue(
        "Second node should contain name == 'GEN 2'",
        secondNode.getName().equalsIgnoreCase("GEN 2"));
    Assert.assertTrue("Second node should contain isGlobal == true", secondNode.getIsGlobal());
    Assert.assertTrue(
        "Second node should contain 0 child node", secondNode.getChangeGroupNodeDto().isEmpty());
  }

  @Test
  public void when_saveByBusStructureBucketUsingAircraftIds_withSingleAircraft_then_save() {
    // arrange
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(boeingAircraft.getId());

    // assert (before act)
    Assert.assertEquals(
        "Project should contain 2 ChangeGroups", 2, project1.getChangeGroups().size());

    // act
    subject.saveByBusStructureBucketUsingAircraftIds(aircraftIds, project1.getId());

    // assert (after act)
    List<ChangeGroup> projectChangeGroups = changeGroupRepo.findAllByProjectId(project1.getId());

    Assert.assertEquals("Project should contain 3 ChangeGroups", 3, projectChangeGroups.size());
  }

  @Test
  public void when_UpdateEffectivity_OnManuallyCreatedChangeGroup_then_update() {
    // arrange
    Aircraft newAircraft1 =
        createAndSaveAircraft("ship4", "4000", "R4000", "Line4", "V4", airbusFleet);
    AircraftChangeGroup aircraftChangeGroup1 =
        createAndSaveAircraftChangeGroup(newAircraft1, airbusChangeGroup2);

    Aircraft newAircraft2 =
        createAndSaveAircraft("ship5", "5000", "R5000", "Line5", "V5", airbusFleet);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAndSaveAircraftChangeGroup(newAircraft2, airbusChangeGroup2);

    List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();
    aircraftChangeGroups.add(aircraftChangeGroup1);
    aircraftChangeGroups.add(aircraftChangeGroup2);

    airbusChangeGroup2.setAircraftChangeGroups(aircraftChangeGroups);
    changeGroupRepo.save(airbusChangeGroup2);

    List<Long> aircraftIds =
        airbusChangeGroup2.getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .map(Aircraft::getId)
            .collect(Collectors.toList());

    // assert (before act)
    Assert.assertEquals("Change Group should contain 2 Aircrafts", 2, aircraftIds.size());

    // act
    subject.updateEffectivity(
        Collections.singletonList(aircraftIds.get(0)),
        project1.getId(),
        airbusChangeGroup2.getId());

    // assert (after act)
    Optional<ChangeGroup> afterUpdateChangeGroup =
        changeGroupRepo.findById(airbusChangeGroup2.getId());

    Assert.assertTrue("Change Group should exist", afterUpdateChangeGroup.isPresent());

    List<Long> afterUpdateAircraftIds =
        afterUpdateChangeGroup.get().getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .map(Aircraft::getId)
            .collect(Collectors.toList());

    Assert.assertEquals("Change Group should contain 1 Aircraft", 1, afterUpdateAircraftIds.size());
  }

  @Test
  public void when_UpdateEffectivity_OnSplitChangeGroup_then_update() {
    // arrange

    // split change group
    ChangeGroup changeGroupSplit =
        createAndSaveChangeGroup(String.format("%s 1 (node [abc] split)", AIRBUS), project1);

    // aircraft(s)
    Aircraft newAircraft1 =
        createAndSaveAircraft("ship4", "4000", "R4000", "Line4", "V4", airbusFleet);
    AircraftChangeGroup aircraftChangeGroup1 =
        createAndSaveAircraftChangeGroup(newAircraft1, changeGroupSplit);

    Aircraft newAircraft2 =
        createAndSaveAircraft("ship5", "5000", "R5000", "Line5", "V5", airbusFleet);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAndSaveAircraftChangeGroup(newAircraft2, changeGroupSplit);

    List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();
    aircraftChangeGroups.add(aircraftChangeGroup1);
    aircraftChangeGroups.add(aircraftChangeGroup2);

    changeGroupSplit.setAircraftChangeGroups(aircraftChangeGroups);
    changeGroupRepo.save(changeGroupSplit);

    List<Long> aircraftIds =
        changeGroupSplit.getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .map(Aircraft::getId)
            .collect(Collectors.toList());

    // assert (before act)
    Assert.assertEquals("Change Group should contain 2 Aircrafts", 2, aircraftIds.size());

    // act
    subject.updateEffectivity(
        Collections.singletonList(aircraftIds.get(0)), project1.getId(), changeGroupSplit.getId());

    // assert (after act)
    Optional<ChangeGroup> afterUpdateChangeGroup =
        changeGroupRepo.findById(changeGroupSplit.getId());

    Assert.assertTrue("Change Group should exist", afterUpdateChangeGroup.isPresent());

    List<Long> afterUpdateAircraftIds =
        afterUpdateChangeGroup.get().getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .map(Aircraft::getId)
            .collect(Collectors.toList());

    Assert.assertEquals("Change Group should contain 1 Aircraft", 1, afterUpdateAircraftIds.size());
  }

  private void initializeDatabase() {
    String airbusBucketName1 = String.format("%s 1", AIRBUS);
    String airbusBucketName2 = String.format("%s 2", AIRBUS);
    String boeingBucketName1 = String.format("%s 1", BOEING);

    // fleet(s)
    airbusFleet = createAndSaveFleet(123, airbusBucketName1);
    boeingFleet = createAndSaveFleet(999, boeingBucketName1);

    // aircraft(s)
    airbusAircraft = createAndSaveAircraft("ship1", "1000", "R1000", "Line1", "V1", airbusFleet);
    Aircraft airbusAircraft2 =
        createAndSaveAircraft("ship2", "2000", "R2000", "Line2", "V2", airbusFleet);
    Aircraft airbusAircraft3 =
        createAndSaveAircraft("ship3", "3000", "R3000", "Line3", "V3", airbusFleet);

    boeingAircraft =
        createAndSaveAircraft("boeingShip1", "1000", "R1000", "Line1", "V1", boeingFleet);

    // ela(s)
    airbusEla1 = createAndSaveEla("ela1", airbusAircraft);
    airbusEla2 = createAndSaveEla("ela2", airbusAircraft2);
    Ela airbusEla3 = createAndSaveEla("ela3", airbusAircraft3);

    elaIds.add(airbusEla1.getId());
    elaIds.add(airbusEla2.getId());

    // node(s) -> airbusEla1
    nodeA =
        createAndSaveNode(
            false,
            "GEN 1",
            5d,
            10d,
            NodeType.GENERATOR,
            300d,
            ElectricalPhase.DC,
            11,
            null,
            airbusEla1);
    createAndSaveNode(
        false,
        "GEN 2",
        5d,
        10d,
        NodeType.GENERATOR,
        120d,
        ElectricalPhase.AC3,
        21,
        null,
        airbusEla1);
    Node node3 =
        createAndSaveNode(
            false, "1WXP", 5d, 10d, NodeType.BUS, 100d, ElectricalPhase.AC3, 31, nodeA, null);
    Node node4 =
        createAndSaveNode(
            false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC3, 41, nodeA, null);
    Node node5 =
        createAndSaveNode(
            false, "101XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC3, 11, node4, null);

    node4.addSubNode(node5);
    nodeA.addSubNode(node3);
    nodeA.addSubNode(node4);

    createAndSaveComponentWithLoads(node3, "component ABC", ElectricalPhase.DC, 20d, 2, false);
    createAndSaveComponentWithLoads(node3, "component XYZ", ElectricalPhase.AC3, 20d, 3, false);

    // Node(s) -> airbusEla2
    nodeB =
        createAndSaveNode(
            false, "one", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.DC, 11, null, airbusEla2);
    createAndSaveNode(
        false, "two", 5d, 10d, NodeType.BUS, 120d, ElectricalPhase.AC3, 21, null, airbusEla2);
    createAndSaveNode(
        false, "three", 5d, 10d, NodeType.BUS, 100d, ElectricalPhase.AC3, 31, nodeB, null);
    createAndSaveNode(
        false, "four", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, nodeB, null);

    // Node(s) -> airbusEla3
    Node rootNodeGenA =
        createAndSaveNode(
            false,
            "GEN 1",
            5d,
            10d,
            NodeType.GENERATOR,
            300d,
            ElectricalPhase.DC,
            11,
            null,
            airbusEla3);
    createAndSaveNode(
        false,
        "GEN 2",
        5d,
        10d,
        NodeType.GENERATOR,
        120d,
        ElectricalPhase.AC3,
        21,
        null,
        airbusEla3);
    Node childNode1 =
        createAndSaveNode(
            false,
            "1WXP",
            5d,
            10d,
            NodeType.BUS,
            100d,
            ElectricalPhase.AC3,
            31,
            rootNodeGenA,
            null);
    Node childNode2 =
        createAndSaveNode(
            false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC3, 41, rootNodeGenA, null);

    nodeA.addSubNode(childNode1);
    nodeA.addSubNode(childNode2);

    // project
    project1 =
        createAndSaveProject(
            "title 1",
            "description goes here.",
            "maintenance description goes here",
            "1",
            "1",
            Instant.now());

    // change group(s)
    airbusChangeGroup1 = createAndSaveChangeGroup(airbusBucketName1, project1);
    airbusChangeGroup2 = createAndSaveChangeGroup(airbusBucketName2, project1);

    // aircraft change groups
    airbusAircraftChangeGroup1 =
        createAndSaveAircraftChangeGroup(airbusAircraft, airbusChangeGroup1);
    createAndSaveAircraftChangeGroup(airbusAircraft3, airbusChangeGroup1);
    airbusAircraftChangeGroup2 =
        createAndSaveAircraftChangeGroup(airbusAircraft2, airbusChangeGroup2);
  }
}
