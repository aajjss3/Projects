package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;

public class GeneratorLoadSummaryCalculatorTest {

  @Test(expected = NullPointerException.class)
  public void testAddLoadSummariesToPhaseSummaries_loadSummaryMap_null() {

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    GeneratorLoadSummaryCalculator.addPhaseSummariesToLoadSummaries(null, loadSummaryOptions);
  }

  @Test(expected = NullPointerException.class)
  public void testAddLoadSummariesToPhaseSummaries_loadummaryOptions_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    GeneratorLoadSummaryCalculator.addPhaseSummariesToLoadSummaries(loadSummaryMap, null);
  }
}
