package com.seatec.ela.app.aop.userevent;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.seatec.ela.app.aop.userevent.LogConfig.Action;
import com.seatec.ela.app.controller.FleetController;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.util.FleetDtoConverter;
import java.util.UUID;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.OidcKeycloakAccount;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.AccessToken;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.context.SecurityContextHolder;

public class LogDetailTest {
  private IdStringInterfaceClass idStringInterfaceClass;
  private IdUUIDInterfaceClass idUUIDInterfaceClass;
  private MostInterfaceClass mostInterfaceClass;

  @Mock private OidcKeycloakAccount account;
  @Mock private KeycloakAuthenticationToken keycloakAuthenticationToken;
  @Mock private KeycloakSecurityContext keycloakSecurityContext;
  @Mock private AccessToken bearerToken;
  private String tokenSubject;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    idStringInterfaceClass = new IdStringInterfaceClass();
    idUUIDInterfaceClass = new IdUUIDInterfaceClass();
    mostInterfaceClass = new MostInterfaceClass();
    tokenSubject = UUID.randomUUID().toString();

    SecurityContextHolder.getContext().setAuthentication(keycloakAuthenticationToken);
    when(keycloakAuthenticationToken.getAccount()).thenReturn(account);
    when(account.getKeycloakSecurityContext()).thenReturn(keycloakSecurityContext);
    when(keycloakSecurityContext.getToken()).thenReturn(bearerToken);
    when(bearerToken.getSubject()).thenReturn(tokenSubject);
  }

  @Test
  public void create_detail_success_all_interfaces() {
    String testClass = "FleetController";
    String testMethod = "findFleets";
    String testHttpMethod = "GET";
    String testUri = "/service/test";
    String testRemoteAddr = "1.2.3.4";
    FleetController mockController = new FleetController();
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(mockController);
    when(joinPoint.getSignature()).thenReturn(signature);
    when(joinPoint.getArgs()).thenReturn(new String[0]); // add real ones??
    when(signature.getName()).thenReturn(testMethod);
    when(signature.getParameterNames()).thenReturn(new String[0]);

    LogUserTrackConfig config =
        new LogUserTrackConfig(testClass, testMethod, Action.SEARCH, "Fleet", null);
    String errorMessage = null;
    MockHttpServletRequest request = new MockHttpServletRequest(testHttpMethod, testUri);
    request.setUserPrincipal(keycloakAuthenticationToken);
    request.setRemoteAddr(testRemoteAddr);

    Object[] testClassList = {idStringInterfaceClass, idUUIDInterfaceClass, mostInterfaceClass};
    for (Object returnObject : testClassList) {
      String data = LogDetail.createDetail(request, config, joinPoint, returnObject, errorMessage);
      assertNotNull(data);
      JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
      // assertEquals("debug see
      // data",LogDetail.createDetail(request,config,joinPoint,returnObject,errorMessage));
      assertEquals(
          "RemoteAddress: " + testRemoteAddr, jsonObject.get(LogDetail.USER_IP_ADDR).getAsString());
      assertEquals(testUri, jsonObject.get(LogDetail.REQUEST_URI).getAsString());
      assertEquals(testHttpMethod, jsonObject.get(LogDetail.REQUEST_METHOD).getAsString());
      if (returnObject instanceof IdStringInterfaceClass) {
        assertEquals(
            "Missing Support IdStringInterface",
            ((IdStringInterfaceClass) returnObject).getId(),
            getJsonValue(jsonObject, LogDetail.PARAM_ID));
      } else if (returnObject instanceof IdUUIDInterfaceClass) {
        assertEquals(
            "Missing Support IdUUIDIngerfaceClass",
            ((IdUUIDInterfaceClass) returnObject).getId().toString(),
            getJsonValue(jsonObject, LogDetail.PARAM_ID));
      } else if (returnObject instanceof MostInterfaceClass) {
        assertEquals(
            "Missing Support MostInterfaceClass Id",
            ((MostInterfaceClass) returnObject).getId().toString(),
            getJsonValue(jsonObject, LogDetail.PARAM_ID));
        assertEquals(
            "Missing Support MostInterfaceClass AircraftId",
            ((MostInterfaceClass) returnObject).getAircraftId().toString(),
            getJsonValue(jsonObject, LogDetail.PARAM_AIRCRAFT_ID));
        assertEquals(
            "Missing Support MostInterfaceClass Author",
            ((MostInterfaceClass) returnObject).getAuthor(),
            getJsonValue(jsonObject, LogDetail.PARAM_AUTHOR));
        assertEquals(
            "Missing Support MostInterfaceClass Name",
            ((MostInterfaceClass) returnObject).getName(),
            getJsonValue(jsonObject, LogDetail.PARAM_NAME));
        assertEquals(
            "Missing Support MostInterfaceClass ShipNo",
            ((MostInterfaceClass) returnObject).getAircraftShipNo(),
            getJsonValue(jsonObject, LogDetail.PARAM_AIRCRAFT_SHIPNO));
        assertEquals(
            "Missing Support MostInterfaceClass Title",
            ((MostInterfaceClass) returnObject).getTitle(),
            getJsonValue(jsonObject, LogDetail.PARAM_TITLE));
        assertEquals(
            "Missing Support MostInterfaceClass CloneAircraft",
            ((MostInterfaceClass) returnObject).getCloneAircraftId().toString(),
            getJsonValue(jsonObject, LogDetail.PARAM_AIRCRAFT_CLONE_ID));
      }
    }
  }

  @Test
  public void create_detail_success_custom_param_names() {
    String testClass = "FleetController";
    String testMethod = "findFleets";
    String testHttpMethod = "GET";
    String testUri = "/service/test";
    String testRemoteAddr = "1.2.3.4";
    String testArg1Name = "HasEla Boolean";
    String testArg2Name = "AircraftShipNo Input";
    Long testIdParam = 1L;
    String testIdNameParam = "name";
    Object returnObject =
        FleetDtoConverter.convertToDto(
            new Fleet(
                testIdParam,
                testIdNameParam,
                "manufacturer",
                "bucket",
                "nodeStruct",
                false,
                false));
    String errorMessage = null;

    FleetController mockController = new FleetController();
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(mockController);
    when(joinPoint.getSignature()).thenReturn(signature);
    Object[] arguments = {false, "2212"};
    when(joinPoint.getArgs()).thenReturn(arguments);
    when(signature.getName()).thenReturn(testMethod);
    String[] argumentNames = "hasEla,aircraftShipNo".split(",");
    when(signature.getParameterNames()).thenReturn(argumentNames);

    String[] configParamNames = {testArg1Name, testArg2Name};
    LogUserTrackConfig config =
        new LogUserTrackConfig(testClass, testMethod, Action.SEARCH, "Fleet", configParamNames);

    MockHttpServletRequest request = new MockHttpServletRequest(testHttpMethod, testUri);
    request.setUserPrincipal(keycloakAuthenticationToken);
    request.setRemoteAddr(testRemoteAddr);
    String data = LogDetail.createDetail(request, config, joinPoint, returnObject, errorMessage);
    assertNotNull(data);
    JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
    //    assertEquals("debug see
    // data",LogDetail.createDetail(request,config,joinPoint,returnObject,errorMessage));
    assertEquals(
        "RemoteAddress: " + testRemoteAddr, jsonObject.get(LogDetail.USER_IP_ADDR).getAsString());
    assertEquals(testUri, jsonObject.get(LogDetail.REQUEST_URI).getAsString());
    assertEquals(testHttpMethod, jsonObject.get(LogDetail.REQUEST_METHOD).getAsString());
    assertEquals(testIdParam.toString(), jsonObject.get(LogDetail.PARAM_ID).getAsString());
    assertEquals(testIdNameParam, jsonObject.get(LogDetail.PARAM_NAME).getAsString());
    assertEquals(arguments[0].toString(), getJsonValue(jsonObject, configParamNames[0]));
    assertEquals(arguments[1].toString(), getJsonValue(jsonObject, configParamNames[1]));
  }

  @Test
  public void create_detail_success_existing_param_names() {
    String testClass = "FleetController";
    String testMethod = "findFleets";
    String testHttpMethod = "GET";
    String testUri = "/service/test";
    String testRemoteAddr = "1.2.3.4";
    String useParam1Name = "hasEla";
    String testArg1Name = "HasEla";
    String useParam2Name = "aircraftShipNo";
    String testArg2Name = "AircraftShipNo";
    Long testIdParam = 1L;
    String testIdNameParam = "name";
    Object returnObject =
        FleetDtoConverter.convertToDto(
            new Fleet(
                testIdParam,
                testIdNameParam,
                "manufacturer",
                "bucket",
                "nodeStruct",
                false,
                false));
    String errorMessage = null;

    FleetController mockController = new FleetController();
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(mockController);
    when(joinPoint.getSignature()).thenReturn(signature);
    Object[] arguments = {false, "2212"};
    when(joinPoint.getArgs()).thenReturn(arguments);
    when(signature.getName()).thenReturn(testMethod);
    String[] argumentNames = {useParam1Name, useParam2Name};
    when(signature.getParameterNames()).thenReturn(argumentNames);

    String[] configParamNames = null;
    LogUserTrackConfig config =
        new LogUserTrackConfig(testClass, testMethod, Action.SEARCH, "Fleet", configParamNames);

    MockHttpServletRequest request = new MockHttpServletRequest(testHttpMethod, testUri);
    request.setUserPrincipal(keycloakAuthenticationToken);
    request.setRemoteAddr(testRemoteAddr);
    String data = LogDetail.createDetail(request, config, joinPoint, returnObject, errorMessage);
    assertNotNull(data);
    JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
    // assertEquals("debug see
    // data",LogDetail.createDetail(request,config,joinPoint,returnObject,errorMessage));
    assertEquals(
        "RemoteAddress: " + testRemoteAddr, jsonObject.get(LogDetail.USER_IP_ADDR).getAsString());
    assertEquals(testUri, jsonObject.get(LogDetail.REQUEST_URI).getAsString());
    assertEquals(testHttpMethod, jsonObject.get(LogDetail.REQUEST_METHOD).getAsString());
    assertEquals(testIdParam.toString(), jsonObject.get(LogDetail.PARAM_ID).getAsString());
    assertEquals(testIdNameParam, jsonObject.get(LogDetail.PARAM_NAME).getAsString());
    assertEquals(arguments[0].toString(), getJsonValue(jsonObject, testArg1Name));
    assertEquals(arguments[1].toString(), getJsonValue(jsonObject, testArg2Name));
  }

  @Test
  public void create_detail_error_message() {
    String testClass = "FleetController";
    String testMethod = "findFleets";
    String testHttpMethod = "GET";
    String testUri = "/service/test";
    String testRemoteAddr = "1.2.3.4";
    Object returnObject = null;
    String errorMessage = "Exception Message";
    FleetController mockController = new FleetController();
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(mockController);
    when(joinPoint.getSignature()).thenReturn(signature);
    when(joinPoint.getArgs()).thenReturn(new String[0]); // add real ones??
    when(signature.getName()).thenReturn(testMethod);
    when(signature.getParameterNames()).thenReturn(new String[0]);

    LogUserTrackConfig config =
        new LogUserTrackConfig(testClass, testMethod, Action.SEARCH, "Fleet", null);

    MockHttpServletRequest request = new MockHttpServletRequest(testHttpMethod, testUri);
    request.setUserPrincipal(keycloakAuthenticationToken);
    request.setRemoteAddr(testRemoteAddr);
    String data = LogDetail.createDetail(request, config, joinPoint, returnObject, errorMessage);
    assertNotNull(data);
    JsonObject jsonObject = new JsonParser().parse(data).getAsJsonObject();
    //   assertEquals("debug see
    // data",LogDetail.createDetail(request,config,joinPoint,returnObject,errorMessage));
    assertEquals(
        "RemoteAddress: " + testRemoteAddr, jsonObject.get(LogDetail.USER_IP_ADDR).getAsString());
    assertEquals(testUri, jsonObject.get(LogDetail.REQUEST_URI).getAsString());
    assertEquals(testHttpMethod, jsonObject.get(LogDetail.REQUEST_METHOD).getAsString());
    assertEquals(errorMessage, jsonObject.get(LogDetail.ERROR_MESSAGE).getAsString());
  }

  private String getJsonValue(JsonObject jsonObject, String key) {
    JsonElement je = jsonObject.get(key);
    if (je != null) {
      return je.getAsString();
    } else {
      return "null";
    }
  }

  private class IdStringInterfaceClass implements UserTrackIdString {
    private String id = "IdStringInterfaceClass";

    @Override
    public String getId() {
      return id;
    }
  }

  private class IdUUIDInterfaceClass implements UserTrackIdUUID {
    private UUID id = UUID.randomUUID();

    @Override
    public UUID getId() {
      return id;
    }
  }

  private class MostInterfaceClass
      implements UserTrackIdLong,
          UserTrackShipNo,
          UserTrackAircraftIdLong,
          UserTrackedCloneAircraftIdLong,
          UserTrackAuthor,
          UserTrackTitle,
          UserTrackName {
    Long id = 2L;
    Long aircraftId = 3L;
    Long cloneAircraftId = 4L;
    String author = "Most Interface Author";
    String name = "Most Interface Name";
    String aircraftShipNo = "12345";
    String title = "Most Interface Title";

    @Override
    public Long getAircraftId() {
      return aircraftId;
    }

    @Override
    public String getAuthor() {
      return author;
    }

    @Override
    public Long getId() {
      return id;
    }

    @Override
    public String getName() {
      return name;
    }

    @Override
    public String getAircraftShipNo() {
      return aircraftShipNo;
    }

    @Override
    public String getTitle() {
      return title;
    }

    @Override
    public Long getCloneAircraftId() {
      return cloneAircraftId;
    }
  }
}
