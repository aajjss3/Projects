package com.seatec.ela.app.util.logging;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;
import com.seatec.ela.app.dto.LogEventDto;
import com.seatec.ela.app.util.enumeration.LogSource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;

@RunWith(MockitoJUnitRunner.class)
public class LogEventTest {
  private static Logger logger = (Logger) LoggerFactory.getLogger(LogEvent.class.getName());

  @Mock Appender appender;

  @Before
  public void setup() {
    logger.addAppender(appender);
  }

  @Test
  public void when_logEvent_with_error_status_then_logError() {
    // arrange
    String msg = "error";
    String formattedMsg = "source=[UI] url=['/ela'] message=['error']";

    LogEventDto logEventDto = createLogEvent(msg, org.slf4j.event.Level.ERROR, "/ela");

    // act
    LogEvent.log(logEventDto);

    // assert
    verify(appender, times(1))
        .doAppend(
            argThat(
                new ArgumentMatcher() {
                  @Override
                  public boolean matches(Object argument) {
                    ILoggingEvent loggingEvent = ((ILoggingEvent) argument);
                    return loggingEvent.getFormattedMessage().equals(formattedMsg)
                        && loggingEvent.getLevel().equals(Level.ERROR);
                  }
                }));
  }

  @Test
  public void when_logEvent_with_warn_status_then_logWarning() {
    // arrange
    String msg = "warn";
    String formattedMsg = "source=[UI] url=['/ela'] message=['warn']";

    LogEventDto logEventDto = createLogEvent(msg, org.slf4j.event.Level.WARN, "/ela");

    // act
    LogEvent.log(logEventDto);

    // assert
    verify(appender, times(1))
        .doAppend(
            argThat(
                new ArgumentMatcher() {
                  @Override
                  public boolean matches(Object argument) {
                    ILoggingEvent loggingEvent = ((ILoggingEvent) argument);
                    return loggingEvent.getFormattedMessage().equals(formattedMsg)
                        && loggingEvent.getLevel().equals(Level.WARN);
                  }
                }));
  }

  @Test
  public void when_logEvent_with_unmatched_status_then_logInformational() {
    // arrange
    String msg = "info";
    String formattedMsg = "source=[UI] url=['/ela'] message=['info']";

    LogEventDto logEventDto = createLogEvent(msg, org.slf4j.event.Level.INFO, "/ela");

    // act
    LogEvent.log(logEventDto);

    // assert
    verify(appender, times(1))
        .doAppend(
            argThat(
                new ArgumentMatcher() {
                  @Override
                  public boolean matches(Object argument) {
                    ILoggingEvent loggingEvent = ((ILoggingEvent) argument);
                    return loggingEvent.getFormattedMessage().equals(formattedMsg)
                        && loggingEvent.getLevel().equals(Level.INFO);
                  }
                }));
  }

  private LogEventDto createLogEvent(String msg, org.slf4j.event.Level status, String url) {
    LogEventDto logEventDto = new LogEventDto();
    logEventDto.setMessage(msg);
    logEventDto.setSource(LogSource.UI);
    logEventDto.setStatus(status);
    logEventDto.setUrl(url);
    return logEventDto;
  }
}
