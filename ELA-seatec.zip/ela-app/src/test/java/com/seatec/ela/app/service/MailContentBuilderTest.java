package com.seatec.ela.app.service;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.thymeleaf.ITemplateEngine;
import org.thymeleaf.context.Context;

public class MailContentBuilderTest {

  @Mock private ITemplateEngine mockTemplateEngine;

  @InjectMocks private MailContentBuilder subject;

  // Defined Template Names that are used to configure (confirms name still supported)
  final String templateLoginSubjectName = "mailSubjectNewLoginTemplate";
  final String templateLoginBodyName = "mailNewLoginTemplate";
  final String projectSubjectTemplateName = "mailSubjectProjectNotificationTemplate";
  final String mailProjectNotificationTemplateName = "mailProjectNotificationTemplate";
  final String mailProjectApprovalTemplateName = "mailProjectApprovalTemplate";

  // Context names used by the template (confirms they are still supported)
  private final String contextName = "name";
  private final String contextUserName = "userLoginName";
  private final String contextUserPassword = "userPassword";
  private final String contextLoginUrl = "loginUrl";
  private final String contextSupportEmail = "supportEmail";
  private final String contextCustomerName = "customerName";
  private final String contextProjectNumber = "projectNumber";
  private final String contextProjectRevision = "projectRevision";
  private final String contextProjectTitle = "projectTitle";

  // test data used in mock
  final String loginSubject = "loginSubject";
  final String loginBody = "loginBody";
  final String projectSubject = "projectSubject";
  final String projectBody = "projectBody";

  final String projectNumber = "12345";
  final String projectRevision = "A1";
  final String projectTitle = "Project Title";

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    subject = new MailContentBuilder(mockTemplateEngine);
  }

  @Test
  public void buildLoginSubject_should_return_subject() {
    when(mockTemplateEngine.process(eq(templateLoginSubjectName), any(Context.class)))
        .thenReturn(loginSubject);
    assertEquals(loginSubject, subject.buildLoginSubject("customerName"));
  }

  @Test
  public void buildProjectSubject_should_return_subject() {
    when(mockTemplateEngine.process(eq(projectSubjectTemplateName), any(Context.class)))
        .thenReturn(projectSubject);
    assertEquals(
        projectSubject,
        subject.buildProjectSubject("customerName", projectNumber, projectRevision, projectTitle));
  }

  @Test
  public void buildLoginText_should_use_expected_args_and_return_body() {
    String name = "name";
    String userName = "userName";
    String password = "password";
    String loginUrl = "loginUrl";
    String supportEmail = "supportEmail";
    String customerName = "customerName";
    doAnswer(
            new Answer() {
              @Override
              public Object answer(InvocationOnMock invocation) throws Throwable {
                Object[] arguments = invocation.getArguments();
                Context context = (Context) arguments[1];
                if (context.getVariable(contextName).equals(name)
                    && context.getVariable(contextUserName).equals(userName)
                    && context.getVariable(contextUserPassword).equals(password)
                    && context.getVariable(contextLoginUrl).equals(loginUrl)
                    && context.getVariable(contextSupportEmail).equals(supportEmail)
                    && context.getVariable(contextCustomerName).equals(customerName)) {
                  return (loginBody);
                }
                return ("loginBody did not Have Expected Parameters");
              }
            })
        .when(mockTemplateEngine)
        .process(eq(templateLoginBodyName), any(Context.class));
    assertEquals(
        loginBody,
        subject.buildLoginText(name, userName, password, loginUrl, supportEmail, customerName));
  }

  @Test
  public void buildProjectNotificationText_should_use_expected_args_and_return_body() {
    String name = "name";
    String loginUrl = "loginUrl";
    String supportEmail = "supportEmail";
    String customerName = "customerName";
    doAnswer(
            new Answer() {
              @Override
              public Object answer(InvocationOnMock invocation) throws Throwable {
                Object[] arguments = invocation.getArguments();
                Context context = (Context) arguments[1];
                if (context.getVariable(contextName).equals(name)
                    && context.getVariable(contextLoginUrl).equals(loginUrl)
                    && context.getVariable(contextSupportEmail).equals(supportEmail)
                    && context.getVariable(contextCustomerName).equals(customerName)
                    && context.getVariable(contextProjectNumber).equals(projectNumber)
                    && context.getVariable(contextProjectRevision).equals(projectRevision)
                    && context.getVariable(contextProjectTitle).equals(projectTitle)) {
                  return (projectBody);
                }
                return ("projectBody did not Have Expected Parameters");
              }
            })
        .when(mockTemplateEngine)
        .process(eq(mailProjectNotificationTemplateName), any(Context.class));
    assertEquals(
        projectBody,
        subject.buildProjectNotificationText(
            name,
            loginUrl,
            supportEmail,
            customerName,
            projectNumber,
            projectRevision,
            projectTitle));
  }

  @Test
  public void buildProjectApprovalText_should_use_expected_args_and_return_body() {
    String name = "name";
    String loginUrl = "loginUrl";
    String supportEmail = "supportEmail";
    String customerName = "customerName";
    doAnswer(
            new Answer() {
              @Override
              public Object answer(InvocationOnMock invocation) throws Throwable {
                Object[] arguments = invocation.getArguments();
                Context context = (Context) arguments[1];
                if (context.getVariable(contextName).equals(name)
                    && context.getVariable(contextLoginUrl).equals(loginUrl)
                    && context.getVariable(contextSupportEmail).equals(supportEmail)
                    && context.getVariable(contextCustomerName).equals(customerName)
                    && context.getVariable(contextProjectNumber).equals(projectNumber)
                    && context.getVariable(contextProjectRevision).equals(projectRevision)
                    && context.getVariable(contextProjectTitle).equals(projectTitle)) {
                  return (projectBody);
                }
                return ("projectBody did not Have Expected Parameters");
              }
            })
        .when(mockTemplateEngine)
        .process(eq(mailProjectApprovalTemplateName), any(Context.class));
    assertEquals(
        projectBody,
        subject.buildProjectApprovalText(
            name,
            loginUrl,
            supportEmail,
            customerName,
            projectNumber,
            projectRevision,
            projectTitle));
  }
}
