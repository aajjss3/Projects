package com.seatec.ela.app.util;

import static junit.framework.TestCase.assertEquals;

import org.junit.Test;

public class LoadUtilTest {

  @Test
  public void getVa_should_same_as_w_for_zero_var() {
    double result = LoadUtil.getVa(100, 0);
    assertEquals(100d, result);
  }

  @Test
  public void getVa_should_same_correct_value_for_nonzero_var() {
    double result = LoadUtil.getVa(100d, 10);
    assertEquals(100.4987562112089, result);
  }

  @Test
  public void getVa_should_var_for_zero_w() {
    double result = LoadUtil.getVa(0d, 10);
    assertEquals(10d, result);
  }

  @Test
  public void getVa_should_zero_for_zero_w_zero_var() {
    double result = LoadUtil.getVa(0d, 0);
    assertEquals(0d, result);
  }

  @Test
  public void getPowerFactor_should_return_1_for_zero_w() {
    double result = LoadUtil.getPowerFactor(0, 100);
    assertEquals(1.0d, result);
  }

  @Test
  public void getPowerFactor_should_return_1_for_zero_var() {
    double result = LoadUtil.getPowerFactor(10, 0);
    assertEquals(1.0d, result);
  }

  @Test
  public void getPowerFactor_should_return_correct_Value_for_nonzero_input() {
    double result = LoadUtil.getPowerFactor(10, 10);
    assertEquals(0.7071067811865476, result);
  }

  @Test
  public void getW_should_return_zero_for_zero_va() {
    double result = LoadUtil.getW(0d, 10);
    assertEquals(0d, result);
  }

  @Test
  public void getW_should_return_zero_for_zero_pf() {
    double result = LoadUtil.getW(10d, 0);
    assertEquals(0d, result);
  }

  @Test
  public void getVar_should_return_zero_for_one_pf() {
    double result = LoadUtil.getVar(100, 1.0);
    assertEquals(0d, result);
  }

  @Test
  public void getVar_should_return_zero_for_one_var() {
    double result = LoadUtil.getVar(0, 0.8);
    assertEquals(0d, result);
  }

  @Test
  public void getVar_should_return_correct_Value_for_nonzero_input() {
    double result = LoadUtil.getVar(110, 0.8);
    assertEquals(66d, result);
  }

  @Test
  public void getVar_should_return_correct_value_for_neg_va() {
    double result = LoadUtil.getVar(-1d, 1d);
    assertEquals(0d, result);
  }

  @Test
  public void getVar_should_return_correct_value_for_zero_va_and_pf() {
    double result = LoadUtil.getVar(0d, 0d);
    assertEquals(0d, result);
  }

  @Test
  public void getAmps_should_return_correct_Value_for_nonzero_va_and_pf() {
    double result = LoadUtil.getAmps(100, .9, 50);
    assertEquals(1.8, result);
  }

  @Test
  public void getAmps_should_return_correct_Value_for_nonzero_w() {
    double result = LoadUtil.getAmps(100, 50);
    assertEquals(2.0, result);
  }
}
