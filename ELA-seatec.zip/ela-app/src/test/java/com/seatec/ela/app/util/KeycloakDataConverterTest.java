package com.seatec.ela.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.seatec.ela.app.dto.KeycloakGroupDto;
import com.seatec.ela.app.dto.KeycloakUserDto;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.keycloak.representations.idm.GroupRepresentation;
import org.keycloak.representations.idm.UserRepresentation;

public class KeycloakDataConverterTest {

  private static final String ID = "2fb9ad23-dd7a-47f7-ad77-01ecedd56ea0";

  private UserRepresentation keycloakUser;
  private GroupRepresentation keycloakGroup;
  private KeycloakDataConverter keycloakDataConverter = new KeycloakDataConverter("ela");

  @Before
  public void setup() {
    keycloakUser = new UserRepresentation();
    keycloakUser.setEmail("test@mail.com");
    keycloakUser.setEmailVerified(true);
    keycloakUser.setFirstName("FirstName");
    keycloakUser.setId(ID);
    keycloakUser.setLastName("LastName");
    keycloakUser.setUsername("username");

    keycloakGroup = new GroupRepresentation();
    keycloakGroup.setName("Group 1");
    keycloakGroup.setId(ID);
  }

  @Test
  public void given_whenConvertKeycloakUserEntityToDto_thenReturnDto() throws Exception {
    KeycloakUserDto result = keycloakDataConverter.convertToUserDto(keycloakUser);

    // assert
    assertNotNull(result);
    assertEquals(keycloakUser.getId(), result.getId());
    assertEquals(keycloakUser.getFirstName(), result.getFirstName());
    assertEquals(keycloakUser.getLastName(), result.getLastName());
    assertEquals(keycloakUser.isEmailVerified(), result.getEmailVerified());
    assertEquals(keycloakUser.isEnabled(), result.getEnabled());
  }

  @Test
  public void given_whenConvertKeycloakUserEntityCollectionToDto_thenReturnDtoCollection()
      throws Exception {
    List<UserRepresentation> allUsers = Arrays.asList(keycloakUser);

    List<KeycloakUserDto> result = keycloakDataConverter.convertToUserDto(allUsers);

    // assert
    assertNotNull(result);
    assertEquals(allUsers.size(), result.size());
    assertEquals(allUsers.get(0).getId(), result.get(0).getId());
    assertEquals(allUsers.get(0).getFirstName(), result.get(0).getFirstName());
    assertEquals(allUsers.get(0).getLastName(), result.get(0).getLastName());
    assertEquals(allUsers.get(0).isEmailVerified(), result.get(0).getEmailVerified());
    assertEquals(allUsers.get(0).isEnabled(), result.get(0).getEnabled());
  }

  @Test
  public void given_whenConvertKeycloakGroupEntityToDto_thenReturnDto() throws Exception {
    KeycloakGroupDto result = KeycloakDataConverter.convertToGroupDto(keycloakGroup);

    // assert
    assertNotNull(result);
    assertEquals(keycloakGroup.getId(), result.getId());
    assertEquals(keycloakGroup.getName(), result.getName());
  }

  @Test
  public void given_whenConvertKeycloakGroupEntityCollectionToDto_thenReturnDtoCollection()
      throws Exception {
    List<GroupRepresentation> allGroups = Arrays.asList(keycloakGroup);

    List<KeycloakGroupDto> result = KeycloakDataConverter.convertToGroupDto(allGroups);

    // assert
    assertNotNull(result);
    assertEquals(allGroups.size(), result.size());
    assertEquals(allGroups.get(0).getId(), result.get(0).getId());
    assertEquals(allGroups.get(0).getName(), result.get(0).getName());
  }
}
