package com.seatec.ela.app.controller;

import static org.assertj.core.api.Assertions.anyOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.FleetNameDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class FleetControllerIT extends AbstractControllerIntegrationTest {

  @Autowired public FleetRepository fleetRepo;

  @Autowired public AircraftRepository aircraftRepo;

  private String ENDPOINT_URL = BASE_URL + "/service/fleets/";

  @Test
  public void shouldGetListWithCloakedForItAdmin() throws Exception {
    int id = 200;
    Fleet newFleet = fleetRepo.save(createFleet(id));
    Aircraft aircraft1 = createAircraft(id);
    aircraft1.setFleet(newFleet);
    aircraft1.setCloaked(true);
    aircraftRepo.save(aircraft1);
    Aircraft aircraft2 = createAircraft(id);
    aircraft2.setFleet(newFleet);
    aircraft2.setCloaked(false);
    aircraftRepo.save(aircraft2);

    ResponseEntity<String> response =
        restTemplate.exchange(ENDPOINT_URL, HttpMethod.GET, createHttpEntity(null), String.class);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("fleetName " + id));
    assertThat(
        "should not include non-cloaked without includedCloaked for itadmin",
        response.getBody(),
        not(containsString("aircraftShipNo\":\"" + aircraft1.getAircraftShipNo())));
    assertThat(
        "should include cloaked for itadmin",
        response.getBody(),
        containsString("aircraftShipNo\":\"" + aircraft2.getAircraftShipNo()));

    ResponseEntity<String> response2 =
        restTemplate.exchange(
            ENDPOINT_URL + "?includeCloaked=true",
            HttpMethod.GET,
            createHttpEntity(null),
            String.class);

    assertEquals(HttpStatus.OK, response2.getStatusCode());
    assertThat(response2.getBody(), containsString("fleetName " + id));
    assertThat(
        "should include cloaked aircraft with includeCloaked for itadmin",
        response2.getBody(),
        containsString("aircraftShipNo\":\"" + aircraft1.getAircraftShipNo()));
    assertThat(
        "should include non-cloaked aircraft for itadmin",
        response2.getBody(),
        containsString("aircraftShipNo\":\"" + aircraft2.getAircraftShipNo()));
  }

  @Test
  public void shouldGetListWitArchivedForAdmin() throws Exception {
    int id = 200;
    Fleet newFleet = fleetRepo.save(createFleet(id));
    Aircraft aircraft1 = createAircraft(id);
    aircraft1.setFleet(newFleet);
    aircraft1.setArchived(true);
    aircraftRepo.save(aircraft1);
    Aircraft aircraft2 = createAircraft(id);
    aircraft2.setFleet(newFleet);
    aircraft2.setArchived(false);
    aircraftRepo.save(aircraft2);

    Set<String> users = new HashSet<>();
    users.add(itAdminUsername);
    users.add(engineeringAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(ENDPOINT_URL, HttpMethod.GET, createHttpEntity(null), String.class);

      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertThat(response.getBody(), containsString("fleetName " + id));
      assertThat(
          "should not include non-archived without includedCloaked for admin",
          response.getBody(),
          not(containsString("aircraftShipNo\":\"" + aircraft1.getAircraftShipNo())));
      assertThat(
          "should include archived for admin",
          response.getBody(),
          containsString("aircraftShipNo\":\"" + aircraft2.getAircraftShipNo()));

      ResponseEntity<String> response2 =
          restTemplate.exchange(
              ENDPOINT_URL + "?includeCloaked=true&includeArchived=true",
              HttpMethod.GET,
              createHttpEntity(null),
              String.class);

      assertEquals(HttpStatus.OK, response2.getStatusCode());
      assertThat(response2.getBody(), containsString("fleetName " + id));
      assertThat(
          "should include archived aircraft with includeCloaked for admin",
          response2.getBody(),
          containsString("aircraftShipNo\":\"" + aircraft1.getAircraftShipNo()));
      assertThat(
          "should include non-archived aircraft for admin",
          response2.getBody(),
          containsString("aircraftShipNo\":\"" + aircraft2.getAircraftShipNo()));
    }
  }

  @Test
  public void shouldGetListWithoutCloakedForNonItAdmin() throws Exception {
    int id = 200;
    Fleet newFleet = fleetRepo.save(createFleet(id));
    Aircraft aircraft1 = createAircraft(id);
    aircraft1.setFleet(newFleet);
    aircraft1.setCloaked(true);
    aircraftRepo.save(aircraft1);
    Aircraft aircraft2 = createAircraft(id);
    aircraft2.setFleet(newFleet);
    aircraftRepo.save(aircraft2);

    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              ENDPOINT_URL, HttpMethod.GET, createHttpEntity(null, user), String.class);

      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertThat(response.getBody(), containsString("fleetName " + id));
      assertThat(
          "should not include cloaked aircraft for user " + user,
          response.getBody(),
          not(containsString("aircraftShipNo\":\"" + aircraft1.getAircraftShipNo())));
      assertThat(
          "should include non-cloaked aircraft for user " + user,
          response.getBody(),
          containsString("aircraftShipNo\":\"" + aircraft2.getAircraftShipNo()));
    }
  }

  @Test
  public void shouldGetFleetList_WithElaOnly() throws Exception {
    int id = 200;
    Fleet newFleet = fleetRepo.save(createFleet(id));

    // Aircraft with Ela
    Aircraft aircraft1 = createAircraft(id);
    aircraft1.setFleet(newFleet);
    aircraft1.addEla(createEla("33-525112-20_ELA_AppendixA_3327_ELA"));
    aircraftRepo.save(aircraft1);

    // Aircraft without Ela
    Aircraft aircraft2 = createAircraft(id + 1);
    aircraft2.setFleet(newFleet);
    aircraftRepo.save(aircraft2);

    ResponseEntity<String> response =
        restTemplate.exchange(
            "/service/fleets?hasEla=true", HttpMethod.GET, createHttpEntity(null), String.class);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("fleetName " + id));
    assertThat(response.getBody(), containsString("aircraftShipNo"));
  }

  @Test
  public void shouldCreateFleetWhenCallingCreateFleet() throws Exception {
    List excludedMatchFields = Arrays.asList(new String[] {"id", "archived"});
    Fleet fleet = createFleet(1);
    ResponseEntity<Fleet> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(fleet), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), fleet, excludedMatchFields);
  }

  @Test
  public void shouldGetFleetWhenCallingGetFleetById() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(2));
    ResponseEntity<Fleet> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.GET, createHttpEntity(null), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), fleet);
  }

  @Test
  public void shouldGetEmptyWhenCallingGetFleetByNoMatchingId() throws Exception {
    ResponseEntity<Fleet> response =
        restTemplate.exchange(
            ENDPOINT_URL + 0, HttpMethod.GET, createHttpEntity(null), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void shouldCreateSubFleetWhenCallingCreateSubFleet() throws Exception {
    List excludedMatchFields = Arrays.asList(new String[] {"id", "archived"});
    Fleet fleet = fleetRepo.save(createFleet(3));
    Fleet subFleet = createSubFleet(3);
    ResponseEntity<Fleet> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), subFleet, excludedMatchFields);
  }

  @Test
  public void shouldNotCreateSubFleetWhenCallingCreateFleetMissingRequiredField() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(4));
    Fleet subFleet = createSubFleet(4);
    subFleet.setStructureName(null);
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Missing required field."));
  }

  @Test
  public void shouldCreateSubFleetWhenCallingCreateFleetMissingRequiredFleetOnlyField()
      throws Exception {
    List excludedMatchFields = Arrays.asList(new String[] {"id", "archived"});
    Fleet fleet = fleetRepo.save(createFleet(5));
    FleetDto subFleet = createSubFleetDto(5);
    subFleet.setParentFleetId(fleet.getId());
    subFleet.setBusStructureBucket(null);
    ResponseEntity<FleetDto> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), FleetDto.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), subFleet, excludedMatchFields);
  }

  @Test
  public void shouldNotCreateFleetWhenCallingCreateFleetMissingRequiredFleetOnlyField()
      throws Exception {
    Fleet fleet = createFleet(6);
    fleet.setBusStructureBucket(null);
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(fleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Missing required field."));
  }

  @Test
  public void shouldNotCreateSubFleetWhenCallingCreateFleetInvalidFieldContent() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(7));
    Fleet subFleet = createSubFleet(7);
    subFleet.setStructureName(" fullofbad%$#@!chars ");
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("must match"));
  }

  @Test
  public void shouldNotCreateSubFleetWhenCallingCreateFleetWithNotMatchingParent()
      throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(8));
    FleetDto subFleet = createSubFleetDto(8);
    subFleet.setParentFleetId(0L);
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Parent Id not valid\""));
  }

  @Test
  public void shouldNotCreateSubFleetWhenCallingCreateFleetWithExistingName() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(9));
    Fleet subFleet = createSubFleet(9);
    subFleet.setName(fleet.getName());
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(subFleet), String.class);
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString(
            "Constraint Violation: Check for Unique Name and Required Fields With Valid Content"));
  }

  @Test
  public void shouldNotModifySubFleetWhenCallingUpdateFleetWithExistingName() throws Exception {
    Fleet existingFleet = fleetRepo.save(createFleet(19));
    Fleet newFleet = fleetRepo.save(createSubFleet(20));
    newFleet.setName(existingFleet.getName());
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + newFleet.getId(),
            HttpMethod.PUT,
            createHttpEntity(newFleet),
            String.class);
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString(
            "Constraint Violation: Check for Unique Name and Required Fields With Valid Content"));
  }

  @Test
  public void shouldUpdateArchivedWhenCallingUpdate() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(10));
    fleet.setArchived(true);
    ResponseEntity<Fleet> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.PUT, createHttpEntity(fleet), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), fleet);
  }

  @Test
  public void shouldNotUpdateArchiveWhenCallingUpdateWithNullId() throws Exception {
    Fleet fleet = createFleet(11);
    fleet.setArchived(true);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.PUT, createHttpEntity(fleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Fleet Resource invalid Id"));
  }

  @Test
  public void shouldUpdateNotArchiveWhenCallingUpdateWithBadId() throws Exception {
    Fleet fleet = createFleet(12);
    fleet.setId(0L);
    fleet.setArchived(true);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.PUT, createHttpEntity(fleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Fleet Resource id 0 not found"));
  }

  @Test
  public void shouldNotUpdateWhenCallingUpdateFleetWithoutBucket() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(13));
    fleet.setBusStructureBucket(null);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.PUT, createHttpEntity(fleet), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Missing required field."));
  }

  @Test
  public void shouldDeleteWhenCallingDeleteNoSubFleetOrAircraft() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(14));
    ResponseEntity<Fleet> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.DELETE, createHttpEntity(null), Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void shouldDeleteWhenCallingDeleteWithSubFleet() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(15));
    Fleet subFleet = createSubFleet(12);
    subFleet.setParentFleet(fleet);
    fleetRepo.save(subFleet);
    ResponseEntity<Fleet> response =
        restTemplate.exchange(
            ENDPOINT_URL + subFleet.getId(),
            HttpMethod.DELETE,
            createHttpEntity(null),
            Fleet.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void shouldNotDeleteWhenCallingDeleteWithAircraft() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(16));
    fleetRepo.save(fleet);
    Aircraft aircraft =
        new Aircraft(
            "1111",
            "1234",
            "registrationNumber",
            "linenumber",
            "variableNumber",
            null,
            null,
            fleet);
    aircraftRepo.save(aircraft);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.DELETE, createHttpEntity(null), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Aircraft and SubFleet must be zero"));
  }

  @Test
  public void shouldNotDeleteWhenCallingDeleteWithSubFleet() throws Exception {
    Fleet fleet = fleetRepo.save(createFleet(17));
    Fleet subFleet = createSubFleet(14);
    subFleet.setParentFleet(fleet);
    fleetRepo.save(subFleet);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleet.getId(), HttpMethod.DELETE, createHttpEntity(null), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Aircraft and SubFleet must be zero"));
  }

  @Test
  public void shouldNotDeleteWhenCallingDeleteAndNotFound() throws Exception {
    FleetDto fleetDto = createFleetDto(18);
    fleetDto.setId(0L);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + fleetDto.getId(),
            HttpMethod.DELETE,
            createHttpEntity(fleetDto),
            String.class);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString("No class com.seatec.ela.app.model.Fleet entity with id 0 exists!"));
  }

  @Test
  public void shouldReturnFleetNamesWhenCallingGetFleetNames() {
    // create fleet data
    // fleet1 has one subfleet (subFleet4)
    Fleet fleet1 = fleetRepo.save(createFleet(1));
    // fleet2 has two subfleets( subFleet5 and subFleet6)
    Fleet fleet2 = fleetRepo.save(createFleet(2));
    // fleet3 has no subfleets
    Fleet fleet3 = fleetRepo.save(createFleet(3));
    Fleet subFleet4 = createSubFleet(4);
    Fleet subFleet5 = createSubFleet(5);
    Fleet subFleet6 = createSubFleet(6);
    subFleet4.setParentFleet(fleet1);
    subFleet5.setParentFleet(fleet2);
    subFleet6.setParentFleet(fleet2);
    fleetRepo.save(subFleet4);
    fleetRepo.save(subFleet5);
    fleetRepo.save(subFleet6);

    ResponseEntity<List<FleetNameDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "names",
            HttpMethod.GET,
            createHttpEntity(null),
            new ParameterizedTypeReference<List<FleetNameDTO>>() {});

    for (FleetNameDTO fleet : response.getBody()) {
      assertThat(fleet.getName(), anyOf(is("fleetName 1"), is("fleetName 2"), is("fleetName 3")));
      if (fleet.getName().equals("fleetName 1")) {
        assertEquals(fleet.getSubFleets().get(0).getName(), "fleetName 1 subFleet4");
      } else if (fleet.getName().equals("fleetName 2")) {
        assertEquals(fleet.getSubFleets().get(0).getName(), "fleetName 1 subFleet5");
        assertEquals(fleet.getSubFleets().get(1).getName(), "fleetName 1 subFleet6");
      }
    }
  }
}
