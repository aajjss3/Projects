package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;

public class AtuLoadSummaryCalculatorTest {

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_loadSummaryMap_null() {
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.ATU);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        null, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_summaryType_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.ATU);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, null, loadSummaryOptions, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_loadSummaryOptions_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    SummaryType summaryType = SummaryType.COMPONENTS;

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.ATU);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, null, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_node_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.ATU);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, null, topMostAncestorTransformer);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCalculateLoadSummaries_node_not_ATU() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.GENERATOR);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, node, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCalculateLoadSummaries_ancestorTransformerNode_not_ATU() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.GENERATOR);

    AtuLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
  }
}
