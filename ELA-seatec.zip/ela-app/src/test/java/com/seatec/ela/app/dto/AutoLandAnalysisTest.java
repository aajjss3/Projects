package com.seatec.ela.app.dto;

import static org.junit.Assert.assertEquals;

import com.seatec.ela.app.dto.analysis.AutoLandAnalysis;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysisNode;
import org.junit.Test;

public class AutoLandAnalysisTest {

  @Test
  public void testGetTotalLoadInAmpsSummary() {
    AutoLandAnalysis analysis = new AutoLandAnalysis();

    assertEquals(0.0d, analysis.getTotalLoadInAmpsSummary(), 0.0d);

    analysis.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysis.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysis.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysis.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysis.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    assertEquals(5.0d, analysis.getTotalLoadInAmpsSummary(), 0.0d);
  }
}
