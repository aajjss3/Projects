package com.seatec.ela.app.util.load;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummarizedLoad.Units;
import com.seatec.ela.app.model.SummaryType;
import java.lang.reflect.Method;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.transaction.Transactional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
@Transactional
public class GeneratorLoadSummaryCalculatorIT {

  GeneratorLoadSummaryCalculator generatorLoadSummaryCalculator;

  private Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();
  private LoadSummaryOptions loadSummaryOptions =
      new LoadSummaryOptions(true, true, true, true, true);
  private static final Double MAX_ALLOWED_DELTA = .0000000003d;

  @Before
  public void setup() {
    testData();
    try {
      Method method =
          GeneratorLoadSummaryCalculator.class.getDeclaredMethod(
              "addPhaseSummariesToLoadSummaries", Map.class, LoadSummaryOptions.class);
      method.setAccessible(true);
      method.invoke(generatorLoadSummaryCalculator, loadSummaryMap, loadSummaryOptions);
    } catch (Exception e) {
      e.printStackTrace();
      fail("see stacktrace");
    }
  }

  @Test
  public void shouldCreateMaxImbalanceSummarizedLoadIf3PhaseWhenAggregatingLoads() {
    List<SummarizedLoad> loads =
        loadSummaryMap.values().stream()
            .filter(SummarizedLoad::isMaxImbalance)
            .collect(Collectors.toList());
    assertEquals(4, loads.size());
    for (SummarizedLoad load : loads) {
      if (load.getSummaryType() == SummaryType.COMPONENTS
          && load.getOperatingMode().equals("maxi")) {
        assertMaxLoadImbalance(load, 5d, "ground");
      }
      if (load.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN
          && load.getOperatingMode().equals("maxi")) {
        assertMaxLoadImbalance(load, 7d, "start");
      }
      if (load.getSummaryType() == SummaryType.COMPONENTS
          && load.getOperatingMode().equals("operational")) {
        assertMaxLoadImbalance(load, 52d, "ground");
      }
      if (load.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN
          && load.getOperatingMode().equals("operational")) {
        assertMaxLoadImbalance(load, 30d, "roll");
      }
    }
  }

  @Test
  public void shouldCreateMaxLoadSummarizedLoadsIf3PhaseWhenAggregatingLoads() {
    List<SummarizedLoad> loadsMaxiComponent =
        loadSummaryMap.values().stream()
            .filter(
                loadSummary ->
                    loadSummary.isMaxPhaseLoad()
                        && loadSummary.getOperatingMode().equalsIgnoreCase("maxi")
                        && loadSummary.getSummaryType() == SummaryType.COMPONENTS)
            .collect(Collectors.toList());
    List<SummarizedLoad> loadsMaxiComponentAndChildren =
        loadSummaryMap.values().stream()
            .filter(
                loadSummary ->
                    loadSummary.isMaxPhaseLoad()
                        && loadSummary.getOperatingMode().equalsIgnoreCase("maxi")
                        && loadSummary.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN)
            .collect(Collectors.toList());
    List<SummarizedLoad> loadsOperationalComponent =
        loadSummaryMap.values().stream()
            .filter(
                loadSummary ->
                    loadSummary.isMaxPhaseLoad()
                        && loadSummary.getOperatingMode().equalsIgnoreCase("operational")
                        && loadSummary.getSummaryType() == SummaryType.COMPONENTS)
            .collect(Collectors.toList());
    List<SummarizedLoad> loadsOperationalComponentAndChildren =
        loadSummaryMap.values().stream()
            .filter(
                loadSummary ->
                    loadSummary.isMaxPhaseLoad()
                        && loadSummary.getOperatingMode().equalsIgnoreCase("operational")
                        && loadSummary.getSummaryType() == SummaryType.COMPONENTS_AND_CHILDREN)
            .collect(Collectors.toList());

    Map<ElectricalPhase, Double> maxiComponentMap =
        Stream.of(
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACA, 8d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACB, 6d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACC, 4d))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    assertMaxPhaseLoad(loadsMaxiComponent, "start", maxiComponentMap);

    Map<ElectricalPhase, Double> maxiComponentAndChildrenMap =
        Stream.of(
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACA, 22d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACB, 21d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACC, 23d))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    assertMaxPhaseLoad(loadsMaxiComponentAndChildren, "ground", maxiComponentAndChildrenMap);

    Map<ElectricalPhase, Double> operationalComponentMap =
        Stream.of(
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACA, 200d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACB, 151d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACC, 150d))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    assertMaxPhaseLoad(loadsOperationalComponent, "roll", operationalComponentMap);

    Map<ElectricalPhase, Double> operationalComponentAndChildrenMap =
        Stream.of(
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACA, 40d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACB, 51d),
                new AbstractMap.SimpleEntry<>(ElectricalPhase.ACC, 21d))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    assertMaxPhaseLoad(
        loadsOperationalComponentAndChildren, "ground", operationalComponentAndChildrenMap);
  }

  private void assertMaxPhaseLoad(
      List<SummarizedLoad> loads, String flightPhase, Map<ElectricalPhase, Double> values) {
    assertEquals(3, loads.size());
    for (SummarizedLoad load : loads) {
      assertEquals(flightPhase, load.getFlightPhase());
      assertEquals(Units.KVA, load.getUnits());
      assertEquals(values.get(load.getElectricalPhase()), load.getW(), MAX_ALLOWED_DELTA);
    }
  }

  private void assertMaxLoadImbalance(SummarizedLoad load, Double value, String flightPhase) {
    assertEquals(value, load.getW());
    assertEquals(flightPhase, load.getFlightPhase());
    assertEquals(SummarizedLoad.Units.KVA, load.getUnits());
    assertEquals(null, load.getElectricalPhase());
    assertEquals(Double.valueOf(0.0), load.getVar());
  }

  private void testData() {
    loadSummaryMap.clear();
    List<SummarizedLoad> loadSummaries = new ArrayList<>();
    loadSummaries.add(
        new SummarizedLoad("ground", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 7d, 0d));
    loadSummaries.add(
        new SummarizedLoad("ground", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 4d, 0d));
    loadSummaries.add(
        new SummarizedLoad("ground", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 2d, 0d));
    loadSummaries.add(
        new SummarizedLoad("start", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 8d, 0d));
    loadSummaries.add(
        new SummarizedLoad("start", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 6d, 0d));
    loadSummaries.add(
        new SummarizedLoad("start", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 4d, 0d));
    loadSummaries.add(
        new SummarizedLoad("roll", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 5d, 0d));
    loadSummaries.add(
        new SummarizedLoad("roll", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 4d, 0d));
    loadSummaries.add(
        new SummarizedLoad("roll", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 1d, 0d));

    loadSummaries.add(
        new SummarizedLoad(
            "ground", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 22d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 21d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 23d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 8d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 6d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 1d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "maxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 5d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "maxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 4d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "maxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 1d, 0d));

    loadSummaries.add(
        new SummarizedLoad(
            "ground", "operational", ElectricalPhase.ACA, SummaryType.COMPONENTS, 72d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground", "operational", ElectricalPhase.ACB, SummaryType.COMPONENTS, 45d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground", "operational", ElectricalPhase.ACC, SummaryType.COMPONENTS, 20d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "operational", ElectricalPhase.ACA, SummaryType.COMPONENTS, 100d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "operational", ElectricalPhase.ACB, SummaryType.COMPONENTS, 101d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start", "operational", ElectricalPhase.ACC, SummaryType.COMPONENTS, 104d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "operational", ElectricalPhase.ACA, SummaryType.COMPONENTS, 200d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "operational", ElectricalPhase.ACB, SummaryType.COMPONENTS, 151d, 0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll", "operational", ElectricalPhase.ACC, SummaryType.COMPONENTS, 150d, 0d));

    loadSummaries.add(
        new SummarizedLoad(
            "ground",
            "operational",
            ElectricalPhase.ACA,
            SummaryType.COMPONENTS_AND_CHILDREN,
            40d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground",
            "operational",
            ElectricalPhase.ACB,
            SummaryType.COMPONENTS_AND_CHILDREN,
            51d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "ground",
            "operational",
            ElectricalPhase.ACC,
            SummaryType.COMPONENTS_AND_CHILDREN,
            21d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start",
            "operational",
            ElectricalPhase.ACA,
            SummaryType.COMPONENTS_AND_CHILDREN,
            48d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start",
            "operational",
            ElectricalPhase.ACB,
            SummaryType.COMPONENTS_AND_CHILDREN,
            25d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "start",
            "operational",
            ElectricalPhase.ACC,
            SummaryType.COMPONENTS_AND_CHILDREN,
            19d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll",
            "operational",
            ElectricalPhase.ACA,
            SummaryType.COMPONENTS_AND_CHILDREN,
            50d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll",
            "operational",
            ElectricalPhase.ACB,
            SummaryType.COMPONENTS_AND_CHILDREN,
            44d,
            0d));
    loadSummaries.add(
        new SummarizedLoad(
            "roll",
            "operational",
            ElectricalPhase.ACC,
            SummaryType.COMPONENTS_AND_CHILDREN,
            20d,
            0d));

    loadSummaries.forEach(
        summarizedLoad ->
            loadSummaryMap.put(LoadSummaryBucketKey.from(summarizedLoad), summarizedLoad));
  }
}
