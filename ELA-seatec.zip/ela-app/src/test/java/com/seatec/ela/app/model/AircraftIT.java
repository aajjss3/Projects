package com.seatec.ela.app.model;

import static org.junit.Assert.*;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import javax.transaction.Transactional;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@Transactional
public class AircraftIT extends AbstractControllerIntegrationTest {

  @Autowired
  private @Qualifier("testEntityManager") TestEntityManager entityManager;

  @Rule public ExpectedException thrown = ExpectedException.none();

  @Test
  public void simpleBusWrite() {
    Fleet fleet = new Fleet();
    Aircraft aircraft =
        new Aircraft(
            "3323",
            "1234",
            "1234",
            "1234",
            "1234",
            "33-525112-20_ELA_AppendixA_3325.xlsx",
            "b5e211742619e8217833cc07e57069a8",
            fleet);
    Object result = entityManager.persistAndGetId(aircraft);
    Aircraft found = entityManager.find(Aircraft.class, aircraft.getId());
    assertEquals(found.getId(), result);
    entityManager.remove(found);
  }

  @Test
  public void failedEmptyBusWrite() {
    Aircraft aircraft = new Aircraft();
    thrown.expectMessage("ConstraintViolationException");
    entityManager.persistAndGetId(aircraft);
  }
}
