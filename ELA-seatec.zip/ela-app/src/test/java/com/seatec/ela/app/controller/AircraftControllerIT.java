package com.seatec.ela.app.controller;

import static junit.framework.TestCase.assertTrue;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.*;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.AircraftDtoConverter;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class AircraftControllerIT extends AbstractControllerIntegrationTest {
  @Autowired public AircraftRepository aircraftRepo;

  @Autowired public FleetRepository fleetRepo;

  @Autowired public ElaRepository elaRepo;

  @Autowired public ProjectRepo projectRepo;

  @Autowired public AircraftChangeGroupRepo aircraftChangeGroupRepo;

  private String ENDPOINT_URL = BASE_URL + "/service/aircrafts/";

  @Test
  public void shouldGetListWithCloakForItAdmin() {
    aircraftRepo.save(createAircraft(100));
    Aircraft aircraft = createAircraft(100);
    aircraft.setCloaked(true);
    aircraftRepo.save(aircraft);
    aircraftRepo.save(createAircraft(104));
    ResponseEntity<String> response =
        restTemplate.exchange(ENDPOINT_URL, HttpMethod.GET, createHttpEntity(null), String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(
        "should contain cloaked aircraft",
        response.getBody(),
        containsString("\"aircraftShipNo\":\"100\""));
    assertThat(
        "should contain uncloaked aircraft",
        response.getBody(),
        containsString("\"aircraftShipNo\":\"104\""));
  }

  @Test
  public void shouldGetListWithoutCloakedForNonItAdmin() {
    Aircraft aircraft = createAircraft(100);
    aircraft.setCloaked(true);
    aircraftRepo.save(aircraft);
    aircraftRepo.save(createAircraft(104));
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              ENDPOINT_URL, HttpMethod.GET, createHttpEntity(null, user), String.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertThat(
          "should not contain cloaked aircraft for user " + user,
          response.getBody(),
          not(containsString("\"aircraftShipNo\":\"100\"")));
      assertThat(
          "should contain non-cloaked aircraft for user " + user,
          response.getBody(),
          containsString("\"aircraftShipNo\":\"104\""));
    }
  }

  @Test
  public void shouldCreateAircraftWhenCallingCreateAircraft() throws Exception {
    List excludedMatchFields = Arrays.asList(new String[] {"id", "archived"});
    Fleet fleet = fleetRepo.save(createFleet(201));
    AircraftDto aircraftDto = createAircraftDto(1);
    aircraftDto.setFleetId(fleet.getId());
    ResponseEntity<AircraftDto> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(aircraftDto), AircraftDto.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), aircraftDto, excludedMatchFields);
  }

  @Test
  public void shouldGetAircraftWhenCallingGetAircraftById() throws Exception {
    Aircraft aircraft = aircraftRepo.save(createAircraft(2));
    AircraftDto aircraftDto = AircraftDtoConverter.convertToDto(aircraft);
    ResponseEntity<AircraftDto> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId(),
            HttpMethod.GET,
            createHttpEntity(null),
            AircraftDto.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), aircraftDto);
  }

  @Test
  public void shouldGetEmptyWhenCallingGetAircraftByNoMatchingId() {
    ResponseEntity<Aircraft> response =
        restTemplate.exchange(
            ENDPOINT_URL + 0, HttpMethod.GET, createHttpEntity(null), Aircraft.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void shouldNotCreateAircraftWhenCallingCreateAircrafttMissingRequiredFField() {
    Aircraft aircraft = createAircraft(3);
    aircraft.setVariableNumber(null);
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(aircraft), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Missing required field."));
  }

  @Test
  public void shouldNotCreateAircraftWhenCallingCreateAircraftWithNoMatchingFleetId() {
    Fleet fleet = fleetRepo.save(createFleet(205));
    Aircraft aircraft = createAircraft(4);
    AircraftDto aircraftDto = AircraftDtoConverter.convertToDto(aircraft);
    aircraftDto.setFleetId(0L);
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(aircraftDto), String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("Fleet Resource id 0 not found"));
  }

  @Test
  public void shouldNotCreateAircraftWhenCallingCreateAircraftWithExistingShipNo() {
    Fleet fleet = fleetRepo.save(createFleet(206));
    Aircraft aircraft = aircraftRepo.save(createAircraft(5));
    AircraftDto aircraftDto = AircraftDtoConverter.convertToDto(aircraft);
    aircraftDto.setFleetId(fleet.getId());
    ResponseEntity<String> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(aircraftDto), String.class);
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString("Constraint Violation: Check for Unique aircraftShipNo"));
  }

  @Test
  public void shouldNotChangeAircraftShipNoWhenModifyingAircraftToExistingShipNo() {
    Fleet fleet = fleetRepo.save(createFleet(207));
    Aircraft existingAircraft =
        new Aircraft(
            "1117",
            "1234",
            "registrationNumber",
            "linenumber",
            "variableNumber",
            null,
            null,
            fleet);
    aircraftRepo.save(existingAircraft);
    Aircraft aircraft = aircraftRepo.save(createAircraft(12));
    AircraftDto aircraftDto = AircraftDtoConverter.convertToDto(aircraft);
    aircraftDto.setAircraftShipNo(existingAircraft.getAircraftShipNo());
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraftDto.getId(),
            HttpMethod.PUT,
            createHttpEntity(aircraftDto),
            String.class);

    assertEquals(
        "Update response should return successful", HttpStatus.OK, response.getStatusCode());
    Optional<Aircraft> updatedAircraft = aircraftRepo.findById(aircraft.getId());
    assertTrue("aircraft entity should be present", updatedAircraft.isPresent());

    Aircraft finalAircraft = updatedAircraft.get();
    assertTrue(
        "shipNo should not update",
        !aircraftDto.getAircraftShipNo().equals(finalAircraft.getAircraftShipNo()));
  }

  @Test
  public void shouldUpdateArchivedWhenCallingUpdate() {
    Aircraft sourceAircraft = createAircraft(6);
    sourceAircraft.setOrigWorkbookFilename("filename");
    Aircraft aircraft = aircraftRepo.save(sourceAircraft);
    Ela ela = createEla("test name 2");
    ela.setAircraft(aircraft);
    elaRepo.save(ela);

    Project approvedProject = createAndSaveProject("approved", "b1", true, true);
    ChangeGroup approvedProjectChangeGroup = createAndSaveChangeGroup("cgName", approvedProject);
    AircraftChangeGroup approvedProjectAcg =
        createAndSaveAircraftChangeGroup(aircraft, approvedProjectChangeGroup);
    Project unApprovedProject = createAndSaveProject("unapproved", "b2", true, false);
    ChangeGroup unApprovedProjectChangeGroup =
        createAndSaveChangeGroup("cgName", unApprovedProject);
    AircraftChangeGroup unApprovedProjectAcg =
        createAndSaveAircraftChangeGroup(aircraft, unApprovedProjectChangeGroup);

    assertTrue(projectRepo.findById(approvedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(approvedProjectAcg.getId()).isPresent());
    assertTrue(projectRepo.findById(unApprovedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(unApprovedProjectAcg.getId()).isPresent());

    AircraftDto aircraftDto = AircraftDtoConverter.convertToDto(aircraft);
    aircraftDto.setArchived(true);
    aircraftDto.setSerialNumber("12345");

    ResponseEntity<AircraftDto> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraftDto.getId(),
            HttpMethod.PUT,
            createHttpEntity(aircraftDto),
            AircraftDto.class);

    assertEquals(HttpStatus.OK, response.getStatusCode());
    Optional<Aircraft> updatedAircraft = aircraftRepo.findById(aircraft.getId());
    assertTrue(updatedAircraft.isPresent());

    Aircraft finalAircraft = updatedAircraft.get();
    assertTrue(
        "Archived field should update", aircraftDto.isArchived() == finalAircraft.isArchived());
    assertEquals(aircraft.getOrigWorkbookFilename(), finalAircraft.getOrigWorkbookFilename());

    assertTrue(projectRepo.findById(approvedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(approvedProjectAcg.getId()).isPresent());
    assertTrue(projectRepo.findById(unApprovedProject.getId()).isPresent());
    assertFalse(aircraftChangeGroupRepo.findById(unApprovedProjectAcg.getId()).isPresent());
  }

  @Test
  public void shouldThrow5xxWhenCallingUpdateWithNullId() {
    fleetRepo.save(createFleet(203));
    AircraftDto aircraftDto = createAircraftDto(7);
    aircraftDto.setArchived(true);
    aircraftDto.setId(null);

    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraftDto.getId(),
            HttpMethod.PUT,
            createHttpEntity(aircraftDto),
            String.class);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
  }

  @Test
  public void shouldNotUpdateArchiveWhenCallingUpdateWithBadId() {
    fleetRepo.save(createFleet(204));
    AircraftDto aircraftDto = createAircraftDto(8);
    aircraftDto.setId(0L);
    aircraftDto.setArchived(true);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraftDto.getId(),
            HttpMethod.PUT,
            createHttpEntity(aircraftDto),
            String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("aircraft id does not exist"));
  }

  @Test
  public void shouldUpdateAircraftWhenVariableNumberIsNull() throws Exception {
    Aircraft aircraft = aircraftRepo.save(createAircraft(9));
    aircraft.setVariableNumber(null);
    ResponseEntity<Aircraft> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId(),
            HttpMethod.PUT,
            createHttpEntity(aircraft),
            Aircraft.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertObjectFields(response.getBody(), aircraft);
  }

  @Test
  public void shouldDeleteWhenCallingDeleteWithNoElaPresent() {
    Aircraft aircraft = aircraftRepo.save(createAircraft(10));
    ResponseEntity<Aircraft> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId(),
            HttpMethod.DELETE,
            createHttpEntity(null),
            Aircraft.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNull(response.getBody());
  }

  @Test
  public void shouldNotDeleteWhenCallingDeleteAndNotFound() {
    AircraftDto aircraftDto = createAircraftDto(11);
    aircraftDto.setId(0L);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraftDto.getId(),
            HttpMethod.DELETE,
            createHttpEntity(aircraftDto),
            String.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertThat(response.getBody(), containsString("aircraft id does not exist"));
  }

  @Test
  public void shouldNotDeleteWhenCallingDeleteWithElaPresent() {
    // arrange
    Fleet fleet = fleetRepo.save(createFleet(16));
    fleetRepo.save(fleet);
    Aircraft aircraft =
        new Aircraft(
            "1116",
            "1234",
            "registrationNumber",
            "linenumber",
            "variableNumber",
            null,
            null,
            fleet);
    aircraft = aircraftRepo.save(aircraft);
    Ela ela = createEla("test name 1");
    ela.setAircraft(aircraft);
    elaRepo.save(ela);

    // act
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId(),
            HttpMethod.DELETE,
            createHttpEntity(null),
            String.class);

    // assert
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString(
            "Aircraft '"
                + aircraft.getAircraftShipNo()
                + "' has an associated ELA. Cannot delete."));
  }

  @Test
  public void when_delete_and_aircraftIsCloaked_then_throw_ConflictException() {
    // arrange
    Fleet fleet = fleetRepo.save(createFleet(16));
    fleetRepo.save(fleet);
    Aircraft aircraft =
        new Aircraft(
            "1116",
            "1234",
            "registrationNumber",
            "linenumber",
            "variableNumber",
            null,
            null,
            fleet);

    // if cloaked = true, code should throw exception
    aircraft.setCloaked(true);
    aircraft = aircraftRepo.save(aircraft);

    // act
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId(),
            HttpMethod.DELETE,
            createHttpEntity(null),
            String.class);

    // assert
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
    assertThat(
        response.getBody(),
        containsString(
            "Aircraft '" + aircraft.getAircraftShipNo() + "' is cloaked. Cannot delete."));
  }

  @Test
  public void shouldGetEmptyCloakList() {
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/cloak", HttpMethod.GET, createHttpEntity(null), String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals("[]", response.getBody());
  }

  @Test
  public void shouldGetCloakList() {
    Aircraft aircraft = createAircraft(101);
    aircraft.setCloaked(true);
    aircraftRepo.save(aircraft);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/cloak", HttpMethod.GET, createHttpEntity(null), String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("\"aircraftShipNo\":\"101\""));
  }

  @Test
  public void shouldGetSearchedCloakList() {
    Aircraft aircraft1 = createAircraft(102);
    aircraft1.setCloaked(true);
    aircraftRepo.save(aircraft1);
    Aircraft aircraft2 = createAircraft(103);
    aircraft2.setCloaked(true);
    aircraftRepo.save(aircraft2);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/cloak?aircraftShipNo=" + aircraft1.getAircraftShipNo(),
            HttpMethod.GET,
            createHttpEntity(null),
            String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("\"aircraftShipNo\":\"102\""));
    assertThat(response.getBody(), not(containsString("\"aircraftShipNo\":\"103\"")));
  }

  @Test
  public void shouldCloakAndUncloakedByITAdmin() throws Exception {
    HttpEntity<String> entity = createHttpEntity(null);
    Aircraft aircraft = createAircraft(102);
    aircraftRepo.save(aircraft);

    Project approvedProject = createAndSaveProject("approved", "b1", true, true);
    ChangeGroup approvedProjectChangeGroup = createAndSaveChangeGroup("cgName", approvedProject);
    AircraftChangeGroup approvedProjectAcg =
        createAndSaveAircraftChangeGroup(aircraft, approvedProjectChangeGroup);
    Project unApprovedProject = createAndSaveProject("unapproved", "b2", true, false);
    ChangeGroup unApprovedProjectChangeGroup =
        createAndSaveChangeGroup("cgName", unApprovedProject);
    AircraftChangeGroup unApprovedProjectAcg =
        createAndSaveAircraftChangeGroup(aircraft, unApprovedProjectChangeGroup);

    assertTrue(projectRepo.findById(approvedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(approvedProjectAcg.getId()).isPresent());
    assertTrue(projectRepo.findById(unApprovedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(unApprovedProjectAcg.getId()).isPresent());
    assertFalse("pretest condition aircraft should not be cloaked", aircraft.isCloaked());

    ResponseEntity<Void> cloakResponse =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId() + "/cloak", HttpMethod.PATCH, entity, Void.class);
    assertEquals(HttpStatus.OK, cloakResponse.getStatusCode());
    assertTrue(
        "aircraft should now be cloaked",
        aircraftRepo.findById(aircraft.getId()).get().isCloaked());
    assertTrue(projectRepo.findById(approvedProject.getId()).isPresent());
    assertTrue(aircraftChangeGroupRepo.findById(approvedProjectAcg.getId()).isPresent());
    assertTrue(projectRepo.findById(unApprovedProject.getId()).isPresent());
    assertFalse(aircraftChangeGroupRepo.findById(unApprovedProjectAcg.getId()).isPresent());

    ResponseEntity<Void> uncloakResponse =
        restTemplate.exchange(
            ENDPOINT_URL + aircraft.getId() + "/uncloak", HttpMethod.PATCH, entity, Void.class);
    assertEquals(HttpStatus.OK, uncloakResponse.getStatusCode());
    assertFalse(
        "aircraft should no longer be cloaked",
        aircraftRepo.findById(aircraft.getId()).get().isCloaked());
  }
}
