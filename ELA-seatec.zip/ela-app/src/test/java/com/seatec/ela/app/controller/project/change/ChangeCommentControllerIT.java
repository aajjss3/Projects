package com.seatec.ela.app.controller.project.change;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.dto.project.change.ChangeCommentDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3324.sql",
        "/datasets/node-3324.sql",
        "/datasets/component-3324.sql",
        "/datasets/load-3324.sql"
      }),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ChangeCommentControllerIT extends AbstractControllerIntegrationTest {
  private String ENDPOINT_PROJECT_URL = BASE_URL + "/service/projects/";

  private String ENDPOINT_CHANGEGROUP_URL = "/changegroups/";

  private String ENDPOINT_CHANGE_URL = "/change/";

  private String ENDPOINT_CHANGECOMMENT_URL = "/comment";

  @Autowired private AircraftRepository aircraftRepo;

  @Test
  public void when_create_then_save() {
    // arrange
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    // LoadChange
    List<LoadChange> loadChanges = new ArrayList<>();

    // ComponentChange
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, true, "ElectIdent1", 0d);
    componentChange.setNominalPower(500.0);

    // save Aircraft ChangeGroup
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // save Change
    Change change =
        createAndSaveChange(
            "1IWXP",
            "compElectIdent",
            ActionType.ADD,
            DEFAULT_USER_ID,
            null,
            componentChange,
            changeGroup);

    // create Change Comment
    ChangeCommentDTO changeCommentDTO = new ChangeCommentDTO();
    changeCommentDTO.setComment("I dont agree");

    // act
    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_PROJECT_URL
                + project.getId()
                + ENDPOINT_CHANGEGROUP_URL
                + changeGroup.getId()
                + ENDPOINT_CHANGE_URL
                + change.getId()
                + ENDPOINT_CHANGECOMMENT_URL,
            createHttpEntity(changeCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  public void when_create_and_missingRequiredCommentValue_then_throw_validation_exception() {
    // arrange
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    // LoadChange
    List<LoadChange> loadChanges = new ArrayList<>();

    // ComponentChange
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, true, "ElectIdent1", 0d);
    componentChange.setNominalPower(500.0);

    // save Aircraft ChangeGroup
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // save Change
    Change change =
        createAndSaveChange(
            "1IWXP",
            "compElectIdent",
            ActionType.ADD,
            DEFAULT_USER_ID,
            null,
            componentChange,
            changeGroup);

    // create Change Comment
    ChangeCommentDTO changeCommentDTO = new ChangeCommentDTO();
    // Do NOT set comment value (should throw validation error)
    // changeCommentDTO.setComment("I dont agree");

    // act
    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_PROJECT_URL
                + project.getId()
                + ENDPOINT_CHANGEGROUP_URL
                + changeGroup.getId()
                + ENDPOINT_CHANGE_URL
                + change.getId()
                + ENDPOINT_CHANGECOMMENT_URL,
            createHttpEntity(changeCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertNotNull(response.getBody());
    assertEquals(1, response.getBody().getErrors().size());
    assertTrue(response.getBody().getErrors().get(0).getField().equalsIgnoreCase("comment"));
    assertTrue(
        response
            .getBody()
            .getErrors()
            .get(0)
            .getMessage()
            .equalsIgnoreCase("missing required field."));
  }
}
