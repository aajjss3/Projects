package com.seatec.ela.app.validator.constraint;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.service.FleetService;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.validator.annotation.BatteryChargeTypeRequiredIfBoeing;
import java.lang.annotation.Annotation;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

public class BatteryChargeTypeRequiredIfBoeingValidatorTest {

  private BatteryChargeTypeRequiredIfBoeingValidator subject;

  @Mock FleetService mockFleetService;

  @Before
  public void setup() {
    mockFleetService = mock(FleetService.class);
    subject = new BatteryChargeTypeRequiredIfBoeingValidator(mockFleetService);
    subject.initialize(getBatteryChargeTypeRequiredIfBoeing());
  }

  @Test
  public void isValid_should_return_true_when_AirbusManufacturerAndValidBatteryChargeType() {
    // arrange
    Long id = 1L;

    Fleet fleet = new Fleet();
    fleet.setManufacturer("airbus");
    fleet.setId(id);

    AircraftDto aircraftDto = new AircraftDto();
    aircraftDto.setBatteryCharge(BatteryChargeType.DUAL_48AH);
    aircraftDto.setFleetId(id);

    when(mockFleetService.findById(any(Long.class))).thenReturn(Optional.of(fleet));

    // act
    boolean result = subject.isValid(aircraftDto, null);

    // assert
    assertTrue(result);
  }

  @Test
  public void isValid_should_return_true_when_AirbusManufacturerAndNullBatteryChargeType() {
    // arrange
    Long id = 1L;

    Fleet fleet = new Fleet();
    fleet.setManufacturer("airbus");
    fleet.setId(id);

    AircraftDto aircraftDto = new AircraftDto();
    aircraftDto.setBatteryCharge(null);
    aircraftDto.setFleetId(id);

    when(mockFleetService.findById(any(Long.class))).thenReturn(Optional.of(fleet));

    // act
    boolean result = subject.isValid(aircraftDto, null);

    // assert
    assertTrue(result);
  }

  @Test
  public void isValid_should_return_true_when_BoeingManufacturerAndValidBatteryChargeType() {
    // arrange
    Long id = 1L;

    Fleet fleet = new Fleet();
    fleet.setManufacturer("boeing");
    fleet.setId(id);

    AircraftDto aircraftDto = new AircraftDto();
    aircraftDto.setBatteryCharge(BatteryChargeType.DUAL_48AH);
    aircraftDto.setFleetId(id);

    when(mockFleetService.findById(any(Long.class))).thenReturn(Optional.of(fleet));

    // act
    boolean result = subject.isValid(aircraftDto, null);

    // assert
    assertTrue(result);
  }

  @Test
  public void isValid_should_return_false_when_BoeingManufacturerAndNullBatteryChargeType() {
    // arrange
    Long id = 1L;

    Fleet fleet = new Fleet();
    fleet.setManufacturer("boeing");
    fleet.setId(id);

    AircraftDto aircraftDto = new AircraftDto();
    aircraftDto.setBatteryCharge(null);
    aircraftDto.setFleetId(id);

    when(mockFleetService.findById(any(Long.class))).thenReturn(Optional.of(fleet));

    // act
    boolean result = subject.isValid(aircraftDto, null);

    // assert
    assertFalse(result);
  }

  private BatteryChargeTypeRequiredIfBoeing getBatteryChargeTypeRequiredIfBoeing() {
    return new BatteryChargeTypeRequiredIfBoeing() {

      @Override
      public Class<? extends Annotation> annotationType() {
        return null;
      }

      @Override
      public String message() {
        return null;
      }

      @Override
      public Class<?>[] groups() {
        return new Class[0];
      }

      @Override
      public Class[] payload() {
        return new Class[0];
      }
    };
  }
}
