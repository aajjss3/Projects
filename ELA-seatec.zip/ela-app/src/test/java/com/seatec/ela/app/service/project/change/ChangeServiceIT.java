package com.seatec.ela.app.service.project.change;

import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.change.ChangeRepo;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ChangeServiceIT extends AbstractControllerIntegrationTest {

  @Autowired private ChangeService subject;

  @Autowired private IChangeGroupService changeGroupService;

  @Autowired private IProjectService projectService;

  @Autowired private ChangeRepo changeRepo;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  private Ela ela;
  private List<Long> elaIds = new ArrayList<>();

  private Fleet fleetAirbus;

  private Project project;

  private Node nodeGeneratorA;
  private Node nodeGeneratorB;

  ChangeGroup changeGroup1;

  @Before
  public void setup() {
    initalizeDatabase();
  }

  @Rule public ExpectedException exceptionRule = ExpectedException.none();

  @Test
  public void
      when_create_with_single_aircraft_in_changeGroup_then_skip_split_changeGroup_section() {
    // arrange
    String electIdent = "1HQ";
    String changeGroupName = "Airbus ABC";

    // change group
    ChangeGroup newChangeGroup = createAndSaveChangeGroup(changeGroupName, project);
    project.addChangeGroup(newChangeGroup);

    // aircraft(s)
    Aircraft aircraft1 = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    // ela(s)
    Ela ela1 = createAndSaveEla("Split Ela 1", aircraft1);

    // ela1 node(s)
    Node ela1NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela1);
    Node ela1NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela1NodeGenerator,
            null);
    ela1NodeGenerator.addSubNode(ela1NodeBus);

    // component(s)
    createAndSaveComponentWithLoads(ela1NodeBus, electIdent, ElectricalPhase.AC, 20d, 1, false);

    // aircraft change group(s)
    createAndSaveAircraftChangeGroup(aircraft1, newChangeGroup);

    // component change
    List<LoadChange> loadChanges = new ArrayList<>();
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, electIdent, 0d);

    // change
    Change change = createChange();
    change.setNodeName("1XP");
    change.setComponentElectIdent(electIdent);
    change.setComponentChange(componentChange);
    change.setAction(ActionType.ADD);
    change.setChanger(DEFAULT_USER_ID);

    // assert (before act)
    Assert.assertEquals(
        "Project Change Group count should be 3",
        3,
        changeGroupRepo.findAllByProjectId(project.getId()).size());

    // act
    Change result = subject.create(change, newChangeGroup.getId(), project.getId());

    // assert (after act)
    Assert.assertNotNull(result);

    List<ChangeGroup> changeGroupsAfterAct = changeGroupRepo.findAllByProjectId(project.getId());
    Assert.assertEquals(
        "Project Change Group count should remain 3", 3, changeGroupsAfterAct.size());
  }

  @Test
  public void
      when_create_with_incompatible_component_on_1_of_2_aircrafts_then_split_changeGroups() {
    // arrange
    String electIdent = "1HQ";
    String changeGroupName = "Airbus ABC";

    // change group
    ChangeGroup newChangeGroup = createAndSaveChangeGroup(changeGroupName, project);
    project.addChangeGroup(newChangeGroup);

    // aircraft(s)
    Aircraft aircraft1 = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);
    Aircraft aircraft2 = createAndSaveAircraft("3351", "0609", "N851NW", "N/A", "N/A", fleetAirbus);

    // ela(s)
    Ela ela1 = createAndSaveEla("Split Ela 1", aircraft1);
    Ela ela2 = createAndSaveEla("Split Ela 2", aircraft2);

    // ela1 node(s)
    Node ela1NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela1);
    Node ela1NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela1NodeGenerator,
            null);
    ela1NodeGenerator.addSubNode(ela1NodeBus);

    // ela2 node(s)
    Node ela2NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela2);
    Node ela2NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela2NodeGenerator,
            null);
    Node ela2NodeBusChild =
        createAndSaveNode(
            true,
            "105XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela2NodeBus,
            null);
    ela2NodeBus.addSubNode(ela2NodeBusChild);
    ela2NodeGenerator.addSubNode(ela2NodeBus);

    // component(s)
    createAndSaveComponentWithLoads(ela1NodeBus, electIdent, ElectricalPhase.AC, 20d, 1, false);
    createAndSaveComponentWithLoads(
        ela2NodeBusChild, electIdent, ElectricalPhase.AC, 20d, 1, false);

    // aircraft change group(s)
    createAndSaveAircraftChangeGroup(aircraft1, newChangeGroup);
    createAndSaveAircraftChangeGroup(aircraft2, newChangeGroup);

    // component change
    List<LoadChange> loadChanges = new ArrayList<>();
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, electIdent, 0d);

    // change
    Change change = createChange();
    change.setNodeName("105XP");
    change.setComponentElectIdent(electIdent);
    change.setComponentChange(componentChange);
    change.setAction(ActionType.EDIT);
    change.setChanger(DEFAULT_USER_ID);

    // assert (before act)
    Assert.assertEquals(
        "Project Change Group count should be 3",
        3,
        changeGroupRepo.findAllByProjectId(project.getId()).size());

    // act
    Change result = subject.create(change, newChangeGroup.getId(), project.getId());

    // assert (after act)
    Assert.assertNotNull(result);

    List<ChangeGroup> changeGroupsAfterAct = changeGroupRepo.findAllByProjectId(project.getId());
    Assert.assertEquals("Project Change Group count should be 4", 4, changeGroupsAfterAct.size());
  }

  @Test
  public void
      when_create_with_incompatible_component_on_2_of_3_aircrafts_then_split_changeGroups() {
    // arrange
    String electIdent = "1HQ";
    String changeGroupName = "Airbus ABC";

    // change group
    ChangeGroup newChangeGroup = createAndSaveChangeGroup(changeGroupName, project);
    project.addChangeGroup(newChangeGroup);

    // aircraft(s)
    Aircraft aircraft1 = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);
    Aircraft aircraft2 = createAndSaveAircraft("3351", "0609", "N851NW", "N/A", "N/A", fleetAirbus);
    Aircraft aircraft3 = createAndSaveAircraft("3500", "0609", "N851NW", "N/A", "N/A", fleetAirbus);

    // ela(s)
    Ela ela1 = createAndSaveEla("Split Ela 1", aircraft1);
    Ela ela2 = createAndSaveEla("Split Ela 2", aircraft2);
    Ela ela3 = createAndSaveEla("Split Ela 3", aircraft3);

    // ela1 node(s)
    Node ela1NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela1);
    Node ela1NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela1NodeGenerator,
            null);
    ela1NodeGenerator.addSubNode(ela1NodeBus);

    // ela2 node(s)
    Node ela2NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela2);
    Node ela2NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela2NodeGenerator,
            null);
    Node ela2NodeBusChild =
        createAndSaveNode(
            true,
            "105XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela2NodeBus,
            null);
    ela2NodeBus.addSubNode(ela2NodeBusChild);
    ela2NodeGenerator.addSubNode(ela2NodeBus);

    // ela3 node(s)
    Node ela3NodeGenerator =
        createAndSaveNode(
            true,
            "GEN 1",
            115d,
            100d,
            NodeType.GENERATOR,
            120d,
            ElectricalPhase.AC3,
            1,
            null,
            ela3);
    Node ela3NodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            ela3NodeGenerator,
            null);
    ela3NodeGenerator.addSubNode(ela3NodeBus);

    // component(s)
    createAndSaveComponentWithLoads(ela1NodeBus, electIdent, ElectricalPhase.AC, 20d, 1, false);
    createAndSaveComponentWithLoads(
        ela2NodeBusChild, electIdent, ElectricalPhase.AC, 20d, 1, false);
    createAndSaveComponentWithLoads(ela3NodeBus, electIdent, ElectricalPhase.AC, 20d, 1, false);

    // aircraft change group(s)
    createAndSaveAircraftChangeGroup(aircraft1, newChangeGroup);
    createAndSaveAircraftChangeGroup(aircraft2, newChangeGroup);
    createAndSaveAircraftChangeGroup(aircraft3, newChangeGroup);

    // component change
    List<LoadChange> loadChanges = new ArrayList<>();
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, electIdent, 0d);

    // change
    Change change = createChange();
    change.setNodeName("105XP");
    change.setComponentElectIdent(electIdent);
    change.setComponentChange(componentChange);
    change.setAction(ActionType.EDIT);
    change.setChanger(DEFAULT_USER_ID);

    // assert (before act)
    Assert.assertEquals(
        "Project Change Group count should be 3",
        3,
        changeGroupRepo.findAllByProjectId(project.getId()).size());

    // act
    Change result = subject.create(change, newChangeGroup.getId(), project.getId());

    // assert (after act)
    Assert.assertNotNull(result);

    List<ChangeGroup> changeGroupsAfterAct = changeGroupRepo.findAllByProjectId(project.getId());
    Assert.assertEquals("Project Change Group count should be 4", 4, changeGroupsAfterAct.size());
  }

  @Test
  public void
      when_createChange_with_nodeChange_action_edit_and_nodeNotPresent_then_throw_NotFoundException() {
    // arrange
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // node change (invalid name value, should not find matching node)
    NodeChange nodeChange =
        createNodeChange(
            null,
            "DUMMY",
            115d,
            ElectricalPhase.AC3,
            NodeType.BUS,
            30d,
            true,
            false,
            false,
            ElectricalPhase.AC3);

    Change newChange = createChange();
    newChange.setNodeName("GEN 1");
    newChange.setNodeChange(nodeChange);
    newChange.setAction(ActionType.EDIT);
    newChange.setChanger(DEFAULT_USER_ID);

    // expected exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Node Name (DUMMY) does not exist in this Change Group.");

    // act
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_change_with_componentchange_for_action_add_and_existing_node_that_already_has_component_with_same_electIdent_and_phase_then_throw_exception() {

    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create a new component change for the node '1XP' with an phase of 'AC3' and an electric ident
    // of '1HQ' (same elect ident and phase as existing component for that node)
    ComponentChange newComponentChange =
        createComponentChange(new ArrayList<>(), ElectricalPhase.AC3, false, "1HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("1HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    // calling this endpoint with these values should throw a conflict exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage(
        "The node: 1XP, already has an existing component or component change with a similar electrical ident: 1HQ, and phase: AC3");
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_change_with_componentchange_for_action_add_and_existing_node_that_already_has_componentchange_with_same_electIdent_and_phase_then_throw_exception() {

    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create and persist a componentchange for the node '1XP' and set its phase to 'AC3' and its
    // elect ident as '2HQ' and persist
    createAndSaveComponentChange(changeGroup, "2HQ", "1XP");

    // create a new component change for the node '1XP' with an phase of 'AC3' and an electric ident
    // of '2HQ' (same elect ident and phase as componentchange created above)
    ComponentChange newComponentChange =
        createComponentChange(new ArrayList<>(), ElectricalPhase.AC3, false, "2HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("2HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    // calling this endpoint with these values should throw a conflict exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage(
        "The node: 1XP, already has an existing component or component change with a similar electrical ident: 2HQ, and phase: AC3");

    // act
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_change_with_componentchange_for_action_add_and_node_that_has_component_with_different_electIdent_then_persist() {

    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create a new component change for the node '1XP' with an phase of 'AC3' and an electric ident
    // of '2HQ' (different elect ident than existing component for that node)
    ComponentChange newComponentChange =
        createComponentChange(new ArrayList<>(), ElectricalPhase.AC3, false, "2HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("2HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    Change result = subject.create(newChange, changeGroup.getId(), project.getId());
    Assert.assertNotNull(result);
  }

  @Test
  public void
      when_create_change_with_componentchange_for_action_edit_and_existing_node_that_already_has_component_with_same_electIdent_and_phase_then_persist() {

    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create a new component change for the node '1XP' with an phase of 'AC3' and an electric ident
    // of '1HQ' (same elect ident and phase as existing component for that node)
    ComponentChange newComponentChange =
        createComponentChange(new ArrayList<>(), ElectricalPhase.AC3, false, "1HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("1HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.EDIT);
    newChange.setChanger(DEFAULT_USER_ID);

    // act
    Change result = subject.create(newChange, changeGroup.getId(), project.getId());

    // assert
    Assert.assertNotNull(result);
  }

  @Test
  public void
      when_createChange_with_componentChange_for_action_edit_and_loadChangesNull_then_persist() {
    // arrange
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create a new component change for the node '1XP' with an phase of 'AC3' and an electric ident
    // of '1HQ' (same elect ident and phase as existing component for that node)
    ComponentChange newComponentChange =
        createComponentChange(null, ElectricalPhase.AC3, true, "1HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("1HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.EDIT);
    newChange.setChanger(DEFAULT_USER_ID);

    // act
    Change result = subject.create(newChange, changeGroup.getId(), project.getId());

    // assert
    Assert.assertNotNull(result);
  }

  @Test
  public void
      when_createChange_with_componentChange_for_action_edit_and_NonIntermittent_withLoadChangesNull_then_throw_BadRequestException() {
    // arrange
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // component change details:
    // loadChanges => null
    // intermittent => false
    // the above combination is not allowed, should throw exception
    ComponentChange newComponentChange =
        createComponentChange(null, ElectricalPhase.AC3, false, "1HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("1HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.EDIT);
    newChange.setChanger(DEFAULT_USER_ID);

    // expected exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage("Loads are missing and required for a non-intermittent component.");

    // act
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_change_with_componentchange_for_node_that_has_component_with_different_phase_then_persist() {

    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // create a new component change for the node '1XP' with an phase of 'AC' and an electric ident
    // of '1HQ' (different phase than existing component for that node)
    ComponentChange newComponentChange =
        createComponentChange(new ArrayList<>(), ElectricalPhase.AC, false, "1HQ", 0d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("1HQ");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    Change result = subject.create(newChange, changeGroup.getId(), project.getId());
    Assert.assertNotNull(result);
  }

  @Test
  public void when_delete_change_with_component_change_then_delete_record() {
    // arrange
    String nodeName = ela.getNodes().get(0).getSubNodes().get(0).getName();
    Component existingComponent = ela.getNodes().get(0).getSubNodes().get(0).getComponents().get(0);

    List<LoadChange> loadChanges = Collections.singletonList(createLoadChange("roll"));
    ComponentChange componentChange =
        createComponentChange(
            loadChanges, ElectricalPhase.AC3, false, existingComponent.getElectIdent(), 0d);
    componentChange.setNominalPower(200d);
    Change existingComponentChange =
        createAndSaveChange(
            nodeName,
            existingComponent.getElectIdent(),
            ActionType.EDIT,
            DEFAULT_USER_ID,
            null,
            componentChange,
            changeGroup1);

    changeGroup1.setChanges(Collections.singletonList(existingComponentChange));
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());

    // act
    subject.delete(existingComponentChange.getId(), changeGroup1.getId(), project.getId());

    // assert (after deleting)
    List<Change> changesAfterDelete = subject.findAllByChangeGroupId(changeGroup1.getId());
    Assert.assertTrue(changesAfterDelete.isEmpty());
  }

  @Test
  public void
      when_delete_change_with_nodeChange_andParentIsNotSameNameAsChild_then_delete_record() {
    // arrange
    Node existingNode = ela.getNodes().get(0).getSubNodes().get(0);
    String nodeName = existingNode.getName();

    NodeChange nodeChange =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    // parent node name is different than child node name
    Change newChange =
        createAndSaveChange(
            ela.getNodes().get(0).getName(),
            null,
            ActionType.EDIT,
            DEFAULT_USER_ID,
            nodeChange,
            null,
            changeGroup1);

    changeGroup1.setChanges(Collections.singletonList(newChange));
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());

    // act
    subject.delete(newChange.getId(), changeGroup1.getId(), project.getId());

    // assert (after deleting)
    List<Change> changesAfterDelete = subject.findAllByChangeGroupId(changeGroup1.getId());
    Assert.assertTrue(changesAfterDelete.isEmpty());
  }

  @Test
  public void
      when_delete_change_with_nodeChange_andParentIsSameNodeNameAsChild_then_delete_record() {
    // arrange
    Node existingNode = ela.getNodes().get(0).getSubNodes().get(0);
    String nodeName = existingNode.getName();

    NodeChange nodeChange =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    // parent node name is same as child node name
    Change newChange =
        createAndSaveChange(
            nodeName, null, ActionType.EDIT, DEFAULT_USER_ID, nodeChange, null, changeGroup1);

    changeGroup1.setChanges(Collections.singletonList(newChange));
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());

    // act
    subject.delete(newChange.getId(), changeGroup1.getId(), project.getId());

    // assert (after deleting)
    List<Change> changesAfterDelete = subject.findAllByChangeGroupId(changeGroup1.getId());
    Assert.assertTrue(changesAfterDelete.isEmpty());
  }

  @Test
  public void when_deleteChange_withNodeChangeAndComponents_then_deleteNodeAndComponents() {
    // arrange
    Node existingNode = ela.getNodes().get(0);
    String parentNodeName = existingNode.getName();
    String nodeName = "TEST";
    String componentName = "newComponent";

    NodeChange nodeChange =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    Change newNodeChange =
        createAndSaveChange(
            parentNodeName, null, ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, changeGroup1);

    // componentChange (related to new nodeChange)
    List<LoadChange> loadChanges = new ArrayList<>();

    //  ElectricalPhase electricalPhase, String electIdent
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, componentName, 0d);
    Change newComponentChange =
        createAndSaveChange(
            nodeName,
            componentName,
            ActionType.ADD,
            DEFAULT_USER_ID,
            null,
            componentChange,
            changeGroup1);

    List<Change> existingChanges = new ArrayList<>();
    existingChanges.add(newNodeChange);
    existingChanges.add(newComponentChange);

    changeGroup1.setChanges(existingChanges);
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());

    // act
    subject.delete(newNodeChange.getId(), changeGroup1.getId(), project.getId());

    // assert (after deleting)
    List<Change> changesAfterDelete = subject.findAllByChangeGroupId(changeGroup1.getId());
    Assert.assertTrue(changesAfterDelete.isEmpty());
  }

  @Test
  public void
      when_deleteChange_withNodeChangeActionAddAndNoComponents_and_ExistingNodeChangeActionDeleteAndComponents_and_SameNodeNameForBoth_then_deleteNodeOnly() {
    // arrange

    // GEN 1 => ela.getNodes().get(0)
    // 1IWXP => ela.getNodes().get(0).getSubNodes().get(0)
    // 1XP => ela.getNodes().get(0).getSubNodes().get(1)
    Node existingNodeToDelete = ela.getNodes().get(0).getSubNodes().get(0);
    String existingNodeNameToDelete = existingNodeToDelete.getName();
    String existingNodeNameToAddChildNode = ela.getNodes().get(0).getSubNodes().get(1).getName();
    String parentNodeNameToDelete = existingNodeToDelete.getName();
    List<Change> existingChanges = new ArrayList<>();

    // node change (delete)
    NodeChange nodeChangeDelete =
        createNodeChange(
            10d,
            existingNodeNameToDelete,
            115d,
            existingNodeToDelete.getVoltageType(),
            existingNodeToDelete.getNodeType(),
            existingNodeToDelete.getNominalPower(),
            existingNodeToDelete.isRequiresApproval(),
            existingNodeToDelete.isSheddable(),
            existingNodeToDelete.isNormalTr(),
            existingNodeToDelete.getElectricalPhase());

    Change nodeToDelete =
        createAndSaveChange(
            parentNodeNameToDelete,
            null,
            ActionType.DELETE,
            DEFAULT_USER_ID,
            nodeChangeDelete,
            null,
            changeGroup1);

    // component change (delete)
    for (Component component : existingNodeToDelete.getComponents()) {
      List<LoadChange> loadChanges = Collections.emptyList();

      ComponentChange componentChange =
          createComponentChange(
              loadChanges,
              component.getElectricalPhase(),
              false,
              component.getElectIdent(),
              component.getNominalPower());
      Change componentToDelete =
          createAndSaveChange(
              existingNodeToDelete.getName(),
              component.getElectIdent(),
              ActionType.DELETE,
              DEFAULT_USER_ID,
              null,
              componentChange,
              changeGroup1);

      existingChanges.add(componentToDelete);
    }

    existingChanges.add(nodeToDelete);

    // node change (add)
    NodeChange nodeChangeToAdd =
        createNodeChange(
            10d,
            existingNodeNameToDelete,
            115d,
            existingNodeToDelete.getVoltageType(),
            existingNodeToDelete.getNodeType(),
            existingNodeToDelete.getNominalPower(),
            existingNodeToDelete.isRequiresApproval(),
            existingNodeToDelete.isSheddable(),
            existingNodeToDelete.isNormalTr(),
            existingNodeToDelete.getElectricalPhase());
    Change nodeToAdd =
        createAndSaveChange(
            existingNodeNameToAddChildNode,
            null,
            ActionType.ADD,
            DEFAULT_USER_ID,
            nodeChangeToAdd,
            null,
            changeGroup1);

    existingChanges.add(nodeToAdd);

    changeGroup1.setChanges(existingChanges);
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());
    Assert.assertEquals("Number of Changes must be 3", 3, changes.size());

    // act
    subject.delete(nodeToAdd.getId(), changeGroup1.getId(), project.getId());

    // assert (after deleting)
    List<Change> changesAfterDelete = subject.findAllByChangeGroupId(changeGroup1.getId());
    Assert.assertFalse(changesAfterDelete.isEmpty());
    Assert.assertEquals("Number of Changes must be 2", 2, changesAfterDelete.size());
  }

  @Test(expected = ConflictException.class)
  public void
      when_delete_change_with_nodechange_that_has_same_name_as_another_change_throw_exception() {

    Node existingNode = ela.getNodes().get(0).getSubNodes().get(0);
    String nodeName = existingNode.getName();

    NodeChange nodeChange1 =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    NodeChange nodeChange2 =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    Change newChange1 =
        createAndSaveChange(
            nodeName, null, ActionType.ADD, DEFAULT_USER_ID, nodeChange1, null, changeGroup1);

    Change newChange2 =
        createAndSaveChange(
            nodeName, null, ActionType.EDIT, DEFAULT_USER_ID, nodeChange2, null, changeGroup1);

    List<Change> changes = Arrays.asList(newChange1, newChange2);

    changeGroup1.setChanges(changes);
    changeGroupRepo.save(changeGroup1);

    // act
    subject.delete(newChange1.getId(), changeGroup1.getId(), project.getId());
  }

  @Test(expected = ConflictException.class)
  public void when_deleteChange_withNodeChangeAndChildrenNodeChanges_then_throwConflictException() {
    // arrange
    Node existingNode = ela.getNodes().get(0);
    String parentNodeName = existingNode.getName();
    String nodeName = "Level 2";
    String childNodeName = "Level 3";

    NodeChange nodeChange =
        createNodeChange(
            10d,
            nodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());

    Change newNodeChange =
        createAndSaveChange(
            parentNodeName, null, ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, changeGroup1);

    // childNodeChange (related to new nodeChange)
    NodeChange childNodeChange =
        createNodeChange(
            10d,
            childNodeName,
            115d,
            existingNode.getVoltageType(),
            existingNode.getNodeType(),
            existingNode.getNominalPower(),
            existingNode.isRequiresApproval(),
            existingNode.isSheddable(),
            existingNode.isNormalTr(),
            existingNode.getElectricalPhase());
    Change newChildNodeChange =
        createAndSaveChange(
            nodeName, null, ActionType.ADD, DEFAULT_USER_ID, childNodeChange, null, changeGroup1);

    List<Change> existingChanges = new ArrayList<>();
    existingChanges.add(newNodeChange);
    existingChanges.add(newChildNodeChange);

    changeGroup1.setChanges(existingChanges);
    changeGroupRepo.save(changeGroup1);

    // assert (before deleting)
    List<Change> changes = changeGroup1.getChanges();
    Assert.assertFalse(changes.isEmpty());

    // act
    subject.delete(newNodeChange.getId(), changeGroup1.getId(), project.getId());
  }

  /** Update Change (valid) */
  @Test
  public void when_update_withvalidFlightPhaseAndOperatingMode_then_persist() {
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // component change (valid flight Phase)
    List<LoadChange> loadChanges = new ArrayList<>();
    loadChanges.add(
        createLoadChange(
            ClientConfig.Airbus.GROUND.toString(), OperatingMode.Airbus.MAXI.toString(), 1d, 20d));
    ComponentChange newComponentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC, false, "TEST", 20d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("TEST");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    Change result = subject.create(newChange, changeGroup.getId(), project.getId());
    Assert.assertNotNull(result);
  }

  /** Update Change (invalid Flight Phase) */
  @Test
  public void when_update_withInvalidFlightPhase_then_throw_BadRequestException() {
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // component change (invalid flight Phase)
    List<LoadChange> loadChanges = new ArrayList<>();
    loadChanges.add(createLoadChange("DUMMY", OperatingMode.Airbus.MAXI.toString(), 1d, 20d));
    ComponentChange newComponentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC, false, "TEST", 20d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("TEST");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    // expected exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage(
        "Load contains incompatible Flight Phase 'DUMMY' for Component 'TEST' and Node '1XP'");

    // act
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  /** Update Change (invalid Operating Mode) */
  @Test
  public void when_update_withInvalidOperatingMode_then_throw_BadRequestException() {
    ChangeGroup changeGroup = createAndSaveChangeGroup("Airbus ABC", project);
    project.addChangeGroup(changeGroup);

    Aircraft aircraft = createAndSaveAircraft("3233", "329", "N333NW", "N/A", "N/A", fleetAirbus);

    Ela ela = createAndSaveEla("Split Ela 1", aircraft);

    // ela1 node(s)
    Node elaNodeGenerator =
        createAndSaveNode(
            true, "GEN 1", 115d, 100d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 1, null, ela);
    Node elaNodeBus =
        createAndSaveNode(
            true,
            "1XP",
            115d,
            50d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            1,
            elaNodeGenerator,
            null);
    elaNodeGenerator.addSubNode(elaNodeBus);

    createAndSaveComponent(elaNodeBus, "1HQ", ElectricalPhase.AC3, 20d, 1);

    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // component change (invalid flight Phase)
    List<LoadChange> loadChanges = new ArrayList<>();
    loadChanges.add(createLoadChange(ClientConfig.Airbus.GROUND.toString(), "DUMMY", 1d, 20d));
    ComponentChange newComponentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC, false, "TEST", 20d);

    Change newChange = createChange();
    newChange.setNodeName("1XP");
    newChange.setComponentElectIdent("TEST");
    newChange.setComponentChange(newComponentChange);
    newChange.setAction(ActionType.ADD);
    newChange.setChanger(DEFAULT_USER_ID);

    // expected exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage(
        "Load contains incompatible Operating Mode 'DUMMY' for Component 'TEST' and Node '1XP'");

    // act
    subject.create(newChange, changeGroup.getId(), project.getId());
  }

  private void initalizeDatabase() {
    // fleet
    fleetAirbus = createAndSaveFleet(100, "Airbus");

    // aircraft(s)
    Aircraft aircraft =
        createAndSaveAircraft("changeService_ship1", "1000", "R1000", "Line1", "V1", fleetAirbus);
    Aircraft aircraft2 =
        createAndSaveAircraft("changeService_ship2", "2000", "R2000", "Line2", "V2", fleetAirbus);

    // ela(s)
    ela = createAndSaveEla("Ela 1", aircraft);
    Ela ela2 = createAndSaveEla("Ela 2", aircraft2);

    elaIds.add(ela.getId());
    elaIds.add(ela2.getId());

    // nodes (1st level)
    nodeGeneratorA =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.DC, 11, null, ela);
    Node node2 =
        createAndSaveNode(
            false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela);

    // nodes (2nd level)
    Node node3 =
        createAndSaveNode(
            false,
            "1IWXP",
            5d,
            10d,
            NodeType.BUS,
            100d,
            ElectricalPhase.AC3,
            31,
            nodeGeneratorA,
            null);
    Node node4 =
        createAndSaveNode(
            false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, nodeGeneratorA, null);

    // nodes (3rd level)
    Node node5 =
        createAndSaveNode(
            false, "101XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, node4, null);

    node4.addSubNode(node5);

    nodeGeneratorA.addSubNode(node3);
    nodeGeneratorA.addSubNode(node4);

    // components
    createAndSaveComponentWithLoads(
        nodeGeneratorA, "component ABC", ElectricalPhase.AC, 20d, 2, false);
    createAndSaveComponentWithLoads(node3, "component XYZ", ElectricalPhase.AC, 20d, 3, false);

    // nodes (1st level)
    nodeGeneratorB =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.DC, 11, null, ela2);
    createAndSaveNode(
        false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela2);

    // nodes (2nd level)
    createAndSaveNode(
        false, "1IWXP", 5d, 10d, NodeType.BUS, 100d, ElectricalPhase.AC3, 31, nodeGeneratorB, null);
    createAndSaveNode(
        false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, nodeGeneratorB, null);

    // project
    project =
        createAndSaveProject(
            "title 1",
            "description goes here.",
            "maintenance description goes here",
            "1",
            "1",
            Instant.now());

    // change groups
    changeGroup1 = createAndSaveChangeGroup("change group 1", project);
    ChangeGroup changeGroup2 = createAndSaveChangeGroup("change group 2", project);

    project.addChangeGroup(changeGroup1);
    project.addChangeGroup(changeGroup2);

    // aircraft change groups
    createAndSaveAircraftChangeGroup(aircraft, changeGroup1);
    createAndSaveAircraftChangeGroup(aircraft2, changeGroup1);
  }
}
