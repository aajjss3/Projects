package com.seatec.ela.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.util.NodeUtil;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3324.sql",
        "/datasets/node-3324.sql",
        "/datasets/component-3324.sql",
        "/datasets/load-3324.sql"
      }),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class NodeServiceIT extends AbstractControllerIntegrationTest {

  private static final long ELA_ID = 4012L;

  @Autowired private NodeService nodeService;

  @Autowired private NodeRepository nodeRepository;

  @Test
  public void findById_should_return_fully_hydrated_root_node() {

    // when
    // Node: Gen 1
    Long expectedNodeId = 248928L;
    String expectedNodeName = "GEN 1";

    // Node: 115XP
    String expectedLeafNodeName = "115XP";

    // then
    Optional<Node> actualResult = nodeService.findById(expectedNodeId, ELA_ID, null);

    // verify
    assertTrue("the hydrated node should be present", actualResult.isPresent());

    Node actualNode = actualResult.get();

    assertEquals(expectedNodeId, actualNode.getId());
    assertEquals(expectedNodeName, actualNode.getName());

    List<Node> actualNodesFlatList = NodeUtil.flattenNodeTrees(Arrays.asList(actualNode));

    Node actualLeafNode = NodeUtil.getNodeByName(actualNodesFlatList, expectedLeafNodeName);

    assertNotNull("the leaf node should exist on the hydrated node", actualLeafNode);
  }

  @Test
  public void findById_should_return_fully_hydrated_leaf_node() {

    // when
    // Node: 115XP
    Long expectedNodeId = 248937L;

    // Component: HEATER WASTE
    Long expectedComponentId = 2287326L;

    // Load: GROUND MAXI
    Long expectedLoadId = 32652652L;
    String expectedLoadOperatingMode = "MAXI";
    String expectedLoadFlightPhase = "GROUND";

    // then
    Optional<Node> actualResult = nodeService.findById(expectedNodeId, ELA_ID, null);

    // verify
    assertTrue("the hydrated node should be present", actualResult.isPresent());

    Node actualNode = actualResult.get();

    assertEquals(expectedNodeId, actualNode.getId());

    List<Component> actualComponents = actualNode.getComponents();

    assertNotNull("the hydrated node should have components", actualComponents);

    Map<Long, Component> actualComponentMap =
        actualComponents.stream().collect(Collectors.toMap(Component::getId, Function.identity()));

    Component actualComponent = actualComponentMap.get(expectedComponentId);

    assertNotNull("the component should exist in the node's components", actualComponent);

    List<Load> actualLoads = actualComponent.getLoads();

    Map<Long, Load> actualLoadMap =
        actualLoads.stream().collect(Collectors.toMap(Load::getId, Function.identity()));

    Load actualLoad = actualLoadMap.get(expectedLoadId);

    assertNotNull("the component should have loads", actualComponents);

    assertNotNull("the load should exist in the component's loads", actualLoad);
    assertEquals(expectedLoadOperatingMode, actualLoad.getOperatingMode());
    assertEquals(expectedLoadFlightPhase, actualLoad.getFlightPhase());
  }

  @Test
  public void findById_should_return_nothing_for_invalid_id() {

    // when
    // Node: non-existent in 3324
    Long expectedNodeId = 0L;

    // then
    Optional<Node> actualResult = nodeService.findById(expectedNodeId, ELA_ID, null);

    // verify
    assertFalse("the node should NOT be found for the invalid id", actualResult.isPresent());
  }

  @Test
  public void hydrateNodes_should_return_fully_hydrated_nodes() {

    // when
    List<Node> expectedElaNodes = nodeRepository.getNodesInEla(ELA_ID);
    List<Long> expectedRootNodeIds = NodeUtil.getTopLevelNodeIds(expectedElaNodes);

    // then
    List<Node> actualElaNodes = nodeService.hydrateNodes(expectedRootNodeIds, ELA_ID, null);

    // verify
    assertEquals(expectedRootNodeIds.size(), actualElaNodes.size());

    assertEquals(expectedElaNodes.size(), NodeUtil.flattenNodeTrees(actualElaNodes).size());
  }

  @Test
  public void hydrateEla_should_return_fully_hydrated_ela() {

    // when
    Ela ela = new Ela();
    ela.setId(ELA_ID);

    // Node: 115XP
    Long expectedNodeId = 248937L;
    String expectedNodeName = "115XP";

    // Component: HEATER WASTE
    Long expectedComponentId = 2287326L;

    // Load: GROUND MAXI
    Long expectedLoadId = 32652652L;
    String expectedLoadOperatingMode = "MAXI";
    String expectedLoadFlightPhase = "GROUND";

    List<Node> expectedElaNodes = nodeRepository.getNodesInEla(ELA_ID);
    List<Long> expectedRootNodeIds = NodeUtil.getTopLevelNodeIds(expectedElaNodes);

    // then
    Ela actualEla = nodeService.hydrateEla(ela);

    // verify
    assertNotNull("a fully hydrated ela is returned", actualEla);

    List<Node> actualNodes = actualEla.getNodes();

    assertNotNull("the fully hydrated ela has nodes", actualNodes);

    assertEquals(expectedRootNodeIds.size(), actualNodes.size());

    List<Node> actualNodesFlatList = NodeUtil.flattenNodeTrees(actualNodes);

    assertEquals(expectedElaNodes.size(), actualNodesFlatList.size());

    Node actualLeafNode = NodeUtil.getNodeByName(actualNodesFlatList, expectedNodeName);

    assertNotNull("the leaf node should exist on the hydrated node", actualLeafNode);
    assertEquals(expectedNodeId, actualLeafNode.getId());

    List<Component> actualLeafComponents = actualLeafNode.getComponents();

    assertNotNull("the leaf node should have components", actualLeafComponents);

    Map<Long, Component> actualComponentMap =
        actualLeafComponents.stream()
            .collect(Collectors.toMap(Component::getId, Function.identity()));

    Component actualComponent = actualComponentMap.get(expectedComponentId);

    assertNotNull("the component should exist in the leaf node's components", actualComponent);

    List<Load> actualLoads = actualComponent.getLoads();

    assertNotNull("the component should have loads", actualLoads);

    Map<Long, Load> actualLoadMap =
        actualLoads.stream().collect(Collectors.toMap(Load::getId, Function.identity()));

    Load actualLoad = actualLoadMap.get(expectedLoadId);

    assertNotNull("the load should exist in the component's loads", actualLoad);
    assertEquals(expectedLoadOperatingMode, actualLoad.getOperatingMode());
    assertEquals(expectedLoadFlightPhase, actualLoad.getFlightPhase());
  }
}
