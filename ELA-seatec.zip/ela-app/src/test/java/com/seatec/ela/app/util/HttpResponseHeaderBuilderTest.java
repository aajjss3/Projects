package com.seatec.ela.app.util;

import static org.junit.Assert.assertEquals;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

public class HttpResponseHeaderBuilderTest {

  @Test
  public void shouldAddLinkHeaderToHttpResponseWhenAddingPaginationForFirstPage() {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    PaginationDTO<ProjectDTO> dto = new PaginationDTO<>();
    dto.setMetadata(1, 5, 3, 15l);
    HttpResponseHeaderBuilder.addLinkHeaderToHttpResponse(response, request, dto);
    assertEquals(
        "<http://localhost?page=2&size=5>; rel=\"next\", <http://localhost?page=1&size=5>; rel=\"first\", <http://localhost?page=3&size=5>; rel=\"last\"",
        response.getHeader("Link"));
  }

  @Test
  public void shouldAddLinkHeaderToHttpResponseWhenAddingPaginationForMiddlePage() {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    PaginationDTO<ProjectDTO> dto = new PaginationDTO<>();
    dto.setMetadata(2, 5, 3, 15l);
    HttpResponseHeaderBuilder.addLinkHeaderToHttpResponse(response, request, dto);
    assertEquals(
        "<http://localhost?page=3&size=5>; rel=\"next\", <http://localhost?page=1&size=5>; rel=\"prev\", <http://localhost?page=1&size=5>; rel=\"first\", <http://localhost?page=3&size=5>; rel=\"last\"",
        response.getHeader("Link"));
  }

  @Test
  public void shouldAddLinkHeaderToHttpResponseWhenAddingPaginationForLastPage() {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    PaginationDTO<ProjectDTO> dto = new PaginationDTO<>();
    dto.setMetadata(3, 5, 3, 15l);
    HttpResponseHeaderBuilder.addLinkHeaderToHttpResponse(response, request, dto);
    assertEquals(
        "<http://localhost?page=2&size=5>; rel=\"prev\", <http://localhost?page=1&size=5>; rel=\"first\", <http://localhost?page=3&size=5>; rel=\"last\"",
        response.getHeader("Link"));
  }
}
