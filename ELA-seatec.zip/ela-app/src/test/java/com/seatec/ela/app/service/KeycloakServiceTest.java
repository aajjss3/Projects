package com.seatec.ela.app.service;

import static com.seatec.ela.app.service.KeycloakService.REALM_MANAGEMENT_CLIENT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.KeycloakUserDto;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.service.contract.IKeycloakExternalService;
import com.seatec.ela.app.util.KeycloakDataConverter;
import edu.emory.mathcs.backport.java.util.Collections;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.ArgumentCaptor;

public class KeycloakServiceTest {

  private static final String AUTHOR_ROLE_NAME = "author";
  private static final String VIEWER_ROLE_NAME = "viewer";
  private static final String IT_ADMIN_ROLE_NAME = "it_admin";

  private KeycloakService subject;
  private IKeycloakExternalService keycloakExternalService;
  private KeycloakDataConverter keycloakDataConverter;

  private EmailExternalService mockEmailService;

  @Rule public ExpectedException exceptionRule = ExpectedException.none();

  @Before
  public void setup() {
    keycloakExternalService = mock(IKeycloakExternalService.class);
    keycloakDataConverter = new KeycloakDataConverter("ela");
    mockEmailService = mock(EmailExternalService.class);
    subject =
        new KeycloakService(
            "ela", "ela-angular", keycloakExternalService, keycloakDataConverter, mockEmailService);
  }

  @Test
  public void
      findUsersInRole_should_return_empty_list_when_keycloakExternalService_returns_empty_list() {
    when(keycloakExternalService.findAllUsers()).thenReturn(Collections.emptyList());
    List<KeycloakUserDto> result = subject.findUsersInRole("test");
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  public void findUsersInRole_should_return_empty_list_when_no_users_with_role_exist() {
    when(keycloakExternalService.findAllUsers())
        .thenReturn(Arrays.asList(createUser(VIEWER_ROLE_NAME)));
    List<KeycloakUserDto> result = subject.findUsersInRole("test");
    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  public void findUsersInRole_should_return_dtos_when_users_with_role_exist() {
    when(keycloakExternalService.findAllUsers())
        .thenReturn(
            Arrays.asList(
                createUser(VIEWER_ROLE_NAME),
                createUser(VIEWER_ROLE_NAME),
                createUser("approver"),
                createUser("approver")));
    List<KeycloakUserDto> result = subject.findUsersInRole(VIEWER_ROLE_NAME);
    assertNotNull(result);
    assertFalse(result.isEmpty());
    assertEquals(2, result.size());
  }

  @Test
  public void createUser_should_create_a_random_password() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, VIEWER_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    // mocks
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(VIEWER_ROLE_NAME));
    doNothing().when(keycloakExternalService).createUser(argument.capture());

    // act
    subject.createUser(user);

    // assert
    assertNotNull(argument.getValue().getCredentials());
    assertFalse(argument.getValue().getCredentials().isEmpty());
    assertNotNull(argument.getValue().getCredentials().get(0));
    assertNotNull(argument.getValue().getCredentials().get(0).getValue());
    verify(mockEmailService).sendUserLoginEmail(any(), anyString());
  }

  @Test
  public void createUser_should_create_client_roles_for_author() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, AUTHOR_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    // mocks
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(AUTHOR_ROLE_NAME));
    doNothing().when(keycloakExternalService).createUser(argument.capture());

    // act
    subject.createUser(user);

    // assert
    assertNotNull(argument.getValue().getClientRoles());
    assertNotNull(argument.getValue().getClientRoles().get("ela"));
    assertNotNull(argument.getValue().getClientRoles().get("ela-angular"));
    assertNotNull(argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT));
    assertFalse(argument.getValue().getClientRoles().get("ela").isEmpty());
    assertFalse(argument.getValue().getClientRoles().get("ela-angular").isEmpty());
    assertFalse(argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT).isEmpty());
    assertEquals(2, argument.getValue().getClientRoles().get("ela").size());
    assertEquals(1, argument.getValue().getClientRoles().get("ela-angular").size());
    assertEquals(2, argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT).size());
    verify(mockEmailService).sendUserLoginEmail(any(), anyString());
  }

  @Test
  public void createUser_should_create_client_roles_for_it_admin() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, IT_ADMIN_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    // mocks
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(IT_ADMIN_ROLE_NAME));
    doNothing().when(keycloakExternalService).createUser(argument.capture());

    // act
    subject.createUser(user);

    // assert
    assertNotNull(argument.getValue().getClientRoles());
    assertNotNull(argument.getValue().getClientRoles().get("ela"));
    assertNotNull(argument.getValue().getClientRoles().get("ela-angular"));
    assertNotNull(argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT));
    assertFalse(argument.getValue().getClientRoles().get("ela").isEmpty());
    assertFalse(argument.getValue().getClientRoles().get("ela-angular").isEmpty());
    assertFalse(argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT).isEmpty());
    assertEquals(2, argument.getValue().getClientRoles().get("ela").size());
    assertEquals(1, argument.getValue().getClientRoles().get("ela-angular").size());
    assertEquals(3, argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT).size());
    verify(mockEmailService).sendUserLoginEmail(any(), anyString());
  }

  @Test
  public void createUser_should_create_client_roles_for_viewer() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, VIEWER_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    // mocks
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(VIEWER_ROLE_NAME));
    doNothing().when(keycloakExternalService).createUser(argument.capture());

    // act
    subject.createUser(user);

    // assert
    assertNotNull(argument.getValue().getClientRoles());
    assertNotNull(argument.getValue().getClientRoles().get("ela"));
    assertNotNull(argument.getValue().getClientRoles().get("ela-angular"));
    assertNull(argument.getValue().getClientRoles().get(REALM_MANAGEMENT_CLIENT));
    assertFalse(argument.getValue().getClientRoles().get("ela").isEmpty());
    assertFalse(argument.getValue().getClientRoles().get("ela-angular").isEmpty());
    assertEquals(2, argument.getValue().getClientRoles().get("ela").size());
    assertEquals(1, argument.getValue().getClientRoles().get("ela-angular").size());
    verify(mockEmailService).sendUserLoginEmail(any(), anyString());
  }

  @Test
  public void when_createUser_withInvalidRole_then_throw_NotFoundException() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, "DUMMY");

    // mocks
    when(keycloakExternalService.getRoleByName(any(String.class))).thenReturn(null);

    // should throw an exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Unable to locate Role (DUMMY)");

    // act
    subject.createUser(user);
  }

  @Test
  public void when_updateUser_andUserNotFound_then_throw_NotFoundException() {
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, VIEWER_ROLE_NAME);

    // should throw an exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Unable to locate User (1)");

    // act
    subject.updateUser(user, "1");
  }

  @Test
  public void when_updateUser_withInvalidRole_then_throw_NotFoundException() {
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, "DUMMY");

    // mocks (DUMMY role does not exist)
    when(keycloakExternalService.findUser(anyString())).thenReturn(createUser(AUTHOR_ROLE_NAME));
    when(keycloakExternalService.getRoleByName(any(String.class))).thenReturn(null);

    // should throw an exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Unable to locate Role (DUMMY)");

    // act
    subject.updateUser(user, "1");
  }

  @Test
  public void updateUser_should_set_user_disabled_if_changing_email() {
    // arrange
    KeycloakUserDto user =
        new KeycloakUserDto(
            "1", "first", "last", true, "testchanged@test.com", true, VIEWER_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    // mocks
    when(keycloakExternalService.findUser(anyString())).thenReturn(createUser(VIEWER_ROLE_NAME));
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(VIEWER_ROLE_NAME));
    doNothing().when(keycloakExternalService).updateUser(argument.capture());

    // act
    subject.updateUser(user, "1");

    // assert
    assertFalse(argument.getValue().isEnabled());
  }

  @Test
  public void updateUser_should_call_keycloakExternalService_when_email_matches() {
    KeycloakUserDto user =
        new KeycloakUserDto("1", "first", "last", true, "test@test.com", true, VIEWER_ROLE_NAME);
    ArgumentCaptor<UserRepresentation> argument = ArgumentCaptor.forClass(UserRepresentation.class);

    when(keycloakExternalService.findUser(anyString())).thenReturn(createUser(VIEWER_ROLE_NAME));
    when(keycloakExternalService.getRoleByName(any(String.class)))
        .thenReturn(getRoleByName(VIEWER_ROLE_NAME));
    doNothing().when(keycloakExternalService).updateUser(argument.capture());

    subject.updateUser(user, "1");
    assertEquals(user.getFirstName(), argument.getValue().getFirstName());
    assertEquals(user.getLastName(), argument.getValue().getLastName());
    assertEquals(user.getEnabled(), argument.getValue().isEnabled());
  }

  @Test
  public void isUserAndInRole_should_return_true_if_user_in_role_is_present() {
    when(keycloakExternalService.findUser(anyString())).thenReturn(createUser(VIEWER_ROLE_NAME));
    boolean result = subject.isUserAndInRole("1", VIEWER_ROLE_NAME);
    assertTrue(result);
  }

  @Test
  public void isUserAndInRole_should_return_false_if_user_does_not_exist() {
    when(keycloakExternalService.findUser(anyString())).thenReturn(null);
    boolean result = subject.isUserAndInRole("1", VIEWER_ROLE_NAME);
    assertFalse(result);
  }

  @Test
  public void isUserAndInRole_should_return_false_if_user_is_present_but_not_in_role() {
    when(keycloakExternalService.findUser(anyString())).thenReturn(createUser("approver"));
    boolean result = subject.isUserAndInRole("1", VIEWER_ROLE_NAME);
    assertFalse(result);
  }

  private UserRepresentation createUser(String role) {
    UserRepresentation user = new UserRepresentation();
    user.setId("1");
    user.setEmail("test@test.com");
    user.setEmailVerified(true);
    user.setFirstName("test");
    user.setLastName("tests");
    user.setEnabled(true);
    Map<String, List<String>> clientRoles = new HashMap<>();
    clientRoles.put("ela", Arrays.asList(role, "user"));
    clientRoles.put("ela-angular", Arrays.asList(role));
    clientRoles.put("realm-management", Arrays.asList("view-users", "view-clients"));
    user.setClientRoles(clientRoles);
    return user;
  }

  private RoleRepresentation getRoleByName(String roleName) {
    RoleRepresentation roleRepresentation = new RoleRepresentation();
    roleRepresentation.setName(roleName);

    return roleRepresentation;
  }
}
