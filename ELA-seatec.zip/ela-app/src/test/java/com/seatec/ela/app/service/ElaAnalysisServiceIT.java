package com.seatec.ela.app.service;

import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.*;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.dto.analysis.*;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.EfficiencyType;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.EfficiencyTableRepo;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ElaAnalysisServiceIT extends AbstractControllerIntegrationTest {

  @Autowired ElaAnalysisService elaAnalysisService;

  @Autowired ElaRepository elaRepo;

  @Autowired AircraftRepository aircraftRepo;

  @Autowired NodeRepository nodeRepo;

  @Autowired ComponentRepository componentRepo;

  @Autowired LoadRepository loadRepo;

  @Autowired EfficiencyTableRepo efficiencyTableRepo;

  private static String BOEING = "Boeing";

  private Long elaId1;
  private Long elaId2;
  private Long elaId3;
  private Long elaId4;
  private Long elaId5;
  private Long elaId6;

  @Before
  public void setup() {
    // fleet
    Fleet fleetAirbus = createFleet(1);
    fleetRepo.save(fleetAirbus);

    Fleet fleetBoeing = createFleet(2);
    fleetBoeing.setManufacturer(BOEING);
    fleetRepo.save(fleetBoeing);

    Fleet B767300 = createFleet(3);
    B767300.setManufacturer(BOEING);
    B767300.setName("B767-300");
    fleetRepo.save(B767300);

    Fleet fleetB777 = createFleet(4);
    fleetB777.setManufacturer(BOEING);
    fleetB777.setName("B777-200LR");
    fleetRepo.save(fleetB777);

    // aircraft
    Aircraft aircraft1 = new Aircraft("ship1", "1000", "R1000", "Line1", "V1", null);
    aircraft1.setFleet(fleetAirbus);
    fleetAirbus.getAircraft().add(aircraft1);
    aircraftRepo.save(aircraft1);

    Aircraft aircraft2 = new Aircraft("ship2", "2000", "R2000", "Line2", "V2", null);
    aircraft2.setFleet(fleetBoeing);
    aircraft2.setBatteryCharge(BatteryChargeType.DUAL_40AH);
    fleetAirbus.getAircraft().add(aircraft2);
    aircraftRepo.save(aircraft2);

    Aircraft aircraft3 = new Aircraft("ship3", "3000", "R3000", "Line3", "V3", null);
    aircraft3.setFleet(fleetBoeing);
    aircraft3.setBatteryCharge(BatteryChargeType.SINGLE_75AH);
    fleetAirbus.getAircraft().add(aircraft3);
    aircraftRepo.save(aircraft3);

    Aircraft aircraft4 = new Aircraft("ship4", "4000", "R3000", "Line4", "V4", null);
    aircraft4.setFleet(B767300);
    aircraft4.setBatteryCharge(BatteryChargeType.SINGLE_40AH);
    fleetAirbus.getAircraft().add(aircraft4);
    aircraftRepo.save(aircraft4);

    Aircraft aircraft5 = new Aircraft("ship5", "4000", "R3000", "Line5", "V5", null);
    aircraft5.setFleet(B767300);
    aircraft5.setBatteryCharge(BatteryChargeType.SINGLE_40AH);
    fleetAirbus.getAircraft().add(aircraft5);
    aircraftRepo.save(aircraft5);

    Aircraft aircraft6 = new Aircraft("ship6", "4000", "R3000", "Line6", "V6", null);
    aircraft6.setFleet(fleetB777);
    aircraft6.setBatteryCharge(BatteryChargeType.SINGLE_47AH);
    fleetAirbus.getAircraft().add(aircraft6);
    aircraftRepo.save(aircraft6);

    // ela
    Ela ela1 = new Ela();
    ela1.setName("test1");
    ela1.setCreatedBy("test");
    ela1.setAircraft(aircraft1);
    elaRepo.save(ela1);

    Ela ela2 = new Ela();
    ela2.setName("test2");
    ela2.setCreatedBy("test");
    ela2.setAircraft(aircraft2);
    elaRepo.save(ela2);

    Ela ela3 = new Ela();
    ela3.setName("test3");
    ela3.setCreatedBy("test");
    ela3.setAircraft(aircraft3);
    elaRepo.save(ela3);

    Ela ela4 = new Ela();
    ela4.setName("test4");
    ela4.setCreatedBy("test");
    ela4.setAircraft(aircraft4);
    elaRepo.save(ela4);

    Ela ela5 = new Ela();
    ela5.setName("test5");
    ela5.setCreatedBy("test");
    ela5.setAircraft(aircraft5);
    elaRepo.save(ela5);

    Ela ela6 = new Ela();
    ela6.setName("test6");
    ela6.setCreatedBy("test");
    ela6.setAircraft(aircraft6);
    elaRepo.save(ela6);

    elaId1 = ela1.getId();
    elaId2 = ela2.getId();
    elaId3 = ela3.getId();
    elaId4 = ela4.getId();
    elaId5 = ela5.getId();
    elaId6 = ela6.getId();

    data(ela1, true, false, "roll", "ground", "start");
    data(ela2, false, true, "STANDBY", "ground", "start");
    data(ela3, false, true, "STANDBY", "ground", "start");
    data(ela4, false, true, "CRUISE", "TAKEOFF_CLIMB", "HOLD_LAND", "HMG");
    data(ela5, false, true, "CRUISE", "TAKEOFF_CLIMB", "HOLD_LAND");
    data(ela6, false, true, "STANDBY", "ground", "start");
  }

  private void data(Ela ela, boolean isAirbus, boolean isBoeing, String... flightPhases) {

    // nodes
    Node node1 = new Node();
    node1.setRequiresApproval(false);
    node1.setEla(ela);
    node1.setName("one");
    node1.setVoltage(5d);
    node1.setNominalPower(10d);
    node1.setNodeType(NodeType.BUS);
    node1.setRequiresApproval(false);
    node1.setBusRating(300d);
    node1.setVoltageType(ElectricalPhase.DC);
    node1.setDisplayOrder(1);
    nodeRepo.save(node1);

    Node node2 = new Node();
    node2.setRequiresApproval(false);
    node2.setEla(ela);
    node2.setName("two");
    node2.setVoltage(5d);
    node2.setNominalPower(10d);
    node2.setNodeType(NodeType.BUS);
    node2.setRequiresApproval(false);
    node2.setBusRating(120d);
    node2.setVoltageType(ElectricalPhase.AC3);
    node2.setDisplayOrder(2);
    nodeRepo.save(node2);

    Node node3 = new Node();
    node3.setRequiresApproval(false);
    node3.setEla(ela);
    node3.setName("three");
    node3.setParentNode(node1);
    node3.setVoltage(5d);
    node3.setNominalPower(10d);
    node3.setNodeType(NodeType.BUS);
    node3.setRequiresApproval(false);
    node3.setBusRating(100d);
    node3.setVoltageType(ElectricalPhase.AC3);
    node3.setDisplayOrder(3);
    nodeRepo.save(node3);

    Node node4 = new Node();
    node4.setRequiresApproval(false);
    node4.setEla(ela);
    node4.setName("four");
    node4.setParentNode(node1);
    node4.setVoltage(5d);
    node4.setNominalPower(20d);
    node4.setNodeType(NodeType.TRU);
    node4.setRequiresApproval(false);
    node4.setBusRating(20d);
    node4.setVoltageType(ElectricalPhase.AC);
    node4.setElectricalPhase(ElectricalPhase.ACA);
    node4.setDisplayOrder(4);
    node4.setNormalTr(true);
    nodeRepo.save(node4);

    Node node4Child = new Node();
    node4Child.setRequiresApproval(false);
    node4Child.setName("fourChild");
    node4Child.setParentNode(node4);
    node4Child.setVoltage(28d);
    node4Child.setNominalPower(20d);
    node4Child.setNodeType(NodeType.BUS);
    node4Child.setRequiresApproval(false);
    node4Child.setBusRating(20d);
    node4Child.setVoltageType(ElectricalPhase.DC);
    node4Child.setDisplayOrder(4);
    node4Child.setNormalTr(false);
    nodeRepo.save(node4Child);

    Node node5 = new Node();
    node5.setRequiresApproval(false);
    node5.setEla(ela);
    node5.setName("five");
    node5.setParentNode(null);
    node5.setVoltage(5d);
    node5.setNominalPower(100d);
    node5.setNodeType(NodeType.GENERATOR);
    node5.setRequiresApproval(false);
    node5.setBusRating(100d);
    node5.setVoltageType(ElectricalPhase.AC3);
    node5.setDisplayOrder(5);
    nodeRepo.save(node5);

    Node node6 = new Node();
    node6.setRequiresApproval(false);
    node6.setEla(ela);
    node6.setName("six");
    node6.setParentNode(null);
    node6.setVoltage(5d);
    node6.setNominalPower(100d);
    node6.setNodeType(NodeType.GENERATOR);
    node6.setRequiresApproval(false);
    node6.setBusRating(100d);
    node6.setVoltageType(ElectricalPhase.AC3);
    node6.setDisplayOrder(6);
    nodeRepo.save(node6);

    Node node7 = new Node();
    node7.setRequiresApproval(false);
    node7.setEla(ela);
    node7.setName("seven");
    node7.setParentNode(node1);
    node7.setVoltage(5d);
    node7.setNominalPower(20d);
    node7.setNodeType(NodeType.TRU);
    node7.setRequiresApproval(false);
    node7.setBusRating(20d);
    node7.setVoltageType(ElectricalPhase.AC);
    node7.setElectricalPhase(ElectricalPhase.ACA);
    node7.setDisplayOrder(7);
    node7.setNormalTr(true);
    nodeRepo.save(node7);

    Node node7Child = new Node();
    node7Child.setRequiresApproval(false);
    node7Child.setName("sevenChild");
    node7Child.setParentNode(node7);
    node7Child.setVoltage(28d);
    node7Child.setNominalPower(20d);
    node7Child.setNodeType(NodeType.BUS);
    node7Child.setRequiresApproval(false);
    node7Child.setBusRating(20d);
    node7Child.setVoltageType(ElectricalPhase.DC);
    node7Child.setDisplayOrder(7);
    node7Child.setNormalTr(false);
    nodeRepo.save(node7Child);

    if (ela.getId().equals(elaId4)
        && flightPhases.length > 3
        && "HMG".equalsIgnoreCase(flightPhases[3])) {
      Node node9 = new Node();
      node9.setEla(ela);
      node9.setName("HMG GEN");
      node9.setParentNode(node1);
      node9.setVoltage(115d);
      node9.setNominalPower(5000d);
      node9.setNodeType(NodeType.STANDBY_GEN);
      node9.setRequiresApproval(false);
      node9.setVoltageType(ElectricalPhase.AC);
      node9.setElectricalPhase(ElectricalPhase.AC3);
      node9.setDisplayOrder(100);
      nodeRepo.save(node9);
    }

    if (ela.getId().equals(elaId5)) {
      Node node8 = new Node();
      node8.setRequiresApproval(false);
      node8.setEla(ela);
      node8.setName("eight");
      node8.setParentNode(node1);
      node8.setVoltage(5d);
      node8.setNominalPower(20d);
      node8.setNodeType(NodeType.TRU);
      node8.setRequiresApproval(false);
      node8.setBusRating(20d);
      node8.setVoltageType(ElectricalPhase.AC);
      node8.setElectricalPhase(ElectricalPhase.ACA);
      node8.setDisplayOrder(8);
      node8.setNormalTr(true);
      nodeRepo.save(node8);

      Node node8Child = new Node();
      node8Child.setRequiresApproval(false);
      node8Child.setName("eightChild");
      node8Child.setParentNode(node8);
      node8Child.setVoltage(28d);
      node8Child.setNominalPower(20d);
      node8Child.setNodeType(NodeType.BUS);
      node8Child.setRequiresApproval(false);
      node8Child.setBusRating(20d);
      node8Child.setVoltageType(ElectricalPhase.DC);
      node8Child.setDisplayOrder(1);
      node8Child.setNormalTr(false);
      nodeRepo.save(node8Child);
    }

    if (ela.getId().equals(elaId4) || ela.getId().equals(elaId5)) {
      // The INVERTER node for B767-300 is required for AutoLandAnalysis
      Node nodeInverter = new Node();
      nodeInverter.setEla(ela);
      nodeInverter.setName("INVERTER");
      nodeInverter.setNodeType(NodeType.INVERTER);
      nodeInverter.setVoltage(24.0d);
      nodeInverter.setSheddable(false);
      nodeInverter.setVoltageType(ElectricalPhase.DC);
      nodeInverter.setNominalPower(1000.0d);
      nodeRepo.save(nodeInverter);
    }

    List<Node> childNodes = new ArrayList<Node>();
    childNodes.add(node3);
    childNodes.add(node4);
    childNodes.add(node7);
    node1.setSubNodes(childNodes);

    // components
    Component component1 = new Component();
    component1.setElectricalPhase(ElectricalPhase.DC);
    component1.setNominalPower(10d);
    component1.setName("component1");
    component1.setDisplayOrder(1);
    component1.setNode(node1);
    component1.setIntermittent(false);
    componentRepo.save(component1);
    List<Component> components1 = new ArrayList<Component>();
    components1.add(component1);
    node1.setComponents(components1);

    Component component2 = new Component();
    component2.setElectricalPhase(ElectricalPhase.AC3);
    component2.setNominalPower(10d);
    component2.setName("component2");
    component2.setDisplayOrder(2);
    component2.setNode(node2);
    component2.setIntermittent(false);
    componentRepo.save(component2);
    List<Component> components2 = new ArrayList<Component>();
    components2.add(component2);
    node2.setComponents(components2);

    Component component3 = new Component();
    component3.setElectricalPhase(ElectricalPhase.AC3);
    component3.setNominalPower(10d);
    component3.setName("component3");
    component3.setDisplayOrder(3);
    component3.setNode(node3);
    component3.setIntermittent(false);
    componentRepo.save(component3);
    List<Component> components3 = new ArrayList<Component>();
    components3.add(component3);
    node3.setComponents(components3);

    Component component4 = new Component();
    component4.setElectricalPhase(ElectricalPhase.AC);
    component4.setNominalPower(10d);
    component4.setName("component4");
    component4.setDisplayOrder(4);
    component4.setNode(node4);
    component4.setIntermittent(false);
    componentRepo.save(component4);
    List<Component> components4 = new ArrayList<Component>();
    components4.add(component4);
    node4.setComponents(components4);

    Component component5 = new Component();
    component5.setElectricalPhase(ElectricalPhase.AC3);
    component5.setNominalPower(10d);
    component5.setName("component5");
    component4.setDisplayOrder(5);
    component5.setNode(node5);
    component5.setSheddable(Boolean.FALSE); // essential load
    component5.setIntermittent(false);
    componentRepo.save(component5);
    List<Component> components5 = new ArrayList<Component>();
    components5.add(component5);
    node5.setComponents(components5);

    // essential loads for node 6
    Component component6 = new Component();
    component6.setElectricalPhase(ElectricalPhase.AC3);
    component6.setNominalPower(10d);
    component6.setName("component6");
    component6.setDisplayOrder(6);
    component6.setNode(node6);
    component6.setSheddable(Boolean.FALSE); // essential load
    component6.setIntermittent(false);
    componentRepo.save(component6);
    List<Component> components6 = new ArrayList<Component>();
    components6.add(component6);
    node6.setComponents(components6);

    // // sheddable loads for node 6
    Component component6sheddable = new Component();
    component6sheddable.setElectricalPhase(ElectricalPhase.AC3);
    component6sheddable.setNominalPower(10d);
    component6sheddable.setName("component6sheddable");
    component6sheddable.setDisplayOrder(7);
    component6sheddable.setNode(node6);
    component6sheddable.setSheddable(Boolean.TRUE); // sheddable load
    component6sheddable.setIntermittent(false);
    componentRepo.save(component6sheddable);
    List<Component> components6sheddable = new ArrayList<Component>();
    components6sheddable.add(component6sheddable);
    node6.setComponents(components6sheddable);

    Component component7 = new Component();
    component7.setElectricalPhase(ElectricalPhase.AC);
    component7.setNominalPower(10d);
    component7.setName("component7");
    component7.setDisplayOrder(8);
    component7.setNode(node7);
    component7.setIntermittent(false);
    componentRepo.save(component7);
    List<Component> components7 = new ArrayList<Component>();
    components7.add(component7);
    node7.setComponents(components7);

    // loads
    Load load1ForNode1 = new Load();
    load1ForNode1.setVa(200d);
    load1ForNode1.setPowerFactor(1d);
    load1ForNode1.setComponent(component1);
    load1ForNode1.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode1.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode1.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode1);

    Load load2ForNode1 = new Load();
    load2ForNode1.setVa(300d);
    load2ForNode1.setPowerFactor(1d);
    load2ForNode1.setComponent(component1);
    load2ForNode1.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode1.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode1.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode1);

    List<Load> loadsNode1 = new ArrayList<Load>();
    loadsNode1.add(load1ForNode1);
    loadsNode1.add(load2ForNode1);
    if (flightPhases.length > 3 && "HMG".equalsIgnoreCase(flightPhases[3])) {
      Load load3ForNode1 = new Load();
      load3ForNode1.setVa(40d);
      load3ForNode1.setPowerFactor(1d);
      load3ForNode1.setComponent(component1);
      load3ForNode1.setFlightPhase(flightPhases[3]);
      if (isBoeing) {
        load3ForNode1.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
        loadRepo.save(load3ForNode1);
        loadsNode1.add(load3ForNode1);
      }
    }
    component1.setLoads(loadsNode1);

    Load load1ForNode2 = new Load();
    load1ForNode2.setVa(50d);
    load1ForNode2.setPowerFactor(1d);
    load1ForNode2.setComponent(component2);
    load1ForNode2.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode2.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode2.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode2);

    Load load2ForNode2 = new Load();
    load2ForNode2.setVa(70d);
    load2ForNode2.setPowerFactor(1d);
    load2ForNode2.setComponent(component2);
    load2ForNode2.setFlightPhase(flightPhases[2]);
    if (isAirbus) {
      load2ForNode2.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode2.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode2);

    List<Load> loadsNode2 = new ArrayList<Load>();
    loadsNode2.add(load1ForNode2);
    loadsNode2.add(load2ForNode2);
    if (flightPhases.length > 3 && "HMG".equalsIgnoreCase(flightPhases[3])) {
      Load load3ForNode2 = new Load();
      load3ForNode2.setVa(200d);
      load3ForNode2.setPowerFactor(0.95d);
      load3ForNode2.setComponent(component2);
      load3ForNode2.setFlightPhase(flightPhases[3]);
      if (isBoeing) {
        load3ForNode2.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
        loadRepo.save(load3ForNode2);
        loadsNode2.add(load3ForNode2);
      }
    }
    component2.setLoads(loadsNode2);

    Load load1ForNode3 = new Load();
    load1ForNode3.setVa(100d);
    load1ForNode3.setPowerFactor(1d);
    load1ForNode3.setComponent(component3);
    load1ForNode3.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode3.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode3.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode3);

    Load load2ForNode3 = new Load();
    load2ForNode3.setVa(120d);
    load2ForNode3.setPowerFactor(1d);
    load2ForNode3.setComponent(component3);
    load2ForNode3.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode3.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode3.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode3);

    List<Load> loadsNode3 = new ArrayList<Load>();
    loadsNode3.add(load1ForNode3);
    loadsNode3.add(load2ForNode3);
    component3.setLoads(loadsNode3);

    Load load1ForNode4 = new Load();
    load1ForNode4.setVa(40d);
    load1ForNode4.setPowerFactor(1d);
    load1ForNode4.setComponent(component4);
    load1ForNode4.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode4.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode4.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode4);

    Load load2ForNode4 = new Load();
    load2ForNode4.setVa(80d);
    load2ForNode4.setPowerFactor(1d);
    load2ForNode4.setComponent(component4);
    load2ForNode4.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode4.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode4.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode4);

    // degraded transformer loads
    Load load3ForNode4 = new Load();
    load3ForNode4.setVa(40d);
    load3ForNode4.setPowerFactor(1d);
    load3ForNode4.setComponent(component4);
    load3ForNode4.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load3ForNode4.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load3ForNode4.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load3ForNode4);

    Load load4ForNode4 = new Load();
    load4ForNode4.setVa(80d);
    load4ForNode4.setPowerFactor(1d);
    load4ForNode4.setComponent(component4);
    load4ForNode4.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load4ForNode4.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load4ForNode4.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load4ForNode4);

    List<Load> loadsNode4 = new ArrayList<Load>();
    loadsNode4.add(load1ForNode4);
    loadsNode4.add(load2ForNode4);
    loadsNode4.add(load3ForNode4);
    loadsNode4.add(load4ForNode4);
    component4.setLoads(loadsNode4);

    // normal generator loads
    Load load1ForNode5 = new Load();
    load1ForNode5.setVa(40d);
    load1ForNode5.setPowerFactor(1d);
    load1ForNode5.setComponent(component5);
    load1ForNode5.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode5.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode5.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode5);

    Load load2ForNode5 = new Load();
    load2ForNode5.setVa(80d);
    load2ForNode5.setPowerFactor(1d);
    load2ForNode5.setComponent(component5);
    load2ForNode5.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode5.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode5.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode5);

    List<Load> loadsNode5 = new ArrayList<Load>();
    loadsNode5.add(load1ForNode5);
    loadsNode5.add(load2ForNode5);
    component5.setLoads(loadsNode5);

    Load load1ForNode6 = new Load();
    load1ForNode6.setVa(30d);
    load1ForNode6.setPowerFactor(1d);
    load1ForNode6.setComponent(component6);
    load1ForNode6.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode6.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load1ForNode6.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load1ForNode6);

    Load load2ForNode6 = new Load();
    load2ForNode6.setVa(70d);
    load2ForNode6.setPowerFactor(1d);
    load2ForNode6.setComponent(component6);
    load2ForNode6.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode6.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    } else if (isBoeing) {
      load2ForNode6.setOperatingMode(ElaAnalysisService.BOEING_NORMAL_CALCULATION);
    }
    loadRepo.save(load2ForNode6);

    List<Load> loadsNode6 = new ArrayList<Load>();
    loadsNode6.add(load1ForNode6);
    loadsNode6.add(load2ForNode6);
    component6.setLoads(loadsNode6);

    // degraded generator loads
    Load load1ForNode5Degraded = new Load();
    load1ForNode5Degraded.setVa(40d);
    load1ForNode5Degraded.setPowerFactor(1d);
    load1ForNode5Degraded.setComponent(component5);
    load1ForNode5Degraded.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode5Degraded.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load1ForNode5Degraded.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load1ForNode5Degraded);

    Load load2ForNode5Degraded = new Load();
    load2ForNode5Degraded.setVa(80d);
    load2ForNode5Degraded.setPowerFactor(1d);
    load2ForNode5Degraded.setComponent(component5);
    load2ForNode5Degraded.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode5Degraded.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load2ForNode5Degraded.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load2ForNode5Degraded);

    List<Load> loadsNode5Degraded = new ArrayList<Load>();
    loadsNode5Degraded.add(load1ForNode5Degraded);
    loadsNode5Degraded.add(load2ForNode5Degraded);
    component5.setLoads(loadsNode5Degraded);

    Load load1ForNode6Degraded = new Load();
    load1ForNode6Degraded.setVa(30d);
    load1ForNode6Degraded.setPowerFactor(1d);
    load1ForNode6Degraded.setComponent(component6);
    load1ForNode6Degraded.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode6Degraded.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load1ForNode6Degraded.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load1ForNode6Degraded);

    Load load2ForNode6Degraded = new Load();
    load2ForNode6Degraded.setVa(70d);
    load2ForNode6Degraded.setPowerFactor(1d);
    load2ForNode6Degraded.setComponent(component6);
    load2ForNode6Degraded.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode6Degraded.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load2ForNode6Degraded.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load2ForNode6Degraded);

    List<Load> loadsNode6Degraded = new ArrayList<Load>();
    loadsNode6Degraded.add(load1ForNode6Degraded);
    loadsNode6Degraded.add(load2ForNode6Degraded);
    component6.setLoads(loadsNode6Degraded);

    Load load1ForNode6SheddableDegraded = new Load();
    load1ForNode6SheddableDegraded.setVa(30d);
    load1ForNode6SheddableDegraded.setPowerFactor(1d);
    load1ForNode6SheddableDegraded.setComponent(component6sheddable);
    load1ForNode6SheddableDegraded.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode6SheddableDegraded.setOperatingMode(
          ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load1ForNode6SheddableDegraded.setOperatingMode(
          ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load1ForNode6SheddableDegraded);

    Load load2ForNode6SheddableDegraded = new Load();
    load2ForNode6SheddableDegraded.setVa(70d);
    load2ForNode6SheddableDegraded.setPowerFactor(1d);
    load2ForNode6SheddableDegraded.setComponent(component6sheddable);
    load2ForNode6SheddableDegraded.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode6SheddableDegraded.setOperatingMode(
          ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load2ForNode6SheddableDegraded.setOperatingMode(
          ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load2ForNode6SheddableDegraded);

    List<Load> loadsNode6SheddableDegraded = new ArrayList<Load>();
    loadsNode6SheddableDegraded.add(load1ForNode6SheddableDegraded);
    loadsNode6SheddableDegraded.add(load2ForNode6SheddableDegraded);
    component6sheddable.setLoads(loadsNode6SheddableDegraded);

    // degraded transformer loads
    Load load1ForNode7 = new Load();
    load1ForNode7.setVa(40d);
    load1ForNode7.setPowerFactor(1d);
    load1ForNode7.setComponent(component7);
    load1ForNode7.setFlightPhase(flightPhases[0]);
    if (isAirbus) {
      load1ForNode7.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load1ForNode7.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load1ForNode7);

    Load load2ForNode7 = new Load();
    load2ForNode7.setVa(80d);
    load2ForNode7.setPowerFactor(1d);
    load2ForNode7.setComponent(component7);
    load2ForNode7.setFlightPhase(flightPhases[1]);
    if (isAirbus) {
      load2ForNode7.setOperatingMode(ElaAnalysisService.AIRBUS_DEGRADED_CALCULATION);
    } else if (isBoeing) {
      load2ForNode7.setOperatingMode(ElaAnalysisService.BOEING_DEGRADED_CALCULATION);
    }
    loadRepo.save(load2ForNode7);

    List<Load> loadsNode7 = new ArrayList<Load>();
    loadsNode7.add(load1ForNode7);
    loadsNode7.add(load2ForNode7);
    component7.setLoads(loadsNode7);

    // TRU efficiency power factor
    EfficiencyTable efficiencyTable = new EfficiencyTable();
    efficiencyTable.setEfficiencyType(EfficiencyType.TRU);
    efficiencyTable.setName("testing");
    List<EfficiencyLoad> efficiencyLoads = new ArrayList<>();
    EfficiencyLoad efficiencyLoadLower = new EfficiencyLoad(10d, 10d, 1d, 40d, 40d);
    EfficiencyLoad efficiencyLoadUpper = new EfficiencyLoad(100d, 100d, 1d, 60d, 60d);
    efficiencyLoads.add(efficiencyLoadLower);
    efficiencyLoads.add(efficiencyLoadUpper);
    efficiencyTable.setLoads(efficiencyLoads);
    efficiencyTableRepo.save(efficiencyTable);
    node4.setEfficiencyTable(efficiencyTable);
    node7.setEfficiencyTable(efficiencyTable);
    nodeRepo.save(node4);
    nodeRepo.save(node7);
  }

  @Test
  public void shouldGetBusNormalAnalysisForELA() {
    try {

      List<AnalysisNode> nodes =
          elaAnalysisService.getAnalysis(elaId1).getNormalAnalysis().getBusNodes();
      assertEquals(5, nodes.size());

      // assert sorting
      AnalysisNode node2 = nodes.get(0);
      assertEquals(node2.getName(), "fourChild");
      AnalysisNode node3 = nodes.get(1);
      assertEquals(node3.getName(), "one");
      AnalysisNode node4 = nodes.get(2);
      assertEquals(node4.getName(), "sevenChild");
      AnalysisNode node5 = nodes.get(3);
      assertEquals(node5.getName(), "three");
      AnalysisNode node6 = nodes.get(4);
      assertEquals(node6.getName(), "two");

      // assert values
      for (AnalysisNode node : nodes) {
        List<AnalysisLoad> loads = node.getAnalysisLoads();
        List<String> flightPhases =
            loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
        List<String> electricalPhases =
            loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
        List<Double> results =
            loads.stream().map(AnalysisLoad::getResult).collect(Collectors.toList());
        if (node.getName().equals("one")) {
          assertEquals(node.getRating(), new Double(300d));
          assertEquals(loads.size(), 10);
          assertThat(
              flightPhases,
              containsInAnyOrder(
                  "roll", "roll", "roll", "roll", "roll", "ground", "ground", "ground", "ground",
                  "ground"));
          assertThat(
              electricalPhases,
              containsInAnyOrder("DC", "AC", "ACA", "ACB", "ACC", "DC", "AC", "ACA", "ACB", "ACC"));
          assertThat(
              results,
              containsInAnyOrder(
                  20.0d,
                  2.666666666666667d,
                  2.666666666666667d,
                  2.666666666666667d,
                  0.08888888888888888d,
                  13.333333333333334d,
                  2.2222222222222223d,
                  2.2222222222222223d,
                  2.2222222222222223d,
                  0.06666666666666668d));
        } else if (node.getName().equals("two")) {
          assertEquals(node.getRating(), new Double(120d));
          assertEquals(loads.size(), 6);
          assertThat(
              flightPhases, containsInAnyOrder("roll", "roll", "roll", "start", "start", "start"));
          assertThat(
              electricalPhases, containsInAnyOrder("ACA", "ACB", "ACC", "ACA", "ACB", "ACC"));
          assertThat(
              results,
              containsInAnyOrder(
                  2.777777777777778d,
                  2.777777777777778d,
                  2.777777777777778d,
                  3.8888888888888884d,
                  3.8888888888888884d,
                  3.8888888888888884d));
        } else if (node.getName().equals("three")) {
          assertEquals(node.getRating(), new Double(100d));
          assertEquals(loads.size(), 6);
          assertThat(
              flightPhases,
              containsInAnyOrder("roll", "roll", "roll", "ground", "ground", "ground"));
          assertThat(
              electricalPhases, containsInAnyOrder("ACA", "ACB", "ACC", "ACA", "ACB", "ACC"));
          assertThat(
              results,
              containsInAnyOrder(
                  8.0d, 8.0d, 8.0d, 6.666666666666667d, 6.666666666666667d, 6.666666666666667d));
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
      fail("see stack trace");
    }
  }

  @Test
  public void shouldGetTruNormalAnalysisForELA() {
    try {

      List<AnalysisNode> nodes =
          elaAnalysisService.getAnalysis(elaId1).getNormalAnalysis().getTruNodes();
      assertEquals(nodes.size(), 2);

      for (AnalysisNode node : nodes) {
        List<AnalysisLoad> loads = node.getAnalysisLoads();
        List<String> flightPhases =
            loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
        List<String> electricalPhases =
            loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
        List<Double> results =
            loads.stream().map(AnalysisLoad::getResult).collect(Collectors.toList());
        if (node.getName().equals("four")) {
          assertEquals(node.getRating(), new Double(20d));
          assertEquals(loads.size(), 2);
          assertThat(flightPhases, containsInAnyOrder("roll", "ground"));
          assertThat(electricalPhases, containsInAnyOrder("AC", "AC"));
          assertThat(results, containsInAnyOrder(14.285714285714285d, 7.142857142857142d));
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
      fail("see stack trace");
    }
  }

  @Test
  public void shouldGetGeneratorNormalAnalysisForELA() {
    try {

      List<AnalysisNode> nodes =
          elaAnalysisService.getAnalysis(elaId1).getNormalAnalysis().getGeneratorNodes();
      assertEquals(nodes.size(), 2);

      for (AnalysisNode node : nodes) {
        List<AnalysisLoad> loads = node.getAnalysisLoads();
        List<String> flightPhases =
            loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
        List<String> electricalPhases =
            loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
        List<Double> values =
            loads.stream().map(AnalysisLoad::getValue).collect(Collectors.toList());
        if (node.getName().equals("five")) {
          assertEquals(node.getRating(), new Double(.1d));
          assertEquals(loads.size(), 10);
          assertThat(
              flightPhases,
              containsInAnyOrder(
                  "roll", "roll", "roll", "roll", "roll", "ground", "ground", "ground", "ground",
                  "ground"));
          assertThat(
              electricalPhases,
              containsInAnyOrder(
                  "ACA",
                  "ACB",
                  "ACC",
                  "ACA",
                  "ACB",
                  "ACC",
                  "TOTAL",
                  "TOTAL",
                  "IMBALANCE",
                  "IMBALANCE"));
          assertThat(
              values,
              containsInAnyOrder(
                  0.026666666666666667d,
                  0.026666666666666667d,
                  0.026666666666666667d,
                  0.08,
                  0.0d,
                  0.013333333333333334d,
                  0.013333333333333334d,
                  0.013333333333333334d,
                  0.04d,
                  0.0d));
        } else if (node.getName().equals("six")) {
          assertEquals(node.getRating(), new Double(.1d));
          assertEquals(loads.size(), 10);
          assertThat(
              flightPhases,
              containsInAnyOrder(
                  "roll", "roll", "roll", "roll", "roll", "ground", "ground", "ground", "ground",
                  "ground"));
          assertThat(
              electricalPhases,
              containsInAnyOrder(
                  "ACA",
                  "ACB",
                  "ACC",
                  "ACA",
                  "ACB",
                  "ACC",
                  "TOTAL",
                  "TOTAL",
                  "IMBALANCE",
                  "IMBALANCE"));
          assertThat(
              values,
              containsInAnyOrder(
                  0.02333333333333333d,
                  0.02333333333333333d,
                  0.02333333333333333d,
                  0.07d,
                  0.0d,
                  0.01d,
                  0.01d,
                  0.01d,
                  0.03d,
                  0.0d));
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
      fail("see stack trace");
    }
  }

  @Test
  public void shouldGetGeneratorDegradedAnalysisForELA() {

    List<AnalysisNode> nodes =
        elaAnalysisService.getAnalysis(elaId1).getDegradedAnalysis().getGeneratorNodes();
    assertEquals(2, nodes.size());

    for (AnalysisNode node : nodes) {
      List<AnalysisLoad> loads = node.getAnalysisLoads();
      List<String> flightPhases =
          loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
      List<String> electricalPhases =
          loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
      List<Double> values = loads.stream().map(AnalysisLoad::getValue).collect(Collectors.toList());
      if (node.getName().equals("five")) {
        assertEquals(new Double(.1d), node.getRating());
        assertEquals(8, loads.size());
        assertThat(
            flightPhases,
            containsInAnyOrder(
                "roll", "roll", "roll", "roll", "ground", "ground", "ground", "ground"));
        assertThat(
            electricalPhases,
            containsInAnyOrder("ACA", "ACB", "ACC", "ACA", "ACB", "ACC", "TOTAL", "TOTAL"));
        assertThat(
            values,
            containsInAnyOrder(
                0.023333333333333334d,
                0.023333333333333334d,
                0.023333333333333334d,
                0.05d,
                0.05d,
                0.05d,
                0.07d,
                0.15000000000000002d));
      } else if (node.getName().equals("six")) {
        assertEquals(new Double(.1d), node.getRating());
        assertEquals(8, loads.size());
        assertThat(
            flightPhases,
            containsInAnyOrder(
                "roll", "roll", "roll", "roll", "ground", "ground", "ground", "ground"));
        assertThat(
            electricalPhases,
            containsInAnyOrder("ACA", "ACB", "ACC", "ACA", "ACB", "ACC", "TOTAL", "TOTAL"));
        assertThat(
            values,
            containsInAnyOrder(
                0.023333333333333334d,
                0.023333333333333334d,
                0.023333333333333334d,
                0.05d,
                0.05d,
                0.05d,
                0.07d,
                0.15000000000000002d));
      }
    }
  }

  @Test
  public void shouldGetTruTransformerDegradedAnalysisForELA() {

    List<AnalysisNode> nodes =
        elaAnalysisService.getAnalysis(elaId1).getDegradedAnalysis().getTruNodes();
    assertEquals(nodes.size(), 2);

    for (AnalysisNode node : nodes) {
      List<AnalysisLoad> loads = node.getAnalysisLoads();
      List<String> flightPhases =
          loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
      List<String> electricalPhases =
          loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
      List<Double> results =
          loads.stream().map(AnalysisLoad::getResult).collect(Collectors.toList());
      if (node.getName().equals("four")) {
        assertEquals(node.getRating(), new Double(20d));
        assertEquals(loads.size(), 2);
        assertThat(flightPhases, containsInAnyOrder("roll", "ground"));
        assertThat(electricalPhases, containsInAnyOrder("TOTAL", "TOTAL"));
        assertThat(results, containsInAnyOrder(14.285714285714285d, 28.57142857142857d));
      } else if (node.getName().equals("seven")) {
        assertEquals(node.getRating(), new Double(20d));
        assertEquals(loads.size(), 2);
        assertThat(flightPhases, containsInAnyOrder("roll", "ground"));
        assertThat(electricalPhases, containsInAnyOrder("TOTAL", "TOTAL"));
        assertThat(results, containsInAnyOrder(14.285714285714285d, 28.57142857142857d));
      }
    }
  }

  @Test
  public void shouldGetTruTransformerDegradedAnalysisForELAWithMoreThanTwoTRUs() {

    List<AnalysisNode> nodes =
        elaAnalysisService.getAnalysis(elaId5).getDegradedAnalysis().getTruNodes();
    assertEquals(nodes.size(), 3);

    for (AnalysisNode node : nodes) {
      List<AnalysisLoad> loads = node.getAnalysisLoads();
      List<String> flightPhases =
          loads.stream().map(AnalysisLoad::getFlightPhase).collect(Collectors.toList());
      List<String> electricalPhases =
          loads.stream().map(AnalysisLoad::getElectricalPhase).collect(Collectors.toList());
      List<Double> results =
          loads.stream().map(AnalysisLoad::getResult).collect(Collectors.toList());
      if (node.getName().equals("four")) {
        assertEquals(node.getRating(), new Double(40d));
        assertEquals(loads.size(), 2);
        assertThat(flightPhases, containsInAnyOrder("CRUISE", "TAKEOFF_CLIMB"));
        assertThat(electricalPhases, containsInAnyOrder("TOTAL", "TOTAL"));
        assertThat(results, containsInAnyOrder(21.428571428571427d, 10.714285714285714d));
      } else if (node.getName().equals("seven")) {
        assertEquals(node.getRating(), new Double(40d));
        assertEquals(loads.size(), 2);
        assertThat(flightPhases, containsInAnyOrder("CRUISE", "TAKEOFF_CLIMB"));
        assertThat(electricalPhases, containsInAnyOrder("TOTAL", "TOTAL"));
        assertThat(results, containsInAnyOrder(21.428571428571427, 10.714285714285714d));
      }
    }
  }

  // test standby analysis for boeing aircraft that has any battery type EXCEPT SINGLE_75AH
  @Test
  public void shouldGetStandbyOperationAnalysisWhenBoeingForELA() {
    StandbyOperation standbyOperation =
        elaAnalysisService.getAnalysis(elaId2).getStandbyOperation();
    assertEquals(new Double(47.6219d), new Double(standbyOperation.getTotalLoadInAmps()), .0001d);
    assertEquals(new Double(30.0d), new Double(standbyOperation.getRequiredBatteryLifeInMinutes()));
    assertEquals(
        new Double(109.56434d),
        new Double(standbyOperation.getActualBatteryLifeInMinutes()),
        .0001d);
    assertEquals(AnalysisStatus.PASS, standbyOperation.getStatus());
    assertEquals(BatteryChargeType.DUAL_40AH, standbyOperation.getBatteryCapacity());
    assertEquals(AnalysisStatus.PASS, standbyOperation.getBatteryStatus());
    assertNull(standbyOperation.getRatCapacity());
    assertNull(standbyOperation.getRatAdjustedCapacity());
    assertNull(standbyOperation.getRatEfficiency());
    assertNull(standbyOperation.getRatLoadInAmps());
    assertNull(standbyOperation.getRatStatus());
  }

  // test standby analysis for boeing aircraft that has a SINGLE_75AH battery
  @Test
  public void shouldGetStandbyOperationAnalysisWhenBoeingAndSINGLE_75BatteryForELA() {
    StandbyOperation standbyOperation =
        elaAnalysisService.getAnalysis(elaId3).getStandbyOperation();
    assertEquals(new Double(47.6219d), new Double(standbyOperation.getTotalLoadInAmps()), .001d);
    assertEquals(new Double(63.495d), new Double(standbyOperation.getPercentAmpsUsed()), .001d);
    assertEquals(new Double(75.0d), new Double(standbyOperation.getMaxBatteryLoad()), .001d);
    assertEquals(AnalysisStatus.PASS, standbyOperation.getStatus());
    assertEquals(BatteryChargeType.SINGLE_75AH, standbyOperation.getBatteryCapacity());
    assertEquals(AnalysisStatus.PASS, standbyOperation.getBatteryStatus());
    assertNull(standbyOperation.getRatCapacity());
    assertNull(standbyOperation.getRatAdjustedCapacity());
    assertNull(standbyOperation.getRatEfficiency());
    assertNull(standbyOperation.getRatLoadInAmps());
    assertNull(standbyOperation.getRatStatus());
  }

  @Test
  public void shouldGetStandbyOperationAnalysisWithRatWhenBoeing777ForELA() {
    StandbyOperation standbyOperation =
        elaAnalysisService.getAnalysis(elaId6).getStandbyOperation();
    assertEquals(new Double(47.3529d), new Double(standbyOperation.getTotalLoadInAmps()), .0001d);
    assertEquals(new Double(30.0d), new Double(standbyOperation.getRequiredBatteryLifeInMinutes()));
    assertEquals(
        new Double(57.2820d), new Double(standbyOperation.getActualBatteryLifeInMinutes()), .0001d);
    assertEquals(AnalysisStatus.PASS, standbyOperation.getStatus());
    assertEquals(BatteryChargeType.SINGLE_47AH, standbyOperation.getBatteryCapacity());
    assertEquals(AnalysisStatus.PASS, standbyOperation.getBatteryStatus());
    assertEquals(216.0d, standbyOperation.getRatCapacity(), 0.0001d);
    assertEquals((216.0d) * (0.85d), standbyOperation.getRatAdjustedCapacity(), 0.0001d);
    assertEquals(0.85d, standbyOperation.getRatEfficiency(), 0.0001d);
    assertEquals(47.3529d, standbyOperation.getRatLoadInAmps(), 0.0001d);
    assertEquals(AnalysisStatus.PASS, standbyOperation.getRatStatus());
  }

  // test static inverter analysis
  @Test
  public void shouldGetStaticAnalysisForBoeing() {
    StaticInverter staticInverter =
        elaAnalysisService
            .getAnalysis(elaId3)
            .getDegradedAnalysis()
            .getStaticInverterAnalysis()
            .get(0);
    assertEquals(staticInverter.getStatus(), AnalysisStatus.PASS);
    assertEquals(1.0, staticInverter.getMaxLoadInKVA(), .001);
    assertEquals(0.150, staticInverter.getTotalLoadInKVA(), .001);
    assertEquals(0.150 / 1.0 * 100.0, staticInverter.getPercentKVAUsed(), .001);
    assertEquals(7.621, staticInverter.getTotalLoadInAmps(), .001);
  }

  // test HMG analysis
  @Test
  public void shouldGetHMGAnalysisForBoeingB767300() {
    HMGAnalysis hmgAnalysis =
        elaAnalysisService.getAnalysis(elaId4).getDegradedAnalysis().getHmgAnalysis().get(0);
    assertEquals(hmgAnalysis.getAcStatus(), AnalysisStatus.PASS);
    assertEquals(hmgAnalysis.getDcStatus(), AnalysisStatus.PASS);
    // AC
    assertEquals(5.0, hmgAnalysis.getAcCapacityKVA(), .001);
    assertEquals(0.20, hmgAnalysis.getAcTotalLoadKVA(), .001);
    assertEquals(0.20 / 5.0 * 100.0, hmgAnalysis.getAcPercentCapacity(), .001);

    assertEquals(0.066, hmgAnalysis.getaPhaseKVA(), .001);
    assertEquals(0.950, hmgAnalysis.getaPhasePf(), .001);
    assertEquals(0.066, hmgAnalysis.getbPhaseKVA(), .001);
    assertEquals(0.950, hmgAnalysis.getbPhasePf(), .001);
    assertEquals(0.066, hmgAnalysis.getcPhaseKVA(), .001);
    assertEquals(0.950, hmgAnalysis.getcPhasePf(), .001);
    assertEquals(0.066, hmgAnalysis.getAvgPhaseKVA(), .001);
    assertEquals(0.950, hmgAnalysis.getAvgPhasePf(), .001);
    // DC
    assertEquals(50.0, hmgAnalysis.getDcCapacityAmps(), .001);
    assertEquals(8.0, hmgAnalysis.getDcTotalLoadAmps(), .001);
    assertEquals(8.0 / 50.0 * 100.0, hmgAnalysis.getDcPercentCapacity(), .001);
  }

  // test fuel jettison analysis
  @Test
  public void shouldGetFuelJettisonAnalysisForB767300() {
    List<FuelJettisonGenerator> fuelInjectionGenerators =
        elaAnalysisService.getAnalysis(elaId4).getDegradedAnalysis().getFuelJettisonGenerators();
    for (FuelJettisonGenerator gen : fuelInjectionGenerators) {
      assertEquals(gen.getGeneratorStatus(), AnalysisStatus.FAIL);
      assertEquals(gen.getWithJettisonStatus(), AnalysisStatus.FAIL);
      assertEquals(gen.getWithoutJettisonStatus(), AnalysisStatus.FAIL);
      for (FuelJettisonLoad load : gen.getFuelJettisonLoads()) {
        if (load.getFlightPhase().equalsIgnoreCase("CRUISE")) {
          assertEquals(load.getLoadWithJettison(), 5.314608, .001);
          assertEquals(load.getLoadWithoutJettison(), 8.16695411, .001);
          assertEquals(load.getPercentageWithJettison(), 5314.608, .001);
          assertEquals(load.getPercentageWithoutJettison(), 8166.9541, .001);
        }
        if (load.getFlightPhase().equalsIgnoreCase("TAKEOFF_CLIMB")) {
          assertEquals(load.getLoadWithJettison(), 5.7437062, .001);
          assertEquals(load.getLoadWithoutJettison(), 8.516667, .001);
          assertEquals(load.getPercentageWithJettison(), 5743.7062, .001);
          assertEquals(load.getPercentageWithoutJettison(), 8516.667, .001);
        }
      }
    }
  }
}
