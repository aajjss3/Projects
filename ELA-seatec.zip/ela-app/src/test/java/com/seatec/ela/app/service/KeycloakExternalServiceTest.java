package com.seatec.ela.app.service;

import static com.seatec.ela.app.service.KeycloakService.DEFAULT_ROLE;
import static com.seatec.ela.app.service.KeycloakService.UMA_PROTECTION_ROLE;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.InternalServerErrorException;
import com.seatec.ela.app.exception.NotAcceptableException;
import com.seatec.ela.app.exception.NotFoundException;
import edu.emory.mathcs.backport.java.util.Collections;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;

public class KeycloakExternalServiceTest {

  private static final String CLIENT_ID = "1";

  private static final String AUTHOR_ROLE_NAME = "author";
  private static final String VIEWER_ROLE_NAME = "viewer";
  private static final String IT_ADMIN_ROLE_NAME = "it_admin";

  private KeycloakExternalService subject;
  private KeycloakRestTemplate mockRestTemplate;

  @Before
  public void setup() {
    mockRestTemplate = mock(KeycloakRestTemplate.class);
    subject = new KeycloakExternalService(mockRestTemplate, "test", "test", "ela", "ela-angular");
  }

  @Test
  public void createUser_without_groups_and_roles_should_return_void_when_API_returns_2xx() {
    // UserRepresentation
    UserRepresentation user = createUser();

    // Groups and Roles
    user.setGroups(null);
    user.setClientRoles(null);
    user.setRealmRoles(null);

    // UserRepresentation[]
    UserRepresentation[] users = new UserRepresentation[] {user};

    // mocks
    mockPostUser(user);
    mockGetRoleCollectionNotFound(user.getId());

    subject.createUser(user);
  }

  @Test
  public void
      createUser_without_groups_and_with_realm_roles_should_return_void_when_API_returns_2xx() {
    // UserRepresentation
    UserRepresentation user = createUser();

    // Remove Groups and Realm Roles
    user.setGroups(null);
    user.setClientRoles(null);
    user.setRealmRoles(Arrays.asList("role1", "role2"));

    // UserRepresentation[]
    UserRepresentation[] users = new UserRepresentation[] {user};

    // RoleRepresentation[]
    RoleRepresentation role1 = createRole("1", "role1");
    RoleRepresentation role2 = createRole("2", "role2");
    RoleRepresentation[] realmRoles = new RoleRepresentation[] {role1, role2};

    // mocks
    mockPostUser(user);
    mockGetAvailableRealmRoleCollection("abc2123-fdsa-cdsa", realmRoles);
    mockPostRole(user.getId(), realmRoles);

    subject.createUser(user);
  }

  @Test
  public void
      createUser_without_groups_and_with_client_roles_should_return_void_when_API_returns_2xx() {
    // UserRepresentation
    UserRepresentation user = createUser();

    // Client Roles
    Map<String, List<String>> clientRoles = new HashMap<>();
    clientRoles.put("ela", Collections.singletonList("user"));
    // clientRoles.put("1", Collections.singletonList("role1"));
    // clientRoles.put("2", Collections.singletonList("role2"));

    // Groups and Roles
    user.setGroups(null);
    user.setClientRoles(clientRoles);
    user.setRealmRoles(null);

    // UserRepresentation[]
    UserRepresentation[] users = new UserRepresentation[] {user};

    // ClientRepresentation[]
    ClientRepresentation client1 = createClient("1", "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};

    // RoleRepresentation[]
    RoleRepresentation clientrole1 = createRole("1", "role1");
    RoleRepresentation clientrole2 = createRole("2", "role2");

    // mocks
    mockPostUser(user);
    mockGetRoleCollectionNotFound(user.getId());
    mockGetClientCollection(clients);
    mockGetAvailableClientRoles("abc2123-fdsa-cdsa", "1", new RoleRepresentation[] {clientrole1});
    mockGetClientRoleCollection(
        "abc2123-fdsa-cdsa", client1.getId(), new RoleRepresentation[] {clientrole1});

    mockPostClientRole(user.getId(), client1.getId(), new RoleRepresentation[] {clientrole1});

    subject.createUser(user);
  }

  @Test
  public void createUser_with_groups_and_no_roles_should_return_void_when_API_returns_2xx() {
    // UserRepresentation
    UserRepresentation user = createUser();

    // Groups and Roles
    user.setGroups(Arrays.asList("group1", "group2"));
    user.setClientRoles(null);
    user.setRealmRoles(null);

    // UserRepresentation[]
    UserRepresentation[] users = new UserRepresentation[] {user};

    // mocks
    mockPostUser(user);
    mockGetRoleCollectionNotFound(user.getId());

    subject.createUser(user);
  }

  @Test(expected = NotAcceptableException.class)
  public void createUser_should_throw_NotAcceptableException_when_API_throws_1xx() {
    UserRepresentation user = createUser();
    mockPostUserException(user, new HttpClientErrorException(HttpStatus.PROCESSING));
    subject.createUser(user);

    fail("NotAcceptableException should have been thrown");
  }

  @Test(expected = BadRequestException.class)
  public void createUser_should_throw_BadRequestException_when_API_throws_409() {
    UserRepresentation user = createUser();
    mockPostUserException(user, new HttpClientErrorException(HttpStatus.CONFLICT));
    subject.createUser(user);

    fail("BadRequestException should have been thrown");
  }

  @Test(expected = InternalServerErrorException.class)
  public void createUser_should_throw_InternalServerErrorException_when_API_throws_500() {
    UserRepresentation user = createUser();
    mockPostUserException(user, new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
    subject.createUser(user);

    fail("InternalServerErrorException should have been thrown");
  }

  @Test
  public void findAllUsers_should_call_keycloakTemplate() {
    List<UserRepresentation> allUsers = Arrays.asList(createUser(), createUser());
    UserRepresentation[] groups = allUsers.toArray(new UserRepresentation[0]);
    ResponseEntity<UserRepresentation[]> response = new ResponseEntity<>(groups, HttpStatus.OK);
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users?briefRepresentation=true&max=500&first=0",
            UserRepresentation[].class))
        .thenReturn(response);
    RoleRepresentation[] roles =
        new RoleRepresentation[] {new RoleRepresentation("viewer", "viewer", false)};
    ResponseEntity<RoleRepresentation[]> rolesResponse = new ResponseEntity<>(roles, HttpStatus.OK);
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + allUsers.get(0).getId() + "/role-mappings/clients/1",
            RoleRepresentation[].class))
        .thenReturn(rolesResponse);

    // ClientRepresentation[]
    ClientRepresentation client1 = createClient("1", "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};

    mockGetClientCollection(clients);

    List<UserRepresentation> result = subject.findAllUsers();
    assertNotNull(result);
    assertEquals(result, allUsers);
  }

  @Test(expected = NullPointerException.class)
  public void findAllUsers_should_throw_null_pointer_if_no_collection_is_returned() {
    ResponseEntity<UserRepresentation[]> response = new ResponseEntity<>(null, HttpStatus.OK);
    when(mockRestTemplate.getForEntity("test/admin/realms/test/users", UserRepresentation[].class))
        .thenReturn(response);
    subject.findAllUsers();

    fail("Exception should have been thrown");
  }

  @Test
  public void findUser_should_return_user_when_user_exists() {
    UserRepresentation user = createUser();
    ResponseEntity<UserRepresentation> response = new ResponseEntity<>(user, HttpStatus.OK);
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + user.getId(), UserRepresentation.class))
        .thenReturn(response);
    RoleRepresentation[] roles =
        new RoleRepresentation[] {new RoleRepresentation("viewer", "viewer", false)};
    ResponseEntity<RoleRepresentation[]> rolesResponse = new ResponseEntity<>(roles, HttpStatus.OK);

    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + user.getId() + "/role-mappings/clients/testid",
            RoleRepresentation[].class))
        .thenReturn(rolesResponse);

    // ClientRepresentation[]
    ClientRepresentation client1 = createClient(CLIENT_ID, "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};

    mockGetClientCollection(clients);

    mockGetUserClientRoles(user.getId(), CLIENT_ID, roles);

    UserRepresentation result = subject.findUser(user.getId());

    assertNotNull(result);
    assertEquals(result, user);
  }

  @Test(expected = NotFoundException.class)
  public void findUser_should_throw_NotFoundException_when_API_throws_404() {
    HttpClientErrorException response = new HttpClientErrorException(HttpStatus.NOT_FOUND);
    String userId = "invalid";

    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + userId, UserRepresentation.class))
        .thenThrow(response);

    subject.findUser(userId);

    fail("NotFoundException should have been thrown");
  }

  @Test(expected = InternalServerErrorException.class)
  public void findUser_should_throw_InternalServerErrorException_when_API_throws_500() {
    HttpClientErrorException response =
        new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    String userId = "invalid";

    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + userId, UserRepresentation.class))
        .thenThrow(response);

    subject.findUser(userId);

    fail("InternalServerErrorException should have been thrown");
  }

  @Test(expected = NotAcceptableException.class)
  public void findUser_should_throw_NotAcceptableException_when_API_throws_1xx() {
    HttpClientErrorException response = new HttpClientErrorException(HttpStatus.PROCESSING);
    String userId = "invalid";

    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + userId, UserRepresentation.class))
        .thenThrow(response);

    subject.findUser(userId);

    fail("NotAcceptableException should have been thrown");
  }

  @Test
  public void updateUser_should_return_void_when_API_returns_2xx() {
    // UserRepresentation
    UserRepresentation user = createUser();

    // Groups and Roles
    user.setGroups(null);
    user.setClientRoles(null);
    user.setRealmRoles(null);

    // mocks
    mockPutUser(user.getId());

    try {
      subject.updateUser(user);
    } finally {
      verify(mockRestTemplate, times(1)).put(isA(String.class), isA(Object.class));
    }
  }

  @Test
  public void findAllRoles_should_call_keycloakTemplate_and_return_role_names() {
    List<RoleRepresentation> allRoles =
        Arrays.asList(createRole("1", "viewer"), createRole("2", "approver"));
    RoleRepresentation[] roles = allRoles.toArray(new RoleRepresentation[0]);
    ResponseEntity<RoleRepresentation[]> response = new ResponseEntity<>(roles, HttpStatus.OK);
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/clients/1/roles", RoleRepresentation[].class))
        .thenReturn(response);
    // ClientRepresentation[]
    ClientRepresentation client1 = createClient("1", "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};
    mockGetClientCollection(clients);

    List<String> result = subject.findAllRoles();
    assertNotNull(result);
    List<RoleRepresentation> sortedRoles =
        Arrays.asList(createRole("2", "approver"), createRole("1", "viewer"));
    for (int i = 0; i < result.size(); i++) {
      assertEquals(result.get(i), sortedRoles.get(i).getName());
    }
  }

  @Test
  public void findAllRoles_should_filter_out_default_roles() {
    List<RoleRepresentation> allRoles =
        Arrays.asList(
            createRole("1", "viewer"),
            createRole("2", DEFAULT_ROLE),
            createRole("2", UMA_PROTECTION_ROLE));

    RoleRepresentation[] roles = allRoles.toArray(new RoleRepresentation[0]);
    ResponseEntity<RoleRepresentation[]> response = new ResponseEntity<>(roles, HttpStatus.OK);
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/clients/1/roles", RoleRepresentation[].class))
        .thenReturn(response);
    // ClientRepresentation[]
    ClientRepresentation client1 = createClient("1", "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};
    mockGetClientCollection(clients);

    List<String> result = subject.findAllRoles();
    assertNotNull(result);
    for (int i = 0; i < result.size(); i++) {
      assertEquals(result.get(i), roles[i].getName());
    }
    assertEquals(result.size(), 1);
  }

  @Test
  public void when_getRoleByName_validRole_then_create_user() {
    // arrange
    ClientRepresentation client1 = createClient(CLIENT_ID, "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};

    RoleRepresentation roleRepresentation = new RoleRepresentation();
    roleRepresentation.setName(VIEWER_ROLE_NAME);

    // mocks
    mockGetClientCollection(clients);
    mockGetRoleByName(VIEWER_ROLE_NAME, roleRepresentation);

    // act
    RoleRepresentation result = subject.getRoleByName(VIEWER_ROLE_NAME);

    // assert
    Assert.assertNotNull(result);
  }

  @Test(expected = NotFoundException.class)
  public void when_getRoleByName_invalidRole_then_throw_NotFoundException() {
    // arrange
    ClientRepresentation client1 = createClient(CLIENT_ID, "ela");
    ClientRepresentation[] clients = new ClientRepresentation[] {client1};

    // mocks
    mockGetClientCollection(clients);
    mockGetRoleByNameException("DUMMY");

    // act
    subject.getRoleByName("DUMMY");
  }

  private ClientRepresentation createClient(String id, String name) {
    ClientRepresentation client = new ClientRepresentation();
    client.setId(id);
    client.setClientId(name);
    client.setName(name);
    client.setEnabled(true);
    client.setDefaultRoles(new String[] {"role1", "role2"});
    return client;
  }

  private RoleRepresentation createRole(String id, String name) {
    RoleRepresentation role = new RoleRepresentation();
    role.setId(id);
    role.setName(name);
    role.setDescription("test");
    role.setClientRole(true);
    return role;
  }

  private UserRepresentation createUser() {
    UserRepresentation user = new UserRepresentation();
    user.setId("1");
    user.setEmail("test@test.com");
    user.setEmailVerified(true);
    user.setFirstName("test");
    user.setLastName("tests");
    user.setEnabled(true);
    user.setRealmRoles(Arrays.asList("test1", "test2"));
    user.setGroups(Arrays.asList("group1", "group2"));
    return user;
  }

  private void mockGetClientCollection(ClientRepresentation[] response) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/clients", ClientRepresentation[].class))
        .thenReturn(new ResponseEntity(response, HttpStatus.OK));
  }

  private void mockGetClientRoleCollection(String id, String clientId, RoleRepresentation[] roles) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/"
                + id
                + "/role-mappings/clients/"
                + clientId
                + "/available",
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity<>(roles, HttpStatus.OK));
  }

  private void mockGetRoleCollectionNotFound(String id) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + id + "/role-mappings/realm/available",
            RoleRepresentation[].class))
        .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
  }

  private void mockGetAvailableRealmRoleCollection(String id, RoleRepresentation[] roles) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + id + "/role-mappings/realm/available",
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity<>(roles, HttpStatus.OK));
  }

  private void mockPostClientRole(String id, String clientId, RoleRepresentation[] response) {
    when(mockRestTemplate.postForEntity(
            "test/admin/realms/test/users/" + id + "/role-mappings/clients/" + clientId,
            RoleRepresentation[].class,
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity(response, HttpStatus.OK));
  }

  private void mockPostRole(String id, RoleRepresentation[] response) {
    when(mockRestTemplate.postForEntity(
            "test/admin/realms/test/users/" + id + "/role-mappings/realm",
            RoleRepresentation[].class,
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity(response, HttpStatus.OK));
  }

  private void mockPostUser(UserRepresentation user) {
    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    headers.put(
        "Location",
        Arrays.asList(
            "http://apps-sandbox.seatec.com/auth/test/admin/realms/test/users/abc2123-fdsa-cdsa"));
    when(mockRestTemplate.postForEntity(
            "test/admin/realms/test/users", user, UserRepresentation.class))
        .thenReturn(new ResponseEntity(user, headers, HttpStatus.CREATED));
  }

  private void mockPostUserException(UserRepresentation user, HttpClientErrorException response) {
    when(mockRestTemplate.postForEntity(
            "test/admin/realms/test/users", user, UserRepresentation.class))
        .thenThrow(response);
  }

  private void mockPutUser(String id) {
    doNothing()
        .when(mockRestTemplate)
        .put("test/admin/realms/test/users/" + id, UserRepresentation.class);
  }

  private void mockGetAvailableClientRoles(
      String userid, String clientId, RoleRepresentation[] roles) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/"
                + userid
                + "/role-mappings/clients/"
                + clientId
                + "/available",
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity(roles, HttpStatus.OK));
  }

  private void mockGetUserClientRoles(String userid, String clientId, RoleRepresentation[] roles) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/users/" + userid + "/role-mappings/clients/" + clientId,
            RoleRepresentation[].class))
        .thenReturn(new ResponseEntity(roles, HttpStatus.OK));
  }

  private void mockGetRoleByName(String roleName, RoleRepresentation role) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/clients/" + CLIENT_ID + "/roles/" + roleName,
            RoleRepresentation.class))
        .thenReturn(new ResponseEntity<>(role, HttpStatus.OK));
  }

  private void mockGetRoleByNameException(String roleName) {
    when(mockRestTemplate.getForEntity(
            "test/admin/realms/test/clients/" + CLIENT_ID + "/roles/" + roleName,
            RoleRepresentation.class))
        .thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
  }
}
