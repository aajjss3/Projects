package com.seatec.ela.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import org.junit.Test;

public class ComponentUtilTest {

  @Test
  public void testIsEssential_sheddable_null() {
    Component component = new Component();
    component.setName("FUEL XFR L PUMP INTERMITTENT");
    component.setSheddable(null);

    assertTrue(
        "When sheddable is null, the component should be essential",
        ComponentUtil.isEssential(component));
  }

  @Test
  public void testIsEssential_sheddable() {
    Component component = new Component();
    component.setName("FUEL XFR L PUMP INTERMITTENT");
    component.setSheddable(true);

    assertFalse(
        "When sheddable is true, the component should NOT be essential",
        ComponentUtil.isEssential(component));
  }

  @Test
  public void testIsEssential_not_sheddable() {
    Component component = new Component();
    component.setName("FUEL XFR L PUMP INTERMITTENT");
    component.setSheddable(false);

    assertTrue(
        "When sheddable is false, the component should be essential",
        ComponentUtil.isEssential(component));
  }

  @Test
  public void testGetConnectedLoadW_connected_load_missing() {
    Component component = new Component();
    component.setConnectedLoadVa(null);
    component.setConnectedLoadPf(null);

    assertEquals(0d, ComponentUtil.getConnectedLoadW(component), 0d);
  }

  @Test
  public void testGetConnectedLoadW_connected_load_present() {
    Component component = new Component();
    component.setId(4510123);
    component.setName("R DME");
    component.setAta("34");
    component.setDisplayOrder(3);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("583");
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(56d);
    component.setConnectedLoadPf(0.8d);

    assertEquals(33.599999999999994d, ComponentUtil.getConnectedLoadVar(component), 0d);
  }

  @Test
  public void testGetConnectedLoadVar_connected_load_missing() {
    Component component = new Component();
    component.setConnectedLoadVa(null);
    component.setConnectedLoadPf(null);

    assertEquals(0d, ComponentUtil.getConnectedLoadVar(component), 0d);
  }

  @Test
  public void testGetConnectedLoadVar_connected_load_present() {
    Component component = new Component();
    component.setId(4510123);
    component.setName("R DME");
    component.setAta("34");
    component.setDisplayOrder(3);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("583");
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(56d);
    component.setConnectedLoadPf(0.8d);

    assertEquals(33.599999999999994d, ComponentUtil.getConnectedLoadVar(component), 0d);
  }

  @Test
  public void testValidateElectricalPhase_valid() {
    ElectricalPhase expectedElectricalPhase = ElectricalPhase.AC3;

    Component component = new Component();
    component.setName("FUEL XFR L PUMP INTERMITTENT");
    component.setElectricalPhase(expectedElectricalPhase);

    ComponentUtil.validateElectricalPhase(expectedElectricalPhase, component);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateElectricalPhase_invalid() {
    ElectricalPhase expectedElectricalPhase = ElectricalPhase.AC3;

    Component component = new Component();
    component.setName("PACK 1 L1 115V AC");
    component.setElectricalPhase(ElectricalPhase.ACA);

    ComponentUtil.validateElectricalPhase(expectedElectricalPhase, component);
  }
}
