package com.seatec.ela.app.validator.constraint;

import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.validator.annotation.ValidateProjectDifferentApprovalChecker;
import java.util.UUID;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ValidateProjectDifferentApprovalCheckerValidatorTest {
  private ValidateProjectDifferentApprovalChecker.Validator subject;

  @Before
  public void before() {
    this.subject = new ValidateProjectDifferentApprovalChecker.Validator();
  }

  @Test
  public void isValid_with_same_approval_and_checker() {
    Project project = new Project();
    String id = UUID.randomUUID().toString();
    // set approval eng to the same as checker eng, should force fail
    project.setApprovalEngineer(id);
    project.setCheckEngineer(id);
    Assert.assertFalse(this.subject.isValid(project, null));
  }

  @Test
  public void isValid_with_different_approval_and_checker() {
    Project project = new Project();
    project.setApprovalEngineer(UUID.randomUUID().toString());
    project.setCheckEngineer(UUID.randomUUID().toString());
    Assert.assertTrue(this.subject.isValid(project, null));
  }

  @Test
  public void isValid_with_null_approval_and_checker() {
    Project project = new Project();
    project.setApprovalEngineer(null);
    project.setCheckEngineer(null);
    Assert.assertTrue(this.subject.isValid(project, null));
  }
}
