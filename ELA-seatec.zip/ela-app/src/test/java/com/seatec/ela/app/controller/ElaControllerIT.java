package com.seatec.ela.app.controller;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;

import com.seatec.ela.app.dto.ElaCreationDto;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/data-node-struct-320.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3001.sql",
        "/datasets/node-3001.sql",
        "/datasets/component-3001.sql",
        "/datasets/load-3001.sql"
      },
      executionPhase = ExecutionPhase.BEFORE_TEST_METHOD),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ElaControllerIT extends AbstractControllerIntegrationTest {

  @Autowired public AircraftRepository aircraftRepo;

  @Autowired public FleetRepository fleetRepo;

  @Autowired public ElaRepository elaRepo;

  @Autowired private NodeRepository nodeRepository;

  @Autowired private ComponentRepository componentRepository;

  @Autowired private LoadRepository loadRepository;

  private String ENDPOINT_URL = BASE_URL + "/service/elas";

  @Test
  public void shouldCreateElaWhenCallingCreateEla() throws Exception {
    Fleet fleet = createFleet(51);
    fleet.setStructureName("A320-Node-Structure");
    fleetRepo.save(fleet);

    Aircraft aircraft = createAircraft(1);
    aircraft.setFleet(fleet);
    aircraftRepo.save(aircraft);

    ElaCreationDto dto = new ElaCreationDto();
    dto.setName("exampleEla");
    dto.setAircraftId(aircraft.getId());

    File file = ResourceUtils.getFile(this.getClass().getResource("/datasets/ela.csv"));
    String fileName = file.getAbsolutePath();
    ResponseEntity<String> response =
        restTemplate.postForEntity(
            ENDPOINT_URL, createHttpEntityForMultipart(dto, fileName), String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // confirm 1HG on 101XP loads values match component nominal power
    Ela newEla = elaRepo.findByAircraftShipNo("1").get(0);
    List<Long> busNodeIds =
        nodeRepository.getNodesInEla(newEla.getId()).stream()
            .filter(x -> x.getName().equals("101XP"))
            .map(Node::getId)
            .collect(Collectors.toList());
    Component newComponent =
        componentRepository.findByNodeIdIn(busNodeIds).stream()
            .filter(x -> x.getElectIdent().equals("1HG"))
            .findFirst()
            .get();
    List<Long> componentIds = new ArrayList<>();
    componentIds.add(newComponent.getId());
    List<Load> newLoads = loadRepository.getLoadsInComponents(componentIds);
    for (Load load : newLoads) {
      assertEquals(newComponent.getNominalPower(), load.getVa());
    }
  }

  @Test
  public void shouldNotCreateElaWhenAlreadyExists() throws Exception {
    ElaCreationDto dto = new ElaCreationDto();
    dto.setName("exampleEla");
    // Using shipno 3001 aircraftId with existing ela
    dto.setAircraftId(1148L);

    File file = ResourceUtils.getFile(this.getClass().getResource("/datasets/ela.csv"));
    String fileName = file.getAbsolutePath();
    ResponseEntity<String> response =
        restTemplate.postForEntity(
            ENDPOINT_URL, createHttpEntityForMultipart(dto, fileName), String.class);
    assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
  }

  @Test
  public void shouldCloneElaWhenCallingCloneEla() throws Exception {
    Fleet fleet = createFleet(51);
    fleet.setStructureName("A320-Node-Structure");
    fleetRepo.save(fleet);

    Aircraft aircraft = createAircraft(1);
    aircraft.setFleet(fleet);
    aircraftRepo.save(aircraft);

    ElaCreationDto dto = new ElaCreationDto();
    dto.setName("exampleCloneEla");
    dto.setAircraftId(aircraft.getId());
    dto.setCloneAircraftId(1148L);

    ResponseEntity<String> response =
        restTemplate.postForEntity(
            ENDPOINT_URL, createHttpEntityForMultipart(dto, null), String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  public void shouldNotCloneElaWhenCallingCloneElaWithCloakedAircraft() throws Exception {
    Fleet fleet = createFleet(51);
    fleet.setStructureName("A320-Node-Structure");
    fleetRepo.save(fleet);

    Aircraft aircraft = createAircraft(1);
    aircraft.setCloaked(true);
    aircraft.setFleet(fleet);
    aircraftRepo.save(aircraft);

    Aircraft cloneAircraft = aircraftRepo.findById(1148L).get();
    cloneAircraft.setCloaked(true);
    aircraftRepo.save(cloneAircraft);

    ElaCreationDto dto = new ElaCreationDto();
    dto.setName("exampleCloneEla");
    dto.setAircraftId(aircraft.getId());
    dto.setCloneAircraftId(1148L);

    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_URL, createHttpEntityForMultipart(dto, null), ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertEquals(
        "No Aircraft Available for clone.", response.getBody().getErrors().get(0).getMessage());
  }

  @Test
  public void shouldGetElaForClonedAircraftWhenItadmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    elaRepo.save(ela);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "?aircraft=" + cloakedAircraft.getAircraftShipNo(),
            HttpMethod.GET,
            createHttpEntity(null),
            String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("\"name\":\"" + elaName + "\""));
  }

  @Test
  public void shouldNotGetElaForClonedAircraftWhenNotItadmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    elaRepo.save(ela);

    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              ENDPOINT_URL + "?aircraft=" + cloakedAircraft.getAircraftShipNo(),
              HttpMethod.GET,
              createHttpEntity(null, user),
              String.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertThat(
          "should not get ela for cloaked aircraft user " + user,
          response.getBody(),
          not(containsString("\"name\":\"" + elaName + "\"")));
    }
  }

  @Test
  public void shouldGetForbiddenWhenGetCloakedNodeAndNotItAdmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    Node node = new Node();
    node.setName("Gen1");
    node.setNodeType(NodeType.GENERATOR);
    ela.addNode(node);
    Ela savedEla = elaRepo.save(ela);
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              ENDPOINT_URL + "/" + savedEla.getId() + "/node/" + savedEla.getNodes().get(0).getId(),
              HttpMethod.GET,
              createHttpEntity(null, user),
              String.class);
      assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
      assertThat(response.getBody(), not(containsString("\"name\":\"" + node.getName() + "\"")));
    }
  }

  @Test
  public void shouldGetResponseWhenGetCloakedNodeAndItAdmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    Node node = new Node();
    node.setName("Gen1");
    node.setNodeType(NodeType.GENERATOR);
    ela.addNode(node);
    Ela savedEla = elaRepo.save(ela);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + savedEla.getId() + "/node/" + savedEla.getNodes().get(0).getId(),
            HttpMethod.GET,
            createHttpEntity(null),
            String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), containsString("\"name\":\"" + node.getName() + "\""));
  }

  @Test
  public void shouldGetForbiddenWhenGetCloakedNodeAnalysesAndNotItAdmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Fleet fleet = createFleet(1);
    fleetRepo.save(fleet);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    Node node = new Node();
    node.setName("Gen1");
    node.setNodeType(NodeType.GENERATOR);
    ela.addNode(node);
    Ela savedEla = elaRepo.save(ela);
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              ENDPOINT_URL + "/" + savedEla.getId() + "/analyses/",
              HttpMethod.GET,
              createHttpEntity(null, user),
              String.class);
      assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
      assertThat(response.getBody(), not(containsString("\"name\":\"" + node.getName() + "\"")));
    }
  }

  @Test
  public void shouldGetResponseWhenGetCloakedNodeAnalysesAndItAdmin() {
    String elaName = "ela110";
    Ela ela = createEla(elaName);
    Fleet fleet = createFleet(1);
    fleetRepo.save(fleet);
    Aircraft cloakedAircraft = createAircraft(110);
    cloakedAircraft.setCloaked(true);
    cloakedAircraft.setFleet(fleet);
    aircraftRepo.save(cloakedAircraft);
    ela.setAircraft(cloakedAircraft);
    Node node = new Node();
    node.setName("Gen1");
    node.setNodeType(NodeType.GENERATOR);
    ela.addNode(node);
    Ela savedEla = elaRepo.save(ela);
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    ResponseEntity<String> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + savedEla.getId() + "/analyses/",
            HttpMethod.GET,
            createHttpEntity(null),
            String.class);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertThat(response.getBody(), not(containsString("\"name\":\"" + node.getName() + "\"")));
  }
}
