package com.seatec.ela.app.util.load;

import com.seatec.ela.app.model.LoadSummaryBucketKey;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.LinkedHashMap;
import java.util.Map;
import org.junit.Test;

public class TruLoadSummaryCalculatorTest {
  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_loadSummaryMap_null() {
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.TRU);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        null, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_summaryType_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.TRU);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, null, loadSummaryOptions, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_loadSummaryOptions_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    SummaryType summaryType = SummaryType.COMPONENTS;

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.TRU);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, null, node, topMostAncestorTransformer);
  }

  @Test(expected = NullPointerException.class)
  public void testCalculateLoadSummaries_node_null() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    SummaryType summaryType = SummaryType.COMPONENTS;

    Node topMostAncestorTransformer = new Node();
    topMostAncestorTransformer.setNodeType(NodeType.TRU);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, null, topMostAncestorTransformer);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCalculateLoadSummaries_node_not_TRU() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.GENERATOR);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, node, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCalculateLoadSummaries_ancestor_transformer_node_not_TRU() {
    Map<LoadSummaryBucketKey, SummarizedLoad> loadSummaryMap = new LinkedHashMap<>();
    SummaryType summaryType = SummaryType.COMPONENTS;

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, true);

    Node node = new Node();
    node.setNodeType(NodeType.BUS);

    Node topMostAncestorTransformer = new Node();
    node.setNodeType(NodeType.GENERATOR);

    TruLoadSummaryCalculator.calculateLoadSummaries(
        loadSummaryMap, summaryType, loadSummaryOptions, node, topMostAncestorTransformer);
  }
}
