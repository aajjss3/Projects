package com.seatec.ela.app.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.email.ProjectChange;
import com.seatec.ela.app.dto.email.ProjectChangeNotification;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.util.enumeration.ProjectStatus;
import edu.emory.mathcs.backport.java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.keycloak.representations.idm.UserRepresentation;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

public class EmailExternalServiceTest {

  @Mock private MailContentBuilder mockMailContentBuilder;

  @Mock private JavaMailSender mockEmailSender;

  @Mock private KeycloakExternalService mockKeycloakExternalService;

  @InjectMocks private EmailExternalService subject = new EmailExternalService();

  private String firstName = "firstName";
  private String lastName = "lastName";
  private String name = firstName + " " + lastName;
  private String email = "joe@joeco.com";
  private String userName = "usernameIsOftenPassword";
  private String tempPassword = "testPassword";
  private String supportEmail = "https://noreplay@seatec.com";
  private String loginURL = "https://app-sandbox.seatec.com";
  private String customerName = "Seatec";

  private String author = "author";
  private String projectNumber = "12345";
  private String projectRevision = "A1";
  private String projectTitle = "Project Title";

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    when(mockMailContentBuilder.buildLoginSubject(eq(customerName))).thenReturn("subject");
    when(mockMailContentBuilder.buildLoginText(
            eq(name),
            eq(userName),
            eq(tempPassword),
            eq(supportEmail),
            anyString(),
            eq(customerName)))
        .thenReturn("body");
    doAnswer(
            new Answer<Void>() {
              @Override
              public Void answer(InvocationOnMock invocation) throws Throwable {
                return null;
              }
            })
        .when(mockEmailSender)
        .send(any(SimpleMailMessage.class));
    ReflectionTestUtils.setField(subject, "supportEmail", supportEmail);
    ReflectionTestUtils.setField(subject, "loginUrl", loginURL);
  }

  @Test
  public void sendUserLoginEmail_should_send_email_when_enabled() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    subject.sendUserLoginEmail(user, tempPassword);
    verify(mockMailContentBuilder).buildLoginSubject(eq(customerName));
    verify(mockMailContentBuilder)
        .buildLoginText(
            anyString(),
            eq(userName),
            eq(tempPassword),
            anyString(),
            anyString(),
            eq(customerName));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendUserLoginEmail_should_not_send_email_when_disabled() {
    ReflectionTestUtils.setField(subject, "enableEmail", false);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    subject.sendUserLoginEmail(user, tempPassword);
    verify(mockMailContentBuilder).buildLoginSubject(eq(customerName));
    verify(mockMailContentBuilder)
        .buildLoginText(
            anyString(),
            eq(userName),
            eq(tempPassword),
            anyString(),
            anyString(),
            eq(customerName));
    verify(mockEmailSender, never()).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendUserLoginEmail_should_swallow_and_log_when_send_email_exception() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    doThrow(MailSendException.class).when(mockEmailSender).send(any(SimpleMailMessage.class));
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    subject.sendUserLoginEmail(user, tempPassword);
    verify(mockMailContentBuilder).buildLoginSubject(eq(customerName));
    verify(mockMailContentBuilder)
        .buildLoginText(
            anyString(),
            eq(userName),
            eq(tempPassword),
            anyString(),
            anyString(),
            eq(customerName));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendProjectUpdateEmail_should_send_approval_email_when_enabled() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    ReflectionTestUtils.setField(subject, "emailBlacklist", ".*@noemail.com");
    ReflectionTestUtils.setField(subject, "emailWhitelist", ".*");
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    when(mockKeycloakExternalService.findUser(eq(author))).thenReturn(user);
    Project project = new Project();
    project.setAuthor(author);
    project.setNumber(projectNumber);
    project.setRevisionLevel(projectRevision);
    project.setTitle(projectTitle);
    subject.sendProjectUpdateEmail(project, ProjectStatus.APPROVED);
    verify(mockMailContentBuilder)
        .buildProjectSubject(
            eq(customerName), eq(projectNumber), eq(projectRevision), eq(projectTitle));
    verify(mockMailContentBuilder)
        .buildProjectApprovalText(
            anyString(),
            eq(loginURL),
            eq(supportEmail),
            eq(customerName),
            eq(projectNumber),
            eq(projectRevision),
            eq(projectTitle));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendProjectUpdateEmail_should_send_notification_email_when_enabled() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    ReflectionTestUtils.setField(subject, "emailBlacklist", ".*@noemail.com");
    ReflectionTestUtils.setField(subject, "emailWhitelist", ".*");
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    when(mockKeycloakExternalService.findUser(eq(author))).thenReturn(user);
    Project project = new Project();
    project.setAuthor(author);
    project.setNumber(projectNumber);
    project.setRevisionLevel(projectRevision);
    project.setTitle(projectTitle);
    subject.sendProjectUpdateEmail(project, ProjectStatus.CHECKED);
    verify(mockMailContentBuilder)
        .buildProjectSubject(
            eq(customerName), eq(projectNumber), eq(projectRevision), eq(projectTitle));
    verify(mockMailContentBuilder)
        .buildProjectNotificationText(
            anyString(),
            eq(loginURL),
            eq(supportEmail),
            eq(customerName),
            eq(projectNumber),
            eq(projectRevision),
            eq(projectTitle));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendProjectUpdateEmail_should_should_not_send_email_when_disabled() {
    ReflectionTestUtils.setField(subject, "enableEmail", false);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    ReflectionTestUtils.setField(subject, "emailBlacklist", ".*@noemail.com");
    ReflectionTestUtils.setField(subject, "emailWhitelist", ".*");
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    when(mockKeycloakExternalService.findUser(eq(author))).thenReturn(user);
    Project project = new Project();
    project.setAuthor(author);
    project.setNumber(projectNumber);
    project.setRevisionLevel(projectRevision);
    project.setTitle(projectTitle);
    subject.sendProjectUpdateEmail(project, ProjectStatus.CHECKED);
    verify(mockMailContentBuilder)
        .buildProjectSubject(
            eq(customerName), eq(projectNumber), eq(projectRevision), eq(projectTitle));
    verify(mockMailContentBuilder)
        .buildProjectNotificationText(
            anyString(),
            eq(loginURL),
            eq(supportEmail),
            eq(customerName),
            eq(projectNumber),
            eq(projectRevision),
            eq(projectTitle));
    verify(mockEmailSender, never()).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendProjectUpdateEmail_should_swallow_and_log_when_send_email_exception() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    ReflectionTestUtils.setField(subject, "emailBlacklist", ".*@noemail.com");
    ReflectionTestUtils.setField(subject, "emailWhitelist", ".*");
    doThrow(MailSendException.class).when(mockEmailSender).send(any(SimpleMailMessage.class));
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);
    when(mockKeycloakExternalService.findUser(eq(author))).thenReturn(user);
    Project project = new Project();
    project.setAuthor(author);
    project.setNumber(projectNumber);
    project.setRevisionLevel(projectRevision);
    project.setTitle(projectTitle);
    subject.sendProjectUpdateEmail(project, ProjectStatus.CHECKED);
    verify(mockMailContentBuilder)
        .buildProjectSubject(
            eq(customerName), eq(projectNumber), eq(projectRevision), eq(projectTitle));
    verify(mockMailContentBuilder)
        .buildProjectNotificationText(
            anyString(),
            eq(loginURL),
            eq(supportEmail),
            eq(customerName),
            eq(projectNumber),
            eq(projectRevision),
            eq(projectTitle));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  @Test
  public void sendProjectChangeNotificationEmail_should_send_notification_email() {
    ReflectionTestUtils.setField(subject, "enableEmail", true);
    ReflectionTestUtils.setField(subject, "customerName", customerName);
    ReflectionTestUtils.setField(subject, "emailBlacklist", ".*@noemail.com");
    ReflectionTestUtils.setField(subject, "emailWhitelist", ".*");

    // create user
    UserRepresentation user = new UserRepresentation();
    user.setFirstName(firstName);
    user.setLastName(lastName);
    user.setUsername(userName);
    user.setEmail(email);

    // create project change notifications
    List<ProjectChangeNotification> projectChangeNotifications =
        mockProjectChangeNotifications(1, 2, 3);

    when(mockKeycloakExternalService.findUser(any(String.class))).thenReturn(user);

    // act
    subject.sendProjectChangeNotifications(projectChangeNotifications);

    String projectNumber = projectChangeNotifications.get(0).getProjectNumber();
    String projectRevision = projectChangeNotifications.get(0).getProjectRevision();
    String projectTitle = projectChangeNotifications.get(0).getProjectTitle();

    // assert
    verify(mockMailContentBuilder)
        .buildProjectChangeSubject(
            eq(customerName), eq(projectNumber), eq(projectRevision), eq(projectTitle));
    verify(mockMailContentBuilder)
        .buildProjectChangeNotificationText(
            eq(loginURL),
            eq(supportEmail),
            eq(customerName),
            eq(projectChangeNotifications.get(0).getProjectChanges()));
    verify(mockEmailSender).send(any(SimpleMailMessage.class));
  }

  private List<ProjectChangeNotification> mockProjectChangeNotifications(
      int numberOfProjects, int numberOfChangeGroups, int numberOfChanges) {
    List<ProjectChangeNotification> projectChangeNotifications = new ArrayList<>();

    for (int i = 0; i < numberOfProjects; i++) {
      ProjectChangeNotification pcn =
          new ProjectChangeNotification(
              RandomStringUtils.random(10, true, false),
              RandomStringUtils.random(5, true, false),
              RandomStringUtils.random(9, true, false),
              Collections.singletonList(author));

      List<ProjectChange> projectChanges = new ArrayList<>();

      for (int x = 0; x < numberOfChangeGroups; x++) {
        ProjectChange projectChange = new ProjectChange();
        String changeGroupName = RandomStringUtils.random(10, true, false);
        projectChange.setChangeGroupName(changeGroupName);

        List<String> conflictingChanges = new ArrayList<>();
        for (int y = 0; y < numberOfChanges; y++) {
          String changePhrase = RandomStringUtils.random(25, true, false);
          conflictingChanges.add(changePhrase);
        }

        projectChange.setConflictingChanges(conflictingChanges);
        projectChanges.add(projectChange);
      }

      pcn.setProjectChanges(projectChanges);
      projectChangeNotifications.add(pcn);
    }

    return projectChangeNotifications;
  }
}
