package com.seatec.ela.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import com.seatec.ela.app.config.ClientConfig.Boeing;
import com.seatec.ela.app.dto.AutoLandFleetConfigDto;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysis;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysisNode;
import com.seatec.ela.app.dto.analysis.AutoLandCondition;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;

public class AutoLandAnalysisServiceTest {

  private AutoLandAnalysisService autoLandAnalysisService;

  @Before
  public void setUp() {
    autoLandAnalysisService = new AutoLandAnalysisService();
  }

  @Test
  public void testCalculate_A321_200() {
    Ela ela = createEla_A321_200();

    List<Node> nodes = new ArrayList<>();

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNull(
        "AutoLandCondition should be NULL for fleets other than B757 or B767", autoLandCondition);
  }

  private Ela createEla_A321_200() {
    Fleet fleet = new Fleet();
    fleet.setId(817L);
    fleet.setName("A321-200");
    fleet.setManufacturer("Airbus");
    fleet.setEtops(false);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1148L);
    aircraft.setAircraftShipNo("3001");
    aircraft.setBatteryCharge(BatteryChargeType.SINGLE_47AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(10867L);
    ela.setAircraft(aircraft);

    return ela;
  }

  @Test
  public void testCalculate_B757_200() {

    Ela ela = createEla_B757_200();

    // AutoLand nodes are HB06, BB1S, DSBY, DCAL
    Node nodeHB06 = createNode_HB06_B757_200();
    Node nodeBB1S = createNode_BB1S_B757_200();
    Node nodeDSBY = createNode_DSBY_B757_200();
    Node nodeDCAL = createNode_DCAL_B757_200();

    // AutoLand nodes for the INVERTER are ACAL, STYS
    Node nodeInverter = createNode_INVERTER_B757_200();
    Node nodeACAL = createNode_ACAL_B757_200();
    Node nodeSTYS = createNode_STYS_B757_200();

    List<Node> nodes =
        Arrays.asList(nodeHB06, nodeBB1S, nodeDSBY, nodeDCAL, nodeInverter, nodeACAL, nodeSTYS);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNotNull("AutoLandCondition should be calculated for B757-200", autoLandCondition);

    BatteryChargeType batteryChargeType = ela.getAircraft().getBatteryCharge();

    assertEquals(batteryChargeType, autoLandCondition.getBatteryCapacity());

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();
    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    List<AutoLandAnalysisNode> listNodesBatteryCharger = analysisBatteryCharger.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        listNodesBatteryCharger.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));
    // All these BatteryCharger nodes should be present
    AutoLandAnalysisNode nodeBatteryChargerHB06 = mapNodesBatteryCharger.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerHB06);

    AutoLandAnalysisNode nodeBatteryChargerBB1S = mapNodesBatteryCharger.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerBB1S);

    AutoLandAnalysisNode nodeBatteryChargerDSBY = mapNodesBatteryCharger.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDSBY);

    AutoLandAnalysisNode nodeBatteryChargerDCAL = mapNodesBatteryCharger.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDCAL);

    AutoLandAnalysisNode nodeBatteryChargerINVERTER = mapNodesBatteryCharger.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryCharger
    Double sumBatteryCharger =
        listNodesBatteryCharger.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryCharger.getTotalLoadInAmpsSummary(), sumBatteryCharger);

    List<AutoLandAnalysisNode> listNodesBatteryOnly = analysisBatteryOnly.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        listNodesBatteryOnly.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));

    // All these BatteryOnly nodes should be present
    AutoLandAnalysisNode nodeBatteryOnlyHB06 = mapNodesBatteryOnly.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyHB06);

    AutoLandAnalysisNode nodeBatteryOnlyBB1S = mapNodesBatteryOnly.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyBB1S);

    AutoLandAnalysisNode nodeBatteryOnlyDSBY = mapNodesBatteryOnly.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDSBY);

    AutoLandAnalysisNode nodeBatteryOnlyDCAL = mapNodesBatteryOnly.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDCAL);

    AutoLandAnalysisNode nodeBatteryOnlyINVERTER = mapNodesBatteryOnly.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryOnly
    Double sumBatteryOnly =
        listNodesBatteryOnly.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryOnly.getTotalLoadInAmpsSummary(), sumBatteryOnly);

    // All the non-INVERTER nodes should have the same totalLoadInAmps
    // for both BatteryCharger and BatteryOnly
    assertEquals(
        nodeBatteryChargerHB06.getTotalLoadInAmps(), nodeBatteryOnlyHB06.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerBB1S.getTotalLoadInAmps(), nodeBatteryOnlyBB1S.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDSBY.getTotalLoadInAmps(), nodeBatteryOnlyDSBY.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDCAL.getTotalLoadInAmps(), nodeBatteryOnlyDCAL.getTotalLoadInAmps());
  }

  private Ela createEla_B757_200() {
    Fleet fleet = new Fleet();
    fleet.setId(40L);
    fleet.setName("B757-200");
    fleet.setManufacturer("Boeing");
    fleet.setEtops(false);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1578L);
    aircraft.setAircraftShipNo("5650");
    aircraft.setBatteryCharge(BatteryChargeType.SINGLE_40AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(23535L);
    ela.setAircraft(aircraft);

    return ela;
  }

  private Node createNode_HB06_B757_200() {
    Node node = new Node();
    node.setId(1484464L);
    node.setName("HB06");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    SummarizedLoad summarizedLoad =
        new SummarizedLoad(
            Boeing.HOLD_LAND.toString(),
            OperatingMode.Boeing.LOAD.toString(),
            node.getElectricalPhase(),
            SummaryType.COMPONENTS_AND_CHILDREN);

    List<SummarizedLoad> summarizedLoads = new ArrayList<>();
    summarizedLoads.add(summarizedLoad);

    node.setSummarizedLoads(summarizedLoads);

    return node;
  }

  private Node createNode_BB1S_B757_200() {
    Node node = new Node();
    node.setId(1484424L);
    node.setName("BB1S");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13115119L);
    component.setName("ALT STAB TRIM");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1010");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DSBY_B757_200() {
    Node node = new Node();
    node.setId(1484425L);
    node.setName("DSBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13115186L);
    component.setName("STAB TRIM CONT L");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1017");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DCAL_B757_200() {
    Node node = new Node();
    node.setId(1484427L);
    node.setName("DCAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13115213L);
    component.setName("FLT CONT CMPT SERVO C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("524");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(64.4d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(64.4d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_INVERTER_B757_200() {
    Node node = new Node();
    node.setId(1484468L);
    node.setName("INVERTER");
    node.setNodeType(NodeType.INVERTER);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setNominalPower(1000.0d);

    return node;
  }

  private Node createNode_ACAL_B757_200() {
    Node node = new Node();
    node.setId(1484413L);
    node.setName("ACAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACB);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13115057L);
    component.setName("FLT CONT CMPTR PWR C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("515");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACB);
    component.setIntermittent(false);
    component.setConnectedLoadVa(115.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(115.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_STYS_B757_200() {
    Node node = new Node();
    node.setId(1484416L);
    node.setName("STYS");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACA);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13115067L);
    component.setName("WARN ELEX B");
    component.setAta("31");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("566");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(30.0d);
    component.setConnectedLoadPf(0.92);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(30.0d);
    load.setPowerFactor(0.92d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  @Test
  public void testCalculate_B757_200ETOPS() {
    Ela ela = createEla_B757_200ETOPS();

    // AutoLand nodes are HB06, BB1S, DSBY, DCAL
    Node nodeHB06 = createNode_HB06_B757_200ETOPS();
    Node nodeBB1S = createNode_BB1S_B757_200ETOPS();
    Node nodeDSBY = createNode_DSBY_B757_200ETOPS();
    Node nodeDCAL = createNode_DCAL_B757_200ETOPS();

    // AutoLand nodes for the INVERTER are ACAL, STYS
    Node nodeInverter = createNode_INVERTER_B757_200ETOPS();
    Node nodeACAL = createNode_ACAL_B757_200ETOPS();
    Node nodeSTYS = createNode_STYS_B757_200ETOPS();

    List<Node> nodes =
        Arrays.asList(nodeHB06, nodeBB1S, nodeDSBY, nodeDCAL, nodeInverter, nodeACAL, nodeSTYS);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNotNull("AutoLandCondition should be calculated for B757-200ETOPS", autoLandCondition);

    BatteryChargeType batteryChargeType = ela.getAircraft().getBatteryCharge();

    assertEquals(batteryChargeType, autoLandCondition.getBatteryCapacity());

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();
    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    List<AutoLandAnalysisNode> listNodesBatteryCharger = analysisBatteryCharger.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        listNodesBatteryCharger.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));
    // All these BatteryCharger nodes should be present
    AutoLandAnalysisNode nodeBatteryChargerHB06 = mapNodesBatteryCharger.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerHB06);

    AutoLandAnalysisNode nodeBatteryChargerBB1S = mapNodesBatteryCharger.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerBB1S);

    AutoLandAnalysisNode nodeBatteryChargerDSBY = mapNodesBatteryCharger.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDSBY);

    AutoLandAnalysisNode nodeBatteryChargerDCAL = mapNodesBatteryCharger.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDCAL);

    AutoLandAnalysisNode nodeBatteryChargerINVERTER = mapNodesBatteryCharger.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryCharger
    Double sumBatteryCharger =
        listNodesBatteryCharger.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryCharger.getTotalLoadInAmpsSummary(), sumBatteryCharger);

    List<AutoLandAnalysisNode> listNodesBatteryOnly = analysisBatteryOnly.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        listNodesBatteryOnly.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));

    // All these BatteryOnly nodes should be present
    AutoLandAnalysisNode nodeBatteryOnlyHB06 = mapNodesBatteryOnly.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyHB06);

    AutoLandAnalysisNode nodeBatteryOnlyBB1S = mapNodesBatteryOnly.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyBB1S);

    AutoLandAnalysisNode nodeBatteryOnlyDSBY = mapNodesBatteryOnly.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDSBY);

    AutoLandAnalysisNode nodeBatteryOnlyDCAL = mapNodesBatteryOnly.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDCAL);

    AutoLandAnalysisNode nodeBatteryOnlyINVERTER = mapNodesBatteryOnly.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryOnly
    Double sumBatteryOnly =
        listNodesBatteryOnly.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryOnly.getTotalLoadInAmpsSummary(), sumBatteryOnly);

    // All the non-INVERTER nodes should have the same totalLoadInAmps
    // for both BatteryCharger and BatteryOnly
    assertEquals(
        nodeBatteryChargerHB06.getTotalLoadInAmps(), nodeBatteryOnlyHB06.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerBB1S.getTotalLoadInAmps(), nodeBatteryOnlyBB1S.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDSBY.getTotalLoadInAmps(), nodeBatteryOnlyDSBY.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDCAL.getTotalLoadInAmps(), nodeBatteryOnlyDCAL.getTotalLoadInAmps());
  }

  private Ela createEla_B757_200ETOPS() {
    Fleet fleet = new Fleet();
    fleet.setId(952L);
    fleet.setName("B757-200ETOPS");
    fleet.setManufacturer("Boeing");
    fleet.setEtops(true);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1563L);
    aircraft.setAircraftShipNo("5635");
    aircraft.setBatteryCharge(BatteryChargeType.SINGLE_40AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(23520L);
    ela.setAircraft(aircraft);

    return ela;
  }

  private Node createNode_HB06_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1484464L);
    node.setName("HB06");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    SummarizedLoad summarizedLoad =
        new SummarizedLoad(
            Boeing.HOLD_LAND.toString(),
            OperatingMode.Boeing.LOAD.toString(),
            node.getElectricalPhase(),
            SummaryType.COMPONENTS_AND_CHILDREN,
            13.999999999999998d,
            0.0d);

    List<SummarizedLoad> summarizedLoads = new ArrayList<>();
    summarizedLoads.add(summarizedLoad);

    node.setSummarizedLoads(summarizedLoads);

    return node;
  }

  private Node createNode_BB1S_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483494L);
    node.setName("BB1S");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13106089L);
    component.setName("STAB TRIM ALTN");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1010");
    component.setPanel("");
    component.setNominalPower(null);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DSBY_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483495L);
    node.setName("DSBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13106168L);
    component.setName("STAB TRIM CONT L");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1017");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DCAL_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483497L);
    node.setName("DCAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13106204L);
    component.setName("FLT CONT CMPT SERVO C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("524");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(64.4d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(64.4d);
    load.setPowerFactor(1.0d);

    node.addComponent(component);
    component.addLoad(load);

    return node;
  }

  private Node createNode_INVERTER_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483538L);
    node.setName("INVERTER");
    node.setNodeType(NodeType.INVERTER);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setNominalPower(1000.0d);

    return node;
  }

  private Node createNode_ACAL_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483483L);
    node.setName("ACAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACB);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13106007L);
    component.setName("FLT CONT CMPTR PWR-C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("515");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACB);
    component.setIntermittent(false);
    component.setConnectedLoadVa(115.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(115.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_STYS_B757_200ETOPS() {
    Node node = new Node();
    node.setId(1483486L);
    node.setName("STYS");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACA);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(1310604L);
    component.setName("WARN ELEX B");
    component.setAta("31");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("566");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(30.0d);
    component.setConnectedLoadPf(0.92);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(30.0d);
    load.setPowerFactor(0.92d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  @Test
  public void testCalculate_B757_300() {
    Ela ela = createEla_B757_300();

    // AutoLand nodes are HB06, BB1S, DSBY, DCAL
    Node nodeHB06 = createNode_HB06_B757_300();
    Node nodeBB1S = createNode_BB1S_B757_300();
    Node nodeDSBY = createNode_DSBY_B757_300();
    Node nodeDCAL = createNode_DCAL_B757_300();

    // AutoLand nodes for the INVERTER are ACAL, STYS
    Node nodeInverter = createNode_INVERTER_B757_300();
    Node nodeACAL = createNode_ACAL_B757_300();
    Node nodeSTYS = createNode_STYS_B757_300();

    List<Node> nodes =
        Arrays.asList(nodeHB06, nodeBB1S, nodeDSBY, nodeDCAL, nodeInverter, nodeACAL, nodeSTYS);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNotNull("AutoLandCondition should be calculated for B757-300", autoLandCondition);

    BatteryChargeType batteryChargeType = ela.getAircraft().getBatteryCharge();

    assertEquals(batteryChargeType, autoLandCondition.getBatteryCapacity());

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();
    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    List<AutoLandAnalysisNode> listNodesBatteryCharger = analysisBatteryCharger.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        listNodesBatteryCharger.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));
    // All these BatteryCharger nodes should be present
    AutoLandAnalysisNode nodeBatteryChargerHB06 = mapNodesBatteryCharger.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerHB06);

    AutoLandAnalysisNode nodeBatteryChargerBB1S = mapNodesBatteryCharger.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerBB1S);

    AutoLandAnalysisNode nodeBatteryChargerDSBY = mapNodesBatteryCharger.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDSBY);

    AutoLandAnalysisNode nodeBatteryChargerDCAL = mapNodesBatteryCharger.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDCAL);

    AutoLandAnalysisNode nodeBatteryChargerINVERTER = mapNodesBatteryCharger.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryCharger
    Double sumBatteryCharger =
        listNodesBatteryCharger.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryCharger.getTotalLoadInAmpsSummary(), sumBatteryCharger);

    List<AutoLandAnalysisNode> listNodesBatteryOnly = analysisBatteryOnly.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        listNodesBatteryOnly.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));

    // All these BatteryOnly nodes should be present
    AutoLandAnalysisNode nodeBatteryOnlyHB06 = mapNodesBatteryOnly.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyHB06);

    AutoLandAnalysisNode nodeBatteryOnlyBB1S = mapNodesBatteryOnly.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyBB1S);

    AutoLandAnalysisNode nodeBatteryOnlyDSBY = mapNodesBatteryOnly.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDSBY);

    AutoLandAnalysisNode nodeBatteryOnlyDCAL = mapNodesBatteryOnly.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDCAL);

    AutoLandAnalysisNode nodeBatteryOnlyINVERTER = mapNodesBatteryOnly.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryOnly
    Double sumBatteryOnly =
        listNodesBatteryOnly.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryOnly.getTotalLoadInAmpsSummary(), sumBatteryOnly);

    // All the non-INVERTER nodes should have the same totalLoadInAmps
    // for both BatteryCharger and BatteryOnly
    assertEquals(
        nodeBatteryChargerHB06.getTotalLoadInAmps(), nodeBatteryOnlyHB06.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerBB1S.getTotalLoadInAmps(), nodeBatteryOnlyBB1S.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDSBY.getTotalLoadInAmps(), nodeBatteryOnlyDSBY.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDCAL.getTotalLoadInAmps(), nodeBatteryOnlyDCAL.getTotalLoadInAmps());
  }

  private Ela createEla_B757_300() {
    Fleet fleet = new Fleet();
    fleet.setId(61L);
    fleet.setName("B757-300");
    fleet.setManufacturer("Boeing");
    fleet.setEtops(true);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1586L);
    aircraft.setAircraftShipNo("5801");
    aircraft.setBatteryCharge(BatteryChargeType.DUAL_48AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(23308L);
    ela.setAircraft(aircraft);

    return ela;
  }

  private Node createNode_HB06_B757_300() {
    Node node = new Node();
    node.setId(1469548L);
    node.setName("HB06");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    SummarizedLoad summarizedLoad =
        new SummarizedLoad(
            Boeing.HOLD_LAND.toString(),
            OperatingMode.Boeing.LOAD.toString(),
            node.getElectricalPhase(),
            SummaryType.COMPONENTS_AND_CHILDREN,
            1.54d,
            0.0d);

    List<SummarizedLoad> summarizedLoads = new ArrayList<>();
    summarizedLoads.add(summarizedLoad);

    node.setSummarizedLoads(summarizedLoads);

    return node;
  }

  private Node createNode_BB1S_B757_300() {
    Node node = new Node();
    node.setId(1469508L);
    node.setName("BB1S");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12950057L);
    component.setName("ALTN STAB TRIM ");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1010");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DSBY_B757_300() {
    Node node = new Node();
    node.setId(1469509L);
    node.setName("DSBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12950136L);
    component.setName("STAB TRIM CONT L");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1017");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(67.2d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(67.2d);
    load.setPowerFactor(1.0d);

    return node;
  }

  private Node createNode_DCAL_B757_300() {
    Node node = new Node();
    node.setId(1469511L);
    node.setName("DCAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12950171L);
    component.setName("FLT CONT CMPT SERVO C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("524");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(64.4d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(64.4d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_INVERTER_B757_300() {
    Node node = new Node();
    node.setId(1469552L);
    node.setName("INVERTER");
    node.setNodeType(NodeType.INVERTER);
    node.setVoltage(24.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setNominalPower(1000.0d);

    return node;
  }

  private Node createNode_ACAL_B757_300() {
    Node node = new Node();
    node.setId(1469497L);
    node.setName("ACAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACB);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12949973L);
    component.setName("FLT CONT CMPTR PWR C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("515");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACB);
    component.setIntermittent(false);
    component.setConnectedLoadVa(115.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(115.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_STYS_B757_300() {
    Node node = new Node();
    node.setId(1469500L);
    node.setName("STYS");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACA);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12949999L);
    component.setName("WARN ELEX B");
    component.setAta("31");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("566");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(30.0d);
    component.setConnectedLoadPf(0.92d);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(30.0d);
    load.setPowerFactor(0.92d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  @Test
  public void testCalculate_B767_300() {
    Ela ela = createEla_B767_300();

    // AutoLand nodes are HB06, BB1S, DSBY, DCAL
    Node nodeHB06 = createNode_HB06_B767_300();
    Node nodeBB1S = createNode_BB1S_B767_300();
    Node nodeDSBY = createNode_DSBY_B767_300();
    Node nodeDCAL = createNode_DCAL_B767_300();

    // AutoLand nodes for the INVERTER are ACAL, ASBY
    Node nodeInverter = createNode_INVERTER_B767_300();
    Node nodeACAL = createNode_ACAL_B767_300();
    Node nodeASBY = createNode_ASBY_B767_300();

    List<Node> nodes =
        Arrays.asList(nodeHB06, nodeBB1S, nodeDSBY, nodeDCAL, nodeInverter, nodeACAL, nodeASBY);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNotNull("AutoLandCondition should be calculated for B767-300", autoLandCondition);

    BatteryChargeType batteryChargeType = ela.getAircraft().getBatteryCharge();

    assertEquals(batteryChargeType, autoLandCondition.getBatteryCapacity());

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();
    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    List<AutoLandAnalysisNode> listNodesBatteryCharger = analysisBatteryCharger.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        listNodesBatteryCharger.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));
    // All these BatteryCharger nodes should be present
    AutoLandAnalysisNode nodeBatteryChargerHB06 = mapNodesBatteryCharger.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerHB06);

    AutoLandAnalysisNode nodeBatteryChargerBB1S = mapNodesBatteryCharger.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerBB1S);

    AutoLandAnalysisNode nodeBatteryChargerDSBY = mapNodesBatteryCharger.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDSBY);

    AutoLandAnalysisNode nodeBatteryChargerDCAL = mapNodesBatteryCharger.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDCAL);

    AutoLandAnalysisNode nodeBatteryChargerINVERTER = mapNodesBatteryCharger.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryCharger
    Double sumBatteryCharger =
        listNodesBatteryCharger.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryCharger.getTotalLoadInAmpsSummary(), sumBatteryCharger);

    List<AutoLandAnalysisNode> listNodesBatteryOnly = analysisBatteryOnly.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        listNodesBatteryOnly.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));

    // All these BatteryOnly nodes should be present
    AutoLandAnalysisNode nodeBatteryOnlyHB06 = mapNodesBatteryOnly.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyHB06);

    AutoLandAnalysisNode nodeBatteryOnlyBB1S = mapNodesBatteryOnly.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyBB1S);

    AutoLandAnalysisNode nodeBatteryOnlyDSBY = mapNodesBatteryOnly.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDSBY);

    AutoLandAnalysisNode nodeBatteryOnlyDCAL = mapNodesBatteryOnly.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDCAL);

    AutoLandAnalysisNode nodeBatteryOnlyINVERTER = mapNodesBatteryOnly.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryOnly
    Double sumBatteryOnly =
        listNodesBatteryOnly.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryOnly.getTotalLoadInAmpsSummary(), sumBatteryOnly);

    // All the non-INVERTER nodes should have the same totalLoadInAmps
    // for both BatteryCharger and BatteryOnly
    assertEquals(
        nodeBatteryChargerHB06.getTotalLoadInAmps(), nodeBatteryOnlyHB06.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerBB1S.getTotalLoadInAmps(), nodeBatteryOnlyBB1S.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDSBY.getTotalLoadInAmps(), nodeBatteryOnlyDSBY.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDCAL.getTotalLoadInAmps(), nodeBatteryOnlyDCAL.getTotalLoadInAmps());
  }

  private Ela createEla_B767_300() {
    Fleet fleet = new Fleet();
    fleet.setId(37L);
    fleet.setName("B767-300");
    fleet.setManufacturer("Boeing");
    fleet.setEtops(true);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1094L);
    aircraft.setAircraftShipNo("1200");
    aircraft.setBatteryCharge(BatteryChargeType.SINGLE_48AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(23352L);
    ela.setAircraft(aircraft);

    return ela;
  }

  private Node createNode_HB06_B767_300() {
    Node node = new Node();
    node.setId(1472132L);
    node.setName("HB06");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);
    node.setBusRating(50.0d);

    SummarizedLoad summarizedLoad =
        new SummarizedLoad(
            Boeing.HOLD_LAND.toString(),
            OperatingMode.Boeing.LOAD.toString(),
            node.getElectricalPhase(),
            SummaryType.COMPONENTS_AND_CHILDREN,
            5.32d,
            0.0d);

    List<SummarizedLoad> summarizedLoads = new ArrayList<>();
    summarizedLoads.add(summarizedLoad);

    node.setSummarizedLoads(summarizedLoads);

    return node;
  }

  private Node createNode_BB1S_B767_300() {
    Node node = new Node();
    node.setId(1472100L);
    node.setName("BB1S");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);
    node.setBusRating(50.0d);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12981414L);
    component.setName("STAB TRIM - ALT");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1010");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(28.0d);
    component.setConnectedLoadPf(1.0d);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(28.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DSBY_B767_300() {
    Node node = new Node();
    node.setId(1472101L);
    node.setName("DSBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);
    node.setBusRating(25.0d);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12981924L);
    component.setName("LE SLAT POS IND");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1001");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(14.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(14.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DCAL_B767_300() {

    Node node = new Node();
    node.setId(1472102L);
    node.setName("DCAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);
    node.setBusRating(10.0d);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12981534L);
    component.setName("FLT CONT CMPT SERVO C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("524");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(64.4d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(64.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_INVERTER_B767_300() {
    Node node = new Node();
    node.setId(1472135L);
    node.setName("INVERTER");
    node.setNodeType(NodeType.INVERTER);
    node.setVoltage(24.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setNominalPower(1000.0d);

    return node;
  }

  private Node createNode_ACAL_B767_300() {
    Node node = new Node();
    node.setId(1472085L);
    node.setName("ACAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACB);
    node.setBusRating(5.0d);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12981271L);
    component.setName("C FLT CONT CMPTR PWR");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("515");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACB);
    component.setIntermittent(false);
    component.setConnectedLoadVa(115.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(115.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_ASBY_B767_300() {
    Node node = new Node();
    node.setId(1472090L);
    node.setName("ASBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACA);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(12981320L);
    component.setName("WARN ELEX B");
    component.setAta("31");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("566");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(30.0d);
    component.setConnectedLoadPf(0.8d);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(30.0d);
    load.setPowerFactor(0.8d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  @Test
  public void testCalculate_B767_400() {
    Ela ela = createEla_B767_400();

    List<Node> nodes = createNodes_B767_400(true, true, true);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNotNull("AutoLandCondition should be calculated for B767-400", autoLandCondition);

    BatteryChargeType batteryChargeType = ela.getAircraft().getBatteryCharge();

    assertEquals(batteryChargeType, autoLandCondition.getBatteryCapacity());

    AutoLandAnalysis analysisBatteryCharger = autoLandCondition.getAnalysisBatteryCharger();
    AutoLandAnalysis analysisBatteryOnly = autoLandCondition.getAnalysisBatteryOnly();

    List<AutoLandAnalysisNode> listNodesBatteryCharger = analysisBatteryCharger.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryCharger =
        listNodesBatteryCharger.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));
    // All these BatteryCharger nodes should be present
    AutoLandAnalysisNode nodeBatteryChargerHB06 = mapNodesBatteryCharger.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerHB06);

    AutoLandAnalysisNode nodeBatteryChargerBB1S = mapNodesBatteryCharger.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerBB1S);

    AutoLandAnalysisNode nodeBatteryChargerDSBY = mapNodesBatteryCharger.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDSBY);

    AutoLandAnalysisNode nodeBatteryChargerDCAL = mapNodesBatteryCharger.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerDCAL);

    AutoLandAnalysisNode nodeBatteryChargerINVERTER = mapNodesBatteryCharger.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryChargerINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryCharger
    Double sumBatteryCharger =
        listNodesBatteryCharger.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryCharger.getTotalLoadInAmpsSummary(), sumBatteryCharger);

    List<AutoLandAnalysisNode> listNodesBatteryOnly = analysisBatteryOnly.getNodes();
    Map<String, AutoLandAnalysisNode> mapNodesBatteryOnly =
        listNodesBatteryOnly.stream()
            .collect(Collectors.toMap(AutoLandAnalysisNode::getName, node -> node));

    // All these BatteryOnly nodes should be present
    AutoLandAnalysisNode nodeBatteryOnlyHB06 = mapNodesBatteryOnly.get("HB06");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyHB06);

    AutoLandAnalysisNode nodeBatteryOnlyBB1S = mapNodesBatteryOnly.get("BB1S");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyBB1S);

    AutoLandAnalysisNode nodeBatteryOnlyDSBY = mapNodesBatteryOnly.get("DSBY");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDSBY);

    AutoLandAnalysisNode nodeBatteryOnlyDCAL = mapNodesBatteryOnly.get("DCAL");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyDCAL);

    AutoLandAnalysisNode nodeBatteryOnlyINVERTER = mapNodesBatteryOnly.get("INVERTER");
    assertNotNull("Node should be present in analysis", nodeBatteryOnlyINVERTER);

    // The sum of the totalLoadInAmps of the nodes should equal the totalLoadInAmpsSummary for
    // BatteryOnly
    Double sumBatteryOnly =
        listNodesBatteryOnly.stream()
            .map(AutoLandAnalysisNode::getTotalLoadInAmps)
            .reduce(0.0d, Double::sum);
    assertEquals(analysisBatteryOnly.getTotalLoadInAmpsSummary(), sumBatteryOnly);

    // All the non-INVERTER nodes should have the same totalLoadInAmps
    // for both BatteryCharger and BatteryOnly
    assertEquals(
        nodeBatteryChargerHB06.getTotalLoadInAmps(), nodeBatteryOnlyHB06.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerBB1S.getTotalLoadInAmps(), nodeBatteryOnlyBB1S.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDSBY.getTotalLoadInAmps(), nodeBatteryOnlyDSBY.getTotalLoadInAmps());
    assertEquals(
        nodeBatteryChargerDCAL.getTotalLoadInAmps(), nodeBatteryOnlyDCAL.getTotalLoadInAmps());
  }

  private Ela createEla_B767_400() {
    Fleet fleet = new Fleet();
    fleet.setId(816L);
    fleet.setName("B767-400");
    fleet.setManufacturer("Boeing");
    fleet.setEtops(true);

    Aircraft aircraft = new Aircraft();
    aircraft.setId(1127L);
    aircraft.setAircraftShipNo("1801");
    aircraft.setBatteryCharge(BatteryChargeType.SINGLE_48AH);
    aircraft.setFleet(fleet);

    Ela ela = new Ela();
    ela.setId(23382L);
    ela.setAircraft(aircraft);

    return ela;
  }

  private List<Node> createNodes_B767_400(
      boolean includeDCAL, boolean includeASBY, boolean includeInverter) {
    // AutoLand nodes are HB06, BB1S, DSBY, DCAL
    Node nodeHB06 = createNode_HB06_B767_400();
    Node nodeBB1S = createNode_BB1S_B767_400();
    Node nodeDSBY = createNode_DSBY_B767_400();
    Node nodeDCAL = createNode_DCAL_B767_400();

    // AutoLand nodes for the INVERTER are ACAL, ASBY
    Node nodeInverter = createNode_INVERTER_B767_400();
    Node nodeACAL = createNode_ACAL_B767_400();
    Node nodeASBY = createNode_ASBY_B767_400();

    List<Node> nodes = new ArrayList<>();
    nodes.add(nodeHB06);
    nodes.add(nodeBB1S);
    nodes.add(nodeDSBY);

    if (includeDCAL) {
      nodes.add(nodeDCAL);
    }

    if (includeInverter) {
      nodes.add(nodeInverter);
    }

    nodes.add(nodeACAL);

    if (includeASBY) {
      nodes.add(nodeASBY);
    }

    return nodes;
  }

  private Node createNode_HB06_B767_400() {
    Node node = new Node();
    node.setId(1473868L);
    node.setName("HB06");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    SummarizedLoad summarizedLoad =
        new SummarizedLoad(
            Boeing.HOLD_LAND.toString(),
            OperatingMode.Boeing.LOAD.toString(),
            node.getElectricalPhase(),
            SummaryType.COMPONENTS_AND_CHILDREN,
            8.959999999999999d,
            0.0d);

    List<SummarizedLoad> summarizedLoads = new ArrayList<>();
    summarizedLoads.add(summarizedLoad);

    node.setSummarizedLoads(summarizedLoads);

    return node;
  }

  private Node createNode_BB1S_B767_400() {
    Node node = new Node();
    node.setId(1473830L);
    node.setName("BB1S");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13003422L);
    component.setName("DUAL PWR INTPH CAPT");
    component.setAta("23");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("10033");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.DC);
    component.setIntermittent(false);
    component.setConnectedLoadVa(10.36d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(10.36d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DSBY_B767_400() {
    Node node = new Node();
    node.setId(1473831L);
    node.setName("DSBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13003511L);
    component.setName("L.E. SLATS POS IND");
    component.setAta("27");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("1001");
    component.setPanel("");
    component.setNominalPower(null);
    component.setIntermittent(false);
    component.setConnectedLoadVa(4.48d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(4.48d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_DCAL_B767_400() {
    Node node = new Node();
    node.setId(1473832L);
    node.setName("DCAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(28.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setElectricalPhase(ElectricalPhase.DC);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13003551L);
    component.setName("FLT CONT CMPT SERVO C");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("524");
    component.setPanel("");
    component.setNominalPower(null);
    component.setIntermittent(false);
    component.setConnectedLoadVa(64.4d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(64.4d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_INVERTER_B767_400() {
    Node node = new Node();
    node.setId(1473871L);
    node.setName("INVERTER");
    node.setNodeType(NodeType.INVERTER);
    node.setVoltage(24.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.DC);
    node.setNominalPower(1000.0d);

    return node;
  }

  private Node createNode_ACAL_B767_400() {
    Node node = new Node();
    node.setId(1473816L);
    node.setName("ACAL");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACB);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13003294L);
    component.setName("C FLT CONT CMPT PWR");
    component.setAta("22");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("515");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACB);
    component.setIntermittent(false);
    component.setConnectedLoadVa(116.0d);
    component.setConnectedLoadPf(1.0);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(116.0d);
    load.setPowerFactor(1.0d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  private Node createNode_ASBY_B767_400() {
    Node node = new Node();
    node.setId(1473821L);
    node.setName("ASBY");
    node.setNodeType(NodeType.BUS);
    node.setVoltage(115.0d);
    node.setSheddable(false);
    node.setVoltageType(ElectricalPhase.AC);
    node.setElectricalPhase(ElectricalPhase.ACA);

    // Only using 1 component for each node for testing purposes
    Component component = new Component();
    component.setId(13003336L);
    component.setName("WARN ELEX B");
    component.setAta("31");
    component.setDisplayOrder(1);
    component.setClipsed(false);
    component.setSheddable(false);
    component.setElectIdent("566");
    component.setPanel("");
    component.setNominalPower(null);
    component.setElectricalPhase(ElectricalPhase.ACA);
    component.setIntermittent(false);
    component.setConnectedLoadVa(30.0d);
    component.setConnectedLoadPf(0.8);

    Load load = new Load();
    load.setFlightPhase(Boeing.HOLD_LAND.toString());
    load.setOperatingMode(OperatingMode.Boeing.LOAD.toString());
    load.setVa(30.0d);
    load.setPowerFactor(0.8d);

    component.addLoad(load);
    node.addComponent(component);

    return node;
  }

  @Test
  public void testCalculate_B767_400_MissingNode() {
    Ela ela = createEla_B767_400();

    List<Node> nodes = createNodes_B767_400(false, true, true);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNull("AutoLandCondition should be NULL for a missing node.", autoLandCondition);
  }

  @Test
  public void testCalculate_B767_400_MissingInverterCalcNode() {
    Ela ela = createEla_B767_400();

    List<Node> nodes = createNodes_B767_400(true, false, true);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNull(
        "AutoLandCondition should be NULL for missing inverter calculation node.",
        autoLandCondition);
  }

  @Test
  public void testCalculate_B767_400_MissingInverter() {
    Ela ela = createEla_B767_400();

    List<Node> nodes = createNodes_B767_400(true, true, false);

    AutoLandFleetConfigDto autoLandFleetConfig =
        autoLandAnalysisService.loadFleetConfig(ela.getAircraft().getFleet());

    AutoLandCondition autoLandCondition =
        autoLandAnalysisService.calculate(ela, nodes, autoLandFleetConfig);

    assertNull("AutoLandCondition should be NULL for a missing INVERTER node.", autoLandCondition);
  }
}
