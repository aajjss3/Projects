package com.seatec.ela.app.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.junit.Test;

public class NodeUtilTest {

  @Test
  public void groupNodesByParent_groups_nodes_by_parent() {

    Node node1 = new Node();
    node1.setId(546429L);
    node1.setName("GEN 1");

    Node node2 = new Node();
    node2.setId(546430L);
    node2.setName("1IWXP");
    node2.setParentNode(node1);

    Node node3 = new Node();
    node3.setId(546431L);
    node3.setName("1XP");

    Node node4 = new Node();
    node4.setId(546432L);
    node4.setName("101XP");

    Node node5 = new Node();
    node5.setId(546433L);
    node5.setName("103XP");

    node1.addSubNode(node2);
    node1.addSubNode(node3);

    node3.addSubNode(node4);
    node3.addSubNode(node5);

    Map<Node, List<Node>> nodeMap =
        NodeUtil.groupNodesByParent(Arrays.asList(node1, node2, node3, node4, node5));

    assertTrue(nodeMap.containsKey(node1));
    assertEquals(2, nodeMap.get(node1).size());

    assertTrue(nodeMap.containsKey(node3));
    assertEquals(2, nodeMap.get(node3).size());

    // node 2 doesn't have children in this example
    assertFalse(nodeMap.containsKey(node2));
  }

  @Test
  public void groupComponentsByNode_groups_components_by_node() {
    Node node1 = new Node();
    node1.setId(546448L);
    node1.setName("103PP");

    Node node2 = new Node();
    node2.setId(546449L);
    node2.setName("3PP");

    Component component1 = new Component();
    component1.setId(4282433L);
    component1.setName("LIGHTING/FLOOD/CAPT/SID");

    Component component2 = new Component();
    component2.setId(4282434L);
    component2.setName("IGGS/CTLR");

    Component component3 = new Component();
    component3.setId(4282435L);
    component3.setName("BAT BUS/301PP/SPLY");

    node1.addComponent(component1);
    node1.addComponent(component2);
    node2.addComponent(component3);

    Map<Node, List<Component>> componentMap =
        NodeUtil.groupComponentsByNode(Arrays.asList(component1, component2, component3));

    assertTrue(componentMap.containsKey(node1));
    assertEquals(2, componentMap.get(node1).size());

    assertTrue(componentMap.containsKey(node2));
    assertEquals(1, componentMap.get(node2).size());
  }

  @Test
  public void groupLoadsByComponent_groups_loads_by_component() {

    Component component1 = new Component();
    component1.setId(4282795L);
    component1.setName("VACU TOIL SYS-VACUUM-SYS");

    Component component2 = new Component();
    component2.setId(4282796L);
    component2.setName("VACU TOIL SYS-LAV PWR-D");

    Load load1 = new Load();
    load1.setId(46589061L);
    load1.setVa(15.0d);
    load1.setPowerFactor(1.0d);
    load1.setOperatingMode("OPERATIONAL");
    load1.setFlightPhase("LANDING");

    Load load2 = new Load();
    load2.setId(46589062L);
    load2.setVa(15.0d);
    load2.setPowerFactor(1.0d);
    load2.setOperatingMode("OPERATIONAL");
    load2.setFlightPhase("TAXI");

    Load load3 = new Load();
    load3.setId(46589063L);
    load3.setVa(98.0d);
    load3.setPowerFactor(1.0d);
    load3.setOperatingMode("MAXI");
    load3.setFlightPhase("GROUND");

    component1.addLoad(load1);
    component1.addLoad(load2);

    component2.addLoad(load3);

    Map<Component, List<Load>> loadMap =
        NodeUtil.groupLoadsByComponent(Arrays.asList(load1, load2, load3));

    assertTrue(loadMap.containsKey(component1));
    assertEquals(2, loadMap.get(component1).size());

    assertTrue(loadMap.containsKey(component2));
    assertEquals(1, loadMap.get(component2).size());
  }

  @Test
  public void flattenNodeTrees_should_return_all_tree_nodes() {

    Node root1 = new Node();
    root1.setId(546429L);
    root1.setName("GEN 1");

    Node root2 = new Node();
    root2.setId(546457L);
    root2.setName("GEN 2");

    Node node2 = new Node();
    node2.setId(546430L);
    node2.setName("1IWXP");

    Node node3 = new Node();
    node3.setId(546431L);
    node3.setName("1XP");

    Node node4 = new Node();
    node4.setId(546432L);
    node4.setName("101XP");

    Node node5 = new Node();
    node5.setId(546433L);
    node5.setName("103XP");

    root1.addSubNode(node2);
    root1.addSubNode(node3);

    node3.addSubNode(node4);
    node3.addSubNode(node5);

    List<Node> flatNodeList = NodeUtil.flattenNodeTrees(Arrays.asList(root1, root2));

    assertEquals(6, flatNodeList.size());
  }

  @Test
  public void flattenNodeTrees_handles_empty_list() {

    List<Node> flatNodeList = NodeUtil.flattenNodeTrees(new ArrayList<>());

    assertEquals(0, flatNodeList.size());
  }

  @Test
  public void flattenNodeTrees_handles_null_list() {

    List<Node> flatNodeList = NodeUtil.flattenNodeTrees(null);

    assertEquals(0, flatNodeList.size());
  }

  @Test
  public void getNodeByName_should_get_node_by_name() {

    String nodeName = "GEN 2";

    Node root1 = new Node();
    root1.setId(546429L);
    root1.setName("GEN 1");

    Node root2 = new Node();
    root2.setId(546457L);
    root2.setName(nodeName);

    Node result = NodeUtil.getNodeByName(Arrays.asList(root1, root2), nodeName);

    assertNotNull(result);
    assertEquals(nodeName, result.getName());
  }

  @Test(expected = NotFoundException.class)
  public void getNodeByName_handles_empty_list() {

    String nodeName = "GEN 2";

    NodeUtil.getNodeByName(new ArrayList<>(), nodeName);
  }

  @Test(expected = NotFoundException.class)
  public void getNodeByName_handles_null_name() {

    Node root1 = new Node();
    root1.setId(546429L);
    root1.setName("GEN 1");

    Node root2 = new Node();
    root2.setId(546457L);
    root2.setName("GEN 2");

    NodeUtil.getNodeByName(Arrays.asList(root1, root2), null);
  }

  @Test
  public void testGetTopLevelNodeIds() {
    Node root1 = new Node();
    root1.setId(546429L);
    root1.setName("GEN 1");

    Node root2 = new Node();
    root2.setId(546457L);
    root2.setName("GEN 2");

    Node node2 = new Node();
    node2.setId(546430L);
    node2.setName("1IWXP");

    Node node3 = new Node();
    node3.setId(546431L);
    node3.setName("1XP");

    Node node4 = new Node();
    node4.setId(546432L);
    node4.setName("101XP");

    Node node5 = new Node();
    node5.setId(546433L);
    node5.setName("103XP");

    root1.addSubNode(node2);
    root1.addSubNode(node3);

    node3.addSubNode(node4);
    node3.addSubNode(node5);

    List<Node> flatNodeList = NodeUtil.flattenNodeTrees(Arrays.asList(root1, root2));
    List<Long> topLevelNodeIds = NodeUtil.getTopLevelNodeIds(flatNodeList);

    assertEquals(2, topLevelNodeIds.size());
    assertTrue(topLevelNodeIds.contains(root1.getId()));
    assertTrue(topLevelNodeIds.contains(root2.getId()));
  }

  @Test
  public void testValidateNodeType_valid() {
    NodeType expectedNodeType = NodeType.GENERATOR;
    NodeUtil.validateNodeType(expectedNodeType, NodeType.GENERATOR);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateNodeType_invalid() {
    NodeType expectedNodeType = NodeType.GENERATOR;
    NodeUtil.validateNodeType(expectedNodeType, NodeType.TRU);
  }

  @Test(expected = NullPointerException.class)
  public void testGetNodeIdentifier_node_null() {
    NodeUtil.getNodeIdentifier(null);
  }

  @Test
  public void testGetNodeIdentifier_id_null() {
    String nodeName = "GEN 1";

    Node node = new Node();
    node.setName(nodeName);

    String actualNodeIdentifier = NodeUtil.getNodeIdentifier(node);

    assertEquals(nodeName, actualNodeIdentifier);
  }

  @Test
  public void testGetNodeIdentifier_id_and_name_null() {

    Node node = new Node();

    String actualNodeIdentifier = NodeUtil.getNodeIdentifier(node);

    assertNull(actualNodeIdentifier);
  }

  @Test
  public void testGetNodeIdentifier() {
    Long nodeId = 546429L;

    Node node = new Node();
    node.setId(nodeId);
    node.setName("GEN 1");

    String actualNodeIdentifier = NodeUtil.getNodeIdentifier(node);

    assertEquals(nodeId.toString(), actualNodeIdentifier);
  }
}
