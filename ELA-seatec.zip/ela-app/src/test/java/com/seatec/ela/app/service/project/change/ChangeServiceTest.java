package com.seatec.ela.app.service.project.change;

import static org.junit.Assert.assertEquals;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.config.ModelMapperConfiguration;
import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.project.change.ChangeRepo;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.service.contract.project.change.IChangeCommentService;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import com.seatec.ela.app.service.project.ChangeGroupService;
import com.seatec.ela.app.service.project.ProjectService;
import com.seatec.ela.app.util.ComponentDtoConverter;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ChangeServiceTest {
  private static final String DEFAULT_USER_ID = "00000-00000-00000-00000-00000";

  // email: seatecappstore+elatestuser@gmail.com (DEV keycloak)
  private static final String ELA_TEST_USER_ID = "64d14438-8968-48d9-890c-c8e31a3a4221";

  private IChangeService subject;

  private IChangeCommentService mockChangeCommentService;

  private IChangeGroupService mockChangeGroupService;

  private IProjectService mockProjectService;

  private ChangeRepo mockChangeRepo;

  private Project project;

  @Rule public ExpectedException exceptionRule = ExpectedException.none();

  @Before
  public void setup() {
    mockChangeRepo = mock(ChangeRepo.class);
    mockChangeCommentService = mock(ChangeCommentService.class);
    mockChangeGroupService = mock(ChangeGroupService.class);
    mockProjectService = mock(ProjectService.class);
    ModelMapperConfiguration config = new ModelMapperConfiguration();
    subject =
        new ChangeService(
            mockChangeCommentService,
            mockChangeGroupService,
            mockProjectService,
            mockChangeRepo,
            config.getAllMapper());

    project =
        createProjectWithChangeGroupsAndEffectivities(
            UUID.randomUUID(), "project1", "1", "maintenance desc", Instant.now());
  }

  @Test
  public void when_findById_then_return_2xx() {
    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change change = createChange(ActionType.ADD, ELA_TEST_USER_ID, nodeChange, null, "", "");

    // mocks
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(change));

    Optional<Change> response = subject.findById(change.getId());

    // assert
    verify(mockChangeRepo, times(1)).findById(isA(UUID.class));

    Assert.assertTrue(response.isPresent());

    Change changeResponse = response.get();
    assertEquals(changeResponse.getId(), change.getId());
    assertEquals(changeResponse.getChanger(), change.getChanger());
    assertEquals(changeResponse.getNodeChange(), change.getNodeChange());
    assertEquals(changeResponse.getAction(), change.getAction());
  }

  /** create Section (start) */
  @Test
  public void when_create_componentChange_andInvalidFlightPhase_then_throw_BadRequestException() {
    // arrange

    // change group
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // load change(s)
    List<LoadChange> loadChanges = createLoadChangesByManufacturer("airbus", 1d, 1d, "A330");
    loadChanges.get(0).setFlightPhase("INVALID");

    // component change
    ComponentChange componentChange =
        createComponentChange(
            "TEST", false, "ata", "TEST", ElectricalPhase.ACA, "panel", false, 1d, loadChanges);

    // change ("1IWXP" => existing node, "TEST" => non-existing component)
    Change newChange =
        createChange(ActionType.ADD, DEFAULT_USER_ID, null, componentChange, "TEST", "1IWXP");

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage(
        "Load contains incompatible Flight Phase 'INVALID' for Component 'TEST' and Node '1IWXP'");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void when_create_componentChange_andInvalidOperatingMode_then_throw_BadRequestException() {
    // arrange

    // change group
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // load change(s)
    List<LoadChange> loadChanges = createLoadChangesByManufacturer("airbus", 1d, 1d, "A330");
    loadChanges.get(0).setOperatingMode("INVALID");

    // component change
    ComponentChange componentChange =
        createComponentChange(
            "TEST", false, "ata", "TEST", ElectricalPhase.ACA, "panel", false, 1d, loadChanges);

    // change ("1IWXP" => existing node, "TEST" => non-existing component)
    Change newChange =
        createChange(ActionType.ADD, DEFAULT_USER_ID, null, componentChange, "TEST", "1IWXP");

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage(
        "Load contains incompatible Operating Mode 'INVALID' for Component 'TEST' and Node '1IWXP'");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test(expected = NotFoundException.class)
  public void addChange_when_bad_change_group_id_then_throw_NotFoundException() {
    when(mockChangeGroupService.findById(any(UUID.class))).thenReturn(Optional.ofNullable(null));

    subject.create(new Change(), UUID.randomUUID(), UUID.randomUUID());
  }

  @Test(expected = NotFoundException.class)
  public void addChange_when_existing_changes_are_not_node_change_then_throw_NotFoundException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    ComponentChange existingComponentChange =
        createComponentChange(
            "componentA", false, "2126", "1HQ", ElectricalPhase.AC3, "123VU", false, 6211.8D, null);

    Change existingChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, null, existingComponentChange, "", "1XP");

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.EDIT, ELA_TEST_USER_ID, nodeChange, null, "", "1XP");

    // add existing change
    airbusChangeGroup.setChanges(Collections.singletonList(existingChange));

    // ChangeGroupNodeDto
    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeGroupService, times(1))
        .findChangeGroupEffectivityBusStructureByChangeGroupId(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test
  public void addChange_when_no_existing_changes_then_save_NodeChange_and_Change() {
    String userId = ELA_TEST_USER_ID;
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, userId, nodeChange, null, "", "");

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeGroupService, times(1))
        .findChangeGroupEffectivityBusStructureByChangeGroupId(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test(expected = NotFoundException.class)
  public void when_create_existing_changes_are_not_node_change_then_throw_NotFoundException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "99XP");

    // ChangeGroupNodeDto
    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    ChangeGroupNodeDto changeGroupNodeDtoChild =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "1XP",
            NodeType.BUS,
            null,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            null,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto changeGroupNodeDtoParent =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            115000D,
            false,
            false,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.singletonList(changeGroupNodeDtoChild),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(changeGroupNodeDtoParent);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      addChange_when_existing_changes_are_not_node_change_then_save_NodeChange_and_Change() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "1XP",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange =
        createChange(ActionType.EDIT, ELA_TEST_USER_ID, nodeChange, null, "", "GEN 1");

    // ChangeGroupNodeDto
    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    ChangeGroupNodeDto changeGroupNodeDtoChild =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "1XP",
            NodeType.BUS,
            null,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            null,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto changeGroupNodeDtoParent =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            115000D,
            false,
            false,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.singletonList(changeGroupNodeDtoChild),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(changeGroupNodeDtoParent);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test(expected = NotFoundException.class)
  public void
      addChange_when_existing_changes_are_node_change_and_node_not_in_change_group_then_throw_NotFoundException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange existingNodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "101XP_MOD",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change existingChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, existingNodeChange, null, "", "101XP");

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "103XP_MOD",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, nodeChange, null, "", "101XP");

    // add existing change
    airbusChangeGroup.setChanges(Collections.singletonList(existingChange));

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(Collections.emptyList());

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test(expected = ConflictException.class)
  public void
      addChange_when_existing_changes_are_node_change_and_node_in_change_group_and_isDuplicate_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange existingNodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "101XP_MOD",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change existingChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, existingNodeChange, null, "", "101XP");

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "101XP_MOD",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, nodeChange, null, "", "101XP");

    // add existing change
    airbusChangeGroup.setChanges(Collections.singletonList(existingChange));

    List<ChangeGroupNodeDto> changeGroupNodeDtos =
        Collections.singletonList(createChangeGroupNodeDtoTree("GEN 1", "1XP", "101XP"));

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      addChange_when_existing_changes_are_node_change_and_node_in_change_group_and_isNotDuplicate_then_save_NodeChange_and_Change() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // node change
    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            100D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeGroupService, times(1))
        .findChangeGroupEffectivityBusStructureByChangeGroupId(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  // com.seatec.ela.app.exception.ConflictException: Incompatible Voltage selection (node: '115.0',
  // parent: '100.0')
  @Test
  public void when_create_withIncompatibleVoltage_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D, // must match parent (ie. 100D)
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage(
        "Incompatible Voltage (115.0) for Node Type (BUS) based on parent Node Type (BUS) and Voltage (100.0)");
    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_withIncompatibleVoltageType_AC3_forNodeTypeATU_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.ATU,
            false,
            false,
            "WrongNodeTypeForATU",
            10D,
            115D,
            ElectricalPhase.AC3, // must be AC for ATU
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage("Incompatible Voltage Type (AC3) for Node Type (ATU)");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_withIncompatibleVoltageType_AC_forNodeTypeTRU_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.TRU,
            false,
            false,
            "WrongNodeTypeForTRU",
            10D,
            115D,
            ElectricalPhase.AC, // must be AC3
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage("Incompatible Voltage Type (AC) for Node Type (TRU)");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_withIncompatibleVoltageType_AC3_forNodeTypeBUS_withParentNodeTypeATU_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "WrongNodeTypeForBusWithParentNodeTypeATU",
            10D,
            100D,
            ElectricalPhase.AC3, // must be AC
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.ATU,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage(
        "Incompatible Voltage Type (AC3) for Node Type (BUS) based on parent Node Type (ATU) and Voltage Type (AC)");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void
      when_create_withIncompatibleVoltageType_AC3_forNodeTypeBUS_withParentNodeTypeTRU_then_throw_ConflictException() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "WrongNodeTypeForBusWithParentNodeTypeTRU",
            10D,
            100D,
            ElectricalPhase.AC3, // must be DC
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, "", "103XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();

    ChangeGroupNodeDto thirdLevelOne =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "101XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto thirdLevelTwo =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "103XP",
            NodeType.TRU,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    List<ChangeGroupNodeDto> thirdLevelNodeDtos = new ArrayList<>();
    thirdLevelNodeDtos.add(thirdLevelOne);
    thirdLevelNodeDtos.add(thirdLevelTwo);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            thirdLevelNodeDtos,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(ConflictException.class);
    exceptionRule.expectMessage(
        "Incompatible Voltage Type (AC3) for Node Type (BUS) based on parent Node Type (TRU) and Voltage Type (AC3)");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void addChange_when_no_existing_changes_then_save_ComponentChange_and_Change() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    ComponentChange componentChange =
        createComponentChange(
            "newComponent",
            false,
            "2422",
            "8XU11",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change newChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, null, componentChange, "", "101XP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    ChangeGroupNodeDto childNode1a =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1IWXP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto childNode1b =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto childNode1c =
        createChangeGroupNodeDto(
            null,
            0D,
            false,
            "101XP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            115000D,
            false,
            false,
            false,
            115D,
            ElectricalPhase.AC3,
            Lists.newArrayList(childNode1a, childNode1b, childNode1c),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);
    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeGroupService.save(any(ChangeGroup.class), any(UUID.class)))
        .then(returnsFirstArg());

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test
  public void addChange_add_component_ensure_no_split() {
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // build out the component change
    ComponentChange componentChange =
        createComponentChange(
            "newComponent", false, null, "newIdent", ElectricalPhase.AC3, null, false, null, null);

    // make sure the change is an ADD
    Change newChange =
        createChange(ActionType.ADD, ELA_TEST_USER_ID, null, componentChange, "newIdent", "1IWXP");

    // ensure that the mocked results of the meta-query return that global==true indicating
    // the component exists across effectivity.  These split determination logic
    // in ChangeService uses these results.
    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    changeGroupNodeDtos.add(
        createChangeGroupNodeDto(
            null,
            0.0,
            true,
            "1IWXP",
            NodeType.BUS,
            90000.0,
            false,
            false,
            false,
            115D,
            null,
            Collections.emptyList(),
            ElectricalPhase.AC3));
    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeGroupService.save(any(ChangeGroup.class), any(UUID.class)))
        .then(returnsFirstArg());

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    assertEquals("Airbus 1", newChange.getChangeGroup().getName());
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test
  public void addChange_add_component_to_cause_split() {
    // arrange
    String userId = ELA_TEST_USER_ID;
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    ComponentChange componentChange =
        createComponentChange(
            "newComponent", false, null, "newIdent", ElectricalPhase.AC3, null, false, null, null);

    Change newChange =
        createChange(ActionType.ADD, userId, null, componentChange, "newIdent", "1IWXP");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    changeGroupNodeDtos.add(
        createChangeGroupNodeDto(
            null,
            0.0,
            false,
            "1IWXP",
            NodeType.BUS,
            90000.0,
            false,
            false,
            false,
            115D,
            null,
            Collections.emptyList(),
            ElectricalPhase.AC3));
    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeGroupService.save(any(ChangeGroup.class), any(UUID.class)))
        .then(returnsFirstArg());

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    // assert
    assertEquals(newChange.getChangeGroup().getName(), "Airbus 1 (split 1)");
    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test
  public void addChange_when_change_splits_changeGroup_then_save() {
    // arrange
    String userId = ELA_TEST_USER_ID;
    ChangeGroup changeGroup = project.getChangeGroups().get(0);

    NodeChange nodeChange =
        createNodeChange(
            1D,
            NodeType.BUS,
            false,
            true,
            "101XP",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.EDIT, userId, nodeChange, null, "", "GEN 1");

    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    ChangeGroupNodeDto childNode1a =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1IWXP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto childNode1b =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "1XP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto childNode1c =
        createChangeGroupNodeDto(
            null,
            0D,
            false,
            "101XP",
            NodeType.BUS,
            0D,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            115000D,
            false,
            false,
            false,
            115D,
            ElectricalPhase.AC3,
            Lists.newArrayList(childNode1a, childNode1b, childNode1c),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(topLevel);

    Aircraft aircraft =
        createAircraft(
            1L,
            "N/A",
            null,
            "3356",
            "N/A",
            "33-525113-20_ELA_AppendixA_3356.xlsx",
            "N856NW",
            "0631",
            null,
            null,
            false,
            "7c3461a3ea73eae1943aa6f1acfe8600");

    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setAircraft(aircraft);
    ChangeGroup newChangeGroup =
        createChangeGroup(
            "Airbus 1 (node 101XP split)", Lists.newArrayList(aircraftChangeGroup), project);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);
    when(mockChangeGroupService.save(any(ChangeGroup.class), any(UUID.class)))
        .thenReturn(newChangeGroup);
    when(mockChangeRepo.save(any(Change.class))).thenReturn(newChange);

    subject.create(newChange, changeGroup.getId(), project.getId());

    verify(mockProjectService, times(1)).findById(isA(UUID.class));
    verify(mockChangeGroupService, times(1))
        .findChangeGroupEffectivityBusStructureByChangeGroupId(isA(UUID.class));
    verify(mockChangeGroupService, times(1)).save(isA(ChangeGroup.class), isA(UUID.class));
    verify(mockChangeRepo, times(1)).save(isA(Change.class));
  }

  @Test
  public void addChange_when_node_is_deleted_delete_all_components() {
    ChangeGroup changeGroup = new ChangeGroup();
    NodeChange nodeChange =
        createNodeChange(
            0d,
            NodeType.BUS,
            false,
            false,
            "101XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);
    Project project = new Project();
    project.addChangeGroup(changeGroup);

    Change change = createChange(ActionType.DELETE, "test", nodeChange, null, null, "101XP");
    when(mockChangeGroupService.findById(changeGroup.getId())).thenReturn(Optional.of(changeGroup));
    when(mockChangeRepo.findById(change.getId())).thenReturn(Optional.of(change));
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    ComponentDto componentDto =
        ComponentDtoConverter.convertComponentToComponentDto(
            createComponent(
                1L,
                false,
                1,
                new ArrayList<>(),
                false,
                ElectricalPhase.AC3,
                "test123",
                0d,
                "123",
                "100",
                null,
                "test",
                false));
    ComponentDto componentDto2 =
        ComponentDtoConverter.convertComponentToComponentDto(
            createComponent(
                2L,
                false,
                2,
                new ArrayList<>(),
                false,
                ElectricalPhase.AC3,
                "test125",
                0d,
                "125",
                "100",
                null,
                "test",
                false));
    List<ComponentDto> componentDtos = Arrays.asList(componentDto, componentDto2);

    // mocks
    when(mockChangeGroupService.findComponentsByChangeGroupAndNodeName(changeGroup, "101XP"))
        .thenReturn(componentDtos);

    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(
            Arrays.asList(
                createChangeGroupNodeDto(
                    null,
                    null,
                    true,
                    "101XP",
                    NodeType.BUS,
                    null,
                    false,
                    true,
                    false,
                    115D,
                    ElectricalPhase.AC3,
                    null,
                    ElectricalPhase.AC3)));

    // act
    subject.create(change, changeGroup.getId(), project.getId());
    verify(mockChangeRepo, times(1 + componentDtos.size())).save(any(Change.class));
  }

  @Test
  public void createChange_should_delete_component_changes_when_their_bus_has_been_deleted() {
    // arrange
    String userId = ELA_TEST_USER_ID;
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);
    ComponentChange componentChange =
        createComponentChange(
            "test", false, "test", "test", ElectricalPhase.AC3, "test", false, 100d, null);
    Change existingChange =
        createChange(ActionType.EDIT, userId, null, componentChange, "test", "1XP");
    // add existing change
    airbusChangeGroup.setChanges(new ArrayList<>(Collections.singletonList(existingChange)));

    // ChangeGroupNodeDto
    List<ChangeGroupNodeDto> changeGroupNodeDtos = new ArrayList<>();
    ChangeGroupNodeDto changeGroupNodeDtoChild =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "1XP",
            NodeType.BUS,
            null,
            false,
            true,
            false,
            115D,
            ElectricalPhase.AC3,
            null,
            ElectricalPhase.AC3);
    ChangeGroupNodeDto changeGroupNodeDtoParent =
        createChangeGroupNodeDto(
            null,
            null,
            true,
            "GEN 1",
            NodeType.GENERATOR,
            115000D,
            false,
            false,
            false,
            115D,
            ElectricalPhase.AC3,
            Collections.singletonList(changeGroupNodeDtoChild),
            ElectricalPhase.AC3);
    changeGroupNodeDtos.add(changeGroupNodeDtoParent);

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupService.findChangeGroupEffectivityBusStructureByChangeGroupId(
            any(UUID.class)))
        .thenReturn(changeGroupNodeDtos);

    NodeChange nodeChange =
        createNodeChange(
            0d,
            NodeType.BUS,
            false,
            false,
            "1XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.DELETE, userId, nodeChange, null, null, "1XP");

    subject.create(newChange, airbusChangeGroup.getId(), project.getId());

    verify(mockChangeRepo, times(1)).save(isA(Change.class));
    verify(mockChangeRepo, times(1)).delete(isA(Change.class));
  }

  @Test(expected = ConflictException.class)
  public void
      createChange_should_throw_ConflictException_when_NodeChangeWithActionAddAndNodeNameAlreadyExists() {
    // arrange
    String userId = ELA_TEST_USER_ID;
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    NodeChange existingNodeChange =
        createNodeChange(
            50d,
            NodeType.BUS,
            false,
            false,
            "115XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change existingChange =
        createChange(ActionType.ADD, userId, existingNodeChange, null, "test", "1XP");

    // add existing change
    airbusChangeGroup.setChanges(new ArrayList<>(Collections.singletonList(existingChange)));

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    NodeChange nodeChange =
        createNodeChange(
            0d,
            NodeType.BUS,
            false,
            false,
            "115XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, userId, nodeChange, null, null, "4XP");

    // act
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }

  @Test
  public void when_create_with_approved_project_then_throw_BadRequestException() {
    // arrange
    String userId = ELA_TEST_USER_ID;
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // new nodeChange
    NodeChange newNodeChange =
        createNodeChange(
            50d,
            NodeType.BUS,
            false,
            false,
            "115XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change newChange = createChange(ActionType.ADD, userId, newNodeChange, null, "test", "1XP");

    // mark project approved
    project.setApproved(Instant.now());

    // mocks
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(BadRequestException.class);
    exceptionRule.expectMessage("Cannot create Changes after a project has been approved.");

    // act (throw exception)
    subject.create(newChange, airbusChangeGroup.getId(), project.getId());
  }
  /** create Section (end) */

  /** delete Section (start) */
  @Test
  public void deleteChange_when_valid_id_then_delete() {
    doNothing().when(mockChangeRepo).delete(any(Change.class));

    Project project = new Project();
    project.setTitle("test");
    ChangeGroup changeGroup = new ChangeGroup();
    project.addChangeGroup(changeGroup);

    when(mockChangeGroupService.findById(any())).thenReturn(Optional.of(changeGroup));
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(new Change()));

    subject.delete(UUID.randomUUID(), changeGroup.getId(), project.getId());

    verify(mockChangeRepo, times(1)).delete(isA(Change.class));
  }

  @Test
  public void
      when_deleteChange_isNodeChange_and_contains_related_component_changes_then_delete_component_changes_and_node_change() {
    // arrange
    Project project = new Project();
    project.setTitle("test");

    // change(s)
    NodeChange nodeChange =
        createNodeChange(
            20d,
            NodeType.BUS,
            false,
            false,
            "666ZZ",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);
    Change change1 = createChange(ActionType.ADD, DEFAULT_USER_ID, nodeChange, null, null, "101XP");

    ComponentChange componentChange =
        createComponentChange(
            "CompChange", false, "ata", "123abc", ElectricalPhase.AC3, "panel", false, 20d, null);
    Change change2 =
        createChange(ActionType.ADD, DEFAULT_USER_ID, null, componentChange, "123abc", "666ZZ");

    List<Change> changes = new ArrayList<>();
    changes.add(change1);
    changes.add(change2);

    // change group(s)
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setName("Airbus 1");
    changeGroup.setChanges(changes);
    project.addChangeGroup(changeGroup);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(change1));
    // when(mockChangeGroupService.findById(any())).thenReturn(Optional.of(changeGroup));
    doNothing().when(mockChangeRepo).delete(any(Change.class));

    // act
    subject.delete(change1.getId(), changeGroup.getId(), project.getId());

    // assert
    verify(mockChangeRepo, times(2)).delete(isA(Change.class));
  }

  @Test(expected = ConflictException.class)
  public void deleteChange_when_parent_node_is_deleted_then_throw_ConflictException() {
    ChangeGroup changeGroup = new ChangeGroup();
    NodeChange nodeChange =
        createNodeChange(
            0d,
            NodeType.BUS,
            false,
            false,
            "101XP",
            0d,
            115d,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);
    ComponentChange componentChange =
        createComponentChange(
            "test", false, "test", "123", ElectricalPhase.AC3, "test", false, 0d, null);
    Change change = createChange(ActionType.DELETE, "test", nodeChange, null, null, "101XP");
    Change compChange =
        createChange(ActionType.DELETE, "test", null, componentChange, "123", "101XP");
    changeGroup.addChange(change);
    changeGroup.addChange(compChange);
    Project project = new Project();
    project.addChangeGroup(changeGroup);
    when(mockChangeGroupService.findById(changeGroup.getId())).thenReturn(Optional.of(changeGroup));
    when(mockChangeRepo.findById(change.getId())).thenReturn(Optional.of(change));
    when(mockChangeRepo.findById(compChange.getId())).thenReturn(Optional.of(compChange));
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    subject.delete(compChange.getId(), changeGroup.getId(), project.getId());
  }
  /** delete Section (end) */

  /** update Section (start) */
  @Test(expected = NotFoundException.class)
  public void updateChange_when_id_not_found_then_throw_NotFoundException() {
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.ofNullable(null));

    subject.update(new Change(), UUID.randomUUID());
  }

  @Test(expected = ConflictException.class)
  public void
      updateChange_when_existing_component_change_add_and_change_add_then_throw_ConflictException() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.ADD, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.ADD, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    // add change group to change
    Fleet fleet = createFleet(1L, "A123-999", "Airbus", false, null, "Airbus", "Airbus");
    Ela ela = createEla(1L, null, Collections.emptyList(), "ELA");
    Aircraft aircraft =
        createAircraft(
            1L,
            "variable",
            fleet,
            "123",
            "line",
            "",
            "",
            "123",
            Collections.EMPTY_LIST,
            Collections.singletonList(ela),
            false,
            "");
    AircraftChangeGroup aircraftChangeGroup = createAircraftChangeGroup(aircraft, null);
    ChangeGroup changeGroup =
        createChangeGroup("Airbus 1", Collections.singletonList(aircraftChangeGroup), project);
    existingChange.setChangeGroup(changeGroup);

    // mock(s)
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    // act
    subject.update(updatedChange, updatedChange.getId());
  }

  @Test(expected = NotFoundException.class)
  public void
      updateChange_when_existing_component_change_add_and_change_add_then_throw_NotFoundException() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.ADD, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.ADD, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    subject.update(updatedChange, updatedChange.getId());
  }

  @Test(expected = BadRequestException.class)
  public void
      updateChange_when_existing_component_change_add_and_change_delete_then_throw_BadRequestException() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.ADD, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.DELETE, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    // add change group to change
    Fleet fleet = createFleet(1L, "A123-999", "Airbus", false, null, "Airbus", "Airbus");
    Ela ela = createEla(1L, null, Collections.emptyList(), "ELA");
    Aircraft aircraft =
        createAircraft(
            1L,
            "variable",
            fleet,
            "123",
            "line",
            "",
            "",
            "123",
            Collections.EMPTY_LIST,
            Collections.singletonList(ela),
            false,
            "");
    AircraftChangeGroup aircraftChangeGroup = createAircraftChangeGroup(aircraft, null);
    ChangeGroup changeGroup =
        createChangeGroup("Airbus 1", Collections.singletonList(aircraftChangeGroup), project);
    existingChange.setChangeGroup(changeGroup);

    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    subject.update(updatedChange, updatedChange.getId());
  }

  @Test
  public void updateChange_when_existing_component_change_add_and_change_edit_then_update_fields() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.ADD, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.EDIT, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    // add change group to change
    Fleet fleet = createFleet(1L, "A123-999", "Airbus", false, null, "Airbus", "Airbus");
    Ela ela = createEla(1L, null, Collections.emptyList(), "ELA");
    Aircraft aircraft =
        createAircraft(
            1L,
            "variable",
            fleet,
            "123",
            "line",
            "",
            "",
            "123",
            Collections.EMPTY_LIST,
            Collections.singletonList(ela),
            false,
            "");
    AircraftChangeGroup aircraftChangeGroup = createAircraftChangeGroup(aircraft, null);
    ChangeGroup changeGroup =
        createChangeGroup("Airbus 1", Collections.singletonList(aircraftChangeGroup), project);
    existingChange.setChangeGroup(changeGroup);

    // mock(s)
    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    // act
    subject.update(updatedChange, updatedChange.getId());

    // assert
    verify(mockChangeRepo, times(1)).findById(isA(UUID.class));
  }

  @Test
  public void
      updateChange_when_existing_component_change_delete_and_change_edit_then_update_action() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.DELETE, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.EDIT, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    // add change group to change
    Fleet fleet = createFleet(1L, "A123-999", "Airbus", false, null, "Airbus", "Airbus");
    Ela ela = createEla(1L, null, Collections.emptyList(), "ELA");
    Aircraft aircraft =
        createAircraft(
            1L,
            "variable",
            fleet,
            "123",
            "line",
            "",
            "",
            "123",
            Collections.EMPTY_LIST,
            Collections.singletonList(ela),
            false,
            "");
    AircraftChangeGroup aircraftChangeGroup = createAircraftChangeGroup(aircraft, null);
    ChangeGroup changeGroup =
        createChangeGroup("Airbus 1", Collections.singletonList(aircraftChangeGroup), project);
    existingChange.setChangeGroup(changeGroup);

    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    subject.update(updatedChange, updatedChange.getId());

    verify(mockChangeRepo, times(1)).findById(isA(UUID.class));
  }

  @Test
  public void
      updateChange_when_existing_component_change_edit_and_change_delete_then_update_action() {
    String userId = ELA_TEST_USER_ID;
    ComponentChange existingComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            false,
            690D,
            null);

    Change existingChange =
        createChange(ActionType.EDIT, userId, null, existingComponentChange, "8XU1", "1IWXP");

    ComponentChange newComponentChange =
        createComponentChange(
            "BTC 1 GND SPLY INTERMITTENT",
            false,
            "2422",
            "8XU1_EDIT",
            ElectricalPhase.AC3,
            "721VU",
            true,
            690D,
            null);
    Change updatedChange =
        createChange(ActionType.DELETE, userId, null, newComponentChange, "", "1IWXP");
    updatedChange.setId(existingChange.getId());

    // add change group to change
    Fleet fleet = createFleet(1L, "A123-999", "Airbus", false, null, "Airbus", "Airbus");
    Ela ela = createEla(1L, null, Collections.emptyList(), "ELA");
    Aircraft aircraft =
        createAircraft(
            1L,
            "variable",
            fleet,
            "123",
            "line",
            "",
            "",
            "123",
            Collections.EMPTY_LIST,
            Collections.singletonList(ela),
            false,
            "");
    AircraftChangeGroup aircraftChangeGroup = createAircraftChangeGroup(aircraft, null);
    ChangeGroup changeGroup =
        createChangeGroup("Airbus 1", Collections.singletonList(aircraftChangeGroup), project);
    existingChange.setChangeGroup(changeGroup);

    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    subject.update(updatedChange, updatedChange.getId());

    verify(mockChangeRepo, times(1)).findById(isA(UUID.class));
  }

  @Test
  public void updateChange_when_node_change_then_update() {
    String userId = ELA_TEST_USER_ID;
    NodeChange existingNodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "1XP_MOD",
            100D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);
    Change existingChange =
        createChange(ActionType.ADD, userId, existingNodeChange, null, "", "1XP");

    when(mockChangeRepo.findById(any(UUID.class))).thenReturn(Optional.of(existingChange));

    NodeChange newNodeChange =
        createNodeChange(
            200D,
            NodeType.BUS,
            true,
            false,
            "1XP_MOD",
            200D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    Change updatedChange = createChange(ActionType.EDIT, userId, newNodeChange, null, "", "1XP");
    updatedChange.setId(existingChange.getId());

    subject.update(updatedChange, updatedChange.getId());

    verify(mockChangeRepo, times(1)).findById(isA(UUID.class));
  }
  /** update Section (end) */
  private Project createProject(
      UUID id,
      String title,
      String nbr,
      String maintDesc,
      Instant started,
      List<ChangeGroup> changeGroups) {
    Project project = new Project();
    project.setId(id);
    project.setTitle(title);
    project.setNumber(nbr);
    project.setMaintenanceDescription(maintDesc);
    project.setStarted(started);

    if (changeGroups != null && !changeGroups.isEmpty()) {
      project.setChangeGroups(changeGroups);
    }

    return project;
  }

  private ChangeGroup createChangeGroup(
      String name, List<AircraftChangeGroup> aircraftChangeGroups, Project projectEntity) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setId(UUID.randomUUID());
    changeGroup.setName(name);
    if (projectEntity != null) {
      changeGroup.setProject(projectEntity);
    }
    if (aircraftChangeGroups != null && !aircraftChangeGroups.isEmpty()) {
      changeGroup.setAircraftChangeGroups(aircraftChangeGroups);
    }
    return changeGroup;
  }

  private ChangeGroupNodeDto createChangeGroupNodeDto(
      ActionType action,
      Double busRating,
      boolean isGlobal,
      String name,
      NodeType nodeType,
      Double nominalPower,
      boolean normalTr,
      boolean requiresApproval,
      boolean sheddable,
      Double voltage,
      ElectricalPhase voltageType,
      List<ChangeGroupNodeDto> childDtos,
      ElectricalPhase electricalPhase) {
    ChangeGroupNodeDto changeGroupNodeDto = new ChangeGroupNodeDto();
    changeGroupNodeDto.setAction(action);
    changeGroupNodeDto.setBusRating(busRating);
    changeGroupNodeDto.setIsGlobal(isGlobal);
    changeGroupNodeDto.setName(name);
    changeGroupNodeDto.setNodeType(nodeType);
    changeGroupNodeDto.setNominalPower(nominalPower);
    changeGroupNodeDto.setNormalTr(normalTr);
    changeGroupNodeDto.setRequiresApproval(requiresApproval);
    changeGroupNodeDto.setSheddable(sheddable);
    changeGroupNodeDto.setVoltage(voltage);
    changeGroupNodeDto.setVoltageType(voltageType);
    changeGroupNodeDto.setElectricalPhase(electricalPhase);
    if (childDtos != null && !childDtos.isEmpty()) {
      changeGroupNodeDto.setChangeGroupNodeDto(childDtos);
    }
    return changeGroupNodeDto;
  }

  private ChangeGroupNodeDto createChangeGroupNodeDtoTree(
      String topLevelName, String secondLevelName, String thirdLevelName) {
    ChangeGroupNodeDto thirdLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            thirdLevelName,
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.emptyList(),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto secondLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            secondLevelName,
            NodeType.BUS,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(thirdLevel),
            ElectricalPhase.AC3);
    ChangeGroupNodeDto topLevel =
        createChangeGroupNodeDto(
            null,
            0D,
            true,
            topLevelName,
            NodeType.GENERATOR,
            0D,
            true,
            true,
            false,
            100D,
            ElectricalPhase.AC3,
            Collections.singletonList(secondLevel),
            ElectricalPhase.AC3);
    return topLevel;
  }

  private Change createChange(
      ActionType actionType,
      String changer,
      NodeChange nodeChange,
      ComponentChange componentChange,
      String componentElectIdent,
      String nodeName) {
    Change change = new Change();
    change.setAction(actionType);
    change.setChanger(changer);
    change.setNodeName(nodeName);

    if (componentChange != null) {
      change.setComponentChange(componentChange);
      change.setComponentElectIdent(componentElectIdent);
    }

    if (nodeChange != null) {
      change.setNodeChange(nodeChange);
    }

    return change;
  }

  private ComponentChange createComponentChange(
      String name,
      boolean clipsed,
      String ata,
      String electIdent,
      ElectricalPhase electricalPhase,
      String panel,
      boolean sheddable,
      Double nomPower,
      List<LoadChange> loadChanges) {
    ComponentChange componentChange = new ComponentChange();
    componentChange.setName(name);
    componentChange.setClipsed(clipsed);
    componentChange.setAta(ata);
    componentChange.setElectIdent(electIdent);
    componentChange.setElectricalPhase(electricalPhase);
    componentChange.setPanel(panel);
    componentChange.setSheddable(sheddable);
    componentChange.setNominalPower(nomPower);

    if (loadChanges != null && !loadChanges.isEmpty()) {
      componentChange.setLoadChanges(loadChanges);
    }

    return componentChange;
  }

  private NodeChange createNodeChange(
      Double busRating,
      NodeType nodeType,
      boolean sheddable,
      boolean reqApproval,
      String name,
      Double nomPower,
      Double voltage,
      ElectricalPhase voltageType,
      ElectricalPhase electricalPhase) {
    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(busRating);
    nodeChange.setSheddable(sheddable);
    nodeChange.setNodeType(nodeType);
    nodeChange.setRequiresApproval(reqApproval);
    nodeChange.setName(name);
    nodeChange.setNominalPower(nomPower);
    nodeChange.setVoltage(voltage);
    nodeChange.setVoltageType(voltageType);
    nodeChange.setElectricalPhase(electricalPhase);

    return nodeChange;
  }

  private Aircraft createAircraft(
      Long id,
      String variableNbr,
      Fleet fleet,
      String aircraftShipNo,
      String lineNumber,
      String origWorkbookFilename,
      String registrationNumber,
      String serialNumber,
      List<AircraftChangeGroup> aircraftChangeGroups,
      List<Ela> elas,
      boolean archived,
      String origWorkBookchecksum) {
    Aircraft aircraft = new Aircraft();
    aircraft.setId(id);
    aircraft.setVariableNumber(variableNbr);
    if (fleet != null) {
      aircraft.setFleet(fleet);
    }
    aircraft.setAircraftShipNo(aircraftShipNo);
    aircraft.setLineNumber(lineNumber);
    aircraft.setOrigWorkbookFilename(origWorkbookFilename);
    aircraft.setRegistrationNumber(registrationNumber);
    aircraft.setSerialNumber(serialNumber);
    if (aircraftChangeGroups != null && !aircraftChangeGroups.isEmpty()) {
      aircraft.setAircraftChangeGroups(aircraftChangeGroups);
    }
    aircraft.setArchived(archived);
    aircraft.setOrigWorkBookchecksum(origWorkBookchecksum);
    if (elas != null && !elas.isEmpty()) {
      for (Ela ela : elas) {
        aircraft.addEla(ela);
      }
    }
    return aircraft;
  }

  private AircraftChangeGroup createAircraftChangeGroup(
      Aircraft aircraft, ChangeGroup changeGroup) {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setId(UUID.randomUUID());

    if (aircraft != null) {
      aircraftChangeGroup.setAircraft(aircraft);
    }
    if (changeGroup != null) {
      aircraftChangeGroup.setChangeGroup(changeGroup);
    }
    return aircraftChangeGroup;
  }

  private Component createComponent(
      Long id,
      Boolean intermittent,
      Integer displayOrder,
      List<Load> loads,
      Boolean sheddable,
      ElectricalPhase electricalPhase,
      String name,
      Double nominalPower,
      String electIdent,
      String ata,
      Node node,
      String panel,
      boolean clipsed) {
    Component component = new Component();
    component.setId(id);
    component.setIntermittent(intermittent);
    component.setDisplayOrder(displayOrder);
    if (loads != null && !loads.isEmpty()) {
      component.setLoads(loads);
    }
    component.setSheddable(sheddable);
    component.setElectricalPhase(electricalPhase);
    component.setName(name);
    component.setNominalPower(nominalPower);
    component.setElectIdent(electIdent);
    component.setAta(ata);
    if (node != null) {
      component.setNode(node);
    }
    component.setPanel(panel);
    component.setClipsed(clipsed);
    return component;
  }

  private Ela createEla(Long id, Aircraft aircraft, List<Node> nodes, String name) {
    Ela ela = new Ela();
    ela.setId(id);
    ela.setAircraft(aircraft);
    ela.setName(name);
    if (nodes != null && !nodes.isEmpty()) {
      ela.setNodes(nodes);
    }
    return ela;
  }

  private Fleet createFleet(
      Long id,
      String name,
      String busStructureBucket,
      boolean archived,
      Fleet parentFleet,
      String structureName,
      String manufacturer) {
    Fleet fleet = new Fleet();
    fleet.setId(id);
    fleet.setName(name);
    fleet.setBusStructureBucket(busStructureBucket);
    fleet.setArchived(archived);
    if (parentFleet != null) {
      fleet.setParentFleet(parentFleet);
    }
    fleet.setStructureName(structureName);
    fleet.setManufacturer(manufacturer);
    return fleet;
  }

  private List<Load> createLoadsByManufacturer(
      String manufacturer, Double va, Double powerFactor, String fleet) {
    List<Load> loads = new ArrayList<>();

    List<FlightPhaseDto> flightPhases =
        FlightPhase.getFlightPhases(manufacturer, false, fleet, false);
    List<String> operatingModes = OperatingMode.getOperatingModes(manufacturer, fleet);

    for (String operatingMode : operatingModes) {
      for (FlightPhaseDto flightPhase : flightPhases) {
        Load load = new Load();
        load.setId(new Random().nextLong());
        load.setVa(va);
        load.setFlightPhase(flightPhase.getName());
        load.setOperatingMode(operatingMode);
        load.setPowerFactor(powerFactor);
        loads.add(load);
      }
    }

    return loads;
  }

  private List<LoadChange> createLoadChangesByManufacturer(
      String manufacturer, Double va, Double powerFactor, String fleet) {
    List<LoadChange> loadChanges = new ArrayList<>();

    List<String> operatingModes = OperatingMode.getOperatingModes(manufacturer, fleet);
    List<FlightPhaseDto> flightPhases =
        FlightPhase.getFlightPhases(manufacturer, false, fleet, false);

    for (String operatingMode : operatingModes) {
      for (FlightPhaseDto flightPhase : flightPhases) {
        LoadChange loadChange = new LoadChange();
        loadChange.setVa(va);
        loadChange.setFlightPhase(flightPhase.getName());
        loadChange.setOperatingMode(operatingMode);
        loadChange.setPowerFactor(powerFactor);
        loadChanges.add(loadChange);
      }
    }

    return loadChanges;
  }

  private Node createNode(
      Long id,
      List<Node> subNodes,
      Node parentNode,
      boolean shedabble,
      Ela ela,
      boolean requiresApproval,
      NodeType nodeType,
      Double busRating,
      Integer displayOrder,
      String name,
      Double nominalPower,
      Double voltage,
      ElectricalPhase voltageType,
      List<Component> components,
      boolean normalTr) {
    Node node = new Node();
    node.setId(id);
    if (parentNode != null) {
      node.setParentNode(parentNode);
    }
    if (subNodes != null && !subNodes.isEmpty()) {
      node.setSubNodes(subNodes);
    }
    node.setSheddable(shedabble);
    if (ela != null) {
      node.setEla(ela);
    }
    node.setRequiresApproval(requiresApproval);
    node.setNodeType(nodeType);
    node.setBusRating(busRating);
    node.setDisplayOrder(displayOrder);
    node.setName(name);
    node.setNominalPower(nominalPower);
    node.setVoltage(voltage);
    node.setVoltageType(voltageType);
    if (voltageType == ElectricalPhase.AC) {
      node.setElectricalPhase(ElectricalPhase.ACA);
    }
    node.setComponents(components);
    node.setNormalTr(normalTr);
    return node;
  }

  private Project createProjectWithChangeGroupsAndEffectivities(
      UUID id, String projectName, String number, String maintDesc, Instant started) {
    // Loads
    List<Load> loads1 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads2 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads3 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads4 = createLoadsByManufacturer("airbus", 0.5D, 10d, "A330");

    // Components
    List<Component> components1 = new ArrayList<>();
    components1.add(
        createComponent(
            1L,
            true,
            1,
            null,
            false,
            ElectricalPhase.AC,
            "BTC 1 GND SPLY INTERMITTENT",
            690D,
            "8XU1",
            "2422",
            null,
            "721VU",
            false));
    components1.add(
        createComponent(
            2L,
            true,
            2,
            null,
            false,
            ElectricalPhase.ACA,
            "ESS BUS NORM SWTG INTMT",
            8D,
            "5XC",
            "2425",
            null,
            "721VU",
            false));
    components1.add(
        createComponent(
            3L,
            false,
            3,
            loads1,
            false,
            ElectricalPhase.ACA,
            "GPCU AC VOLT SNSG",
            8D,
            "27XG",
            "2441",
            null,
            "721VU",
            true));

    List<Component> components2 = new ArrayList<>();
    components2.add(
        createComponent(
            1L,
            true,
            1,
            loads2,
            false,
            ElectricalPhase.AC,
            "L RECIRC FAN",
            9801D,
            "1HG1",
            "2121",
            null,
            "715VU",
            false));
    components2.add(
        createComponent(
            2L,
            true,
            2,
            loads3,
            false,
            ElectricalPhase.ACA,
            "ESS BUS NORM SPLY",
            0D,
            "1XC",
            "2425",
            null,
            "715VU",
            false));
    components2.add(
        createComponent(
            3L,
            false,
            3,
            loads4,
            false,
            ElectricalPhase.ACA,
            "GALLEY AFT",
            9750D,
            "12MC",
            "2456",
            null,
            "715VU",
            false));

    // Nodes
    List<Node> nodes1 = new ArrayList<>();
    Node rootLevelNode1 =
        createNode(
            1L,
            null,
            null,
            false,
            null,
            false,
            NodeType.GENERATOR,
            null,
            1,
            "GEN 1",
            115000D,
            115D,
            ElectricalPhase.AC3,
            null,
            false);
    nodes1.add(rootLevelNode1);
    nodes1.add(
        createNode(
            2L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            1,
            "1IWXP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));
    nodes1.add(
        createNode(
            3L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            2,
            "1XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));
    nodes1.add(
        createNode(
            4L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            3,
            "101XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));

    List<Node> nodes2 = new ArrayList<>();
    Node rootLevelNode2 =
        createNode(
            1L,
            null,
            null,
            false,
            null,
            false,
            NodeType.GENERATOR,
            null,
            1,
            "GEN 1",
            115000D,
            115D,
            ElectricalPhase.AC3,
            null,
            false);
    nodes2.add(rootLevelNode1);
    nodes2.add(
        createNode(
            2L,
            null,
            rootLevelNode2,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            1,
            "1IWXP",
            null,
            115D,
            ElectricalPhase.AC3,
            components2,
            false));
    nodes2.add(
        createNode(
            3L,
            null,
            rootLevelNode2,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            2,
            "1XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components2,
            false));

    // Airbus Fleet
    Fleet parentFleet1 =
        createFleet(1L, "A330", "Airbus 1", false, null, "A330-Node-Structure", "Airbus");
    Fleet childFleet1a =
        createFleet(2L, "A330-200", null, false, parentFleet1, "A330-Node-Structure", "Airbus");
    Fleet childFleet1b =
        createFleet(3L, "A330-300", null, false, parentFleet1, "A330-Node-Structure", "Airbus");

    // Boeing Fleet
    Fleet parentFleet2 = createFleet(1L, "B767", "Boeing 1", false, null, null, "Boeing");
    Fleet childFleet2a = createFleet(2L, "B767-300", null, false, parentFleet2, null, "Boeing");
    Fleet childFleet2b = createFleet(3L, "B767-300ER", null, false, parentFleet2, null, "Boeing");

    // Ela
    Ela ela1 = createEla(1L, null, nodes1, "33-525112-20_ELA_AppendixA_3315_ELA");
    Ela ela2 = createEla(2L, null, nodes2, "33-525113-20_ELA_AppendixA_3356_ELA");

    // aircrafts
    Aircraft aircraft1 =
        createAircraft(
            1L,
            "N/A",
            childFleet1a,
            "3356",
            "N/A",
            "33-525113-20_ELA_AppendixA_3356.xlsx",
            "N856NW",
            "0631",
            null,
            Lists.newArrayList(ela1),
            false,
            "7c3461a3ea73eae1943aa6f1acfe8600");
    Aircraft aircraft2 =
        createAircraft(
            2L,
            "N/A",
            childFleet1b,
            "3315",
            "N/A",
            "33-525112-20_ELA_AppendixA_3315.xlsx",
            "N815NW",
            "0817",
            null,
            Lists.newArrayList(ela2),
            false,
            "a066a86801ffa634cf6594aab164f6ca");
    Aircraft aircraft3 =
        createAircraft(
            3L,
            "VN251",
            childFleet2a,
            "171",
            "304",
            null,
            "N171DN",
            "24759",
            null,
            Lists.newArrayList(ela2),
            false,
            null);

    // aircraft change group
    AircraftChangeGroup aircraftChangeGroup1 = createAircraftChangeGroup(aircraft1, null);
    AircraftChangeGroup aircraftChangeGroup2 = createAircraftChangeGroup(aircraft2, null);
    AircraftChangeGroup aircraftChangeGroup3 = createAircraftChangeGroup(aircraft3, null);

    // create Project
    Project project = createProject(id, projectName, number, maintDesc, started, null);

    // change groups
    ChangeGroup changeGroup1 =
        createChangeGroup(
            "Airbus 1", Lists.newArrayList(aircraftChangeGroup1, aircraftChangeGroup2), project);
    ChangeGroup changeGroup2 =
        createChangeGroup("Boeing 1", Lists.newArrayList(aircraftChangeGroup3), project);

    project.setChangeGroups(Lists.newArrayList(changeGroup1, changeGroup2));

    return project;
  }
}
