package com.seatec.ela.app.controller;

import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.ProjectWrapperDTO;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class PaginationControllerIT extends AbstractControllerIntegrationTest {

  private static final String ENDPOINT_URL = BASE_URL + "/service/projects/";

  @Autowired private ProjectRepo projectRepo;

  String emptyUserId;
  private HttpEntity<String> viewerEntity;

  @Before
  public void setup() throws Exception {
    viewerEntity = createHttpEntity(Collections.singletonList(VIEWER_ID));
    emptyUserId = getUserId(createHttpEntity(null));
  }

  // pagination for getting approved projects (project history)
  @Test
  public void
      shouldGetApprovedPaginatedProjectsFilteredByDescriptionWhenCallingGetApprovedProjects() {

    // create 3 approved projects
    Project one = createProject("1", "2");
    one.setApproved(Instant.now());
    one.setChecked(Instant.now());
    one.setApprovalEngineer(emptyUserId);
    one.setCheckEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    projectRepo.save(one);

    Project two = createProject("3", "1");
    two.setApproved(Instant.now());
    two.setChecked(Instant.now());
    two.setApprovalEngineer(emptyUserId);
    two.setCheckEngineer(emptyUserId);
    two.setSubmitted(Instant.now());
    projectRepo.save(two);

    Project three = createProject("4", "3");
    three.setApproved(Instant.now());
    three.setChecked(Instant.now());
    three.setApprovalEngineer(emptyUserId);
    three.setCheckEngineer(emptyUserId);
    three.setSubmitted(Instant.now());
    projectRepo.save(three);

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage1 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?description=four&page=1&size=2",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage1.getBody().getContents().size(), 2);
    assertEquals(responsePage1.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage1.getBody().getTotalRecords(), new Long(3));

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage2 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?description=four&page=2&size=2",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage2.getBody().getContents().size(), 1);
    assertEquals(responsePage2.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage2.getBody().getTotalRecords(), new Long(3));

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage3 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?description=four&page=3&size=2",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage3.getStatusCode(), HttpStatus.BAD_REQUEST);

    // test sorting no pagination - ascending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage4 =
        restTemplate.exchange(
            ENDPOINT_URL
                + "/approved?description=four&page=1&size=3&sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage4.getBody().getContents().size(), 3);
    assertEquals(responsePage4.getBody().getTotalPages(), new Integer(1));
    assertEquals(responsePage4.getBody().getTotalRecords(), new Long(3));
    for (int inx = 1; inx <= 3; inx++) {
      String number = responsePage4.getBody().getContents().get(inx - 1).getNumber();
      assertEquals(number, Integer.toString(inx));
    }

    // test sorting no pagination - decending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage5 =
        restTemplate.exchange(
            ENDPOINT_URL
                + "/approved?description=four&page=1&size=3&sortField=number&sortAscending=false",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage5.getBody().getContents().size(), 3);
    assertEquals(responsePage5.getBody().getTotalPages(), new Integer(1));
    assertEquals(responsePage5.getBody().getTotalRecords(), new Long(3));
    for (int inx = 1; inx <= 3; inx++) {
      String number = responsePage5.getBody().getContents().get(inx - 1).getNumber();
      assertEquals(number, Integer.toString(4 - inx));
    }

    // test sorting with pagination - ascending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage6 =
        restTemplate.exchange(
            ENDPOINT_URL
                + "/approved?description=four&page=2&size=2&sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage6.getBody().getContents().get(0).getNumber(), "3");

    // test sorting with pagination - decending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage7 =
        restTemplate.exchange(
            ENDPOINT_URL
                + "/approved?description=four&page=2&size=2&sortField=number&sortAscending=false",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage7.getBody().getContents().get(0).getNumber(), "1");
  }

  // pagination for getting all projects
  @Test
  public void shouldGetPaginatedProjectsWhenCallingGetAllProjects() {
    projectRepo.save(createProject("1"));
    projectRepo.save(createProject("2"));
    projectRepo.save(createProject("3"));
    projectRepo.save(createProject("4"));
    projectRepo.save(createProject("5"));

    ResponseEntity<PaginationDTO<ProjectDTO>> responsePage1 =
        restTemplate.exchange(
            ENDPOINT_URL + "?page=1&size=3",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
    assertEquals(responsePage1.getBody().getContents().size(), 3);
    assertEquals(responsePage1.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage1.getBody().getTotalRecords(), new Long(5));

    ResponseEntity<PaginationDTO<ProjectDTO>> responsePage2 =
        restTemplate.exchange(
            ENDPOINT_URL + "?page=2&size=3",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
    assertEquals(responsePage2.getBody().getContents().size(), 2);
    assertEquals(responsePage2.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage2.getBody().getTotalRecords(), new Long(5));

    ResponseEntity<PaginationDTO<ProjectDTO>> responsePage3 =
        restTemplate.exchange(
            ENDPOINT_URL + "?page=3&size=3",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
    assertEquals(responsePage3.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  // pagination is required - fail input validation when calling all projects without pagination
  @Test
  public void shouldFailInputValidationWhenCallingGetAppProjectsWithNoPagination() {
    ResponseEntity<PaginationDTO<ProjectDTO>> responsePage =
        restTemplate.exchange(
            ENDPOINT_URL,
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
    assertEquals(responsePage.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  // pagination for getting my projects
  @Test
  public void shouldGetPaginatedProjectsWhenCallingMyProjects() throws Exception {
    HttpEntity<String> entity =
        createHttpEntity(
            Collections.singletonList(VIEWER_ID),
            env.getRequiredProperty("auth.authorUsername").trim());
    String userId = getUserId(entity);
    projectRepo.save(createProject(userId, "1"));
    projectRepo.save(createProject(userId, "2"));
    projectRepo.save(createProject(userId, "3"));
    projectRepo.save(createProject(userId, "4"));
    projectRepo.save(createProject(userId, "5"));

    // test pagination (page 1) and sorting in ascending order
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage1 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?page=1&size=3&sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage1.getBody().getContents().size(), 3);
    assertEquals(responsePage1.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage1.getBody().getTotalRecords(), new Long(5));

    List<String> projectIds1 =
        responsePage1.getBody().getContents().stream()
            .map(p -> p.getNumber())
            .collect(Collectors.toList());
    assertThat(projectIds1, containsInAnyOrder("1", "2", "3"));

    // test pagination (page 2) and sorting in ascending order
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage2 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?page=2&size=3&sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage2.getBody().getContents().size(), 2);
    assertEquals(responsePage2.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage2.getBody().getTotalRecords(), new Long(5));

    List<String> projectIds2 =
        responsePage2.getBody().getContents().stream()
            .map(p -> p.getNumber())
            .collect(Collectors.toList());
    assertThat(projectIds2, containsInAnyOrder("4", "5"));

    // test pagination (page 3) and sorting in ascending order
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage3 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?page=3&size=3&sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage3.getStatusCode(), HttpStatus.BAD_REQUEST);

    // test pagination (page 1) and sorting in decending order
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage4 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?page=1&size=3&sortField=number&sortAscending=false",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage4.getBody().getContents().size(), 3);
    assertEquals(responsePage4.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage4.getBody().getTotalRecords(), new Long(5));
    List<String> projectIds4 =
        responsePage4.getBody().getContents().stream()
            .map(p -> p.getNumber())
            .collect(Collectors.toList());
    assertThat(projectIds4, containsInAnyOrder("3", "4", "5"));

    // test pagination (page 2) and sorting in decending order
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage5 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?page=2&size=3&sortField=number&sortAscending=false",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage5.getBody().getContents().size(), 2);
    assertEquals(responsePage5.getBody().getTotalPages(), new Integer(2));
    assertEquals(responsePage5.getBody().getTotalRecords(), new Long(5));
    List<String> projectIds5 =
        responsePage5.getBody().getContents().stream()
            .map(p -> p.getNumber())
            .collect(Collectors.toList());
    assertThat(projectIds5, containsInAnyOrder("1", "2"));

    // test no pagination
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePage6 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=number&sortAscending=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePage6.getBody().getContents().size(), 5);
  }

  @Test
  public void shouldGetPaginatedProjectsWhenCallingPendingReviewProjects() {
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    projectRepo.save(one);

    Project two = createProject("2");
    two.setApprovalEngineer(emptyUserId);
    two.setSubmitted(Instant.now());
    two.setChecked(Instant.now());
    projectRepo.save(two);

    Project three = createProject("3");
    three.setApprovalEngineer(emptyUserId);
    three.setSubmitted(Instant.now());
    three.setChecked(Instant.now());
    projectRepo.save(three);

    ResponseEntity<PaginationDTO<ProjectWrapperDTO>> response1 =
        restTemplate.exchange(
            ENDPOINT_URL + "/pendingreview?page=1&size=2",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectWrapperDTO>>() {});
    PaginationDTO<ProjectWrapperDTO> dto1 = response1.getBody();
    assertEquals(dto1.getContents().get(0).getApprover().size(), 2);
    assertEquals(dto1.getTotalPages(), new Integer(2));
    assertEquals(dto1.getTotalRecords(), new Long(3));

    ResponseEntity<PaginationDTO<ProjectWrapperDTO>> response2 =
        restTemplate.exchange(
            ENDPOINT_URL + "/pendingreview?page=2&size=2",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectWrapperDTO>>() {});
    PaginationDTO<ProjectWrapperDTO> dto2 = response2.getBody();
    assertEquals(dto2.getContents().get(0).getApprover().size(), 1);
    assertEquals(dto2.getTotalPages(), new Integer(2));
    assertEquals(dto2.getTotalRecords(), new Long(3));
  }
}
