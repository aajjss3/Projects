package com.seatec.ela.app.service.project.change;

import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.config.ModelMapperConfiguration;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.FlightPhaseDto;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.project.change.ChangeComment;
import com.seatec.ela.app.model.repository.project.change.ChangeCommentRepo;
import com.seatec.ela.app.service.KeycloakService;
import com.seatec.ela.app.service.contract.IKeycloakService;
import com.seatec.ela.app.service.contract.project.change.IChangeCommentService;
import com.seatec.ela.app.service.contract.project.change.IChangeService;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.FlightPhase;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ChangeCommentServiceTest {
  private static final String DEFAULT_USER_ID = "00000-00000-00000-00000-00000";

  private IChangeCommentService subject;

  private IKeycloakService mockKeycloakService;

  private IChangeService mockChangeService;

  private ChangeCommentRepo mockChangeCommentRepo;

  private Project project;

  private Change change;

  @Rule public ExpectedException exceptionRule = ExpectedException.none();

  @Before
  public void setup() {
    mockChangeService = mock(ChangeService.class);
    mockKeycloakService = mock(KeycloakService.class);
    mockChangeCommentRepo = mock(ChangeCommentRepo.class);
    ModelMapperConfiguration config = new ModelMapperConfiguration();

    subject =
        new ChangeCommentService(
            mockChangeService, mockKeycloakService, mockChangeCommentRepo, config.getAllMapper());

    // initialize data
    createProjectWithChangeGroupsAndEffectivities(
        UUID.randomUUID(), "project1", "1", "maintenance desc", Instant.now());
  }

  @Test
  public void when_deleteByChangeId_then_return_2xx() {
    // add comments
    List<ChangeComment> comments = new ArrayList<>();
    comments.add(createChangeComment(change, "I decline"));
    change.setComments(comments);
    project.getChangeGroups().get(0).setChanges(Collections.singletonList(change));

    // mocks
    when(mockChangeService.findById(any(UUID.class))).thenReturn(Optional.of(change));
    doNothing().when(mockChangeCommentRepo).deleteByChangeId(any(UUID.class));

    // act
    subject.deleteAllByChangeId(
        project.getId(), project.getChangeGroups().get(0).getId(), change.getId());

    // assert
    verify(mockChangeCommentRepo, times(1)).deleteByChangeId(isA(UUID.class));
  }

  @Test
  public void when_deleteByChangeId_and_changeGroupEntity_not_match_then_throw_notFoundException() {
    // arrange
    UUID randomUUID = UUID.randomUUID();

    // mocks
    when(mockChangeService.findById(any(UUID.class))).thenReturn(Optional.of(change));

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Unable to complete. Change Group (" + randomUUID + ") not found.");

    // act
    // pass random UUID for ChangeGroup Id - should not find match and throw exception
    subject.deleteAllByChangeId(project.getId(), randomUUID, randomUUID);

    // assert
    // throw NotFoundException()
  }

  @Test
  public void when_deleteByChangeId_and_changeEntity_not_match_then_throw_notFoundException() {
    // arrange
    UUID randomUUID = UUID.randomUUID();

    // mocks
    when(mockChangeService.findById(any(UUID.class))).thenReturn(Optional.empty());

    // calling this endpoint with these values should throw an exception
    exceptionRule.expect(NotFoundException.class);
    exceptionRule.expectMessage("Unable to complete. Change (" + randomUUID + ") not found.");

    // act
    // pass random UUID for ChangeGroup Id - should not find match and throw exception
    subject.deleteAllByChangeId(
        project.getId(), project.getChangeGroups().get(0).getId(), randomUUID);

    // assert
    // throw NotFoundException()
  }

  private ChangeComment createChangeComment(Change change, String commentText) {
    ChangeComment comment = new ChangeComment();
    comment.setChange(change);
    comment.setAuthor(DEFAULT_USER_ID);
    comment.setComment(commentText);
    comment.setDisplayName("Test User");
    return comment;
  }

  /** update Section (end) */
  private Project createProject(
      UUID id,
      String title,
      String nbr,
      String maintDesc,
      Instant started,
      List<ChangeGroup> changeGroups) {
    Project project = new Project();
    project.setId(id);
    project.setTitle(title);
    project.setNumber(nbr);
    project.setMaintenanceDescription(maintDesc);
    project.setStarted(started);

    if (changeGroups != null && !changeGroups.isEmpty()) {
      project.setChangeGroups(changeGroups);
    }

    return project;
  }

  private ChangeGroup createChangeGroup(
      String name, List<AircraftChangeGroup> aircraftChangeGroups, Project projectEntity) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setId(UUID.randomUUID());
    changeGroup.setName(name);
    if (projectEntity != null) {
      changeGroup.setProject(projectEntity);
    }
    if (aircraftChangeGroups != null && !aircraftChangeGroups.isEmpty()) {
      changeGroup.setAircraftChangeGroups(aircraftChangeGroups);
    }
    return changeGroup;
  }

  private Change createChange(
      ActionType actionType,
      String changer,
      NodeChange nodeChange,
      ComponentChange componentChange,
      List<ChangeComment> comments,
      String componentElectIdent,
      String nodeName,
      ChangeGroup changeGroup) {
    Change change = new Change();
    change.setAction(actionType);
    change.setChanger(changer);
    change.setNodeName(nodeName);
    change.setComments(comments);
    change.setChangeGroup(changeGroup);

    if (componentChange != null) {
      change.setComponentChange(componentChange);
      change.setComponentElectIdent(componentElectIdent);
    }

    if (nodeChange != null) {
      change.setNodeChange(nodeChange);
    }

    return change;
  }

  private NodeChange createNodeChange(
      Double busRating,
      NodeType nodeType,
      boolean sheddable,
      boolean reqApproval,
      String name,
      Double nomPower,
      Double voltage,
      ElectricalPhase voltageType,
      ElectricalPhase electricalPhase) {
    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(busRating);
    nodeChange.setSheddable(sheddable);
    nodeChange.setNodeType(nodeType);
    nodeChange.setRequiresApproval(reqApproval);
    nodeChange.setName(name);
    nodeChange.setNominalPower(nomPower);
    nodeChange.setVoltage(voltage);
    nodeChange.setVoltageType(voltageType);
    nodeChange.setElectricalPhase(electricalPhase);

    return nodeChange;
  }

  private Aircraft createAircraft(
      Long id,
      String variableNbr,
      Fleet fleet,
      String aircraftShipNo,
      String lineNumber,
      String origWorkbookFilename,
      String registrationNumber,
      String serialNumber,
      List<AircraftChangeGroup> aircraftChangeGroups,
      List<Ela> elas,
      boolean archived,
      String origWorkBookchecksum) {
    Aircraft aircraft = new Aircraft();
    aircraft.setId(id);
    aircraft.setVariableNumber(variableNbr);
    if (fleet != null) {
      aircraft.setFleet(fleet);
    }
    aircraft.setAircraftShipNo(aircraftShipNo);
    aircraft.setLineNumber(lineNumber);
    aircraft.setOrigWorkbookFilename(origWorkbookFilename);
    aircraft.setRegistrationNumber(registrationNumber);
    aircraft.setSerialNumber(serialNumber);
    if (aircraftChangeGroups != null && !aircraftChangeGroups.isEmpty()) {
      aircraft.setAircraftChangeGroups(aircraftChangeGroups);
    }
    aircraft.setArchived(archived);
    aircraft.setOrigWorkBookchecksum(origWorkBookchecksum);
    if (elas != null && !elas.isEmpty()) {
      for (Ela ela : elas) {
        aircraft.addEla(ela);
      }
    }
    return aircraft;
  }

  private AircraftChangeGroup createAircraftChangeGroup(
      Aircraft aircraft, ChangeGroup changeGroup) {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setId(UUID.randomUUID());

    if (aircraft != null) {
      aircraftChangeGroup.setAircraft(aircraft);
    }
    if (changeGroup != null) {
      aircraftChangeGroup.setChangeGroup(changeGroup);
    }
    return aircraftChangeGroup;
  }

  private Component createComponent(
      Long id,
      Boolean intermittent,
      Integer displayOrder,
      List<Load> loads,
      Boolean sheddable,
      ElectricalPhase electricalPhase,
      String name,
      Double nominalPower,
      String electIdent,
      String ata,
      Node node,
      String panel,
      boolean clipsed) {
    Component component = new Component();
    component.setId(id);
    component.setIntermittent(intermittent);
    component.setDisplayOrder(displayOrder);
    if (loads != null && !loads.isEmpty()) {
      component.setLoads(loads);
    }
    component.setSheddable(sheddable);
    component.setElectricalPhase(electricalPhase);
    component.setName(name);
    component.setNominalPower(nominalPower);
    component.setElectIdent(electIdent);
    component.setAta(ata);
    if (node != null) {
      component.setNode(node);
    }
    component.setPanel(panel);
    component.setClipsed(clipsed);
    return component;
  }

  private Ela createEla(Long id, Aircraft aircraft, List<Node> nodes, String name) {
    Ela ela = new Ela();
    ela.setId(id);
    ela.setAircraft(aircraft);
    ela.setName(name);
    if (nodes != null && !nodes.isEmpty()) {
      ela.setNodes(nodes);
    }
    return ela;
  }

  private Fleet createFleet(
      Long id,
      String name,
      String busStructureBucket,
      boolean archived,
      Fleet parentFleet,
      String structureName,
      String manufacturer) {
    Fleet fleet = new Fleet();
    fleet.setId(id);
    fleet.setName(name);
    fleet.setBusStructureBucket(busStructureBucket);
    fleet.setArchived(archived);
    if (parentFleet != null) {
      fleet.setParentFleet(parentFleet);
    }
    fleet.setStructureName(structureName);
    fleet.setManufacturer(manufacturer);
    return fleet;
  }

  private List<Load> createLoadsByManufacturer(
      String manufacturer, Double va, Double powerFactor, String fleet) {
    List<Load> loads = new ArrayList<>();

    List<FlightPhaseDto> flightPhases =
        FlightPhase.getFlightPhases(manufacturer, false, fleet, false);
    List<String> operatingModes = OperatingMode.getOperatingModes(manufacturer, fleet);

    for (String operatingMode : operatingModes) {
      for (FlightPhaseDto flightPhase : flightPhases) {
        Load load = new Load();
        load.setId(new Random().nextLong());
        load.setVa(va);
        load.setFlightPhase(flightPhase.getName());
        load.setOperatingMode(operatingMode);
        load.setPowerFactor(powerFactor);
        loads.add(load);
      }
    }

    return loads;
  }

  private Node createNode(
      Long id,
      List<Node> subNodes,
      Node parentNode,
      boolean shedabble,
      Ela ela,
      boolean requiresApproval,
      NodeType nodeType,
      Double busRating,
      Integer displayOrder,
      String name,
      Double nominalPower,
      Double voltage,
      ElectricalPhase voltageType,
      List<Component> components,
      boolean normalTr) {
    Node node = new Node();
    node.setId(id);
    if (parentNode != null) {
      node.setParentNode(parentNode);
    }
    if (subNodes != null && !subNodes.isEmpty()) {
      node.setSubNodes(subNodes);
    }
    node.setSheddable(shedabble);
    if (ela != null) {
      node.setEla(ela);
    }
    node.setRequiresApproval(requiresApproval);
    node.setNodeType(nodeType);
    node.setBusRating(busRating);
    node.setDisplayOrder(displayOrder);
    node.setName(name);
    node.setNominalPower(nominalPower);
    node.setVoltage(voltage);
    node.setVoltageType(voltageType);
    if (voltageType == ElectricalPhase.AC) {
      node.setElectricalPhase(ElectricalPhase.ACA);
    }
    node.setComponents(components);
    node.setNormalTr(normalTr);
    return node;
  }

  private void createProjectWithChangeGroupsAndEffectivities(
      UUID id, String projectName, String number, String maintDesc, Instant started) {
    // Loads
    List<Load> loads1 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads2 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads3 = createLoadsByManufacturer("airbus", 0D, 10d, "A330");
    List<Load> loads4 = createLoadsByManufacturer("airbus", 0.5D, 10d, "A330");

    // Components
    List<Component> components1 = new ArrayList<>();
    components1.add(
        createComponent(
            1L,
            true,
            1,
            null,
            false,
            ElectricalPhase.AC,
            "BTC 1 GND SPLY INTERMITTENT",
            690D,
            "8XU1",
            "2422",
            null,
            "721VU",
            false));
    components1.add(
        createComponent(
            2L,
            true,
            2,
            null,
            false,
            ElectricalPhase.ACA,
            "ESS BUS NORM SWTG INTMT",
            8D,
            "5XC",
            "2425",
            null,
            "721VU",
            false));
    components1.add(
        createComponent(
            3L,
            false,
            3,
            loads1,
            false,
            ElectricalPhase.ACA,
            "GPCU AC VOLT SNSG",
            8D,
            "27XG",
            "2441",
            null,
            "721VU",
            true));

    List<Component> components2 = new ArrayList<>();
    components2.add(
        createComponent(
            1L,
            true,
            1,
            loads2,
            false,
            ElectricalPhase.AC,
            "L RECIRC FAN",
            9801D,
            "1HG1",
            "2121",
            null,
            "715VU",
            false));
    components2.add(
        createComponent(
            2L,
            true,
            2,
            loads3,
            false,
            ElectricalPhase.ACA,
            "ESS BUS NORM SPLY",
            0D,
            "1XC",
            "2425",
            null,
            "715VU",
            false));
    components2.add(
        createComponent(
            3L,
            false,
            3,
            loads4,
            false,
            ElectricalPhase.ACA,
            "GALLEY AFT",
            9750D,
            "12MC",
            "2456",
            null,
            "715VU",
            false));

    // Nodes
    List<Node> nodes1 = new ArrayList<>();
    Node rootLevelNode1 =
        createNode(
            1L,
            null,
            null,
            false,
            null,
            false,
            NodeType.GENERATOR,
            null,
            1,
            "GEN 1",
            115000D,
            115D,
            ElectricalPhase.AC3,
            null,
            false);
    nodes1.add(rootLevelNode1);
    nodes1.add(
        createNode(
            2L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            1,
            "1IWXP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));
    nodes1.add(
        createNode(
            3L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            2,
            "1XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));
    nodes1.add(
        createNode(
            4L,
            null,
            rootLevelNode1,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            3,
            "101XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components1,
            false));

    List<Node> nodes2 = new ArrayList<>();
    Node rootLevelNode2 =
        createNode(
            1L,
            null,
            null,
            false,
            null,
            false,
            NodeType.GENERATOR,
            null,
            1,
            "GEN 1",
            115000D,
            115D,
            ElectricalPhase.AC3,
            null,
            false);
    nodes2.add(rootLevelNode1);
    nodes2.add(
        createNode(
            2L,
            null,
            rootLevelNode2,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            1,
            "1IWXP",
            null,
            115D,
            ElectricalPhase.AC3,
            components2,
            false));
    nodes2.add(
        createNode(
            3L,
            null,
            rootLevelNode2,
            false,
            null,
            true,
            NodeType.BUS,
            null,
            2,
            "1XP",
            null,
            115D,
            ElectricalPhase.AC3,
            components2,
            false));

    // Airbus Fleet
    Fleet parentFleet1 =
        createFleet(1L, "A330", "Airbus 1", false, null, "A330-Node-Structure", "Airbus");
    Fleet childFleet1a =
        createFleet(2L, "A330-200", null, false, parentFleet1, "A330-Node-Structure", "Airbus");
    Fleet childFleet1b =
        createFleet(3L, "A330-300", null, false, parentFleet1, "A330-Node-Structure", "Airbus");

    // Boeing Fleet
    Fleet parentFleet2 = createFleet(1L, "B767", "Boeing 1", false, null, null, "Boeing");
    Fleet childFleet2a = createFleet(2L, "B767-300", null, false, parentFleet2, null, "Boeing");
    Fleet childFleet2b = createFleet(3L, "B767-300ER", null, false, parentFleet2, null, "Boeing");

    // Ela
    Ela ela1 = createEla(1L, null, nodes1, "33-525112-20_ELA_AppendixA_3315_ELA");
    Ela ela2 = createEla(2L, null, nodes2, "33-525113-20_ELA_AppendixA_3356_ELA");

    // aircrafts
    Aircraft aircraft1 =
        createAircraft(
            1L,
            "N/A",
            childFleet1a,
            "3356",
            "N/A",
            "33-525113-20_ELA_AppendixA_3356.xlsx",
            "N856NW",
            "0631",
            null,
            Lists.newArrayList(ela1),
            false,
            "7c3461a3ea73eae1943aa6f1acfe8600");
    Aircraft aircraft2 =
        createAircraft(
            2L,
            "N/A",
            childFleet1b,
            "3315",
            "N/A",
            "33-525112-20_ELA_AppendixA_3315.xlsx",
            "N815NW",
            "0817",
            null,
            Lists.newArrayList(ela2),
            false,
            "a066a86801ffa634cf6594aab164f6ca");
    Aircraft aircraft3 =
        createAircraft(
            3L,
            "VN251",
            childFleet2a,
            "171",
            "304",
            null,
            "N171DN",
            "24759",
            null,
            Lists.newArrayList(ela2),
            false,
            null);

    // aircraft change group
    AircraftChangeGroup aircraftChangeGroup1 = createAircraftChangeGroup(aircraft1, null);
    AircraftChangeGroup aircraftChangeGroup2 = createAircraftChangeGroup(aircraft2, null);
    AircraftChangeGroup aircraftChangeGroup3 = createAircraftChangeGroup(aircraft3, null);

    // create Project
    project = createProject(id, projectName, number, maintDesc, started, null);

    // change groups
    ChangeGroup changeGroup1 =
        createChangeGroup(
            "Airbus 1", Lists.newArrayList(aircraftChangeGroup1, aircraftChangeGroup2), project);
    ChangeGroup changeGroup2 =
        createChangeGroup("Boeing 1", Lists.newArrayList(aircraftChangeGroup3), project);

    // changes
    NodeChange nodeChange =
        createNodeChange(
            300D,
            NodeType.BUS,
            false,
            false,
            "newName",
            10D,
            115D,
            ElectricalPhase.AC3,
            ElectricalPhase.AC3);

    change =
        createChange(
            ActionType.ADD,
            "64d14438-8968-48d9-890c-c8e31a3a4221",
            nodeChange,
            null,
            Collections.emptyList(),
            "",
            "",
            changeGroup1);

    changeGroup1.setChanges(Collections.singletonList(change));

    project.setChangeGroups(Lists.newArrayList(changeGroup1, changeGroup2));
  }
}
