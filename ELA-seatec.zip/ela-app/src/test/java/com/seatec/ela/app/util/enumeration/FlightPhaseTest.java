package com.seatec.ela.app.util.enumeration;

import static org.junit.Assert.*;

import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.model.FlightPhaseDto;
import java.util.List;
import org.junit.Test;

public class FlightPhaseTest {

  @Test(expected = NullPointerException.class)
  public void getFlightPhases_should_throw_null_pointer_exception_for_null_manufacturer() {
    FlightPhase.getFlightPhases(null, false, "A330", false);
  }

  @Test
  public void getFlightPhases_should_return_empty_collection_for_bad_manufacturer() {
    List<FlightPhaseDto> result = FlightPhase.getFlightPhases("foo", false, "A330", false);
    assertTrue("result should be empty", result.isEmpty());
  }

  @Test
  public void
      getFlightPhases_should_return_airbus_flight_phases_for_airbus_manufacturer_false_etops() {
    List<FlightPhaseDto> result = FlightPhase.getFlightPhases("Airbus", false, "A330", false);
    for (int i = 0; i < result.size(); i++) {
      assertEquals(result.get(i).getName(), ClientConfig.Airbus.values()[i].toString());
    }
  }

  @Test
  public void
      getFlightPhases_should_return_airbus_flight_phases_for_airbus_manufacturer_true_etops() {
    List<FlightPhaseDto> result = FlightPhase.getFlightPhases("Airbus", true, "A330", false);
    for (int i = 0; i < result.size(); i++) {
      assertEquals(result.get(i).getName(), ClientConfig.Airbus.values()[i].toString());
    }
  }

  @Test
  public void
      getFlightPhases_should_return_boeing_flight_phases_for_boeing_manufacturer_false_etops() {
    List<FlightPhaseDto> result = FlightPhase.getFlightPhases("Boeing", false, "A330", false);
    for (int i = 0; i < result.size(); i++) {
      assertEquals(result.get(i).getName(), ClientConfig.Boeing.values()[i].toString());
    }
  }

  @Test
  public void
      getFlightPhases_should_return_boeing_flight_phases_plus_hmg_for_boeing_manufacturer_true_etops() {
    List<FlightPhaseDto> result = FlightPhase.getFlightPhases("Boeing", true, "A330", false);
    for (int i = 0; i < result.size(); i++) {
      if (i == result.size() - 1) {
        assertEquals(result.get(i).getName(), FlightPhase.HMG_FLIGHT_PHASE);
      } else {
        assertEquals(result.get(i).getName(), ClientConfig.Boeing.values()[i].toString());
      }
    }
  }
}
