package com.seatec.ela.app.service.project.change.history;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.project.change.history.ComponentChangeHistory;
import com.seatec.ela.app.model.project.change.history.LoadChangeHistory;
import com.seatec.ela.app.model.project.change.history.NodeChangeHistory;
import com.seatec.ela.app.model.repository.project.change.history.ComponentChangeHistoryRepo;
import com.seatec.ela.app.model.repository.project.change.history.LoadChangeHistoryRepo;
import com.seatec.ela.app.model.repository.project.change.history.NodeChangeHistoryRepo;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ChangeHistoryServiceIT extends AbstractControllerIntegrationTest {

  @Autowired private ChangeHistoryService subject;

  @Autowired private ComponentChangeHistoryRepo componentChangeHistoryRepo;

  @Autowired private LoadChangeHistoryRepo loadChangeHistoryRepo;

  @Autowired private NodeChangeHistoryRepo nodeChangeHistoryRepo;

  private Aircraft aircraft;
  private Ela ela;
  private ChangeGroup changeGroup1;

  @Before
  public void setup() {
    initalizeDatabase();
  }

  @Test
  public void when_saveOriginalNodeValues_then_save() {
    // arrange

    // node
    Node node =
        createAndSaveNode(
            true, "BUS 1", 10d, 50d, NodeType.BUS, 30d, ElectricalPhase.AC3, 1, null, ela);

    // nodeChange (EDIT voltage from 10d to 15d)
    NodeChange nodeChange =
        createNodeChange(
            node.getBusRating(),
            node.getName(),
            node.getVoltage() + 5d,
            node.getVoltageType(),
            node.getNodeType(),
            node.getNominalPower(),
            node.isRequiresApproval(),
            node.isSheddable(),
            node.isNormalTr(),
            node.getElectricalPhase());

    // change
    Change change = createAndSaveChangeWithNodeChange(changeGroup1, nodeChange, ActionType.EDIT);

    // assert (before act)
    Optional<NodeChangeHistory> matchingRecordBefore =
        nodeChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse("Change Node History count should be 0", matchingRecordBefore.isPresent());

    // act
    subject.saveOriginalNodeValues(change, ela, node);

    Optional<NodeChangeHistory> matchingRecordAfter =
        nodeChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertTrue("Change Node History count should exist", matchingRecordAfter.isPresent());
    Assert.assertEquals(
        "Change Node History record voltage should be original 10d",
        10d,
        matchingRecordAfter.get().getVoltage(),
        0.0);
  }

  @Test
  public void when_saveOriginalComponentValues_with_metadata_change_and_no_loads_then_save() {
    // arrange

    // node
    Node node =
        createAndSaveNode(
            true, "BUS 1", 10d, 50d, NodeType.BUS, 30d, ElectricalPhase.AC3, 1, null, ela);

    // component
    Component component =
        createAndSaveComponent(
            node, "Component 1", node.getElectricalPhase(), node.getNominalPower(), 1);

    // componentChange (EDIT nominalPower from 50d to 40d)
    ComponentChange componentChange =
        createComponentChange(
            Collections.emptyList(), // cannot pass null as it doesnt pass ComponentValidation
            component.getElectricalPhase(),
            component.getIntermittent(),
            component.getElectIdent(),
            component.getNominalPower() - 10d);

    // change
    Change change =
        createAndSaveChangeWithComponentChange(
            changeGroup1, node.getName(), componentChange, ActionType.EDIT);

    // assert (before act)
    Optional<ComponentChangeHistory> matchingRecordBefore =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Component History count should be 0", matchingRecordBefore.isPresent());

    // act
    subject.saveOriginalComponentValues(change, ela, component);

    Optional<ComponentChangeHistory> matchingRecordAfter =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertTrue(
        "Change Component History count should exist", matchingRecordAfter.isPresent());
    Assert.assertEquals(
        "Change Component History record nominalPower should be original 50d",
        50d,
        matchingRecordAfter.get().getNominalPower(),
        0.0);
  }

  @Test
  public void when_saveOriginalComponentValues_with_metadata_change_and_loads_then_save() {
    // arrange

    // node
    Node node =
        createAndSaveNode(
            true, "BUS 1", 10d, 500d, NodeType.BUS, 30d, ElectricalPhase.AC3, 1, null, ela);

    // component
    Component component =
        createAndSaveComponentWithLoads(
            node, "Component 1", node.getElectricalPhase(), node.getNominalPower(), 1, false);

    List<LoadChange> loadChanges = new ArrayList<>();

    for (Load load : component.getLoads()) {
      LoadChange loadChange = createLoadChange(load.getFlightPhase());
      loadChanges.add(loadChange);
    }

    // componentChange (EDIT loads)
    ComponentChange componentChange =
        createComponentChange(
            loadChanges,
            component.getElectricalPhase(),
            component.getIntermittent(),
            component.getElectIdent(),
            component.getNominalPower() - 10d);

    // change
    Change change =
        createAndSaveChangeWithComponentChange(
            changeGroup1, node.getName(), componentChange, ActionType.EDIT);

    // assert (before act)
    Optional<ComponentChangeHistory> matchingRecordBefore =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Component History count should be 0", matchingRecordBefore.isPresent());

    // act
    subject.saveOriginalComponentValues(change, ela, component);

    Optional<ComponentChangeHistory> matchingComponentRecordAfter =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertTrue(
        "Change Component History count should exist", matchingComponentRecordAfter.isPresent());
    Assert.assertEquals(
        "Change Component History record nominalPower should be original 500d",
        500d,
        matchingComponentRecordAfter.get().getNominalPower(),
        0.0);

    List<LoadChangeHistory> matchingLoadRecordAfter =
        loadChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Load History count should be greater than 1", matchingLoadRecordAfter.isEmpty());
  }

  @Test
  public void when_saveOriginalComponentValues_with_no_metadata_change_and_load_change_then_save() {
    // arrange

    // node
    Node node =
        createAndSaveNode(
            true, "BUS 1", 10d, 500d, NodeType.BUS, 30d, ElectricalPhase.AC3, 1, null, ela);

    // component
    Component component =
        createAndSaveComponentWithLoads(
            node, "Component 1", node.getElectricalPhase(), node.getNominalPower(), 1, false);

    List<LoadChange> loadChanges = new ArrayList<>();

    for (Load load : component.getLoads()) {
      LoadChange loadChange = createLoadChange(load.getFlightPhase());
      loadChanges.add(loadChange);
    }

    // componentChange (EDIT loads and nothing else)
    ComponentChange componentChange =
        createComponentChange(
            loadChanges,
            component.getElectricalPhase(),
            component.getIntermittent(),
            component.getElectIdent(),
            component.getNominalPower(),
            component.getName(),
            component.getSheddable(),
            component.getAta(),
            component.getClipsed(),
            component.getPanel(),
            component.getConnectedLoadPf(),
            component.getConnectedLoadVa());

    // change
    Change change =
        createAndSaveChangeWithComponentChange(
            changeGroup1, node.getName(), componentChange, ActionType.EDIT);

    // assert (before act)
    Optional<ComponentChangeHistory> matchingRecordBefore =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Component History count should be 0", matchingRecordBefore.isPresent());

    // act
    subject.saveOriginalComponentValues(change, ela, component);

    Optional<ComponentChangeHistory> matchingComponentRecordAfter =
        componentChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Component History count should be 0", matchingComponentRecordAfter.isPresent());

    List<LoadChangeHistory> matchingLoadRecordAfter =
        loadChangeHistoryRepo.findByChangeId(change.getId());
    Assert.assertFalse(
        "Change Load History count should be greater than 1", matchingLoadRecordAfter.isEmpty());
  }

  private void initalizeDatabase() {
    // fleet
    Fleet fleetAirbus = createAndSaveFleet(100, "Airbus");

    // aircraft(s)
    aircraft =
        createAndSaveAircraft("changeService_ship1", "1000", "R1000", "Line1", "V1", fleetAirbus);
    Aircraft aircraft2 =
        createAndSaveAircraft("changeService_ship2", "2000", "R2000", "Line2", "V2", fleetAirbus);

    // ela(s)
    ela = createAndSaveEla("Ela 1", aircraft);
    Ela ela2 = createAndSaveEla("Ela 2", aircraft2);

    // nodes (1st level)
    Node nodeGeneratorA =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.DC, 11, null, ela);
    Node node2 =
        createAndSaveNode(
            false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela);

    // nodes (2nd level)
    Node node3 =
        createAndSaveNode(
            false,
            "1IWXP",
            5d,
            10d,
            NodeType.BUS,
            100d,
            ElectricalPhase.AC3,
            31,
            nodeGeneratorA,
            null);
    Node node4 =
        createAndSaveNode(
            false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, nodeGeneratorA, null);

    // nodes (3rd level)
    Node node5 =
        createAndSaveNode(
            false, "101XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, node4, null);

    node4.addSubNode(node5);

    nodeGeneratorA.addSubNode(node3);
    nodeGeneratorA.addSubNode(node4);

    // components
    createAndSaveComponentWithLoads(
        nodeGeneratorA, "component ABC", ElectricalPhase.AC, 20d, 2, false);
    createAndSaveComponentWithLoads(node3, "component XYZ", ElectricalPhase.AC, 20d, 3, false);

    // nodes (1st level)
    Node nodeGeneratorB =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.DC, 11, null, ela2);
    createAndSaveNode(
        false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela2);

    // nodes (2nd level)
    createAndSaveNode(
        false, "1IWXP", 5d, 10d, NodeType.BUS, 100d, ElectricalPhase.AC3, 31, nodeGeneratorB, null);
    createAndSaveNode(
        false, "1XP", 5d, 10d, NodeType.BUS, 4d, ElectricalPhase.AC, 41, nodeGeneratorB, null);

    // project
    Project project =
        createAndSaveProject(
            "title 1",
            "description goes here.",
            "maintenance description goes here",
            "1",
            "1",
            Instant.now());

    // change groups
    changeGroup1 = createAndSaveChangeGroup("change group 1", project);
    ChangeGroup changeGroup2 = createAndSaveChangeGroup("change group 2", project);

    project.addChangeGroup(changeGroup1);
    project.addChangeGroup(changeGroup2);

    // aircraft change groups
    createAndSaveAircraftChangeGroup(aircraft, changeGroup1);
    createAndSaveAircraftChangeGroup(aircraft2, changeGroup1);
  }
}
