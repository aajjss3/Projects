package com.seatec.ela.app.service.project;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.mockito.AdditionalAnswers.returnsFirstArg;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.AircraftBusStructureBucketDto;
import com.seatec.ela.app.dto.ChangeGroupMappedNodeDto;
import com.seatec.ela.app.dto.ChangeGroupNodeDto;
import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.changeGroup.ComponentDto;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.exception.ConflictException;
import com.seatec.ela.app.exception.NotAcceptableException;
import com.seatec.ela.app.exception.NotFoundException;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeStructureRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupEffectivityDao;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.service.AircraftService;
import com.seatec.ela.app.service.contract.IAircraftService;
import com.seatec.ela.app.service.contract.IComponentService;
import com.seatec.ela.app.service.contract.IElaService;
import com.seatec.ela.app.service.contract.INodeService;
import com.seatec.ela.app.service.contract.project.IAircraftChangeGroupService;
import com.seatec.ela.app.service.contract.project.IChangeGroupService;
import com.seatec.ela.app.service.contract.project.IProjectService;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;
import org.apache.commons.lang3.RandomStringUtils;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

public class ChangeGroupServiceTest {

  private IChangeGroupService subject;

  private ChangeGroupRepo mockChangeGroupRepo;

  private IAircraftService mockAircraftService;

  private IProjectService mockProjectService;

  private IAircraftChangeGroupService mockAircraftChangeGroupService;

  private LoadRepository mockLoadRepository;

  private IElaService mockElaService;

  private ChangeGroupEffectivityDao mockChangeGroupEffectivityDao;

  private IComponentService mockComponentService;

  private INodeService mockNodeService;

  private NodeStructureRepository mockNodeStructureRepository;

  private static final String KEYCLOAK_USER_GUID = "64d14438-8968-48d9-890c-c8e31a3a4221";

  @Before
  public void setup() {
    mockChangeGroupRepo = mock(ChangeGroupRepo.class);
    mockAircraftService = mock(AircraftService.class);
    mockProjectService = mock(ProjectService.class);
    mockAircraftChangeGroupService = mock(AircraftChangeGroupService.class);
    mockLoadRepository = mock(LoadRepository.class);
    mockElaService = mock(IElaService.class);
    mockChangeGroupEffectivityDao = mock(ChangeGroupEffectivityDao.class);
    mockComponentService = mock(IComponentService.class);
    mockNodeService = mock(INodeService.class);
    mockNodeStructureRepository = mock(NodeStructureRepository.class);

    subject =
        new ChangeGroupService(
            mockAircraftService,
            mockProjectService,
            mockAircraftChangeGroupService,
            mockChangeGroupRepo,
            mockLoadRepository,
            mockElaService,
            mockChangeGroupEffectivityDao,
            mockComponentService,
            mockNodeService,
            mockNodeStructureRepository);
  }

  /** find Section (start) */
  @Test(expected = BadRequestException.class)
  public void
      when_findComponentsByChangeGroupAndNodeName_with_NullNodeName_then_throwBadRequestException() {
    // mock(s)
    when(mockComponentService.findByNodeIds(anyList())).thenReturn(Collections.emptyList());

    // act
    subject.findComponentsByChangeGroupAndNodeName(new ChangeGroup(), null);
  }

  @Test(expected = BadRequestException.class)
  public void
      when_findComponentsByChangeGroupAndNodeName_with_EmptyNodeName_then_throwBadRequestException() {
    // mock(s)
    when(mockComponentService.findByNodeIds(anyList())).thenReturn(Collections.emptyList());

    // act
    subject.findComponentsByChangeGroupAndNodeName(new ChangeGroup(), "");
  }

  @Test
  public void
      findComponentsByChangeGroupAndNodeName_should_return_all_unique_components_and_loads_when_elas_and_matching_nodes_are_found() {
    // arrange
    Project project = createProjectWithChangeGroupsAndEffectivities();

    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    List<Long> nodeIds = Arrays.asList(1L, 2L);
    List<ChangeGroupMappedNodeDto> changeGroupNodes = createChangeGroupMappedNodeDtos();
    List<Component> components = createComponents(2, changeGroupNodes.get(0).getName());

    List<Load> loads = new ArrayList<>(createLoads(components.get(0)));
    loads.addAll(createLoads(components.get(1)));

    Map<Component, List<Load>> loadsByComponent = new HashMap<>();
    loadsByComponent.put(components.get(0), createLoads(components.get(0)));
    loadsByComponent.put(components.get(1), createLoads(components.get(1)));

    // mock(s)
    when(mockComponentService.findByNodeIds(Arrays.asList(1L, 11L))).thenReturn(components);
    when(mockElaService.findDistinctElaIdByAircraftChangeGroups(
            airbusChangeGroup.getAircraftChangeGroups()))
        .thenReturn(nodeIds);
    when(mockChangeGroupEffectivityDao.findChangeGroupEffectivities(nodeIds))
        .thenReturn(changeGroupNodes);
    when(mockLoadRepository.getLoadsInComponents(Arrays.asList(1L, 2L))).thenReturn(loads);
    when(mockNodeService.getLoadsByComponent(loads)).thenReturn(loadsByComponent);

    // act
    List<ComponentDto> results =
        subject.findComponentsByChangeGroupAndNodeName(airbusChangeGroup, "101XP");

    // assert
    assertNotNull("components should not be null", results);
    assertFalse("components should not be empty", results.isEmpty());
    assertNotNull("loads should not be null", results.get(0).getLoads());
    assertFalse("loads should not be empty", results.get(0).getLoads().isEmpty());
  }

  @Test
  public void
      when_findComponentsByChangeGroupAndNodeName_and_no_matching_nodeComponents_then_return_empty_resultset() {
    // arrange
    Project project = createProjectWithChangeGroupsAndEffectivities();
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    when(mockComponentService.findByNodeIds(anyList())).thenReturn(Collections.emptyList());

    // act
    List<ComponentDto> results =
        subject.findComponentsByChangeGroupAndNodeName(airbusChangeGroup, "101XP");

    // assert
    assertNotNull("components should not be null", results);
    assertTrue("components should be empty", results.isEmpty());
  }

  @Test
  public void
      when_findComponentsByChangeGroupAndNodeName_and_matching_nodeComponents_then_return_resultset() {
    // arrange
    String nodeName = "101XP";
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // change group(s)
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    List<Long> nodeIds = Arrays.asList(1L, 2L);
    List<ChangeGroupMappedNodeDto> changeGroupNodes = createChangeGroupMappedNodeDtos();

    // component(s)
    List<Component> components = createComponents(2, changeGroupNodes.get(0).getName());

    Node node = createNode(nodeName);

    // component change(s)
    components.get(0).setNominalPower(null);
    components.get(0).setConnectedLoadVa(1d);
    components.get(0).setConnectedLoadPf(.5d);
    Component existingComponent = components.get(0);
    existingComponent.setNode(node);

    // edited `connectedLoadPf`
    ComponentChange componentChange =
        createComponentChange(
            existingComponent.getName(),
            existingComponent.getClipsed(),
            existingComponent.getAta(),
            existingComponent.getElectIdent(),
            existingComponent.getElectricalPhase(),
            existingComponent.getPanel(),
            existingComponent.getSheddable(),
            existingComponent.getIntermittent(),
            1d,
            null,
            .5d);

    List<Change> changes = new ArrayList<>();
    Change change =
        createChange(
            airbusChangeGroup,
            existingComponent.getElectIdent(),
            existingComponent.getNode().getName(),
            ActionType.EDIT,
            componentChange);
    changes.add(change);

    airbusChangeGroup.setChanges(changes);

    // load(s)
    List<Load> loads = new ArrayList<>(createLoads(components.get(0)));
    loads.addAll(createLoads(components.get(1)));

    Map<Component, List<Load>> loadsByComponent = new HashMap<>();
    loadsByComponent.put(components.get(0), createLoads(components.get(0)));
    loadsByComponent.put(components.get(1), createLoads(components.get(1)));

    // mock(s)
    when(mockElaService.findDistinctElaIdByAircraftChangeGroups(
            airbusChangeGroup.getAircraftChangeGroups()))
        .thenReturn(nodeIds);
    when(mockChangeGroupEffectivityDao.findChangeGroupEffectivities(nodeIds))
        .thenReturn(changeGroupNodes);
    when(mockComponentService.findByNodeIds(anyList())).thenReturn(components);
    when(mockLoadRepository.getLoadsInComponents(anyList())).thenReturn(loads);
    when(mockNodeService.getLoadsByComponent(loads)).thenReturn(loadsByComponent);

    // assert (before act)
    Assert.assertNull("component nominalPower should be null", components.get(0).getNominalPower());
    assertEquals("component Va should be 1.00", 1d, components.get(0).getConnectedLoadVa());
    assertEquals("component Pf should be 0.50", .5d, components.get(0).getConnectedLoadPf());

    // act
    List<ComponentDto> results =
        subject.findComponentsByChangeGroupAndNodeName(airbusChangeGroup, nodeName);

    // assert (after act)
    assertNotNull("components should not be null", results);
    assertFalse("components should not be empty", results.isEmpty());
    assertNotNull("loads should not be null", results.get(0).getLoads());
    assertFalse("loads should not be empty", results.get(0).getLoads().isEmpty());

    assertEquals("component nominalPower should be 1.00", 1d, results.get(0).getNominalPower());
    Assert.assertNull("component Va should be null", results.get(0).getConnectedLoadVa());
    assertEquals("component Pf should be 0.50", .5d, results.get(0).getConnectedLoadPf());
  }

  @Test
  public void
      findChangeGroupEffectivityBusStructureByChangeGroupId_should_return_all_unique_nodes_when_elas_and_matching_nodes_are_found() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    List<Long> nodeIds = Arrays.asList(1L);
    List<ChangeGroupMappedNodeDto> changeGroupNodes = createChangeGroupMappedNodeDtos();
    List<Component> components = createComponents(2, changeGroupNodes.get(0).getName());

    List<Load> loads = new ArrayList<>(createLoads(components.get(0)));
    loads.addAll(createLoads(components.get(1)));

    Map<Component, List<Load>> loadsByComponent = new HashMap<>();
    loadsByComponent.put(components.get(0), createLoads(components.get(0)));
    loadsByComponent.put(components.get(1), createLoads(components.get(1)));

    when(mockChangeGroupRepo.findById(airbusChangeGroup.getId()))
        .thenReturn(Optional.of(airbusChangeGroup));
    when(mockElaService.findDistinctElaIdByAircraftChangeGroups(
            airbusChangeGroup.getAircraftChangeGroups()))
        .thenReturn(nodeIds);
    when(mockChangeGroupEffectivityDao.findChangeGroupEffectivities(nodeIds))
        .thenReturn(changeGroupNodes);
    when(mockComponentService.findByNodeIds(Arrays.asList(1L, 11L))).thenReturn(components);
    when(mockLoadRepository.getLoadsInComponents(Arrays.asList(1L, 2L))).thenReturn(loads);
    when(mockNodeService.getLoadsByComponent(loads)).thenReturn(loadsByComponent);
    List<ChangeGroupNodeDto> results =
        subject.findChangeGroupEffectivityBusStructureByChangeGroupId(airbusChangeGroup.getId());

    assertNotNull("components should not be null", results);
    assertFalse("components should not be empty", results.isEmpty());
    assertNotNull("name should not be null", results.get(0).getName());
  }

  @Test
  public void
      findComponentsByChangeGroupAndNodeName_should_return_all_unique_components_and_loads_with_component_changes_when_elas_and_matching_nodes_are_found() {
    String nodeName = "101XP";

    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    ChangeGroup changeGroup = project.getChangeGroups().get(0);
    Change change = createChange(changeGroup, "H123_1", nodeName, ActionType.EDIT);
    changeGroup.addChange(change);

    List<Long> nodeIds = Arrays.asList(1L, 2L);
    List<ChangeGroupMappedNodeDto> changeGroupNodes = createChangeGroupMappedNodeDtos();
    List<Component> components = createComponents(2, changeGroupNodes.get(0).getName());

    List<Load> loads = new ArrayList<>(createLoads(components.get(0)));
    loads.addAll(createLoads(components.get(1)));

    Map<Component, List<Load>> loadsByComponent = new HashMap<>();
    loadsByComponent.put(components.get(0), createLoads(components.get(0)));
    loadsByComponent.put(components.get(1), createLoads(components.get(1)));

    when(mockElaService.findDistinctElaIdByAircraftChangeGroups(
            changeGroup.getAircraftChangeGroups()))
        .thenReturn(nodeIds);
    when(mockChangeGroupEffectivityDao.findChangeGroupEffectivities(nodeIds))
        .thenReturn(changeGroupNodes);
    when(mockComponentService.findByNodeIds(Arrays.asList(1L, 11L))).thenReturn(components);
    when(mockLoadRepository.getLoadsInComponents(Arrays.asList(1L, 2L))).thenReturn(loads);
    when(mockNodeService.getLoadsByComponent(loads)).thenReturn(loadsByComponent);

    List<ComponentDto> results =
        subject.findComponentsByChangeGroupAndNodeName(changeGroup, nodeName);

    assertNotNull("components should not be null", results);
    assertFalse("components should not be empty", results.isEmpty());
    assertNotNull("loads should not be null", results.get(0).getLoads());
    assertFalse("loads should not be empty", results.get(0).getLoads().isEmpty());

    assertTrue("action should not be null", results.get(0).getAction() == ActionType.EDIT);
  }

  @Test
  public void
      findComponentsByChangeGroupAndNodeName_should_return_added_components_across_electrical_phases_with_component_changes_when_elas_and_matching_nodes_are_found() {
    String nodeName = "101XP";

    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    ChangeGroup changeGroup = project.getChangeGroups().get(0);

    Change changeA = new Change();
    changeA.setId(UUID.randomUUID());
    changeA.setAction(ActionType.ADD);
    changeA.setChangeGroup(changeGroup);
    changeA.setComponentElectIdent("TEST");
    changeA.setNodeName(nodeName);
    changeA.setChanger(KEYCLOAK_USER_GUID);
    changeA.setComponentChange(
        createComponentChange(
            "componentA",
            false,
            "123",
            "TEST",
            ElectricalPhase.ACA,
            "123VU",
            false,
            false,
            6211.8D));

    changeGroup.addChange(changeA);

    Change changeB = new Change();
    changeB.setId(UUID.randomUUID());
    changeB.setAction(ActionType.ADD);
    changeB.setChangeGroup(changeGroup);
    changeB.setComponentElectIdent("TEST");
    changeB.setNodeName(nodeName);
    changeB.setChanger(KEYCLOAK_USER_GUID);
    changeB.setComponentChange(
        createComponentChange(
            "componentA",
            false,
            "123",
            "TEST",
            ElectricalPhase.ACB,
            "123VU",
            false,
            false,
            6211.8D));

    changeGroup.addChange(changeB);

    Change changeC = new Change();
    changeC.setId(UUID.randomUUID());
    changeC.setAction(ActionType.ADD);
    changeC.setChangeGroup(changeGroup);
    changeC.setComponentElectIdent("TEST");
    changeC.setNodeName(nodeName);
    changeC.setChanger(KEYCLOAK_USER_GUID);
    changeC.setComponentChange(
        createComponentChange(
            "componentC",
            false,
            "123",
            "TEST",
            ElectricalPhase.ACC,
            "123VU",
            false,
            false,
            6211.8D));

    changeGroup.addChange(changeC);

    List<Long> nodeIds = Arrays.asList(1L, 2L);
    List<ChangeGroupMappedNodeDto> changeGroupNodes = createChangeGroupMappedNodeDtos();
    List<Component> components = createComponents(2, changeGroupNodes.get(0).getName());

    List<Load> loads = new ArrayList<>(createLoads(components.get(0)));
    loads.addAll(createLoads(components.get(1)));

    Map<Component, List<Load>> loadsByComponent = new HashMap<>();
    loadsByComponent.put(components.get(0), createLoads(components.get(0)));
    loadsByComponent.put(components.get(1), createLoads(components.get(1)));

    when(mockElaService.findDistinctElaIdByAircraftChangeGroups(
            changeGroup.getAircraftChangeGroups()))
        .thenReturn(nodeIds);
    when(mockChangeGroupEffectivityDao.findChangeGroupEffectivities(nodeIds))
        .thenReturn(changeGroupNodes);
    when(mockComponentService.findByNodeIds(Arrays.asList(1L, 11L))).thenReturn(components);
    when(mockLoadRepository.getLoadsInComponents(Arrays.asList(1L, 2L))).thenReturn(loads);
    when(mockNodeService.getLoadsByComponent(loads)).thenReturn(loadsByComponent);

    List<ComponentDto> results =
        subject.findComponentsByChangeGroupAndNodeName(changeGroup, nodeName);

    assertNotNull("components should not be null", results);
    assertFalse("components should not be empty", results.isEmpty());
    assertEquals(
        "there should be 3 component changes",
        3,
        results.stream().filter(c -> c.getAction() != null).count());
  }

  @Test
  public void findParentFleets_should_return_parent_fleets() {
    Project project = createProjectWithChangeGroupsAndEffectivities();
    UUID uuid = UUID.randomUUID();
    when(mockChangeGroupRepo.findById(uuid))
        .thenReturn(Optional.of(project.getChangeGroups().get(0)));

    List<FleetDto> result = subject.findParentFleets(uuid);
    assertNotNull("fleet response should not be null", result);
    assertFalse("fleet response should not be empty", result.isEmpty());
  }
  /** find Section (end) */

  /** save Section (start) */
  @Test(expected = BadRequestException.class)
  public void save_ChangeGroup_name_null_should_return_BadRequestException() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // new ChangeGroup
    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName(null);
    newChangeGroup.setProject(project);

    subject.save(newChangeGroup, project.getId());
  }

  @Test(expected = BadRequestException.class)
  public void save_ChangeGroup_name_empty_should_return_BadRequestException() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // new ChangeGroup
    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("");
    newChangeGroup.setProject(project);

    subject.save(newChangeGroup, project.getId());
  }

  @Test(expected = BadRequestException.class)
  public void save_ChangeGroup_project_not_found_should_return_BadRequestException() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // new ChangeGroup
    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("Random Title");
    newChangeGroup.setProject(project);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.empty());

    subject.save(newChangeGroup, project.getId());
  }

  @Test(expected = BadRequestException.class)
  public void save_ChangeGroup_duplicate_changeGroup_should_return_BadRequestException() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // new ChangeGroup
    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("Random Title");
    newChangeGroup.setProject(project);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupRepo.findByProjectIdAndChangeGroupName(
            any(Project.class), any(String.class)))
        .thenReturn(Optional.of(newChangeGroup));

    subject.save(newChangeGroup, project.getId());
  }

  @Test
  public void save_changeGroup_when_changeGroup_name_not_exists_then_return_successful() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // change group (new)
    ChangeGroup newChangeGroup = createChangeGroup("testing");

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupRepo.findByProjectIdAndChangeGroupName(
            any(Project.class), any(String.class)))
        .thenReturn(Optional.empty());
    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).thenReturn(newChangeGroup);

    ChangeGroup newChangeGroupEntity = subject.save(newChangeGroup, UUID.randomUUID());

    assertNotNull("ChangeGroup response should not be null", newChangeGroupEntity);
    assertEquals(
        "ChangeGroup Names should match", newChangeGroup.getName(), newChangeGroupEntity.getName());
  }

  @Test(expected = NotAcceptableException.class)
  public void
      saveByBusStructureBucketUsingAircraftIds_should_not_create_change_group_when_given_duplicate_aircraft() {
    Project project = createProject("test");

    Fleet fleet1 = createFleet("Airbus 1");
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);

    AircraftChangeGroup acg = new AircraftChangeGroup();
    acg.setAircraft(newAirbusAircraft);
    ChangeGroup existingChangeGroup = new ChangeGroup();
    existingChangeGroup.setName("Existing Random Title");
    existingChangeGroup.setProject(project);

    List<ChangeGroup> findAllByProjectId = new ArrayList<>();
    findAllByProjectId.add(existingChangeGroup);

    List<AircraftChangeGroup> findAllByChangeGroupIdIn = new ArrayList<>();
    findAllByChangeGroupIdIn.add(acg);

    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("Random Title");
    newChangeGroup.setProject(project);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    when(mockChangeGroupRepo.findAllByProjectId(any())).thenReturn(findAllByProjectId);

    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdIn);

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).thenReturn(newChangeGroup);

    subject.saveByBusStructureBucketUsingAircraftIds(
        Lists.newArrayList(newAirbusAircraft.getId()), project.getId());

    verify(mockChangeGroupRepo, never()).save(any(ChangeGroup.class));
  }

  @Test
  public void
      saveByBusStructureBucketUsingAircraftIds_should_create_a_single_change_group_when_given_a_single_aircraft() {
    Project project = createProject("test");

    Fleet fleet1 = createFleet("Airbus 1");
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);

    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("Random Title");
    newChangeGroup.setProject(project);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).thenReturn(newChangeGroup);

    subject.saveByBusStructureBucketUsingAircraftIds(
        Lists.newArrayList(newAirbusAircraft.getId()), project.getId());

    verify(mockChangeGroupRepo).save(any(ChangeGroup.class));
  }

  @Test
  public void
      saveByBusStructureBucketUsingAircraftIds_should_create_when_no_prior_change_group_present() {
    Project project = createProject("test");

    Fleet fleet1 = createFleet("Airbus 1");
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);

    AircraftChangeGroup acg = new AircraftChangeGroup();
    acg.setAircraft(newAirbusAircraft);
    ChangeGroup existingChangeGroup = new ChangeGroup();
    existingChangeGroup.setName("Existing Random Title");
    existingChangeGroup.setProject(project);

    List<ChangeGroup> findAllByProjectId = new ArrayList<>();
    // findAllByProjectId is empty list no change groups present

    List<AircraftChangeGroup> findAllByChangeGroupIdIn = new ArrayList<>();
    // findAllByChangeGroupIdIn is empty list no aircrafts present

    ChangeGroup newChangeGroup = new ChangeGroup();
    newChangeGroup.setName("Random Title");
    newChangeGroup.setProject(project);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    when(mockChangeGroupRepo.findAllByProjectId(any())).thenReturn(findAllByProjectId);

    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdIn);

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).thenReturn(newChangeGroup);

    subject.saveByBusStructureBucketUsingAircraftIds(
        Lists.newArrayList(newAirbusAircraft.getId()), project.getId());

    verify(mockChangeGroupRepo).save(any(ChangeGroup.class));
  }

  @Test
  public void saveByBusStructureBucket_should_create_change_group_with_child_fleet_name() {
    Project project = createProject("test");

    Fleet parentFleet = createFleet("Airbus Parent");
    // set the child fleet name to a valid value and the bucket should use this name and *not* use
    // the parent fleet name
    Fleet fleet1 = createFleet("Airbus 1");
    fleet1.setParentFleet(parentFleet);
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).then(returnsFirstArg());
    ArgumentCaptor<ChangeGroup> captor = ArgumentCaptor.forClass(ChangeGroup.class);

    subject.saveByBusStructureBucketUsingAircraftIds(
        Lists.newArrayList(newAirbusAircraft.getId()), project.getId());
    verify(mockChangeGroupRepo).save(captor.capture());
    assertEquals("Airbus 1", captor.getValue().getName());
  }

  @Test
  public void saveByBusStructureBucket_should_create_change_group_with_parent_fleet_name() {
    Project project = createProject("test");

    Fleet parentFleet = createFleet("Airbus Parent");
    // set the child fleet name to an empty string so the bucket name should be set
    // to the parent
    Fleet fleet1 = createFleet("");
    fleet1.setParentFleet(parentFleet);
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).then(returnsFirstArg());
    ArgumentCaptor<ChangeGroup> captor = ArgumentCaptor.forClass(ChangeGroup.class);

    subject.saveByBusStructureBucketUsingAircraftIds(
        Lists.newArrayList(newAirbusAircraft.getId()), project.getId());
    verify(mockChangeGroupRepo).save(captor.capture());
    assertEquals("Airbus Parent", captor.getValue().getName());
  }

  @Test
  public void updateEffectivity_should_split_etops() {
    Project project = createProject("test");

    // build up a change group with a single non-ETOPS aircraft
    Fleet fleet = createFleet("Boeing 1");
    Aircraft currentAircraft = createAircraft("685", fleet);
    ChangeGroup currentChangeGroup = createChangeGroup("Boeing 1");
    AircraftChangeGroup aircraftChangeGroup =
        createAircraftChangeGroup(currentChangeGroup, currentAircraft);
    currentChangeGroup.getAircraftChangeGroups().add(aircraftChangeGroup);

    // make an ETOPS fleet with a single aircraft
    Fleet etopsFleet = createFleet("Boeing ETOPS 1");
    etopsFleet.setEtops(true);
    Aircraft etopsAircraft = createAircraft("6801", etopsFleet);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    // mock the results for the query of both aircraft: one from the non-ETOPS fleet, and the
    // aircraft from the ETOPS fleet
    when(mockAircraftService.findByIdIn(anyList()))
        .thenReturn(Arrays.asList(currentAircraft, etopsAircraft));

    // mock the results for the project's change groups to return our single initial
    // change group
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(Collections.singletonList(currentChangeGroup));

    defaultMockAircraftChangeGroupRepo();

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).then(returnsFirstArg());
    ArgumentCaptor<ChangeGroup> captor = ArgumentCaptor.forClass(ChangeGroup.class);

    subject.updateEffectivity(
        Arrays.asList(currentAircraft.getId(), etopsAircraft.getId()),
        project.getId(),
        currentChangeGroup.getId());
    // we'll verify the change group save got called one time for the new ETOPS
    // change group and the name matches expections with that single ETOPS aircraft
    verify(mockChangeGroupRepo).save(captor.capture());
    ChangeGroup newChangeGroup = captor.getValue();
    assertEquals("Boeing ETOPS 1", newChangeGroup.getName());
    assertEquals(1, newChangeGroup.getAircraftChangeGroups().size());
    assertEquals(
        "6801", newChangeGroup.getAircraftChangeGroups().get(0).getAircraft().getAircraftShipNo());
  }

  @Test
  public void updateEffectivity_add_aircraft_custom_change_group_and_create_new_change_group() {
    Project project = createProject("test");

    // build up a change group with a single non-ETOPS aircraft
    Fleet fleet = createFleet("Boeing 1");
    Aircraft currentAircraft = createAircraft("685", fleet);
    ChangeGroup currentChangeGroup = createChangeGroup("My Custom ChangeGroup");
    AircraftChangeGroup aircraftChangeGroup =
        createAircraftChangeGroup(currentChangeGroup, currentAircraft);
    currentChangeGroup.getAircraftChangeGroups().add(aircraftChangeGroup);

    // a second Boeing aircraft in the same fleet as the 685, should land in the same
    // change group
    Aircraft boeingAircraft = createAircraft("686", fleet);

    // make an ETOPS fleet with a single aircraft.  We'll want to make sure
    // that a separate change group is made
    Fleet etopsFleet = createFleet("Boeing ETOPS 1");
    etopsFleet.setEtops(true);
    Aircraft etopsAircraft = createAircraft("6801", etopsFleet);

    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));

    // mock the results for the query of all aircraft in this test: 2 non-ETOPS, 1 ETOPS
    when(mockAircraftService.findByIdIn(anyList()))
        .thenReturn(Arrays.asList(currentAircraft, boeingAircraft, etopsAircraft));

    // mock the results for the project's change groups to return our single initial
    // change group
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(Collections.singletonList(currentChangeGroup));

    defaultMockAircraftChangeGroupRepo();

    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).then(returnsFirstArg());
    ArgumentCaptor<ChangeGroup> captor = ArgumentCaptor.forClass(ChangeGroup.class);

    subject.updateEffectivity(
        Arrays.asList(currentAircraft.getId(), etopsAircraft.getId(), boeingAircraft.getId()),
        project.getId(),
        currentChangeGroup.getId());
    // first we'll verify that the original change group got a 2nd aircraft
    assertEquals(2, currentChangeGroup.getAircraftChangeGroups().size());
    assertTrue(
        currentChangeGroup.getAircraftChangeGroups().stream()
            .anyMatch(acg -> acg.getAircraft().equals(boeingAircraft)));
    // we'll verify the change group save got called one time for the new ETOPS
    // change group and the name matches expections with that single ETOPS aircraft
    verify(mockChangeGroupRepo).save(captor.capture());
    ChangeGroup newChangeGroup = captor.getValue();
    assertEquals("Boeing ETOPS 1", newChangeGroup.getName());
    assertEquals(1, newChangeGroup.getAircraftChangeGroups().size());
    assertEquals(
        "6801", newChangeGroup.getAircraftChangeGroups().get(0).getAircraft().getAircraftShipNo());
  }

  // this particular 'mock' is a bit more heavy weight than the others since it replicates
  // what the main service implementation does
  private void defaultMockAircraftChangeGroupRepo() {
    when(mockAircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            any(AircraftBusStructureBucketDto.class), any(ChangeGroup.class)))
        .thenAnswer(
            answer -> {
              AircraftBusStructureBucketDto bucket = answer.getArgument(0);
              ChangeGroup changeGroup = answer.getArgument(1);
              return bucket.getAircrafts().stream()
                  .map(
                      aircraft -> {
                        AircraftChangeGroup acg = new AircraftChangeGroup();
                        acg.setChangeGroup(changeGroup);
                        acg.setAircraft(aircraft);
                        return acg;
                      })
                  .collect(Collectors.toList());
            });
  }
  /** save Section (end) */

  /** update Section (start) */
  @Test
  public void updateEffectivity_should_save_effectivity_when_API_returns_2xx() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet
    Fleet fleet1 = createFleet("Airbus 1");
    Fleet fleet2 = createFleet("Boeing 1");
    Aircraft aircraft1 = createAircraft("12345", fleet1);
    Aircraft aircraft2 = createAircraft("67890", fleet2);

    Aircraft aircraft3 = createAircraft("23456", fleet1);
    // updated aircraft list to process
    List<Aircraft> newAircrafts = Lists.newArrayList(aircraft3);

    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);
    ChangeGroup boeingChangeGroup = project.getChangeGroups().get(1);

    AircraftChangeGroup aircraftChangeGroup1 =
        createAircraftChangeGroup(airbusChangeGroup, aircraft1);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAircraftChangeGroup(boeingChangeGroup, aircraft2);
    List<AircraftChangeGroup> boeingAircraftChangeGroups = Lists.newArrayList(aircraftChangeGroup2);

    AircraftBusStructureBucketDto aircraftBusStructureBucketDto2 =
        createAircraftBusStructureBucketDto(aircraft2, "Boeing 1");

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(newAircrafts);
    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(Collections.emptyList());
    when(mockAircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDto2, boeingChangeGroup))
        .thenReturn(boeingAircraftChangeGroups);

    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(1L);

    ChangeGroup wantToUpdateThisChangeGroup = project.getChangeGroups().get(0);

    subject.updateEffectivity(aircraftIds, project.getId(), wantToUpdateThisChangeGroup.getId());

    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
    verify(mockAircraftChangeGroupService, times(1))
        .convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            isA(AircraftBusStructureBucketDto.class), isA(ChangeGroup.class));
  }

  @Test
  public void
      updateEffectivity_should_update_existing_changegroup_when_compatible_aircraft_is_added() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet(s)
    Fleet fleet1 = createFleet("Airbus 1");
    Fleet fleet2 = createFleet("Boeing 1");

    // aircraft(s)
    Aircraft aircraft1 = createAircraft("12345", fleet1);
    Aircraft aircraft2 = createAircraft("67890", fleet2);

    // change group(s)
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);
    ChangeGroup boeingChangeGroup = project.getChangeGroups().get(1);

    // aircraft change group(s)
    AircraftChangeGroup aircraftChangeGroup1 =
        createAircraftChangeGroup(airbusChangeGroup, aircraft1);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAircraftChangeGroup(boeingChangeGroup, aircraft2);
    List<AircraftChangeGroup> airbusAircraftChangeGroups = Lists.newArrayList(aircraftChangeGroup1);

    AircraftBusStructureBucketDto aircraftBusStructureBucketDtoAirbus =
        createAircraftBusStructureBucketDto(aircraft1, "Airbus 1");

    // airbus
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(newAirbusAircraft.getId());
    aircraftIds.add(aircraft1.getId());

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);
    findByIdInAircrafts.add(aircraft1);

    ChangeGroup existingAirbusChangeGroup = project.getChangeGroups().get(0); // airbus

    // duplicates found
    List<AircraftChangeGroup> findAllByChangeGroupIdInDuplicates = Collections.emptyList();

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);
    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdInDuplicates);
    when(mockAircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDtoAirbus, airbusChangeGroup))
        .thenReturn(airbusAircraftChangeGroups);

    // act
    subject.updateEffectivity(aircraftIds, project.getId(), existingAirbusChangeGroup.getId());

    // assert
    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
    verify(mockAircraftChangeGroupService, times(1))
        .convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            isA(AircraftBusStructureBucketDto.class), isA(ChangeGroup.class));
  }

  @Test
  public void
      updateEffectivity_should_create_new_changegroup_when_incompatible_aircraft_manufactuer_is_included() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet(s)
    Fleet fleet1 = createFleet("Airbus 1");
    Fleet fleet2 = createFleet("Boeing 1");
    Fleet fleet3 = createFleet("Candlestick 1");

    // aircraft(s)
    Aircraft aircraft1 = createAircraft("12345", fleet1);
    Aircraft aircraft2 = createAircraft("67890", fleet2);

    // change group(s)
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);
    ChangeGroup boeingChangeGroup = project.getChangeGroups().get(1);

    // aircraft change group(s)
    AircraftChangeGroup aircraftChangeGroup1 =
        createAircraftChangeGroup(airbusChangeGroup, aircraft1);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAircraftChangeGroup(boeingChangeGroup, aircraft2);
    List<AircraftChangeGroup> airbusAircraftChangeGroups = Lists.newArrayList(aircraftChangeGroup1);
    List<AircraftChangeGroup> BoeingAircraftChangeGroups = Lists.newArrayList(aircraftChangeGroup2);

    AircraftBusStructureBucketDto aircraftBusStructureBucketDtoAirbus =
        createAircraftBusStructureBucketDto(aircraft1, "Airbus 1");
    AircraftBusStructureBucketDto aircraftBusStructureBucketDtoBoeing =
        createAircraftBusStructureBucketDto(aircraft2, "Boeing 1");

    // airbus
    Aircraft newAircraftToAdd = createAircraft("abc123", fleet3);
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(newAircraftToAdd.getId());
    aircraftIds.add(aircraft1.getId());

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAircraftToAdd);
    findByIdInAircrafts.add(aircraft1);

    ChangeGroup existingAirbusChangeGroup = project.getChangeGroups().get(0); // airbus

    // duplicates found
    List<AircraftChangeGroup> findAllByChangeGroupIdInDuplicates = Collections.emptyList();

    // new change group mock
    ChangeGroup newChangeGroup = createChangeGroup("Candlestick 1");
    newChangeGroup.setProject(project);

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);
    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdInDuplicates);
    when(mockProjectService.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockChangeGroupRepo.save(any(ChangeGroup.class))).thenReturn(newChangeGroup);
    when(mockAircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDtoAirbus, airbusChangeGroup))
        .thenReturn(airbusAircraftChangeGroups);
    when(mockAircraftChangeGroupService.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDtoBoeing, boeingChangeGroup))
        .thenReturn(BoeingAircraftChangeGroups);

    // act
    subject.updateEffectivity(aircraftIds, project.getId(), existingAirbusChangeGroup.getId());

    // assert
    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
    verify(mockAircraftChangeGroupService, times(1)).findAllByChangeGroupIdIn(anyList());
    verify(mockProjectService, times(1)).findById(any(UUID.class));
    verify(mockChangeGroupRepo, times(1)).save(any(ChangeGroup.class));
    verify(mockAircraftChangeGroupService, times(2))
        .convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            isA(AircraftBusStructureBucketDto.class), isA(ChangeGroup.class));
  }

  @Test(expected = NotFoundException.class)
  public void
      updateEffectivity_should_throw_NotFoundException_when_findByChangeGroupId_returns_no_results() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet(s)
    Fleet fleet1 = createFleet("Airbus 1");

    // aircraft(s)
    Aircraft aircraft1 = createAircraft("12345", fleet1);

    // airbus
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(newAirbusAircraft.getId());
    aircraftIds.add(aircraft1.getId());

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);
    findByIdInAircrafts.add(aircraft1);

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);

    // act
    subject.updateEffectivity(aircraftIds, project.getId(), UUID.randomUUID());

    // assert
    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
  }

  @Test(expected = NotAcceptableException.class)
  public void
      updateEffectivity_should_throw_NotAcceptableException_when_removing_all_effectivities_from_changeGroup() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet(s)
    Fleet fleet1 = createFleet("Airbus 1 (split node abc)");
    Fleet fleet2 = createFleet("Boeing 1");

    // aircraft(s)
    Aircraft aircraft1 = createAircraft("12345", fleet1);
    Aircraft aircraft2 = createAircraft("67890", fleet2);

    // change group(s)
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);
    ChangeGroup boeingChangeGroup = project.getChangeGroups().get(1);

    // aircraft change group(s)
    AircraftChangeGroup aircraftChangeGroup1 =
        createAircraftChangeGroup(airbusChangeGroup, aircraft1);
    AircraftChangeGroup aircraftChangeGroup2 =
        createAircraftChangeGroup(boeingChangeGroup, aircraft2);
    List<AircraftChangeGroup> airbusAircraftChangeGroups = Lists.newArrayList(aircraftChangeGroup1);

    AircraftBusStructureBucketDto aircraftBusStructureBucketDtoBoeing =
        createAircraftBusStructureBucketDto(aircraft1, "Boeing 1");

    // airbus
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(newAirbusAircraft.getId());
    aircraftIds.add(aircraft1.getId());

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);
    findByIdInAircrafts.add(aircraft1);

    ChangeGroup existingBoeingChangeGroup = project.getChangeGroups().get(1); // airbus

    // duplicates found
    List<AircraftChangeGroup> findAllByChangeGroupIdInDuplicates = Collections.emptyList();

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);
    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdInDuplicates);

    // act
    subject.updateEffectivity(aircraftIds, project.getId(), existingBoeingChangeGroup.getId());

    // assert
    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
  }

  @Test(expected = NotAcceptableException.class)
  public void
      updateEffectivity_should_throw_NotAcceptableException_when_aircraft_exists_in_another_changeGroup() {
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // fleet(s)
    Fleet fleet1 = createFleet("Airbus 1");

    // aircraft(s)
    Aircraft aircraft1 = createAircraft("12345", fleet1);

    // change group(s)
    ChangeGroup airbusChangeGroup = project.getChangeGroups().get(0);

    // aircraft change group(s)
    AircraftChangeGroup aircraftChangeGroup1 =
        createAircraftChangeGroup(airbusChangeGroup, aircraft1);

    // airbus
    Aircraft newAirbusAircraft = createAircraft("abc123", fleet1);
    List<Long> aircraftIds = new ArrayList<>();
    aircraftIds.add(newAirbusAircraft.getId());
    aircraftIds.add(aircraft1.getId());

    List<Aircraft> findByIdInAircrafts = new ArrayList<>();
    findByIdInAircrafts.add(newAirbusAircraft);
    findByIdInAircrafts.add(aircraft1);

    ChangeGroup existingAirbusChangeGroup = project.getChangeGroups().get(0); // airbus

    // duplicates found
    List<AircraftChangeGroup> findAllByChangeGroupIdInDuplicates =
        Collections.singletonList(aircraftChangeGroup1);

    // mocks
    when(mockChangeGroupRepo.findAllByProjectId(any(UUID.class)))
        .thenReturn(project.getChangeGroups());
    when(mockAircraftService.findByIdIn(anyList())).thenReturn(findByIdInAircrafts);
    when(mockAircraftChangeGroupService.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(findAllByChangeGroupIdInDuplicates);

    // act
    subject.updateEffectivity(aircraftIds, project.getId(), existingAirbusChangeGroup.getId());

    // assert
    verify(mockChangeGroupRepo, times(1)).findAllByProjectId(isA(UUID.class));
    verify(mockAircraftService, times(1)).findByIdIn(anyList());
  }
  /** updateEffectivity Section (end) */
  @Test
  public void when_updateChangeGroupName_then_save() {
    // arrange
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();
    String name = "test";

    // mock(s)
    when(mockChangeGroupRepo.findById(any(UUID.class)))
        .thenReturn(Optional.of(project.getChangeGroups().get(0)));

    // act
    subject.updateChangeGroupName(project.getChangeGroups().get(0).getId(), name);

    // assert
    verify(mockChangeGroupRepo, times(1)).findById(any(UUID.class));
    assertEquals(name, project.getChangeGroups().get(0).getName());
  }

  @Test(expected = NotFoundException.class)
  public void when_updateChangeGroupName_with_missing_changeGroup_then_throw_NotFoundException() {
    // arrange
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // mock(s)
    when(mockChangeGroupRepo.findById(any(UUID.class))).thenReturn(Optional.empty());

    // act
    subject.updateChangeGroupName(project.getChangeGroups().get(0).getId(), "test");
  }

  @Test(expected = BadRequestException.class)
  public void when_updateChangeGroupName_with_blank_name_then_throw_BadRequestException() {
    // arrange
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // mock(s)
    when(mockChangeGroupRepo.findById(any(UUID.class)))
        .thenReturn(Optional.of(project.getChangeGroups().get(0)));

    // empty name
    String name = "";

    // act
    subject.updateChangeGroupName(project.getChangeGroups().get(0).getId(), name);
  }

  @Test(expected = ConflictException.class)
  public void
      when_updateChangeGroupName_with_same_name_as_existing_change_group_then_throw_ConflictException() {
    // arrange
    // project
    Project project = createProjectWithChangeGroupsAndEffectivities();

    // change group
    ChangeGroup changeGroup = project.getChangeGroups().get(0);

    // mock(s)
    when(mockChangeGroupRepo.findById(any(UUID.class))).thenReturn(Optional.of(changeGroup));

    // set name the same as existing CG
    String name = changeGroup.getName();

    // act
    subject.updateChangeGroupName(changeGroup.getId(), name);
  }

  private Change createChange(
      ChangeGroup changeGroup, String electIdent, String nodeName, ActionType action) {
    Change change = new Change();
    change.setId(UUID.randomUUID());
    change.setAction(action);
    change.setChangeGroup(changeGroup);
    change.setComponentElectIdent(electIdent);
    change.setNodeName(nodeName);
    change.setChanger(KEYCLOAK_USER_GUID);
    change.setComponentChange(
        createComponentChange(
            "componentA",
            false,
            "123",
            "1HQ",
            ElectricalPhase.AC3,
            "123VU",
            false,
            false,
            6211.8D));

    return change;
  }

  private Change createChange(
      ChangeGroup changeGroup,
      String electIdent,
      String nodeName,
      ActionType action,
      ComponentChange componentChange) {
    Change change = new Change();
    change.setId(UUID.randomUUID());
    change.setAction(action);
    change.setChangeGroup(changeGroup);
    change.setComponentElectIdent(electIdent);
    change.setNodeName(nodeName);
    change.setChanger(KEYCLOAK_USER_GUID);
    change.setComponentChange(componentChange);
    return change;
  }

  private List<ChangeGroupMappedNodeDto> createChangeGroupMappedNodeDtos() {
    return Arrays.asList(
        new ChangeGroupMappedNodeDto(1L, "101XP", "101XP", 1, 1),
        new ChangeGroupMappedNodeDto(2L, "102XP", "102XP", 2, 1),
        new ChangeGroupMappedNodeDto(11L, "101XP", "101XP", 1, 1));
  }

  private List<Component> createComponents(int count, String nodeName) {
    List<Component> components = new ArrayList<>();

    Node node = createNode(nodeName);

    for (int i = 1; i <= count; i++) {
      components.add(
          createComponent(
              (long) i, String.format("test component %s", i), node, String.format("H123_%s", i)));
    }
    return components;
  }

  private Component createComponent(Long id, String name, Node node, String electIdent) {
    Component component = new Component();
    component.setElectricalPhase(ElectricalPhase.AC3);
    component.setId(id);
    component.setClipsed(false);
    component.setNominalPower(2500d);
    component.setConnectedLoadPf(1d);
    component.setConnectedLoadVa(1d);
    component.setName(name);
    component.setDisplayOrder(1);
    component.setAta("123");
    component.setElectIdent(electIdent);
    component.setPanel("test");
    component.setSheddable(false);
    component.setIntermittent(false);
    component.setNode(node);
    return component;
  }

  private ComponentChange createComponentChange(
      String name,
      boolean clipsed,
      String ata,
      String electIdent,
      ElectricalPhase electricalPhase,
      String panel,
      boolean sheddable,
      Boolean intermittent,
      Double nomPower) {
    ComponentChange componentChange = new ComponentChange();
    componentChange.setName(name);
    componentChange.setClipsed(clipsed);
    componentChange.setAta(ata);
    componentChange.setElectIdent(electIdent);
    componentChange.setElectricalPhase(electricalPhase);
    componentChange.setPanel(panel);
    componentChange.setSheddable(sheddable);
    componentChange.setNominalPower(nomPower);
    componentChange.setIntermittent(intermittent);

    return componentChange;
  }

  private ComponentChange createComponentChange(
      String name,
      boolean clipsed,
      String ata,
      String electIdent,
      ElectricalPhase electricalPhase,
      String panel,
      boolean sheddable,
      Boolean intermittent,
      Double nomPower,
      Double connectedLoadVa,
      Double connectedLoadPf) {
    ComponentChange componentChange = new ComponentChange();
    componentChange.setName(name);
    componentChange.setClipsed(clipsed);
    componentChange.setAta(ata);
    componentChange.setElectIdent(electIdent);
    componentChange.setElectricalPhase(electricalPhase);
    componentChange.setPanel(panel);
    componentChange.setSheddable(sheddable);
    componentChange.setNominalPower(nomPower);
    componentChange.setIntermittent(intermittent);
    componentChange.setConnectedLoadVa(connectedLoadVa);
    componentChange.setConnectedLoadPf(connectedLoadPf);

    return componentChange;
  }

  private List<Load> createLoads(Component c) {
    return Arrays.asList(
        new Load(.9, "GROUND", "OPERATIONAL", c, 1d), new Load(1.0, "TAXI", "OPERATIONAL", c, 1d));
  }

  private Aircraft createAircraft(String shipNo, Fleet fleet) {
    Aircraft aircraft =
        new Aircraft(
            shipNo,
            RandomStringUtils.random(5, false, true),
            RandomStringUtils.random(6, true, true),
            RandomStringUtils.random(3, false, true),
            RandomStringUtils.random(5, true, true),
            fleet);
    aircraft.setId(new Random().nextLong());
    return aircraft;
  }

  private Fleet createFleet(String busStructureBucket) {
    Fleet fleet = new Fleet();
    fleet.setBusStructureBucket(busStructureBucket);
    return fleet;
  }

  private Project createProject(String title) {
    Project project = new Project();
    project.setId(UUID.randomUUID());
    project.setTitle(title);
    project.setNumber("1");
    project.setMaintenanceDescription("maintenance description");
    project.setStarted(Instant.now());
    return project;
  }

  private ChangeGroup createChangeGroup(String name) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setId(UUID.randomUUID());
    changeGroup.setName(name);
    return changeGroup;
  }

  private AircraftChangeGroup createAircraftChangeGroup() {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setId(UUID.randomUUID());
    return aircraftChangeGroup;
  }

  private AircraftChangeGroup createAircraftChangeGroup(
      ChangeGroup changeGroup, Aircraft aircraft) {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setId(UUID.randomUUID());
    aircraftChangeGroup.setChangeGroup(changeGroup);
    aircraftChangeGroup.setAircraft(aircraft);
    return aircraftChangeGroup;
  }

  private Node createNode(String name) {
    Node node = new Node();
    node.setName(name);
    return node;
  }

  private AircraftBusStructureBucketDto createAircraftBusStructureBucketDto(
      Aircraft aircraft, String busStructureBucketName) {
    AircraftBusStructureBucketDto newItem = new AircraftBusStructureBucketDto();
    newItem.setName(busStructureBucketName);

    List<Aircraft> newAircraft = Lists.newArrayList(aircraft);
    newItem.setAircraft(newAircraft);

    return newItem;
  }

  private Project createProjectWithChangeGroupsAndEffectivities() {
    // project
    Project project = createProject("project1");

    // aircrafts
    Aircraft aircraft1 = new Aircraft();
    aircraft1.setFleet(new Fleet());
    Aircraft aircraft2 = new Aircraft();
    aircraft2.setFleet(new Fleet());

    // aircraft change group
    AircraftChangeGroup aircraftChangeGroup1 = createAircraftChangeGroup();
    aircraftChangeGroup1.setAircraft(aircraft1);

    AircraftChangeGroup aircraftChangeGroup2 = createAircraftChangeGroup();
    aircraftChangeGroup2.setAircraft(aircraft2);

    // change groups
    ChangeGroup changeGroup1 = createChangeGroup("Airbus 1");
    changeGroup1.setAircraftChangeGroups(Lists.newArrayList(aircraftChangeGroup1));
    changeGroup1.setProject(project);

    ChangeGroup changeGroup2 = createChangeGroup("Boeing 1");
    changeGroup2.setAircraftChangeGroups(Lists.newArrayList(aircraftChangeGroup2));
    changeGroup2.setProject(project);

    List<ChangeGroup> changeGroups = Lists.newArrayList(changeGroup1, changeGroup2);

    project.setChangeGroups(changeGroups);

    return project;
  }
}
