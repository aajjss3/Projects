package com.seatec.ela.app.service.project;

import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.dto.analysis.Analysis;
import com.seatec.ela.app.dto.analysis.AnalysisLoad;
import com.seatec.ela.app.dto.analysis.AnalysisLoad.Units;
import com.seatec.ela.app.dto.analysis.AnalysisNode;
import com.seatec.ela.app.dto.analysis.AnalysisType;
import com.seatec.ela.app.dto.analysis.ProjectAnalysis;
import com.seatec.ela.app.dto.analysis.StandbyOperation;
import com.seatec.ela.app.dto.report.ProjectReportChangeGroupDTO;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyType;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.EfficiencyTableRepo;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.NodeChangeRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.model.repository.project.change.ChangeRepo;
import com.seatec.ela.app.service.ElaAnalysisService;
import com.seatec.ela.app.service.NodeService;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ProjectAnalysisIT extends AbstractControllerIntegrationTest {

  @Autowired private ProjectAnalysisService projectAnalysisService;

  @Autowired ElaAnalysisService elaAnalysisService;

  @Autowired ElaRepository elaRepo;

  @Autowired AircraftRepository aircraftRepo;

  @Autowired NodeRepository nodeRepo;

  @Autowired ComponentRepository componentRepo;

  @Autowired LoadRepository loadRepo;

  @Autowired EfficiencyTableRepo efficiencyTableRepo;

  @Autowired ChangeGroupRepo changeGroupRepo;

  @Autowired AircraftChangeGroupRepo aircraftChangeGroupRepo;

  @Autowired ProjectRepo projectRepo;

  @Autowired ChangeRepo changeRepo;

  @Autowired NodeChangeRepo nodeChangeRepo;

  @Autowired NodeService nodeService;

  private Project project;
  private Project projectApproved;
  private ChangeGroup changeGroup;
  private ChangeGroup changeGroupApproved;
  private Ela ela;
  private Node node2;
  private Aircraft aircraft;
  private Aircraft aircraftApproved;
  private Node node1;

  @Before
  public void setup() {
    initializeDatabase();
  }

  // get aircraft analysis for editing a bus node - change the nodes bus rating from 300 to 250
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenEditNode() throws JsonProcessingException {

    NodeChange nodeChange =
        createNodeChange(
            250d,
            "three",
            5d,
            ElectricalPhase.DC,
            NodeType.BUS,
            10d,
            false,
            false,
            false,
            ElectricalPhase.AC3);

    Change change =
        createAndSaveChange(
            "three", null, ActionType.EDIT, "person making change", nodeChange, null, changeGroup);

    List<Change> changes = new ArrayList<>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisBusNode = projectAnalysis.getBusNodes().get(0);
    assertEquals(projectAnalysisBusNode.getName(), "three");
    assertEquals(projectAnalysisBusNode.getRating(), new Double(250d));
    List<String> flightPhases =
        projectAnalysisBusNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getFlightPhase)
            .collect(Collectors.toList());
    List<String> electricalPhases =
        projectAnalysisBusNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getElectricalPhase)
            .collect(Collectors.toList());
    List<Double> results =
        projectAnalysisBusNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getResult)
            .collect(Collectors.toList());
    List<Double> values =
        projectAnalysisBusNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getValue)
            .collect(Collectors.toList());
    assertThat(flightPhases, containsInAnyOrder("ground", "roll"));
    assertThat(electricalPhases, containsInAnyOrder("DC", "DC"));
    assertThat(results, containsInAnyOrder(6.4, 3.2));
    assertThat(values, containsInAnyOrder(8.0, 16.0));
  }

  // get aircraft analysis for editing a bus component - change the components nominal power from 10
  // to 23
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenEditComponent()
      throws JsonProcessingException {

    LoadChange load1ForComponent3 = new LoadChange();
    load1ForComponent3.setVa(92d);
    load1ForComponent3.setPowerFactor(1d);
    load1ForComponent3.setFlightPhase("roll");
    load1ForComponent3.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    LoadChange load2ForComponent3 = new LoadChange();
    load2ForComponent3.setVa(184d);
    load2ForComponent3.setPowerFactor(1d);
    load2ForComponent3.setFlightPhase("ground");
    load2ForComponent3.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    List<LoadChange> loadChanges = new ArrayList<LoadChange>();
    loadChanges.add(load1ForComponent3);
    loadChanges.add(load2ForComponent3);

    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component3");
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setName("component3");
    componentChange.setNominalPower(230d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    componentChange.setLoadChanges(loadChanges);

    Change change = new Change();
    change.setNodeName("three");
    change.setAction(ActionType.EDIT);
    change.setChanger("person making change");
    change.setComponentChange(componentChange);
    change.setComponentElectIdent("component3");
    change.setChangeGroup(changeGroup);
    changeRepo.save(change);

    List<Change> changes = new ArrayList<Change>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisNode = projectAnalysis.getBusNodes().get(0);
    assertEquals("three", projectAnalysisNode.getName());
    assertEquals(new Double(300), projectAnalysisNode.getRating());
    assertEquals(2, projectAnalysisNode.getAnalysisLoads().size());
    List<Double> results =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getResult)
            .collect(Collectors.toList());
    List<Double> values =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getValue)
            .collect(Collectors.toList());
    List<String> flightPhases =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getFlightPhase)
            .collect(Collectors.toList());
    List<String> electricalPhases =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getElectricalPhase)
            .collect(Collectors.toList());
    assertThat(results, containsInAnyOrder(12.266666666666666, 6.133333333333333));
    assertThat(values, containsInAnyOrder(36.8, 18.4));
    assertThat(flightPhases, containsInAnyOrder("ground", "roll"));
    assertThat(electricalPhases, containsInAnyOrder("DC", "DC"));
  }

  // get aircraft analysis for editing a bus load - change the load value from 8 to 10 for 'ground'
  // only
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenEditLoad() throws JsonProcessingException {

    LoadChange loadChange = new LoadChange();
    loadChange.setVa(100d);
    loadChange.setPowerFactor(1d);
    loadChange.setFlightPhase("ground");
    loadChange.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    List<LoadChange> loadChanges = new ArrayList<LoadChange>();
    loadChanges.add(loadChange);

    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component3");
    componentChange.setName("component3");
    componentChange.setLoadChanges(loadChanges);
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setNominalPower(1000d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    loadChange.setComponentChange(componentChange);

    Change change = new Change();
    change.setNodeName("three");
    change.setAction(ActionType.EDIT);
    change.setChanger("person making change");
    change.setComponentChange(componentChange);
    change.setComponentElectIdent("component3");
    change.setChangeGroup(changeGroup);
    changeRepo.save(change);

    List<Change> changes = new ArrayList<Change>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalysesPostChange.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();
    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisNode = projectAnalysis.getBusNodes().get(0);
    assertEquals(projectAnalysisNode.getName(), "three");
    assertEquals(projectAnalysisNode.getRating(), new Double(300));
    assertEquals(projectAnalysisNode.getAnalysisLoads().size(), 2);
    List<Double> results =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getResult)
            .collect(Collectors.toList());
    List<Double> values =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getValue)
            .collect(Collectors.toList());
    List<String> flightPhases =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getFlightPhase)
            .collect(Collectors.toList());
    List<String> electricalPhases =
        projectAnalysisNode.getAnalysisLoads().stream()
            .map(AnalysisLoad::getElectricalPhase)
            .collect(Collectors.toList());
    assertThat(results, containsInAnyOrder(6.666666666666667, 2.666666666666667));
    assertThat(values, containsInAnyOrder(20.0, 8.0));
    assertThat(flightPhases, containsInAnyOrder("ground", "roll"));
    assertThat(electricalPhases, containsInAnyOrder("DC", "DC"));
  }

  // get aircraft analysis for deleting a bus node and its components and the components loads -
  // delete node 'four'
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenDeleteNodeAndComponentAndLoad()
      throws JsonProcessingException {

    // add another node tree
    addNode4WithComponentsAndLoads();

    // delete a node
    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(300d);
    nodeChange.setName("four");
    nodeChange.setNodeType(NodeType.BUS);
    nodeChange.setNominalPower(10d);
    nodeChange.setRequiresApproval(false);
    nodeChange.setSheddable(false);
    nodeChange.setVoltageType(ElectricalPhase.DC);
    nodeChange.setVoltage(5d);

    Change change = new Change();
    change.setNodeName("four");
    change.setAction(ActionType.DELETE);
    change.setChanger("person making change");
    change.setNodeChange(nodeChange);
    change.setComponentElectIdent("component3");
    change.setChangeGroup(changeGroup);
    changeGroup.addChange(change);
    changeRepo.save(change);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    assertEquals(projectAnalysis.getBusNodes().size(), 1);
    assertEquals(projectAnalysis.getBusNodes().size(), 1);
    AnalysisNode projectAnalysisNode = projectAnalysis.getBusNodes().get(0);
    assertEquals(projectAnalysisNode.getName(), "three");
  }

  // get aircraft analysis for deleting a bus component and its loads - delete component 'five'
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenDeleteComponentAndLoad()
      throws JsonProcessingException {

    // add another node tree
    Node addedNode4 = addNode4WithComponentsAndLoads();
    assertNotNull(addedNode4.getParentNode());
    assertNotNull(addedNode4.getParentNode().getParentNode());
    assertNotNull(addedNode4.getParentNode().getParentNode().getEla());

    // delete a component
    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component5");
    componentChange.setName("component5");
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setNominalPower(10d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);

    Change change = new Change();
    change.setNodeName("four");
    change.setAction(ActionType.DELETE);
    change.setChanger("person making change");
    change.setComponentChange(componentChange);
    change.setComponentElectIdent("component5");
    changeGroup.addChange(change);
    changeRepo.save(change);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(2, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisNode =
        projectAnalysis.getBusNodes().stream()
            .filter(analysisNode -> analysisNode.getName().equalsIgnoreCase("four"))
            .findFirst()
            .get();
    assertEquals(projectAnalysisNode.getAnalysisLoads().size(), 1);
    AnalysisLoad projectAnalysisLoad = projectAnalysisNode.getAnalysisLoads().get(0);
    assertEquals(projectAnalysisLoad.getValue(), new Double(20.0d));
    assertEquals(projectAnalysisLoad.getResult(), new Double(5.714285714285714d));
    assertEquals(projectAnalysisLoad.getElectricalPhase(), "DC");
    assertEquals(projectAnalysisLoad.getFlightPhase(), "roll");
  }

  // get aircraft analysis for adding a bus node, a component and loads
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenAddNodeAndComponentAndLoad()
      throws JsonProcessingException {

    // node
    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(350d);
    nodeChange.setName("four");
    nodeChange.setNodeType(NodeType.BUS);
    nodeChange.setVoltage(20d);
    nodeChange.setVoltageType(ElectricalPhase.DC);
    nodeChange.setNominalPower(20d);
    nodeChange.setRequiresApproval(false);
    nodeChange.setSheddable(false);

    Change changeAddNode = new Change();
    changeAddNode.setNodeName("two"); // parent node
    changeAddNode.setAction(ActionType.ADD);
    changeAddNode.setChanger("person making change");
    changeAddNode.setNodeChange(nodeChange);
    changeAddNode.setChangeGroup(changeGroup);
    changeRepo.save(changeAddNode);

    // load and component
    LoadChange loadChange = new LoadChange();
    loadChange.setVa(200d);
    loadChange.setPowerFactor(1d);
    loadChange.setFlightPhase("roll");
    loadChange.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component4");
    componentChange.setName("component4");
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setNominalPower(200d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);

    componentChange.addLoadChange(loadChange);

    Change changeAddComponent = new Change();
    changeAddComponent.setNodeName("four");
    changeAddComponent.setAction(ActionType.ADD);
    changeAddComponent.setChanger("person making change");
    changeAddComponent.setComponentChange(componentChange);
    changeAddComponent.setComponentElectIdent("component4");
    changeAddComponent.setChangeGroup(changeGroup);
    changeRepo.save(changeAddComponent);

    changeGroup.addChange(changeAddNode);
    changeGroup.addChange(changeAddComponent);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();
    assertEquals(projectAnalysis.getTruNodes().size(), 1);
    assertEquals(projectAnalysis.getBusNodes().size(), 2);
    assertEquals(projectAnalysis.getGeneratorNodes().size(), 1);
    List<AnalysisNode> projectAnalysisNodes = projectAnalysis.getBusNodes();
    for (AnalysisNode projectAnalysisNode : projectAnalysisNodes) {
      List<Double> results =
          projectAnalysisNode.getAnalysisLoads().stream()
              .map(AnalysisLoad::getResult)
              .collect(Collectors.toList());
      List<Double> values =
          projectAnalysisNode.getAnalysisLoads().stream()
              .map(AnalysisLoad::getValue)
              .collect(Collectors.toList());
      List<String> flightPhases =
          projectAnalysisNode.getAnalysisLoads().stream()
              .map(AnalysisLoad::getFlightPhase)
              .collect(Collectors.toList());
      List<String> electricalPhases =
          projectAnalysisNode.getAnalysisLoads().stream()
              .map(AnalysisLoad::getElectricalPhase)
              .collect(Collectors.toList());
      if (projectAnalysisNode.getName().equals("three")) {
        assertEquals(projectAnalysisNode.getAnalysisLoads().size(), 2);
        assertThat(results, containsInAnyOrder(5.333333333333334d, 2.666666666666667d));
        assertThat(values, containsInAnyOrder(16.0d, 8.0d));
        assertThat(flightPhases, containsInAnyOrder("ground", "roll"));
        assertThat(electricalPhases, containsInAnyOrder("DC", "DC"));
      }
      if (projectAnalysisNode.getName().equals("four")) {
        assertEquals(projectAnalysisNode.getAnalysisLoads().size(), 1);
        assertThat(results, containsInAnyOrder(2.857142857142857d));
        assertThat(values, containsInAnyOrder(10.0d));
        assertThat(flightPhases, containsInAnyOrder("roll"));
        assertThat(electricalPhases, containsInAnyOrder("DC"));
      }
    }
  }

  // get aircraft analysis for adding a transformer node and then add a bus with a load under the
  // transformer
  @Test
  public void shouldGetProjectAnalysisForAircraftWhenAddTruTransformerNode() throws Exception {

    // add an TRU transformer
    NodeChange truNodeChange =
        createNodeChange(
            350d,
            "four",
            20d,
            ElectricalPhase.AC3,
            NodeType.TRU,
            20d,
            false,
            false,
            true,
            ElectricalPhase.AC3);

    Change changeAddTruNode =
        createAndSaveChange(
            "one", null, ActionType.ADD, "person making change", truNodeChange, null, changeGroup);

    // added since the order the changes are created matters (order is based on the change.created
    // field). by sleeping for 5 millisecs it guarantees the change prior will have an earlier
    // created timestamp than the change after. Since created field is annotated with
    // CreationTimestamp cannot override it.
    Thread.sleep(5);

    // add a Bus under the transformer
    NodeChange busNodeChange =
        createNodeChange(
            350d,
            "five",
            20d,
            ElectricalPhase.DC,
            NodeType.BUS,
            20d,
            false,
            false,
            false,
            ElectricalPhase.AC3);

    Change changeAddBusNode =
        createAndSaveChange(
            "four", null, ActionType.ADD, "person making change", busNodeChange, null, changeGroup);

    // add a Component and Load to the Bus
    LoadChange loadChange = new LoadChange();
    loadChange.setVa(200d);
    loadChange.setPowerFactor(1d);
    loadChange.setFlightPhase("roll");
    loadChange.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component6");
    componentChange.setName("component6");
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setNominalPower(200d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    componentChange.addLoadChange(loadChange);

    Change changeAddComponent = new Change();
    changeAddComponent.setNodeName("five"); // parent node
    changeAddComponent.setAction(ActionType.ADD);
    changeAddComponent.setChanger("person making change");
    changeAddComponent.setComponentChange(componentChange);
    changeAddComponent.setComponentElectIdent("component6");
    changeAddComponent.setChangeGroup(changeGroup);
    changeRepo.save(changeAddComponent);

    changeGroup.addChange(changeAddTruNode);
    changeGroup.addChange(changeAddBusNode);
    changeGroup.addChange(changeAddComponent);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    AnalysisType normalAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();
    assertEquals(2, normalAnalysis.getTruNodes().size());
    assertEquals(2, normalAnalysis.getBusNodes().size());
    assertEquals(new Double(20d), normalAnalysis.getTruNodes().get(0).getRating());
  }

  @Test
  public void shouldGetChangeToGeneratorLoadForAircraftWhenChangeBusLoad()
      throws JsonProcessingException {

    List<ProjectAnalysis> projectAnalysesPreChange =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalysesPreChange.get(0)));
    AnalysisType projectAnalysisPreChange =
        projectAnalysesPreChange.get(0).getAnalysis().getNormalAnalysis();
    List<AnalysisLoad> preGeneratorLoads =
        projectAnalysisPreChange.getGeneratorNodes().get(0).getAnalysisLoads();
    AnalysisLoad preGeneratorLoadForRoll =
        preGeneratorLoads.stream()
            .filter(load -> load.getFlightPhase().equalsIgnoreCase("ground"))
            .findFirst()
            .get();

    LoadChange loadChange = new LoadChange();
    loadChange.setVa(100d);
    loadChange.setPowerFactor(1d);
    loadChange.setFlightPhase("ground");
    loadChange.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);

    List<LoadChange> loadChanges = new ArrayList<LoadChange>();
    loadChanges.add(loadChange);

    ComponentChange componentChange = new ComponentChange();
    componentChange.setElectIdent("component3");
    componentChange.setName("component3");
    componentChange.setLoadChanges(loadChanges);
    componentChange.setElectricalPhase(ElectricalPhase.DC);
    componentChange.setNominalPower(100d);
    componentChange.setSheddable(Boolean.FALSE);
    componentChange.setIntermittent(Boolean.FALSE);
    loadChange.setComponentChange(componentChange);

    Change change = new Change();
    change.setNodeName("three");
    change.setAction(ActionType.EDIT);
    change.setChanger("person making change");
    change.setComponentChange(componentChange);
    change.setComponentElectIdent("component3");
    change.setChangeGroup(changeGroup);
    changeRepo.save(change);

    List<Change> changes = new ArrayList<Change>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalysesPostChange =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalysesPostChange.get(0)));
    AnalysisType projectAnalysisPostChange =
        projectAnalysesPostChange.get(0).getAnalysis().getNormalAnalysis();
    List<AnalysisLoad> postGeneratorLoads =
        projectAnalysisPostChange.getGeneratorNodes().get(0).getAnalysisLoads();
    AnalysisLoad postGeneratorLoadForRoll =
        postGeneratorLoads.stream()
            .filter(load -> load.getFlightPhase().equalsIgnoreCase("ground"))
            .findFirst()
            .get();

    assertFalse(preGeneratorLoadForRoll.equals(postGeneratorLoadForRoll));
  }

  // get change group analysis for editing a bus node - change the nodes bus rating from 300 to 250
  // status - PASS
  @Test
  public void shouldGetProjectAnalysisForChangeGroupWhenEditNodePASS()
      throws JsonProcessingException {

    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(250d);
    nodeChange.setName("three");
    nodeChange.setVoltage(5d);
    nodeChange.setVoltageType(ElectricalPhase.DC);
    nodeChange.setNodeType(NodeType.BUS);
    nodeChange.setNominalPower(10d);
    nodeChange.setRequiresApproval(false);
    nodeChange.setSheddable(false);

    Change change = new Change();
    change.setNodeName("three");
    change.setAction(ActionType.EDIT);
    change.setChanger("person making change");
    change.setNodeChange(nodeChange);
    change.setChangeGroup(changeGroup);
    changeRepo.save(change);

    List<Change> changes = new ArrayList<Change>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), null, true);
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisBusNode = projectAnalysis.getBusNodes().get(0);
    AnalysisNode projectAnalysisTruNode = projectAnalysis.getTruNodes().get(0);
    AnalysisNode projectAnalysisGeneratorNode = projectAnalysis.getGeneratorNodes().get(0);
    assertTrue(projectAnalysisBusNode.getAnalysisLoads().isEmpty());
    assertTrue(projectAnalysisTruNode.getAnalysisLoads().isEmpty());
    assertTrue(projectAnalysisGeneratorNode.getAnalysisLoads().isEmpty());
    assertTrue(projectAnalysisBusNode.getStatus() == AnalysisStatus.PASS);
    assertTrue(projectAnalysisTruNode.getStatus() == AnalysisStatus.PASS);
    assertTrue(projectAnalysisGeneratorNode.getStatus() == AnalysisStatus.PASS);
    assertTrue(projectAnalyses.get(0).getAnalysis().getNormalStatus() == AnalysisStatus.PASS);
  }

  // get change group analysis for editing a bus node - change the nodes bus rating from 300 to .01
  // status - FAIL
  @Test
  public void shouldGetProjectAnalysisForChangeGroupWhenEditNodeFAIL()
      throws JsonProcessingException {

    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(.01d);
    nodeChange.setName("three");
    nodeChange.setVoltage(5d);
    nodeChange.setVoltageType(ElectricalPhase.DC);
    nodeChange.setNodeType(NodeType.BUS);
    nodeChange.setNominalPower(10d);
    nodeChange.setRequiresApproval(false);
    nodeChange.setSheddable(false);

    Change change = new Change();
    change.setNodeName("three");
    change.setAction(ActionType.EDIT);
    change.setChanger("person making change");
    change.setNodeChange(nodeChange);
    change.setChangeGroup(changeGroup);
    changeRepo.save(change);

    List<Change> changes = new ArrayList<Change>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), null, true);
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();
    // System.out.println(new
    // ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(projectAnalyses.get(0)));
    assertEquals(1, projectAnalysis.getTruNodes().size());
    assertEquals(1, projectAnalysis.getBusNodes().size());
    assertEquals(1, projectAnalysis.getGeneratorNodes().size());
    AnalysisNode projectAnalysisBusNode = projectAnalysis.getBusNodes().get(0);
    AnalysisNode projectAnalysisTruNode = projectAnalysis.getTruNodes().get(0);
    AnalysisNode projectAnalysisGeneratorNode = projectAnalysis.getGeneratorNodes().get(0);
    assertTrue(projectAnalysisBusNode.getAnalysisLoads().isEmpty());
    assertTrue(projectAnalysisTruNode.getAnalysisLoads().isEmpty());
    assertTrue(projectAnalysisGeneratorNode.getAnalysisLoads().isEmpty());
    assertEquals(projectAnalysisBusNode.getStatus(), AnalysisStatus.FAIL);
    assertEquals(projectAnalysisTruNode.getStatus(), AnalysisStatus.PASS);
    assertEquals(projectAnalysisGeneratorNode.getStatus(), AnalysisStatus.PASS);
    assertEquals(projectAnalyses.get(0).getAnalysis().getNormalStatus(), AnalysisStatus.FAIL);
  }

  @Test
  public void shouldGetProjectAnalysisForApprovedAircraftWhenChangeGroupIdOnly() {
    // save project analysis
    int nbrOfAtuNodes = 2;
    int nbrOfBusNodes = 2;
    int nbrOfGenNodes = 2;
    int nbrOfTruNodes = 2;
    ProjectReportDTO projectReportDTO =
        createProjectReportDTO(
            changeGroupApproved, nbrOfTruNodes, nbrOfAtuNodes, nbrOfGenNodes, nbrOfBusNodes);
    saveProjectAnalysis(projectApproved, projectReportDTO);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroupApproved.getId(), null, false);
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(nbrOfAtuNodes, projectAnalysis.getAtuNodes().size());
    assertEquals(nbrOfTruNodes, projectAnalysis.getTruNodes().size());
    assertEquals(nbrOfBusNodes, projectAnalysis.getBusNodes().size());
    assertEquals(nbrOfGenNodes, projectAnalysis.getGeneratorNodes().size());
  }

  @Test
  public void shouldGetProjectAnalysisForApprovedAircraftWhenChangeGroupIdAndAircraftId() {
    // save project analysis
    int nbrOfAtuNodes = 2;
    int nbrOfBusNodes = 2;
    int nbrOfGenNodes = 2;
    int nbrOfTruNodes = 2;

    ProjectReportDTO projectReportDTO =
        createProjectReportDTO(
            changeGroupApproved, nbrOfTruNodes, nbrOfAtuNodes, nbrOfGenNodes, nbrOfBusNodes);
    saveProjectAnalysis(projectApproved, projectReportDTO);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(
            changeGroupApproved.getId(), aircraftApproved.getId(), false);
    AnalysisType projectAnalysis = projectAnalyses.get(0).getAnalysis().getNormalAnalysis();

    assertEquals(nbrOfAtuNodes, projectAnalysis.getAtuNodes().size());
    assertEquals(nbrOfTruNodes, projectAnalysis.getTruNodes().size());
    assertEquals(nbrOfBusNodes, projectAnalysis.getBusNodes().size());
    assertEquals(nbrOfGenNodes, projectAnalysis.getGeneratorNodes().size());
  }

  // get aircraft analysis with standby operation analysis for boeing aircraft.
  @Test
  @Transactional
  public void shouldGetProjectAnalysisWithStandbyOperationForBoeingAircraft()
      throws JsonProcessingException {

    // set the manufacture for the aircraft as Boeing and the battery charge to DUAL 40AH
    aircraft.setBatteryCharge(BatteryChargeType.DUAL_40AH);
    aircraft.getFleet().setManufacturer("Boeing");

    NodeChange nodeChange =
        createNodeChange(
            250d,
            "three",
            5d,
            ElectricalPhase.DC,
            NodeType.BUS,
            10d,
            false,
            false,
            false,
            ElectricalPhase.AC3);
    Change change =
        createAndSaveChange(
            "three", null, ActionType.EDIT, "person making change", nodeChange, null, changeGroup);
    List<Change> changes = new ArrayList<>();
    changes.add(change);
    changeGroup.setChanges(changes);

    List<ProjectAnalysis> projectAnalyses =
        projectAnalysisService.getAnalysis(changeGroup.getId(), aircraft.getId(), false);
    StandbyOperation standbyOperation = projectAnalyses.get(0).getAnalysis().getStandbyOperation();
    assertEquals(new Double(30.0d), new Double(standbyOperation.getRequiredBatteryLifeInMinutes()));
    assertEquals(AnalysisStatus.PASS, standbyOperation.getStatus());
    assertEquals(BatteryChargeType.DUAL_40AH, standbyOperation.getBatteryCapacity());
  }

  private Node addNode4WithComponentsAndLoads() {
    Node node4 = new Node();
    node4.setRequiresApproval(false);
    node4.setName("four");
    node4.setVoltage(10d);
    node4.setNominalPower(20d);
    node4.setNodeType(NodeType.BUS);
    node4.setRequiresApproval(false);
    node4.setBusRating(350d);
    node4.setVoltageType(ElectricalPhase.DC);
    node4.setDisplayOrder(4);
    node2.addSubNode(node4);
    nodeRepo.save(node4);
    nodeRepo.save(node2);

    Component component4 = new Component();
    component4.setElectricalPhase(ElectricalPhase.DC);
    component4.setElectIdent("component4");
    component4.setNominalPower(20d);
    component4.setName("component4");
    component4.setDisplayOrder(2);
    component4.setSheddable(Boolean.FALSE);
    component4.setIntermittent(Boolean.FALSE);
    node4.addComponent(component4);
    componentRepo.save(component4);

    Load load1ForComponent4 = new Load();
    load1ForComponent4.setVa(200d);
    load1ForComponent4.setPowerFactor(1d);
    load1ForComponent4.setComponent(component4);
    load1ForComponent4.setFlightPhase("roll");
    load1ForComponent4.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    component4.addLoad(load1ForComponent4);
    loadRepo.save(load1ForComponent4);

    Component component5 = new Component();
    component5.setElectricalPhase(ElectricalPhase.DC);
    component5.setElectIdent("component5");
    component5.setNominalPower(20d);
    component5.setName("component5");
    component5.setDisplayOrder(3);
    component5.setSheddable(Boolean.FALSE);
    component5.setIntermittent(Boolean.FALSE);
    node4.addComponent(component5);
    componentRepo.save(component5);

    Load load1ForComponent5 = new Load();
    load1ForComponent5.setVa(200d);
    load1ForComponent5.setPowerFactor(1d);
    load1ForComponent5.setComponent(component5);
    load1ForComponent5.setFlightPhase("roll");
    load1ForComponent5.setOperatingMode(ElaAnalysisService.AIRBUS_NORMAL_CALCULATION);
    component5.addLoad(load1ForComponent5);
    loadRepo.save(load1ForComponent5);
    return node4;
  }

  private void initializeDatabase() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    aircraft = createAndSaveAircraft(1, fleet);
    aircraftApproved = createAndSaveAircraft(2, fleet);

    // ela
    ela = createAndSaveEla("test1", aircraft);

    // project
    project = createAndSaveProject("project one", "100", true, false);
    projectApproved = createAndSaveProject("project approved", "200", true, true);

    // change group
    changeGroup = createAndSaveChangeGroup("change group", project);
    changeGroupApproved = createAndSaveChangeGroup("change group Approved", projectApproved);

    // aircraft change group
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);
    createAndSaveAircraftChangeGroup(aircraftApproved, changeGroupApproved);

    // nodes
    node1 =
        createAndSaveNode(
            false, "one", 5d, 100000d, NodeType.GENERATOR, 100d, ElectricalPhase.AC3, 1, null, ela);
    node2 =
        createAndSaveNode(
            false, "two", 5d, 20d, NodeType.TRU, 100d, ElectricalPhase.DC, 2, node1, null);
    Node node3 =
        createAndSaveNode(
            false, "three", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.DC, 3, node2, null);

    // component
    Component component3 = createAndSaveComponent(node3, "component3", ElectricalPhase.DC, 20d, 1);

    // loads
    createAndSaveLoad(component3, "roll", ElaAnalysisService.AIRBUS_NORMAL_CALCULATION, 40d, 1d);
    createAndSaveLoad(component3, "ground", ElaAnalysisService.AIRBUS_NORMAL_CALCULATION, 80d, 1d);

    // TRU efficiency power factor
    EfficiencyLoad efficiencyLoadLower = new EfficiencyLoad(10d, 10d, 1d, 4d, 40d);
    EfficiencyLoad efficiencyLoadUpper = new EfficiencyLoad(100d, 100d, 1d, 6d, 60d);
    createAndSaveEfficiencyTable(
        EfficiencyType.TRU, "testing", efficiencyLoadLower, efficiencyLoadUpper, node2);
  }

  private ProjectReportDTO createProjectReportDTO(
      ChangeGroup changeGroup,
      int nbrOfTruNodes,
      int nbrOfAtuNodes,
      int nbrOfGenNodes,
      int nbrOfBusNodes) {
    ProjectReportDTO projectReportDTO = new ProjectReportDTO();
    List<ProjectReportChangeGroupDTO> projectReportChangeGroups = new ArrayList<>();
    ProjectReportChangeGroupDTO projectReportChangeGroup =
        new ProjectReportChangeGroupDTO(changeGroup.getId(), changeGroup.getName());
    List<ProjectAnalysis> projectAnalyses = new ArrayList<>();

    List<Aircraft> aircrafts =
        changeGroup.getAircraftChangeGroups().stream()
            .map(AircraftChangeGroup::getAircraft)
            .collect(Collectors.toList());

    for (Aircraft aircraft : aircrafts) {
      Analysis analysis =
          createAnalysis(nbrOfAtuNodes, nbrOfBusNodes, nbrOfGenNodes, nbrOfTruNodes);
      ProjectAnalysis projectAnalysis =
          new ProjectAnalysis(aircraft.getAircraftShipNo(), aircraft.getId(), analysis);
      projectAnalyses.add(projectAnalysis);
    }

    projectReportChangeGroup.setAnalyses(projectAnalyses);
    projectReportChangeGroups.add(projectReportChangeGroup);
    projectReportDTO.setProjectReportChangeGroups(projectReportChangeGroups);
    return projectReportDTO;
  }

  private Analysis createAnalysis(
      int nbrOfTruNodes, int nbrOfAtuNodes, int nbrOfGenNodes, int nbrOfBusNodes) {
    Analysis analysis = new Analysis();
    analysis.setDegradedStatus(AnalysisStatus.PASS);
    analysis.setNormalStatus(AnalysisStatus.PASS);

    AnalysisType analysisTypeNormal =
        createAnalysisType(nbrOfAtuNodes, nbrOfBusNodes, nbrOfGenNodes, nbrOfTruNodes);
    analysis.setNormalAnalysis(analysisTypeNormal);

    AnalysisType analysisTypeDegraded =
        createAnalysisType(nbrOfAtuNodes, nbrOfBusNodes, nbrOfGenNodes, nbrOfTruNodes);
    analysis.setDegradedAnalysis(analysisTypeDegraded);

    analysis.setThresholdLowerLimit(10d);
    analysis.setThresholdUpperLimit(100d);

    return analysis;
  }

  private AnalysisType createAnalysisType(
      int nbrOfTruNodes, int nbrOfAtuNodes, int nbrOfGenNodes, int nbrOfBusNodes) {
    AnalysisType analysisType = new AnalysisType();

    List<AnalysisNode> atuNodes = createAnalysisNodes(nbrOfAtuNodes);
    analysisType.setAtuNodes(atuNodes);

    List<AnalysisNode> busNodes = createAnalysisNodes(nbrOfBusNodes);
    analysisType.setBusNodes(busNodes);

    List<AnalysisNode> generatorNodes = createAnalysisNodes(nbrOfGenNodes);
    analysisType.setGeneratorNodes(generatorNodes);

    List<AnalysisNode> truNodes = createAnalysisNodes(nbrOfTruNodes);
    analysisType.setTruNodes(truNodes);

    return analysisType;
  }

  private List<AnalysisNode> createAnalysisNodes(int nbrOfNodes) {
    List<AnalysisNode> analysisNodes = new ArrayList<>();

    for (int i = 0; i < nbrOfNodes; i++) {
      Long nodeId = 10L + i;
      Double rating = 5d;
      String name = RandomStringUtils.random(4 + i, true, false);
      analysisNodes.add(createAnalysisNode(nodeId, rating, name));
    }

    return analysisNodes;
  }

  private AnalysisNode createAnalysisNode(Long nodeId, Double rating, String name) {
    AnalysisNode analysisNode = new AnalysisNode(nodeId, rating, name);

    analysisNode.setStatus(AnalysisStatus.PASS);
    analysisNode.setVoltageType(ElectricalPhase.AC3.toString());

    List<AnalysisLoad> analysisLoads = createAnalysisLoads();
    analysisNode.setAnalysisLoads(analysisLoads);

    return analysisNode;
  }

  private List<AnalysisLoad> createAnalysisLoads() {
    List<AnalysisLoad> analysisLoads = new ArrayList<>();

    for (int i = 0; i < 5; i++) {
      Double result = 5d + i;
      String flightPhase = "flightPhase";
      Double value = 20d + i;
      String electricalPhase = "electricalPhase";
      Units units = Units.AMPS;

      analysisLoads.add(createAnalysisLoad(result, flightPhase, value, electricalPhase, units));
    }

    return analysisLoads;
  }

  private AnalysisLoad createAnalysisLoad(
      Double result, String flightPhase, Double value, String electricalPhase, Units units) {
    return new AnalysisLoad(result, flightPhase, value, electricalPhase, units);
  }
}
