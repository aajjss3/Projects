package com.seatec.ela.app.validator.constraint;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.service.KeycloakService;
import com.seatec.ela.app.util.enumeration.KeycloakRole;
import com.seatec.ela.app.validator.annotation.ValidateEngineer;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import javax.validation.Payload;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

public class ValidateEngineerValidatorTest {

  private ValidateEngineerValidator subject;
  private KeycloakService mockKeycloakService;

  @Before
  public void setup() {
    mockKeycloakService = mock(KeycloakService.class);
    subject = new ValidateEngineerValidator(mockKeycloakService);
  }

  @Test
  public void isValid_should_return_true_when_engineer_is_null() {
    boolean result = subject.isValid(null, null);
    assertTrue(result);
  }

  @Test
  public void isValid_should_return_false_when_isUserValidAndInRoles_returns_false() {
    subject.initialize(getValidateEngineer("test", KeycloakRole.VIEWER));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
  }

  @Test
  public void isValid_should_return_true_when_isUserValidAndInRoles_returns_true() {
    when(mockKeycloakService.isUserValidAndInRoles("test", Arrays.asList("it_admin")))
        .thenReturn(true);
    subject.initialize(getValidateEngineer("test", KeycloakRole.IT_ADMIN));
    boolean result = subject.isValid("test", null);
    assertTrue(result);
    verify(mockKeycloakService, times(1)).isUserValidAndInRoles(any(String.class), any(List.class));
  }

  @Test
  public void isValid_should_return_test_against_all_roles_when_viewer_is_used() {
    List<String> allRoles =
        Arrays.asList("viewer", "author", "checker", "approver", "engineering_admin", "it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.VIEWER));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  @Test
  public void
      isValid_should_return_test_against_author_checker_approver_eng_admin_it_admin_roles_when_author_is_used() {
    List<String> allRoles =
        Arrays.asList("author", "checker", "approver", "engineering_admin", "it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.AUTHOR));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  @Test
  public void
      isValid_should_return_test_against_checker_approver_eng_admin_it_admin_roles_when_checker_is_used() {
    List<String> allRoles = Arrays.asList("checker", "approver", "engineering_admin", "it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.CHECKER));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  @Test
  public void
      isValid_should_return_test_against_approver_eng_admin_it_admin_roles_when_approver_is_used() {
    List<String> allRoles = Arrays.asList("approver", "engineering_admin", "it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.APPROVER));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  @Test
  public void
      isValid_should_return_test_against_engineering_admin_it_admin_roles_when_engineering_admin_is_used() {
    List<String> allRoles = Arrays.asList("engineering_admin", "it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.ENGINEERING_ADMIN));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  @Test
  public void isValid_should_return_test_against_it_admin_roles_when_it_admin_is_used() {
    List<String> allRoles = Arrays.asList("it_admin");
    subject.initialize(getValidateEngineer("test", KeycloakRole.IT_ADMIN));
    boolean result = subject.isValid("test", null);
    assertFalse(result);
    ArgumentCaptor<List<String>> argument = ArgumentCaptor.forClass(List.class);
    verify(mockKeycloakService).isUserValidAndInRoles(any(String.class), argument.capture());
    assertEquals(allRoles, argument.getValue());
  }

  private ValidateEngineer getValidateEngineer(String id, KeycloakRole role) {
    return new ValidateEngineer() {

      @Override
      public Class<? extends Annotation> annotationType() {
        return null;
      }

      @Override
      public KeycloakRole keycloakRole() {
        return role;
      }

      @Override
      public String message() {
        return null;
      }

      @Override
      public Class<?>[] groups() {
        return new Class[0];
      }

      @Override
      public Class<? extends Payload>[] payload() {
        return new Class[0];
      }
    };
  }
}
