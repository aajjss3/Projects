package com.seatec.ela.app.controller;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.project.ProjectCommentDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.dto.project.ProjectWrapperDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ProjectControllerIT extends AbstractControllerIntegrationTest {

  private static final String ENDPOINT_URL = BASE_URL + "/service/projects/";

  @Autowired private ProjectRepo projectRepo;

  @Autowired private NodeRepository nodeRepository;

  @Autowired private ComponentRepository componentRepository;

  @PersistenceContext private EntityManager entityManager;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  private HttpEntity<String> viewerEntity;
  private HttpEntity<String> emptyEntity;
  private HttpEntity<String> coAuthorEntity;
  private HttpEntity<String> invalidCoAuthorEntity;
  private HttpEntity<String> authorEntity;

  private String emptyUserId;
  private String authorUserId;
  private String coAuthorUserId;

  private Project projectSameAuthor;
  private Project projectDifferentAuthor;
  private Project projectSameChecker;
  private Project projectSameApprover;
  private Project projectSameCoauthor;
  private Project one;
  private Project two;
  private Project three;
  private Project four;

  @Before
  public void setup() throws Exception {
    authorEntity = createAuthorHttpEntity(null);
    emptyEntity = createHttpEntity(null);
    viewerEntity = createHttpEntity(Collections.singletonList(VIEWER_ID));
    coAuthorEntity = createHttpEntity(Collections.singletonList(COAUTHOR_ID));
    invalidCoAuthorEntity = createHttpEntity(Collections.singletonList(INVALID_COAUTHOR_ID));

    emptyUserId = getUserId(emptyEntity);
    authorUserId = getUserId(authorEntity);
    coAuthorUserId = getUserId(coAuthorEntity);
  }

  @Test
  public void shouldCreateProjectWhenCallingCreateProject() throws Exception {
    Project project = createProject(null);
    ResponseEntity<Project> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(project), Project.class);
    assertEquals(response.getStatusCode(), HttpStatus.OK);
    assertObjectFields(response.getBody(), project);
  }

  @Test
  public void shouldNotCreateProjectWithSameApprovalCheckerWhenCallingCreateProject()
      throws Exception {
    Project project = createProject(null);
    project.setApprovalEngineer("same");
    project.setCheckEngineer("same");
    ResponseEntity<Project> response =
        restTemplate.postForEntity(ENDPOINT_URL, createHttpEntity(project), Project.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
  }

  @Test
  public void shouldGetProjectWhenCallingGetProjectById() throws Exception {
    // insert database record to retrieve
    Project project = projectRepo.save(createProject("0"));
    ResponseEntity<Project> response =
        restTemplate.exchange(
            ENDPOINT_URL + project.getId(), HttpMethod.GET, createHttpEntity(null), Project.class);
    assertEquals(response.getStatusCode(), HttpStatus.OK);
    assertObjectFields(response.getBody(), project);
  }

  @Test
  public void shouldGetAllMyProjectsForAdminWhenCallingGetMyProjects() throws Exception {
    createTestData(emptyUserId);

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=number&sortAscending=true",
            HttpMethod.GET,
            emptyEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});

    assertEquals(response.getStatusCode(), HttpStatus.OK);
    List<AssignedProjectDTO> projects = response.getBody().getContents();

    assertEquals(5, projects.size());

    List<UUID> projectIds =
        projects.stream().map(AssignedProjectDTO::getId).collect(Collectors.toList());

    assertThat(
        projectIds,
        containsInAnyOrder(
            projectSameAuthor.getId(),
            projectSameChecker.getId(),
            projectSameApprover.getId(),
            projectSameCoauthor.getId(),
            projectDifferentAuthor.getId()));
    assertObjectFields(
        projects.stream()
            .filter(p -> p.getId().equals(projectSameAuthor.getId()))
            .findFirst()
            .get(),
        projectSameAuthor);
    assertObjectFields(
        projects.stream()
            .filter(p -> p.getId().equals(projectSameChecker.getId()))
            .findFirst()
            .get(),
        projectSameChecker);
    assertObjectFields(
        projects.stream()
            .filter(p -> p.getId().equals(projectSameApprover.getId()))
            .findFirst()
            .get(),
        projectSameApprover);
    assertObjectFields(
        projects.stream()
            .filter(p -> p.getId().equals(projectSameCoauthor.getId()))
            .findFirst()
            .get(),
        projectSameCoauthor);

    // assert checkEngineer
    AssignedProjectDTO project2 =
        projects.stream().filter(p -> "2".equals(p.getNumber())).findFirst().get();
    assertNotNull(project2.getCheckEngineer());

    // assert approvalEngineer
    AssignedProjectDTO project3 =
        projects.stream().filter(p -> "3".equals(p.getNumber())).findFirst().get();
    assertNotNull(project3.getApprovalEngineer());

    // assert Fleets and coauthors
    AssignedProjectDTO project4 =
        projects.stream().filter(p -> "4".equals(p.getNumber())).findFirst().get();
    assertEquals(project4.getFleets(), "fleetName 1 subFleet2, fleetName 1 subFleet3");
    assertEquals(project4.getCoauthors().size(), 1);

    // assert checkedStatus
    List<String> checkedStatus =
        projects.stream().map(p -> p.getCheckedStatus()).collect(Collectors.toList());
    assertThat(checkedStatus, contains("In Review", "Draft", "Draft", "Draft", "Draft"));

    // assert appovedStatus
    List<String> approvedStatus =
        projects.stream().map(p -> p.getApprovedStatus()).collect(Collectors.toList());
    assertThat(approvedStatus, contains(null, "Draft", "Draft", "Draft", "Draft"));

    // assert the sort order by 'number' field
    int inx = 2;
    for (AssignedProjectDTO dto : projects) {
      assertEquals(dto.getNumber(), Integer.toString(inx));
      inx++;
    }

    // test sorting by the checkedStatus
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response1 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=checked&sortAscending=true",
            HttpMethod.GET,
            emptyEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    List<String> fleets1 =
        response1.getBody().getContents().stream()
            .map(p -> p.getCheckedStatus())
            .collect(Collectors.toList());
    assertThat(fleets1, contains("Draft", "Draft", "Draft", "Draft", "In Review"));

    // test sorting by the 'fleets' field - ascending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response2 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=fleets&sortAscending=true",
            HttpMethod.GET,
            emptyEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    List<String> fleets2 =
        response2.getBody().getContents().stream()
            .map(p -> p.getFleets())
            .collect(Collectors.toList());
    assertThat(
        fleets2, contains(null, null, null, null, "fleetName 1 subFleet2, fleetName 1 subFleet3"));

    // test sorting by the 'fleets' field - descending
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response3 =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=fleets&sortAscending=false",
            HttpMethod.GET,
            emptyEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    List<String> fleets3 =
        response3.getBody().getContents().stream()
            .map(p -> p.getFleets())
            .collect(Collectors.toList());
    assertThat(
        fleets3, contains("fleetName 1 subFleet2, fleetName 1 subFleet3", null, null, null, null));
  }

  @Test
  public void shouldGetMyProjectsForAuthorWhenCallingGetMyProjects() throws Exception {
    createTestData(authorUserId);

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/myprojects?sortField=number&sortAscending=true",
            HttpMethod.GET,
            authorEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});

    assertEquals(response.getStatusCode(), HttpStatus.OK);
    List<AssignedProjectDTO> projects = response.getBody().getContents();

    assertEquals(4, projects.size());
    String author =
        response.getBody().getContents().stream()
            .filter(p -> !p.getAuthor().equalsIgnoreCase("0"))
            .map(p -> p.getAuthor())
            .collect(Collectors.toList())
            .get(0);

    String checkEngineer =
        response.getBody().getContents().stream()
            .filter(p -> p.getCheckEngineer() != null)
            .map(p -> p.getCheckEngineer())
            .collect(Collectors.toList())
            .get(0);

    String approvalEngineer =
        response.getBody().getContents().stream()
            .filter(p -> p.getApprovalEngineer() != null)
            .map(p -> p.getApprovalEngineer())
            .collect(Collectors.toList())
            .get(0);

    List<String> coauthors =
        response.getBody().getContents().stream()
            .filter(p -> p.getCoauthors().size() != 0)
            .map(p -> p.getCoauthors())
            .collect(Collectors.toList())
            .get(0);

    assertEquals(authorUserId, author);
    assertEquals(authorUserId, checkEngineer);
    assertEquals(authorUserId, approvalEngineer);
    assertEquals(authorUserId, coauthors.get(0));
  }

  @Test
  public void
      shouldGetAllPendingReviewProjectsForApproverOrCheckerWhenCallingGetPendingReviewProjects()
          throws Exception {
    // create and persist 5 projects to the database
    Project one = createProject("1");
    one.setCheckEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    Project sameCheckerProject = projectRepo.save(one); // pending request project for Checker

    Project two = createProject("2");
    two.setApprovalEngineer(emptyUserId);
    two.setSubmitted(Instant.now());
    two.setChecked(Instant.now());
    Project sameApproverProject = projectRepo.save(two); // pending request project for Approval

    Project three = createProject("3");
    three.setApprovalEngineer(emptyUserId);
    three.setSubmitted(Instant.now());
    Project nullCheckerAndApproverProject = projectRepo.save(three); // not pending request project

    Project four = createProject("4");
    four.setApproved(Instant.now());
    four.setChecked(Instant.now());
    four.setApprovalEngineer(emptyUserId);
    four.setCheckEngineer(emptyUserId);
    four.setSubmitted(Instant.now());
    Project approvedProject = projectRepo.save(four); // not pending request project

    Project five = createProject("5");
    five.setApprovalEngineer("0");
    five.setCheckEngineer("0");
    five.setSubmitted(Instant.now());
    Project notSubmittedProject = projectRepo.save(five); // not pending request project

    ResponseEntity<PaginationDTO<ProjectWrapperDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/pendingreview",
            HttpMethod.GET,
            emptyEntity,
            new ParameterizedTypeReference<PaginationDTO<ProjectWrapperDTO>>() {});
    assertEquals(response.getStatusCode(), HttpStatus.OK);
    List<ProjectDTO> approvers = response.getBody().getContents().get(0).getApprover();
    List<ProjectDTO> checkers = response.getBody().getContents().get(0).getChecker();
    assertEquals(approvers.size(), 1);
    assertEquals(checkers.size(), 1);
    assertEquals(approvers.get(0).getAuthor(), "2");
    assertObjectFields(approvers.get(0), sameApproverProject);
    assertEquals(checkers.get(0).getAuthor(), "1");
    assertObjectFields(checkers.get(0), sameCheckerProject);
  }

  @Test
  public void shouldSignoffOnAProjectByCheckerWhenCallingCheckProject() {
    Aircraft draftAircraft = createAircraft(23);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    Project one = createProject("1");
    one.setCheckEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    Project projectByChecker = projectRepo.save(one);
    ChangeGroup cg1 = createAndSaveChangeGroup("Airbus 1", one);
    createAndSaveAircraftChangeGroup(aircraft, cg1);

    Project two = createProject("2");
    two.setCheckEngineer("0");
    two.setSubmitted(Instant.now());
    Project projectNotByChecker = projectRepo.save(two);
    ChangeGroup cg2 = createAndSaveChangeGroup("Airbus 2", two);
    createAndSaveAircraftChangeGroup(aircraft, cg2);

    Project three = createProject("3");
    three.setCheckEngineer(emptyUserId);
    three.setSubmitted(Instant.now());
    Project projectNoEffectivity = projectRepo.save(three);
    createAndSaveChangeGroup("Airbus 3", three);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I check");

    assertNull(projectRepo.findById(projectByChecker.getId()).get().getChecked());
    ResponseEntity<Void> responseByChecker =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectByChecker.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert
    assertEquals(responseByChecker.getStatusCode(), HttpStatus.OK);
    assertNotNull(projectRepo.findById(projectByChecker.getId()).get().getChecked());

    ResponseEntity<ErrorWrapperDTO> responseNotByChecker =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotByChecker.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotByChecker.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Sign-off: The user is not authorized.",
        responseNotByChecker.getBody().getErrors().get(0).getMessage());

    ResponseEntity<ErrorWrapperDTO> responseNoEffectivity =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNoEffectivity.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNoEffectivity.getStatusCode(), HttpStatus.BAD_REQUEST);
    assertEquals(
        "Unable to transition to CHECKED: There are no aircrafts in the Effectivity ",
        responseNoEffectivity.getBody().getErrors().get(0).getMessage());
  }

  @SuppressWarnings("unchecked")
  @Test
  public void shouldRejectProjectByCheckerOrApproverWhenCallingRejectProject() throws Exception {
    ProjectCommentDTO comment = new ProjectCommentDTO();
    comment.setComment("four score and seven... ");
    HttpEntity<String> entity = createHttpEntity(comment);
    String userId = getUserId(entity);

    // project that can be rejected by the checker
    Project one = createProject("1");
    one.setCheckEngineer(userId);
    one.setApprovalEngineer("someoneelse");
    one.setChecked(null);
    one.setSubmitted(Instant.now());
    Project rejectProjectByChecker = projectRepo.save(one);

    // project that can be rejected by an approver
    Project two = createProject("2");
    two.setApprovalEngineer(userId);
    two.setCheckEngineer("someoneelse");
    two.setChecked(Instant.now());
    two.setSubmitted(Instant.now());
    Project rejectProjectByApprover = projectRepo.save(two);

    // project that cannot be rejected by checker
    Project four = createProject("4");
    four.setApprovalEngineer("someoneelse");
    four.setCheckEngineer("0");
    four.setChecked(null);
    four.setSubmitted(Instant.now());
    Project failedRejectByCheckerProject = projectRepo.save(four);

    // project that cannot be rejected by approver
    Project five = createProject("5");
    five.setApprovalEngineer("0");
    five.setCheckEngineer("someoneelse");
    five.setChecked(null);
    five.setSubmitted(null);
    Project failedRejectByApproverProject = projectRepo.save(five);

    // call endpoint - reject by checker
    Project beforeChecker = projectRepo.findById(rejectProjectByChecker.getId()).get();
    assertNotNull(beforeChecker.getSubmitted());

    ResponseEntity<Void> responseByChecker =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + rejectProjectByChecker.getId() + "/check/reject",
            HttpMethod.PATCH,
            entity,
            Void.class);
    assertEquals(responseByChecker.getStatusCode(), HttpStatus.OK);
    Project afterChecker = projectRepo.findById(rejectProjectByChecker.getId()).get();
    assertNotNull(afterChecker.getRejected());
    assertNull(afterChecker.getChecked());
    assertNull(afterChecker.getApproved());

    Query queryChecker =
        entityManager.createNativeQuery(
            "select ca.display_name from project_comment ca where ca.project_id =:id");
    queryChecker.setParameter("id", afterChecker.getId());
    List<String> displayName = (List<String>) queryChecker.getResultList();
    assertEquals(displayName.size(), 1);
    assertNotNull(displayName.get(0));
    // end endpoint call

    // call endpoint - reject by approver
    Project beforeApprover = projectRepo.findById(rejectProjectByApprover.getId()).get();
    assertNotNull(beforeApprover.getSubmitted());

    ResponseEntity<Void> responseByApprover =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + rejectProjectByApprover.getId() + "/approve/reject",
            HttpMethod.PATCH,
            entity,
            Void.class);
    assertEquals(responseByApprover.getStatusCode(), HttpStatus.OK);
    Project afterApprover = projectRepo.findById(rejectProjectByApprover.getId()).get();
    assertNotNull(afterApprover.getRejected());
    assertNull(afterApprover.getChecked());
    assertNull(afterApprover.getApproved());

    Query queryApprover =
        entityManager.createNativeQuery(
            "select ca.display_name from project_comment ca where ca.project_id =:id");
    queryApprover.setParameter("id", afterApprover.getId());
    displayName = (List<String>) queryApprover.getResultList();
    assertEquals(displayName.size(), 1);
    assertNotNull(displayName.get(0));
    // end endpoint call

    // call endpoint - checker not authorized to reject
    ResponseEntity<Void> responseNotRejectedChecker =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + failedRejectByCheckerProject.getId() + "/check/reject",
            HttpMethod.PATCH,
            entity,
            Void.class);
    assertEquals(responseNotRejectedChecker.getStatusCode(), HttpStatus.FORBIDDEN);
    // end endpoint call

    // call endpoint - approver not authorized to reject
    ResponseEntity<Void> responseNotRejectedApprover =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + failedRejectByApproverProject.getId() + "/approve/reject",
            HttpMethod.PATCH,
            entity,
            Void.class);
    assertEquals(responseNotRejectedApprover.getStatusCode(), HttpStatus.FORBIDDEN);
    // end endpoint call

  }

  @Test
  public void shouldApproveAProjectByApproverWhenCallingApproveProject() throws Exception {
    String userId = getUserId(emptyEntity);

    Aircraft draftAircraft = createAircraft(23);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    Project one = createProject("1");
    one.setApprovalEngineer(userId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project projectByApprover = projectRepo.save(one);
    ChangeGroup cg1 = createAndSaveChangeGroup("Airbus 1", one);
    createAndSaveAircraftChangeGroup(aircraft, cg1);

    Project two = createProject("2");
    two.setApprovalEngineer("0");
    two.setSubmitted(Instant.now());
    two.setChecked(Instant.now());
    Project projectNotByApprover = projectRepo.save(two);
    ChangeGroup cg2 = createAndSaveChangeGroup("Airbus 1", two);
    createAndSaveAircraftChangeGroup(aircraft, cg2);

    Project three = createProject("3");
    three.setApprovalEngineer(userId);
    three.setSubmitted(Instant.now());
    three.setChecked(null);
    Project projectNotChecked = projectRepo.save(three);
    ChangeGroup cg3 = createAndSaveChangeGroup("Airbus 1", three);
    createAndSaveAircraftChangeGroup(aircraft, cg3);

    Project four = createProject("4");
    four.setApprovalEngineer(userId);
    four.setSubmitted(Instant.now());
    four.setChecked(Instant.now());
    four.setRejected(Instant.now());
    Project projectRejected = projectRepo.save(four);
    ChangeGroup cg4 = createAndSaveChangeGroup("Airbus 1", four);
    createAndSaveAircraftChangeGroup(aircraft, cg4);

    Project five = createProject("5");
    five.setApprovalEngineer(userId);
    five.setSubmitted(Instant.now());
    five.setChecked(Instant.now());
    five.setRejected(null);
    Project projectNoEffectivity = projectRepo.save(five);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // call endpoint approve successful
    assertNull(projectRepo.findById(projectByApprover.getId()).get().getApproved());
    ResponseEntity<Void> responseByApprover =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectByApprover.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert
    assertEquals(responseByApprover.getStatusCode(), HttpStatus.OK);
    assertNotNull(projectRepo.findById(projectByApprover.getId()).get().getApproved());
    // end endpoint call

    // call endpoint unable to approve since its not checked
    ResponseEntity<Void> responseNotChecked =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotByApprover.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert
    assertEquals(responseNotChecked.getStatusCode(), HttpStatus.FORBIDDEN);
    // end endpoint call

    // call endpoint unable to approve since its not approved
    ResponseEntity<ErrorWrapperDTO> responseNotApprover =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotChecked.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotApprover.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Approve: The project has not been submitted and checked.",
        responseNotApprover.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to approve since its rejected
    ResponseEntity<ErrorWrapperDTO> responseRejected =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectRejected.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseRejected.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Approve: The project has been rejected.",
        responseRejected.getBody().getErrors().get(0).getMessage());

    // call endpoint unable to approve since no AircraftControlGroup
    ResponseEntity<ErrorWrapperDTO> responseEffectivity =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNoEffectivity.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseEffectivity.getStatusCode(), HttpStatus.BAD_REQUEST);
    assertEquals(
        "Unable to transition to APPROVED: There are no aircrafts in the Effectivity ",
        responseEffectivity.getBody().getErrors().get(0).getMessage());
    // end endpoint call

  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_ADD_Root_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // node
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);

    // assert (before act)
    assertEquals("One node should exist before saving project approval.", 1, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change
    NodeChange nc = new NodeChange();
    nc.setName("GEN 2");
    nc.setVoltageType(ElectricalPhase.AC);
    nc.setElectricalPhase(ElectricalPhase.ACA);
    nc.setNodeType(NodeType.GENERATOR);
    nc.setBusRating(100d);
    nc.setVoltage(1.0);

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.ADD);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName(null);
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());

    assertEquals("Two nodes should exist after saving project.", 2, nodesInEla.size());
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_ADD_Child_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // node
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);

    // assert (before act)
    assertEquals("One node should exist before saving project approval.", 1, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change
    NodeChange nc = new NodeChange();
    nc.setName("BUS 1");
    nc.setVoltage(1.0);
    nc.setVoltageType(ElectricalPhase.AC);
    nc.setElectricalPhase(ElectricalPhase.ACA);
    nc.setNodeType(NodeType.BUS);
    nc.setBusRating(100d);

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.ADD);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName("GEN 1");
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_DELETE_Root_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    Node parentNode2 =
        createAndSaveNode(
            false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela);
    Node childNode1 =
        createAndSaveNode(
            false,
            "BUS 1",
            5d,
            10d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            21,
            parentNode1,
            null);

    // assert (before act)
    assertEquals("Two nodes should exist before saving project.", 2, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change
    NodeChange nc = new NodeChange();
    nc.setName("GEN 2");
    nc.setVoltage(1.0);
    nc.setVoltageType(ElectricalPhase.AC);
    nc.setElectricalPhase(ElectricalPhase.ACA);
    nc.setNodeType(NodeType.BUS);

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.DELETE);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName("GEN 2");
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_DELETE_Child_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    Node parentNode2 =
        createAndSaveNode(
            false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela);

    Node childNode1 =
        createAndSaveNode(
            false,
            "BUS 1",
            5d,
            10d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            21,
            parentNode1,
            null);

    // assert (before act)
    assertEquals("Two nodes should exist before saving project.", 2, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change
    NodeChange nc = new NodeChange();
    nc.setName("BUS 1");
    nc.setVoltage(1.0);
    nc.setVoltageType(ElectricalPhase.AC);
    nc.setElectricalPhase(ElectricalPhase.ACA);
    nc.setNodeType(NodeType.BUS);

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.DELETE);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName("BUS 1");
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    assertEquals("Two nodes should exist after saving project.", 2, nodesInEla.size());

    nodesInEla.stream()
        .filter(n -> n.getParentNode() == null)
        .forEach(
            savedNode ->
                assertNotEquals(
                    "BUS 1 should no longer be present.", "BUS 1", savedNode.getName()));
  }

  /**
   * Endpoint: /approve Description: Project Changes (child Node DELETE and parent Node EDIT)
   * Expected Result: Save successfully
   */
  @Test
  public void shouldApproveProjectAndRebaseElasWhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);

    createAndSaveNode(
        false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 21, null, ela);

    Node childBusNode =
        createAndSaveNode(
            false,
            "BUS 1",
            5d,
            10d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            21,
            parentNode1,
            null);

    // assert (before act)
    assertEquals("Two nodes should exist before saving project.", 2, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // change #1 (GEN 1 > BUS 1 - child) DELETE
    NodeChange nc1 =
        createNodeChange(
            childBusNode.getBusRating(),
            childBusNode.getName(),
            childBusNode.getVoltage(),
            childBusNode.getVoltageType(),
            childBusNode.getNodeType(),
            childBusNode.getNominalPower(),
            childBusNode.isRequiresApproval(),
            childBusNode.isSheddable(),
            childBusNode.isNormalTr(),
            childBusNode.getElectricalPhase());

    createAndSaveChange("BUS 1", null, ActionType.DELETE, emptyUserId, nc1, null, cg);

    // change #2 (GEN 1 - parent) EDIT
    NodeChange nc2 =
        createNodeChange(
            parentNode1.getBusRating(),
            parentNode1.getName(),
            10d, // was 5d
            parentNode1.getVoltageType(),
            parentNode1.getNodeType(),
            parentNode1.getNominalPower(),
            parentNode1.isRequiresApproval(),
            parentNode1.isSheddable(),
            parentNode1.isNormalTr(),
            parentNode1.getElectricalPhase());

    createAndSaveChange("GEN 1", null, ActionType.EDIT, emptyUserId, nc2, null, cg);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    assertEquals("Two nodes should exist after saving project.", 2, nodesInEla.size());

    nodesInEla.stream()
        .filter(n -> n.getParentNode() == null)
        .forEach(
            savedNode ->
                assertNotEquals(
                    "BUS 1 should no longer be present.", "BUS 1", savedNode.getName()));

    Optional<Node> gen1Node =
        nodesInEla.stream().filter(n -> n.getName().equalsIgnoreCase("GEN 1")).findFirst();
    assertTrue("GEN 1 should be present.", gen1Node.isPresent());
    gen1Node.ifPresent(
        node ->
            assertEquals(
                "GEN 1 voltage should be 10.", Optional.of(10d), Optional.of(node.getVoltage())));
  }

  /**
   * Endpoint: /approve Description: Project Changes (root level Node EDIT and child Component
   * DELETE) Expected Result: Save successfully
   */
  @Test
  public void shouldApproveProjectAndRebaseElaWhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1, "Airbus");

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    draftAircraft.setFleet(fleet);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false,
            "GEN 1",
            115d,
            90000d,
            NodeType.GENERATOR,
            300d,
            ElectricalPhase.AC3,
            1,
            null,
            ela);

    Node childNode1ToParentNode1 =
        createAndSaveNode(
            true,
            "1IWXP",
            115d,
            null,
            NodeType.BUS,
            300d,
            ElectricalPhase.AC3,
            1,
            parentNode1,
            null);

    // components
    createAndSaveComponentWithLoads(
        childNode1ToParentNode1, "GND/PWR/PROT", ElectricalPhase.AC3, 0d, 1, false);
    createAndSaveComponentWithLoads(
        childNode1ToParentNode1,
        "L WING TK/PUMP 1/STBY SPLY INTERMITTENT",
        ElectricalPhase.AC3,
        2931.9d,
        2,
        false);
    createAndSaveComponentWithLoads(
        childNode1ToParentNode1,
        "R WING TK/PUMP 1/STBY SPLY INTERMITTENT",
        ElectricalPhase.AC3,
        2931.9d,
        3,
        false);
    createAndSaveComponentWithLoads(
        childNode1ToParentNode1, "ELEC/STAT INV/BUS 901XP/SPLY", ElectricalPhase.ACA, 0d, 4, false);
    createAndSaveComponentWithLoads(
        childNode1ToParentNode1, "AC ESS/BUS NORM/CNTOR/CTL", ElectricalPhase.ACC, 0d, 5, false);

    Node childNode2ToParentNode1 =
        createAndSaveNode(
            true, "1XP", 115d, null, NodeType.BUS, 300d, ElectricalPhase.AC3, 2, parentNode1, null);

    Node childChildNode1ToChildNode2 =
        createAndSaveNode(
            false,
            "101XP",
            115d,
            null,
            NodeType.BUS,
            50d,
            ElectricalPhase.AC3,
            1,
            childNode2ToParentNode1,
            null);
    createAndSaveComponentWithLoads(
        childChildNode1ToChildNode2,
        "AIR COND/RECIRC FAN/L/SPLY",
        ElectricalPhase.AC3,
        2931.3d,
        1,
        false);

    createAndSaveNode(
        false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d, ElectricalPhase.AC3, 2, null, ela);

    // assert (before act)
    assertEquals("Two nodes should exist before saving project.", 2, ela.getNodes().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    createAndSaveAircraftChangeGroup(aircraft, cg);

    // change #1 (GEN 1 - parent) EDIT
    NodeChange nc2 =
        createNodeChange(
            parentNode1.getBusRating(),
            parentNode1.getName(),
            10d, // was 5d
            parentNode1.getVoltageType(),
            parentNode1.getNodeType(),
            parentNode1.getNominalPower(),
            parentNode1.isRequiresApproval(),
            parentNode1.isSheddable(),
            parentNode1.isNormalTr(),
            parentNode1.getElectricalPhase());

    createAndSaveChange("GEN 1", null, ActionType.EDIT, emptyUserId, nc2, null, cg);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    assertEquals("Five nodes should exist after saving project.", 5, nodesInEla.size());

    nodesInEla.stream()
        .filter(n -> n.getParentNode() == null)
        .forEach(
            savedNode ->
                assertNotEquals(
                    "1IWXP should no longer be present.", "1IWXP", savedNode.getName()));

    Optional<Node> gen1Node =
        nodesInEla.stream().filter(n -> n.getName().equalsIgnoreCase("GEN 1")).findFirst();
    assertTrue("GEN 1 should be present.", gen1Node.isPresent());
    gen1Node.ifPresent(
        node ->
            assertEquals(
                "GEN 1 voltage should be 10.", Optional.of(10d), Optional.of(node.getVoltage())));
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_EDIT_Root_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    // Node parentNode2 = createAndSaveNode(false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d,
    // ElectricalPhase.AC3, 21, null, ela);

    Node childNode1 =
        createAndSaveNode(
            false,
            "BUS 1",
            5d,
            10d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            21,
            parentNode1,
            null);

    // assert (before act)
    assertEquals("One node should exist before saving project.", 1, ela.getNodes().size());
    assertEquals("Voltage should be 5d.", 5d, ela.getNodes().get(0).getVoltage(), 0.0);

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change (edit voltage)
    NodeChange nc = new NodeChange();
    nc.setName(parentNode1.getName());
    nc.setNodeType(parentNode1.getNodeType());
    nc.setVoltage(parentNode1.getVoltage() + 5d);
    nc.setVoltageType(parentNode1.getVoltageType());
    nc.setElectricalPhase(parentNode1.getElectricalPhase());

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.EDIT);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName("GEN 1");
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());
    assertEquals("One node should exist after saving project.", 1, rootNodes.size());
    assertTrue("Voltage should be 10d after saving.", rootNodes.get(0).getVoltage() == 10d);
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_EDIT_Child_Node_NodeChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(1);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // nodes
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    // Node parentNode2 = createAndSaveNode(false, "GEN 2", 5d, 10d, NodeType.GENERATOR, 120d,
    // ElectricalPhase.AC3, 21, null, ela);

    Node childNode1 =
        createAndSaveNode(
            false,
            "BUS 1",
            5d,
            10d,
            NodeType.BUS,
            120d,
            ElectricalPhase.AC3,
            21,
            parentNode1,
            null);

    // assert (before act)
    assertEquals("One node should exist before saving project.", 1, ela.getNodes().size());
    assertEquals(
        "BUS 1 child node Voltage should be 5d.",
        5d,
        ela.getNodes().get(0).getSubNodes().get(0).getVoltage(),
        0.0);

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // node change (edit voltage)
    NodeChange nc = new NodeChange();
    nc.setName(childNode1.getName());
    nc.setElectricalPhase(childNode1.getElectricalPhase());
    nc.setVoltage(childNode1.getVoltage() + 5d);
    nc.setVoltageType(childNode1.getVoltageType());
    nc.setNodeType(childNode1.getNodeType());

    // change
    Change draftNodeChangeChange = createChange();
    draftNodeChangeChange.setAction(ActionType.EDIT);
    draftNodeChangeChange.setChangeGroup(cg);
    draftNodeChangeChange.setNodeName("GEN 1");
    draftNodeChangeChange.setChanger(emptyUserId);
    draftNodeChangeChange.setNodeChange(nc);
    saveChange(draftNodeChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());

    Node bus1 =
        nodesInEla.stream().filter(n -> n.getName().equals("BUS 1")).findFirst().orElse(null);
    assertNotNull(bus1);
    assertEquals("Child node Voltage should be 10d after saving.", 10d, bus1.getVoltage(), 0.0);
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_ADD_Component_ComponentChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = fleetRepo.save(createFleet(23));

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    draftAircraft.setFleet(fleet);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // node
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    Node childNode1 =
        createAndSaveNode(
            false, "BUS 1", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.AC, 11, parentNode1, null);

    // component(s)
    addComponentsAndLoadsToNode(childNode1);

    // assert (before act)
    assertEquals("One node should exist before saving project.", 1, ela.getNodes().size());

    // GEN 1 > BUS 1 > Components
    assertEquals(
        "Two Components should exist before saving project.", 2, childNode1.getComponents().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // load change(s)
    LoadChange loadChange = createLoadChange("roll");

    // component change
    ComponentChange cc = new ComponentChange();
    cc.setName("101XP");
    cc.setElectIdent("101XP");
    cc.setElectricalPhase(ElectricalPhase.AC);
    cc.setNominalPower(200d);
    cc.setSheddable(Boolean.FALSE);
    cc.setIntermittent(Boolean.FALSE);
    cc.setIntermittent(Boolean.FALSE);

    cc.addLoadChange(loadChange);

    // change
    Change draftComponentChangeChange = createChange();
    draftComponentChangeChange.setAction(ActionType.ADD);
    draftComponentChangeChange.setChangeGroup(cg);
    draftComponentChangeChange.setNodeName("BUS 1");
    draftComponentChangeChange.setComponentElectIdent("101XP");
    draftComponentChangeChange.setChanger(emptyUserId);
    draftComponentChangeChange.setComponentChange(cc);
    Change componentChangeChange = saveChange(draftComponentChangeChange);

    cg.addChange(componentChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());

    // GEN 1 > BUS 1 > Components
    List<Component> components = componentRepository.getComponentsInEla(ela.getId());

    assertEquals("Three Components should exist after saving project.", 3, components.size());

    Optional<Component> isFound =
        components.stream()
            .filter(component -> component.getElectIdent().equalsIgnoreCase("101xp"))
            .findAny();
    assertTrue("101XP Component should exist.", isFound.isPresent());
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_DELETE_Component_ComponentChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = fleetRepo.save(createFleet(23));

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    draftAircraft.setFleet(fleet);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // node
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    Node childNode1 =
        createAndSaveNode(
            false, "BUS 1", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.AC, 11, parentNode1, null);

    // component(s)
    addComponentsAndLoadsToNode(childNode1);

    // assert (before act)
    assertEquals("One node should exist before saving project approval.", 1, ela.getNodes().size());

    // GEN 1 > BUS 1 > Components
    assertEquals(
        "Two Components should exist before saving project.", 2, childNode1.getComponents().size());

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // load change(s)
    LoadChange loadChange = createLoadChange("roll");
    // component change
    ComponentChange cc = new ComponentChange();
    cc.setName("component4");
    cc.setElectIdent("component4");
    cc.setElectricalPhase(ElectricalPhase.AC);
    cc.setIntermittent(Boolean.FALSE);
    cc.setNominalPower(300.0);

    cc.addLoadChange(loadChange);

    // change
    Change draftComponentChangeChange = createChange();
    draftComponentChangeChange.setAction(ActionType.DELETE);
    draftComponentChangeChange.setChangeGroup(cg);
    draftComponentChangeChange.setNodeName("BUS 1");
    draftComponentChangeChange.setComponentElectIdent("component4");
    draftComponentChangeChange.setChanger(emptyUserId);
    draftComponentChangeChange.setComponentChange(cc);
    Change componentChangeChange = saveChange(draftComponentChangeChange);

    cg.addChange(componentChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());

    List<Component> components = componentRepository.getComponentsInEla(ela.getId());

    // GEN 1 > BUS 1 > Components
    assertEquals("One Component should exist after saving project.", 1, components.size());

    Optional<Component> isFound =
        components.stream()
            .filter(component -> component.getElectIdent().equalsIgnoreCase("component4"))
            .findAny();
    assertFalse(isFound.isPresent());
  }

  @Test
  public void
      shouldApproveProjectAndRebaseElas_EDIT_Component_ComponentChange_WhenCallingApproveProject() {
    // fleet
    Fleet fleet = createAndSaveFleet(23);

    // aircraft
    Aircraft aircraft = createAndSaveAircraft(23, fleet);

    // ela
    Ela ela = createAndSaveEla("Ela Boss", aircraft);

    // node
    Node parentNode1 =
        createAndSaveNode(
            false, "GEN 1", 5d, 10d, NodeType.GENERATOR, 300d, ElectricalPhase.AC, 11, null, ela);
    Node childNode1 =
        createAndSaveNode(
            false, "BUS 1", 5d, 10d, NodeType.BUS, 300d, ElectricalPhase.AC, 11, parentNode1, null);

    // component(s)
    addComponentsAndLoadsToNode(childNode1);

    // assert (before act)
    assertEquals("One node should exist before saving project approval.", 1, ela.getNodes().size());

    // GEN 1 > BUS 1 > Components
    assertEquals(
        "Two Components should exist before saving project.", 2, childNode1.getComponents().size());
    assertEquals(
        "Component NominalPower should be 20d.",
        20d,
        childNode1.getComponents().get(0).getNominalPower(),
        0.0);

    // project
    Project one = createProject("1");
    one.setApprovalEngineer(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    Project project = projectRepo.save(one);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Airbus 1", project);

    // aircraft change group
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, cg);

    // load change(s)
    LoadChange loadChange = createLoadChange("roll");

    // component change
    ComponentChange cc = new ComponentChange();
    cc.setName("component4");
    cc.setElectIdent("component4");
    cc.setIntermittent(Boolean.FALSE);
    cc.setNominalPower(300d);
    cc.setElectricalPhase(ElectricalPhase.AC);

    cc.addLoadChange(loadChange);

    // change
    Change draftComponentChangeChange = createChange();
    draftComponentChangeChange.setAction(ActionType.EDIT);
    draftComponentChangeChange.setChangeGroup(cg);
    draftComponentChangeChange.setNodeName("BUS 1");
    draftComponentChangeChange.setComponentElectIdent("component4");
    draftComponentChangeChange.setChanger(emptyUserId);
    draftComponentChangeChange.setComponentChange(cc);
    Change componentChangeChange = saveChange(draftComponentChangeChange);

    cg.addChange(componentChangeChange);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I approve");

    // assert (before act)
    assertNull(projectRepo.findById(project.getId()).get().getApproved());

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert (after act)
    assertEquals(HttpStatus.OK, response.getStatusCode());

    // assert project level
    Project updatedProject = projectRepo.findById(project.getId()).get();
    assertNotNull(updatedProject.getApproved());

    // assert Ela level
    List<Node> nodesInEla = nodeRepository.getNodesInEla(ela.getId());
    List<Node> rootNodes =
        nodesInEla.stream().filter(n -> n.getParentNode() == null).collect(Collectors.toList());

    assertEquals("One node should exist after saving project.", 1, rootNodes.size());

    // GEN 1 > BUS 1 > Components
    List<Component> components = componentRepository.getComponentsInEla(ela.getId());

    assertEquals("Two Components should exist after saving project.", 2, components.size());

    Optional<Component> isFound =
        components.stream()
            .filter(component -> component.getElectIdent().equalsIgnoreCase("component4"))
            .findFirst();
    assertTrue("component4 Component should exist.", isFound.isPresent());
    assertEquals(
        "Component NominalPower should be 300d after saving project.",
        300d,
        isFound.get().getNominalPower(),
        0.0);
  }

  @Test
  public void shouldCheckAProjectByCheckerWhenCallingApproveProject() {
    Aircraft draftAircraft = createAircraft(23);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    Project one = createProject("1");
    one.setSubmitted(Instant.now());
    one.setCheckEngineer(emptyUserId);
    Project projectByChecker = projectRepo.save(one);

    ChangeGroup changeGroup = createAndSaveChangeGroup("cg1", one);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    Project two = createProject("2");
    two.setSubmitted(null);
    two.setCheckEngineer(emptyUserId);
    Project projectNotSubmitted = projectRepo.save(two);

    Project three = createProject("3");
    three.setSubmitted(Instant.now());
    three.setRejected(Instant.now());
    three.setCheckEngineer(emptyUserId);
    Project projectRejected = projectRepo.save(three);

    Project four = createProject("4");
    four.setSubmitted(Instant.now());
    four.setCheckEngineer("0");
    Project projectNotValidCheckId = projectRepo.save(four);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I check");

    // call endpoint check - successful
    assertNull(projectRepo.findById(projectByChecker.getId()).get().getApproved());
    ResponseEntity<Void> responseByChecker =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectByChecker.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert
    assertEquals(responseByChecker.getStatusCode(), HttpStatus.OK);
    assertNotNull(projectRepo.findById(projectByChecker.getId()).get().getChecked());
    // end endpoint call

    // call endpoint unable to check since not submitted
    ResponseEntity<ErrorWrapperDTO> responseNotSubmitted =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotSubmitted.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotSubmitted.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Sign-off: The project has not been submitted.",
        responseNotSubmitted.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to check since rejected
    ResponseEntity<ErrorWrapperDTO> responseRejected =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectRejected.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseRejected.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Sign-off: The project has been rejected.",
        responseRejected.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to check since not valid check id
    ResponseEntity<ErrorWrapperDTO> responseNotValidCheckId =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotValidCheckId.getId() + "/check",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotValidCheckId.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Sign-off: The user is not authorized.",
        responseNotValidCheckId.getBody().getErrors().get(0).getMessage());
    // end endpoint call
  }

  @Test
  public void shouldSubmitAProjectByAuthorOrCoauthorWhenCallingSubmitProject() {
    Aircraft draftAircraft = createAircraft(23);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    Project one = createProject("1");
    one.setAuthor(emptyUserId);
    one.setSubmitted(null);
    one.setChecked(null);
    one.setApprovalEngineer("0");
    one.setCheckEngineer("0");
    Project projectByAuthor = projectRepo.save(one);
    ChangeGroup changeGroup = createAndSaveChangeGroup("cg1", one);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);
    Change change = createAndSaveNodeChange(changeGroup);
    change.setChangeGroup(changeGroup);
    changeGroup.setProject(projectByAuthor);

    Project two = createProject("2");
    two.setAuthor("0");
    two.setCoauthors(Collections.singletonList(emptyUserId));
    two.setSubmitted(null);
    two.setChecked(null);
    two.setApprovalEngineer("0");
    two.setCheckEngineer("0");
    Project projectByCoauthor = projectRepo.save(two);
    ChangeGroup changeGroup2 = createAndSaveChangeGroup("cg2", two);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup2);
    Change change2 = createAndSaveNodeChange(changeGroup2);
    change2.setChangeGroup(changeGroup2);
    changeGroup2.setProject(projectByCoauthor);

    Project three = createProject("3");
    one.setAuthor(emptyUserId);
    one.setSubmitted(Instant.now());
    one.setChecked(Instant.now());
    one.setApprovalEngineer("0");
    one.setCheckEngineer("0");
    Project projectNotChange = projectRepo.save(three);
    ChangeGroup changeGroup3 = createAndSaveChangeGroup("cg3", three);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup3);

    Project four = createProject("4");
    four.setAuthor("0");
    four.setCoauthors(Collections.singletonList("0"));
    four.setSubmitted(Instant.now());
    four.setChecked(Instant.now());
    four.setApprovalEngineer("0");
    four.setCheckEngineer("0");
    Project projectNotAuthorized = projectRepo.save(four);
    ChangeGroup changeGroup4 = createAndSaveChangeGroup("cg4", four);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup4);
    Change change3 = createAndSaveNodeChange(changeGroup4);
    change3.setChangeGroup(changeGroup4);
    changeGroup3.setProject(projectNotAuthorized);

    Project five = createProject("5");
    five.setAuthor(emptyUserId);
    five.setSubmitted(Instant.now());
    five.setChecked(Instant.now());
    five.setCheckEngineer("0");
    five.setApprovalEngineer("bad");
    Project projectMissingApprover = projectRepo.save(five);
    ChangeGroup changeGroup5 = createAndSaveChangeGroup("cg5", five);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup5);
    Change change4 = createAndSaveNodeChange(changeGroup5);
    change4.setChangeGroup(changeGroup5);
    changeGroup4.setProject(projectMissingApprover);

    Project six = createProject("6");
    six.setAuthor("0");
    six.setSubmitted(Instant.now());
    six.setChecked(Instant.now());
    six.setApprovalEngineer(emptyUserId);
    six.setCheckEngineer("0");
    Project projectMissingEffectivity = projectRepo.save(six);
    ChangeGroup changeGroup6 = createAndSaveChangeGroup("cg6", six);
    Change change5 = createAndSaveNodeChange(changeGroup6);
    change5.setChangeGroup(changeGroup6);

    ProjectCommentDTO projectCommentDTO = new ProjectCommentDTO();
    projectCommentDTO.setComment("I submit");

    // call endpoint submit by author
    assertNull(projectRepo.findById(projectByAuthor.getId()).get().getSubmitted());
    ResponseEntity<Void> responseByAuthor =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectByAuthor.getId() + "/submit",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            Void.class);

    // assert
    assertEquals(responseByAuthor.getStatusCode(), HttpStatus.OK);
    assertNotNull(projectRepo.findById(projectByAuthor.getId()).get().getSubmitted());
    assertNull(projectRepo.findById(projectByAuthor.getId()).get().getRejected());
    // end endpoint call

    // call endpoint submit by coauthor
    assertNull(projectRepo.findById(projectByCoauthor.getId()).get().getSubmitted());
    ResponseEntity<String> responseByCoauthor =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectByCoauthor.getId() + "/submit",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            String.class);

    // assert
    assertEquals(responseByCoauthor.getStatusCode(), HttpStatus.OK);
    assertNotNull(projectRepo.findById(projectByCoauthor.getId()).get().getSubmitted());
    assertNull(projectRepo.findById(projectByCoauthor.getId()).get().getRejected());
    // end endpoint call

    // call endpoint unable to submit - no change
    ResponseEntity<ErrorWrapperDTO> responseNotChange =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotChange.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotChange.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Approve: The project has not been submitted and checked.",
        responseNotChange.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to submit - not authorized
    ResponseEntity<ErrorWrapperDTO> responseNotAuthorized =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectNotAuthorized.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseNotAuthorized.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Approve: The user is not authorized.",
        responseNotAuthorized.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to submit - missing approver
    ResponseEntity<ErrorWrapperDTO> responseMissingApprover =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectMissingApprover.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseMissingApprover.getStatusCode(), HttpStatus.FORBIDDEN);
    assertEquals(
        "Unable to Approve: The user is not authorized.",
        responseMissingApprover.getBody().getErrors().get(0).getMessage());
    // end endpoint call

    // call endpoint unable to submit - missing effectivity
    ResponseEntity<ErrorWrapperDTO> responseMissingEffectivity =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + projectMissingEffectivity.getId() + "/approve",
            HttpMethod.PATCH,
            createHttpEntity(projectCommentDTO),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(responseMissingEffectivity.getStatusCode(), HttpStatus.BAD_REQUEST);
    assertEquals(
        "Unable to transition to APPROVED: There are no aircrafts in the Effectivity ",
        responseMissingEffectivity.getBody().getErrors().get(0).getMessage());
    // end endpoint call
  }

  @SuppressWarnings("unchecked")
  @Test
  public void shouldSetCoauthorsByAuthorWhenCallingSetProjectCoauthors() {
    Project project = projectRepo.save(createProject(coAuthorUserId));
    assertEquals(project.getCoauthors().size(), 0);

    // call endpoint with valid coauthor
    ResponseEntity<Void> responseValid =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/coauthors",
            HttpMethod.PUT,
            coAuthorEntity,
            Void.class);
    assertEquals(responseValid.getStatusCode(), HttpStatus.OK);
    Query queryValid =
        entityManager.createNativeQuery(
            "select ca.coauthor from project_coauthor ca where ca.project_id =:id");
    queryValid.setParameter("id", project.getId());
    List<String> coauthors = (List<String>) queryValid.getResultList();
    assertEquals(coauthors.size(), 1);
    assertEquals(coauthors.get(0), COAUTHOR_ID);
    // end endpoint call

    // call endpoint with invalid coauthor
    ResponseEntity<Void> responseInvalid =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/coauthors",
            HttpMethod.PUT,
            invalidCoAuthorEntity,
            Void.class);
    assertEquals(responseInvalid.getStatusCode(), HttpStatus.BAD_REQUEST);
    Query queryInvalid =
        entityManager.createNativeQuery(
            "select ca.coauthor from project_coauthor ca where ca.project_id =:id");
    queryInvalid.setParameter("id", project.getId());
    coauthors = (List<String>) queryInvalid.getResultList();
    assertEquals(coauthors.size(), 1);
    assertEquals(coauthors.get(0), COAUTHOR_ID);
  }

  @Test
  public void
      shouldFailInputValidationWhenSetCoauthorSameAsCheckerWhenCallingSetProjectCoauthors() {
    Project project = createProject(coAuthorUserId);
    project.setCheckEngineer(COAUTHOR_ID);
    projectRepo.save(project);
    // call endpoint with coauthor same as check engineer
    ResponseEntity<String> responseValid =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/coauthors",
            HttpMethod.PUT,
            coAuthorEntity,
            String.class);
    assertEquals(responseValid.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void
      shouldFailInputValidationWhenSetCoauthorSameAsApproverWhenCallingSetProjectCoauthors() {
    Project project = createProject(coAuthorUserId);
    project.setApprovalEngineer(COAUTHOR_ID);
    projectRepo.save(project);
    // call endpoint with coauthor same as approver engineer
    ResponseEntity<String> responseValid =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId() + "/coauthors",
            HttpMethod.PUT,
            coAuthorEntity,
            String.class);
    assertEquals(responseValid.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void shouldGetApprovedProjectsWithFilterWhenCallingGetApprovedProjects() {
    // create 2 approved projects and 1 non-approved project
    // one of the approved projects belongs to the aircraft passed in and the other does not.
    Project project1 = createProject("1");
    project1.setApproved(Instant.now());
    projectRepo.save(project1);

    Project project2 = createProject("2");
    project2.setNumber("AAAA");
    project2.setApproved(Instant.now());
    projectRepo.save(project2);

    projectRepo.save(createProject("3"));

    // aircraft
    Aircraft aircraft = createAircraft(1);
    aircraftRepo.save(aircraft);

    // change groups
    ChangeGroup changeGroup1 = createAndSaveChangeGroup("change group 1", project1);

    project1.addChangeGroup(changeGroup1);
    createAndSaveAircraftChangeGroup(aircraft, changeGroup1);

    // retrieve entire approved projects based on matching aircraft ship number
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responseAircraft =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?aircraft=1&isEntire=true",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responseAircraft.getStatusCode(), HttpStatus.OK);
    assertEquals(responseAircraft.getBody().getContents().size(), 1);
    ProjectDTO projectDTO = (ProjectDTO) responseAircraft.getBody().getContents().get(0);
    assertEquals(projectDTO.getNumber(), "A12345");
    assertEquals(
        projectDTO
            .getChangeGroups()
            .get(0)
            .getAircraftChangeGroups()
            .get(0)
            .getAircraft()
            .getAircraftShipNo(),
        "1");

    // retrieve partial approved projects based on matching aircraft ship number
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePartial =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?aircraft=1&isEntire=false",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responsePartial.getStatusCode(), HttpStatus.OK);
    assertEquals(responsePartial.getBody().getContents().size(), 1);
    projectDTO = (ProjectDTO) responsePartial.getBody().getContents().get(0);
    assertEquals(projectDTO.getNumber(), "A12345");
    assertEquals(projectDTO.getChangeGroups().size(), 0);

    // retrieve partial approved projects based on matching project number
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responseNumber =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?number=AAAA",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(responseNumber.getStatusCode(), HttpStatus.OK);
    assertEquals(responseNumber.getBody().getContents().size(), 1);
    projectDTO = (ProjectDTO) responseNumber.getBody().getContents().get(0);
    assertEquals(projectDTO.getNumber(), "AAAA");
    assertEquals(projectDTO.getChangeGroups().size(), 0);

    // retrieve partial approved projects based on matching aircraft ship number and project number
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responseNone =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?aircraft=1&number=AAAA",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(HttpStatus.OK, responseNone.getStatusCode());
    assertEquals(0, responseNone.getBody().getContents().size());

    // retrieve partial approved projects based on matching project number
    ResponseEntity<PaginationDTO<AssignedProjectDTO>> responsePartialNumber =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?number=A",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(HttpStatus.OK, responsePartialNumber.getStatusCode());
    assertEquals(2, responsePartialNumber.getBody().getContents().size());
  }

  @Test
  public void shouldGetApprovedProjectsWithNoFilterCallingGetApprovedProjects() {
    // create 2 approved projects and 1 non-approved project
    Project project1 = createProject("1");
    project1.setApproved(Instant.now());
    projectRepo.save(project1);
    Project project2 = createProject("2");
    project2.setApproved(Instant.now());
    projectRepo.save(project2);
    project2.setApproved(Instant.now());
    projectRepo.save(createProject("3"));

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(2, response.getBody().getContents().size());
  }

  @Test
  public void shouldGetApprovedProjectsWithFleetFilterCallingGetApprovedProjects() {
    // fleet
    Fleet fleet = fleetRepo.save(createFleet(23));

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    draftAircraft.setFleet(fleet);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    createAndSaveEla("Ela Boss", aircraft);

    // project
    Project project1 = createProject("1");
    project1.setApprovalEngineer(emptyUserId);
    project1.setApproved(Instant.now());
    Project project = projectRepo.save(project1);

    // change group
    ChangeGroup cg = createAndSaveChangeGroup("Boeing 1", project);

    // aircraft change group
    createAndSaveAircraftChangeGroup(aircraft, cg);

    String fleetName = fleet.getName();

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?fleet=" + fleetName,
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});

    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(1, response.getBody().getContents().size());
    assertEquals(response.getBody().getContents().get(0).getFleets(), "fleetName 23");
  }

  @Test
  public void
      shouldGetApprovedProjectsWhenFleetAircraftsExistAndNoChangeGroupsAndCallingGetApprovedProjects() {
    // fleet
    Fleet fleet = fleetRepo.save(createFleet(23));

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    draftAircraft.setFleet(fleet);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    createAndSaveEla("Ela Boss", aircraft);

    // project
    Project project1 = createProject("1");
    project1.setApprovalEngineer(emptyUserId);
    project1.setApproved(Instant.now());
    projectRepo.save(project1);

    String fleetName = fleet.getName();

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?fleet=" + fleetName,
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(0, response.getBody().getContents().size());
  }

  @Test
  public void shouldGetApprovedProjectsWhenNoFleetAircraftsExistAndCallingGetApprovedProjects() {
    // fleet
    Fleet fleet = fleetRepo.save(createFleet(23));

    // aircraft
    Aircraft draftAircraft = createAircraft(23);
    Aircraft aircraft = aircraftRepo.save(draftAircraft);

    // ela
    createAndSaveEla("Ela Boss", aircraft);

    // project
    Project project1 = createProject("1");
    project1.setApprovalEngineer(emptyUserId);
    project1.setApproved(Instant.now());
    Project project = projectRepo.save(project1);

    // change group
    createAndSaveChangeGroup("Boeing 1", project);

    String fleetName = fleet.getName();

    ResponseEntity<PaginationDTO<AssignedProjectDTO>> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?fleet=" + fleetName,
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<PaginationDTO<AssignedProjectDTO>>() {});
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertEquals(0, response.getBody().getContents().size());
  }

  @Test
  public void updateProject_should_return_400_when_project_is_approved() {
    Project one = createProject(emptyUserId);
    one.setApproved(Instant.now());
    projectRepo.save(one);

    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + one.getId(), HttpMethod.PUT, emptyEntity, Void.class);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
  }

  @Test
  public void updateProject_should_fail_validation_when_started_is_null() {
    // arrange
    Project project =
        createAndSaveProject(
            "New Project", "description", "maintenance description", "1", "1", Instant.now());

    // set started to null
    Project updatedProject = createProject(project.getAuthor());
    updatedProject.setId(project.getId());
    updatedProject.setStarted(null);

    // act
    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + project.getId(),
            HttpMethod.PUT,
            createHttpEntity(updatedProject),
            Void.class);

    // assert
    // Input validation failed. JSON returned to the client is:
    // {"errors":[{"field":"started","message":"Missing required field."}]}
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
  }

  @Test
  public void deleteProject_should_return_400_when_project_is_approved() {
    Project one = createProject(emptyUserId);
    one.setApproved(Instant.now());
    projectRepo.save(one);

    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + one.getId(), HttpMethod.DELETE, emptyEntity, Void.class);
    assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void submitProject_should_return_400_when_project_is_approved() {
    Project one = createProject(emptyUserId);
    one.setApproved(Instant.now());
    projectRepo.save(one);

    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + one.getId() + "/submit",
            HttpMethod.PATCH,
            emptyEntity,
            Void.class);
    assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void checkProject_should_return_400_when_project_is_approved() {
    Project one = createProject(emptyUserId);
    one.setApproved(Instant.now());
    projectRepo.save(one);

    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + one.getId() + "/check", HttpMethod.PATCH, emptyEntity, Void.class);
    assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void approveProject_should_return_400_when_project_is_approved() {
    Project one = createProject(emptyUserId);
    one.setApproved(Instant.now());
    projectRepo.save(one);

    ResponseEntity<Void> response =
        restTemplate.exchange(
            ENDPOINT_URL + "/" + one.getId() + "/approve",
            HttpMethod.PATCH,
            emptyEntity,
            Void.class);
    assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void
      shouldFailInputValidationWhenCallGetApprovedProjectsWithInvalidAircraftShipNoOrFleetName() {

    // invalid fleet name
    ResponseEntity<ErrorWrapperDTO> response1 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?fleet=xxxxxyyy",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<ErrorWrapperDTO>() {});
    assertEquals(HttpStatus.BAD_REQUEST, response1.getStatusCode());
    assertEquals(
        response1.getBody().getErrors().get(0).getMessage(), "Fleet name is invalid: xxxxxyyy");

    // invalid aircraft ship number
    ResponseEntity<ErrorWrapperDTO> response2 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?aircraft=xxxxxyyy",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<ErrorWrapperDTO>() {});
    assertEquals(HttpStatus.BAD_REQUEST, response2.getStatusCode());
    assertEquals(
        response2.getBody().getErrors().get(0).getMessage(),
        "Aircraft ship number is invalid: xxxxxyyy");

    // invalid fleet name and aircraft ship number
    ResponseEntity<ErrorWrapperDTO> response3 =
        restTemplate.exchange(
            ENDPOINT_URL + "/approved?aircraft=xxxxxyyy&fleet=xxxxxyyy",
            HttpMethod.GET,
            viewerEntity,
            new ParameterizedTypeReference<ErrorWrapperDTO>() {});
    assertEquals(HttpStatus.BAD_REQUEST, response3.getStatusCode());
    assertEquals(
        response3.getBody().getErrors().get(0).getMessage(),
        "Aircraft ship number is invalid: xxxxxyyy");
  }

  private void addComponentsAndLoadsToNode(Node node) {
    Component component4 = createAndSaveComponent(node, "component4", ElectricalPhase.AC, 20d, 2);
    createAndSaveLoad(component4, "roll");

    Component component5 = createAndSaveComponent(node, "component5", ElectricalPhase.AC, 20d, 3);
    createAndSaveLoad(component5, "roll");
  }

  private void createTestData(String userId) {
    // create and persist 6 projects to the database
    projectSameAuthor = projectRepo.save(createProject(userId, "5")); // non approved project
    // with author same as
    // user Id in the
    // request
    projectDifferentAuthor = projectRepo.save(createProject("0", "6")); // non approved project with
    // a author different than
    // user Id in the
    // request

    one = createProject(userId, "1");
    one.setApproved(Instant.now());
    projectRepo.save(one); // approved project with author same as user Id in the request

    two = createProject("0", "2");
    two.setSubmitted(Instant.now());
    two.setCheckEngineer(userId);
    projectSameChecker = projectRepo.save(two); // non approved project with checker same as user id
    // in the request

    three = createProject("0", "3");
    three.setApprovalEngineer(userId);
    projectSameApprover = projectRepo.save(three); // non approved project with approver same as
    // user id in the request

    four = createProject("0", "4");
    four.setCoauthors(Collections.singletonList(userId));
    projectSameCoauthor = projectRepo.save(four); // non approved project with coauthor same
    // as user id in the request

    // set fleet data
    Fleet fleet = createFleet(1);
    fleetRepo.save(fleet);
    Fleet subFleet2 = createSubFleet(2);
    Fleet subFleet3 = createSubFleet(3);
    subFleet2.setParentFleet(fleet);
    subFleet3.setParentFleet(fleet);
    fleetRepo.save(subFleet2);
    fleetRepo.save(subFleet3);
    SortedSet<Aircraft> aircrafts = new TreeSet<>();
    Aircraft aircraft1 = createAircraft(1);
    Aircraft aircraft2 = createAircraft(2);
    aircrafts.add(aircraft1);
    aircrafts.add(aircraft2);
    fleet.setAircraft(aircrafts);
    aircraft1.setFleet(subFleet2);
    aircraft2.setFleet(subFleet3);
    aircraftRepo.save(aircraft1);
    aircraftRepo.save(aircraft2);

    ChangeGroup changeGroup = createChangeGroup("change");
    changeGroup.setProject(four);
    changeGroupRepo.save(changeGroup);

    createAndSaveAircraftChangeGroup(aircraft1, changeGroup);
    createAndSaveAircraftChangeGroup(aircraft2, changeGroup);
  }
}
