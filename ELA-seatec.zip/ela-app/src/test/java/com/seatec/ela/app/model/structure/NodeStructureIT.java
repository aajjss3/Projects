package com.seatec.ela.app.model.structure;

import static org.junit.Assert.*;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import javax.transaction.Transactional;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@Transactional
public class NodeStructureIT extends AbstractControllerIntegrationTest {

  @Autowired
  private @Qualifier("testEntityManager") TestEntityManager entityManager;

  @Rule public ExpectedException thrown = ExpectedException.none();

  @Test
  public void simpleWrite() {
    NodeStructure nodeStructure = new NodeStructure();
    nodeStructure.setStructureName("structureName");
    nodeStructure.setNodeName("nodeName");
    Object result = entityManager.persistAndGetId(nodeStructure);
    NodeStructure found = entityManager.find(NodeStructure.class, nodeStructure.getId());
    assertEquals(found.getId(), result);
    entityManager.remove(found);
  }

  @Test
  public void failedEmptyFlushedWrite() {
    NodeStructure nodeStructure = new NodeStructure();
    thrown.expectMessage("ConstraintViolationException");
    // Note:  persistAndGetID does not flush and won't throw exception in general: see HHH-8028
    // Object result = entityManager.persistAndGetId(nodeStructure);
    Object result = entityManager.persistFlushFind(nodeStructure);
  }
}
