package com.seatec.ela.app.controller.project.change;

import static org.junit.Assert.*;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.enumeration.ActionType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3324.sql",
        "/datasets/node-3324.sql",
        "/datasets/component-3324.sql",
        "/datasets/load-3324.sql"
      }),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class ChangeControllerIT extends AbstractControllerIntegrationTest {
  private String ENDPOINT_START_URL = BASE_URL + "/service/projects/";

  private String ENDPOINT_MID_URL = "/changegroups/";

  private String ENDPOINT_END_URL = "/change";

  @Autowired private ProjectRepo projectRepo;

  @Test
  public void when_create_componentChangeWithNullLoadChanges_then_persist() {
    // arrange
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    ComponentChange componentChange =
        createComponentChange(null, ElectricalPhase.AC3, false, "ElectIdent1", 0d);
    componentChange.setNominalPower(500.0);

    Change changeWithComponentData = createChange();
    changeWithComponentData.setNodeName("1IWXP");
    changeWithComponentData.setComponentChange(componentChange);
    changeWithComponentData.setAction(ActionType.ADD);
    changeWithComponentData.setComponentElectIdent("compElectIdent");
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // act
    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);

    // assert
    assertEquals(HttpStatus.OK, response.getStatusCode());
  }

  @Test
  public void
      when_create_nodeChangeActionAdd_WithIncompatibleVoltage_then_throwConflictException() {
    // arrange
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    // node change
    NodeChange nodeChange =
        createNodeChange(
            300D,
            "newBus",
            100D, // must match parent (ie. 115D)
            ElectricalPhase.AC3,
            NodeType.BUS,
            10D,
            false,
            false,
            false,
            ElectricalPhase.AC3);

    // change
    Change change = createChange();
    change.setAction(ActionType.ADD);
    change.setNodeName("1IWXP");
    change.setNodeChange(nodeChange);

    // aircraft change group
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // act
    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(change),
            ErrorWrapperDTO.class);

    // assert
    ErrorWrapperDTO body = response.getBody();
    HttpStatus status = response.getStatusCode();

    assertEquals(HttpStatus.CONFLICT, status);
    assertNotNull(body);
    assertNotNull(body.getErrors());
    assertEquals(
        "Incompatible Voltage (100.0) for Node Type (BUS) based on parent Node Type (BUS) and Voltage (115.0)",
        body.getErrors().get(0).getMessage());
  }

  @Test
  public void
      when_create_nodeChangeActionAdd_WithIncompatibleVoltageType_then_throwConflictException() {
    // arrange
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    // node change
    NodeChange nodeChange =
        createNodeChange(
            300D,
            "newBus",
            115D,
            ElectricalPhase.DC, // has to match parent (ie AC3)
            NodeType.BUS,
            10D,
            false,
            false,
            false,
            ElectricalPhase.AC3);

    // change
    Change change = createChange();
    change.setAction(ActionType.ADD);
    change.setNodeName("1IWXP");
    change.setNodeChange(nodeChange);

    // aircraft change group
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // act
    ResponseEntity<ErrorWrapperDTO> response =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(change),
            ErrorWrapperDTO.class);

    // assert
    ErrorWrapperDTO body = response.getBody();
    HttpStatus status = response.getStatusCode();

    assertEquals(HttpStatus.CONFLICT, status);
    assertNotNull(body);
    assertNotNull(body.getErrors());
    assertEquals(
        "Incompatible Voltage Type (DC) for Node Type (BUS) based on parent Node Type (BUS) and Voltage Type (AC3)",
        body.getErrors().get(0).getMessage());
  }

  @Test
  public void shouldProduceErrorWhenMissingRequiredParmWhenCreateNodeChange() {
    Fleet fleet = createAndSaveFleet(1);
    Aircraft aircraft = createAndSaveAircraft(1, fleet);
    Ela ela = createAndSaveEla("ela name", aircraft);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);
    Change emptyChange = createChange();
    NodeChange nodeChange =
        createNodeChange(
            null,
            "name",
            1.0,
            ElectricalPhase.AC,
            NodeType.GENERATOR,
            null,
            false,
            false,
            false,
            ElectricalPhase.AC3);
    Change changeWithNodeData = createChange();
    changeWithNodeData.setNodeChange(nodeChange);
    changeWithNodeData.setAction(ActionType.ADD);
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // empty change
    ResponseEntity<ErrorWrapperDTO> emptyChangeresponse =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(emptyChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, emptyChangeresponse.getStatusCode());
    assertTrue(
        emptyChangeresponse.getBody().getErrors().stream()
            .anyMatch(
                item ->
                    "change".equals(item.getField())
                        && "not a valid change type".equals(item.getMessage())));
    assertTrue(
        emptyChangeresponse.getBody().getErrors().stream()
            .anyMatch(
                item ->
                    "action".equals(item.getField())
                        && "Missing required field.".equals(item.getMessage())));

    // null node change name
    nodeChange.setName(null);
    ResponseEntity<ErrorWrapperDTO> responseNoName =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithNodeData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoName.getStatusCode());
    assertEquals("nodeChange.name", responseNoName.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoName.getBody().getErrors().get(0).getMessage());

    // null node type
    nodeChange.setName("nodeChange.name");
    nodeChange.setNodeType(null);
    ResponseEntity<ErrorWrapperDTO> responseNoNodeType =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithNodeData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoNodeType.getStatusCode());
    assertEquals("nodeChange.nodeType", responseNoNodeType.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoNodeType.getBody().getErrors().get(0).getMessage());

    // null voltage
    nodeChange.setNodeType(NodeType.GENERATOR);
    nodeChange.setVoltage(null);
    ResponseEntity<ErrorWrapperDTO> responseNoVoltage =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithNodeData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoVoltage.getStatusCode());
    assertEquals("nodeChange.voltage", responseNoVoltage.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoVoltage.getBody().getErrors().get(0).getMessage());

    // null voltage type
    nodeChange.setVoltage(1.2);
    nodeChange.setVoltageType(null);
    ResponseEntity<ErrorWrapperDTO> responseNoVoltageType =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithNodeData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoVoltageType.getStatusCode());
    assertEquals(
        "nodeChange.voltageType", responseNoVoltageType.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoVoltageType.getBody().getErrors().get(0).getMessage());
  }

  @Test
  public void shouldProduceErrorWhenLoadValuesAreOutofRangeWhenCreateComponentChange() {
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    List<LoadChange> loadChanges = new ArrayList<>();
    LoadChange loadChange = createLoadChange("roll");
    loadChanges.add(loadChange);
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, "ElectIdent1", 0d);
    componentChange.setNominalPower(500.0);

    Change changeWithComponentData = createChange();
    changeWithComponentData.setNodeName("1IWXP");
    changeWithComponentData.setComponentChange(componentChange);
    changeWithComponentData.setAction(ActionType.ADD);
    changeWithComponentData.setComponentElectIdent("compElectIdent");
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // test va greater than nominal power provided
    loadChange.setVa(componentChange.getNominalPower() + 1);
    ResponseEntity<ErrorWrapperDTO> responseOverVa =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseOverVa.getStatusCode());
    assertEquals(
        "componentChange.nominalPower", responseOverVa.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid component load for Nominal Power",
        responseOverVa.getBody().getErrors().get(0).getMessage());

    // test negative va
    loadChange.setVa(-0.001);
    ResponseEntity<ErrorWrapperDTO> responseNegVa =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNegVa.getStatusCode());
    assertEquals(
        "componentChange.nominalPower", responseNegVa.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid component load for Nominal Power",
        responseNegVa.getBody().getErrors().get(0).getMessage());

    // test negative pf
    loadChange.setVa(componentChange.getNominalPower());
    loadChange.setPowerFactor(1.1);
    ResponseEntity<ErrorWrapperDTO> responseNegPf =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNegPf.getStatusCode());
    assertEquals(
        "componentChange.nominalPower", responseNegPf.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid component load for Nominal Power",
        responseNegPf.getBody().getErrors().get(0).getMessage());

    // test negative nomPower
    loadChange.setVa(componentChange.getNominalPower());
    loadChange.setPowerFactor(-0.01);
    ResponseEntity<ErrorWrapperDTO> responseOverPf =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseOverPf.getStatusCode());
    assertEquals(
        "componentChange.nominalPower", responseOverPf.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid component load for Nominal Power",
        responseOverPf.getBody().getErrors().get(0).getMessage());

    // missing nominalPower and has bad pf load
    componentChange.setNominalPower(null);
    ResponseEntity<ErrorWrapperDTO> responseLoadButNoNomPower =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseLoadButNoNomPower.getStatusCode());
    assertEquals(
        "componentChange.nominalPower",
        responseLoadButNoNomPower.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid component load for Nominal Power",
        responseLoadButNoNomPower.getBody().getErrors().get(0).getMessage());

    // missing nominalPower  and has loads (succeeds for Boeing case)
    loadChange.setPowerFactor(1.0d);
    ResponseEntity<ErrorWrapperDTO> responseLoadButNoNomPowerAndNoLoads =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.OK, responseLoadButNoNomPowerAndNoLoads.getStatusCode());
  }

  @Test
  public void shouldProduceErrorWhenMissingRequiredParamWhenCreateComponentChange() {
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    List<LoadChange> loadChanges = new ArrayList<>();
    loadChanges.add(createLoadChange("roll"));
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.AC3, false, "ElectIdent1", 0d);

    Change changeWithComponentData = createChange();
    changeWithComponentData.setComponentChange(componentChange);
    changeWithComponentData.setAction(ActionType.ADD);
    changeWithComponentData.setNodeName("1IWXP");
    changeWithComponentData.setComponentElectIdent("compElectIdent");
    componentChange.setNominalPower(500.0);
    AircraftChangeGroup acg = createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // add happy path
    ResponseEntity<ErrorWrapperDTO> responseOk =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.OK, responseOk.getStatusCode());

    // null component Elect Ident
    changeWithComponentData.setComponentElectIdent(null);
    ResponseEntity<ErrorWrapperDTO> responseNoComponentElectIdent =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoComponentElectIdent.getStatusCode());
    assertEquals("change", responseNoComponentElectIdent.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid change type",
        responseNoComponentElectIdent.getBody().getErrors().get(0).getMessage());

    // null Change action
    changeWithComponentData.setComponentElectIdent("compElectIdent");
    changeWithComponentData.setAction(null);
    ResponseEntity<ErrorWrapperDTO> responseNoAction =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoAction.getStatusCode());
    assertEquals("action", responseNoAction.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoAction.getBody().getErrors().get(0).getMessage());

    // null component change name
    changeWithComponentData.setAction(ActionType.ADD);
    componentChange.setName(null);
    ResponseEntity<ErrorWrapperDTO> responseNoName =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoName.getStatusCode());
    assertEquals("componentChange.name", responseNoName.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoName.getBody().getErrors().get(0).getMessage());

    // null component change electrical ident
    componentChange.setName("name");
    componentChange.setElectIdent(null);
    ResponseEntity<ErrorWrapperDTO> responseNoElectIdent =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoElectIdent.getStatusCode());
    assertEquals(
        "componentChange.electIdent", responseNoElectIdent.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoElectIdent.getBody().getErrors().get(0).getMessage());

    // null electrical phase
    componentChange.setElectIdent("electIden2");
    componentChange.setElectricalPhase(null);
    ResponseEntity<ErrorWrapperDTO> responseNoElectricalPhase =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoElectricalPhase.getStatusCode());
    assertEquals(
        "componentChange.electricalPhase",
        responseNoElectricalPhase.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseNoElectricalPhase.getBody().getErrors().get(0).getMessage());

    // null component electrical ident for Change
    componentChange.setElectricalPhase(ElectricalPhase.AC3);
    changeWithComponentData.setComponentElectIdent(null);
    ResponseEntity<ErrorWrapperDTO> responseNoChangeElectricalIdent =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoChangeElectricalIdent.getStatusCode());
    assertEquals("change", responseNoChangeElectricalIdent.getBody().getErrors().get(0).getField());
    assertEquals(
        "not a valid change type",
        responseNoChangeElectricalIdent.getBody().getErrors().get(0).getMessage());
  }

  @Test
  public void shouldProduceErrorWhenMissingRequiredParamWhenUpdateNodeChange() {
    Fleet fleet = createAndSaveFleet(1);
    Aircraft aircraft = createAndSaveAircraft(1, fleet);
    Ela ela = createAndSaveEla("ela name", aircraft);
    Project project = createAndSaveProject("title", "description", null, null, null, null);

    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    Change changeWithNodeData = createAndSaveNodeChange(changeGroup);
    UUID testChangeId = changeWithNodeData.getId();
    Change testChange = new Change();
    testChange.setNodeChange(changeWithNodeData.getNodeChange());
    testChange.setNodeName(changeWithNodeData.getNodeName());
    testChange.setAction(ActionType.EDIT);

    NodeChange testNodeChange = new NodeChange();
    testNodeChange.setVoltageType(changeWithNodeData.getNodeChange().getVoltageType());
    testNodeChange.setVoltage(changeWithNodeData.getNodeChange().getVoltage());
    testNodeChange.setName(changeWithNodeData.getNodeChange().getName());
    testNodeChange.setNodeType(changeWithNodeData.getNodeChange().getNodeType());
    testChange.setNodeChange(testNodeChange);

    // confirm happy path works
    ResponseEntity<ErrorWrapperDTO> responseOk =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.OK, responseOk.getStatusCode());

    // missing change node name
    testNodeChange.setName(null);
    ResponseEntity<ErrorWrapperDTO> responseNoName =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoName.getStatusCode());
    assertEquals("nodeChange.name", responseNoName.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoName.getBody().getErrors().get(0).getMessage());

    // change node name does not match the original
    testNodeChange.setName("new name not matching");
    ResponseEntity<ErrorWrapperDTO> responseChangedName =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.CONFLICT, responseChangedName.getStatusCode());
    assertEquals(
        "Cannot edit the Name value for an existing entity.",
        responseChangedName.getBody().getErrors().get(0).getMessage());

    // action existing ADD to new ADD exception
    testNodeChange.setName(changeWithNodeData.getNodeChange().getName());
    testChange.setAction(ActionType.ADD);
    ResponseEntity<ErrorWrapperDTO> responseActionAddtoAdd =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.CONFLICT, responseActionAddtoAdd.getStatusCode());
    assertEquals(
        "Cannot 'ADD' this item because its marked as 'ADD' already. To resolve, remove the 'ADD' Change entry.",
        responseActionAddtoAdd.getBody().getErrors().get(0).getMessage());

    // action existing ADD to new DELETE exception
    testChange.setAction(ActionType.DELETE);
    ResponseEntity<ErrorWrapperDTO> responseActionAddtoDelete =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionAddtoDelete.getStatusCode());
    assertEquals(
        "Cannot perform this action (ADD -> DELETE).",
        responseActionAddtoDelete.getBody().getErrors().get(0).getMessage());

    // missing nodeType
    testChange.setAction(ActionType.EDIT);
    testNodeChange.setNodeType(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoNodeType =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoNodeType.getStatusCode());
    assertEquals(
        "nodeChange.nodeType", responseActionNoNodeType.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoNodeType.getBody().getErrors().get(0).getMessage());

    // missing voltage
    testNodeChange.setNodeType(changeWithNodeData.getNodeChange().getNodeType());
    testNodeChange.setVoltage(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoVoltage =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoVoltage.getStatusCode());
    assertEquals(
        "nodeChange.voltage", responseActionNoVoltage.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoVoltage.getBody().getErrors().get(0).getMessage());

    // missing voltageType
    testNodeChange.setVoltage(changeWithNodeData.getNodeChange().getVoltage());
    testNodeChange.setVoltageType(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoVoltageType =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoVoltageType.getStatusCode());
    assertEquals(
        "nodeChange.voltageType",
        responseActionNoVoltageType.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoVoltageType.getBody().getErrors().get(0).getMessage());

    // change entity not present
    testNodeChange.setVoltageType(changeWithNodeData.getNodeChange().getVoltageType());
    testChangeId = UUID.randomUUID();
    ResponseEntity<ErrorWrapperDTO> responseActionNotPresentChangeId =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNotPresentChangeId.getStatusCode());
    assertEquals(
        "changeId", responseActionNotPresentChangeId.getBody().getErrors().get(0).getField());
    assertEquals(
        "Value does not exist.",
        responseActionNotPresentChangeId.getBody().getErrors().get(0).getMessage());
  }

  @Test
  public void shouldProduceErrorWhenMissingRequiredParamWhenUpdateComponentChange() {
    Fleet fleet = createAndSaveFleet(1);
    Aircraft aircraft = createAndSaveAircraft(1, fleet);
    createAndSaveEla("ela name", aircraft);
    Project project = createAndSaveProject("title", "description", null, null, null, null);

    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    Change changeWithComponentData = createAndSaveComponentChange(changeGroup);
    UUID testChangeId = changeWithComponentData.getId();
    Change testChange = new Change();
    testChange.setNodeChange(changeWithComponentData.getNodeChange());
    testChange.setNodeName(changeWithComponentData.getNodeName());
    testChange.setComponentElectIdent(changeWithComponentData.getComponentElectIdent());
    testChange.setAction(ActionType.EDIT);

    ComponentChange testComponentChange = new ComponentChange();
    testComponentChange.setName(changeWithComponentData.getComponentChange().getName());
    testComponentChange.setElectIdent(changeWithComponentData.getComponentChange().getElectIdent());
    testComponentChange.setElectricalPhase(
        changeWithComponentData.getComponentChange().getElectricalPhase());
    testComponentChange.setIntermittent(
        changeWithComponentData.getComponentChange().getIntermittent());
    testChange.setComponentChange(testComponentChange);

    // missing aircraft in change group
    ResponseEntity<ErrorWrapperDTO> responseNoAircraft =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.NOT_FOUND, responseNoAircraft.getStatusCode());

    // confirm happy path works
    AircraftChangeGroup aircraftChangeGroup =
        createAndSaveAircraftChangeGroup(aircraft, changeGroup);
    changeGroup.setAircraftChangeGroups(Collections.singletonList(aircraftChangeGroup));
    ResponseEntity<ErrorWrapperDTO> responseOk =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.OK, responseOk.getStatusCode());

    // missing change component name
    testComponentChange.setName(null);
    ResponseEntity<ErrorWrapperDTO> responseNoName =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseNoName.getStatusCode());
    assertEquals("componentChange.name", responseNoName.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.", responseNoName.getBody().getErrors().get(0).getMessage());

    // action existing ADD to new ADD exception
    testComponentChange.setName(changeWithComponentData.getComponentChange().getName());
    testChange.setAction(ActionType.ADD);
    ResponseEntity<ErrorWrapperDTO> responseActionAddtoAdd =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.CONFLICT, responseActionAddtoAdd.getStatusCode());
    assertEquals(
        "Cannot 'ADD' this item because its marked as 'ADD' already. To resolve, remove the 'ADD' Change entry.",
        responseActionAddtoAdd.getBody().getErrors().get(0).getMessage());

    // action existing ADD to new DELETE exception
    testChange.setAction(ActionType.DELETE);
    ResponseEntity<ErrorWrapperDTO> responseActionAddtoDelete =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionAddtoDelete.getStatusCode());
    assertEquals(
        "Cannot perform this action (ADD -> DELETE).",
        responseActionAddtoDelete.getBody().getErrors().get(0).getMessage());

    // missing  change componentElectIdent
    testChange.setAction(ActionType.EDIT);
    testComponentChange.setElectIdent(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoElectIdent =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoElectIdent.getStatusCode());
    assertEquals(
        "componentChange.electIdent",
        responseActionNoElectIdent.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoElectIdent.getBody().getErrors().get(0).getMessage());

    // misssing change component electricalPhase
    testComponentChange.setElectIdent(changeWithComponentData.getComponentChange().getElectIdent());
    testComponentChange.setElectricalPhase(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoElectricalPhase =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoElectricalPhase.getStatusCode());
    assertEquals(
        "componentChange.electricalPhase",
        responseActionNoElectricalPhase.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoElectricalPhase.getBody().getErrors().get(0).getMessage());

    // missing change component intermittent
    testComponentChange.setElectricalPhase(
        changeWithComponentData.getComponentChange().getElectricalPhase());
    testComponentChange.setIntermittent(null);
    ResponseEntity<ErrorWrapperDTO> responseActionNoIntermittent =
        restTemplate.exchange(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL
                + "/"
                + testChangeId,
            HttpMethod.PUT,
            createHttpEntity(testChange),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, responseActionNoIntermittent.getStatusCode());
    assertEquals(
        "componentChange.intermittent",
        responseActionNoIntermittent.getBody().getErrors().get(0).getField());
    assertEquals(
        "Missing required field.",
        responseActionNoIntermittent.getBody().getErrors().get(0).getMessage());
  }

  @Test
  public void when_CreateComponentChange_PowerFactorLoadValueIsNotOne_then_ThrowValidationError() {
    Aircraft aircraft = aircraftRepo.findByAircraftShipNo("3324").get(0);
    Project project = createAndSaveProject("title", "description", null, null, null, null);
    ChangeGroup changeGroup = createAndSaveChangeGroup("change group name", project);

    List<LoadChange> loadChanges = new ArrayList<>();
    LoadChange loadChange = createLoadChange("roll");

    // set PowerFactor to something other than 1 (validation should fail here)
    loadChange.setPowerFactor(0d);
    loadChanges.add(loadChange);

    // 'DC' electricalPhase must be 1 Pf
    ComponentChange componentChange =
        createComponentChange(loadChanges, ElectricalPhase.DC, false, "ElectIdent1", 0d);
    componentChange.setNominalPower(500.0);

    Change changeWithComponentData = createChange();
    changeWithComponentData.setNodeName("1IWXP");
    changeWithComponentData.setComponentChange(componentChange);
    changeWithComponentData.setAction(ActionType.ADD);
    changeWithComponentData.setComponentElectIdent("compElectIdent");
    createAndSaveAircraftChangeGroup(aircraft, changeGroup);

    // test invalid pf
    ResponseEntity<ErrorWrapperDTO> invalidResponse =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.BAD_REQUEST, invalidResponse.getStatusCode());
    assertEquals(
        "not a valid Power Factor '0.0' for component load (Operating Mode: 'MAXI' and Flight Phase 'roll')",
        invalidResponse.getBody().getErrors().get(0).getMessage());

    // test valid pf
    componentChange.getLoadChanges().get(0).setPowerFactor(1d);
    ResponseEntity<ErrorWrapperDTO> validResponse =
        restTemplate.postForEntity(
            ENDPOINT_START_URL
                + project.getId()
                + ENDPOINT_MID_URL
                + changeGroup.getId()
                + ENDPOINT_END_URL,
            createHttpEntity(changeWithComponentData),
            ErrorWrapperDTO.class);
    assertEquals(HttpStatus.OK, validResponse.getStatusCode());
  }
}
