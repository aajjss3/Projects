package com.seatec.ela.app.util.load;

import com.seatec.ela.app.config.ClientConfig;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import com.seatec.ela.app.util.enumeration.OperatingMode;
import org.junit.Test;

public class LoadSummaryUtilTest {

  @Test
  public void testValidateElectricalPhase_valid() {
    ElectricalPhase expectedElectricalPhase = ElectricalPhase.AC3;

    SummarizedLoad loadSummary =
        new SummarizedLoad(
            ClientConfig.Airbus.GROUND.toString(),
            OperatingMode.Airbus.MAXI.toString(),
            expectedElectricalPhase,
            SummaryType.COMPONENTS);

    LoadSummaryUtil.validateElectricalPhase(expectedElectricalPhase, loadSummary);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testValidateElectricalPhase_invalid() {
    ElectricalPhase expectedElectricalPhase = ElectricalPhase.AC3;

    SummarizedLoad loadSummary =
        new SummarizedLoad(
            ClientConfig.Airbus.GROUND.toString(),
            OperatingMode.Airbus.MAXI.toString(),
            ElectricalPhase.ACA,
            SummaryType.COMPONENTS);

    LoadSummaryUtil.validateElectricalPhase(expectedElectricalPhase, loadSummary);
  }
}
