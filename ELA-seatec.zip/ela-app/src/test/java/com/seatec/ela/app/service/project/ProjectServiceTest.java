package com.seatec.ela.app.service.project;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.AssignedProjectDTO;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.exception.BadRequestException;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ProjectDAO;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.service.ElaService;
import com.seatec.ela.app.service.EmailExternalService;
import com.seatec.ela.app.service.KeycloakService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

@RunWith(MockitoJUnitRunner.class)
public class ProjectServiceTest {

  private static final String DEFAULT_USER_ID = "00000-00000-00000-00000-00000";

  @InjectMocks private ProjectService subject;

  @Mock private ProjectRepo mockProjectRepo;

  @Mock private ProjectDAO mockProjectDAO;

  @Mock private EmailExternalService mockEmailService;

  @Mock private AircraftRepository mockAircraftRepository;

  @Mock private ChangeGroupRepo mockChangeGroupRepo;

  @Mock private KeycloakService mockKeycloakService;

  @Mock private ElaService mockElaService;

  @Mock
  @Qualifier("mapAllFlatProject")
  ModelMapper mapperPartial;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void when_GetMyProjects_isAdminUser_then_return_all_projects() {
    // arrange
    List<AssignedProjectDTO> assignedProjects = mockAssignedProjectDTOs(1);

    when(mockKeycloakService.isUserValidAndInRoles(any(String.class), anyList())).thenReturn(true);
    when(mockProjectDAO.findAllByApprovedIsNull()).thenReturn(assignedProjects);

    // act
    PaginationDTO<AssignedProjectDTO> results =
        subject.getMyProjects(DEFAULT_USER_ID, null, null, "fleets", true);

    // assert
    verify(mockKeycloakService, times(1)).isUserValidAndInRoles(isA(String.class), anyList());
    verify(mockProjectDAO, times(1)).findAllByApprovedIsNull();

    assertFalse(results.getContents().isEmpty());
    assertEquals(
        "project count should match", assignedProjects.size(), results.getContents().size());
  }

  @Test
  public void when_GetMyProjects_isNotAdminUser_then_return_matching_projects() {
    // arrange
    List<AssignedProjectDTO> assignedProjects = mockAssignedProjectDTOs(1);

    when(mockKeycloakService.isUserValidAndInRoles(any(String.class), anyList())).thenReturn(false);
    when(mockProjectDAO.getMyProjects(DEFAULT_USER_ID)).thenReturn(assignedProjects);
    PaginationDTO<AssignedProjectDTO> results =
        subject.getMyProjects(DEFAULT_USER_ID, null, null, "fleets", true);

    // assert
    verify(mockKeycloakService, times(1)).isUserValidAndInRoles(isA(String.class), anyList());
    verify(mockProjectDAO, times(1)).getMyProjects(DEFAULT_USER_ID);

    assertFalse(results.getContents().isEmpty());
    assertEquals(
        "project count should be one", assignedProjects.size(), results.getContents().size());
  }

  @Test
  public void when_getApprovedProjects_with_no_fleet_aircrafts_then_return_empty_list() {
    // arrange
    when(mockAircraftRepository.findAllByFleet_Name(any(String.class)))
        .thenReturn(new ArrayList<>());

    // act
    List<AssignedProjectDTO> response =
        subject
            .getApprovedProjects(
                null, "B767", null, null, null, null, false, null, null, "approved", true)
            .getContents();

    // assert
    verify(mockAircraftRepository, times(1)).findAllByFleet_Name(isA(String.class));

    assertTrue(response.isEmpty());
  }

  @Test
  public void when_deleteProject_with_author_then_delete_successful() {
    // arrange
    Project project = createNewProject("Project 123", "123", true, false);
    project.setAuthor(DEFAULT_USER_ID);
    project.setCheckEngineer("0");
    project.setCoauthors(new ArrayList<>());

    when(mockProjectRepo.findById(any(UUID.class))).thenReturn(Optional.of(project));
    doNothing().when(mockProjectRepo).deleteById(isA(UUID.class));

    // act
    subject.deleteProject(project.getId(), DEFAULT_USER_ID);

    // assert
    verify(mockProjectRepo, times(1)).findById(isA(UUID.class));
    verify(mockProjectRepo, times(1)).deleteById(isA(UUID.class));
  }

  @Test
  public void when_deleteProject_with_checker_then_delete_successful() {
    // arrange
    Project project = createNewProject("Project 123", "123", true, false);
    project.setAuthor("0");
    project.setCoauthors(new ArrayList<>());
    project.setCheckEngineer(DEFAULT_USER_ID);

    when(mockProjectRepo.findById(any(UUID.class))).thenReturn(Optional.of(project));
    doNothing().when(mockProjectRepo).deleteById(isA(UUID.class));

    // act
    subject.deleteProject(project.getId(), DEFAULT_USER_ID);

    // assert
    verify(mockProjectRepo, times(1)).findById(isA(UUID.class));
    verify(mockProjectRepo, times(1)).deleteById(isA(UUID.class));
  }

  @Test
  public void when_deleteProject_with_coAuthor_then_delete_successful() {
    // arrange
    Project project = createNewProject("Project 123", "123", true, false);
    project.setAuthor("0");
    project.setCheckEngineer("0");
    project.setCoauthors(Arrays.asList(DEFAULT_USER_ID));

    when(mockProjectRepo.findById(any(UUID.class))).thenReturn(Optional.of(project));
    doNothing().when(mockProjectRepo).deleteById(isA(UUID.class));

    // act
    subject.deleteProject(project.getId(), DEFAULT_USER_ID);

    // assert
    verify(mockProjectRepo, times(1)).findById(isA(UUID.class));
    verify(mockProjectRepo, times(1)).deleteById(isA(UUID.class));
  }

  @Test
  public void when_deleteProject_with_admin_then_delete_successful() {
    // arrange
    Project project = createNewProject("Project 123", "123", true, false);
    project.setAuthor("0");
    project.setCheckEngineer("0");
    project.setCoauthors(new ArrayList<>());

    when(mockProjectRepo.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockKeycloakService.isUserValidAndInRoles(any(String.class), anyList())).thenReturn(true);
    doNothing().when(mockProjectRepo).deleteById(isA(UUID.class));

    // act
    subject.deleteProject(project.getId(), DEFAULT_USER_ID);

    // assert
    verify(mockProjectRepo, times(1)).findById(isA(UUID.class));
    verify(mockKeycloakService, times(1)).isUserValidAndInRoles(isA(String.class), anyList());
    verify(mockProjectRepo, times(1)).deleteById(isA(UUID.class));
  }

  @Test(expected = BadRequestException.class)
  public void when_deleteProject_with_invalid_user_then_throw_BadRequestException() {
    // arrange
    Project project = createNewProject("Project 123", "123", true, false);
    project.setAuthor("0");
    project.setCheckEngineer("0");
    project.setCoauthors(new ArrayList<>());

    when(mockProjectRepo.findById(any(UUID.class))).thenReturn(Optional.of(project));
    when(mockKeycloakService.isUserValidAndInRoles(any(String.class), anyList())).thenReturn(false);

    // act
    subject.deleteProject(project.getId(), DEFAULT_USER_ID);
  }

  private List<AssignedProjectDTO> mappedProjectDtos(List<Project> projects) {
    List<AssignedProjectDTO> assignedProjectDTOS = new ArrayList<>();

    for (Project project : projects) {
      assignedProjectDTOS.add(convertProjectToAssignedProjectDTO(project));
    }

    return assignedProjectDTOS;
  }

  private List<Project> mockProjects(int numberOfProjects) {
    List<Project> projects = new ArrayList<>();

    for (int i = 0; i < numberOfProjects; i++) {
      String title = RandomStringUtils.random(5 + i, true, false);
      String number = RandomStringUtils.random(5 + i, false, true);
      Project project = createNewProject(title, number, true, false);
      projects.add(project);
    }

    return projects;
  }

  private Page<Project> mockPageProjects(int numberOfProjects) {
    List<Project> projects = new ArrayList<>();

    for (int i = 0; i < numberOfProjects; i++) {
      String title = RandomStringUtils.random(5 + i, true, false);
      String number = RandomStringUtils.random(5 + i, false, true);
      Project project = createNewProject(title, number, true, false);
      projects.add(project);
    }

    return new PageImpl<Project>(projects);
  }

  private List<AssignedProjectDTO> mockAssignedProjectDTOs(int numberOfProjects) {
    List<AssignedProjectDTO> dtos = new ArrayList<>();
    for (int i = 0; i < numberOfProjects; i++) {
      String title = RandomStringUtils.random(5 + i, true, false);
      String number = RandomStringUtils.random(5 + i, false, true);
      dtos.add(createNewAssignedProjectDTO(title, number, true, false));
    }
    return dtos;
  }

  private AssignedProjectDTO createNewAssignedProjectDTO(
      String title, String nbr, boolean isChecked, boolean isApproved) {
    AssignedProjectDTO dto = new AssignedProjectDTO();
    dto.setTitle(title);
    dto.setId(UUID.randomUUID());
    dto.setSubmitted(Instant.now());
    dto.setStarted(Instant.now());
    dto.setRevisionLevel("revision level");
    dto.setRetired(Instant.now());
    dto.setNumber(nbr);
    dto.setMaintenanceDescription("maintenance Desc");
    dto.setDescription("description");
    dto.setAuthor("0");
    dto.setComments(new ArrayList<>());
    if (isChecked) {
      dto.setCheckEngineer("check engineer");
      dto.setChecked(Instant.now());
    }

    if (isApproved) {
      dto.setApprovalEngineer(DEFAULT_USER_ID);
      dto.setApproved(Instant.now());
    }

    return dto;
  }

  private Project createNewProject(
      String title, String nbr, boolean isChecked, boolean isApproved) {
    Project project = new Project();
    project.setTitle(title);
    project.setId(UUID.randomUUID());
    project.setSubmitted(Instant.now());
    project.setStarted(Instant.now());
    project.setRevisionLevel("revision level");
    project.setRetired(Instant.now());
    project.setNumber(nbr);
    project.setMaintenanceDescription("maintenance Desc");
    project.setDescription("description");
    project.setAuthor("0");
    project.setCreated(Instant.now());
    project.setAnalysis(new ProjectReportDTO());
    project.setComments(new ArrayList<>());
    project.setVersion(1);

    if (isChecked) {
      project.setCheckEngineer("check engineer");
      project.setChecked(Instant.now());
    }

    if (isApproved) {
      project.setApprovalEngineer(DEFAULT_USER_ID);
      project.setApproved(Instant.now());
    }

    return project;
  }

  private AssignedProjectDTO convertProjectToAssignedProjectDTO(Project project) {
    AssignedProjectDTO assignedProjectDTO = new AssignedProjectDTO();

    assignedProjectDTO.setApprovalEngineer(project.getApprovalEngineer());
    assignedProjectDTO.setApproved(project.getApproved());
    assignedProjectDTO.setAuthor(project.getAuthor());
    assignedProjectDTO.setChecked(project.getChecked());
    assignedProjectDTO.setCheckEngineer(project.getCheckEngineer());
    assignedProjectDTO.setCoauthors(project.getCoauthors());
    // assignedProjectDTO.setComments(project.getComments());
    assignedProjectDTO.setDescription(project.getDescription());
    assignedProjectDTO.setId(project.getId());
    assignedProjectDTO.setMaintenanceDescription(project.getMaintenanceDescription());
    assignedProjectDTO.setNumber(project.getNumber());
    assignedProjectDTO.setRejected(project.getRejected());
    assignedProjectDTO.setRetired(project.getRetired());
    assignedProjectDTO.setRevisionLevel(project.getRevisionLevel());
    assignedProjectDTO.setStarted(project.getStarted());
    assignedProjectDTO.setSubmitted(project.getSubmitted());
    assignedProjectDTO.setTitle(project.getTitle());

    return assignedProjectDTO;
  }
}
