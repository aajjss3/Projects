package com.seatec.ela.app.aop.userevent;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.controller.AircraftController;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Test;

public class LogConfigTest {

  // CONCERN_LIST is all of the currently supported concern values
  final String[] CONCERN_LIST = {
    "Aircraft",
    "Aircraft Cloak",
    "AircraftChangeGroup",
    "Change",
    "ChangeGroup",
    "ChangeGroup Effectivity",
    "ChangeGroup Node Component",
    "ChangeGroup Parent Fleet",
    "Ela",
    "Ela Node",
    "Fleet",
    "MyProject",
    "Project",
    "Pending Review Project",
    "Project Workflow",
    "Project Reject",
    "Project Coauthor",
    "Approved Project",
    "Role",
    "Role User",
    "User"
  };

  @Test
  public void result_found_findMatchingConfig() {
    String testClass = "AircraftController";
    String testMethod = "findAircraft";
    AircraftController mockController = new AircraftController();
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(mockController);
    when(joinPoint.getSignature()).thenReturn(signature);
    when(signature.getName()).thenReturn(testMethod);
    LogUserTrackConfig result = LogConfig.findMatchingConfig(joinPoint);
    assertEquals(
        "UserTrackConfig found with matching Class Name", testClass, result.getSourceClass());
    assertEquals(
        "userTrackConfig found with matching Method Name", testMethod, result.getSourceMethod());
  }

  @Test
  public void confirm_no_unexpected_nulls() {
    for (LogUserTrackConfig entry : LogConfig.LOG_USER_TRACK_CONFIGS) {
      assertNotNull(entry.getSourceClass());
      assertNotNull(entry.getSourceMethod());
      assertNotNull(entry.getActionString());
      assertNotNull(entry.getConcern());
    }
  }

  @Test
  public void matches_expected_distinct_concern_names() {
    Set<String> concern_names = new TreeSet();
    for (LogUserTrackConfig entry : LogConfig.LOG_USER_TRACK_CONFIGS) {
      concern_names.add(entry.getConcern());
    }
    String[] result = concern_names.toArray(new String[0]);
    List<String> resultList = new ArrayList(Arrays.asList(result));
    List<String> concernList = Arrays.asList(CONCERN_LIST);
    boolean foundConcern = resultList.removeAll(concernList);
    assertTrue("UserTrackConfig did not contain anything on the CONCERN_LIST", foundConcern);
    assertEquals(
        "UserTrackConfig concern in LogConfig should be defined in CONCERN LIST",
        "",
        String.join(",", resultList));
  }

  @Test
  public void confirm_class_method_values() {
    for (LogUserTrackConfig entry : LogConfig.LOG_USER_TRACK_CONFIGS) {
      String className = entry.getSourceClass();
      String classMethod = entry.getSourceMethod();
      boolean result =
          foundClassAndMethod("com.seatec.ela.app.controller." + className, classMethod)
              || foundClassAndMethod(
                  "com.seatec.ela.app.controller.keycloak." + className, classMethod)
              || foundClassAndMethod(
                  "com.seatec.ela.app.controller.project." + className, classMethod)
              || foundClassAndMethod("com.seatec.ela.app." + className, classMethod);
      assertTrue("Class/Method not found " + className + ":" + classMethod, result);
    }
  }

  private boolean foundClassAndMethod(String fullPackageName, String classMethod) {
    try {
      Class<?> result = Class.forName(fullPackageName);
      Method[] junk = result.getMethods();
      for (Method method : result.getMethods()) {
        if (classMethod.equals(method.getName())) {
          return true;
        }
      }
      return false;
    } catch (Exception ex) {
      return false;
    }
  }
}
