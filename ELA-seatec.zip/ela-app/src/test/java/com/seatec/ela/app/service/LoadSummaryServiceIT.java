package com.seatec.ela.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.controller.AbstractControllerIntegrationTest;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3324.sql",
        "/datasets/node-3324.sql",
        "/datasets/component-3324.sql",
        "/datasets/load-3324.sql"
      }),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class LoadSummaryServiceIT extends AbstractControllerIntegrationTest {

  private static Logger LOGGER = LoggerFactory.getLogger(LoadSummaryServiceIT.class);

  @Autowired private NodeService nodeService;

  @Autowired private EfficiencyTableService efficiencyTableService;

  private long elaId = 4012L;

  private LoadSummaryRequest loadSummaryRequest;

  @Before
  public void setUp() {
    Map<UUID, EfficiencyTable> efficiencyTableMap = efficiencyTableService.findAllAsMap();

    LoadSummaryOptions loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, false);

    loadSummaryRequest = new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);
  }

  @Test
  public void node_401XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248939L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertNominalPower(result, 424, ElectricalPhase.ACA);
    assertNominalPower(result, 703.8, ElectricalPhase.ACB);
    assertNominalPower(result, 1965.7, ElectricalPhase.ACC);

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4,
          118.4, 118.4, 118.4, 118.4, 118.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          76.0, 76.0, 76.0, 83.2, 83.2, 83.2, 83.2, 76.0, 76.0, 76.0, 76.0, 76.0, 83.2, 83.2, 83.2,
          83.2, 76.0, 76.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          453.4, 1320.1, 1320.1, 1320.1, 653.4, 653.4, 653.4, 1320.1, 653.4, 453.4, 1320.1, 1320.1,
          1320.1, 653.4, 653.4, 653.4, 1320.1, 653.4
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4, 118.4,
          118.4, 118.4, 118.4, 118.4, 118.4
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          66.2, 66.2, 66.2, 73.4, 73.4, 73.4, 73.4, 66.2, 66.2, 66.2, 66.2, 66.2, 73.4, 73.4, 73.4,
          73.4, 66.2, 66.2
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          343.0, 1209.7, 1209.7, 1209.7, 543.0, 543.0, 543.0, 1209.7, 543.0, 343.0, 1209.7, 1209.7,
          1209.7, 543.0, 543.0, 543.0, 1209.7, 543.0
        });
  }

  @Test
  public void node_4XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248938L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          0.0, 2622.2, 2576.0, 3732.0, 3732.0, 3732.0, 3732.0, 3732.0, 2576.0, 118.4, 2740.6,
          2694.4, 3850.4, 3850.4, 3850.4, 3850.4, 3850.4, 2694.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          0.0, 2622.2, 2576.0, 3732.0, 3732.0, 3732.0, 3732.0, 3732.0, 2576.0, 76.0, 2698.2, 2652.0,
          3815.2, 3815.2, 3815.2, 3815.2, 3808.0, 2652.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          0.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 453.4, 2740.1,
          2740.1, 2740.1, 2073.4, 2073.4, 2073.4, 2740.1, 2073.4
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          0.0, 2460.4, 2460.4, 3500.8, 3038.4, 3038.4, 3038.4, 3500.8, 2460.4, 118.4, 2578.8,
          2578.8, 3619.2, 3156.8, 3156.8, 3156.8, 3619.2, 2578.8
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          0.0, 2460.4, 2460.4, 3500.8, 3038.4, 3038.4, 3038.4, 3500.8, 2460.4, 66.2, 2526.6, 2526.6,
          3574.2, 3111.8, 3111.8, 3111.8, 3567.0, 2526.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          0.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 1420.0, 343.0, 2629.7,
          2629.7, 2629.7, 1963.0, 1963.0, 1963.0, 2629.7, 1963.0
        });
  }

  @Test
  public void node_1XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248930L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          12078.5, 12078.5, 12078.5, 12078.5, 12078.5, 12078.5, 12078.5, 12078.5, 12078.5, 28214.1,
          31551.2, 31505.0, 31205.3, 31154.5, 31154.5, 31248.6, 31418.7, 30079.1
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 26794.3,
          29652.5, 29606.3, 29012.9, 29017.3, 29017.3, 29111.4, 30279.3, 28180.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 10333.5, 27470.4,
          33623.4, 32830.0, 30660.4, 30144.2, 30144.2, 30238.4, 32001.2, 30737.4
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          6628.3, 6628.3, 6628.3, 6628.3, 11555.8, 11131.1, 6268.9, 6628.3, 6628.3, 17993.1,
          21610.3, 21610.3, 21085.1, 25787.4, 25074.7, 20594.6, 21298.5, 20121.5
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          5930.3, 5930.3, 5930.3, 5930.3, 9810.8, 9386.1, 5570.9, 5930.3, 5930.3, 18310.0, 21759.5,
          21759.5, 20931.6, 24419.7, 23995.0, 20273.9, 22263.5, 20333.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          5930.3, 5930.3, 5930.3, 5930.3, 9810.8, 9386.1, 5570.9, 5930.3, 5930.3, 18173.5, 23819.5,
          23694.2, 21279.2, 24479.4, 24054.7, 20333.7, 22539.4, 21601.7
        });
  }

  @Test
  public void node_101XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248931L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          966.6, 1740.6, 1740.6, 792.6, 792.6, 792.6, 792.6, 1030.6, 1030.6, 966.6, 1740.6, 1740.6,
          792.6, 792.6, 792.6, 792.6, 1030.6, 1030.6
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          928.0, 1702.0, 1702.0, 439.0, 439.0, 439.0, 439.0, 992.0, 992.0, 928.0, 1702.0, 1702.0,
          439.0, 439.0, 439.0, 439.0, 992.0, 992.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          569.3, 3431.3, 2637.9, 1374.9, 1521.0, 1521.0, 1521.0, 2074.0, 1927.9, 569.3, 3431.3,
          2637.9, 1374.9, 1521.0, 1521.0, 1521.0, 2074.0, 1927.9
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          678.6, 1452.6, 1452.6, 504.6, 792.6, 504.6, 792.6, 742.6, 742.6, 678.6, 1452.6, 1452.6,
          504.6, 792.6, 504.6, 792.6, 742.6, 742.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          832.1, 1606.1, 1606.1, 343.1, 343.1, 343.1, 343.1, 896.1, 896.1, 832.1, 1606.1, 1606.1,
          343.1, 343.1, 343.1, 343.1, 896.1, 896.1
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          569.3, 2596.1, 2470.8, 1207.8, 1124.3, 1124.3, 1124.3, 1760.8, 1760.8, 569.3, 2596.1,
          2470.8, 1207.8, 1124.3, 1124.3, 1124.3, 1760.8, 1760.8
        });
  }

  @Test
  public void node_103XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248932L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0, 425.0,
          425.0, 425.0, 425.0, 425.0, 425.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          126.5, 207.8, 207.8, 207.8, 207.8, 207.8, 207.8, 897.8, 207.8, 126.5, 207.8, 207.8, 207.8,
          207.8, 207.8, 207.8, 897.8, 207.8
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          170.0, 781.1, 781.1, 170.0, 170.0, 170.0, 170.0, 781.1, 781.1, 170.0, 781.1, 781.1, 170.0,
          170.0, 170.0, 170.0, 781.1, 781.1
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0, 119.0,
          119.0, 119.0, 119.0, 119.0, 119.0
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          126.5, 207.8, 207.8, 207.8, 207.8, 207.8, 207.8, 897.8, 207.8, 126.5, 207.8, 207.8, 207.8,
          207.8, 207.8, 207.8, 897.8, 207.8
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          170.0, 781.1, 781.1, 170.0, 170.0, 170.0, 170.0, 781.1, 781.1, 170.0, 781.1, 781.1, 170.0,
          170.0, 170.0, 170.0, 781.1, 781.1
        });
  }

  @Test
  public void node_105XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248933L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          1283.9, 1993.9, 1993.9, 1283.9, 1283.9, 1283.9, 1283.9, 1283.9, 1283.9, 1283.9, 1993.9,
          1993.9, 1283.9, 1283.9, 1283.9, 1283.9, 1283.9, 1283.9
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          1036.1, 2035.9, 2035.9, 1325.9, 1381.1, 1381.1, 1381.1, 1381.1, 1325.9, 1036.1, 2035.9,
          2035.9, 1325.9, 1381.1, 1381.1, 1381.1, 1381.1, 1325.9
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          986.0, 1696.0, 1696.0, 986.0, 986.0, 986.0, 986.0, 986.0, 986.0, 986.0, 1696.0, 1696.0,
          986.0, 986.0, 986.0, 986.0, 986.0, 986.0
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          977.9, 1687.9, 1687.9, 977.9, 977.9, 977.9, 977.9, 977.9, 977.9, 977.9, 1687.9, 1687.9,
          977.9, 977.9, 977.9, 977.9, 977.9, 977.9
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          996.1, 1882.1, 1882.1, 1172.1, 1292.8, 1292.8, 1292.8, 1292.8, 1172.1, 996.1, 1882.1,
          1882.1, 1172.1, 1292.8, 1292.8, 1292.8, 1292.8, 1172.1
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          981.0, 1691.0, 1691.0, 981.0, 981.0, 981.0, 981.0, 981.0, 981.0, 981.0, 1691.0, 1691.0,
          981.0, 981.0, 981.0, 981.0, 981.0, 981.0
        });
  }

  @Test
  public void node_113XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248936L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          2151.0, 1301.0, 1301.0, 1473.3, 1473.3, 1473.3, 1473.3, 1473.3, 1301.0, 2151.0, 1301.0,
          1301.0, 1473.3, 1473.3, 1473.3, 1473.3, 1473.3, 1301.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          2893.9, 1193.9, 1193.9, 1380.3, 1380.3, 1380.3, 1380.3, 1380.3, 1193.9, 2893.9, 1193.9,
          1193.9, 1380.3, 1380.3, 1380.3, 1380.3, 1380.3, 1193.9
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          3611.5, 2761.5, 2761.5, 3146.0, 3146.0, 3146.0, 3146.0, 3146.0, 2761.5, 3611.5, 2761.5,
          2761.5, 3146.0, 3146.0, 3146.0, 3146.0, 3146.0, 2761.5
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          1274.5, 849.5, 849.5, 911.8, 911.8, 911.8, 911.8, 911.8, 786.6, 1274.5, 849.5, 849.5,
          911.8, 911.8, 911.8, 911.8, 911.8, 786.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          1630.2, 780.2, 780.2, 847.6, 847.6, 847.6, 847.6, 847.6, 780.2, 1630.2, 780.2, 780.2,
          847.6, 847.6, 847.6, 847.6, 847.6, 780.2
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          1656.1, 1231.1, 1231.1, 1370.2, 1370.2, 1370.2, 1370.2, 1370.2, 1231.1, 1656.1, 1231.1,
          1231.1, 1370.2, 1370.2, 1370.2, 1370.2, 1370.2, 1231.1
        });
  }

  @Test
  public void node_115XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248937L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0,
          4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0, 4785.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4,
          4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4, 4951.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6,
          5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6, 5076.6
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6,
          1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6, 1864.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9,
          2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9, 2312.9
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8,
          2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8, 2270.8
        });
  }

  @Test
  public void node_107XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248934L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        new double[] {
          4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0,
          4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        new double[] {
          4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0,
          4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        new double[] {
          4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0,
          4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        new double[] {
          4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0,
          4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0, 4918.0
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        new double[] {
          4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0,
          4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0, 4873.0
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        new double[] {
          4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0,
          4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0, 4878.0
        });
  }

  @Test
  public void node_9XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248940L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6});
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {361.9, 361.9, 361.9, 361.9, 361.9, 361.9, 361.9, 361.9, 361.9});
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {178.0, 630.4, 630.4, 630.4, 685.6, 685.6, 685.6, 685.6, 630.4});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6});
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {345.7, 345.7, 345.7, 345.7, 345.7, 345.7, 345.7, 345.7, 345.7});
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {178.0, 516.6, 516.6, 516.6, 637.3, 637.3, 637.3, 637.3, 516.6});
  }

  @Test
  public void node_901XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248941L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS,
        new double[] {248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6, 248.6});
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS,
        new double[] {170.0, 170.0, 170.0, 170.0, 170.0, 170.0, 170.0, 170.0, 170.0});
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS,
        new double[] {178.0, 630.4, 630.4, 630.4, 685.6, 685.6, 685.6, 685.6, 630.4});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS,
        new double[] {208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6, 208.6});
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS,
        new double[] {153.9, 153.9, 153.9, 153.9, 153.9, 153.9, 153.9, 153.9, 153.9});
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS,
        new double[] {178.0, 516.6, 516.6, 516.6, 637.3, 637.3, 637.3, 637.3, 516.6});
  }

  @Test
  public void node_905XP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248943L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS,
        new double[] {175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS,
        new double[] {175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0, 175.0});
  }

  @Test
  public void node_1IWXP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248929L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertNominalPower(result, 238, ElectricalPhase.ACA);
    assertNominalPower(result, 230, ElectricalPhase.ACB);
    assertNominalPower(result, 230, ElectricalPhase.ACC);
  }

  @Test
  public void node_AXFMR_ESS_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248944L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9, 16.9});
  }

  @Test
  public void node_AXFMR_1_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248946L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2, 8.2});
  }

  @Test
  public void node_TR_1_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248948L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    double[] maxi =
        new double[] {
          1895.7 / 3,
          2187.6 / 3,
          2187.6 / 3,
          2188.3 / 3,
          1905.9 / 3,
          1905.9 / 3,
          2188.3 / 3,
          2172.6 / 3,
          2173.3 / 3
        };
    double[] operational =
        new double[] {
          1439.8 / 3,
          1713.5 / 3,
          1713.5 / 3,
          1706.3 / 3,
          1442.2 / 3,
          1442.2 / 3,
          1706.3 / 3,
          1698.5 / 3,
          1699.2 / 3
        };

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);
  }

  @Test
  public void node_TR_ESS_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248956L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    double[] maxi =
        new double[] {
          1746.4 / 3,
          1697.1 / 3,
          1697.1 / 3,
          1786.5 / 3,
          1916.4 / 3,
          1916.4 / 3,
          1916.4 / 3,
          1728.3 / 3,
          1693.7 / 3
        };
    double[] operational =
        new double[] {
          1746.4 / 3,
          1697.1 / 3,
          1697.1 / 3,
          1786.5 / 3,
          1916.4 / 3,
          1916.4 / 3,
          1916.4 / 3,
          1728.3 / 3,
          1693.7 / 3
        };

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);

    assertLoadPhase(result, "MAXI", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, maxi);

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        operational);
  }

  @Test
  public void node_1PP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248949L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {1691.7, 1952.2, 1952.2, 1952.8, 1700.8, 1700.8, 1952.8, 1938.8, 1939.4});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {1268.6, 1529.1, 1529.1, 1522.7, 1270.7, 1270.7, 1522.7, 1515.7, 1516.3});
  }

  @Test
  public void node_101PP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248950L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {460.2, 764.9, 764.9, 764.9, 512.9, 512.9, 764.9, 764.9, 764.9});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {434.4, 739.1, 739.1, 739.1, 487.1, 487.1, 739.1, 739.1, 739.1});
  }

  @Test
  public void node_103PP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248951L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {632.9, 639.3, 639.3, 646.9, 646.9, 646.9, 646.9, 632.9, 632.9});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {396.6, 403.0, 403.0, 403.6, 403.6, 403.6, 403.6, 396.6, 396.6});
  }

  @Test
  public void node_105PP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248952L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {387.4, 362.8, 362.8, 355.8, 355.8, 355.8, 355.8, 355.8, 356.4});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS,
        new double[] {230.1, 205.5, 205.5, 198.5, 198.5, 198.5, 198.5, 198.5, 199.1});
  }

  @Test
  public void node_3PP_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248953L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {211.2, 185.2, 185.2, 185.2, 185.2, 185.2, 185.2, 185.2, 185.2});

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.DC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {207.5, 181.5, 181.5, 181.5, 181.5, 181.5, 181.5, 181.5, 181.5});
  }

  @Test
  public void node_GEN1_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248928L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          28197.2, 31534.3, 31488.1, 31188.4, 31137.6, 31137.6, 31231.7, 31401.8, 30062.2
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          26794.3, 29652.5, 29606.3, 29012.9, 29017.3, 29017.3, 29111.4, 30279.3, 28180.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          27470.4, 33623.4, 32830.0, 30660.4, 30144.2, 30144.2, 30238.4, 32001.2, 30737.4
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          17841.1, 21437.4, 21437.4, 20907.3, 25617.1, 24904.4, 20418.2, 21125.5, 19948.5
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          18158.1, 21586.6, 21586.6, 20753.8, 24249.3, 23824.6, 20097.5, 22090.6, 20160.7
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          18021.6, 23646.5, 23521.2, 21101.4, 24309.1, 23884.4, 20157.3, 22366.5, 21428.6
        });
  }

  @Test
  public void node_GEN2_should_summarize_correctly() {

    Optional<Node> nodeMaybe = nodeService.findById(248967L, elaId, loadSummaryRequest);
    assertTrue(nodeMaybe.isPresent());
    Node node = nodeMaybe.get();

    List<SummarizedLoad> result = node.getSummarizedLoads();

    assertNotNull("result should not be null", result);
    assertFalse("result should not be empty", result.isEmpty());

    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          30605.7, 32452.7, 32060.6, 33681.1, 33400.7, 33500.8, 32468.6, 33351.6, 32060.6
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          28422.3, 30492.6, 30100.4, 31467.9, 31827.5, 32013.1, 31192.9, 32150.6, 30100.4
        });
    assertLoadPhase(
        result,
        "MAXI",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          29178.1, 32450.4, 31311.1, 31020.0, 30914.2, 31099.8, 30279.6, 31825.1, 30644.4
        });

    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACA,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          20771.4, 23172.5, 22826.6, 24224.0, 29404.8, 29377.8, 22388.9, 23899.9, 22826.6
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACB,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          19666.2, 22390.2, 22044.3, 23144.5, 29148.0, 28621.0, 22237.4, 23832.6, 22044.3
        });
    assertLoadPhase(
        result,
        "OPERATIONAL",
        ElectricalPhase.ACC,
        SummaryType.COMPONENTS_AND_CHILDREN,
        new double[] {
          20104.3, 23003.5, 22532.4, 22020.3, 27600.2, 28573.2, 21658.1, 22750.3, 21865.7
        });
  }

  private void assertLoadPhase(
      List<SummarizedLoad> result,
      String operatingMode,
      ElectricalPhase electricalPhase,
      SummaryType summaryType,
      double[] vals) {
    assertEquals("vals should be length of 9", vals.length, 9);
    assertLoadValue(result, operatingMode, "GROUND", electricalPhase, summaryType, vals[0]);
    assertLoadValue(result, operatingMode, "START", electricalPhase, summaryType, vals[1]);
    assertLoadValue(result, operatingMode, "ROLL", electricalPhase, summaryType, vals[2]);
    assertLoadValue(result, operatingMode, "TOFF", electricalPhase, summaryType, vals[3]);
    assertLoadValue(result, operatingMode, "CLIMB", electricalPhase, summaryType, vals[4]);
    assertLoadValue(result, operatingMode, "CRUISE", electricalPhase, summaryType, vals[5]);
    assertLoadValue(result, operatingMode, "DESCENT", electricalPhase, summaryType, vals[6]);
    assertLoadValue(result, operatingMode, "LANDING", electricalPhase, summaryType, vals[7]);
    assertLoadValue(result, operatingMode, "TAXI", electricalPhase, summaryType, vals[8]);
  }

  private void assertLoadPhase(
      List<SummarizedLoad> result,
      String operatingMode,
      ElectricalPhase electricalPhase,
      double[] vals) {
    assertEquals("vals should be length of 18", vals.length, 18);
    assertLoadValue(
        result, operatingMode, "GROUND", electricalPhase, SummaryType.COMPONENTS, vals[0]);
    assertLoadValue(
        result, operatingMode, "START", electricalPhase, SummaryType.COMPONENTS, vals[1]);
    assertLoadValue(
        result, operatingMode, "ROLL", electricalPhase, SummaryType.COMPONENTS, vals[2]);
    assertLoadValue(
        result, operatingMode, "TOFF", electricalPhase, SummaryType.COMPONENTS, vals[3]);
    assertLoadValue(
        result, operatingMode, "CLIMB", electricalPhase, SummaryType.COMPONENTS, vals[4]);
    assertLoadValue(
        result, operatingMode, "CRUISE", electricalPhase, SummaryType.COMPONENTS, vals[5]);
    assertLoadValue(
        result, operatingMode, "DESCENT", electricalPhase, SummaryType.COMPONENTS, vals[6]);
    assertLoadValue(
        result, operatingMode, "LANDING", electricalPhase, SummaryType.COMPONENTS, vals[7]);
    assertLoadValue(
        result, operatingMode, "TAXI", electricalPhase, SummaryType.COMPONENTS, vals[8]);

    assertLoadValue(
        result,
        operatingMode,
        "GROUND",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[9]);
    assertLoadValue(
        result,
        operatingMode,
        "START",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[10]);
    assertLoadValue(
        result,
        operatingMode,
        "ROLL",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[11]);
    assertLoadValue(
        result,
        operatingMode,
        "TOFF",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[12]);
    assertLoadValue(
        result,
        operatingMode,
        "CLIMB",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[13]);
    assertLoadValue(
        result,
        operatingMode,
        "CRUISE",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[14]);
    assertLoadValue(
        result,
        operatingMode,
        "DESCENT",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[15]);
    assertLoadValue(
        result,
        operatingMode,
        "LANDING",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[16]);
    assertLoadValue(
        result,
        operatingMode,
        "TAXI",
        electricalPhase,
        SummaryType.COMPONENTS_AND_CHILDREN,
        vals[17]);
  }

  private void assertLoadValue(
      List<SummarizedLoad> result,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType type,
      double value) {
    Optional<SummarizedLoad> matchingLoad =
        result.stream()
            .filter(
                l ->
                    (l.getFlightPhase().equals("NominalPower")
                            || l.getFlightPhase().equals("ConnectedLoad")
                            || l.getOperatingMode().equals(operatingMode))
                        && l.getFlightPhase().equals(flightPhase)
                        && l.getSummaryType().equals(type)
                        && l.getElectricalPhase().equals(electricalPhase))
            .findAny();
    assertTrue(
        String.format(
            "load for %s %s %s %s should be present",
            operatingMode, flightPhase, electricalPhase, type),
        matchingLoad.isPresent());

    double diff = Math.abs(value - matchingLoad.get().getW());
    if (diff > 0) {
      int percent = (int) (diff / value * 100);
      LOGGER.warn(
          "diff for load {} {} {} {} is {} % different ({} {})",
          operatingMode,
          flightPhase,
          electricalPhase,
          type,
          percent,
          value,
          matchingLoad.get().getW());

      assertTrue(
          String.format(
              "diff for load %s %s %s %s should be less than 2 percent different (%f %f) %d%% different",
              operatingMode,
              flightPhase,
              electricalPhase,
              type,
              value,
              matchingLoad.get().getW(),
              percent),
          (percent <= 2));
    }
  }

  private void assertNominalPower(
      List<SummarizedLoad> result, double value, ElectricalPhase electricalPhase) {
    Optional<SummarizedLoad> matchingLoad =
        result.stream()
            .filter(
                l ->
                    l.getFlightPhase().equals("NominalPower")
                        && l.getElectricalPhase().equals(electricalPhase))
            .findAny();
    assertTrue("nominal power summary should exist", matchingLoad.isPresent());
    assertEquals(
        "Nominal Power should equal expected value for " + electricalPhase,
        value,
        matchingLoad.get().getW(),
        0.05);
  }
}
