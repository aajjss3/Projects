package com.seatec.ela.app.util.regexp;

import static org.junit.Assert.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.Test;

public class ValidationRegExpTest {
  final String[] trimCharsNumsDashUnderscoreSpaceMatches = {
    "This is a test",
    "atest",
    "a-test-",
    "a_test_",
    "aaaaaaaaaaaaa",
    "a b c d e f",
    "23232abcd",
    "1 2 3 a b c-_",
    "McDonnell Douglas",
    "A330-Node-Structure"
  };

  final String[] trimCharsNumsDashUnderscoreSpaceNoMatches = {
    "tab after\t",
    "space after ",
    " space before",
    "\ttab before",
    "!bang",
    "@atsymbol",
    "#pound",
    "$dollar",
    "%percent",
    "^uparrow",
    "&andsymbol",
    "*star",
    "(leftparenth",
    ")rightparenth",
    "+plus",
    "~tilde",
    "tch`tick",
    "plus+",
    "plus+\r\n",
    "plus+\n",
    "tilde~tilde"
  };

  @Test
  public void shouldMatchTrimCharsNumsDashUnderscoeSpace() throws Exception {
    String regex = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE;
    String[] testPatterns = trimCharsNumsDashUnderscoreSpaceMatches;
    int matchCount = patternMatchCount(regex, testPatterns);
    assertEquals(testPatterns.length, matchCount);
  }

  @Test
  public void shouldNotMatchTrimCharsNumsDashUnderscoeSpace() throws Exception {
    String regex = ValidationRegExp.TRIMMED_CHARS_NUMS_DASH_UNDERSCORE_SPACE;
    String[] testPatterns = trimCharsNumsDashUnderscoreSpaceNoMatches;
    int matchCount = patternMatchCount(regex, testPatterns);
    assertEquals(0, matchCount);
  }

  private int patternMatchCount(String regex, String[] testPatterns) {
    int matchCount = 0;
    final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
    for (String testPattern : testPatterns) {
      Matcher matcher = pattern.matcher(testPattern);
      if (matcher.find()) {
        matchCount++;
      }
    }
    return matchCount;
  }
}
