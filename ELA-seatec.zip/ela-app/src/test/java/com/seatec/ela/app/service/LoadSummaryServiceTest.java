package com.seatec.ela.app.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.exception.InternalServerErrorException;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.LoadSummaryOptions;
import com.seatec.ela.app.model.LoadSummaryRequest;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.SummarizedLoad;
import com.seatec.ela.app.model.SummaryType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.Before;
import org.junit.Test;

public class LoadSummaryServiceTest {

  private LoadSummaryService subject;
  private EfficiencyTable mockEfficiencyTable = new EfficiencyTable();
  private Map<UUID, EfficiencyTable> efficiencyTableMap;
  private LoadSummaryOptions loadSummaryOptions;

  @Before
  public void setup() {
    UUID efficiencyTableId = UUID.randomUUID();
    mockEfficiencyTable.setId(efficiencyTableId);

    mockEfficiencyTable.setLoads(Arrays.asList(new EfficiencyLoad(5d, 5d, 1d, .5, .5)));

    efficiencyTableMap = new HashMap<>();
    efficiencyTableMap.put(efficiencyTableId, mockEfficiencyTable);

    loadSummaryOptions = new LoadSummaryOptions(true, true, true, true, false);

    subject = new LoadSummaryService();
  }

  @Test
  public void summarizeNodeLoadValues_bus_with_no_children_should_sum_loads() {
    Node node = dcBusWithNoSubNodes();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 3.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 6.0);
  }

  @Test
  public void summarizeNodeLoadValues_bus_with_one_child_should_sum_loads_recursively() {
    Node node = dcBusWithNoSubNodes();
    node.getSubNodes().add(dcBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 6.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 12.0);
  }

  @Test
  public void summarizeNodeLoadValues_bus_with_many_children_should_sum_loads_recursively() {
    Node node = dcBusManyChildren();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 15.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.DC, SummaryType.COMPONENTS_AND_CHILDREN, 30.0);
  }

  @Test
  public void
      summarizeNodeLoadValues_tr_with_many_children_should_sum_loads_recursively_and_transform() {
    Node node = truNode();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 10);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 20.0);
  }

  @Test
  public void summarizeNodeLoadValues_single_phase_ac_bus_with_no_children_should_sum_loads() {
    Node node = singleACBusWithNoSubNodes();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 3.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 6.0);
  }

  @Test
  public void
      summarizeNodeLoadValues_single_phase_ac_bus_with_one_child_should_sum_loads_recursively() {
    Node node = singleACBusWithNoSubNodes();
    node.getSubNodes().add(singleACBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 6.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 12.0);
  }

  @Test
  public void
      summarizeNodeLoadValues_atu_with_many_children_should_sum_loads_recursively_and_transform() {
    Node node = atuNode();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 30);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 60.0);
  }

  @Test
  public void summarizeNodeLoadValues_three_phase_ac_bus_with_no_children_should_sum_loads() {
    Node node = threeACBusWithNoSubNodes();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);
    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 7.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 9.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 7.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 9.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 7.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 9.0);
  }

  @Test
  public void
      summarizeNodeLoadValues_three_phase_ac_bus_with_one_child_should_sum_loads_recursively() {
    Node node = threeACBusWithNoSubNodes();
    node.getSubNodes().add(threeACBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 14.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 18.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 14.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 18.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 14.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 18.0);
  }

  @Test
  public void
      summarizeNodeLoadValues_three_phase_ac_bus_with_many_children_should_sum_loads_recursively() {
    Node node = threePhaseACBusManyChildren();

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);

    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 35.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 45.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 35.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACB, SummaryType.COMPONENTS_AND_CHILDREN, 45.0);
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS, 7.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS, 9.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 35.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACC, SummaryType.COMPONENTS_AND_CHILDREN, 45.0);
  }

  @Test
  public void summarizedNodeLoadValues_ac_bus_with_tr_child_should_sum_loads_recursively() {
    Node node = singleACBusWithNoSubNodes();
    node.getSubNodes().add(truNode());
    node.getSubNodes().forEach(c -> c.setParentNode(node));

    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    List<SummarizedLoad> result = subject.retrieveLoadSummaries(node, loadSummaryRequest);
    assertNotNull("summarized loads values should not be null", result);
    assertFalse("summarized load values should not be empty", result.isEmpty());
    assertLoadValue(result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS, 3.0);
    assertLoadValue(result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS, 6.0);
    assertLoadValue(
        result, "MAXI", "Ground", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 13.0);
    assertLoadValue(
        result, "MAXI", "Taxi", ElectricalPhase.ACA, SummaryType.COMPONENTS_AND_CHILDREN, 26.0);
  }

  @Test(expected = NullPointerException.class)
  public void testRetrieveLoadSummaries_node_null() {
    LoadSummaryRequest loadSummaryRequest =
        new LoadSummaryRequest(efficiencyTableMap, loadSummaryOptions);

    subject.retrieveLoadSummaries(null, loadSummaryRequest);
  }

  @Test(expected = InternalServerErrorException.class)
  public void testRetrieveAdjustedTransformerLoadEfficiencyPowerFactor_table_not_found() {
    String nodeIdentifier = "2369719460180604208";
    NodeType nodeType = NodeType.TRU;
    // value is active power for TRU
    Double activePower = 1960d;
    UUID efficiencyTableId = UUID.randomUUID();

    EfficiencyTable efficiencyTableTRU = getEfficiencyTableTRU();
    EfficiencyTable efficiencyTableATU = getEfficiencyTableATU();

    efficiencyTableMap =
        Stream.of(efficiencyTableTRU, efficiencyTableATU)
            .collect(Collectors.toMap(EfficiencyTable::getId, Function.identity()));

    subject.retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
        nodeIdentifier, nodeType, activePower, efficiencyTableId, efficiencyTableMap);
  }

  @Test
  public void testRetrieveAdjustedTransformerLoadEfficiencyPowerFactor_TRU() {
    String nodeIdentifier = "2369719460180604208";
    NodeType nodeType = NodeType.TRU;
    // value is active power for TRU
    Double activePower = 1960d;
    UUID efficiencyTableId = UUID.fromString("1f345933-72d8-432c-a30a-1e792386f2cb");

    EfficiencyLoad expectedEfficiencyLoad =
        new EfficiencyLoad(
            70d, 1960d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);

    EfficiencyTable efficiencyTableTRU = getEfficiencyTableTRU();
    EfficiencyTable efficiencyTableATU = getEfficiencyTableATU();

    efficiencyTableMap =
        Stream.of(efficiencyTableTRU, efficiencyTableATU)
            .collect(Collectors.toMap(EfficiencyTable::getId, Function.identity()));

    EfficiencyLoad actualEfficiencyLoad =
        subject.retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
            nodeIdentifier, nodeType, activePower, efficiencyTableId, efficiencyTableMap);

    assertEquals(expectedEfficiencyLoad, actualEfficiencyLoad);
  }

  @Test
  public void testRetrieveAdjustedTransformerLoadEfficiencyPowerFactor_ATU() {
    String nodeIdentifier = "2369719460180604208";
    NodeType nodeType = NodeType.ATU;
    // value is current for ATU
    Double current = 15.0d;
    UUID efficiencyTableId = UUID.fromString("d4f01850-639e-4592-a860-dcb0419a6d42");

    EfficiencyLoad expectedEfficiencyLoad =
        new EfficiencyLoad(15, null, null, null, 0.810000000000000053d);

    EfficiencyTable efficiencyTableTRU = getEfficiencyTableTRU();
    EfficiencyTable efficiencyTableATU = getEfficiencyTableATU();

    efficiencyTableMap =
        Stream.of(efficiencyTableTRU, efficiencyTableATU)
            .collect(Collectors.toMap(EfficiencyTable::getId, Function.identity()));

    EfficiencyLoad actualEfficiencyLoad =
        subject.retrieveAdjustedTransformerLoadEfficiencyPowerFactor(
            nodeIdentifier, nodeType, current, efficiencyTableId, efficiencyTableMap);

    assertEquals(expectedEfficiencyLoad, actualEfficiencyLoad);
  }

  private Node atuNode() {
    Node node = new Node();
    node.setId(randomId());
    node.setNodeType(NodeType.ATU);
    node.getSubNodes().add(singleACBusWithManyChildren());
    node.getSubNodes().forEach(n -> n.setParentNode(node));
    node.setEfficiencyTable(mockEfficiencyTable);
    return node;
  }

  private Node truNode() {
    Node node = new Node();
    node.setId(randomId());
    node.setNodeType(NodeType.TRU);
    node.getSubNodes().add(dcBusManyChildren());
    node.getSubNodes().forEach(n -> n.setParentNode(node));
    node.setEfficiencyTable(mockEfficiencyTable);
    return node;
  }

  private Node singleACBusWithManyChildren() {
    Node node = singleACBusWithNoSubNodes();
    Node c1 = singleACBusWithNoSubNodes();
    c1.getSubNodes().add(singleACBusWithNoSubNodes());
    c1.getSubNodes().forEach(n -> n.setParentNode(c1));
    node.getSubNodes().add(c1);
    node.getSubNodes().add(singleACBusWithNoSubNodes());
    node.getSubNodes().add(singleACBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));
    return node;
  }

  private Node dcBusManyChildren() {
    Node node = dcBusWithNoSubNodes();
    Node c1 = dcBusWithNoSubNodes();
    c1.getSubNodes().add(dcBusWithNoSubNodes());
    c1.getSubNodes().forEach(n -> n.setParentNode(c1));
    node.getSubNodes().add(c1);
    node.getSubNodes().add(dcBusWithNoSubNodes());
    node.getSubNodes().add(dcBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));
    return node;
  }

  private Node threePhaseACBusManyChildren() {
    Node node = threeACBusWithNoSubNodes();
    Node c1 = threeACBusWithNoSubNodes();
    c1.getSubNodes().add(threeACBusWithNoSubNodes());
    c1.getSubNodes().forEach(n -> n.setParentNode(c1));
    node.getSubNodes().add(c1);
    node.getSubNodes().add(threeACBusWithNoSubNodes());
    node.getSubNodes().add(threeACBusWithNoSubNodes());
    node.getSubNodes().forEach(n -> n.setParentNode(node));
    return node;
  }

  private void assertLoadValue(
      List<SummarizedLoad> result,
      String operatingMode,
      String flightPhase,
      ElectricalPhase electricalPhase,
      SummaryType type,
      double value) {
    Optional<SummarizedLoad> matchingLoad =
        result.stream()
            .filter(
                l ->
                    (l.getFlightPhase().equals("NominalPower")
                            || l.getFlightPhase().equals("ConnectedLoad")
                            || l.getOperatingMode().equals(operatingMode))
                        && l.getFlightPhase().equals(flightPhase)
                        && l.getSummaryType().equals(type)
                        && l.getElectricalPhase().equals(electricalPhase))
            .findAny();
    assertTrue(
        String.format(
            "load for %s %s %s %s should be present",
            operatingMode, flightPhase, electricalPhase, type),
        matchingLoad.isPresent());
    assertEquals(
        String.format(
            "load for %s %s %s %s should equal %f",
            operatingMode, flightPhase, electricalPhase, type, value),
        value,
        matchingLoad.get().getW().doubleValue(),
        0.05);
  }

  private Node dcBusWithNoSubNodes() {
    Node node = new Node();
    node.setId(randomId());
    node.setNodeType(NodeType.BUS);
    addComponent(node, ElectricalPhase.DC, 10, 1, 2);
    addComponent(node, ElectricalPhase.DC, 10, 1, 2);
    addComponent(node, ElectricalPhase.DC, 10, 1, 2);
    return node;
  }

  private Node singleACBusWithNoSubNodes() {
    Node node = new Node();
    node.setId(randomId());
    node.setNodeType(NodeType.BUS);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    return node;
  }

  private Node threeACBusWithNoSubNodes() {
    Node node = new Node();
    node.setId(randomId());
    node.setNodeType(NodeType.BUS);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACA, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACB, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACB, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACB, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACC, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACC, 10, 1, 2);
    addComponent(node, ElectricalPhase.ACC, 10, 1, 2);
    addComponent(node, ElectricalPhase.AC3, 10, 4, 3);
    addComponent(node, ElectricalPhase.AC3, 10, 4, 3);
    addComponent(node, ElectricalPhase.AC3, 10, 4, 3);
    return node;
  }

  private Component addComponent(
      Node n, ElectricalPhase electricalPhase, double nominalPower, double load1, double load2) {
    Component c = new Component();
    c.setId(randomId());
    c.setName("test");
    c.setNode(n);
    c.setNominalPower(nominalPower);
    c.setElectricalPhase(electricalPhase);
    addLoad(c, "MAXI", "Ground", load1);
    addLoad(c, "MAXI", "Taxi", load2);
    n.getComponents().add(c);
    return c;
  }

  private Load addLoad(Component c, String operatingMode, String flightPhase) {
    return addLoad(c, operatingMode, flightPhase, null);
  }

  private Load addLoad(Component c, String operatingMode, String flightPhase, Double value) {
    Load l = new Load();
    l.setComponent(c);
    l.setOperatingMode(operatingMode);
    l.setFlightPhase(flightPhase);
    l.setId(randomId());
    l.setVa(value == null ? randomValue() : value);
    l.setPowerFactor(1d);
    c.getLoads().add(l);
    return l;
  }

  private Long randomId() {
    return new Random().nextLong();
  }

  private Double randomValue() {
    return new Random().nextDouble();
  }

  private EfficiencyTable getEfficiencyTableTRU() {

    EfficiencyLoad efficiencyLoad10 =
        new EfficiencyLoad(
            10d, 280d, 0.880000000000000004d, 0.630000000000000004d, 0.554400000000000004d);
    EfficiencyLoad efficiencyLoad20 =
        new EfficiencyLoad(
            20d, 560d, 0.910000000000000031d, 0.67000000000000004d, 0.60970000000000002d);
    EfficiencyLoad efficiencyLoad30 =
        new EfficiencyLoad(
            30d, 840d, 0.959999999999999964d, 0.910000000000000031d, 0.873600000000000043d);
    EfficiencyLoad efficiencyLoad40 =
        new EfficiencyLoad(
            40d, 1120d, 0.959999999999999964d, 0.910000000000000031d, 0.873600000000000043d);
    EfficiencyLoad efficiencyLoad50 =
        new EfficiencyLoad(
            50d, 1400d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad60 =
        new EfficiencyLoad(
            60d, 1680d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad70 =
        new EfficiencyLoad(
            70d, 1960d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad80 =
        new EfficiencyLoad(
            80d, 2240d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad90 =
        new EfficiencyLoad(
            90d, 2520d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad100 =
        new EfficiencyLoad(
            100d, 2800d, 0.969999999999999973d, 0.92000000000000004d, 0.892399999999999971d);
    EfficiencyLoad efficiencyLoad110 =
        new EfficiencyLoad(
            110d, 3080d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad120 =
        new EfficiencyLoad(
            120d, 3360d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad130 =
        new EfficiencyLoad(
            130d, 3640d, 0.979999999999999982d, 0.930000000000000049d, 0.911399999999999988d);
    EfficiencyLoad efficiencyLoad140 =
        new EfficiencyLoad(
            140d, 3920d, 0.979999999999999982d, 0.930000000000000049d, 0.911399999999999988d);
    EfficiencyLoad efficiencyLoad150 =
        new EfficiencyLoad(
            150d, 4200d, 0.979999999999999982d, 0.930000000000000049d, 0.911399999999999988d);
    EfficiencyLoad efficiencyLoad160 =
        new EfficiencyLoad(
            160d, 4480d, 0.979999999999999982d, 0.930000000000000049d, 0.911399999999999988d);
    EfficiencyLoad efficiencyLoad170 =
        new EfficiencyLoad(
            170d, 4760d, 0.979999999999999982d, 0.930000000000000049d, 0.911399999999999988d);
    EfficiencyLoad efficiencyLoad180 =
        new EfficiencyLoad(
            180d, 5040d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad190 =
        new EfficiencyLoad(
            190d, 5320d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad200 =
        new EfficiencyLoad(
            200d, 5600d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad210 =
        new EfficiencyLoad(
            210d, 5880d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);
    EfficiencyLoad efficiencyLoad220 =
        new EfficiencyLoad(
            220d, 6160d, 0.979999999999999982d, 0.92000000000000004d, 0.901599999999999957d);

    List<EfficiencyLoad> efficiencyLoads = new ArrayList<>();
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad10,
            efficiencyLoad20,
            efficiencyLoad30,
            efficiencyLoad40,
            efficiencyLoad50));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad60,
            efficiencyLoad70,
            efficiencyLoad80,
            efficiencyLoad90,
            efficiencyLoad100));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad110,
            efficiencyLoad120,
            efficiencyLoad130,
            efficiencyLoad140,
            efficiencyLoad150));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad160,
            efficiencyLoad170,
            efficiencyLoad180,
            efficiencyLoad190,
            efficiencyLoad200));
    efficiencyLoads.addAll(Arrays.asList(efficiencyLoad210, efficiencyLoad220));

    EfficiencyTable efficiencyTable = new EfficiencyTable();
    efficiencyTable.setId(UUID.fromString("1f345933-72d8-432c-a30a-1e792386f2cb"));
    efficiencyTable.setName("A330TRUTable");
    efficiencyTable.setVersion(1);
    efficiencyTable.setLoads(efficiencyLoads);

    return efficiencyTable;
  }

  private EfficiencyTable getEfficiencyTableATU() {
    EfficiencyLoad efficiencyLoad3 = new EfficiencyLoad(3, null, null, null, 0.489999999999999991d);
    EfficiencyLoad efficiencyLoad6 = new EfficiencyLoad(6, null, null, null, 0.609999999999999987d);
    EfficiencyLoad efficiencyLoad9 = new EfficiencyLoad(9, null, null, null, 0.709999999999999964d);
    EfficiencyLoad efficiencyLoad12 =
        new EfficiencyLoad(12, null, null, null, 0.770000000000000018d);
    EfficiencyLoad efficiencyLoad15 =
        new EfficiencyLoad(15, null, null, null, 0.810000000000000053d);
    EfficiencyLoad efficiencyLoad18 =
        new EfficiencyLoad(18, null, null, null, 0.82999999999999996d);
    EfficiencyLoad efficiencyLoad21 =
        new EfficiencyLoad(21, null, null, null, 0.849999999999999978d);
    EfficiencyLoad efficiencyLoad24 =
        new EfficiencyLoad(24, null, null, null, 0.869999999999999996d);
    EfficiencyLoad efficiencyLoad27 =
        new EfficiencyLoad(27, null, null, null, 0.890000000000000013d);
    EfficiencyLoad efficiencyLoad30 =
        new EfficiencyLoad(30, null, null, null, 0.900000000000000022d);
    EfficiencyLoad efficiencyLoad33 =
        new EfficiencyLoad(33, null, null, null, 0.910000000000000031d);
    EfficiencyLoad efficiencyLoad36 =
        new EfficiencyLoad(36, null, null, null, 0.910000000000000031d);
    EfficiencyLoad efficiencyLoad39 =
        new EfficiencyLoad(39, null, null, null, 0.92000000000000004d);
    EfficiencyLoad efficiencyLoad42 =
        new EfficiencyLoad(42, null, null, null, 0.92000000000000004d);
    EfficiencyLoad efficiencyLoad45 =
        new EfficiencyLoad(45, null, null, null, 0.92000000000000004d);
    EfficiencyLoad efficiencyLoad48 =
        new EfficiencyLoad(48, null, null, null, 0.930000000000000049d);
    EfficiencyLoad efficiencyLoad51 =
        new EfficiencyLoad(51, null, null, null, 0.930000000000000049d);
    EfficiencyLoad efficiencyLoad54 =
        new EfficiencyLoad(54, null, null, null, 0.930000000000000049d);
    EfficiencyLoad efficiencyLoad57 =
        new EfficiencyLoad(57, null, null, null, 0.930000000000000049d);
    EfficiencyLoad efficiencyLoad60 =
        new EfficiencyLoad(60, null, null, null, 0.930000000000000049d);

    List<EfficiencyLoad> efficiencyLoads = new ArrayList<>();
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad3, efficiencyLoad6, efficiencyLoad9, efficiencyLoad12, efficiencyLoad15));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad18,
            efficiencyLoad21,
            efficiencyLoad24,
            efficiencyLoad27,
            efficiencyLoad30));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad33,
            efficiencyLoad36,
            efficiencyLoad39,
            efficiencyLoad42,
            efficiencyLoad45));
    efficiencyLoads.addAll(
        Arrays.asList(
            efficiencyLoad48,
            efficiencyLoad51,
            efficiencyLoad54,
            efficiencyLoad57,
            efficiencyLoad60));

    EfficiencyTable efficiencyTable = new EfficiencyTable();
    efficiencyTable.setId(UUID.fromString("d4f01850-639e-4592-a860-dcb0419a6d42"));
    efficiencyTable.setName("A330ATUTable");
    efficiencyTable.setVersion(1);
    efficiencyTable.setLoads(efficiencyLoads);

    return efficiencyTable;
  }
}
