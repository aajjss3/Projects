package com.seatec.ela.app.controller;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.support.SimpleValueWrapper;
import org.springframework.context.ApplicationContext;

public class CacheControllerTest {

  private CacheController subject;
  private CacheManager mockCacheManager;
  private ApplicationContext mockApplicationContext;

  @Before
  public void setup() {
    mockCacheManager = mock(CacheManager.class);
    mockApplicationContext = mock(ApplicationContext.class);
    subject = new CacheController(mockCacheManager, mockApplicationContext);
  }

  @Test(expected = IllegalArgumentException.class)
  public void getCachedItem_should_throw_IllegalArgumentException_if_cache_not_found() {
    when(mockCacheManager.getCache(anyString())).thenReturn(null);
    subject.getCachedItem("test", "test");
  }

  @Test(expected = IllegalArgumentException.class)
  public void getCachedItem_should_throw_IllegalArgumentException_if_cache_key_not_found() {
    Cache mockCache = mock(Cache.class);
    when(mockCacheManager.getCache(anyString())).thenReturn(mockCache);
    subject.getCachedItem("test", "test");
  }

  @Test
  public void getCachedItem_should_return_json_response_when_cache_item_is_found() {
    Cache mockCache = mock(Cache.class);
    when(mockCacheManager.getCache(anyString())).thenReturn(mockCache);
    when(mockCache.get("test")).thenReturn(new SimpleValueWrapper("test"));
    String cachedItem = subject.getCachedItem("test", "test");
    assertNotNull("cached item should not be null", cachedItem);
  }
}
