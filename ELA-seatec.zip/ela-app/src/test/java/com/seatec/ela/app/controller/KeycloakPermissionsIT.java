package com.seatec.ela.app.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.dto.PaginationDTO;
import com.seatec.ela.app.dto.project.ProjectDTO;
import com.seatec.ela.app.exception.error.ErrorWrapperDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.util.AircraftDtoConverter;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * This class tests the permissions configuration in Keycloak, verifying that the correct users can
 * perform the correct operations on the external API.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@SqlGroup({
  @Sql(
      scripts = {
        "/datasets/efficiency_table.sql",
        "/datasets/efficiency_table_efficiency_load.sql",
        "/datasets/fleet.sql",
        "/datasets/aircraft.sql",
        "/datasets/ela-3324.sql",
        "/datasets/node-3324.sql",
        "/datasets/component-3324.sql",
        "/datasets/load-3324.sql"
      }),
  @Sql(
      scripts = "/datasets/test-data-cleanup.sql",
      executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
})
public class KeycloakPermissionsIT extends AbstractControllerIntegrationTest {

  @Autowired private ProjectRepo projectRepo;

  @Test
  public void all_users_should_be_able_to_view_elas() {
    for (String user : allUsers()) {
      ResponseEntity<Ela[]> response =
          restTemplate.exchange(
              "/service/elas?aircraft=3324",
              HttpMethod.GET,
              createHttpEntity(null, user),
              Ela[].class);
      assertEquals(
          "user " + user + " should be able to view elas", HttpStatus.OK, response.getStatusCode());
      Ela[] entity = response.getBody();
      assertNotNull(entity);
      assertTrue(entity.length > 0);
      assertEquals(entity[0].getName(), "33-525112-20_ELA_AppendixA_3324_ELA");
    }
  }

  @Test
  public void all_admins_should_be_able_to_create_fleets() {
    int idx = 1;
    for (String user : allAdmins()) {
      Fleet fleet = createFleet(idx++);
      ResponseEntity<Fleet> response =
          restTemplate.exchange(
              "/service/fleets", HttpMethod.POST, createHttpEntity(fleet, user), Fleet.class);
      try {
        assertEquals(
            "user " + user + " should be able to create fleets",
            HttpStatus.OK,
            response.getStatusCode());
        assertNotNull(response.getBody());
      } finally {
        fleetRepo.deleteById(response.getBody().getId());
      }
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_create_fleets() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Fleet fleet = createFleet(idx++);
      ResponseEntity<Fleet> response =
          restTemplate.exchange(
              "/service/fleets", HttpMethod.POST, createHttpEntity(fleet, user), Fleet.class);
      assertEquals(
          "user " + user + " should not be able to create fleets",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void all_admins_should_be_able_to_update_fleets() {
    int idx = 1;
    for (String user : allAdmins()) {
      Fleet fleet = createFleet(idx++);
      Fleet saved = fleetRepo.save(fleet);
      try {
        String updatedName = fleet.getName() + " updated fleet name";
        fleet.setName(updatedName);
        ResponseEntity<Fleet> response =
            restTemplate.exchange(
                "/service/fleets/" + saved.getId(),
                HttpMethod.PUT,
                createHttpEntity(fleet, user),
                Fleet.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Fleet entity = response.getBody();
        assertNotNull(entity);
        assertEquals(updatedName, entity.getName());
      } finally {
        fleetRepo.deleteById(saved.getId());
      }
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_update_fleets() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Fleet fleet = createFleet(idx++);
      Fleet saved = fleetRepo.save(fleet);
      try {
        String updatedName = fleet.getName() + " updated fleet name";
        fleet.setName(updatedName);
        ResponseEntity<Fleet> response =
            restTemplate.exchange(
                "/service/fleets/" + saved.getId(),
                HttpMethod.PUT,
                createHttpEntity(fleet, user),
                Fleet.class);
        assertEquals(
            "user " + user + " should not be able to update fleets",
            HttpStatus.FORBIDDEN,
            response.getStatusCode());
      } finally {
        fleetRepo.deleteById(saved.getId());
      }
    }
  }

  @Test
  public void all_admins_should_be_able_to_delete_fleets() {
    int idx = 1;
    for (String user : allAdmins()) {
      Fleet fleet = createFleet(idx++);
      Fleet saved = fleetRepo.save(fleet);
      ResponseEntity<Fleet> response =
          restTemplate.exchange(
              "/service/fleets/" + saved.getId(),
              HttpMethod.DELETE,
              createHttpEntity(null, user),
              Fleet.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertNull(response.getBody());
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_delete_fleets() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Fleet fleet = createFleet(idx++);
      Fleet saved = fleetRepo.save(fleet);
      try {
        ResponseEntity<Fleet> response =
            restTemplate.exchange(
                "/service/fleets/" + saved.getId(),
                HttpMethod.DELETE,
                createHttpEntity(null, user),
                Fleet.class);
        assertEquals(
            "user " + user + " should not be able to delete fleets",
            HttpStatus.FORBIDDEN,
            response.getStatusCode());
      } finally {
        fleetRepo.deleteById(saved.getId());
      }
    }
  }

  @Test
  public void all_admins_should_be_able_to_create_aircraft() {
    int idx = 300;
    Long boeingFleetId = 36L;

    for (String user : allAdmins()) {
      AircraftDto ac = createAircraftDto(idx++);

      // Custom Class Validator is hit after keycloak auth
      // [BatteryChargeType] is required for boeing
      ac.setBatteryCharge(BatteryChargeType.DUAL_40AH);

      ac.setFleetId(boeingFleetId);
      ResponseEntity<Aircraft> response =
          restTemplate.exchange(
              "/service/aircrafts", HttpMethod.POST, createHttpEntity(ac, user), Aircraft.class);
      assertEquals(
          "user "
              + user
              + " should be able to create aircraft id: "
              + ac.getId()
              + " ship num: "
              + ac.getAircraftShipNo(),
          HttpStatus.OK,
          response.getStatusCode());
      assertNotNull(response.getBody());
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_create_aircraft() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Aircraft ac = createAircraft(idx++);
      ResponseEntity<Aircraft> response =
          restTemplate.exchange(
              "/service/aircrafts", HttpMethod.POST, createHttpEntity(ac, user), Aircraft.class);
      assertEquals(
          "user " + user + " should not be able to create aircraft",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void all_admins_should_be_able_to_update_aircraft() {
    int idx = 1;
    for (String user : allAdmins()) {
      Aircraft aircraft = createAircraft(idx++);
      Fleet fleet = createFleet(idx);
      Fleet savedFleet = fleetRepo.save(fleet);
      aircraft.setFleet(fleet);
      Aircraft saved = aircraftRepo.save(aircraft);
      try {
        AircraftDto ac = AircraftDtoConverter.convertToDto(aircraft);
        String updatedName = ac.getVariableNumber() + "updated file name";
        ac.setVariableNumber(updatedName);
        ResponseEntity<Aircraft> response =
            restTemplate.exchange(
                "/service/aircrafts/" + saved.getId(),
                HttpMethod.PUT,
                createHttpEntity(ac, user),
                Aircraft.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Aircraft entity = response.getBody();
        assertNotNull(entity);
        assertEquals(updatedName, entity.getVariableNumber());
      } finally {
        aircraftRepo.deleteById(saved.getId());
        fleetRepo.deleteById(savedFleet.getId());
      }
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_update_aircraft() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Aircraft ac = createAircraft(idx++);
      ac.setFleet(createFleet(idx));
      Fleet savedFleet = fleetRepo.save(ac.getFleet());
      Aircraft saved = aircraftRepo.save(ac);
      try {
        String updatedName = ac.getOrigWorkbookFilename() + "updated file name";
        ac.setOrigWorkbookFilename(updatedName);
        ResponseEntity<Aircraft> response =
            restTemplate.exchange(
                "/service/aircrafts/" + saved.getId(),
                HttpMethod.PUT,
                createHttpEntity(ac, user),
                Aircraft.class);
        assertEquals(
            "user " + user + " should not be able to update aircraft",
            HttpStatus.FORBIDDEN,
            response.getStatusCode());
      } finally {
        aircraftRepo.deleteById(saved.getId());
        fleetRepo.deleteById(savedFleet.getId());
      }
    }
  }

  @Test
  public void all_admins_should_be_able_to_delete_aircraft() {
    int idx = 1;
    for (String user : allAdmins()) {
      Aircraft ac = createAircraft(idx++);
      ac.setFleet(createFleet(idx));
      Fleet savedFleet = fleetRepo.save(ac.getFleet());
      try {
        Aircraft saved = aircraftRepo.save(ac);
        ResponseEntity<Aircraft> response =
            restTemplate.exchange(
                "/service/aircrafts/" + saved.getId(),
                HttpMethod.DELETE,
                createHttpEntity(null, user),
                Aircraft.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());
      } finally {
        fleetRepo.deleteById(savedFleet.getId());
      }
    }
  }

  @Test
  public void non_admins_should_not_be_able_to_delete_aircraft() {
    int idx = 1;
    Set<String> users = allUsers();
    users.removeAll(allAdmins());
    for (String user : users) {
      Aircraft ac = createAircraft(idx++);
      ac.setFleet(createFleet(idx));
      Fleet savedFleet = fleetRepo.save(ac.getFleet());
      Aircraft saved = aircraftRepo.save(ac);
      try {
        ResponseEntity<Aircraft> response =
            restTemplate.exchange(
                "/service/aircrafts/" + saved.getId(),
                HttpMethod.DELETE,
                createHttpEntity(null, user),
                Aircraft.class);
        assertEquals(
            "user " + user + " should not be able to delete aircraft",
            HttpStatus.FORBIDDEN,
            response.getStatusCode());
      } finally {
        aircraftRepo.deleteById(saved.getId());
        fleetRepo.deleteById(savedFleet.getId());
      }
    }
  }

  @Test
  public void everyone_should_be_able_to_view_approved_projects() {
    for (String user : allUsers()) {
      Project project = createProject("0");
      project.setApproved(Instant.now());
      projectRepo.save(project);
      ResponseEntity<PaginationDTO<ProjectDTO>> response =
          restTemplate.exchange(
              "/service/projects/approved",
              HttpMethod.GET,
              createHttpEntity(null, user),
              new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
      assertEquals(response.getStatusCode(), HttpStatus.OK);
      List<ProjectDTO> projectDTOs = response.getBody().getContents();
      assertTrue(projectDTOs.size() > 0);
      assertEquals(projectDTOs.get(0).getNumber(), "A12345");
    }
  }

  @Test
  public void everyone_but_viewers_should_be_able_to_view_unapproved_projects() {
    for (String user : allButViewer()) {
      Project project = createProject("0");
      projectRepo.save(project);
      ResponseEntity<PaginationDTO<ProjectDTO>> response =
          restTemplate.exchange(
              "/service/projects?page=1&size=10",
              HttpMethod.GET,
              createHttpEntity(null, user),
              new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
      assertEquals(response.getStatusCode(), HttpStatus.OK);
      List<ProjectDTO> entity = response.getBody().getContents();
      assertTrue(entity.size() > 0);
      assertEquals(entity.get(0).getNumber(), "A12345");
    }
  }

  @Test
  public void viewers_should_not_be_able_to_view_unapproved_projects() {
    Set<String> users = allUsers();
    users.removeAll(allButViewer());
    for (String user : users) {
      Project project = createProject("0");
      project.setApproved(Instant.now());
      projectRepo.save(project);

      ResponseEntity<PaginationDTO<ProjectDTO>> response =
          restTemplate.exchange(
              "/service/projects?page=1&size=10",
              HttpMethod.GET,
              createHttpEntity(null, user),
              new ParameterizedTypeReference<PaginationDTO<ProjectDTO>>() {});
      assertEquals(response.getStatusCode(), HttpStatus.OK);
      List<ProjectDTO> entity = response.getBody().getContents();
      assertTrue(entity.size() == 0);
    }
  }

  @Test
  public void everyone_but_viewers_should_be_able_to_view_unapproved_projects_by_id() {
    Set<String> users = allUsers();
    users.removeAll(viewers());
    for (String user : users) {
      Project project = createProject("0");
      project.setApproved(Instant.now());
      projectRepo.save(project);

      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + project.getId(),
              HttpMethod.GET,
              createHttpEntity(null, user),
              Project.class);
      assertEquals(
          "user " + user + " should be able to view an unapproved project by id",
          HttpStatus.OK,
          response.getStatusCode());
    }
  }

  @Test
  public void viewers_should_not_be_able_to_view_unapproved_projects_by_id() {
    Set<String> users = allUsers();
    users.removeAll(allButViewer());
    for (String user : users) {
      Project project = createProject("0");
      projectRepo.save(project);

      ResponseEntity<ErrorWrapperDTO> response =
          restTemplate.exchange(
              "/service/projects/" + project.getId(),
              HttpMethod.GET,
              createHttpEntity(null, user),
              ErrorWrapperDTO.class);
      assertEquals(
          "viewer " + user + " should not be able to view an unapproved project by id",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
      assertEquals(
          "Viewers are only allowed to view approved projects.",
          response.getBody().getErrors().get(0).getMessage());
    }
  }

  @Test
  public void everyone_but_viewers_should_be_able_to_create_projects() {
    for (String user : allButViewer()) {
      Project project = createProject("0");
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects", HttpMethod.POST, createHttpEntity(project, user), Project.class);
      assertEquals(
          "user " + user + " should be able to create projects",
          HttpStatus.OK,
          response.getStatusCode());
      assertNotNull(response.getBody());
    }
  }

  @Test
  public void viewers_should_not_be_able_to_create_projects() {
    Set<String> users = allUsers();
    users.removeAll(allButViewer());
    for (String user : users) {
      Project project = createProject("0");
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects", HttpMethod.POST, createHttpEntity(project, user), Project.class);
      assertEquals(
          "user " + user + " should not be able to create projects",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void everyone_but_viewers_should_be_able_to_update_projects() {
    for (String user : allButViewer()) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      String updatedName = "updated title";
      project.setTitle(updatedName);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(),
              HttpMethod.PUT,
              createHttpEntity(project, user),
              Project.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertNull(response.getBody());
    }
  }

  @Test
  public void viewers_should_not_be_able_to_update_projects() {
    Set<String> users = allUsers();
    users.removeAll(allButViewer());
    for (String user : users) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      String updatedName = "updated title";
      project.setTitle(updatedName);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(),
              HttpMethod.PUT,
              createHttpEntity(project, user),
              Project.class);
      assertEquals(
          "user " + user + " should not be able to update projects",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void all_admins_should_be_able_to_delete_projects() {
    for (String user : allAdmins()) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(),
              HttpMethod.DELETE,
              createHttpEntity(null, user),
              Project.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
      assertNull(response.getBody());
    }
  }

  @Test
  public void author_of_project_should_be_able_to_delete_project() throws Exception {
    Set<String> users = authors();

    for (String user : users) {
      HttpEntity<String> entity = createHttpEntity(null, user);
      String userId = getUserId(entity);

      Project project = createProject(userId);
      Project saved = projectRepo.save(project);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(), HttpMethod.DELETE, entity, Project.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
    }
  }

  @Test
  public void checker_of_project_should_be_able_to_delete_project() throws Exception {
    Set<String> users = checkers();

    for (String user : users) {
      HttpEntity<String> entity = createHttpEntity(null, user);
      String userId = getUserId(entity);

      Project project = createProject("0");
      project.setCheckEngineer(userId);

      Project saved = projectRepo.save(project);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(), HttpMethod.DELETE, entity, Project.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
    }
  }

  @Test
  public void coAuthor_of_project_should_be_able_to_delete_project() throws Exception {
    Set<String> users = allButViewer();

    for (String user : users) {
      HttpEntity<String> entity = createHttpEntity(null, user);
      String userId = getUserId(entity);

      Project project = createProject("0");
      project.setCoauthors(Arrays.asList(userId));

      Project saved = projectRepo.save(project);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(), HttpMethod.DELETE, entity, Project.class);
      assertEquals(HttpStatus.OK, response.getStatusCode());
    }
  }

  @Test
  public void viewers_should_not_be_able_to_delete_projects() {
    Set<String> users = viewers();

    for (String user : users) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      ResponseEntity<Project> response =
          restTemplate.exchange(
              "/service/projects/" + saved.getId(),
              HttpMethod.DELETE,
              createHttpEntity(null, user),
              Project.class);
      assertEquals(
          "user " + user + " should not be able to delete projects",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void non_checkers_approvers_should_not_be_able_check_or_reject_project() {
    Set<String> users = notCheckers();
    for (String user : users) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      ResponseEntity<Void> cloakResponse =
          restTemplate.exchange(
              "/service/projects/" + saved.getId() + "/check/reject",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to reject projects",
          HttpStatus.FORBIDDEN,
          cloakResponse.getStatusCode());
      ResponseEntity<Void> uncloakResponse =
          restTemplate.exchange(
              "/service/aircrafts/" + saved.getId() + "/check/approve",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to approve",
          HttpStatus.FORBIDDEN,
          uncloakResponse.getStatusCode());
    }
  }

  @Test
  public void non_approvers_should_not_be_able_approve_or_reject_projects() {
    Set<String> users = notApprovers();
    for (String user : users) {
      Project project = createProject("0");
      Project saved = projectRepo.save(project);
      ResponseEntity<Void> cloakResponse =
          restTemplate.exchange(
              "/service/projects/" + saved.getId() + "/approve/reject",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to reject projects",
          HttpStatus.FORBIDDEN,
          cloakResponse.getStatusCode());
      ResponseEntity<Void> uncloakResponse =
          restTemplate.exchange(
              "/service/aircrafts/" + saved.getId() + "/approve",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to approve",
          HttpStatus.FORBIDDEN,
          uncloakResponse.getStatusCode());
    }
  }

  @Test
  public void everyone_should_be_able_to_view_users() {
    for (String user : allUsers()) {
      ResponseEntity<UserRepresentation[]> response =
          restTemplate.exchange(
              "/service/keycloak/users",
              HttpMethod.GET,
              createHttpEntity(null, user),
              UserRepresentation[].class);
      assertEquals(response.getStatusCode(), HttpStatus.OK);
      UserRepresentation[] entity = response.getBody();
      assertTrue(entity.length > 0);
    }
  }

  @Test
  public void all_users_should_be_able_to_view_roles() {
    for (String user : allUsers()) {
      ResponseEntity<String[]> response =
          restTemplate.exchange(
              "/service/keycloak/roles",
              HttpMethod.GET,
              createHttpEntity(null, user),
              String[].class);
      assertEquals(response.getStatusCode(), HttpStatus.OK);
      String[] entity = response.getBody();
      assertTrue(entity.length > 0);
    }
  }

  @Test
  public void non_itadmin_should_not_be_able_to_view_cloaked() {
    Aircraft aircraft = createAircraft(110);
    aircraft.setCloaked(true);
    aircraftRepo.save(aircraft);
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<String> response =
          restTemplate.exchange(
              "/service/aircrafts/cloak",
              HttpMethod.GET,
              createHttpEntity(null, user),
              String.class);
      assertEquals(
          "user " + user + " should not be able to get cloaked",
          HttpStatus.FORBIDDEN,
          response.getStatusCode());
    }
  }

  @Test
  public void non_itadmin_should_not_be_able_to_modify_cloaked() {
    Aircraft aircraft = createAircraft(110);
    aircraft.setCloaked(true);
    aircraftRepo.save(aircraft);
    Set<String> users = allUsers();
    users.remove(itAdminUsername);
    for (String user : users) {
      ResponseEntity<Void> cloakResponse =
          restTemplate.exchange(
              "/service/aircrafts/" + aircraft.getId() + "/cloak",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to cloak",
          HttpStatus.FORBIDDEN,
          cloakResponse.getStatusCode());
      ResponseEntity<Void> uncloakResponse =
          restTemplate.exchange(
              "/service/aircrafts/" + aircraft.getId() + "/uncloak",
              HttpMethod.PATCH,
              createHttpEntity(null, user),
              Void.class);
      assertEquals(
          "user " + user + " should not be able to uncloaked",
          HttpStatus.FORBIDDEN,
          uncloakResponse.getStatusCode());
    }
  }
}
