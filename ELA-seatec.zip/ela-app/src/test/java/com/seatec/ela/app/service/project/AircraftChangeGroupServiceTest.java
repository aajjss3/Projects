package com.seatec.ela.app.service.project;

import static junit.framework.TestCase.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.seatec.ela.app.dto.AircraftBusStructureBucketDto;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.service.contract.project.IAircraftChangeGroupService;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Test;

public class AircraftChangeGroupServiceTest {

  private IAircraftChangeGroupService subject;

  private AircraftChangeGroupRepo mockAircraftChangeGroupRepo;

  @Before
  public void setup() {
    mockAircraftChangeGroupRepo = mock(AircraftChangeGroupRepo.class);
    subject = new AircraftChangeGroupService(mockAircraftChangeGroupRepo);
  }

  @Test
  public void findAllByChangeGroupIdIn_should_return_successful() {
    // change groups
    List<ChangeGroup> changeGroups = createMockChangeGroups(3);

    // change group ids
    List<UUID> changeGroupIds =
        changeGroups.stream().map(ChangeGroup::getId).collect(Collectors.toList());

    List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();
    for (ChangeGroup changeGroup : changeGroups) {
      List<AircraftChangeGroup> groups = createMockAircraftChangeGroups(generateInt(1, 4));
      changeGroup.setAircraftChangeGroups(groups);
      aircraftChangeGroups.addAll(groups);
    }

    when(mockAircraftChangeGroupRepo.findAllByChangeGroupIdIn(anyList()))
        .thenReturn(aircraftChangeGroups);

    List<AircraftChangeGroup> results = subject.findAllByChangeGroupIdIn(changeGroupIds);

    assertNotNull("result should not be null", results);
    assertFalse("result should not be empty", results.isEmpty());
    assertNotNull("Aircraft id should not be null", results.get(0).getAircraft().getId());
    assertEquals(aircraftChangeGroups.size(), results.size());
  }

  @Test
  public void convertAircraftBusStructureBucketDtoToAircraftChangeGroup_should_return_successful() {
    int totalAircrafts = 3;
    String changeGroupName = "Airbus";
    AircraftBusStructureBucketDto aircraftBusStructureBucketDto =
        createAircraftBusStructureBucketDto(changeGroupName, totalAircrafts);

    ChangeGroup changeGroup = createMockChangeGroup(changeGroupName);

    List<AircraftChangeGroup> results =
        subject.convertAircraftBusStructureBucketDtoToAircraftChangeGroup(
            aircraftBusStructureBucketDto, changeGroup);

    assertNotNull("result should not be null", results);
    assertFalse("result should not be empty", results.isEmpty());
    assertEquals(results.size(), totalAircrafts);

    for (AircraftChangeGroup acg : results) {
      assertEquals(acg.getChangeGroup().getName(), changeGroupName);
    }
  }

  @Test
  public void save_ChangeGroup_name_null_should_return_BadRequestException() {
    // new AircraftChangeGroup
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setAircraft(createMockAircraft());
    aircraftChangeGroup.setChangeGroup(createMockChangeGroup("Airbus 1"));

    when(mockAircraftChangeGroupRepo.save(any(AircraftChangeGroup.class)))
        .thenReturn(aircraftChangeGroup);

    AircraftChangeGroup result = subject.save(aircraftChangeGroup);

    assertNotNull("result should not be null", result);
    assertEquals(aircraftChangeGroup.getAircraft().getId(), result.getAircraft().getId());
    assertEquals(
        aircraftChangeGroup.getAircraft().getAircraftShipNo(),
        result.getAircraft().getAircraftShipNo());
    assertEquals(aircraftChangeGroup.getChangeGroup().getName(), result.getChangeGroup().getName());
    assertEquals(
        aircraftChangeGroup.getChangeGroup().getChanges(), result.getChangeGroup().getChanges());
  }

  private AircraftBusStructureBucketDto createAircraftBusStructureBucketDto(
      String name, int mockAircrafts) {
    AircraftBusStructureBucketDto aircraftBusStructureBucketDto =
        new AircraftBusStructureBucketDto();

    aircraftBusStructureBucketDto.setName(name);
    aircraftBusStructureBucketDto.setAircraft(createMockAircrafts(mockAircrafts));

    return aircraftBusStructureBucketDto;
  }

  private Aircraft createMockAircraft() {
    Aircraft aircraft = new Aircraft();
    aircraft.setId(Integer.toUnsignedLong(generateInt(1, 200)));
    aircraft.setAircraftShipNo(Integer.toString(generateInt(2000, 5000)));
    return aircraft;
  }

  private List<Aircraft> createMockAircrafts(int amount) {
    List<Aircraft> aircrafts = new ArrayList<>();

    for (int i = 0; i < amount; i++) {
      aircrafts.add(createMockAircraft());
    }

    return aircrafts;
  }

  private AircraftChangeGroup createMockAircraftChangeGroup() {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();
    aircraftChangeGroup.setAircraft(createMockAircraft());
    return aircraftChangeGroup;
  }

  private List<AircraftChangeGroup> createMockAircraftChangeGroups(int amount) {
    List<AircraftChangeGroup> aircraftChangeGroups = new ArrayList<>();

    for (int i = 0; i < amount; i++) {
      aircraftChangeGroups.add(createMockAircraftChangeGroup());
    }

    return aircraftChangeGroups;
  }

  private ChangeGroup createMockChangeGroup(String name) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setId(UUID.randomUUID());
    changeGroup.setName(name);
    return changeGroup;
  }

  private List<ChangeGroup> createMockChangeGroups(int amount) {
    List<ChangeGroup> changeGroups = new ArrayList<>();

    for (int i = 0; i < amount; i++) {
      changeGroups.add(createMockChangeGroup(generateString(10)));
    }

    return changeGroups;
  }

  private int generateInt(int min, int max) {
    return min + (int) (Math.random() * ((max - min) + 1));
  }

  private String generateString(int len) {
    return RandomStringUtils.random(len, true, false);
  }
}
