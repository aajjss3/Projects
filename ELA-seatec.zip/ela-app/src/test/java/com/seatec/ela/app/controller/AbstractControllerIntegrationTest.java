package com.seatec.ela.app.controller;

import static org.junit.Assert.assertEquals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.seatec.ela.app.dto.AircraftDto;
import com.seatec.ela.app.dto.FleetDto;
import com.seatec.ela.app.dto.report.ProjectReportDTO;
import com.seatec.ela.app.model.Aircraft;
import com.seatec.ela.app.model.Component;
import com.seatec.ela.app.model.EfficiencyLoad;
import com.seatec.ela.app.model.EfficiencyTable;
import com.seatec.ela.app.model.EfficiencyType;
import com.seatec.ela.app.model.Ela;
import com.seatec.ela.app.model.ElectricalPhase;
import com.seatec.ela.app.model.Fleet;
import com.seatec.ela.app.model.Load;
import com.seatec.ela.app.model.Node;
import com.seatec.ela.app.model.NodeType;
import com.seatec.ela.app.model.project.AircraftChangeGroup;
import com.seatec.ela.app.model.project.ChangeGroup;
import com.seatec.ela.app.model.project.ComponentChange;
import com.seatec.ela.app.model.project.LoadChange;
import com.seatec.ela.app.model.project.NodeChange;
import com.seatec.ela.app.model.project.Project;
import com.seatec.ela.app.model.project.change.Change;
import com.seatec.ela.app.model.repository.AircraftRepository;
import com.seatec.ela.app.model.repository.ComponentRepository;
import com.seatec.ela.app.model.repository.EfficiencyTableRepo;
import com.seatec.ela.app.model.repository.ElaRepository;
import com.seatec.ela.app.model.repository.FleetRepository;
import com.seatec.ela.app.model.repository.LoadRepository;
import com.seatec.ela.app.model.repository.NodeRepository;
import com.seatec.ela.app.model.repository.project.AircraftChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.ChangeGroupRepo;
import com.seatec.ela.app.model.repository.project.NodeChangeRepo;
import com.seatec.ela.app.model.repository.project.ProjectRepo;
import com.seatec.ela.app.model.repository.project.change.ChangeRepo;
import com.seatec.ela.app.util.AircraftDtoConverter;
import com.seatec.ela.app.util.FleetDtoConverter;
import com.seatec.ela.app.util.enumeration.ActionType;
import com.seatec.ela.app.util.enumeration.OperatingMode.Airbus;
import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.Before;
import org.junit.Test;
import org.keycloak.TokenVerifier;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

public abstract class AbstractControllerIntegrationTest {

  protected static final String BASE_URL = "http://localhost:9291";

  protected static final String DEFAULT_USER_ID = "00000-00000-00000-00000-00000";
  protected static final String VIEWER_ID = "64d14438-8968-48d9-890c-c8e31a3a4221";
  protected static final String COAUTHOR_ID = "64d14438-8968-48d9-890c-c8e31a3a4221";
  protected static final String INVALID_COAUTHOR_ID =
      "8a4cef89-dbe7-42d9-af4f-9efc17877509"; // viewer role

  @Autowired protected TestRestTemplate restTemplate;

  @Autowired protected FleetRepository fleetRepo;

  @Autowired protected AircraftRepository aircraftRepo;

  @Autowired public Environment env;

  @Autowired private CacheController cacheController;

  @Autowired private ChangeGroupRepo changeGroupRepo;

  @Autowired private ChangeRepo changeRepo;

  @Autowired private ElaRepository elaRepo;

  @Autowired private NodeRepository nodeRepository;

  @Autowired private NodeChangeRepo nodeChangeRepo;

  @Autowired private AircraftChangeGroupRepo aircraftChangeGroupRepo;

  @Autowired private ComponentRepository componentRepository;

  @Autowired private LoadRepository loadRepository;

  @Autowired private ProjectRepo projectRepo;

  @Autowired private EfficiencyTableRepo efficiencyTableRepo;

  @Value("${auth.viewerUsername}")
  String viewUsername;

  @Value("${auth.authorUsername}")
  String authorUsername;

  @Value("${auth.checkerUsername}")
  String checkerUsername;

  @Value("${auth.approverUsername}")
  String approverUsername;

  @Value("${auth.engineeringAdminUser}")
  String engineeringAdminUsername;

  @Value("${auth.itAdminUser}")
  String itAdminUsername;

  @Before
  public void clearCache() {
    cacheController.clearCache();
  }

  @Test
  public void contextLoads() {}

  private String keycloakAuthentication() {
    return keycloakAuthentication(
        env.getRequiredProperty("keycloak.resource").trim(),
        env.getRequiredProperty("auth.itAdminUser").trim(),
        env.getRequiredProperty("auth.password").trim(),
        env.getRequiredProperty("keycloak.credentials.secret").trim());
  }

  private String keycloakAuthentication(String username) {
    return keycloakAuthentication(
        env.getRequiredProperty("keycloak.resource").trim(),
        username,
        env.getRequiredProperty("auth.password").trim(),
        env.getRequiredProperty("keycloak.credentials.secret").trim());
  }

  /**
   * Call KeyCloak to authenticate and return the JWT token.
   *
   * @return - JWT token
   */
  private String keycloakAuthentication(
      String clientId, String username, String password, String clientSecret) {
    HttpHeaders headers = new HttpHeaders();
    // keycloak's rest endpoint expects the data to be passed in as 'x-www-form-urlencoded' name
    // value pairs.
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
    params.add("grant_type", "password");
    params.add("client_id", clientId);
    params.add("username", username);
    params.add("password", password);
    params.add("client_secret", clientSecret);
    HttpEntity<MultiValueMap<String, String>> request =
        new HttpEntity<MultiValueMap<String, String>>(params, headers);

    ResponseEntity<String> response =
        restTemplate.postForEntity(
            env.getRequiredProperty("keycloak.auth-server-url")
                + "/realms/"
                + env.getRequiredProperty("keycloak.realm").trim()
                + "/protocol/openid-connect/token",
            request,
            String.class);
    JsonObject reply = new Gson().fromJson(response.getBody(), JsonObject.class);
    if (reply.has("access_token")) {
      return reply.get("access_token").toString().replace("\"", "");
    } else {
      throw new UnsupportedOperationException("Error authenticating: " + reply.toString());
    }
  }

  protected HttpEntity<String> createHttpEntity(Object obj) {
    return createHttpEntity(obj, env.getRequiredProperty("auth.itAdminUser").trim());
  }

  protected HttpEntity<String> createAuthorHttpEntity(Object obj) {
    return createHttpEntity(obj, authorUsername);
  }

  protected HttpEntity<String> createHttpEntity(Object obj, String username) {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter(Instant.class, new InstantSerializer());
    String body = gsonBuilder.create().toJson(obj);

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.set("Authorization", "Bearer " + keycloakAuthentication(username));
    return new HttpEntity<String>(body, headers);
  }

  protected HttpEntity<MultiValueMap<String, Object>> createHttpEntityForMultipart(
      Object dto, String fileName) {
    GsonBuilder gsonBuilder = new GsonBuilder();
    gsonBuilder.registerTypeAdapter(Instant.class, new InstantSerializer());
    String jsonDto = gsonBuilder.create().toJson(dto);

    HttpHeaders headers = new HttpHeaders();
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.setContentType(MediaType.MULTIPART_FORM_DATA);
    headers.set("Authorization", "Bearer " + keycloakAuthentication());
    MultiValueMap<String, Object> multipartRequest = new LinkedMultiValueMap<>();

    // creating an HttpEntity for the JSON part
    HttpHeaders jsonHeader = new HttpHeaders();
    jsonHeader.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> jsonHttpEntity = new HttpEntity<>(jsonDto, jsonHeader);

    // putting the part into the request
    multipartRequest.add("elaDto", jsonHttpEntity);

    // creating an HttpEntity for the file
    HttpHeaders fileHeader = new HttpHeaders();
    //   fileHeader.setContentType(MediaType.TEXT_PLAIN);
    if (fileName != null) {
      jsonHeader.setContentType(MediaType.TEXT_EVENT_STREAM);
      HttpEntity<FileSystemResource> filePart =
          new HttpEntity<>(new FileSystemResource(fileName), fileHeader);
      // putting the part into the request
      multipartRequest.add("file", filePart);
    }

    return new HttpEntity<>(multipartRequest, headers);
  }

  protected ComponentChange createComponentChange(
      List<LoadChange> loadChanges,
      ElectricalPhase electricalPhase,
      boolean intermittent,
      String electIdent,
      Double nominalPower) {
    ComponentChange componentChange = new ComponentChange();
    componentChange.setName("changedComponentName");
    componentChange.setLoadChanges(loadChanges);
    componentChange.setElectricalPhase(electricalPhase);
    componentChange.setIntermittent(intermittent);
    componentChange.setElectIdent(electIdent);
    componentChange.setSheddable(false);
    componentChange.setAta("ata");
    componentChange.setClipsed(false);
    componentChange.setPanel("panel");
    componentChange.setDisplayOrder(1);
    componentChange.setNominalPower(nominalPower);
    componentChange.setConnectedLoadPf(0d);
    componentChange.setConnectedLoadVa(0d);
    return componentChange;
  }

  protected ComponentChange createComponentChange(
      List<LoadChange> loadChanges,
      ElectricalPhase electricalPhase,
      boolean intermittent,
      String electIdent,
      Double nominalPower,
      String name,
      boolean sheddable,
      String ata,
      boolean clipsed,
      String panel,
      Double connectLoadPf,
      Double connectLoadVa) {
    ComponentChange componentChange = new ComponentChange();

    componentChange.setName(name);
    componentChange.setLoadChanges(loadChanges);
    componentChange.setElectricalPhase(electricalPhase);
    componentChange.setIntermittent(intermittent);
    componentChange.setElectIdent(electIdent);
    componentChange.setSheddable(sheddable);
    componentChange.setAta(ata);
    componentChange.setClipsed(clipsed);
    componentChange.setPanel(panel);
    componentChange.setDisplayOrder(1);
    componentChange.setNominalPower(nominalPower);
    componentChange.setConnectedLoadPf(connectLoadPf);
    componentChange.setConnectedLoadVa(connectLoadVa);

    return componentChange;
  }

  protected Change createChange() {
    return new Change();
  }

  protected ChangeGroup createChangeGroup(String name) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setName(name);
    return changeGroup;
  }

  protected LoadChange createLoadChange(String flightPhase) {
    LoadChange loadChange = new LoadChange();
    loadChange.setVa(200d);
    loadChange.setPowerFactor(1d);
    loadChange.setFlightPhase(flightPhase);
    loadChange.setOperatingMode(Airbus.MAXI.toString());
    return loadChange;
  }

  protected LoadChange createLoadChange(
      String flightPhase, String operatingMode, Double powerFactor, Double va) {
    LoadChange loadChange = new LoadChange();
    loadChange.setVa(va);
    loadChange.setPowerFactor(powerFactor);
    loadChange.setFlightPhase(flightPhase);
    loadChange.setOperatingMode(operatingMode);
    return loadChange;
  }

  protected NodeChange createNodeChange(
      Double busRating,
      String name,
      Double voltage,
      ElectricalPhase voltageType,
      NodeType nodeType,
      Double nominalPower,
      boolean requiresApproval,
      boolean sheddable,
      boolean normalTr,
      ElectricalPhase electricalPhase) {
    NodeChange nodeChange = new NodeChange();
    nodeChange.setBusRating(busRating);
    nodeChange.setName(name);
    nodeChange.setVoltage(voltage);
    nodeChange.setVoltageType(voltageType);
    nodeChange.setElectricalPhase(electricalPhase);
    nodeChange.setNodeType(nodeType);
    nodeChange.setNominalPower(nominalPower);
    nodeChange.setRequiresApproval(requiresApproval);
    nodeChange.setSheddable(sheddable);
    nodeChange.setNormalTr(normalTr);
    return nodeChange;
  }

  protected Project createProject(String userId) {
    Project project = new Project();
    project.setStarted(Instant.now().plus(3, ChronoUnit.HOURS));
    project.setDescription("four score");
    project.setNumber("A12345");
    project.setRevisionLevel("revision 1");
    project.setMaintenanceDescription("maintenance 1");
    project.setTitle("title 1");
    project.setAuthor(userId);
    return project;
  }

  protected Project createProject(String userId, String number) {
    Project project = new Project();
    project.setStarted(Instant.now().plus(3, ChronoUnit.HOURS));
    project.setDescription("four score");
    project.setNumber(number);
    project.setRevisionLevel("revision 1");
    project.setMaintenanceDescription("maintenance 1");
    project.setTitle("title 1");
    project.setAuthor(userId);
    return project;
  }

  protected Ela createEla(String name) {
    Ela ela = new Ela();
    ela.setName(name);
    ela.setCreatedBy("max-a-million");
    return ela;
  }

  protected FleetDto createFleetDto(int number) {
    return FleetDtoConverter.convertToDto(createFleet(number));
  }

  protected FleetDto createSubFleetDto(int number) {
    return FleetDtoConverter.convertToDto(createSubFleet(number));
  }

  protected Fleet createFleet(int number) {
    while (true) {
      List<Fleet> fleets = fleetRepo.findByName("fleetName " + number);
      if (fleets.isEmpty()) {
        break;
      }
      number++;
    }
    Fleet fleet = new Fleet();
    fleet.setName("fleetName " + number);
    fleet.setManufacturer("Airbus");
    fleet.setBusStructureBucket("Big Sky Airplanes 1");
    fleet.setStructureName("BigSkye-321-model");
    return fleet;
  }

  protected Fleet createSubFleet(int number) {
    Fleet fleet = new Fleet();
    fleet.setName("fleetName 1 subFleet" + number);
    fleet.setManufacturer("Big Sky Airplanes");
    fleet.setBusStructureBucket("Big Sky Airplanes 1");
    fleet.setStructureName("BigSkye-321-model");
    return fleet;
  }

  protected AircraftDto createAircraftDto(int number) {
    return AircraftDtoConverter.convertToDto(createAircraft(number));
  }

  protected Aircraft createAircraft(int number) {
    while (true) {
      List<Aircraft> acs = aircraftRepo.findByAircraftShipNo("" + number);
      if (acs.isEmpty()) {
        break;
      }
      number++;
    }

    Aircraft aircraft = new Aircraft();
    aircraft.setAircraftShipNo(Integer.toString(number));
    aircraft.setSerialNumber("A0001232");
    aircraft.setRegistrationNumber("N23922");
    aircraft.setLineNumber("223");
    aircraft.setVariableNumber("VN2322");
    return aircraft;
  }

  /**
   * assert that the fields on the two objects passed have the same values. This assumes that the
   * sourceObj and targetObj objects passed in are of the same class with the same fields (number,
   * type and name). Do not assert any fields located on the objects parent class.
   */
  protected void assertObjectFields(Object targetObj, Object sourceObj, List<String> excludeList)
      throws Exception {
    Field[] sourceFields = sourceObj.getClass().getDeclaredFields();
    Field[] targetFields = targetObj.getClass().getDeclaredFields();

    // find the fields on the object that are on the BaseEntity (ex. version, id, created, updated)
    Field[] baseFields = sourceObj.getClass().getSuperclass().getDeclaredFields();
    List<String> baseFieldNames = new ArrayList<String>();
    Arrays.asList(baseFields).forEach(field -> baseFieldNames.add(field.getName()));

    // dont assert the fields on the BaseEntity. create a list of fields that exclude the BaseEntity
    // fields
    List<Field> filteredSourceFields =
        Arrays.asList(sourceFields).stream()
            .filter(field -> !baseFieldNames.contains(field.getName()))
            .collect(Collectors.toList());
    List<Field> filteredTargetFields =
        Arrays.asList(targetFields).stream()
            .filter(field -> !baseFieldNames.contains(field.getName()))
            .collect(Collectors.toList());

    // assert fields on the source and target objects (excluding BaseEntity fields)
    for (Field sourceField : filteredSourceFields) {
      if (excludeList.contains(sourceField.getName()) || sourceField.getName().equals("author")) {
        continue;
      }
      sourceField.setAccessible(true);
      Optional<Field> targetField =
          filteredTargetFields.stream()
              .filter(field -> field.getName().equals(sourceField.getName()))
              .findFirst();
      if (targetField.isPresent()) {
        targetField.get().setAccessible(true);
        assertEquals(targetField.get().get(targetObj), sourceField.get(sourceObj));
      }
    }
  }

  protected void assertObjectFields(Object targetObj, Object sourceObj) throws Exception {
    assertObjectFields(targetObj, sourceObj, new ArrayList<String>());
  }

  // get the subject (user id) from the JWT token in the Authorization header
  protected String getUserId(HttpEntity<String> entity) throws Exception {
    HttpHeaders headers = entity.getHeaders();
    String token = headers.get("Authorization").get(0).replace("Bearer ", "");
    String userId = TokenVerifier.create(token, AccessToken.class).getToken().getSubject();
    return userId;
  }

  /**
   * Replace GSON's protected serialization of an Instant (which is
   * {:"seconds":#########,"nanos":########} ) to a string format {:"yyyy-MM-ddThh:mm:ss.SSSZ"}
   *
   * @author asparago
   */
  class InstantSerializer implements JsonSerializer<Instant> {

    @Override
    public JsonElement serialize(Instant value, Type typeOfSrc, JsonSerializationContext context) {
      return new JsonPrimitive(value.toString());
    }
  }

  protected Aircraft createAndSaveAircraft(int number, Fleet fleet) {
    Aircraft aircraft = createAircraft(number);
    aircraft.setFleet(fleet);
    fleet.getAircraft().add(aircraft);
    return aircraftRepo.save(aircraft);
  }

  protected Aircraft createAndSaveAircraft(
      String shipNumber,
      String serialNumber,
      String registrationNumber,
      String lineNumber,
      String variableNumber,
      Fleet fleet) {
    Aircraft aircraft =
        new Aircraft(
            shipNumber, serialNumber, registrationNumber, lineNumber, variableNumber, fleet);
    return aircraftRepo.save(aircraft);
  }

  protected Change createAndSaveChange(
      String nodeName,
      String electIdent,
      ActionType actionType,
      String changer,
      NodeChange nodeChange,
      ComponentChange componentChange,
      ChangeGroup changeGroup) {
    Change change = new Change();
    change.setNodeName(nodeName);
    change.setAction(actionType);
    change.setChanger(changer);
    change.setComponentElectIdent(electIdent);
    change.setChangeGroup(changeGroup);
    change.setNodeChange(nodeChange);
    change.setComponentChange(componentChange);
    return changeRepo.save(change);
  }

  protected ChangeGroup createAndSaveChangeGroup(String name, Project project) {
    ChangeGroup changeGroup = new ChangeGroup();
    changeGroup.setName(name);
    project.addChangeGroup(changeGroup);
    return changeGroupRepo.save(changeGroup);
  }

  protected Component createAndSaveComponent(
      Node node,
      String name,
      ElectricalPhase electricalPhase,
      Double nominalPower,
      int displayOrder) {
    Component component = new Component();
    component.setElectricalPhase(electricalPhase);
    component.setElectIdent(name);
    component.setAta("ata");
    component.setPanel("panel");
    component.setNominalPower(nominalPower);
    component.setClipsed(false);
    component.setName(name);
    component.setDisplayOrder(displayOrder);
    component.setSheddable(Boolean.FALSE);
    component.setIntermittent(Boolean.FALSE);
    node.addComponent(component);
    return componentRepository.save(component);
  }

  protected Component createAndSaveComponentWithLoads(
      Node node,
      String name,
      ElectricalPhase electricalPhase,
      Double nominalPower,
      int displayOrder,
      boolean isBoeing) {
    Component component =
        createAndSaveComponent(node, name, electricalPhase, nominalPower, displayOrder);

    if (!isBoeing) {
      createAndSaveLoad(component, "ground");
      createAndSaveLoad(component, "start");
      createAndSaveLoad(component, "roll");
      createAndSaveLoad(component, "toff");
      createAndSaveLoad(component, "climb");
      createAndSaveLoad(component, "cruise");
      createAndSaveLoad(component, "desc");
      createAndSaveLoad(component, "land");
      createAndSaveLoad(component, "taxi");
    } else {
      createAndSaveLoad(component, "loading");
      createAndSaveLoad(component, "engine_start");
      createAndSaveLoad(component, "taxi");
      createAndSaveLoad(component, "takeoff_climb");
      createAndSaveLoad(component, "cruise");
      createAndSaveLoad(component, "hold_land");
      createAndSaveLoad(component, "standby");
    }

    return component;
  }

  protected EfficiencyTable createAndSaveEfficiencyTable(
      EfficiencyType efficiencyType,
      String name,
      EfficiencyLoad efficiencyLoadLower,
      EfficiencyLoad efficiencyLoadUpper,
      Node node) {
    EfficiencyTable efficiencyTable = new EfficiencyTable();
    efficiencyTable.setEfficiencyType(efficiencyType);
    efficiencyTable.setName(name);

    // efficiency loads
    List<EfficiencyLoad> efficiencyLoads = new ArrayList<>();
    efficiencyLoads.add(efficiencyLoadLower);
    efficiencyLoads.add(efficiencyLoadUpper);
    efficiencyTable.setLoads(efficiencyLoads);

    node.setEfficiencyTable(efficiencyTable);
    EfficiencyTable finalEfficiencyTable = efficiencyTableRepo.save(efficiencyTable);
    nodeRepository.save(node);

    return finalEfficiencyTable;
  }

  protected Ela createAndSaveEla(String name, Aircraft aircraft) {
    Ela ela = new Ela();
    ela.setName(name);
    ela.setCreatedBy("test");
    ela.setAircraft(aircraft);
    return elaRepo.save(ela);
  }

  protected Fleet createAndSaveFleet(int number) {
    Fleet fleet = createFleet(number);
    return fleetRepo.save(fleet);
  }

  protected Fleet createAndSaveFleet(int number, String busStructureBucketName) {
    Fleet fleet = createFleet(number);
    fleet.setBusStructureBucket(busStructureBucketName);
    return fleetRepo.save(fleet);
  }

  protected Node createAndSaveNode(
      Boolean requiresApproval,
      String name,
      Double voltage,
      Double nominalPower,
      NodeType nodeType,
      Double busRating,
      ElectricalPhase electricalPhase,
      Integer order,
      Node parentNode,
      Ela ela) {
    Node node = new Node();
    node.setRequiresApproval(requiresApproval);
    node.setEla(ela);
    node.setName(name);
    node.setVoltage(voltage);
    node.setVoltageType(electricalPhase);
    node.setNominalPower(nominalPower);
    node.setNodeType(nodeType);
    node.setBusRating(busRating);
    node.setVoltageType(electricalPhase);
    node.setElectricalPhase(
        ElectricalPhase.AC.equals(electricalPhase) ? ElectricalPhase.ACA : electricalPhase);
    node.setDisplayOrder(order);

    if (parentNode != null) {
      parentNode.addSubNode(node);
    } else {
      ela.addNode(node);
    }

    return nodeRepository.save(node);
  }

  protected Change createAndSaveNodeChange(ChangeGroup changeGroup) {
    Change change = new Change();
    NodeChange nc = new NodeChange();
    nc.setName("nodeChangeName");
    nc.setVoltageType(ElectricalPhase.AC);
    nc.setVoltage(1.0);
    nc.setElectricalPhase(ElectricalPhase.AC3);
    nc.setNodeType(NodeType.BUS);
    change.setNodeChange(nc);
    change.setAction(ActionType.ADD);
    changeGroup.addChange(change);
    return changeRepo.save(change);
  }

  protected Change createAndSaveChangeWithNodeChange(
      ChangeGroup changeGroup, NodeChange nodeChange, ActionType actionType) {
    Change change = new Change();

    change.setNodeChange(nodeChange);
    change.setAction(actionType);
    changeGroup.addChange(change);

    return changeRepo.save(change);
  }

  protected Change createAndSaveChangeWithComponentChange(
      ChangeGroup changeGroup,
      String nodeName,
      ComponentChange componentChange,
      ActionType actionType) {
    Change change = new Change();

    change.setComponentChange(componentChange);
    change.setNodeName(nodeName);
    change.setComponentElectIdent(componentChange.getElectIdent());
    change.setAction(actionType);
    changeGroup.addChange(change);

    return changeRepo.save(change);
  }

  protected Change createAndSaveComponentChange(ChangeGroup changeGroup) {
    return createAndSaveComponentChange(changeGroup, "12345", null);
  }

  protected Change createAndSaveComponentChange(
      ChangeGroup changeGroup, String electIdent, String nodeName) {
    Change change = new Change();
    if (nodeName != null) {
      change.setNodeName(nodeName);
    }
    ComponentChange componentChange = new ComponentChange();
    componentChange.setName("componentChangeName");
    componentChange.setElectIdent(electIdent);
    componentChange.setElectricalPhase(ElectricalPhase.AC3);
    componentChange.setIntermittent(false);
    change.setComponentChange(componentChange);
    change.setAction(ActionType.ADD);
    change.setComponentElectIdent("123");
    changeGroup.addChange(change);
    return changeRepo.save(change);
  }

  protected Load createAndSaveLoad(Component component, String flightPhase) {
    Load load = new Load();
    load.setVa(200d);
    load.setPowerFactor(1d);
    load.setComponent(component);
    load.setFlightPhase(flightPhase);
    load.setOperatingMode(Airbus.MAXI.toString());
    component.addLoad(load);
    return loadRepository.save(load);
  }

  protected Load createAndSaveLoad(
      Component component,
      String flightPhase,
      String operatingMode,
      Double va,
      Double powerFactor) {
    Load load = new Load();
    load.setVa(va);
    load.setPowerFactor(powerFactor);
    load.setComponent(component);
    load.setFlightPhase(flightPhase);
    load.setOperatingMode(operatingMode);
    component.addLoad(load);
    return loadRepository.save(load);
  }

  protected Change saveChange(Change change) {
    return changeRepo.save(change);
  }

  protected AircraftChangeGroup createAndSaveAircraftChangeGroup(
      Aircraft aircraft, ChangeGroup changeGroup) {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();

    aircraftChangeGroup.setAircraft(aircraft);
    changeGroup.addAircraftChangeGroup(aircraftChangeGroup);

    return aircraftChangeGroupRepo.save(aircraftChangeGroup);
  }

  protected AircraftChangeGroup createAircraftChangeGroup(
      Aircraft aircraft, ChangeGroup changeGroup) {
    AircraftChangeGroup aircraftChangeGroup = new AircraftChangeGroup();

    aircraftChangeGroup.setAircraft(aircraft);
    changeGroup.addAircraftChangeGroup(aircraftChangeGroup);

    return aircraftChangeGroup;
  }

  protected Project createAndSaveProject(
      String title,
      String description,
      String maintDescription,
      String revisionLevel,
      String number,
      Instant started) {
    Project project = new Project();
    project.setTitle(title);
    project.setDescription(description);
    project.setStarted(started);
    project.setMaintenanceDescription(maintDescription);
    project.setRevisionLevel(revisionLevel);
    project.setNumber(number);
    project.setAuthor("0");

    return projectRepo.save(project);
  }

  protected Project createAndSaveProject(
      String title, String nbr, boolean isChecked, boolean isApproved) {
    Project project = new Project();
    project.setApprovalEngineer(DEFAULT_USER_ID);
    project.setTitle(title);
    project.setSubmitted(Instant.now());
    project.setStarted(Instant.now());
    project.setRevisionLevel("revision level");
    project.setRetired(Instant.now());
    project.setNumber(nbr);
    project.setMaintenanceDescription("maintenance Desc");
    project.setDescription("description");
    project.setCheckEngineer("check engineer");
    project.setChecked(Instant.now());
    project.setAuthor("0");

    if (isChecked) {
      project.setChecked(Instant.now());
    }

    if (isApproved) {
      project.setApproved(Instant.now());
    }

    return projectRepo.save(project);
  }

  protected Project saveProjectAnalysis(Project project, ProjectReportDTO projectReportDTO) {
    project.setAnalysis(projectReportDTO);
    return projectRepo.save(project);
  }

  protected Set<String> allUsers() {
    return new HashSet<>(
        Arrays.asList(
            viewUsername,
            authorUsername,
            checkerUsername,
            approverUsername,
            engineeringAdminUsername,
            itAdminUsername));
  }

  protected Set<String> allAdmins() {
    return new HashSet<>(Arrays.asList(engineeringAdminUsername, itAdminUsername));
  }

  protected Set<String> allButViewer() {
    return new HashSet<>(
        Arrays.asList(
            authorUsername,
            checkerUsername,
            approverUsername,
            engineeringAdminUsername,
            itAdminUsername));
  }

  protected Set<String> authors() {
    return new HashSet<>(Arrays.asList(authorUsername));
  }

  protected Set<String> notApprovers() {
    Set<String> set = allUsers();
    set.removeAll(approvers());
    return set;
  }

  protected Set<String> checkers() {
    return new HashSet<>(Arrays.asList(checkerUsername));
  }

  protected Set<String> notCheckers() {
    return new HashSet<>(Arrays.asList(viewUsername, authorUsername));
  }

  protected Set<String> approvers() {
    return new HashSet<>(
        Arrays.asList(approverUsername, engineeringAdminUsername, itAdminUsername));
  }

  protected Set<String> viewers() {
    return new HashSet<>(Arrays.asList(viewUsername));
  }

  protected Set<String> itAdmin() {
    return new HashSet<>(Arrays.asList(itAdminUsername));
  }
}
