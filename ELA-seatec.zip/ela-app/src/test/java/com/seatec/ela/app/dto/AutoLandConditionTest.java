package com.seatec.ela.app.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.seatec.ela.app.dto.analysis.AutoLandAnalysis;
import com.seatec.ela.app.dto.analysis.AutoLandAnalysisNode;
import com.seatec.ela.app.dto.analysis.AutoLandCondition;
import com.seatec.ela.app.util.BatteryDischargeCalculation;
import com.seatec.ela.app.util.enumeration.AnalysisStatus;
import com.seatec.ela.app.util.enumeration.BatteryChargeType;
import org.junit.Test;

public class AutoLandConditionTest {

  @Test
  public void testGetStatus_PASS() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    BatteryChargeType batteryChargeType = BatteryChargeType.SINGLE_40AH;

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(batteryChargeType);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    assertEquals(AnalysisStatus.PASS, autoLandCondition.getStatus());
  }

  @Test
  public void testGetStatus_FAIL() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 100.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 100.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 100.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 100.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 100.0d));

    BatteryChargeType batteryChargeType = BatteryChargeType.SINGLE_40AH;

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(batteryChargeType);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    assertEquals(AnalysisStatus.FAIL, autoLandCondition.getStatus());
  }

  @Test
  public void testGetActualBatteryLifeInMinutes() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    BatteryChargeType batteryChargeType = BatteryChargeType.SINGLE_40AH;

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(batteryChargeType);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    Double actualBatteryLifeInMinutes = autoLandCondition.getActualBatteryLifeInMinutes();

    Double expectedBatteryLifeInMinutes =
        BatteryDischargeCalculation.boeingEquation(batteryChargeType, 10.0d);

    assertEquals(expectedBatteryLifeInMinutes, actualBatteryLifeInMinutes, 0.0d);
  }

  @Test
  public void testGetActualBatteryLifeInMinutes_NoAnalysisBatteryOnly() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    BatteryChargeType batteryChargeType = BatteryChargeType.SINGLE_40AH;

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(batteryChargeType);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(null);

    Double actualBatteryLifeInMinutes = autoLandCondition.getActualBatteryLifeInMinutes();

    assertNull(actualBatteryLifeInMinutes);
  }

  @Test
  public void testGetActualBatteryLifeInMinutes_NoBatteryCapacity() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(null);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    Double actualBatteryLifeInMinutes = autoLandCondition.getActualBatteryLifeInMinutes();

    assertNull(actualBatteryLifeInMinutes);
  }

  @Test
  public void getTotalLoadInAmps() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(BatteryChargeType.SINGLE_40AH);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    Double actualTotalLoadInAmps = autoLandCondition.getTotalLoadInAmps();

    assertEquals(10.0d, actualTotalLoadInAmps, 0.0d);
  }

  @Test
  public void getTotalLoadInAmps_NoAnalysisBatteryOnly() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(BatteryChargeType.SINGLE_40AH);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);

    Double actualTotalLoadInAmps = autoLandCondition.getTotalLoadInAmps();

    assertNull(actualTotalLoadInAmps);
  }

  @Test
  public void testGetRequiredBatteryLifeInMinutes() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    BatteryChargeType batteryChargeType = BatteryChargeType.SINGLE_40AH;

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(batteryChargeType);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    Double requiredBatteryLifeInMinutes = autoLandCondition.getRequiredBatteryLifeInMinutes();

    assertEquals(5.0d, requiredBatteryLifeInMinutes, 0.0d);
  }

  @Test
  public void testGetRequiredBatteryLifeInMinutes_NoBatteryCapacity() {
    AutoLandAnalysis analysisBatteryCharger = new AutoLandAnalysis();
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("HB06", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("BB1S", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DSBY", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("DCAL", 1.0d));
    analysisBatteryCharger.addNode(new AutoLandAnalysisNode("INVERTER", 1.0d));

    AutoLandAnalysis analysisBatteryOnly = new AutoLandAnalysis();
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("HB06", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("BB1S", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DSBY", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("DCAL", 2.0d));
    analysisBatteryOnly.addNode(new AutoLandAnalysisNode("INVERTER", 2.0d));

    AutoLandCondition autoLandCondition = new AutoLandCondition();
    autoLandCondition.setBatteryCapacity(null);
    autoLandCondition.setAnalysisBatteryCharger(analysisBatteryCharger);
    autoLandCondition.setAnalysisBatteryOnly(analysisBatteryOnly);

    Double requiredBatteryLifeInMinutes = autoLandCondition.getRequiredBatteryLifeInMinutes();

    assertNull(requiredBatteryLifeInMinutes);
  }
}
