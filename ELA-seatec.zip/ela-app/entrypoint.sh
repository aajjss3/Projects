#!/bin/sh

# if $AWS_SECRETS_MGR_ID not empty, fetch RDS password from secrets manager
if [ -n "$AWS_SECRETS_MGR_ID" ] ; then
  # override db password unless it's already overridden
  if [ -z "$APP_DATASOURCE_PASSWORD" ] ; then
    export APP_DATASOURCE_PASSWORD=`AWS_DEFAULT_REGION="us-east-1" aws secretsmanager get-secret-value --secret-id $AWS_SECRETS_MGR_ID | jq '.SecretString' -r`
    if [ -z "$APP_DATASOURCE_PASSWORD" ] ; then
      echo "Error fetching db pass from AWS, exiting"
      exit 1
    fi
  fi
fi

if [ -n "$AWS_SECRETS_MGR_SMTP_ID" ] ; then
  # override db password unless it's already overridden
  if [ -z "$SPRING_MAIL_PASSWORD" ] ; then
    export SPRING_MAIL_PASSWORD=`AWS_DEFAULT_REGION="us-east-1" aws secretsmanager get-secret-value --secret-id $AWS_SECRETS_MGR_SMTP_ID | jq '.SecretString | fromjson.password' -r`
    if [ -z "$SPRING_MAIL_PASSWORD" ] ; then
      echo "Error fetching email password from AWS, exiting"
      exit 1
    fi
  fi
fi
java $JAVA_OPTS -Djava.security.egd=file:/dev/./urandom -jar /app.jar
