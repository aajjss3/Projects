May 2017

the GitHub url for this project is: https://github.com/aajjss3/Practice


Need to manually start the mySQL database server before starting this spring boot application.
Currently, MySQL 8 is the default database I use locally when i run the following commands. 
To start the mySQL server go to a DOS prompt RUN AS ADMINISTRATOR and type;  mysqld --console     (see the document:  D:\projects\documentation\'how to set up and use mysql.txt')
To stop the mySQL server go to a different DOS prompt RUN AS ADMINISTRATOR and type: mysqladmin -u root shutdown

This spring boot application is set to create the database each time the spring boot application starts up and drops the database each time the spring boot application shuts down.
(see the property: spring.jpa.hibernate.ddl-auto in the application.properties file)

This spring boot application is set to save the ddl that hibernate creates (based on the domain model annotation)
(see the properties: spring.jpa.properties.javax.persistence.schema-generation.*  in the application.properties file)

To run this application's 'local' profile:
	right click on the Practice project and select... Run As... Run Configurations... Spring Boot App... and select the 'Practice - PracticeApplication - local'.
	or
	right click on the PracticeApplication.java file and select... Run As... Spring Boot App... and select the 'Practice - PracticeApplication - local'.
	NOTE: the application is started when this is printed to the console...  'Started PracticeApplication in x.xxx seconds'


Spring boot applications uses the 'open entity in view' design pattern by default BUT there is no need to use this design pattern if using DTO's (only use this design pattern if passing the domain model objects either into or out of the service layer).
Since DTO's are populated in the service layer, there is no need to use the 'open entity in view' design pattern when using DTO's.

See the application*.properties files for additional comments

This application uses:
	Spring Boot - containing: Spring, Hibernate ORM and Tomcat (part of springboot)
	Spring MVC for creating REST web services (part of springboot)
	Spring Data JPA for creating repositories (part of springboot)
	MapStruct API for Entity to DTO mapping and visa versa. (seperate jar file) 
	Bean Validation and its reference implementation Hibernate Validator for input data validation. (part of springboot)
	Springs custom exception handling (part of springboot)
	Maven for building
	Springs Developer Tools (separate jar file) - If developing in an IDE it will automatically restart tomcat whenever files on the classpath change (JRebel uses dynamic class reloading which is even better but JRebel costs $500).
							 					  Just by adding this jar file to the pom, if the application is running in Tomcat in an IDE, it will auto restart when a file is changed. No additional configuration is required.  
	MySQL database (seperate jar file)