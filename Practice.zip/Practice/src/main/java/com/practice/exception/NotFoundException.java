package com.practice.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
import com.practice.util.log.BaseLogger.LogLevel;

/**
 * Exception to throw when a Http Status NOT FOUND (404) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotFoundException extends CustomException{

	public NotFoundException(String message){
		super(message);
	}
	
	public NotFoundException(String message, LogLevel logLevel){
		super(message, logLevel);
	}
	
	public NotFoundException(String message, LogLevel logLevel, Exception rootCause){
		super(message, logLevel, rootCause);
	}

}