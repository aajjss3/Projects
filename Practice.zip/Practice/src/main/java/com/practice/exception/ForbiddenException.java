package com.practice.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.practice.util.log.BaseLogger.LogLevel;


/**
 * Exception to throw when a Http Status FORBIDDEN (403) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class ForbiddenException extends CustomException{
	
	public ForbiddenException(String message){
		super(message);
	}
	
	public ForbiddenException(String message, LogLevel logLevel){
		super(message, logLevel);
	}
	
	public ForbiddenException(String message, LogLevel logLevel, Exception rootCause){
		super(message, logLevel, rootCause);
	}
	
}
