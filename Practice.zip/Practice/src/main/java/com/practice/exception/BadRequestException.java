package com.practice.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.practice.util.log.BaseLogger.LogLevel;


/**
 * Exception to throw when a Http Status BAD_REQUEST (400) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class BadRequestException extends CustomException{
	
	public BadRequestException(String message){
		super(message);
	}
	
	public BadRequestException(String message, LogLevel logLevel){
		super(message, logLevel);
	}
	
	public BadRequestException(String message, LogLevel logLevel, Exception rootCause){
		super(message, logLevel, rootCause);
	}
	
}
