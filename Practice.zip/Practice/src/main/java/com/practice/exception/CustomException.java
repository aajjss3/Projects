package com.practice.exception;

import com.practice.util.log.BaseLogger.LogLevel;

/**
 * Base Exception class that all exceptions should extend from. 
 * 
 * @author asparago
 *
 */
public abstract class CustomException extends RuntimeException{
	
	
	public boolean isLoggable = false;   // if the exception should be logged. default to no logging
	public Exception rootCause; //the root exception if there is one
	public LogLevel logLevel; // the log level to use if the exception should be logged
	
	
	
	/**
	 * call this constructor if no logging is desired
	 * @param message - the message to send back to the client
	 */
	public CustomException(String message){
		super(message);
	}
	
	/**
	 * call this constructor if logging is desired but there is no underlying exception to log
	 * @param message - the message to log and to send back to the client
	 * @param logLevel  - the log level to use
	 */
	public CustomException(String message, LogLevel logLevel){
		super(message);
		this.isLoggable = true;
		this.logLevel = logLevel;
	}
	
	/**
	 * call this constructor if logging is desired and you wish to log the underlying exception
	 * @param message - the message to log and to send back to the client
	 * @param logLevel - the log level to use
	 * @param rootCause - the underlying exception to log
	 */
	public CustomException(String message, LogLevel logLevel, Exception rootCause){
		super(message);
		this.isLoggable = true;
		this.logLevel = logLevel;
		this.rootCause = rootCause;
	}

}
