package com.practice.controller.rest;

import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.practice.dto.ScoreDTO;


@RestController
@RequestMapping(path="score", produces = "application/json")
@Validated
public class ScoreController {
	
	
	/**
	 * URL: GET http://localhost:8080/score
	 * Example of an endpoint that dynamically determines during runtime whether to display a field name and value in the json response. 
	 * Since ScoreDTO is annotated with @JsonFilter, the json output will either contain a field called 'grade' and/or a field called 'score' depending on the values for these fields.
	 * The filter is run when Jackson serialized the dto returned from the controller, after the controller is finished.
	 * (see ScoreFilter.java for the logic used to determine whether a field name and value is displayed)
	 * @return
	 */
	@GetMapping
	@ResponseStatus(HttpStatus.OK)
	public ScoreDTO getScore(){
		ScoreDTO dto = new ScoreDTO();
		dto.setGrade("Axxxx");   // will not be displayed 'grade' if the value is anything other than 'A' (see ScoreFilter)
		dto.setScore("5");   // will not be displayed 'score' if the value is anything other than '5' (see ScoreFilter)
		return dto;
	}

}
