package com.practice.controller.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.practice.domain.model.Setting;
import com.practice.service.SettingService;


@RestController
@RequestMapping(path="setting", produces = "application/json")
@Validated
public class SettingController {
	
	@Autowired
	SettingService settingService;
	
	/**
	 * Create or update a setting record. Any user can create or update the same setting record
	 * Return the Setting object, not a SettingDTO object. (example of returning a domain object and not a dto)
	 * @param name
	 * @param quantity
	 * @return
	 */
	@PutMapping("/{name}/{quantity}")
	@ResponseStatus(HttpStatus.OK)
	public Setting createOrUpdateSetting( @PathVariable("name") String name, @PathVariable("quantity") Integer quantity ){
		return settingService.createOrUpdateSetting(name, quantity);
	}
	
	
	/**
	 * 
	 * @param name
	 * @return List of Integers
	 */
	@GetMapping("/{name}")
	@ResponseStatus(HttpStatus.OK)
	public List<Integer> getQuantities( @PathVariable("name") String name ){
		return settingService.getQuantities(name);
	}

}
