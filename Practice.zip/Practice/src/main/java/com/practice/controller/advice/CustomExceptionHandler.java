package com.practice.controller.advice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.practice.exception.CustomException;
import com.practice.util.log.BaseLogger;
import static org.springframework.core.annotation.AnnotatedElementUtils.findMergedAnnotation;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Path;
import java.util.*;
import com.google.gson.Gson;

/**
 * Override springs default handling when an exception is thrown by the application.
 * @author asparago
 *
 */
@ControllerAdvice
public class CustomExceptionHandler{
	
    @Autowired
    private BaseLogger logger;
    
    
    @ExceptionHandler
    @ResponseBody
    ResponseEntity<ErrorDTOWrapper> handle(Exception exception) {
    	
    	ResponseEntity<ErrorDTOWrapper> response = null;
    	
    	// if CustomException, or any subclass of it, is thrown
    	if( exception instanceof CustomException ){
			// log the exception if applicable.
			if( ((CustomException)exception).isLoggable ){
				if( ((CustomException)exception).rootCause != null ){
					logger.log( ((CustomException)exception).logLevel,  exception.getLocalizedMessage(), ((CustomException)exception).rootCause );
				}
				else{
					logger.log( ((CustomException)exception).logLevel,  exception.getLocalizedMessage() );
				}
			}
			ErrorDTO errorDTO = new ErrorDTO( null, exception.getLocalizedMessage() );
			ErrorDTOWrapper body = new ErrorDTOWrapper(errorDTO);
			// get the HTTP status code annotated on the CustomException, or if one isn't present, then set to HTTP status code to INTERNAL_SERVER_ERROR as default
			ResponseStatus annotation = findMergedAnnotation(exception.getClass(), ResponseStatus.class);
			HttpStatus responseStatus = ( annotation != null ) ?  annotation.value() : HttpStatus.INTERNAL_SERVER_ERROR ;
			response = new ResponseEntity<ErrorDTOWrapper>(body, responseStatus);
    	}
    	// if Bean Validation annotation fails on either @PathVariable or @RequestParam
    	else if( exception instanceof ConstraintViolationException ){
    		List<ErrorDTO> errors = new ArrayList<ErrorDTO>();
    		Set<ConstraintViolation<?>> violations = ((ConstraintViolationException)exception).getConstraintViolations();
    		for( ConstraintViolation violation : violations ){
    			Iterator nodes = violation.getPropertyPath().iterator();
    			String fieldName = null;
    			while (nodes.hasNext() ){
    				fieldName = ((Path.Node)nodes.next()).getName();
    			}
    			ErrorDTO dto = new ErrorDTO(fieldName, violation.getMessage());
    			errors.add(dto);
    		}
    		ErrorDTOWrapper body = new ErrorDTOWrapper(errors);
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST);
    		String json = new Gson().toJson(body);
    		logger.warning( "Input validation failed. JSON returned to the client is: " + json );
    	}
    	// if @Validated or @Valid fails
    	else if( exception instanceof MethodArgumentNotValidException ){
    		List<ErrorDTO> errors = new ArrayList<ErrorDTO>();
    		for (FieldError error : ((MethodArgumentNotValidException)exception).getBindingResult().getFieldErrors()) {
    			ErrorDTO errorDTO = new ErrorDTO(error.getField(), error.getDefaultMessage());
    			errors.add(errorDTO);
    		}
    		for (ObjectError error : ((MethodArgumentNotValidException)exception).getBindingResult().getGlobalErrors()) {
    			ErrorDTO errorDTO = new ErrorDTO(error.getObjectName(), error.getDefaultMessage());
    			errors.add(errorDTO);
    		}
    		ErrorDTOWrapper body = new ErrorDTOWrapper(errors);
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST);  
    		String json = new Gson().toJson(body);
    		logger.warning( "Input validation failed. JSON returned to the client is: " + json );
    	}
    	// if input JSON in request body is malformed
    	else if( exception instanceof HttpMessageNotReadableException ){
    		String message = (exception.getCause() != null) ? exception.getCause().getMessage() : exception.getLocalizedMessage();
    		ErrorDTO error = new ErrorDTO(null, "Failed to process input. The reason is: " + message);
    		ErrorDTOWrapper body = new ErrorDTOWrapper(error);
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST); 
    		logger.warning( "The input JSON in the requests body is malformed. " + message );
    	}
    	// if any other exception not listed above is thrown
    	else{
    		String message = (exception.getCause() != null) ? exception.getCause().getMessage() : exception.getLocalizedMessage();
    		ErrorDTO error = new ErrorDTO(null, message);
    		ErrorDTOWrapper body = new ErrorDTOWrapper(error);
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.INTERNAL_SERVER_ERROR);   
    		logger.severe( "Uncaught exception was thrown.", exception );
    	}
    	
    	return response;
    	
    }    
  
    
    /**
     * JavaBean to match the response json structure for errors.
     *
     * @author asparago
     *
     */
    class ErrorDTOWrapper {
    	
    	private List<ErrorDTO> errors = new ArrayList<ErrorDTO>();
    	
    	public ErrorDTOWrapper(List<ErrorDTO> errors){
    		super();
    		this.errors.addAll( errors );
    	}
    	
    	public ErrorDTOWrapper(ErrorDTO error){
    		super();
    		this.errors.add( error );
    	}

    	public List<ErrorDTO> getErrors() {
    		return errors;
    	}
    	public void setErrors(List<ErrorDTO> errors) {
    		this.errors = errors;
    	}
        	
    }


    class ErrorDTO {
    	
    	private String field;
    	private String message;
    	
    	public ErrorDTO(String field, String message) {
    		this.field = field;
    		this.message = message;
    	}
    	
    	public String getField() {
    		return field;
    	}
    	public void setField(String field) {
    		this.field = field;
    	}
    	public String getMessage() {
    		return message;
    	}
    	public void setMessage(String message) {
    		this.message = message;
    	}
    	
    }	

}
