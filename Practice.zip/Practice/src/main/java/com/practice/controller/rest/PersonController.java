package com.practice.controller.rest;

import java.util.List;
import javax.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import com.practice.dto.PersonDTO;
import com.practice.service.PersonService;
import com.practice.util.validation.group.PersonCreate;
import com.practice.util.validation.group.PersonUpdate;


@RestController
@RequestMapping(path="person", produces = "application/json")
@Validated
public class PersonController {
	
	@Autowired
	PersonService personService;
	
	
	/**
	 * Retrieve a collection of people who have the last name of {last}. 
	 * 
	 * GET URL http://localhost:8080/person/{last}
	 * 
	 * @param name - String
	 * @return List<PersonDTO>
	 */
	@GetMapping("/{last}")
	@ResponseStatus(HttpStatus.OK)
	public List<PersonDTO> getPersons( @Pattern(regexp="^[a-zA-Z]+$", message="{field.letters.only}") @PathVariable("last") String last ){
		
//test throwing an exception
//throw new ForbiddenException("four score four score four score", LogLevel.WARNING, new NullPointerException("alan"));
//throw new NullPointerException("throwing a null is not good");
		return personService.getPersons(last);
	}
	
	/**
	 * Persist a person object. Also persist any Pets (associated with the Person) passed in the JSON request. 
	 * 
	 * POST URL http://localhost:8080/person
	 * example of body of the request :  {"role":"ADMIN", "type":"BOX", "pets":[{"age":5,"category":"dog","nick_name":"elmo"}],"first_name":"alan","last_name":"sparago","date_of_birth":null}
	 * @param dto - PersonDTO
	 * @return void
	 */
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public void createPerson( @Validated(value=PersonCreate.class) @RequestBody PersonDTO dto ){
		personService.createPerson(dto);
	}
	
	
	/**
	 * Delete a Person object with the id that is passed in. Delete any Pet objects associated with the Person. 
	 * 
	 * DELETE URL http://localhost:8080/person/{id_of_person_to_delete}
	 * 
	 * @param id
	 * @return void
	 */
	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public void deletePerson(@PathVariable("id") Long id){
		personService.deletePerson(id);
	}
	
	
	/**
	 * Update the person object with the id that is passed in. Only update fields on the Person object if the corresponding field passed in the JSON is not null/empty.
	 * Only update the Person, do not update any Pet fields associated with the person, even if they are passed in the JSON request.
	 * Return a full populated PersonDTO will all persisted fields, independent of whether those fields were passed in the JSON request. This PersonDTO will also contain any persisted PetDTO's.
	 * 
	 * PUT URL http://localhost:8080/person/{id_of_person_to_update}
	 * 
	 * @param dto
	 * @param id
	 * @return PersonDTO
	 */
	@PutMapping("/{id}")
	@ResponseStatus(HttpStatus.OK)
	public PersonDTO updatePerson( @Validated(value=PersonUpdate.class) @RequestBody PersonDTO dto, @PathVariable("id") Long id){
		return personService.updatePerson(dto, id);
	}
	
}
