package com.practice.controller.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.practice.dto.PersonDTO;

/**
 * Both of these methods do the same thing. 
 * One method accepts a Model object and returns a String
 * The other method accepts nothing and returns a ModelAndView
 * @author alan
 *
 */
@Controller
public class TestWebAppController {
	
	/**
	 * URL: http://localhost:8080/test-hello-1
	 * @param model- a Model object
	 * @return String - name of the html page to display. page should be in the directory:  /resources/templates and its extension should be .html
	 */
    @GetMapping("/test-hello-1")
    public String hello1(Model model) {
    	PersonDTO dto = new PersonDTO();
    	dto.setFirstName("alan");
    	dto.setLastName("sparago");
        model.addAttribute("person", dto);
        return "hello";
    }
    
    
	/**
	 * URL: http://localhost:8080/test-hello-2
	 * @return ModelAndView
	 */
    @GetMapping("/test-hello-2")
    public ModelAndView hello2() {
    	PersonDTO dto = new PersonDTO();
    	dto.setFirstName("alan");
    	dto.setLastName("sparago");
        ModelAndView modelAndView = new ModelAndView("hello");
        modelAndView.addObject("person", dto);
        return modelAndView;
    }

}
