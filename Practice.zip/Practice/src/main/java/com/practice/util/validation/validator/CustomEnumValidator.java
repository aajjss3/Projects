package com.practice.util.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.practice.util.validation.annotation.CustomEnum;


/**
 * only allow a value if its a valid custom enum (ex. Types.class).
 * The enum type/class is stored in the variable enumType.
 *
 */
public class CustomEnumValidator implements ConstraintValidator<CustomEnum, String>{

	// variable that contains the custom enum class (ex. Types)
	private Class enumType;
	
	@Override
	public void initialize(CustomEnum constraintAnnotation) {
		this.enumType = constraintAnnotation.enumType();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value == null || value.equals("")){
			return true;
		}
		Enum[] enumerations = (Enum[])enumType.getEnumConstants();
		for (Enum enumeration : enumerations) {
			if (enumeration.name().equals(value)) {
				return true;
			}
		}
		return false;
	}

	
}
