package com.practice.util.validation.group;

public interface PersonCreate {}
