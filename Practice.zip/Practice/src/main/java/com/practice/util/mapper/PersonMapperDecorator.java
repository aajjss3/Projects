package com.practice.util.mapper;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import com.practice.domain.model.Person;
import com.practice.domain.model.Pet;
import com.practice.dto.PersonDTO;

/**
 * contains custom mapping/logic that can't be handled by MapStruct's default mapping.
 * @author alan
 *
 */
public abstract class PersonMapperDecorator extends PersonMapper {
	
    @Autowired
    PersonMapper personMapper;

    /**
     * Override the pesonDtotoPerson method on the PersonMapper
     */
    @Override
    public Person personDtoToPerson(PersonDTO dto) {
    	
    	// call the PersonMapper.personDtoToPerson method for default mapping
        Person person = personMapper.personDtoToPerson( dto );
        
        // extend the default mapping with custom logic. 
        // this logic is required by hibernate to cascade create (to allow hibernate to auto create nested Pet objects when creating a Person).
		Set<Pet> pets = person.getPets();
		for(Pet pet : pets){
			pet.setPerson(person);
		}
		
        return person;
    }

}
