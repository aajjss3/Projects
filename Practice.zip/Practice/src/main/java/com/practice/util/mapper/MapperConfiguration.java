package com.practice.util.mapper;

import org.mapstruct.MapperConfig;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.NullValueCheckStrategy;


/**
 * Set global MapStruct configuration parameters.
 */
@MapperConfig(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS  // only update/set a field on the destination object if the source object's field is not null/empty
)
public interface MapperConfiguration {
}
