package com.practice.util;

public enum Types {
	
	PACKAGE, BOX, MAIL;

}
