package com.practice.util.validation.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.practice.util.Roles;
import com.practice.util.validation.annotation.Role;

public class RoleValidator implements ConstraintValidator<Role, String>{
	
	// list of valid roles.
	private Roles[] roles;
	
	@Override
	public void initialize(Role constraintAnnotation) {
		this.roles = constraintAnnotation.roles();
	}

	public boolean isValid(String value, ConstraintValidatorContext constraintContext) {
		boolean success = false;
		for( Roles role : roles ){
			if( role.toString().equals(value)){
				success = true;
			}
		}
		return success;		
	}
	
}
