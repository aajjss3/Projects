package com.practice.util;

public enum Roles {

	ADMIN, SUPER_USER, USER;
	
}
