package com.practice.util.mapper;

import org.mapstruct.DecoratedWith;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import com.practice.domain.model.Person;
import com.practice.domain.model.Pet;
import com.practice.dto.PersonDTO;
import com.practice.dto.PetDTO;

/**
 * Uses MapStruct for Person to PersonDTO mapping and visa versa.
 * It will map nested object graphs.
 * 
 * @author alan
 *
 */
@Mapper(config = MapperConfiguration.class)
@DecoratedWith(PersonMapperDecorator.class) // tells mapstruct to look at PersonMapperDecorator for any overridden methods.
public abstract class PersonMapper{
	
	
    @Mapping(source = "first", target = "firstName")
    @Mapping(source = "last", target = "lastName")
    public abstract PersonDTO personToPersonDto(Person person);
    
    
    @InheritInverseConfiguration(name = "personToPersonDto")
    public abstract Person personDtoToPerson(PersonDTO dto);
      
    
    /**
     * update an existing Person object with data in the dto. only update a field on person if the corresponding dto field is not null.
     * Do not update any Pet objects associated with the Person, even if the PersonDTO has a non-null value for pets (non-null PetDTOs).
     * Reason... if you want to update a nested object graph how do you know if a child (ie. PetDTO) represents a new record to add, or an existing to update. and if its an existing to update, which pet record should be updated.
     * also, if there are no nested objects (ie PetDto assign to the PersonDto), does that mean that no existing pet records assign to that person should be updated or that all existing pet records (if there are any) assign to that person should be deleted 
     */
    @InheritInverseConfiguration(name = "personToPersonDto")
    @Mapping(target = "pets", ignore = true) // do not update any pet fields, even if there are PetDTOs associated with the PersonDTO 
    public abstract Person updatePersonFromPersonDto(PersonDTO personDTO, @MappingTarget Person person);
         
    
    @Mapping(source = "name", target = "nickName")
    public abstract PetDTO petToPetDto(Pet pet);
        
    
    @InheritInverseConfiguration(name = "petToPetDto")
    public abstract Pet petDtoToPet(PetDTO dto);

    
}
