package com.practice.domain.model;


import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.OptimisticLock;

@Entity
public class Pet extends BaseModel{
		
	// example of turning off optimistic locking on a specific field
	//@OptimisticLock(excluded=true)
	private String name;
	private Integer age;
	private String category;
	
	@ManyToOne
    @JoinColumn(name="person_id", nullable=false)
	private Person person;
	
	
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
    public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
}