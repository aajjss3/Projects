package com.practice.domain.model;


import java.util.Date;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table( indexes = { @Index(columnList ="last", name="person_last_idx") } )
public class Person extends BaseModel{
	
	private String first;
	private String last;
	private Date dob;
	private String role;
	
	// cascade inserts and deletes only. 
	@OneToMany(cascade={CascadeType.PERSIST, CascadeType.REMOVE}, mappedBy="person")
	private Set<Pet> pets;
	
		
	public Set<Pet> getPets() {
		return pets;
	}
	public void setPets(Set<Pet> pets) {
		this.pets = pets;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}


}
