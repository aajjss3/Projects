package com.practice.domain.dao;

import com.practice.domain.model.Setting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.*;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.LockModeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import org.springframework.jdbc.core.JdbcTemplate;

@Repository
public class SettingDao{
	
	
	@PersistenceContext
	protected EntityManager entityManager;
	
	@Autowired
	JdbcTemplate JdbcTemplate;
	
	
	/**
	 * Retrieve a Setting object using pessimistic locking since any user can perform CRUD operations against a Setting record.
	 * Pessimistic locking is handled by SELECT * FOR UPDATE sql statements but I dont know if MySQL can handle pessimistic locking.
	 * Setting has a unique constraint on 'name' so there can only be one setting record for a 'name'.
	 * NOTE: Im using JPA's EntityManager and not Hibernate's SessionFactory. I could not get it to work using the SessionFactory
	 * 
	 * @param name
	 * @return Setting object or null if no settings record exists
	 */
	public Setting getSettingByName(String name){
		try{
			return (Setting)entityManager.createQuery("select s from Setting s where s.name = :name", Setting.class).setParameter("name", name).setLockMode( LockModeType.PESSIMISTIC_WRITE ).getSingleResult();
		}
		catch(NoResultException nre){
			return null;
		}
	}
	
	
	/**
	 * Example on how to use Spring's JdbcTemplate to query the database.
	 * 
	 * @param name
	 * @return List of quantities
	 */
	public List<Integer> getQuantities(String name){
		List<Integer> quantities = new ArrayList<Integer>();
		List<Map<String, Object>> rows = JdbcTemplate.queryForList("select quantity from setting where name=?", name);
		for(Map row : rows){
			quantities.add((Integer)row.get("quantity"));
		}
		return quantities;
	}

}
