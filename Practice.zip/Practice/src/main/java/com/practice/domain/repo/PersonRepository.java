package com.practice.domain.repo;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.practice.domain.model.Person;


public interface PersonRepository extends CrudRepository<Person, Long>{
	
	public List<Person> findAllByLast(String last);

}
