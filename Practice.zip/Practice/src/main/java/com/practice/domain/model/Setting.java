package com.practice.domain.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Contains global settings that apply to all users. 
 * CRUD operations against these fields can be performed by any user.
 * A database unique constraint is created for the 'name' field
 * 
 * @author alan
 *
 */
@Entity
@Table( indexes = { @Index(columnList ="name", name="setting_name_idx") },
		uniqueConstraints = { @UniqueConstraint(columnNames = "name") } )
public class Setting extends BaseModel{
	
	private Integer quantity; 
	private String name;

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Setting(){}
	 
	public Setting( Integer quantity, String name ){
		this.name = name;
		this.quantity = quantity;
		this.created = new Date();
		this.updated = new Date();
	}
	
}
