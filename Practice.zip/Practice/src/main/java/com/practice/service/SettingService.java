package com.practice.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import com.practice.domain.dao.SettingDao;
import com.practice.domain.model.Setting;
import com.practice.domain.repo.SettingRepository;


@Service
public class SettingService {
	
	@Autowired
	SettingDao settingDao;
	
	@Autowired
	SettingRepository settingRepository;
	
	/**
	 * If a settings object exists for the given name then update the quantity.
	 * If a settings object does not exist for the given name then create one. 
	 * Since any user can perform CRUD operations against a setting it should be pessimistically locked first. 
	 * Pessimistic locking is handled by SELECT * FOR UPDATE sql statements but I dont know if MySQL can handle pessimistic locking.
	 * The isolation level to use for pessimistic locking depends on the DBMS. (for PostgreSQL it should be READ_COMMITTED, but i dont know about MySQL)
	 * 
	 * @param name
	 * @return
	 */
	@Transactional(isolation=Isolation.READ_COMMITTED)
	public Setting createOrUpdateSetting(String name, Integer quantity){
		Setting setting = settingDao.getSettingByName(name);
		if( setting == null ){
			setting = settingRepository.saveAndFlush( new Setting(quantity, name) );
		}
		else{
			setting.setQuantity(quantity);
			setting.setUpdated(new Date());
		}
		return setting;
	}
	
	
	public List<Integer> getQuantities(String name){
		return settingDao.getQuantities(name);
	}

}
