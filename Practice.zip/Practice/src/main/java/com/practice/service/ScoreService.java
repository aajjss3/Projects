package com.practice.service;

import org.springframework.stereotype.Service;

@Service
public class ScoreService {

	
	public boolean displayField(){
		return true;
	}
}
