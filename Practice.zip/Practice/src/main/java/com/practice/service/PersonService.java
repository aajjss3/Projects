package com.practice.service;


import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Locale;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import com.practice.domain.model.Person;
import com.practice.domain.repo.PersonRepository;
import com.practice.dto.PersonDTO;
import com.practice.exception.InternalServerErrorException;
import com.practice.exception.NotFoundException;
import com.practice.util.log.BaseLogger.LogLevel;
import com.practice.util.mapper.PersonMapper;
import org.springframework.transaction.annotation.Transactional;



@Service
public class PersonService {
	
	
	@Autowired
	PersonRepository personRepository;
	
	@Autowired
	PersonMapper personMapper;
	
	// get messages from messages.properties file
	@Autowired
	MessageSource message;
	
	
	/**
	 * Cascade creating a Person, which will also create Pets if there are any associated with the Person
	 * @param dto
	 */
	@Transactional
	public void createPerson(PersonDTO dto){
		
		Person person = personMapper.personDtoToPerson(dto);
		
		// FYI... This code is being handled in the PersonMapperDecorator class
		// the following is required by hibernate to cascade create (to allow hibernate to auto create nested Pet objects when creating a Person).
		//Set<Pet> pets = person.getPets();
		//for(Pet pet : pets){
		//	pet.setPerson(person);
		//}
		
		try{
			personRepository.save(person);
		}	
		catch(Exception e){
			throw new InternalServerErrorException(message.getMessage( "person.save.failed", null, Locale.getDefault() ), LogLevel.SEVERE, e);
		}	

	}

	
	@Transactional(readOnly = true)
	public List<PersonDTO> getPersons(String name){
		List<Person> persons;
		try{
			persons = personRepository.findAllByLast(name);
		}
		catch(Exception e){
			throw new InternalServerErrorException(message.getMessage( "person.retrieve.failed", null, Locale.getDefault() ), LogLevel.SEVERE, e);
		}		
		if( persons == null || persons.size() == 0 ){
			throw new NotFoundException( message.getMessage( "person.find.name.failed", new String[]{name}, Locale.getDefault() ) );
		}
		
		List<PersonDTO> dtos = new ArrayList<PersonDTO>();
		for( Person person : persons ){
			PersonDTO dto = personMapper.personToPersonDto(person);
			dtos.add(dto);
		}

		return dtos;

	}
	
	@Transactional
	public void deletePerson(Long id){
		try{
			personRepository.delete(id);
		}
		catch(Exception e){
			throw new InternalServerErrorException(message.getMessage( "person.delete.failed", null, Locale.getDefault() ), LogLevel.SEVERE, e);
		}
	}
	

	/**
	 * Only update the Person, do not update any Pets associated with the person, even if Pet fields are passed in the JSON request. 
	 * @param dto
	 * @param id
	 * @return
	 */
	@Transactional
	public PersonDTO updatePerson( PersonDTO dto, Long id){
		
		Person person = null;
		try{
			person = personRepository.findOne(id);
		}
		catch(Exception e){
			throw new InternalServerErrorException(message.getMessage( "person.find.failed", null, Locale.getDefault() ), LogLevel.SEVERE, e);
		}
		if( person == null ){
			throw new NotFoundException(message.getMessage( "person.find.id.failed", new Long[]{id}, Locale.getDefault() ));
		}
		
		// only update fields on the Person entity if the corresponding field in the PersonDTO is not null/empty.
		// do not update or create any Pets records even if there are nested PetDTOs associated with the PersonDTO.
		// hibernate will commit the changed person fields when the method exits.
		Person updatedPerson = personMapper.updatePersonFromPersonDto(dto, person);
		
		// populate a PersonDTO with a value for all Person fields - independent of whether the field was updated (passed in) or not.
		// the populated PersonDTO will also contain any nested Pets associated with the Person. 
		PersonDTO personDTO = personMapper.personToPersonDto( updatedPerson );
		return personDTO;
		
	}
	
}
