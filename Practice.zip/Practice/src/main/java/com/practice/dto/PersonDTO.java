package com.practice.dto;

import java.util.Date;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.practice.util.Roles;
import com.practice.util.Types;
import com.practice.util.validation.annotation.CustomEnum;
import com.practice.util.validation.annotation.Role;
import com.practice.util.validation.group.PersonCreate;
import com.practice.util.validation.group.PersonUpdate;


public class PersonDTO {
	
	@JsonProperty(value="first_name")
	@NotNull(message = "{field.required}", groups={PersonCreate.class})
	private String firstName;
	
	@JsonProperty(value="last_name")
	private String lastName;
	
	@JsonProperty(value="date_of_birth")
	private Date dob;
		
	@Role(roles={Roles.ADMIN, Roles.SUPER_USER}, message = "{field.role.invalid}", groups={PersonCreate.class, PersonUpdate.class})
	private String role;
	
	@NotNull(message = "{field.required}", groups={PersonCreate.class, PersonUpdate.class})
	@CustomEnum(enumType = Types.class, message = "{field.type.invalid}", groups={PersonCreate.class, PersonUpdate.class})	
	private String type;
	
	@NotNull(message = "{field.required}", groups={PersonCreate.class})
	@Valid // required to validate any fields in PetDTO that have validation annotation (ex nickName)
	private Set<PetDTO> pets;

	
	public Set<PetDTO> getPets() {
		return pets;
	}
	public void setPets(Set<PetDTO> pets) {
		this.pets = pets;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}
