package com.practice.dto;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.practice.util.validation.group.PersonCreate;


public class PetDTO {
	
	@JsonProperty(value="nick_name")
	@NotNull(message = "{field.required}", groups={PersonCreate.class})
	private String nickName;
	
	private Integer age;
	
	private String category;

	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}


}
