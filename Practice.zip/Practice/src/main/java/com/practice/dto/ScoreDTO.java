package com.practice.dto;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * This DTO is annotated with @JsonFilter since whether to display a field name and value in the json response is dynamically determined during runtime based on the value of the field.
 * @author alan
 *
 */
@JsonFilter("scoreFilter")
public class ScoreDTO {
	
	private String grade;
	private String score;
	
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}


}
