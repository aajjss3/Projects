package com.practice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import com.practice.config.filter.jackson.ScoreFilter;
import com.fasterxml.jackson.databind.DeserializationFeature;

/**
 * Custom jackson configuration
 * 
 * @author alan
 *
 */
@Configuration
public class JacksonConfiguration {
	
	@Autowired
	ScoreFilter scoreFilter;
	
	public Jackson2ObjectMapperBuilder jacksonBuilder(){
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		builder.featuresToDisable(DeserializationFeature.ACCEPT_FLOAT_AS_INT);
		return builder;
	}
	
	
	/**
	 * Only include this method if adding a Jackson Filter (i.e. a class that contains a PropertyFilter field (as an example see ScoreFilter.java) and a DTO that is annotated with @JsonFilter (as an example see ScoreDTO.java))
	 * This method is the link that couples/marries the PropertyFilter with the DTO annotated with @JsonFilter.
	 * This filter is run when Jackson serialized the dto returned from the controller, after the controller is finished.
	 * 
	 * A Jackson Filter is used if you want to dynamically determined DURING RUNTIME if the field name and value should be returned in the JSON response. 
	 * If that functionality is not required, then there is no need to include this Bean (method) (NOTE: it might override some jackson defaults)
	 * @return
	 */
	@Bean
	public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter(){
		MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
		FilterProvider filter = new SimpleFilterProvider().addFilter("scoreFilter", (PropertyFilter)scoreFilter.filter);
		ObjectMapper mapper = Jackson2ObjectMapperBuilder.json().filters(filter).build();
		jsonConverter.setObjectMapper(mapper);
		return jsonConverter;

	}

}
