package com.practice.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * This class is run/called by spring when the application starts up. Its an example of creating spring beans that the application can use by injecting into a class using the Autowired annotation. 
 * @author alan
 *
 */
@Configuration
public class TestConfiguration {
	
	@Autowired Environment env;
	
	/**
	 * example of creating a bean instance
	 * @return
	 */
	@Bean
	@Qualifier("testBean")
	public Object test1() {
		return new Object();
	}
	

}
