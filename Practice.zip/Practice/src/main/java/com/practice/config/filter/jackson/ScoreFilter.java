package com.practice.config.filter.jackson;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
import com.fasterxml.jackson.databind.ser.PropertyFilter;
import com.fasterxml.jackson.databind.ser.PropertyWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.practice.dto.ScoreDTO;
import com.practice.service.ScoreService;


/**
 * Determine if a field name and value in the ScoreDTO should be displayed in the JSON response.
 * This will DYNAMICALLY determined DURING RUNTIME if the field name and value (not just the value) is returned in the JSON response based on the value of the field.
 * This filter is run when Jackson serialized the dto returned from the controller, after the controller is finished.
 * 
 * As an alternative, you could annotate the field in the DTO with @JsonIgnore or @JsonInclude(Include.NON_NULL) but that will either always exclude the field, or only include the field if the value is not null.
 * There are times when you might want to exclude a field name and value based on some more complex runtime condition, and that is when a PropertyFilter and @JsonFilter should be used.
 * For an example: see http://www.baeldung.com/jackson-serialize-field-custom-criteria
 * 
 * @author alan
 *
 */
@Component
public class ScoreFilter {
	
	// an example of injecting a service layer class for additional logic if needed
	@Autowired
	ScoreService scoreService;
	
	public PropertyFilter filter = new SimpleBeanPropertyFilter() {
		
		@Override
		public void serializeAsField(Object pojo, JsonGenerator jgen, SerializerProvider provider, PropertyWriter writer)  throws Exception {
			//By default, a field name and value is not displayed. Only display a field by calling writer.serializeAsField() on it.
			// this will only display the' grade' field name and value - if its value is 'A', and will only display a 'score' field name and value - if its values is '5'. AND also if the scoreService.displayField() returns true
		   if (include(writer)) {
			  if (writer.getName().equals("grade")  &&  scoreService.displayField()  &&  "A".equals( ((ScoreDTO) pojo).getGrade() )  ) {
				 writer.serializeAsField(pojo, jgen, provider);
				 return;
			  }
			  if (writer.getName().equals("score")  &&  scoreService.displayField() &&  "5".equals( ((ScoreDTO) pojo).getScore() )  ) {
				 writer.serializeAsField(pojo, jgen, provider);
				 return;
			  }
		   } else if (!jgen.canOmitFields()) {
			  writer.serializeAsOmittedField(pojo, jgen, provider);
		   }
		}
		
		@Override
		protected boolean include(BeanPropertyWriter writer) {
		   return true;
		}
		
		@Override
		protected boolean include(PropertyWriter writer) {
		   return true;
		}
		
	 };

}
