package com.glynlyon.kl.classroom.config

import org.hibernate.validator.HibernateValidator
import org.springframework.beans.factory.ObjectProvider
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.config.AutowireCapableBeanFactory
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary
import org.springframework.transaction.jta.JtaTransactionManager
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor
import org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory

import javax.sql.DataSource
import javax.validation.ConstraintValidatorFactory
import javax.validation.Validation
import javax.validation.Validator
import javax.validation.ValidatorFactory

@Configuration
public class HibernateValidationConfiguration extends HibernateJpaAutoConfiguration {

    @Autowired
    AutowireCapableBeanFactory autowireCapableBeanFactory


    HibernateValidationConfiguration(DataSource dataSource, JpaProperties jpaProperties, ObjectProvider<JtaTransactionManager> jtaTransactionManagerProvider, ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
        super(dataSource, jpaProperties, jtaTransactionManagerProvider, transactionManagerCustomizers)
    }

    @Override
    protected void customizeVendorProperties(Map<String, Object> vendorProperties) {
        super.customizeVendorProperties(vendorProperties);
        vendorProperties.put("javax.persistence.validation.factory", validatorFactory());
    }

    @Bean
    @Primary
    public ValidatorFactory validatorFactory () {
        return Validation.byProvider(HibernateValidator)
                .configure().constraintValidatorFactory(constraintValidatorFactory())
                .buildValidatorFactory()
    }

    @Bean
    @Primary
    public ConstraintValidatorFactory constraintValidatorFactory(){
        return new SpringConstraintValidatorFactory(autowireCapableBeanFactory)
    }
}