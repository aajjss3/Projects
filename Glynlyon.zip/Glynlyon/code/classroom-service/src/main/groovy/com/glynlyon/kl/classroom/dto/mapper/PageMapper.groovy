package com.glynlyon.kl.classroom.dto.mapper

import java.lang.reflect.Field
import java.util.List
import com.glynlyon.kl.classroom.dto.PageAssignmentDTO
import com.glynlyon.kl.classroom.dto.AssignmentDTO
import com.glynlyon.kl.classroom.dto.PageDTO
import com.glynlyon.kl.classroom.dto.ClassDTO
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

/**
 * Migrates data from an PageDTO to an PageObj and visa versa.
 * 
 *
 */
@Component
class PageMapper extends AbstractMapper{
	
	@Autowired
	PageAssignmentRepo pageAssignmentRepo
	
	
		
	protected void custom (Object source, Object destination, boolean mapIfNull){
		if (source instanceof PageDTO){
			Class clazz = source.getClass()
			// An HTTP Patch will only include a field in the request if it should be updated. Since non-required Page fields can be updated to null, check if the non-required fields existed in the json request and if the value passed in was null.
			// If so, set the corresponding page field to null
			if ( !((PageDTO)source).getName() && ((PageDTO)source).requestFields.contains("name")){
				((PageObj)destination).name = null
			}
			if ( !((PageDTO)source).getDueDate() && ((PageDTO)source).requestFields.contains("dueDate")){
				((PageObj)destination).dueDate = null
			}
			if ( !((PageDTO)source).getCompletedDate() && ((PageDTO)source).requestFields.contains("completedDate")){
				((PageObj)destination).completedDate = null
			}
			if( ((PageDTO)source).getStatus() ){
				((PageObj)destination).status = ((PageDTO)source).getStatusAsEnum()
			}	
		}
		if( source instanceof PageObj){
			if( ((PageObj)source).status ){
				((PageDTO)destination).setStatusAsEnum( ((PageObj)source).status )
			}
			
			// populate the nested object graph
			List<PageAssignment> pageAssignments = pageAssignmentRepo.findAllByPageObjUuidOrderBySequenceAsc(((PageObj)source).uuid)
			List<PageAssignmentDTO> pageAssignmentDTOs = new ArrayList<PageAssignmentDTO>()
			for( PageAssignment pageAssignment : pageAssignments ){
				PageAssignmentDTO pageAssignmentDTO = baseMapper.defaultMapAll( pageAssignment, PageAssignmentDTO.class )
				pageAssignmentDTO.setAssignment( baseMapper.defaultMapAll( pageAssignment.assignment, AssignmentDTO.class ) )
				pageAssignmentDTOs.add(pageAssignmentDTO)
			}
			((PageDTO)destination).setClazz( baseMapper.defaultMapAll( ((PageObj)source).classObj, ClassDTO.class ) )
			((PageDTO)destination).setPageAssignments(pageAssignmentDTOs)
			
		}
	}

}
