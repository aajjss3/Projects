package com.glynlyon.kl.classroom.dto.grade

public class GpaScoresInput {
    List<Question> questions
    Settings settings
    Learnosity learnosity
    String user_id

    static class Question {
        String id
        BigDecimal score
        BigDecimal max_score
        String type
    }

    static class Settings {
        Integer threshold
    }

    static class Learnosity {
        String session_id
        String client_domain
    }

}