package com.glynlyon.kl.classroom.constraints.annotation

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target
import javax.validation.Constraint
import com.glynlyon.kl.classroom.constraints.validator.StudentRoleValidator
import javax.validation.Payload

@Target([ElementType.FIELD, ElementType.TYPE, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = StudentRoleValidator.class)
@Documented
@Inherited
public @interface StudentRole {
	String message() default "not a student"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
