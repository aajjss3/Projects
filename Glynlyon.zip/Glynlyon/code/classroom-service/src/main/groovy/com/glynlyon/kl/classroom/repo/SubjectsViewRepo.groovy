package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.UuidOrgId
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.CrudRepository

interface SubjectsViewRepo extends CrudRepository<SubjectsView, UuidOrgId>, JpaSpecificationExecutor, LocalRepo<SubjectsView>{

    SubjectsView findByNameIgnoreCaseAndOrganizationUuid(String name, UUID orgUuid)
    SubjectsView findByNameIgnoreCaseAndOrganizationUuidAndUuidNot(String name, UUID orgUuid, UUID uuid)
    SubjectsView findByOrganizationUuid(UUID organization_uuid)
	SubjectsView findByOrganizationUuidAndUuid(UUID organizationUuid, UUID subjectUuid)
}