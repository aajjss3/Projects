package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.PlannerEntry
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface PlannerEntryRepo extends PagingAndSortingRepository<PlannerEntry, UUID>, LocalRepo<PlannerEntry>, JpaSpecificationExecutor<PlannerEntry> {
    List<PlannerEntry> findAllByUserUuidAndSlot(UUID userUuid, Integer slot)
    Long countByUserUuidAndSlot(UUID userUuid, Integer slot)
	List<PlannerEntry> findAllByUserUuidAndClassObjUuid(UUID userUuid, UUID classObjUuid)
    List<PlannerEntry> deleteAllByClassObjUuid(UUID classObjUuid)

    List<PlannerEntry> findAllByAttemptsAndPageObjUuid(List<Attempt> attempts, UUID pageUuid)
    List<PlannerEntry> findAllByAttemptsAndClassObjUuid(List<Attempt> attempts, UUID classUuid)
}
