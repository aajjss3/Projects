package com.glynlyon.kl.classroom.exceptions

class OrgNotFoundException extends RuntimeException {
    OrgNotFoundException() {
        super()
    }

    OrgNotFoundException(String message) {
        super(message)
    }

    OrgNotFoundException(String message, Throwable cause) {
        super(message, cause)
    }

    OrgNotFoundException(Throwable cause) {
        super(cause)
    }

    protected OrgNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
