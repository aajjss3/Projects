package com.glynlyon.kl.classroom.constraints.group

interface OrganizationSetting {

}
