package com.glynlyon.kl.classroom.config

import com.glynlyon.kl.classroom.auth.JwtAuthenticationFilter
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.builders.WebSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter


@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Value('${jwt.secret.key}')
    String secret

    @Override
    public void configure(WebSecurity webSecurity) throws Exception {
        webSecurity
                .ignoring()
                .antMatchers("/health")
                .antMatchers("/info")
                .antMatchers("/launches/?*")
                .antMatchers("/issuerlaunches/?*")
    }

    @Override
    protected void configure(HttpSecurity auth) throws Exception {
        http
                .csrf().disable()
                .addFilterAfter(new JwtAuthenticationFilter(secret), BasicAuthenticationFilter)
    }
}