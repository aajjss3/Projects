package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import org.springframework.beans.factory.annotation.Autowired

class CustomAcademicSessionDeserializer extends StdDeserializer<AcademicSession> {

    @Autowired
    AcademicSessionRepo academicSessionRepo

    protected CustomAcademicSessionDeserializer() {
        super(AcademicSession)
    }

    @Override
    public AcademicSession deserialize(
            JsonParser p,
            DeserializationContext ctx)
            throws IOException, JsonProcessingException {

        return LocalDeserializerHelper.deserialize(p, ctx, academicSessionRepo, "academic_session_uuid", "academic session")
    }
}
