package com.glynlyon.kl.classroom.constraints

import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.UserRepo
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class MatchingEnrollmentRoleValidator implements ConstraintValidator<MatchingEnrollmentRole, Enrollment> {

    @Autowired
    UserRepo userRepo

    @Override
    void initialize(MatchingEnrollmentRole constraintAnnotation) {}

    @Override
    boolean isValid(Enrollment enrollment, ConstraintValidatorContext context) {

        Role role = enrollment.role

        AppUserType type = enrollment.user?.type
        Boolean valid = !role || !type || (type && validRoleType(role, type))

        if(!valid){
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate()).addPropertyNode("role").addConstraintViolation()
        }
        return valid
    }

    private static boolean validRoleType(Role role, AppUserType appUserType) {
        switch (role){
            case Role.ADMINISTRATOR:
                return AppUserType.ADMIN.equals(appUserType)
            case Role.STUDENT:
                return AppUserType.STUDENT.equals(appUserType)
            case Role.TEACHER:
                return AppUserType.TEACHER.equals(appUserType)
            default:
                return false
        }
    }
}
