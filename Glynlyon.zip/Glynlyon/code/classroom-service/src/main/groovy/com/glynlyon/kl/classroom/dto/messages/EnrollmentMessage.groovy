package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonIgnore

abstract class EnrollmentMessage {

    @JsonIgnore
    abstract String container
}
