package com.glynlyon.kl.classroom.service

import com.fasterxml.jackson.databind.BeanDescription
import com.fasterxml.jackson.databind.JavaType
import com.fasterxml.jackson.databind.JsonMappingException
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.exc.InvalidFormatException
import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition
import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.exceptions.FieldNotFoundException
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.validation.ConstraintViolation
import javax.validation.Validator

@Service
class InputMapperService {

    Logger logger = LogManager.getLogger(InputMapperService)

    @Autowired
    ObjectMapper mapper

    @Autowired
    Validator validator


    public <T> MappingResult<T> processInput(ObjectNode json, Class<T> clazz){
        List errorVals = []
        def mappingResult = processInputHelper(json, clazz)
        while(mappingResult.error){
            errorVals << mappingResult.error
            mappingResult = processInputHelper(json, clazz)
        }
        return new MappingResult<T>(obj: mappingResult.obj, errors: errorVals)
    }

    public List mergeErrors(List existingErrors, Set<ConstraintViolation> errors, Class clazz){

        List ret = new ArrayList(existingErrors)
        def properties = getClassProperties(clazz)

        def fieldErrors =  errors.findAll{it?.propertyPath?.toString()}.collect{ error ->
            def field = properties.find{prop ->
                prop.internalName == error.propertyPath.toString() && prop.couldDeserialize()
            }.name
            def message = error.message
            return [field: field, message: message]
        }.findAll{ error ->
            !existingErrors.any { e ->
                // second clause added for SAT-2690 to prevent 'required field' state errors
                // from appearing alongside 'invalid value' status errors
                // TODO: can be removed when 'state' is removed from ClassObj
                e.field == error.field || (e.field == "status" && error.field == "state")
            }
        }
        ret.addAll(fieldErrors)
        return ret
    }

    private <T> Map processInputHelper(ObjectNode json, Class<T> clazz){
        T obj = null
        def error = null
        try {
            obj = mapper.convertValue(json, clazz)
        }
        catch(Throwable t){
            if(t?.cause?.cause instanceof FieldNotFoundException){
                FieldNotFoundException fieldNotFoundException = (FieldNotFoundException)t.cause.cause
                String field = fieldNotFoundException.field
                String message = fieldNotFoundException.message
                error = [field: field, message: message]
                json.remove(field)
            }
            else if (t?.cause instanceof InvalidFormatException || t?.cause instanceof JsonMappingException) {
                String field = t.cause._path.fieldName[0]
                String fullField = t.cause._path.fieldName.join('.')
                String message = "Invalid value for " + fullField
                try{
                    message += " " + t.cause?._value
                    if(t.cause._value instanceof Integer && t.cause.message.contains("FAIL_ON_NUMBERS_FOR_ENUMS")){
                        message += " (hint: enum values must be Strings)"
                    }
                } catch (MissingPropertyException){}
                error = [field: fullField, message: message]
                json.remove(field)
            }
            else{
                logger.error("Couldn't continue processing input [" + json + "]", t)
            }
        }
        return [obj: obj, error: error]
    }


    private List<BeanPropertyDefinition> getClassProperties(Class clazz){
        JavaType userType = mapper.getTypeFactory().constructType(clazz)
        BeanDescription introspection = mapper.getSerializationConfig().introspect(userType)
        List<BeanPropertyDefinition> properties = introspection.findProperties()
        return properties
    }

    class MappingResult<T>{
        T obj
        List errors
    }
}
