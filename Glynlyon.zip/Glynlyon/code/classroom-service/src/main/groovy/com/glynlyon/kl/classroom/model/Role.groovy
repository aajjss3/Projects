package com.glynlyon.kl.classroom.model

public enum Role {
    TEACHER("teachers"),
    STUDENT("students"),
    AIDE("aides"),
    ADMINISTRATOR("admins")

    public final String countKeyName

    Role(String countKeyName){
        this.countKeyName = countKeyName
    }
}