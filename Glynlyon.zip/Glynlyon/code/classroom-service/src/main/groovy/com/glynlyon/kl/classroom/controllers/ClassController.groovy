package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.exceptions.ClassObjNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.ClassService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

@RestController
class ClassController extends AbstractController {

    @Autowired
    ClassService classService

    @Autowired
    ClassRepo classRepo

    @Autowired
    ClassGradeLevelService classGradeLevelService

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    PageableService pageableService

    @RequestMapping(path = "/classes", method = RequestMethod.GET, produces = Constants.CLASSES_VERSION_1)
    ResponseEntity<?> getClasses(@RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestParam(name = "user_uuid", required = false) String enrolledUser,
            @RequestParam(name = "excludeExpiredClasses", required = false) Boolean excludeExpiredClasses,
            @RequestHeader(name = "authorization") String auth){

        String token = auth.substring(7)
        sort = sort?.replaceAll("status", "state")
        Page page = null
        HttpHeaders responseHeaders = null
        UUID enrolledUserUuid = null
        try {
            enrolledUserUuid = enrolledUser ? UUID.fromString(enrolledUser) : null
        }
        catch (IllegalArgumentException e){
            page = new PageImpl([new ErrorOutput(field: "user_uuid", message: "invalid uuid ${enrolledUser}")])
        }

        if(!page) {
            try {
                Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_CLASS_SORT, ClassObj, ["organization"])
                page = classService.findAllClasses(token, filter, enrolledUserUuid, excludeExpiredClasses, pageable)
                responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
            }
            catch (UnsupportedFieldException e) {
                page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
            }
            catch (Throwable t){
                logger.error(t)
            }
        }

        PagedResponse.createResponse("classes", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }

    @RequestMapping(path = "/classes/{uuid}", method = RequestMethod.GET, produces = Constants.CLASSES_VERSION_1)
    ResponseEntity<?> getClass(@PathVariable('uuid') UUID uuid,
                                 @RequestHeader(name = "authorization") String auth){
        String token = auth.substring(7)
        ClassObj returnedClass
        try {
            returnedClass = classService.findClass(token, uuid)
        }
        catch(ClassObjNotFoundException e){
            return new ResponseEntity([errors: [field: e.field, message: e.message]], HttpStatus.valueOf(e.status.toInteger()))
        }

        return new ResponseEntity(returnedClass, HttpStatus.OK)
    }

    @RequestMapping(path = "/classes", method = RequestMethod.POST, produces = Constants.CLASSES_VERSION_1, consumes = Constants.CLASSES_VERSION_1)
    ResponseEntity<?> createClass(@RequestBody ObjectNode json, HttpServletRequest req,
                                    @RequestHeader(name = "authorization") String auth) {

        String token = auth.substring(7)
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)

        def mappingResult = inputMapperService.processInput(json, ClassObj)
        ClassObj input = mappingResult.obj
        if (input == null) {
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        input.created = new Date()
        input.updated = new Date()
        input.uuid = null

        if(role == AppUserType.TEACHER && input.organization.uuid == orgUuid) {
            return ResponseEntity.badRequest().body([errors: [["field": "organization_uuid", message: "TEACHER can not create classes using school UUID " + orgUuid]]])
        }

        try {
            ClassObj classObj = classService.create(input, mappingResult, token)
            classObj = classService.addTransients(classObj)
            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/classes/" + classObj.uuid)).body(classObj)
        } catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, ClassObj)])
            }
            if(t instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, ClassObj)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @RequestMapping(path = "/classes/{uuid}", method = RequestMethod.PUT, produces = Constants.CLASSES_VERSION_1, consumes = Constants.CLASSES_VERSION_1)
    ResponseEntity<?> updateClass(@RequestBody ObjectNode json, @PathVariable UUID uuid, @RequestHeader(name = "authorization") String auth) {

        String token = auth.substring(7)
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)
        ClassObj existing = classRepo.findByUuid(uuid)
        if (existing == null) {
            return ResponseEntity.badRequest().body([errors: [["field": "uuid", message: "Invalid class uuid " + uuid]]])
        }
        def mappingResult = inputMapperService.processInput(json, ClassObj)
        ClassObj input = mappingResult.obj

        if (input == null) {
            return ResponseEntity.badRequest().body("Couldn't process input")
        }
        input.uuid = uuid
        input.created = existing.created
        input.version = existing.version
        input.updated = new Date()

        if(role == AppUserType.TEACHER && input.organization.uuid == orgUuid) {
            return ResponseEntity.badRequest().body([errors: [["field": "organization_uuid", message: "TEACHER can not update classes using school UUID " + orgUuid]]])
        }

        if (input.state == ClassObjState.COMPLETED) {
            input.completed = input.completed?: new Date();
        }
        if (input.done) {
            input.doneDate = new Date()
        }
        else {
            input.done = false
            input.doneDate = null
        }
        try {
            ClassObj classObj = classService.update(input, mappingResult, token)
            classObj = classService.addTransients(classObj)
            return ResponseEntity.ok().body(classObj)
        } catch (Throwable t) {

            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, ClassObj)])
            }
            else if(t instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, ClassObj)])
            }
            else if (t instanceof ClassObjNotFoundException) {
                return ResponseEntity.badRequest().body([errors: [field: t.field, message: t.message]])
            }
            else {
                logger.error(t)
                return ResponseEntity.badRequest().body([errors: mappingResult.errors])
            }


        }
    }

    @DeleteMapping(path = "/classes/{uuid}")
    ResponseEntity<?> deleteClass(@PathVariable('uuid') UUID uuid, @RequestHeader(name = "authorization") String auth){
        String token = auth.substring(JWT_STARTING_INDEX)
        classService.delete(uuid, token)

        return ResponseEntity.noContent().build()
    }

}
