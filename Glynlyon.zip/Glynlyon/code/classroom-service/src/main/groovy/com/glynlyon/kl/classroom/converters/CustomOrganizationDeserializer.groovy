package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import org.springframework.beans.factory.annotation.Autowired

class CustomOrganizationDeserializer extends StdDeserializer<Organization> {

    @Autowired
    OrganizationRepo organizationRepo

    protected CustomOrganizationDeserializer() {
        super(Organization)
    }

    @Override
    public Organization deserialize(
            JsonParser p,
            DeserializationContext ctx)
            throws IOException, JsonProcessingException {

        return LocalDeserializerHelper.deserialize(p, ctx, organizationRepo, "organization_uuid", "organization")
    }
}

