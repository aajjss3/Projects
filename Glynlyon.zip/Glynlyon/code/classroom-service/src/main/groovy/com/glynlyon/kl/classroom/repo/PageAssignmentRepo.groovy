package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.PageAssignment
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface PageAssignmentRepo extends PagingAndSortingRepository<PageAssignment, UUID>, LocalRepo<PageAssignment>, JpaSpecificationExecutor<PageAssignment>, JpaRepository<PageAssignment, UUID> {
    List<PageAssignment> findAllByPageObjUuid(UUID pageUuid)
    Page<PageAssignment> findAllByPageObjUuid(UUID pageUuid, Pageable pageable)
    List<PageAssignment> findAllByPageObjUuidOrderBySequenceAsc(UUID pageUuid)
    PageAssignment findOneByUuid(UUID uuid)
    PageAssignment findOneByPageObjUuidAndSequence(UUID pageUuid, Integer sequence)

    PageAssignment findByPageObjUuidAndUuid(UUID pageUuid, UUID pageAssignmentUuid)
    PageAssignment findByPageObjUuidAndAssignmentUuid(UUID pageUuid, UUID assignmentUuid)

    List<PageAssignment> deleteAllByPageObjClassObjUuid(UUID classObjUuid)
}
