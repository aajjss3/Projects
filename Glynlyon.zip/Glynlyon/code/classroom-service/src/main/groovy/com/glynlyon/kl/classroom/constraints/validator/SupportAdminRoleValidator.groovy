package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.SupportAdminRole
//import com.glynlyon.kl.classroom.exceptions.UnauthorizedException
import com.glynlyon.kl.classroom.model.AppUserType

class SupportAdminRoleValidator extends AbstractValidator implements ConstraintValidator<SupportAdminRole, String>{

	// only allow if the role is SUPPORT_ADMINISTRATOR

    @Override
    void initialize(SupportAdminRole constraintAnnotation) {

    }

    public boolean isValid(String auth, ConstraintValidatorContext constraintContext) {
		AppUserType role = jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) )
		if ( role != AppUserType.SUPPORT_ADMINISTRATOR ){
			return false
		}
		return true
	}
	
}
