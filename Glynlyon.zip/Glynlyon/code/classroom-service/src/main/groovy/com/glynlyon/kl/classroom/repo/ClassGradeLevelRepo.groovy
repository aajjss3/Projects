package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.Grade
import org.springframework.data.repository.CrudRepository

import javax.transaction.Transactional

interface ClassGradeLevelRepo extends CrudRepository<ClassGradeLevel, UUID>{

    List<ClassGradeLevel> findAllByClassUuid(UUID classUuid)
    @Transactional
    List<ClassGradeLevel> deleteAllByGradeInAndClassUuid(List<Grade> grades, UUID classUUID)
}
