package com.glynlyon.kl.classroom.dto.grade

class OutcomeResponse {
    Double score
    OutcomeStatus status
}
