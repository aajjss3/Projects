package com.glynlyon.kl.classroom.controllers.handler

import com.glynlyon.kl.classroom.dto.PaginationDTO
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice
import org.springframework.core.MethodParameter
import org.springframework.data.domain.Page
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import org.springframework.http.converter.HttpMessageConverter
import org.springframework.http.server.ServerHttpRequest
import org.springframework.http.server.ServerHttpResponse


/**
 * Add http header fields to the response for all controller methods that return paginated data (i.e. if the response body contains a 'page' field that is an instance of Page).
 * 
 */
@ControllerAdvice
class CustomPaginationHeader implements ResponseBodyAdvice<Object>{
	
	public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
		return true
	}
	

	/**
	 * Add http header fields to the response for all controller methods that return paginated data (i.e. if the response body contains a 'page' field that is an instance of Page).
	 */
	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
		if( body && body instanceof PaginationDTO && body.page && body.page instanceof Page){
			Page page = body.page
			HttpHeaders newHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
			HttpHeaders existingHeaders = response.getHeaders()
			Set<Map.Entry<String, List<String>>> entries = newHeaders.entrySet()
			for( Map.Entry entry : entries ){
				for( String value : entry.getValue()){
					existingHeaders.add(entry.getKey(), value)
				}
			}
		}	
		return body
	}

}
