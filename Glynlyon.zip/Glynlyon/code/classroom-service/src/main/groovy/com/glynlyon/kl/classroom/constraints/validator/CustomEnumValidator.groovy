package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.CustomEnum
import com.glynlyon.kl.classroom.util.EventEnum


/**
 * Determien if the Object passed in is a valid enum. 
 * The object can either be a String representing the enum name or it can be an Enum
 * 
 */
class CustomEnumValidator implements ConstraintValidator<CustomEnum, Object>{
	
	// variable that contains the custom enum class
	private Class enumType
	
	// if this field is required
	private boolean required
	
	@Override
	public void initialize(CustomEnum constraintAnnotation) {
		this.enumType = constraintAnnotation.enumType()
		this.required = constraintAnnotation.required()
	}

	/**
	 * value is either of type String or an Enum class
	 */
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if (!value ){
			if( !required ){
				return true
			}
			else{
				return false
			}	
		}
		Enum[] enumerations = enumType.getEnumConstants()
		for (Enum enumeration : enumerations) {
			String enumName
			if ( enumeration.name().equalsIgnoreCase( ( value instanceof Enum )? value.name() : value ) ) {
				return true
			}
		}
		return false
	}

}
