package com.glynlyon.kl.classroom.model

public enum AppUserType {
    ADMIN("Admin"),
    TEACHER("Teacher"),
    STUDENT("Student"),
    SUPPORT_ADMINISTRATOR("Administrator"),
    PARENT("Parent"),
    SUPPORT_LICENSING("Licensing User"),
    SUPPORT_USER("Support User"),
    SUPPORT_CEM("CEM User");

    private final String displayName;

    AppUserType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return this.displayName;
    }
}