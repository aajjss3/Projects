package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.FutureDate


class FutureDateValidator  implements ConstraintValidator<FutureDate, Date>{
		
	// if this field is required
	private boolean required
	
	@Override
	public void initialize(FutureDate constraintAnnotation) {
		this.required = constraintAnnotation.required()
	}

	@Override
	public boolean isValid(Date value, ConstraintValidatorContext context) {
		if (!value ){
			if( !required ){
				return true
			}
			else{
				return false
			}
		}
		if ( value >= new Date()){
			return true
		}
		else{
			return false
		}
	}

}

