package com.glynlyon.kl.classroom.util

import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.service.SettingService
import java.math.BigDecimal
import java.util.Map
import java.util.UUID
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component

@Component
class ScoreMapUtil {
	
	@Autowired
	SettingService settingService
	
	/**
	 * Determine the grade/ for the numeric score passed in and return a map with either the grade, numeric score or both depending on the settings for the class uuid passed in
	 *
	 * @param classUUID
	 * @param score - single numeric score
	 * @return
	 */
	public Map<String, Object> getScoreAsMap(UUID classUUID, BigDecimal score){
		SettingDTO dto = settingService.findClassSettings(classUUID)
		Boolean isLetter = dto.value.classroom.gradeDisplay.letter
		Boolean isPercentage = dto.value.classroom.gradeDisplay.percentage
		Map<String, Double> scales = dto.value.classroom.gradeScale
		
		return getScoreAsMap(isLetter, isPercentage, scales, score)
		
	}
	
	
	/**
	 * Determine the grade for the numeric score passed in and return a map with either the grade, numeric score or both depending on the isLetter, isPercentage and scales passed in
	 * UI expects a null value and not an empty map if both letter and score are null (representing an in-progress attempt)
	 * @param isLetter
	 * @param isPercentage
	 * @param scales
	 * @param score - single numeric score
	 * @return
	 */
	public Map<String, Object> getScoreAsMap(Boolean isLetter, Boolean isPercentage, Map<String, Double> scales, Number score){
		Map<String, Object> map = new HashMap<String, Object>()
		if( isLetter ){
			if( !scales.isEmpty() && score ){
				// since there is a need to break out of the following loop, use a java 'for' loop and not a groovy 'map.each' closure
				Map<String,Double> sortedScales = scales.sort{ a, b -> b.value <=> a.value } // sorted in descending order
				boolean found = false
				for(Map.Entry<String, Double> entry : sortedScales.entrySet()) {
					if(score.doubleValue()*100d >= entry.getValue().doubleValue()){
						map.put("grade", entry.getKey())
						found = true
						break
					}
					// if there is no corresponding letter then set to null
					if( !found ){
						map.put("grade", null)
					}
				}
			}
			// if there is no scale or score is null then set to null
			else{
				map.put("grade", null)
			}
		}

		if( isPercentage ){
			map.put("value", score)
		}

		if(!map.grade && score == null) {
			map = null
		}
		return map
	}

}
