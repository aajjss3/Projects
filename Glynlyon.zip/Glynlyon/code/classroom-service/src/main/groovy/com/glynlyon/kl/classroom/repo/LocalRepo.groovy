package com.glynlyon.kl.classroom.repo

interface LocalRepo<T> {
    T findByUuid(UUID uuid)
}