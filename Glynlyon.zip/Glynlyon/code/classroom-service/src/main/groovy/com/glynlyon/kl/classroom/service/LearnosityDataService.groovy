package com.glynlyon.kl.classroom.service

import com.glynlyon.learnosity.client.LearnosityDataClient
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service

@Service
class LearnosityDataService {

	@Value('${learnosity.secret}')
    String learnositySecret

    @Value('${learnosity.key}')
    String learnosityKey

    LearnosityDataClient getClient(String domain) {
		return new LearnosityDataClient(learnosityKey, learnositySecret, domain)
	}
}

