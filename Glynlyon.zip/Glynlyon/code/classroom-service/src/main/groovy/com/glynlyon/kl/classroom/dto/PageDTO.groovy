package com.glynlyon.kl.classroom.dto

import java.util.Date
import java.util.UUID
import javax.validation.GroupSequence
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.constraints.annotation.CustomEnum
import com.glynlyon.kl.classroom.constraints.annotation.FutureDate
import com.glynlyon.kl.classroom.constraints.annotation.NotNullFieldsInRequest
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.constraints.group.PagePatch


/**
 * The fields: updatedBy and updatedAt are imported during deserialization but not exported during serialization (see placement of the @JsonIgnore and @JsonProperty annotations)
 * The fields: uuid and classUUID and pageAssignments are exported during serialization but not imported during deserialization (see placement of the @JsonIgnore and @JsonProperty annotations)
 * Since this DTO is used for a HTTP PATCH, each setter method will add the name of field that is being set to a collection of strings stored in the BaseDTO. This is used during validation and during dto to entity mapping to determine if the input json contains the field in the request
 */
@NotNullFieldsInRequest(message = "{input.field.cannot.be.null}", groups=[PagePatch.class], fields = ["status", "type", "sequence"]) // list of fields that cannot be null if present in the json request 
class PageDTO extends BaseDTO{
	
	
	@JsonIgnore
	private UUID uuid 
	
	@JsonIgnore
	private Date updatedAt
	
	@JsonIgnore
	private ClassDTO clazz
	
	@JsonProperty(value="name")
	private String name 
	
	@JsonProperty(value="status")
	@CustomEnum(enumType=PageState.class, message = "{input.field.status}", required=false, groups=[PagePatch.class])
	private String status
	
	@JsonProperty(value="type")
	private String type
	
	@JsonProperty(value="sequence")
	@Min(value = 1L, message = "{input.integer.min}", groups=[PagePatch.class])
	private Integer sequence
	
	@JsonProperty(value = "completed_date")
	private Date completedDate
	
	@JsonProperty(value = "due_date")
	private Date dueDate
		
	@JsonIgnore
	private List<PageAssignment> pageAssignments
	

	@JsonProperty(value="page_uuid")
	public UUID getUuid() {
		return uuid;
	}

	@JsonIgnore
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	@JsonIgnore
	public Date getUpdatedAt() {
		return updatedAt;
	}

	@JsonProperty(value = "updated_at")
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	@JsonProperty(value = "class")
	public ClassDTO getClazz() {
		return clazz;
	}

	@JsonIgnore
	public void setClazz(ClassDTO clazz) {
		this.clazz = clazz;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		requestFields.add("name") // used for an HTTP PATCH
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		requestFields.add("status") // used for an HTTP PATCH
		this.status = status;
	}
	
	// helper method that returns status as an enum
	@JsonIgnore
	public PageState getStatusAsEnum() {
		return PageState.valueOf(this.status)
	}
	// helper method that sets status based on an enum
	@JsonIgnore
	public void setStatusAsEnum(PageState status) {
		this.status = status.name()
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		requestFields.add("type") // used for an HTTP PATCH
		this.type = type;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		requestFields.add("sequence") // used for an HTTP PATCH
		this.sequence = sequence;
	}

	public Date getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Date completedDate) {
		requestFields.add("completedDate") // used for an HTTP PATCH
		this.completedDate = completedDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		requestFields.add("dueDate") // used for an HTTP PATCH
		this.dueDate = dueDate;
	}

	@JsonProperty(value = "page_assignments")
	public List<PageAssignment> getPageAssignments() {
		return pageAssignments;
	}

	@JsonIgnore
	public void setPageAssignments(List<PageAssignment> pageAssignments) {
		this.pageAssignments = pageAssignments;
	}

}


public class PageAssignmentDTO{
	
	private Integer sequence
	
	@JsonProperty(value = "page_assignment_uuid")
	private UUID uuid
	
	private AssignmentDTO assignment

	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	public UUID getUuid() {
		return uuid;
	}
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	public AssignmentDTO getAssignment() {
		return assignment;
	}
	public void setAssignment(AssignmentDTO assignment) {
		this.assignment = assignment;
	}
	
}

public class AssignmentDTO{
	
	@JsonProperty(value = "assignment_uuid")
	private UUID uuid

	@JsonProperty(value = "assignment_type")
	private AssignmentType type

	@JsonProperty(value = "assignment_title")
	private String title

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public AssignmentType getType() {
		return type;
	}

	public void setType(AssignmentType type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
		
}

public class ClassDTO{
	
	@JsonProperty(value = "class_uuid")
	private UUID uuid
	
	private String name
	
	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}

