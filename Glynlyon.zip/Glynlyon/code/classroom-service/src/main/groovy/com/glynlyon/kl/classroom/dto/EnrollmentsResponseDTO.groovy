package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty

/**
 * DTO that is used to return a collection of deleted enrollments (successful and unsuccessful) to the client
 * @author asparago
 *
 */
public class EnrollmentsResponseDTO {
	public List<Success> successes
	public List<Failure> failures
}


class Success{
	@JsonProperty(value="enrollment_uuid")
	public String enrollmentUUID

	@JsonProperty(value = "user_uuid")
	public String userUuid
}


class Failure{
	@JsonProperty(value="enrollment_uuid")
	public String enrollmentUUID
	public List<Error> errors
}


class Error{
	public String field
	public String message
}