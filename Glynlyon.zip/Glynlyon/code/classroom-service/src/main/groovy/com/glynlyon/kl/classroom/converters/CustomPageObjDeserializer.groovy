package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.exceptions.FieldNotFoundException
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

class CustomPageObjDeserializer extends StdDeserializer<PageObj> {

    @Autowired
    PageRepo pageRepo

    @Autowired
    JwtService jwtService

    protected CustomPageObjDeserializer() {
        super(PageObj)
    }

    @Override
    public PageObj deserialize(
            JsonParser p,
            DeserializationContext ctx)
            throws IOException, JsonProcessingException {

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String token = req.getHeader("Authorization").substring(7)
        UUID orgUuid = jwtService.getOrgUuid(token)

        UUID uuid = UUID.fromString(p.getValueAsString())
        PageObj obj = pageRepo.findOne(uuid)
        if (obj == null) {
            throw new FieldNotFoundException("page_uuid", "Could not find page with uuid ${uuid}")
        }
        return obj
    }
}

