package com.glynlyon.kl.classroom.model

import groovy.lang.GroovyObject
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import java.io.Serializable
import java.util.Date
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.Enumerated
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.TypeDef
import org.hibernate.annotations.TypeDefs
import org.hibernate.annotations.Type
import com.fasterxml.jackson.annotation.JsonIgnore
import com.glynlyon.clt.hibernate.JsonbUserType
import com.glynlyon.kl.classroom.hibernate.HstoreUserType
import org.hibernate.annotations.Parameter
import javax.persistence.EnumType


@Entity
@ToString
@EqualsAndHashCode
@DynamicInsert
@Table(name="setting", indexes = [ @Index(columnList ="source_uuid", name="setting_source_idx"), @Index(columnList ="type", name="setting_type_idx") ])
@TypeDefs([
	@TypeDef(name = 'jsonb', typeClass = JsonbUserType)
])
class Setting  extends BaseEntity implements Serializable, GroovyObject{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public UUID uuid
	
	@Column(name = "created_at")
	Date createdAt

	@Column(name = "updated_at")
	Date updatedAt
	
	@Column(name = "created_by")
	public UUID createdBy
	
	@Column(nullable = false)
	@Enumerated(EnumType.STRING)
	public SettingType type
	
	@Column(name = "source_uuid", unique=true)
	public UUID sourceUUID

	@Type(type = 'jsonb', parameters = [@Parameter(name = 'jsonClass', value = 'java.util.HashMap')])
	@Column(nullable = false)
	public HashMap value
	
}
