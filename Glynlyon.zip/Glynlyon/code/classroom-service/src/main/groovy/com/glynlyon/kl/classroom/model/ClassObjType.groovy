package com.glynlyon.kl.classroom.model

public enum ClassObjType {
    CLASS,
    ILP
}