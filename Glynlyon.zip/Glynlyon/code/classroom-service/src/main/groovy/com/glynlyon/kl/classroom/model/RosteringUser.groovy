package com.glynlyon.kl.classroom.model

class RosteringUser {

    UUID uuid
    String source
    String fullName
    String firstName
    String lastName

    AppUserType appUserType

    RosteringUser() {}

}
