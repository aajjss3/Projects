package com.glynlyon.kl.classroom.constraints.group

public interface PagePatch {

}
