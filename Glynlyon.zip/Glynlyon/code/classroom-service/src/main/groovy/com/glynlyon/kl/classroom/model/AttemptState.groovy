package com.glynlyon.kl.classroom.model

public enum AttemptState {
    IN_PROGRESS, 
    SAVED, 
    SUBMITTED, 
    PASSED, 
    FAILED,
	OBE
}