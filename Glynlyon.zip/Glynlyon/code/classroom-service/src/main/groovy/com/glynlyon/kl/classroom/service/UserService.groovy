package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.InvalidFilterException
import com.glynlyon.kl.classroom.exceptions.InvalidOrgUserException
import com.glynlyon.kl.classroom.exceptions.NotAllowedException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.stereotype.Service

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Join
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root

import static org.springframework.data.jpa.domain.Specifications.where

/**
 * Created by etatarzycki on 2/23/17.
 */
@Service
class UserService {

    @Autowired
    UserRepo userRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    JwtService jwtService

    @Autowired
    FilterService filterService

    Logger logger = LogManager.getLogger(UserService)

    public User findOne(UUID uuid) {
        return (uuid ? userRepo.findOne(uuid) : null)
    }

    public Page<User> findAllUsers(String token, UUID organization_uuid = null, UUID excludedClassUuid = null, String filter, Pageable pageable) throws InvalidFilterException, InvalidOrgUserException {
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)  // requesting user's school uuid
        String userUuid = jwtService.getUuid(token)  // requesting user
        User user = userRepo.findByUuid(UUID.fromString(userUuid))  // requsting user object
        List<Organization> userCampusIdentifiers = user ? user.organizations.findAll{ it.type == OrganizationType.CAMPUS} : null
        Organization schoolOrg = organizationRepo.findOne(orgUuid)  // requesting user's school object

        Page<User> users  //resultSet

        Closure<Specification> mainFilter

        if (!user || !schoolOrg) {
            throw new NotAllowedException("Not authorized to search users. Need valid user and school")
        }
        if(role == AppUserType.TEACHER && !userCampusIdentifiers) {
            throw new NotAllowedException("User ${user?.userName} does not have a campus associated.")
        }

        Closure<Specification> notArchiveFilter = {
            new Specification<User>(){
                @Override
                Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                    return cb.notEqual(root.get("status"), AppUserStatus.ARCHIVE)
                }
            }
        }

        Closure<Specification>  enrolledUserFilter  = {
            new Specification<User>(){
                @Override
                Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                    if (excludedClassUuid) {
                        List<Enrollment> enrollments = enrollmentRepo.findAllByClassObjUuid(excludedClassUuid)
                        Set<UUID> enrolledUsers = enrollments.collect{ it.user.uuid }
                        if (!enrolledUsers.empty) {
                            return root.get("uuid").in(enrolledUsers).not()
                        }
                        return cb.and()
                    }
                    return cb.and()
                }
            }
        }

        //find users By class Campus or School
        if (organization_uuid) { //find by campus
            mainFilter = (Closure<Specification>){
                def campusFilter = new Specification<User>() {
                    public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                        Organization campusOrg = organizationRepo.findByUuid(organization_uuid)
                        if (!campusOrg || campusOrg.parent.uuid != orgUuid) {
                            throw new OrgNotFoundException("campus ${organization_uuid.toString()} not found in school ${orgUuid.toString()}.")
                        }
                        Join<User, Organization> school = root.join("organizations")
                        query.distinct(true);
                        return cb.equal(school, campusOrg)
                    }
                }
                return (Specification)(where(campusFilter).and(enrolledUserFilter()).and(notArchiveFilter()))
            }
        } else { //findBySchool or restrictedCampuses
            if(role == AppUserType.ADMIN) {
                mainFilter = (Closure<Specification>){
                    def schoolFilter = new Specification<User>() {
                        public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                            Join<User, Organization> school = root.join("organizations")
                            query.distinct(true);
                            return cb.equal(school, schoolOrg)
                        }
                    }
                    return (Specification)(where(schoolFilter).and(enrolledUserFilter()).and(notArchiveFilter()))
                }
            } else {//restricted by campuses
                mainFilter = (Closure<Specification>){
                    def restrictedCampusesFilter = new Specification<User>() {
                        public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                            Join<User, Organization> campuses = root.join("organizations")
                            query.distinct(true);
                            return campuses.in(userCampusIdentifiers)
                        }
                    }
                    return (Specification)(where(restrictedCampusesFilter).and(enrolledUserFilter()).and(notArchiveFilter()))
                }
            }
        }

        if (filter) {
            Map<String, String> mappings = [:]
            users = filterService.find(filter, User, userRepo, pageable, mappings, mainFilter)
        }
        else {
            users = userRepo.findAll(mainFilter(), pageable)
        }

        return users
    }
}
