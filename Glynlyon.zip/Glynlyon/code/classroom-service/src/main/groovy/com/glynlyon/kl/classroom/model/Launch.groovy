package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@Entity
class Launch extends BaseEntity {
	
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "launch_uuid", nullable = false)
    UUID uuid

    @Column(name = "jwt", nullable = false)
    String jwt

    @Column(name = "date_launched", nullable = true)
    Date date_launched

    @Column(name = "launched", nullable = false)
    Boolean launched

    public Launch(String jwt){
        this.jwt = jwt
        this.launched = false
    }

    Launch(){}
}
