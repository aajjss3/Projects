package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest



class CustomPageClassObjSerializer extends JsonSerializer<ClassObj> {
    @Autowired
    PageAssignmentRepo pageAssignmentRepo;

    @Override
    void serialize(ClassObj value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String serverRoot = req.getScheme() + "://" + req.getHeader("Host")

        gen.writeStartObject()
        gen.writeStringField("class_uuid", value.uuid.toString())
        gen.writeStringField("name", value.name)
        gen.writeObjectField("_links", ["self": ["href": serverRoot + "/classes/" + value.uuid]])
        gen.writeEndObject()
    }
}
