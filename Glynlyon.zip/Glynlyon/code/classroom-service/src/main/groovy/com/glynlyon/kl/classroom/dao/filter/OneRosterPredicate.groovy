package com.glynlyon.kl.classroom.dao.filter

public enum OneRosterPredicate {
    EQUALS("=","="), NOT_EQUAL("!=","!="), GREATER_THAN(">",">"), GREATER_THAN_OR_EQUAL(">=",">="),LESS_THAN("<","<"), LESS_THAN_OR_EQUAL("<=","<="), CONTAINS("contains","ILIKE")

    private String oneRosterRepresentation
    private String dbRepresentation

    private OneRosterPredicate(String oneRosterRepresentation,String dbRepresentation) {
        this.oneRosterRepresentation = oneRosterRepresentation
        this.dbRepresentation = dbRepresentation
    }
    public String getOneRosterRepresentation() {
        return oneRosterRepresentation
    }
    public String getDBRepresentation() {
        return dbRepresentation
    }
    public static OneRosterPredicate find(String oneRosterRepresentation) {
        OneRosterPredicate predicate = OneRosterPredicate.find {it.oneRosterRepresentation == oneRosterRepresentation}
        return predicate
    }


}
