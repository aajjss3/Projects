package com.glynlyon.kl.classroom.dto.grade

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

public class GpaStudentsResponse {
	
    List<StudentsResponse> students
    List failures

    static class StudentsResponse {
        @JsonIgnore
        String id

        @JsonProperty(value = "uuid")
        public String getId(){
            return id
        }

        @JsonProperty(value = "id")
        public void setId(String id){
            this.id = id
        }

        @JsonProperty(value="score_earned")
        BigDecimal scoreEarned

        @JsonProperty(value = "score_to_date")
        BigDecimal scoreToDate
		
		@JsonProperty(value="earned_scores")
		Map<String, Object> earnedScores = new HashMap<String, Object>()
    }
}