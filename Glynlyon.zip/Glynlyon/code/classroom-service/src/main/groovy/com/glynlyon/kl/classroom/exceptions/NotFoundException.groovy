package com.glynlyon.kl.classroom.exceptions

import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.http.HttpStatus
import org.apache.logging.log4j.Level

/**
 * Exception to throw when a Http Status NOT FOUND (404) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
class NotFoundException extends CustomException{

	public NotFoundException(String message){
		super(message)
	}
	
	public NotFoundException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public NotFoundException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}

}