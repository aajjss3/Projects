package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dao.AttemptDao
import com.glynlyon.kl.classroom.dto.ClassDTO
import com.glynlyon.kl.classroom.dto.AssignmentDTO
import com.glynlyon.kl.classroom.dto.PageAssignmentDTO
import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.dto.PageDTO
import com.glynlyon.kl.classroom.dto.Status
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.exceptions.InvalidRoleException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.util.Token
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root
import static com.glynlyon.kl.classroom.specs.Spec.spec
import static org.springframework.data.jpa.domain.Specifications.where
import com.glynlyon.kl.classroom.dto.BaseDTO
import com.glynlyon.kl.classroom.dto.mapper.PageMapper

@Service
class PageService extends AbstractService{

    @Autowired
    PageRepo pageRepo

    @Autowired
    JwtService jwtService

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    FilterService filterService

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    AttemptDao attemptDao

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    ClassService classService
	
	@Autowired
	PageMapper pageMapper
	
	@Autowired
	PageAssignmentRepo pageAssignmentRepo

    Logger logger = LogManager.getLogger(this.class)

    @Transactional
    public PageObj create(PageObj input, InputMapperService.MappingResult<PageObj> mappingResult) {

        if (input.sequence <= 0) {
            mappingResult.errors.add(["field": "sequence", message: "Invalid or missing field sequence number."])
        }

        def existingPages = pageRepo.findAllByClassObjUuidAndSequenceGreaterThanEqual(input?.classObj?.uuid, input.sequence)
        Integer previousPagesCount = pageRepo.countByClassObjUuid(input?.classObj?.uuid)
        if (existingPages) {
            existingPages.each { page ->
                page.sequence += 1
                page.updatedAt = new Date()
                pageRepo.save(page)
            }
        } else if (input.sequence > previousPagesCount) {
            input.sequence = previousPagesCount+1
        }

        def pageObj = pageRepo.save(input)

        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        return pageObj
    }

    public Page findAllPages(String token, String classUuid, String filter, Pageable pageable) {
        UUID orgUuid = jwtService.getOrgUuid(token)
        String datasource = jwtService.getDatasource(token)
        Organization org = organizationRepo.findByUuidAndOriginationId(orgUuid, datasource)

        if (!org) {
            throw new OrgNotFoundException("no organization ${orgUuid} found in datasource ${datasource}");
        }

        def mainFilter = {
            Specification<PageObj> orgSpec = createOrgSpec(token, true)
            if (classUuid) {
                return (Specification)(where(orgSpec)).and((Specification)spec("classObj.uuid", "=", classUuid))
            }
            else {
                return orgSpec
            }
        }

        if (filter) {
            def mappings = [:]
            return filterService.find(filter, PageObj, pageRepo, pageable, mappings, mainFilter, null)
        } else {
            pageRepo.findAll(mainFilter(), pageable)
        }
    }

    ValidationResult<PageObj> validateOrgAndPage(String token, UUID pageUuid, Boolean allowStudents, boolean isPageObjNeeded) {
        UUID orgUuid = jwtService.getOrgUuid(token)
        AppUserType role = jwtService.getRole(token)
        UUID userUuid = UUID.fromString(jwtService.getUuid(token))
        PageObj pageObj = null
		int count = 0
        try {
            if (role == AppUserType.ADMIN) {
                count = pageRepo.validatePageAndOrgForAdmin(pageUuid, orgUuid)
            }
            else if(role == AppUserType.TEACHER || (allowStudents && role == AppUserType.STUDENT)) {
                count = pageRepo.validatePageAndOrgForTeacherOrStudent(pageUuid, userUuid, AppUserType.TEACHER == role ? Role.TEACHER.toString() : Role.STUDENT.toString())
            }else {
                return new ValidationResult<PageObj>(valid: false, message: "only supported roles are ADMIN, TEACHER${allowStudents? ", and STUDENT" : ""}", httpStatus: HttpStatus.FORBIDDEN)
            }

            if (count == 0) {
                return new ValidationResult<PageObj>(valid: false, message: "Could not find page ${pageUuid} in organization ${orgUuid}", httpStatus: HttpStatus.NOT_FOUND)
            }
			if(isPageObjNeeded && count > 0){
				pageObj = pageRepo.findByUuid(pageUuid)
			}
			
            return new ValidationResult<PageObj>(valid: true, obj: pageObj, message: "")
        }
        catch(OrgNotFoundException | InvalidRoleException e){
            return new ValidationResult<PageObj>(valid: false, message: e.message)
        }
    }

    private Specification<PageObj> createOrgSpec(String token, Boolean allowStudents){
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)
        String userUuid = jwtService.getUuid(token)

        Specification orgSpec
        if (role == AppUserType.ADMIN) {
            orgSpec = new Specification<PageObj>() {
                Predicate toPredicate(Root<PageObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    return builder.or(builder.equal(root.get("classObj").get("organization").get('parent').get('uuid'), orgUuid), builder.equal(root.get("classObj").get("organization").get('uuid'), orgUuid))
                }
            }
        }
        else if(role == AppUserType.TEACHER || (allowStudents && role == AppUserType.STUDENT)) {
            return new Specification<PageObj>() {
                public Predicate toPredicate(Root<PageObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole(UUID.fromString(userUuid), AppUserType.TEACHER == role ? Role.TEACHER : Role.STUDENT)
                    return enrollments ? root.get("classObj").get("uuid").in(enrollments.classObj.uuid) : builder.or()
                }
            }
        }
        else {
            throw new InvalidRoleException("only supported roles are ADMIN, TEACHER${allowStudents? ", and STUDENT" : ""}")
        }
        return orgSpec
    }

    @Transactional
    PageObj update(PageObj input, PageObj existing, InputMapperService.MappingResult<PageObj> mappingResult) {
        existing.name = input.name?.trim() ?: null
        existing.status = input.status
        existing.updatedAt = new Date()
		existing.updatedBy = input.updatedBy

        if(input.status == PageState.COMPLETED) {
            existing.completedDate = new Date()
        }

        def pageObj = pageRepo.save(existing)

        if(input.status == PageState.COMPLETED) {
            completeByPageUuid(existing.uuid)
        }

        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        return pageObj
    }

    void completeByPageUuid(UUID pageUuid){
        attemptDao.deleteSavedInProgressForPage(pageUuid)

        completeAttempts(attemptDao.findLatestByPageUuid(pageUuid))

        List<PlannerEntry> orphanEntries = plannerEntryRepo.findAllByAttemptsAndPageObjUuid(null, pageUuid)
        orphanEntries.each {
            plannerEntryRepo.delete(it.uuid)
        }

    }

    void completeByClassUuid(UUID classUuid){
        attemptDao.deleteSavedInProgressForClass(classUuid)

        completeAttempts(attemptDao.findLatestByClassUuid(classUuid))

        List<PlannerEntry> orphanEntries = plannerEntryRepo.findAllByAttemptsAndClassObjUuid(null, classUuid)
        orphanEntries.each {
            plannerEntryRepo.delete(it.uuid)
        }
    }

    void completeAttempts(List<PageAttemptDTO> latestAttempts){
        latestAttempts.each { attempt ->
            if(attempt.state in [AttemptState.PASSED, AttemptState.FAILED]){
                PlannerEntry pe = plannerEntryRepo.findOne(attempt.plannerEntryUuid)
                pe.status = PlannerEntryState.GRADED
                plannerEntryRepo.save(pe)
            }
            else if(attempt.state == AttemptState.SUBMITTED){
                PlannerEntry pe = plannerEntryRepo.findOne(attempt.plannerEntryUuid)
                pe.status = PlannerEntryState.COMPLETED
                plannerEntryRepo.save(pe)
            }
            attemptRepo.save(attemptRepo.findOne(attempt.attemptUuid).with {
                it.creditBearing = true
                it
            })
        }
    }

    @Transactional
    public void updateAll(UUID classUuid, Status input, String token){
        classService.validateClass(classUuid, token)
        pageRepo.save(pageRepo.findAllByClassObjUuid(classUuid).collect {
			it.updatedBy = input.updatedBy
            it.status = input.status
            if(input.status == PageState.COMPLETED) {
                it.completedDate = new Date()
            }
            it
        })

        if(input.status == PageState.COMPLETED) {
            completeByClassUuid(classUuid)
        }
    }
	
	/**
	 * Update page fields with the corresponding values passed in the pageDTO. Only update a field if it was present in the request (independent if its value is null or not)
	 * If a required field is present in the request and its request value is explicitly set to null then data validation will fail.
	 * To determine if a field was present in the json request see the parameter BaseDTO.requestField
	 * @param pageUUID
	 * @param pageDTO
	 * @param token
	 * @return
	 */
	@Transactional
	public PageDTO patchPage( UUID pageUUID, PageDTO pageDTO, Token token){
		
		PageObj page = pageRepo.findByUuid(pageUUID)
		if( page ){
			
			// admin organization validation and teacher class validation
			adminTeacherValidation(token.userUUID, page.classObj?.organization?.uuid, page.classObj, token.role)

			// update the page entity
			pageDTO.setUpdatedAt( new Date() )
			if(pageDTO.getStatus() == "COMPLETED") {
				pageDTO.setCompletedDate( new Date() )
				completeByPageUuid(pageUUID)
			}
			pageMapper.map( pageDTO, page, false )
			
			// return a fully populated PageDTO, including all page nested objects.
			return pageMapper.map( page, PageDTO.class, true )
			
		}
		else{
			throw new NotFoundException("A page with the following uuid was not found: " + pageUUID.toString())
		}
		
	}
}