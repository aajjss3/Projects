package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.Launch
import com.glynlyon.kl.classroom.repo.LaunchRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class LaunchesService {

    @Autowired
    LaunchRepo launchRepository

    Launch findByUuid(UUID uuid) {
        launchRepository.findByUuid(uuid)
    }

    @Transactional
    Launch save(Launch launch) {
        launchRepository.save(launch)
    }
}
