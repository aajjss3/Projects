package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.Configuration
import com.glynlyon.kl.classroom.repo.ConfigurationRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ConfigurationService {

    @Autowired
    ConfigurationRepo configurationRepo

    Configuration getConfigurationByKey(String key) {
        return configurationRepo.findByKey(key)
    }
}
