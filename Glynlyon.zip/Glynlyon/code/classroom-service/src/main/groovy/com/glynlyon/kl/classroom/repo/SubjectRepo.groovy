package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Subject
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.CrudRepository

interface SubjectRepo extends CrudRepository<Subject, UUID>, JpaSpecificationExecutor, LocalRepo<Subject> {
    Page<Subject> findAll(Pageable pageable)
    Page<Subject> findByOrganizationUuid(Pageable pageable, UUID organization_uuid)

    List<Subject> findAllByNameIgnoreCase(String name)
}