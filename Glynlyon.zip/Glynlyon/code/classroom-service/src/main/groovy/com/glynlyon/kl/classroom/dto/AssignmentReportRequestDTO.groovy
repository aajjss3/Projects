package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty

import javax.validation.constraints.NotNull

class AssignmentReportRequestDTO extends BaseDTO{

    @JsonProperty(value = "report_id_prefix")
    @NotNull
    String report_id_prefix

    @JsonProperty(value = "report_type")
    @NotNull
    AssignmentReportType report_type
}
