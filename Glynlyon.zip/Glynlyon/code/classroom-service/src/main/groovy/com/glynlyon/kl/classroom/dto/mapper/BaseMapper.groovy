package com.glynlyon.kl.classroom.dto.mapper

import org.modelmapper.ModelMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.stereotype.Component

/**
 * Wrapper class for the ModelMapper API. 
 * As per the ModelMapper API Javadoc, the ModelMapper object is thread safe and therefore a single ModelMapper object can be used for all dto to entity mappings and visa versa. 
 * Migrate data between an Entity and DTO (and visa versa) if ALL the field names and data types between the 2 objects are identical. 
 * NOTE: a field name is considered the same even if one field is camel case and the other has underscores
 * @author asparago
 *
 */
@Component
class BaseMapper {
	
	// ModelMapper that maps all fields independent of the source value
	@Autowired
	@Qualifier("mapperAll")
	public ModelMapper mapperAll
	
	// ModelMapper that only maps fields that have a source value that isnt null
	@Autowired
	@Qualifier("mapperNonNulls")
	public ModelMapper mapperNonNulls
	

	/**
	 * ModelMapper that maps all fields
	 * @param obj - the JavaBean that contains state. 
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a populated object of type clazz
	 */
	public Object defaultMapAll(Object object, Class clazz){
		return mapperAll.map(object, clazz)
	}
	
	/**
	 * ModelMapper that maps all fields from source to destination.
	 * @param source - the source JavaBean object.
	 * @param destination - the destination JavaBean object.
	 */
	public void defaultMapAll(Object source, Object destination){
		mapperAll.map(source, destination)
	}
		
	/**
	 * ModelMapper that only maps fields whose source value is not null.
	 * @param obj - the JavaBean that contains state. 
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a populated object of type clazz
	 */
	public Object defaultMapNonNulls(Object object, Class clazz){
		return mapperNonNulls.map(object, clazz)
	}
	
	/**
	 * ModelMapper that only maps fields whose source value is not null from source to destination
	 * @param source - the source JavaBean object.
	 * @param destination - the destination JavaBean object.
	 */
	public Object defaultMapNonNulls(Object source, Object destination){
		mapperNonNulls.map(source, destination)
	}
	

	/** 
	* ModelMapper that maps all fields.
	* Migrate data between a List of Entities to a List of DTOs (and visa versa) if ALL the field names and data types between the 2 objects are identical.
	* NOTE: a field name is considered the same even if one field is camel case and the other has underscores
	*
	* @param obj - a List of JavaBeans that contains state.
	* @param clazz - the JavaBean class that will be instantiated and populated and returned.
	* @return a List of populated object of type clazz
	*/
	public List listMapAll(List objects, Class clazz){
		List list = new ArrayList()
		for( Object object : objects ){
			list.add( defaultMapAll(object, clazz) )
		}
		return list
	}
	
	
	/**
	 * ModelMapper that only maps fields whose source value is not null.
	 * Migrate data between a List of Entities to a List of DTOs (and visa versa) if ALL the field names and data types between the 2 objects are identical.
	 * NOTE: a field name is considered the same even if one field is camel case and the other has underscores
	 *
	 * @param obj - a List of JavaBeans that contains state.
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a List of populated object of type clazz
	 */
	public List listMapNonNulls(List objects, Class clazz){
		List list = new ArrayList()
		for( Object object : objects ){
			list.add( defaultMapNonNulls(object, clazz) )
		}
		return list
	}
		
}
