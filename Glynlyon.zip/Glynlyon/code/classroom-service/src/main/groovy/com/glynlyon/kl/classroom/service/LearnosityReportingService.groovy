package com.glynlyon.kl.classroom.service

import com.glynlyon.learnosity.client.LearnosityReportingClient
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service

@Service
class LearnosityReportingService {

	@Value('${learnosity.secret}')
    String learnositySecret

    @Value('${learnosity.key}')
    String learnosityKey

    LearnosityReportingClient getClient(String domain) {
		return new LearnosityReportingClient(learnosityKey, learnositySecret, domain)
	}
}

