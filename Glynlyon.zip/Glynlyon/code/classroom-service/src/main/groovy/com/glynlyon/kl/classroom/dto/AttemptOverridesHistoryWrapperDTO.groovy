package com.glynlyon.kl.classroom.dto

import java.util.Date
import java.util.UUID
import javax.persistence.Column
import org.springframework.data.domain.Page
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.model.AttemptOverridesHistory

public class AttemptOverridesHistoryWrapperDTO extends PaginationDTO{
	
	@JsonProperty("response_overrides")
	List<AttemptOverridesHistoryDTO> responseOverrides
		
	public AttemptOverridesHistoryWrapperDTO(List<AttemptOverridesHistoryDTO> responseOverrides, Page page){
		super(page)
		this.responseOverrides = responseOverrides
	}
	public List<AttemptOverridesHistoryDTO> getResponseOverrides() {
		return responseOverrides
	}
	public void setResponseOverrides(List<AttemptOverridesHistoryDTO> responseOverrides) {
		this.responseOverrides = responseOverrides
	}
		
}


class AttemptOverridesHistoryDTO{
	
	@JsonProperty(value = "created_at")
	private Date createdAt

	@JsonProperty(value = "created_by")
	private UUID createdBy
	
	@JsonProperty(value = "attempt_uuid")
	private UUID attemptUUID
	
	@JsonProperty(value = "response_id")
	private String responseID
	
	@JsonProperty(value = "page_assignment_uuid")
	private UUID pageAssignmentUUID
	
	@JsonProperty(value = "assignment_uuid")
	private UUID assignmentUUID
	
	@JsonProperty(value = "credit")
	private Boolean credit
	
	@JsonProperty(value = "date_overridden")
	private Date dateOverridden

	@JsonProperty(value = "user_uuid")
	private UUID userUUID
	
	@JsonProperty(value = "first_name")
	private String firstName
	
	@JsonProperty(value = "last_name")
	private String lastName

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public UUID getCreatedBy() {
		return createdBy
	}

	public void setCreatedBy(UUID createdBy) {
		this.createdBy = createdBy
	}

	public UUID getAttemptUUID() {
		return attemptUUID
	}

	public void setAttemptUUID(UUID attemptUUID) {
		this.attemptUUID = attemptUUID
	}

	public String getResponseID() {
		return responseID
	}

	public void setResponseID(String responseID) {
		this.responseID = responseID
	}

	public UUID getPageAssignmentUUID() {
		return pageAssignmentUUID
	}

	public void setPageAssignmentUUID(UUID pageAssignmentUUID) {
		this.pageAssignmentUUID = pageAssignmentUUID
	}

	public UUID getAssignmentUUID() {
		return assignmentUUID
	}

	public void setAssignmentUUID(UUID assignmentUUID) {
		this.assignmentUUID = assignmentUUID
	}

	public Boolean getCredit() {
		return credit
	}

	public void setCredit(Boolean credit) {
		this.credit = credit
	}

	public Date getDateOverridden() {
		return dateOverridden
	}

	public void setDateOverridden(Date dateOverridden) {
		this.dateOverridden = dateOverridden
	}

	public UUID getUserUUID() {
		return userUUID
	}

	public void setUserUUID(UUID userUUID) {
		this.userUUID = userUUID
	}

	public String getFirstName() {
		return firstName
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName
	}

	public String getLastName() {
		return lastName
	}

	public void setLastName(String lastName) {
		this.lastName = lastName
	}
	
	
	
	
}