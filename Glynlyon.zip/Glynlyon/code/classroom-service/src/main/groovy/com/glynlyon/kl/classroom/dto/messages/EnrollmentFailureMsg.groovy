package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty

class EnrollmentFailureMsg extends EnrollmentMessage {

    @Override
    String getContainer() {
        return "failures"
    }

    @JsonProperty(value = "user_uuid")
    String userUuid

    @JsonProperty(value = "class_uuid")
    String classUuid

    List errors
}
