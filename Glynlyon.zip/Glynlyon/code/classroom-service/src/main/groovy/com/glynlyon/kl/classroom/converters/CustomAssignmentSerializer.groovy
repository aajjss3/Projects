package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.BeanDescription
import com.fasterxml.jackson.databind.JavaType
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.fasterxml.jackson.databind.ser.BeanSerializerFactory
import com.glynlyon.kl.classroom.model.Assignment
import org.springframework.beans.factory.annotation.Value

class CustomAssignmentSerializer extends JsonSerializer<Assignment> {

    @Value('${cltSearch.base.uri}')
    String cltBaseUri

    @Override
    void serialize(Assignment value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        gen.writeStartObject()
        JavaType javaType = serializers.constructType(Assignment.class);
        BeanDescription beanDesc = serializers.getConfig().introspect(javaType);
        JsonSerializer<Object> serializer = BeanSerializerFactory.instance.findBeanSerializer(serializers, javaType, beanDesc);
        serializer.unwrappingSerializer(null).serialize(value, gen, serializers)
        gen.writeObjectField("_links", ["self": ["href": "${cltBaseUri}" + "/nodes/" + value.uuid]])
        gen.writeEndObject()
    }
}
