package com.glynlyon.kl.classroom.exceptions

import org.apache.logging.log4j.Level
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus


/**
 * Exception to throw when a Http Status FORBIDDEN (403) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
class BadRequestException extends CustomException{

	public BadRequestException(String message){
		super(message)
	}

	public BadRequestException(String message, Level logLevel){
		super(message, logLevel)
	}

	public BadRequestException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
}
