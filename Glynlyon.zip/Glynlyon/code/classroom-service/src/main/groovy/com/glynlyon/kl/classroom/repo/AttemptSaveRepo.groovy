package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.AttemptSave
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param

interface AttemptSaveRepo extends CrudRepository<AttemptSave, UUID>, JpaSpecificationExecutor<AttemptSave> {

    @Query(value = "select max(attemptSave.sequence) from AttemptSave attemptSave where attemptSave.attempt.uuid = :attemptUuid")
    Integer maxSequenceByAttemptUuid(@Param("attemptUuid") UUID attemptUuid)
}
