package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dao.LockDao
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.exceptions.ConflictException
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.model.*
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.LockRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Transactional
import org.springframework.dao.DataIntegrityViolationException

import groovy.time.*

@Service
class LockService extends AbstractService {

    @Autowired
    UserRepo userRepo

    @Autowired
    LockRepo lockRepo
	
	@Autowired
	LockDao lockDao

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    JwtService jwtService

    @Value('${attempt.lock.hours}')
    Integer lockDuration

	/**
	 * Since this method retrieves a lock object using pessimistic locking, the isolation level is declared as READ_COMMITTED. 
	 * Determine if a lock record already exists for a given resource. 
	 * 		If a lock does not already exist then create one. 
	 *      If a lock already exists and has expired then update the lock record
	 * 		If a lock already exists and the user requesting the lock is the user holding the current lock then update the lock record
	 * 		If a lock already exists and has not expired and the user requesting the lock is not the user holding the current lock then throw a ConflictException
	 *      
	 * @param resourceType
	 * @param resourceUuid
	 * @param plannerEntryUuid
	 * @param token
	 * @return
	 */
	@Transactional(isolation=Isolation.READ_COMMITTED)
    public Lock create(ResourceType resourceType, UUID resourceUuid, UUID plannerEntryUuid, String token) {
		
        User userAttempingLock = userRepo.findByUuid(UUID.fromString(jwtService.getUuid(token)))
        AppUserType userRole = jwtService.getRole(token)
        PlannerEntry plannerEntry = plannerEntryRepo.findByUuid(plannerEntryUuid)
        Enrollment validEnrollment = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(plannerEntry.classObj.uuid, UUID.fromString(jwtService.getUuid(token)), Role.TEACHER)

        //Check admin permissions
        adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), plannerEntry.classObj.organization.uuid, userRole)

        if(!validEnrollment && userRole != AppUserType.ADMIN) {
            throw new ForbiddenException("User is not an enrolled TEACHER or an ADMIN.")
        }

		Lock lock = lockDao.getLockByResourcePessimistically(resourceUuid)

		if( lock ){
			if( new Date().getTime() < ( lock.lockedAt.getTime() + lockDuration*3600000 ) ){ // 3600000 converts hours to milliseconds
				if( lock.lockedByUser.uuid.toString().equals(userAttempingLock.uuid.toString()) ){
					lock.lockedAt = new Date()
				}
				else{
					throw new ConflictException(lock.lockedByUser.firstName + " " + lock.lockedByUser.lastName + " is currently reviewing this assignment.")
				}
			}
			else{
				lock.lockedAt = new Date()
				lock.lockedByUser = userAttempingLock
			}
		}
		else{
			lock = lockRepo.saveAndFlush(new Lock(lockedByUser: userAttempingLock, resourceType: resourceType, resourceUuid: resourceUuid, lockedAt: new Date()))
		}

		return lock		
		
    }

	
    @Transactional(readOnly = true)
    ValidationResult<Lock> validateLock(UUID plannerEntryUuid, UUID attemptUuid, UUID lockUuid, String token) {
        PlannerEntry plannerEntry = plannerEntryRepo.findByUuid(plannerEntryUuid)
        Attempt attempt = attemptRepo.findByUuid(attemptUuid)
        User user = userRepo.findByUuid(UUID.fromString(jwtService.getUuid(token)))
        Lock lock = lockRepo.findByUuid(lockUuid)

        if(!attempt || attempt.plannerEntry != plannerEntry) {
            return new ValidationResult<Lock>(valid: false, message: "Could not find planner entry ${plannerEntryUuid} for attempt ${attemptUuid}")
        }

        if(!lock) {
            return new ValidationResult<Lock>(valid: false, message: "Could not find lock ${lockUuid}")
        }

        if(lock.lockedByUser != user) {
            return new ValidationResult<Lock>(valid: false, message: "Lock does not belong to user ${user.uuid}")
        }

        return new ValidationResult<Lock>(valid: true, obj: lock)
    }

    @Transactional
    void delete(Lock lock) {
        lockRepo.delete(lock.uuid)
    }
}
