package com.glynlyon.kl.classroom.dto

enum AssignmentReportType {
    SESSIONS_LIST_BY_ITEM
}