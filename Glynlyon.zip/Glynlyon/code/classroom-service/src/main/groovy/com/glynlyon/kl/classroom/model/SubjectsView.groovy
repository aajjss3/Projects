package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

import javax.persistence.*


/**
 * This entity corresponds to a database view, not a table.
 * Therefore, it does not extend from BaseEntity
 */
@Entity
@ToString
@EqualsAndHashCode
@Table(name="subjects")
@IdClass(UuidOrgId.class)
class SubjectsView implements Serializable, GroovyObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "subject_uuid", nullable = false)
    @JsonProperty(value = "subject_uuid")
    UUID uuid

    @Id
    @JsonProperty(value = "organization_uuid")
    @Column(name = "organization_uuid")
    UUID organizationUuid
	
	@JsonIgnore
	@Version
	public long version

    @JsonProperty(value = "name")
    @Column(name = "name", nullable = false)
    String name

    @JsonProperty(value = "default_subject")
    @Column(name = "default_subject")
    Boolean defaultSubject

    @JsonProperty(value = "disabled")
    @Column(name = "disabled")
    Boolean disabled

    @Column(name = "created_at", nullable = true)
    @JsonIgnore
    Date createdAt

    @Column(name = "updated_at", nullable = true)
    @JsonIgnore
    Date updatedAt

    SubjectsView() {}

}
