package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty

public class SettingsDTO {
	
	public List<Org> orgs

	public List<Org> getOrgs() {
		return orgs;
	}
	public void setOrgs(List<Org> orgs) {
		this.orgs = orgs;
	}

}


class Org{
	
	public List<String> classes

	@JsonProperty(value="org_uuid")
	public String orgUUID		
	
	@JsonProperty(value="class_settings")
	public List<SettingDTO> classSettings
	
	@JsonProperty(value="org_settings")
	public SettingDTO orgSetting

	public List<String> getClasses() {
		return classes;
	}
	public void setClasses(List<String> classes) {
		this.classes = classes;
	}
	public String getOrgUUID() {
		return orgUUID;
	}
	public void setOrgUUID(String orgUUID) {
		this.orgUUID = orgUUID;
	}
	public List<SettingDTO> getClassSettings() {
		return classSettings;
	}
	public void setClassSettings(List<SettingDTO> classSettings) {
		this.classSettings = classSettings;
	}
	public SettingDTO getOrgSetting() {
		return orgSetting;
	}
	public void setOrgSetting(SettingDTO orgSetting) {
		this.orgSetting = orgSetting;
	}

}
