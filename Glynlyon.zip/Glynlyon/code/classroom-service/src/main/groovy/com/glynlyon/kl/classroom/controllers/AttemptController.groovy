package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.constraints.annotation.StudentTeacherAdminRole
import com.glynlyon.kl.classroom.constraints.annotation.TeacherAdminRole
import com.glynlyon.kl.classroom.constraints.group.*
import com.glynlyon.kl.classroom.dto.AttemptOverridesHistoryWrapperDTO
import com.glynlyon.kl.classroom.dto.AttemptDTO
import com.glynlyon.kl.classroom.dto.ResponseOverridesDTO
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.dto.mapper.AttemptMapper
import com.glynlyon.kl.classroom.exceptions.CustomException
import com.glynlyon.kl.classroom.exceptions.InternalServerErrorException
import com.glynlyon.kl.classroom.exceptions.LearnocityClientException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.Lock
import com.glynlyon.kl.classroom.model.ResourceType
import com.glynlyon.kl.classroom.service.AttemptService
import com.glynlyon.kl.classroom.service.AttemptValidationService
import com.glynlyon.kl.classroom.service.LockService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.apache.logging.log4j.Level
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import com.glynlyon.kl.classroom.model.AttemptOverridesHistory

@RestController
@Validated
class AttemptController extends AbstractController {
	
	@Autowired
	AttemptService attemptService
	
	@Autowired
	AttemptValidationService attemptValidationService

	@Autowired
	AttemptMapper mapper

	@Autowired
	LockService lockService

	@GetMapping("/plannerentries/{planner_entry_uuid}/attempts")
	public ResponseEntity<List<AttemptDTO>> getAttempts(@RequestParam(name = "limit", required = false) Integer limit,
														@RequestParam(name = "offset", required = false) Integer offset,
														@RequestParam(name = "orderBy", required = false) String orderBy,
														@RequestParam(name = "sort", required = false) String sort,
														@RequestParam(name = "filter", required = false) String filter,
														@PathVariable("planner_entry_uuid") String plannerEntryUUID,
														@StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}") @RequestHeader(name = "authorization") String auth,
														HttpServletRequest req ){
		if( filter ){
			filter = filter.replaceAll("status","state")
		}
		if( sort ){
			sort = sort.replaceAll("status","state")
		}
		Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_ATTEMPT_SORT, Attempt.class)
		Page page = attemptService.getAttempts(plannerEntryUUID, jwtService.getUuid( auth.substring(JWT_STARTING_INDEX) ), jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) ), filter, pageable)
		HttpHeaders headers = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
		List<AttemptDTO> dtos = ( page.content ) ? mapper.map(page.content, AttemptDTO.class, true) : null
		return new ResponseEntity([("attempts") : dtos, (Constants.CURRENT_PAGE): page.getNumber() + 1,(Constants.PAGE_SIZE) : page.getNumberOfElements(), (Constants.TOTAL_PAGES) : page.getTotalPages()], headers, HttpStatus.OK)
	}


	@RequestMapping(path = "/classes/{uuid}/attempts", method = RequestMethod.GET, produces = Constants.ATTEMPTS_VERSION_1)
	public ResponseEntity<List<AttemptDTO>> getClassAttempts(@RequestParam(name = "limit", required = false) Integer limit,
														@RequestParam(name = "offset", required = false) Integer offset,
														@RequestParam(name = "orderBy", required = false) String orderBy,
														@RequestParam(name = "sort", required = false) String sort,
														@RequestParam(name = "filter", required = false) String filter,
														@PathVariable("uuid") String uuid,
													    @RequestHeader(name = "authorization") String auth,
														HttpServletRequest req ){
		if( filter ){
			filter = filter.replaceAll("status","state")
		}
		if( sort ){
			sort = sort.replaceAll("status","state")
		}	
		Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_ATTEMPT_SORT, Attempt.class)
		Page page = attemptService.getAttemptsByClass(uuid, jwtService.getUuid( auth.substring(JWT_STARTING_INDEX) ), jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) ), filter, pageable)
		HttpHeaders headers = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
		List<AttemptDTO> dtos = ( page.content ) ? mapper.map(page.content, AttemptDTO.class, true) : null
		return new ResponseEntity([("attempts") : dtos, (Constants.CURRENT_PAGE): page.getNumber() + 1,(Constants.PAGE_SIZE) : page.getNumberOfElements(), (Constants.TOTAL_PAGES) : page.getTotalPages()], headers, HttpStatus.OK)

	}
	
	@PostMapping(path = "/plannerentries/attempts", produces = Constants.ATTEMPTS_VERSION_1, consumes = Constants.ATTEMPTS_VERSION_1)
    ResponseEntity<?> createAttempt(@Validated(value=AttemptCreate.class) @RequestBody  AttemptDTO input, 
                                	@StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}")
                                    @RequestHeader(name = "authorization") String auth) {
        input.createdAt = new Date()
        input.updatedAt = new Date()
        input.uuid = null

        AttemptDTO attempt 
		try {
    		attempt = attemptService.create(input, auth.substring(JWT_STARTING_INDEX))
		}
		catch (Exception e) {
			if (!CustomException.class.isInstance(e)) {
				throw new InternalServerErrorException("Unable to proceed ", Level.ERROR, e)
			}
			else {
				throw e
			}
		}

		return createResponse(HttpStatus.CREATED, attempt, "/plannerentries/"+ input.plannerEntryUuid + "/attempts/"+attempt.uuid)
    }

	@GetMapping(value = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}/reviews", produces = Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1)
	ResponseEntity<?> getAttemptReview(@PathVariable('attempt_uuid') UUID attemptUuid,
									   @PathVariable('planner_entry_uuid') UUID plannerEntryUuid,
									   @RequestHeader(name = "authorization") String auth,
									   @RequestHeader(name = "x-client-domain") String domain,
									   @RequestParam(name = "items", required = false) String items) {
		String token = auth.substring(JWT_STARTING_INDEX)
		def response

		try {
			response = attemptService.getAssignmentReview(token, attemptUuid, plannerEntryUuid, domain,items)
		}
		catch (Throwable t) {
			if(t instanceof LearnocityClientException) {
				return new ResponseEntity([errors: t.message], HttpStatus.INTERNAL_SERVER_ERROR)
			}
			return new ResponseEntity([errors: t.message], HttpStatus.BAD_REQUEST)
		}

		return new ResponseEntity(response, HttpStatus.OK)
	}

	@PutMapping(path = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}", consumes = Constants.ATTEMPTS_VERSION_1)
	ResponseEntity<?> updateAttempt(@PathVariable("planner_entry_uuid") UUID planner_entry_uuid, 
                                 @PathVariable("attempt_uuid") UUID attempt_uuid,  
                                 @Validated(value=AttemptUpdate.class) @RequestBody AttemptDTO input, 
                                 @StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}")                               
                                 @RequestHeader(name = "authorization" ) String auth,
								 @RequestHeader(name = "x-client-domain") String domain){

       	AttemptDTO attempt = attemptService.update(input, planner_entry_uuid, attempt_uuid, auth.substring(JWT_STARTING_INDEX), domain)

		return createResponse(HttpStatus.OK, attempt, "/plannerentries/"+ input.plannerEntryUuid + "/attempts/"+attempt.uuid)
	}

	@PatchMapping(path = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}", consumes = Constants.ATTEMPTS_VERSION_1)
	ResponseEntity<?> patchAttempt(@PathVariable("planner_entry_uuid") UUID planner_entry_uuid,
			@PathVariable("attempt_uuid") UUID attempt_uuid,
			@Validated(value=AttemptPatch.class) @RequestBody AttemptDTO input,
			@StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}")
			@RequestHeader(name = "authorization" ) String auth) {

		AttemptDTO attempt = attemptService.patch(input, planner_entry_uuid, attempt_uuid, auth.substring(JWT_STARTING_INDEX))

		return createResponse(HttpStatus.OK, attempt, "/plannerentries/" + attempt.plannerEntryUuid + "/attempts/" + attempt.uuid)
	}

	@DeleteMapping("/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}")
	public ResponseEntity<?> deleteAttempt(	@PathVariable("planner_entry_uuid") String plannerEntryUUID,
											@PathVariable("attempt_uuid") String attemptUUID,
											@StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}") @RequestHeader(name = "authorization") String auth ){
											String token = auth.substring( JWT_STARTING_INDEX )

        UUID plannerEntryUuid
        UUID userUuid
        UUID orgUuid
        UUID attemptUuid

        AppUserType role = jwtService.getRole( token )
        String userUUID = jwtService.getUuid( token )
        String orgUUID = jwtService.getOrgUuid( token )

        try{
            plannerEntryUuid = UUID.fromString(plannerEntryUUID)
            userUuid = UUID.fromString(userUUID)
            orgUuid = UUID.fromString(orgUUID)
            attemptUuid = UUID.fromString(attemptUUID)
        }
        catch(Exception e){
            throw new NotFoundException( "Either planner entry uuid, attempt uuid or user uuid are not valid UUID's", Level.ERROR, e )
        }
        //we are going to delete the Attempt anyway, so we will validate the enrollment and class COMPLETED
        //after the delete
		Attempt attempt = attemptService.deleteAttempt( plannerEntryUuid, attemptUuid, userUuid, orgUuid, role )

        if (!attemptValidationService.validateStudentEnrolledInClass(attempt) ||
                !attemptValidationService.validateClassNotEnded(attempt)) {
            return ResponseEntity.status(HttpStatus.RESET_CONTENT).build()
        }else{
            return ResponseEntity.status(HttpStatus.NO_CONTENT).build()
        }


	}

	@PutMapping(value = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}/reviews", produces = Constants.PAGE_ATTEMPTS_VERSION_1, consumes = Constants.REVIEWS_OVERRIDES_VERSION_1)
	ResponseEntity<?> updateResponses(@PathVariable('attempt_uuid') UUID attemptUuid,
			@PathVariable('planner_entry_uuid') UUID plannerEntryUuid,
			@Validated @RequestBody ResponseOverridesDTO responseOverridesDTO,
			@RequestHeader(name = "x-client-domain") String domain,
			@RequestHeader(name = "authorization") String auth) {
		try {
			String token = auth.substring(JWT_STARTING_INDEX)
			return createResponse(attemptService.updateResponses(plannerEntryUuid, attemptUuid, responseOverridesDTO, domain, token))
		}
		catch (Throwable t) {
			if (!(t instanceof CustomException)) {
				String message = (t.message == null) ? "" : t.message
				throw new InternalServerErrorException(message, Level.ERROR, t)
			}
			throw t
		}
	}


	@PostMapping(path = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}/reviews/locks", produces = Constants.LOCKS_VERSION_1)
	ResponseEntity<?> createPlannerEntryLock(@Validated
											 @PathVariable("planner_entry_uuid") UUID plannerEntryUuid,
											 @PathVariable("attempt_uuid") UUID attemptUuid,
											 @TeacherAdminRole(message="{input.role.notallowed.teacheradmin}")
											 @RequestHeader(name = "authorization") String auth) {

		String token = auth.substring(JWT_STARTING_INDEX)

		Lock lock = lockService.create(ResourceType.ATTEMPT, attemptUuid, plannerEntryUuid, token)

		return createResponse(HttpStatus.CREATED, lock, "/plannerentries/" + plannerEntryUuid + "/attempts/" + attemptUuid + "/reviews/locks/" + lock.uuid)
	}

	@DeleteMapping(path = "/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}/reviews/locks/{uuid}", produces = Constants.LOCKS_VERSION_1)
	ResponseEntity<?> deletePlannerEntryLock(@Validated
											 @PathVariable("planner_entry_uuid") UUID plannerEntryUuid,
											 @PathVariable("attempt_uuid") UUID attemptUuid,
											 @PathVariable("uuid") UUID lockUuid,
											 @TeacherAdminRole(message="{input.role.notallowed.teacheradmin}")
											 @RequestHeader(name = "authorization") String auth) {

		String token = auth.substring(JWT_STARTING_INDEX)

		ValidationResult<Lock> result = lockService.validateLock(plannerEntryUuid, attemptUuid, lockUuid, token)
		if(!result.valid){
			return ResponseEntity.badRequest().body([errors: [message: [result.message]]])
		}

		lockService.delete(result.obj)
		return ResponseEntity.noContent().build()
	}
	
	/**
	 * Return a collection of AttemptOverridesHistory object for the attempt passed in the url.
	 * 
	 * @param limit
	 * @param offset
	 * @param orderBy
	 * @param sort
	 * @param filter
	 * @param plannerEntryUUID
	 * @param attemptUUID
	 * @param auth
	 * @return
	 */
	@GetMapping(path="/plannerentries/{planner_entry_uuid}/attempts/{attempt_uuid}/reviews/histories", produces = Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
	public AttemptOverridesHistoryWrapperDTO getAttemptOverridesHistories(
											@RequestParam(name = "limit", required = false) Integer limit,
											@RequestParam(name = "offset", required = false) Integer offset,
											@RequestParam(name = "orderBy", required = false) String orderBy,
											@RequestParam(name = "sort", required = false) String sort,
											@RequestParam(name = "filter", required = false) String filter,
											@PathVariable("planner_entry_uuid") UUID plannerEntryUUID,
											@PathVariable("attempt_uuid") UUID attemptUUID,
											@TeacherAdminRole(message="{input.role.notallowed.teacheradmin}") @RequestHeader(name = "authorization") String auth
											){
		Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, "date_overridden", AttemptOverridesHistory.class)
		return attemptService.getAttemptOverridesHistories(pageable, filter, attemptUUID, plannerEntryUUID, jwtService.getUuid( auth.substring(JWT_STARTING_INDEX) ), jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) ) )
	}

}
