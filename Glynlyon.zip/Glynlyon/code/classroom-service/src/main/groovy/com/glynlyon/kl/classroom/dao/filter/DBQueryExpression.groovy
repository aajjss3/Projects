package com.glynlyon.kl.classroom.dao.filter

import javax.persistence.Column
import javax.persistence.JoinColumn
import java.lang.reflect.Field

public class DBQueryExpression {
    private Field leftHandSide
    private OneRosterPredicate predicate
    private String rightHandSide
    private String conjunctiveOperator


    public DBQueryExpression(Field leftHandSide, OneRosterPredicate predicate, String rightHandSide,String conjunctiveOperator) {
        this.leftHandSide = leftHandSide
        this.predicate = predicate
        this.rightHandSide = rightHandSide
        this.conjunctiveOperator = conjunctiveOperator
    }

    static String toSnakeCase( String text ) {
                text.replaceAll(/\B[A-Z]/) { '_' + it }.toLowerCase()
    }

    public String render() {
        return new StringBuilder().with {
            append(' ')
            append(conjunctiveOperator?conjunctiveOperator:"")
            append(' ')
            append(getDBRepresentationForLHS())
            append(' ')
            append(predicate.DBRepresentation)
            append(' ')
            append(getDBRepresentationForRHS())
            append(' ')

        }
    }

    private def getDBRepresentationForRHS(){
        switch(leftHandSide.type) {
            case String:
                if(predicate.equals(OneRosterPredicate.CONTAINS)){
                    return "'%${rightHandSide}%'"
                } else return "'${rightHandSide}'"
                break
            case Boolean:
                return rightHandSide
                break
            default:
                return "'${rightHandSide}'"
        }
    }

    private def getDBRepresentationForLHS(){
        switch(leftHandSide.type) {
            case String:
                if(predicate.equals(OneRosterPredicate.CONTAINS)){
                    return "UPPER(${dbName()})"
                } else {
                    return dbName()
                }
                break
            case Date:
                return "date_trunc('second', ${dbName()})"
                break
            default:
                return dbName()
        }
    }

    private String dbName(){
        toSnakeCase(leftHandSide.declaringClass.simpleName) + "." + (leftHandSide.getAnnotation(JoinColumn)?.name() ?: leftHandSide.getAnnotation(Column)?.name() ?: toSnakeCase(leftHandSide.name))
    }





}