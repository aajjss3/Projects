package com.glynlyon.kl.classroom.dto

import com.glynlyon.kl.classroom.model.PageState
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

@ToString
@EqualsAndHashCode
class Status extends BaseDTO{

    PageState status
}
