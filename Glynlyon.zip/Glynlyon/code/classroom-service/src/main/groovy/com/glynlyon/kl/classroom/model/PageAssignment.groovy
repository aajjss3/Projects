package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.CustomPageAssignmentDeserializer
import com.glynlyon.kl.classroom.converters.CustomPageUuidObjSerializer

import org.hibernate.annotations.DynamicInsert

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.FetchType
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.Table
import javax.persistence.UniqueConstraint
import javax.validation.constraints.NotNull

@Entity
@DynamicInsert
@Table(
        uniqueConstraints = [
                @UniqueConstraint(columnNames = ["page_uuid", "sequence"]),
                @UniqueConstraint(columnNames = ["page_uuid", "assignment_uuid"])
        ]
)
@JsonDeserialize(using = CustomPageAssignmentDeserializer)
class PageAssignment extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "page_assignment_uuid", nullable = false)
    @JsonProperty(value = "page_assignment_uuid")
    UUID uuid

    @JsonProperty(value = "page_uuid")
    @JoinColumn(name = "page_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field page_uuid")
    @JsonSerialize(using = CustomPageUuidObjSerializer)
    PageObj pageObj

    @NotNull(message = "Missing required field assignment_uuid")
    @JoinColumn(name = "assignment_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @JsonProperty(value = "assignment")
    Assignment assignment

    @Column(name = 'sequence', nullable = false)
    @NotNull(message = "Missing required field sequence")
    Integer sequence

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date createdAt

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    Date updatedAt

    PageAssignment() {}

}
