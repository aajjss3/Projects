package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.exceptions.CustomException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.DefaultSubject
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.constraints.annotation.AdminRole
import com.glynlyon.kl.classroom.dto.messages.SubjectFailureMsg
import com.glynlyon.kl.classroom.dto.messages.SubjectSuccessMsg
import com.glynlyon.kl.classroom.service.DisabledSubjectService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

@RestController
@Validated
class SubjectsController extends AbstractController {

    @Autowired
    SubjectsService subjectsService

    @Autowired
    DisabledSubjectService disabledSubjectService

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    JwtService jwtUtil

    @Autowired
    PageableService pageableService

    @Autowired
    MessagesUtil messagesUtil

    @RequestMapping(path = "/subjects", method = RequestMethod.GET, produces = Constants.SUBJECTS_VERSION_1)
    public ResponseEntity list(
            @RequestParam(name = "organization_uuid", required = false) UUID organization_uuid,
            @RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "Authorization", required = true) authHeader)
    {
        String token = authHeader.substring(JWT_STARTING_INDEX)

        Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_SUBJECT_SORT, SubjectsView)

        Page<SubjectsView> subjects = subjectsService.find(pageable, organization_uuid, filter, token)
        HttpHeaders responseHeaders = new LinkHeaderBuilder(subjects).addCommonLinks().build(new HttpHeaders())

        if (subjects.content.size() == 0) {
            return PagedResponse.createResponse("subjects", subjects.content, subjects.getNumber() + 1, subjects.getNumberOfElements(), subjects.getTotalPages(), responseHeaders)
        }

        if (!SubjectsView.isInstance(subjects.content[0])) {
            return new ResponseEntity([errors: subjects.content], responseHeaders, HttpStatus.BAD_REQUEST)
        }

        return PagedResponse.createResponse("subjects", subjects.content, subjects.getNumber() + 1, subjects.getNumberOfElements(), subjects.getTotalPages(), responseHeaders)

    }

    @RequestMapping(path = "/subjects", method = RequestMethod.POST, produces = Constants.SUBJECTS_VERSION_1, consumes = Constants.SUBJECTS_VERSION_1)
    ResponseEntity<?> createSubject(@RequestBody ObjectNode json, HttpServletRequest req, @RequestHeader(name = "Authorization", required = true) authHeader) {
        String token = authHeader.substring(7)

        if(jwtUtil.getRole(token) != AppUserType.ADMIN) {
            return ResponseEntity.badRequest().body([errors: [ field: "role_in_issuer", message: "User is not authorized to create subjects" ] ])
        }

        def mappingResult = inputMapperService.processInput(json, SubjectsView)
        SubjectsView input = mappingResult.obj

        if(input == null){
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        input.createdAt = new Date()
        input.updatedAt = new Date()
        input.uuid = null

        try {
            Subject convertedSubject = convertToSubject(input)
            def s = subjectsService.save(convertedSubject, mappingResult, token)

            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/subjects/" + s.uuid)).body(subjectsService.findOne(s.uuid, s.organizationUuid))
        } catch (Throwable t) {
            if(t instanceof CustomException) {
                throw t
            }
            if(t?.cause?.cause instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException)t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, Subject)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @RequestMapping(path = "/subjects", method = RequestMethod.PUT, produces = Constants.SUBJECTS_MESSAGES_VERSION_1, consumes = Constants.SUBJECTS_VERSION_1)
    ResponseEntity<?> updateSubjects(@RequestBody ObjectNode jsonInput, @RequestHeader(name = "Authorization", required = true) auth) {

        String token = auth.substring(7)

        if(jwtUtil.getRole(token) != AppUserType.ADMIN) {
            return ResponseEntity.badRequest().body([errors: [ field: "role_in_issuer", message: "User is not authorized to update subjects" ] ])
        }
		UUID updatedBy = UUID.fromString(jsonInput.get("updated_by").asText())
        List<JsonNode> jsonList = jsonInput.get("subjects").toList()
        return ResponseEntity.ok([successes:[], failures:[]] + jsonList.collect { json ->
            ObjectNode origJson = json.deepCopy()
            def mappingResult = inputMapperService.processInput((ObjectNode)json, SubjectsView)
            def input = mappingResult.obj

            if(!input){
                return new SubjectFailureMsg(subjectUuid: null, errors: [new ErrorOutput(field: "body", message: "Failed to process input ${origJson}")])
            }

            SubjectsView existingSubject = subjectsService.findOne(input.uuid, jwtUtil.getOrgUuid(token))
            if(existingSubject == null){
                return new SubjectFailureMsg(subjectUuid: origJson.findValue("subject_uuid")?.textValue(), errors: [new ErrorOutput(field: "subject_uuid", message: messagesUtil.get("subjects.error.notfound"))])
            }

            try {
                subjectsService.update(existingSubject, input, mappingResult, token, updatedBy)
                return new SubjectSuccessMsg(subjectUuid: input.uuid)
            }
            catch (Throwable t) {
                List errors = mappingResult.errors
                if (t?.cause?.cause instanceof ConstraintViolationException) {
                    ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                    errors = inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, SubjectsView)
                }
                return new SubjectFailureMsg(subjectUuid: origJson.findValue("subject_uuid")?.textValue(), errors: errors)
            }
        }.groupBy{it.container})
    }

	
	/**
	 * Delete a subject.
	 * Only an ADMIN can delete a subject and and only if the admin belongs to the organization (or is the parent of the organization) that the subject belongs.
	 * Only delete a subject if either it has no classes associated with it, or all the class that are associated with it are already soft deleted. 
	 * If any class associated with a subject is not soft deleted, then do not delete the subject and instead throw a ForbiddenException
	 * To delete a subject, first un-assign any soft deleted classes associated with it (by setting the class.subject to null), and then delete the subject. 
	 * NOTE: a soft deleted class is defined as a class whose STATE is 'completed' and whose COMPLETED_AT plus 'duration' is less than or equal to the current time. 
	 * 
	 * @param subjectUUID
	 * @param auth
	 * 
	 */
	@DeleteMapping("/subjects/{subject_uuid}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteSubject(@PathVariable("subject_uuid") String subjectUUID, @AdminRole(message="{input.role.notallowed.admin}") @RequestHeader(name = "authorization") String auth){
		AppUserType role = jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) )
		String userUUID = jwtService.getUuid( auth.substring( JWT_STARTING_INDEX ) )
		subjectsService.deleteSubject(subjectUUID, userUUID, role)
	}
	

    @RequestMapping(path = "/defaultsubjects", method = RequestMethod.POST, produces = Constants.SUBJECTS_VERSION_1, consumes = Constants.SUBJECTS_VERSION_1)
    ResponseEntity<?> createDefaultSubject(@RequestBody ObjectNode json, HttpServletRequest req, @RequestHeader(name = "Authorization", required = true) authHeader) {
        String token = authHeader.substring(JWT_STARTING_INDEX)

        if(jwtUtil.getRole(token) != AppUserType.SUPPORT_ADMINISTRATOR) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body([errors: [ field: "role_in_issuer", message: "User is not authorized to create default subjects" ] ])
        }

        def mappingResult = inputMapperService.processInput(json, DefaultSubject)
        DefaultSubject input = mappingResult.obj

        if(input == null){
            return ResponseEntity.badRequest().body("Couldn't process input")
        }
        input.uuid = null
        input.createdAt = new Date()
        input.updatedAt = new Date()
        input.updatedBy = UUID.fromString(jwtUtil.getUuid(token))
        try {
            def s = subjectsService.createDefault(input, mappingResult)

            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/subjects/" + s.uuid)).body(s)
        }
        catch(Throwable t){
            if(t instanceof CustomException) {
                throw t
            }
            if(t?.cause?.cause instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException)t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, DefaultSubject)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }


    private static Subject convertToSubject(SubjectsView subjectsView){
        return new Subject(name: subjectsView.name, organizationUuid: subjectsView.organizationUuid, disabled: subjectsView.disabled, createdAt: new Date(), updatedAt: new Date())
    }


}
