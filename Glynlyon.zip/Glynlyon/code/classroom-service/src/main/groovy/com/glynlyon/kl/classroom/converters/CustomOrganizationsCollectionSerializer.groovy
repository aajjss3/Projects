package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.Organization
import org.springframework.beans.factory.annotation.Value

class CustomOrganizationsCollectionSerializer extends JsonSerializer<List<Organization>> {


    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    @Override
    void serialize(List<Organization> value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        gen.writeStartArray()
        value.each {
            gen.writeStartObject()
            gen.writeStringField("organization_uuid", it.uuid.toString())
            gen.writeStringField("name", it.name.toString())
            gen.writeStringField("type", it.type.toString())
            gen.writeObjectField("_links", ["self": ["href": "${rosteringBaseUri}" + "/orgs/" + it.uuid]])
            gen.writeEndObject()
        }
        gen.writeEndArray()
    }
}
