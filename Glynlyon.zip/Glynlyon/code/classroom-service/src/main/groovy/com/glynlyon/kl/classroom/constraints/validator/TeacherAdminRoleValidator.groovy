package com.glynlyon.kl.classroom.constraints.validator

import com.glynlyon.kl.classroom.constraints.annotation.TeacherAdminRole
import com.glynlyon.kl.classroom.model.AppUserType

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class TeacherAdminRoleValidator extends AbstractValidator implements ConstraintValidator<TeacherAdminRole, String>{

	// only allow if the role is TEACHER or ADMIN

    @Override
    void initialize(TeacherAdminRole constraintAnnotation) {

    }

    public boolean isValid(String auth, ConstraintValidatorContext constraintContext) {
		AppUserType role = jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) )
		if ( role == AppUserType.TEACHER || role == AppUserType.ADMIN ){
			return true
		}
		return false
	}
	
}
