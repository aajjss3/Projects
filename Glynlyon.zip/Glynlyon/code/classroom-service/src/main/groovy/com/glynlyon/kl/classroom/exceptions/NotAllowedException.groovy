package com.glynlyon.kl.classroom.exceptions

/**
 * Created by etatarzycki on 2/27/17.
 */
class NotAllowedException extends RuntimeException {

    NotAllowedException() {
        super()
    }

    NotAllowedException(String message) {
        super(message)
    }

    NotAllowedException(String message, Throwable cause) {
        super(message, cause)
    }
    NotAllowedException(Throwable cause) {
        super(cause)
    }

    protected NotAllowedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
