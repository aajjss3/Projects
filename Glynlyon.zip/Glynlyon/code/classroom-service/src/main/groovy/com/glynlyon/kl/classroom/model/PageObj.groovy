package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.CustomClassObjDeserializer
import com.glynlyon.kl.classroom.converters.CustomPageClassObjSerializer
import com.glynlyon.kl.classroom.converters.CustomPageObjSerializer
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import javax.persistence.FetchType
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.Table
import javax.validation.constraints.NotNull

@Entity
@Table(name="page")
@JsonSerialize(using = CustomPageObjSerializer)
@ToString
@EqualsAndHashCode
class PageObj extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "page_uuid", nullable = false)
    @JsonProperty(value = "page_uuid", access = JsonProperty.Access.READ_ONLY)
    UUID uuid

    @JoinColumn(name = "class_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field class_uuid")
    ClassObj classObj


    @JsonProperty(value = "class_uuid")
    @JsonDeserialize(using = CustomClassObjDeserializer)
    ClassObj setClassObj (ClassObj classObj) {
        this.classObj = classObj
    }

    @JsonProperty(value = "class")
    @JsonSerialize(using = CustomPageClassObjSerializer)
    ClassObj getClassObj() {
        return classObj
    }


    @Column(name = 'name', nullable = true)
    String name

    @Column(name = 'status', nullable = false)
    @NotNull(message = "Missing required field status")
    @Enumerated(EnumType.STRING)
    PageState status

    @Column(name = 'type', nullable = false)
    @NotNull(message = "Missing required field type")
    String type

    @Column(name = 'sequence', nullable = false)
    @NotNull(message = "Missing required field sequence")
    Integer sequence

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date createdAt

    @Column(name = "completed_date", nullable = true)
    @JsonProperty(value = "completed_date")
    Date completedDate

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    Date updatedAt
	

	@Column(name = "due_date", nullable = true)
	@JsonProperty(value = "due_date")
	Date dueDate

    PageObj() {}

}
