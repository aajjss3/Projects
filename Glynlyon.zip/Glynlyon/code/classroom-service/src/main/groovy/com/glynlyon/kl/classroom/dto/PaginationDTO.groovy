package com.glynlyon.kl.classroom.dto

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.dto.mapper.BaseMapper

/**
 * Any response that requires pagination should extend from this DTO.
 * 
 *
 */
class PaginationDTO {
	
	@JsonProperty("current_page")
	int number
	
	@JsonProperty("page_size")
	int numberOfElements
	
	@JsonProperty("total_pages")
	int totalPages
	
	@JsonIgnore
	Page page

	public PaginationDTO(Page page){
		this.page = page
		this.number = page.number + 1
		this.numberOfElements = page.numberOfElements
		this.totalPages = page.totalPages
	}
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getNumberOfElements() {
		return numberOfElements;
	}
	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	
}
