package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Course
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface CourseRepo extends PagingAndSortingRepository<Course, UUID>, LocalRepo<Course>, JpaSpecificationExecutor<Course> {

    Long deleteByUuid(UUID uuid);

}
