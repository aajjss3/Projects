package com.glynlyon.kl.classroom.model

import com.glynlyon.kl.classroom.util.Constants
import org.springframework.data.domain.Page
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

class PagedResponse {

    static ResponseEntity<Page> createResponse(String collectionName, List content, Integer currentPage, Integer pageSize, Integer totalPages, HttpHeaders responseHeaders) {
        HttpStatus status = HttpStatus.OK
        if(content && content.size() && content.get(0) instanceof ErrorOutput){
            status = HttpStatus.BAD_REQUEST
            collectionName = "errors"
        }
        new ResponseEntity([(collectionName) : content,
                           (Constants.CURRENT_PAGE): currentPage,
                           (Constants.PAGE_SIZE)   : pageSize,
                           (Constants.TOTAL_PAGES) : totalPages], responseHeaders, status)
    }
}
