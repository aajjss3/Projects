package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonValue

public enum Grade {
    PK("PK"),
    K("K"),
    ONE("1"),
    TWO("2"),
    THREE("3"),
    FOUR("4"),
    FIVE("5"),
    SIX("6"),
    SEVEN("7"),
    EIGHT("8"),
    NINE("9"),
    TEN("10"),
    ELEVEN("11"),
    TWELVE("12")


    private final String grade

    Grade(String grade) {
        this.grade = grade
    }

    @JsonValue
    public String getType() {
        return this.grade
    }

    public static Grade fromString(String text) {
        return values().find{text?.equalsIgnoreCase(it.type)}
    }
}