package com.glynlyon.kl.classroom.dto

class EnrollmentTimeOnTaskDTO {

	public UUID enrollmentUUID
	public long time

	public EnrollmentTimeOnTaskDTO(UUID enrollmentUUID, long time){
		this.enrollmentUUID = enrollmentUUID
		this.time = time
	}
	
	public UUID getEnrollmentUUID() {
		return enrollmentUUID;
	}
	public void setEnrollmentUUID(UUID enrollmentUUID) {
		this.enrollmentUUID = enrollmentUUID;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}

}
