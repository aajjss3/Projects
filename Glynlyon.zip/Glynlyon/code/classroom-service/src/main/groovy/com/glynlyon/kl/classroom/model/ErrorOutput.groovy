package com.glynlyon.kl.classroom.model

class ErrorOutput {
    String field
    String message
}
