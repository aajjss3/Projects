package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.exceptions.FieldNotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.JwtService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

class CustomClassObjDeserializer extends StdDeserializer<ClassObj> {

    @Autowired
    ClassRepo classRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    JwtService jwtService

    @Autowired
    EnrollmentRepo enrollmentRepo

    protected CustomClassObjDeserializer() {
        super(ClassObj)
    }

    @Override
    public ClassObj deserialize(
            JsonParser p,
            DeserializationContext ctx)
            throws IOException, JsonProcessingException {

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String jwt = req.getHeader("Authorization").substring(7)
        UUID classUUID = UUID.fromString(p.getValueAsString())
        String userUuidString = jwtService.getUuid(jwt)
        ClassObj classObj = classRepo.findByUuid(classUUID)
        AppUserType appUserType = jwtService.getRole(jwt)

        if(appUserType == AppUserType.ADMIN) {
            UUID schoolUUID = jwtService.getOrgUuid(jwt)
            if (classObj && (classObj.organization.uuid == schoolUUID || classObj.organization.parent.uuid == schoolUUID)) {
                return classObj
            }
        }
        else if(appUserType == AppUserType.TEACHER){
            List<UUID> orgsUuids = organizationRepo.findAllByUsersUuidAndType(UUID.fromString(userUuidString),OrganizationType.CAMPUS)*.uuid
            if(classObj && classObj.organization.uuid in orgsUuids){
                return classObj
            }
        }
        else if(appUserType == AppUserType.STUDENT){
            if(classObj && enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(classObj.uuid, UUID.fromString(userUuidString), Role.STUDENT)) {
                return classObj
            }
        }
        throw new FieldNotFoundException("class_uuid", "Could not find class with uuid ${classUUID}")
    }
}

