package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class MapUniqueDoubleValidator implements ConstraintValidator<MapUniqueDouble, Map<String,Double>> {
    @Override
    public void initialize(MapUniqueDouble constraintAnnotation) {}

    @Override
    public boolean isValid(Map<String,Double> inputMap, ConstraintValidatorContext context) {
        boolean isValid = true

        if( inputMap) {
            //map should not have duplicate values
            if(inputMap.groupBy { it.value }.find { it.value.size() > 1 } ) {
                isValid = false
                context.disableDefaultConstraintViolation()
                context.buildConstraintViolationWithTemplate('{input.map.duplicate.values}').addConstraintViolation()
            }
        }
        return isValid

    }
}
