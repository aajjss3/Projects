package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.StudentRole
import com.glynlyon.kl.classroom.model.AppUserType

class StudentRoleValidator extends AbstractValidator implements ConstraintValidator<StudentRole, String>{

	// only allow if the role is STUDENT

    @Override
    void initialize(StudentRole constraintAnnotation) {

    }

    public boolean isValid(String auth, ConstraintValidatorContext constraintContext) {
		AppUserType role = jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) )
		if ( role != AppUserType.STUDENT ){
			return false
		}
		return true
	}
	
}
