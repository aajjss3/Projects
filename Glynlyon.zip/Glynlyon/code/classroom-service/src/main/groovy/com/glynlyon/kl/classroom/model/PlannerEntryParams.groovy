package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonProperty

class PlannerEntryParams {

    PlannerEntryFilter filter

    @JsonProperty("planner_entry")
    PlannerEntry plannerEntry
}
