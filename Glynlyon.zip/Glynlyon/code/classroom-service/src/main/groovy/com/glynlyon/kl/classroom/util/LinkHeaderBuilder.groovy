package com.glynlyon.kl.classroom.util

import org.springframework.data.domain.Page
import org.springframework.hateoas.Link
import org.springframework.http.HttpHeaders
import org.springframework.web.servlet.support.ServletUriComponentsBuilder

class LinkHeaderBuilder {
    static final String PREVIOUS = "previous"
    static final String NEXT     = "next"
    static final String FIRST    = "first"
    static final String LAST     = "last"

    Page<?> page // zero-based so page number will need to be converted to one-based if applicable
    Map<String, Link> links = [:]

    String offsetName // name of the current offset (e.g. /schools?offset=5)
    String pageSizeParmName   // name of how many entries are on each page (e.g. /schools?per_page=20)

    StringUrlProvider urlProvider = REQUEST_URI_PATH_PROVIDER // by default we will build the URL from the the current request URI. Override this field if you want to provide a different way to build your URL path


    static final StringUrlProvider REQUEST_URI_PATH_PROVIDER = new StringUrlProvider() {

        String url(Map<String, ?> queryParms) {
            ServletUriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentRequestUri()

            queryParms.each { String k, v ->
                builder.queryParam(k, v)
            }

            return builder.build().toUriString()
        }
    }

    LinkHeaderBuilder(Page<?> page, String offsetName = 'offset', String pageSizeParmName = 'limit') {
        if (!page) throw new RuntimeException('page cannot be null')

        this.page = page
        this.pageSizeParmName = pageSizeParmName
        this.offsetName = offsetName
    }

    HttpHeaders build(HttpHeaders headers) {
        headers.set('Link', build())
        headers.set('X-Total-Count', page.totalElements as String)
        headers.set('Access-Control-Expose-Headers','X-Total-Count')
        return headers
    }

    String build() {
        links.values().join(',')
    }

    LinkHeaderBuilder urlProvider(StringUrlProvider urlProvider) {
        this.urlProvider = urlProvider
        return this
    }

    LinkHeaderBuilder addCommonLinks() {
        addPreviousLink()
        addNextLink()
        addFirstLink()
        addLastLink()
    }

    LinkHeaderBuilder addPreviousLink() {
        if (page.hasPrevious()) {
            int newOffset = page.previousPageable().offset
            addLink(PREVIOUS, newOffset)
        }
        else if(page.pageable.offset > 0){
            addLink(PREVIOUS, 0)
        }
        return this
    }

    LinkHeaderBuilder addNextLink() {
        if (page.hasNext()) {
            int newOffset = page.nextPageable().offset
            int pageSize = page.size
            if(newOffset + pageSize >= page.totalElements){
                pageSize = page.totalElements - (page.size + page.pageable.offset)
                newOffset = page.totalElements - pageSize
            }
            if(pageSize > 0) {
                addLink(NEXT, newOffset, pageSize)
            }
        }
        return this
    }

    LinkHeaderBuilder addFirstLink() {
        if (page.hasPrevious() || page.pageable.offset > 0) {
            addLink(FIRST, 0)
        }
        return this
    }

    LinkHeaderBuilder addLastLink() {
        if (page.hasNext()) {
            int pageSize = Math.min(page.totalElements - (page.size * (page.totalPages - 1)), page.totalElements - (page.size + page.pageable.offset))
            int newOffset = page.totalElements - pageSize
            if(pageSize > 0) {
                addLink(LAST, newOffset, pageSize)
            }
        }
        return this
    }

    LinkHeaderBuilder addLink(String rel, int pageNumber, int pageSize = page.size) {
        links[rel] = buildPageLink(rel, pageNumber, pageSize)
        return this
    }

    private Link buildPageLink(String rel, int offset, int pageSize) {
        new Link(urlProvider.url((pageSizeParmName):pageSize, (offsetName):offset), rel)
    }

    static interface StringUrlProvider {

        String url(Map<String, ?> queryParms)
    }
}