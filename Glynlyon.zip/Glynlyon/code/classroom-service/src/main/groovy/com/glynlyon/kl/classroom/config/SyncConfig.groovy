package com.glynlyon.kl.classroom.config

import jsr166y.ForkJoinPool
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class SyncConfig {

    @Bean
    public ForkJoinPool forkJoinPool() {
        ForkJoinPool pool = new ForkJoinPool()
        return pool
    }
}
