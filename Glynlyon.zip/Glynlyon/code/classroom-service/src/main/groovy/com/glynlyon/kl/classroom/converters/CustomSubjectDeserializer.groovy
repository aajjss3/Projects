package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.exceptions.FieldNotFoundException
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.SubjectsService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

class CustomSubjectDeserializer extends StdDeserializer<SubjectsView> {

    @Autowired
    SubjectsService subjectsService

    @Autowired
    JwtService jwtService

    protected CustomSubjectDeserializer() {
        super(SubjectsView)
    }

    @Override
    public SubjectsView deserialize(
            JsonParser p,
            DeserializationContext ctx)
            throws IOException, JsonProcessingException {

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String token = req.getHeader("Authorization").substring(7)
        UUID orgUuid = jwtService.getOrgUuid(token)

        UUID uuid = UUID.fromString(p.getValueAsString())
        SubjectsView obj = subjectsService.findOne(uuid, orgUuid)
        if (obj == null) {
            throw new FieldNotFoundException("subject_uuid", "Could not find subject with uuid ${uuid}")
        }
        return obj
    }
}

