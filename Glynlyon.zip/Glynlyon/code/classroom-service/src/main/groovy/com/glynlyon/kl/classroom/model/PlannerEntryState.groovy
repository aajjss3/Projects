package com.glynlyon.kl.classroom.model

public enum PlannerEntryState {
    NOT_STARTED,
    IN_PROGRESS,
    OBE,
    GRADED,
    COMPLETED,
    REASSIGNED,
    REASSIGNED_IN_PROGRESS
}