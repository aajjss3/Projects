package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty

class CourseFailureMsg extends CourseMessage {

    @Override
    String getContainer() {
        return "failures"
    }

    @JsonProperty(value = "course_uuid")
    String courseUuid

    List errors
}
