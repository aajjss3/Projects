package com.glynlyon.kl.classroom.model

public enum ResourceType {
    ATTEMPT
}