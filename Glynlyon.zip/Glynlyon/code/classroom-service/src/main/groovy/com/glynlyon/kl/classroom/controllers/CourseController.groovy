package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.constraints.annotation.SupportAdminRole
import com.glynlyon.kl.classroom.dto.CoursesDTO
import com.glynlyon.kl.classroom.dto.messages.CourseFailureMsg
import com.glynlyon.kl.classroom.dto.messages.CourseSuccessMsg
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Course
import com.glynlyon.kl.classroom.service.CourseService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*

@RestController
@Validated
class CourseController extends AbstractController {

    @Autowired
    CourseService courseService

    @Autowired
    InputMapperService inputMapperService

    @RequestMapping(path = "/courses", method = RequestMethod.GET, produces = Constants.COURSES_VERSION_1)
    ResponseEntity getCourses() {
        List<Course> courses = courseService.getAllCourses()

        return new ResponseEntity([courses: courses], HttpStatus.OK)
    }

    @RequestMapping(path = "/courses", method = RequestMethod.POST, produces = Constants.COURSES_VERSION_1)
    ResponseEntity postCourses(@RequestBody ObjectNode jsonInput, @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(7)
        AppUserType role = jwtService.getRole(token)

        if(role != AppUserType.SUPPORT_ADMINISTRATOR) {
            return ResponseEntity.badRequest().body("Only Support Adminstrator is allowed to add courses.")
        }

        List<JsonNode> jsonList = jsonInput.get("courses").toList()
        return ResponseEntity.ok([successes:[], failures:[]] + jsonList.collect { json ->
            ObjectNode origJson = json.deepCopy()
            def mappingResult = inputMapperService.processInput((ObjectNode)json, Course)
            def input = mappingResult.obj

            if(!input){
                return new CourseFailureMsg(courseUuid: null, errors: ["Failed to process input ${origJson}"])
            }

            input.uuid = UUID.fromString(json.course_uuid.textValue())

            try {
                Course course = courseService.create(input)
                return new CourseSuccessMsg(courseUuid: course.uuid)
            }
            catch (Throwable t) {
                return new CourseFailureMsg(courseUuid: origJson.findValue("course_uuid")?.textValue(), errors: [t.message])
            }
        }.groupBy{it.container})
    }

    @DeleteMapping(path = "/courses", produces = Constants.COURSES_VERSION_1)
    ResponseEntity deleteCourses(@RequestBody CoursesDTO coursesDTO,
                                 @SupportAdminRole(message="{input.role.notallowed.support}") @RequestHeader(name = "authorization") String auth) {
        return ResponseEntity.ok([successes:[], failures:[]] + coursesDTO.courses.collect { course ->
            try {
                Long count = courseService.deleteByUuid(course.uuid)
                if (!count) {
                    return new CourseFailureMsg(courseUuid: course.uuid, errors: [message.getMessage("course.error.notfound",null,locale)])
                }
                return new CourseSuccessMsg(courseUuid: course.uuid)
            }
            catch (Throwable t) {
                return new CourseFailureMsg(courseUuid: course.uuid, errors: [t.message])
            }
        }.groupBy{it.container})
    }

}
