package com.glynlyon.kl.classroom.repo


import java.util.UUID

import org.springframework.data.repository.CrudRepository

import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType


interface SettingRepo extends CrudRepository<Setting, UUID>{
	
	public Setting findBySourceUUIDAndType( UUID uuid, SettingType type )
	public Setting findByType( SettingType type )
	public void deleteByTypeAndSourceUUIDIn(SettingType type, List<UUID> sourceUUIDs)
	public List<Setting> findAllBySourceUUIDIn(List<UUID> sourceUUIDs)
	
}
