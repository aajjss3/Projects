package com.glynlyon.kl.classroom.model

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

@ToString
@EqualsAndHashCode
class RosteringOrganization {
    UUID uuid
    String source
    String name
    String type

    List<UUID> children

    RosteringOrganization() {}
}
