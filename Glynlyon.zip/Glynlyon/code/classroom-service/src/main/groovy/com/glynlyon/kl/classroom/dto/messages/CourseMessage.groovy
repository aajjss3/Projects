package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonIgnore

abstract class CourseMessage {

    @JsonIgnore
    abstract String container
}
