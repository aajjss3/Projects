package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.exceptions.NotAllowedException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.service.UserService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

/**
 * Created by etatarzycki on 2/23/17.
 */
@RestController
class UserController extends AbstractController {

    @Autowired
    UserService userService

    @Autowired
    PageableService pageableService

    @Autowired
    JwtService jwtService

    Logger logger = LogManager.getLogger(UserController)

    @RequestMapping(path = "/users", method = RequestMethod.GET, produces = Constants.USERS_VERSION_1)
    public ResponseEntity getUser(@RequestParam(name = "limit", required = false) Integer limit,
                                  @RequestParam(name = "offset", required = false) Integer offset,
                                  @RequestParam(name = "orderBy", required = false) String orderBy,
                                  @RequestParam(name = "sort", required = false) String sort,
                                  @RequestParam(name = "filter", required = false) String filter,
                                  @RequestParam(name = "organization_uuid", required = false) String organizationUuidStr,
                                  @RequestParam(name = "excluded_class_uuid", required = false) String excludedClassUuidStr,
                                  @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        Page page = null
        HttpHeaders responseHeaders = null
        List<ErrorOutput> errors = []

        //validate campus identifier - used to give me the students/teachers in a particular campus
        UUID campusOrgUuid = null
        try {
            campusOrgUuid = organizationUuidStr ? UUID.fromString(organizationUuidStr) : null
        }
        catch (IllegalArgumentException e){
            errors.add(new ErrorOutput(field: "organization_uuid", message: "invalid organization_uuid ${organizationUuidStr}"))
        }

        //validate class uuid - used to give me the students/teachers but not those enrolled already in this class
        UUID excludedClassUuid = null
        try {
            excludedClassUuid = excludedClassUuidStr ? UUID.fromString(excludedClassUuidStr) : null
        }
        catch (IllegalArgumentException e){
            errors.add(new ErrorOutput(field: "excluded_class_uuid", message: "invalid excluded_class_uuid ${excludedClassUuidStr}"))
        }

        if(errors.empty) {
            try {
                Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_USER_SORT, User, ["organization"])
                page = userService.findAllUsers(token, campusOrgUuid, excludedClassUuid, filter, pageable)
                responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
            }
            catch (UnsupportedFieldException e) {
                page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
            }
            catch (OrgNotFoundException e) {
                page = new PageImpl([new ErrorOutput(message: "'${e.message}'")])
            }
            catch (NotAllowedException e) {
                page = new PageImpl([new ErrorOutput(message: "'${e.message}'")])
            }
            catch (Throwable t){
                logger.error(t)
            }
        } else {
            page = new PageImpl(errors)
        }

        PagedResponse.createResponse("users", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }
}
