package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.CustomAssignmentSerializer
import org.hibernate.annotations.DynamicInsert

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.Id
import javax.validation.constraints.NotNull

@Entity
@DynamicInsert
@JsonSerialize(using = CustomAssignmentSerializer)
class Assignment extends BaseEntity{

    @Id
    @Column(name = "assignment_uuid", nullable = false)
    @JsonProperty(value = "assignment_uuid")
    @NotNull(message = "Missing required field assignment_uuid")
    UUID uuid

    @Column(name = 'assignment_type', nullable = false)
    @JsonProperty(value = "assignment_type")
    @NotNull(message = "Missing required field assignment_type")
    @Enumerated(EnumType.STRING)
    AssignmentType type

    @Column(name = "assignment_title", nullable = false)
    @JsonProperty(value = "assignment_title")
    @NotNull(message = "Missing required field assignment_title")
    String title

    @Column(name = "created_at")
    @JsonIgnore
    Date created

    @Column(name = "updated_at")
    @JsonIgnore
    Date updated

}
