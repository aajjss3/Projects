package com.glynlyon.kl.classroom.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController
import com.glynlyon.kl.classroom.constraints.annotation.AdminRole
import com.glynlyon.kl.classroom.constraints.annotation.StudentTeacherAdminRole
import com.glynlyon.kl.classroom.constraints.annotation.TeacherAdminRole
import com.glynlyon.kl.classroom.constraints.group.ClassSetting
import com.glynlyon.kl.classroom.constraints.group.OrganizationSetting
import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.dto.SettingsDTO
import com.glynlyon.kl.classroom.service.SettingService


@RestController
@RequestMapping(path="settings")
@Validated
class SettingController extends AbstractController{
	
	@Autowired
	SettingService settingService
	
	
	/**
	 * Retrieve the settings for the organization passed in.
	 * 
	 * @param uuid - organization uuid
	 * @param auth
	 * @return SettingDTO
	 * @throws UnauthorizedException
	 */
	@GetMapping(value = "/orgs/{uuid}", produces = "application/vnd.settings.v1+json")
	@ResponseStatus(HttpStatus.OK)
	public SettingDTO getOrgSettings(@PathVariable('uuid') UUID uuid, @RequestHeader(name = "authorization") String auth){
		return settingService.getSettings(uuid, token(auth))
	}

	
	@GetMapping(value = "/orgs/{org_uuid}/classes/{class_uuid}", produces = "application/vnd.settings.v1+json")
	@ResponseStatus(HttpStatus.OK)
	public SettingDTO getClassSettings(@PathVariable('org_uuid') UUID orgUuid, @PathVariable('class_uuid') UUID classUuid, @RequestHeader(name = "authorization") String auth){
		return settingService.getSettings(orgUuid, classUuid, token(auth))
	}

	
	/**
	 * If a setting exists for the organization then update it, otherwise save it as a new organization setting. 
	 * Only an Admin can save/update an organization setting
	 * 
	 * @param uuid Organization UUID
	 * @param auth
	 * @return
	 */
	@PutMapping(value = "/orgs/{uuid}", consumes = "application/vnd.settings.v1+json", produces = "application/vnd.settings.v1+json")
	@ResponseStatus(HttpStatus.OK)
	public SettingDTO saveOrUpdateOrgSettings(	@PathVariable('uuid') UUID uuid, 
												@Validated(value=[OrganizationSetting.class]) @RequestBody SettingDTO setting, 
												@AdminRole(message="{input.role.notallowed.admin}") @RequestHeader(name = "authorization") String auth){
		return settingService.saveOrUpdateOrgSettings( uuid, setting, token(auth) )
	}
	
	
	/**
	 * If a setting exists for the class then update it, otherwise save it as a new class setting.
	 * Only a Teacher or Admin can save/update a class setting
	 * 
	 * @param uuid Organization UUID
	 * @param class_uuid ClassObj UUID
	 * @param auth
	 * @return
	 */
	@PutMapping(value = "/orgs/{uuid}/classes/{class_uuid}", consumes = "application/vnd.settings.v1+json", produces = "application/vnd.settings.v1+json")
	@ResponseStatus(HttpStatus.OK)
	public SettingDTO saveOrUpdateClassSettings(@PathVariable('uuid') UUID orgUUID,
												@PathVariable('class_uuid') UUID classUUID,
												@Validated(value=[ClassSetting.class]) @RequestBody SettingDTO setting,
												@TeacherAdminRole(message="{input.role.notallowed.teacheradmin}") @RequestHeader(name = "authorization") String auth){
		return settingService.saveOrUpdateClassSettings( classUUID, orgUUID, setting, token(auth) )
	}
	
	
	/**
	 * Retrieve all org and class settings for a user.
	 * Org setting defaults to global setting if there is no explicit org setting. 
	 * 
	 * @param userUUID
	 * @param excludeExpiredClasses - an optional request parameter. if included and true then do not return the settings for any soft deleted classes.
	 * @param auth
	 * @return SettingsDTO
	 */
	@GetMapping(value = "/users/{uuid}", produces = "application/vnd.orgs.users.settings.v1+json")
	@ResponseStatus(HttpStatus.OK)
	public SettingsDTO getSettingsForUser(@PathVariable('uuid') UUID userUUID,
										@RequestParam(value = "excludeExpiredClasses", required = false, defaultValue="false") boolean excludeExpiredClasses,
										@StudentTeacherAdminRole(message="{input.role.notallowed.studentteacheradmin}") @RequestHeader(name = "authorization") String auth){
		return settingService.getSettingsForUser( userUUID, excludeExpiredClasses, token(auth) )
	}

}
