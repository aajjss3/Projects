package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.DefaultSubject
import com.glynlyon.kl.classroom.model.DisabledSubject
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.UuidOrgId
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.DefaultSubjectRepo
import com.glynlyon.kl.classroom.repo.DisabledSubjectRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.SubjectsViewRepo
import com.glynlyon.kl.classroom.specs.Spec
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.stereotype.Service

import javax.transaction.Transactional

import static org.springframework.data.jpa.domain.Specifications.where

@Service
class SubjectsService extends AbstractService {

    @Autowired
    SubjectsViewRepo subjectsViewRepository

    @Autowired
    FilterService filterService

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    DisabledSubjectRepo disabledSubjectRepo

    @Autowired
    DefaultSubjectRepo defaultSubjectRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    MessagesUtil messagesUtil

    @Autowired
    JwtService jwtService
	
	@Autowired
	ClassRepo classRepo
	
	@Autowired
	ConfigurationService configurationService
	

    Page<SubjectsView> find(Pageable pageable, UUID organization_uuid, String filter, String token) {
        UUID tokenOrg = jwtService.getOrgUuid(token)

        Closure<Specification> mainFilter = {
            def orgFilter = Spec.spec("organizationUuid", "=", tokenOrg.toString())

            if (organization_uuid) {
                return where(Spec.spec("organizationUuid", "=", organization_uuid.toString())).and(orgFilter)
            }
            return orgFilter
        }

        if (filter) {
           return filterService.find(filter, SubjectsView, subjectsViewRepository, pageable, [:], mainFilter, null)
        }
        return subjectsViewRepository.findAll(mainFilter(), pageable)

    }

    @Transactional
    Subject save(Subject subject, InputMapperService.MappingResult<SubjectsView> mappingResult, String token) {
        adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), subject.organizationUuid, jwtService.getRole(token))

        def subjectNameExists
        if(subject.uuid) {
            subjectNameExists = subjectsViewRepository.findByNameIgnoreCaseAndOrganizationUuidAndUuidNot(subject.name, subject.organizationUuid, subject.uuid)
        }
        else {
            subjectNameExists = subjectsViewRepository.findByNameIgnoreCaseAndOrganizationUuid(subject.name, subject.organizationUuid)
        }
        if(subjectNameExists) {
            mappingResult.errors.add("field": "name", message: messagesUtil.get("subjects.error.existing"))
        }
        if(subject.disabled == null) {
            if(!mappingResult.errors.any{it.field == "disabled"}){
                mappingResult.errors.add("field": "disabled", message: "Missing required field disabled")
            }
        }

        def returnedSubject = subjectRepo.save(subject)

        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        updateDisabled(subject, mappingResult)

        return returnedSubject
    }

    @Transactional
    private void updateDisabled(Subject subject, InputMapperService.MappingResult<SubjectsView> mappingResult){
        if(subject.disabled == null) {
            if(!mappingResult.errors.any{it.field == "disabled"}){
                mappingResult.errors.add("field": "disabled", message: "Missing required field disabled")
            }
        }
        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        DisabledSubject existingDisabled = disabledSubjectRepo.findOne(new UuidOrgId(subject.uuid, subject.organizationUuid))
        if(subject.disabled) {
            if(!existingDisabled) {
                DisabledSubject disabledSubject = convertToDisabledSubject(subject)
                disabledSubject.uuid = subject.uuid
                disabledSubjectRepo.save(disabledSubject)
            }
        }
        else {
            if(existingDisabled) {
                disabledSubjectRepo.delete(new UuidOrgId(existingDisabled.uuid, subject.organizationUuid))
            }
        }
    }


    SubjectsView findOne(UUID uuid, UUID orgUuid){
        return subjectsViewRepository.findOne(new UuidOrgId(uuid, orgUuid))
    }

    private static DisabledSubject convertToDisabledSubject(Subject subject){
        return new DisabledSubject(organizationUuid: subject.organizationUuid, createdAt: new Date(), updatedAt: new Date())
    }

    @Transactional
    public void update(SubjectsView existing, SubjectsView input, InputMapperService.MappingResult<SubjectsView> mappingResult, String token, UUID updatedBy) {
        if(existing.defaultSubject && existing.name != input.name) {
            mappingResult.errors.add([field: "name", message: messagesUtil.get("subjects.error.default.name")])
        }
        Subject toUpdate = new Subject(
                uuid: existing.uuid,
                name: input.name,
                organizationUuid: existing.organizationUuid,
                createdAt: existing.createdAt,
                updatedAt: existing.updatedAt,
                disabled: input.disabled,
                version: existing.version,
				updatedBy: updatedBy
        )

        if(existing.defaultSubject) {
            updateDisabled(toUpdate, mappingResult)
        }
        else {
            save(toUpdate, mappingResult, token)
        }
    }
	
	
	@Transactional
	public void deleteSubject(String subjectUUID, String userUUID, AppUserType role){
		
		Subject subject = subjectRepo.findOne( UUID.fromString(subjectUUID) )
		
		if( !subject ){
			throw new NotFoundException("The subject_uuid is not valid.")
		}
		
		// admin orgainization validation
		adminOrganizationValidation( UUID.fromString(userUUID), subject.organizationUuid, role )
		
		// retrieve a list of class associated with the subject
		SubjectsView subjectsView = subjectsViewRepository.findByOrganizationUuidAndUuid(subject.organizationUuid, subject.uuid)
		List<ClassObj> classes = classRepo.findAllBySubject( subjectsView )
				
		if( classes.size() == 0 ){
			subjectRepo.delete( subject.uuid )
		}
		else{
			long durationInMilliSeconds = Long.parseLong(configurationService.getConfigurationByKey(Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY).value) * 3600000
			for(ClassObj clazz : classes){
				if( clazz.state == ClassObjState.COMPLETED && (clazz.completed.getTime() + durationInMilliSeconds) <= (new Date()).getTime() ){
					clazz.subject = null
				}
				else{
					throw new ForbiddenException("Unable to delete the subject since there is at least one associated class.")
				}
			}
			subjectRepo.delete( subject.uuid )
		}
								
	}
	

    @Transactional
    DefaultSubject createDefault(DefaultSubject defaultSubject, InputMapperService.MappingResult<DefaultSubject> mappingResult) {
        if(defaultSubjectRepo.findAllByNameIgnoreCase(defaultSubject.name)){
            mappingResult.errors.add([field: "name", message: messagesUtil.get("subjects.default.error.existing")])
        }
        else {
            List<Subject> existing = subjectRepo.findAllByNameIgnoreCase(defaultSubject.name)
            if(existing) {
                List<String> schools = existing.collect{organizationRepo.findOne(it.organizationUuid)}.collect{"{${it.uuid}, ${it.name}}"}
                mappingResult.errors.add([field: "name", message: messagesUtil.get("subjects.default.error.custom.existing", schools)])
            }
        }
        DefaultSubject result =  defaultSubjectRepo.save(defaultSubject)
        if(mappingResult.errors){
            throw new RuntimeException()
        }
        return result
    }

}
