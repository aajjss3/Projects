package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

import java.util.UUID

import javax.persistence.*

@Entity
@ToString
@EqualsAndHashCode
@IdClass(UuidOrgId)
class DisabledSubject extends BaseEntity implements Serializable, GroovyObject {


    @Id
    @Column(name = "subject_uuid", nullable = false)
    @JsonProperty(value = "subject_uuid")
    UUID uuid

    @Id
    @JsonProperty(value = "organization_uuid")
    @Column(name = "organization_uuid")
    UUID organizationUuid


    @Column(name = "created_at", nullable = true)
    @JsonIgnore
    Date createdAt

    @Column(name = "updated_at", nullable = true)
    @JsonIgnore
    Date updatedAt

    DisabledSubject() {}

}
