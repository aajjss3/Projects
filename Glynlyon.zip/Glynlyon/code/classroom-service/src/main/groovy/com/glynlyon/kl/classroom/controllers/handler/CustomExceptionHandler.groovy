package com.glynlyon.kl.classroom.controllers.handler

import com.fasterxml.jackson.databind.JsonMappingException
import com.fasterxml.jackson.databind.exc.InvalidFormatException
import com.glynlyon.kl.classroom.constraints.validator.AdminRoleValidator
import com.glynlyon.kl.classroom.constraints.validator.StudentRoleValidator
import com.glynlyon.kl.classroom.constraints.validator.StudentTeacherAdminRoleValidator
import com.glynlyon.kl.classroom.constraints.validator.SupportAdminRoleValidator
import com.glynlyon.kl.classroom.constraints.validator.TeacherAdminRoleValidator
import com.glynlyon.kl.classroom.exceptions.CustomException
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.validation.FieldError
import org.springframework.validation.ObjectError
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.ResponseStatus

import javax.validation.ConstraintViolation
import javax.validation.ConstraintViolationException
import javax.validation.Path

import static org.springframework.core.annotation.AnnotatedElementUtils.findMergedAnnotation
/**
 * Override springs default handling when an exception is thrown by the application.
 * @author asparago
 *
 */
@ControllerAdvice
class CustomExceptionHandler {

	/**
	 * Override Springs default error handling behavior if a CustomException, or any subclass of it, is thrown by the application.
	 * 
	 * @param exception CustomException
	 */
    @ExceptionHandler
    @ResponseBody
    ResponseEntity<ErrorMessageDTO> handle(CustomException exception) {
		// log the exception if applicable.
		if( exception.isLoggable ){
			Logger logger = LogManager.getLogger(exception.getClass())
			if( exception.rootCause ){
				logger.log( exception.logLevel, exception.getLocalizedMessage(), exception.rootCause )
			}
			else{
				logger.log( exception.logLevel, exception.getLocalizedMessage() )
			}
		}
		ErrorMessageDTO body = new ErrorMessageDTO(exception.getLocalizedMessage())
		// get the HTTP status code annotated on the CustomException, or if one isn't present, then set to HTTP status code to INTERNAL_SERVER_ERROR as default
		ResponseStatus annotation = findMergedAnnotation(exception.getClass(), ResponseStatus.class)
		HttpStatus responseStatus = ( annotation ) ?  annotation.value() : HttpStatus.INTERNAL_SERVER_ERROR 
		return new ResponseEntity<ErrorMessageDTO>(body, responseStatus)
    }

		
	/**
	 * Override Springs default error handling behavior if a ConstraintViolationException is thrown by the application. 
	 * This exception is thrown when @Validated fails validation.
	 * This occurs with the annotations: @PathVariable and @RequestParam
	 *
	 * @param ex - ConstraintViolationException
	 */
	@ExceptionHandler
	@ResponseBody
	ResponseEntity<ValidationFailureWrapper> handle( ConstraintViolationException ex) {
        HttpStatus status = HttpStatus.BAD_REQUEST
		List<ValidationFailureDTO> errors = new ArrayList<ValidationFailureDTO>()
		Set<ConstraintViolation<?>> violations = ex.getConstraintViolations()
        List roleValidators = [AdminRoleValidator, StudentRoleValidator, StudentTeacherAdminRoleValidator, SupportAdminRoleValidator, TeacherAdminRoleValidator]
        if(violations.any{v -> v.constraintDescriptor.constraintValidatorClasses.any{it in roleValidators}}){
            status = HttpStatus.FORBIDDEN
        }
		for( ConstraintViolation violation : violations ){
			Path.Node node = violation.getPropertyPath().last()
			ValidationFailureDTO dto = new ValidationFailureDTO(node.getName(), violation.getMessage())
			errors.add(dto)
		}
		ValidationFailureWrapper body = new ValidationFailureWrapper(errors)
		return new ResponseEntity<ValidationFailureWrapper>(body, status)
	}

	
	/**
	 * Override Springs default error handling behavior if a MethodArgumentNotValidException is thrown by the application.
	 * This exception is thrown when @Valid fails validation.
	 * This occurs with the annotations: @RequestBody
	 *
	 * @param ex - MethodArgumentNotValidException
	 */
	@ExceptionHandler
	@ResponseBody
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	ResponseEntity<ValidationFailureWrapper> handle( MethodArgumentNotValidException ex) {
		List<ValidationFailureDTO> errors = new ArrayList<ValidationFailureDTO>()
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			ValidationFailureDTO errorDTO = new ValidationFailureDTO(error.getField(), error.getDefaultMessage())
			errors.add(errorDTO)
		}
		for (ObjectError error : ex.getBindingResult().getGlobalErrors()) {
			ValidationFailureDTO errorDTO = new ValidationFailureDTO(error.getObjectName(), error.getDefaultMessage())
			errors.add(errorDTO)
		}
		ValidationFailureWrapper dto = new ValidationFailureWrapper(errors)
		return new ResponseEntity<ValidationFailureWrapper>(dto, HttpStatus.BAD_REQUEST)
	}
	
	
	/**
	 * Override Springs default error handling behavior if a HttpMessageNotReadableException is thrown by the application.
	 * This exception is thrown when the input JSON data cannot be bound which is probably due to the json being malformed, missing or a json data type not matching the corresponding declared java data type.
	 *
	 * @param ex - HttpMessageNotReadableException
	 */
	@ExceptionHandler
	@ResponseBody
	ResponseEntity<ErrorMessageDTO> handle( HttpMessageNotReadableException ex) {
		if(ex.cause instanceof InvalidFormatException){
			InvalidFormatException ife = ex.cause as InvalidFormatException
			String field = ife.path.collect{it.getFieldName()}.join(".")
			String message = "invalid input ${ife.value}"
			if(field && message) {
				List<ValidationFailureDTO> errors = new ArrayList<ValidationFailureDTO>()
				errors.add(new ValidationFailureDTO(field, message))
				ValidationFailureWrapper dto = new ValidationFailureWrapper(errors)
				return new ResponseEntity<ValidationFailureWrapper>(dto, HttpStatus.BAD_REQUEST)
			}
		}
		else if (ex.cause instanceof JsonMappingException) {
			JsonMappingException jsonMappingException = ex.cause
			String field = jsonMappingException.path._fieldName.join(".")
			String message = jsonMappingException.cause?.getOriginalMessage() ?: "invalid input"
			if(field) {
				List<ValidationFailureDTO> errors = new ArrayList<ValidationFailureDTO>()
				errors.add(new ValidationFailureDTO(field, message))
				ValidationFailureWrapper dto = new ValidationFailureWrapper(errors)
				return new ResponseEntity<ValidationFailureWrapper>(dto, HttpStatus.BAD_REQUEST)
			}
		}
		String message = (ex.getCause() != null) ? ex.getCause().getMessage() : ex.getLocalizedMessage()
		ErrorMessageDTO body = new ErrorMessageDTO("Failed to process input. The reason is: " + message)
		return new ResponseEntity<ErrorMessageDTO>(body, HttpStatus.BAD_REQUEST)
	}

}


/**
 * JavaBean to match the response json structure for failed input data validation.
 *
 * @author asparago
 *
 */
class ValidationFailureWrapper {
	
	List<ValidationFailureDTO> errors = new ArrayList<ValidationFailureDTO>()
	
	public ValidationFailureWrapper(List<ValidationFailureDTO> errors){
		super()
		this.errors.addAll( errors )
	}

	public List<ValidationFailureDTO> getErrors() {
		return errors;
	}
	public void setErrors(List<ValidationFailureDTO> errors) {
		this.errors = errors;
	}
	
}


class ValidationFailureDTO {
	
	String field
	String message
	
	public ValidationFailureDTO(String field, String message) {
		this.field = field
		this.message = message
	}
	
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}



/**
 * JavaBean to match the response json structure for thrown CustomExceptions.
 * 
 * @author asparago
 *
 */
class ErrorMessageDTO{
	
	List<Map<String, String>> errors = new ArrayList<HashMap<String, String>>()

	public ErrorMessageDTO(String message){
		Map<String, String> entry = new HashMap<String, String>()
		entry.put("message", message)
		errors.add(entry)
	}
	
}
