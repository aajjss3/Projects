package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dao.AttemptDao
import com.glynlyon.kl.classroom.dto.AttemptDTO
import com.glynlyon.kl.classroom.dto.AttemptOverridesHistoryDTO
import com.glynlyon.kl.classroom.dto.AttemptOverridesHistoryWrapperDTO
import com.glynlyon.kl.classroom.dto.ItemAnalysisReportAttempt
import com.glynlyon.kl.classroom.dto.LearnosityJobStatusJmsDTO
import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.dto.Question
import com.glynlyon.kl.classroom.dto.ResponseOverridesDTO
import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.dto.grade.GpaScoresInput
import com.glynlyon.kl.classroom.dto.grade.OutcomeResponse
import com.glynlyon.kl.classroom.dto.grade.OutcomeStatus
import com.glynlyon.kl.classroom.dto.mapper.AttemptMapper
import com.glynlyon.kl.classroom.exceptions.BadRequestException
import com.glynlyon.kl.classroom.exceptions.ClassObjNotFoundException
import com.glynlyon.kl.classroom.exceptions.CustomException
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.InternalServerErrorException
import com.glynlyon.kl.classroom.exceptions.InvalidInputException
import com.glynlyon.kl.classroom.exceptions.LearnocityClientException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptOverridesHistory
import com.glynlyon.kl.classroom.model.AttemptSave
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Lock
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.pagination.OffsetBasedPageRequest
import com.glynlyon.kl.classroom.repo.AttemptOverridesHistoryRepo
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.LockRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.specs.Spec
import com.glynlyon.kl.classroom.util.AttemptUtil
import com.glynlyon.kl.classroom.util.MessagesUtil
import com.glynlyon.kl.classroom.util.ScoreMapUtil
import com.glynlyon.learnosity.client.LearnosityDataClient
import com.glynlyon.learnosity.exception.LearnosityStatusCodeException
import com.glynlyon.learnosity.exception.LearnosityUpdateScoreException
import com.glynlyon.learnosity.model.LearnosityConfig
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityReportUser
import com.glynlyon.learnosity.model.LearnosityResponse
import com.glynlyon.learnosity.model.LearnositySessionListByItemRequest
import com.glynlyon.learnosity.model.LearnosityUpdateSessionResponse
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.convert.converter.Converter
import org.springframework.core.env.Environment
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.data.jpa.domain.Specifications
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Transactional
import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root

@Service
class AttemptService extends AbstractService{

	private static final Double MAX_SCORE = 1.0
	private static final Double MIN_SCORE = 0.0
	
	@Autowired
	AttemptRepo attemptRepo

	@Autowired
    PlannerEntryRepo plannerEntryRepo

	@Autowired
	ScoreMapUtil scoreMapUtil

	@Autowired
	EnrollmentRepo enrollmentRepo

	@Autowired
	PageAssignmentRepo pageAssignmentRepo

	@Autowired
	AttemptMapper attemptMapper

	@Autowired
	MessagesUtil messagesUtil

	@Autowired
	JwtService jwtService

	@Autowired
	LearnosityAssessmentService assessmentService

	@Autowired
	FilterService filterService

	@Autowired
	AttemptDao attemptDao

	@Autowired
	SettingService settingService

	@Autowired
	LearnosityReportingService learnosityReportingService

	@Autowired
	PageRepo pageRepo

	@Autowired
	LockRepo lockRepo

	@Autowired
	AttemptValidationService attemptValidationService

	@Autowired
	ClassRepo classRepo

	@Value('${learnosity.secret}')
	String learnositySecret

	@Value('${learnosity.key}')
	String learnosityKey

	@Value('${learnosity.organisationId}')
	Integer organisationId

	@Value('${reports.student.maxAttempts}')
	Integer attemptsPerReport

	@Autowired
	AttemptSaveService attemptSaveService

	@Autowired
	GpaService gpaService

	@Autowired
	LearnosityDataService learnosityDataService

	@Autowired
	LearnosityJobStatusJmsService learnosityJobStatusJmsService
	
	@Autowired
	AttemptOverridesHistoryRepo attemptOverridesHistoryRepo
	
	@Autowired
	PageableService pageableService
	
	@Autowired
	protected Environment env

	Logger logger = LogManager.getLogger(AttemptService)

	@Transactional(readOnly = true)
	public Page<Attempt> getAttempts(String plannerEntryUUID, String userUUID, AppUserType role, String filter, Pageable pageable){
	//TODO simplify and move validation rules to AttemptValidationService
		// if the planner entry uuid is not a valid UUID
		try{
			UUID.fromString(plannerEntryUUID)
		}
		catch(Exception e){
			throw new NotFoundException("planner entry uuid is not a valid UUID")
		}
		
		PlannerEntry plannerEntry = plannerEntryRepo.findByUuid(UUID.fromString(plannerEntryUUID))
		if( !plannerEntry ){
			throw new NotFoundException("planner entry uuid does not exist")
		}
		
		// admin orgainization validation
		UUID organizationUUID = plannerEntry?.classObj?.organization?.uuid
		adminOrganizationValidation(UUID.fromString(userUUID), organizationUUID, role)
		
		try{
			if( filter) {
							
				return filterService.find(filter, Attempt, attemptRepo, pageable, [:], {
					if( role == AppUserType.STUDENT ){
						Specifications.where(Spec.spec("plannerEntry.uuid", "=", plannerEntryUUID)).and(Spec.spec("user.uuid", "=", userUUID))
					}
					else if( role == AppUserType.ADMIN ){
						Spec.spec("plannerEntry.uuid", "=", plannerEntryUUID)
					}
					else if( role == AppUserType.TEACHER ){
						Specification enrolledFilter = new Specification<Attempt>() {
							@Override
							Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole( UUID.fromString(userUUID), Role.TEACHER )
								return enrollments ? root.get("plannerEntry").get("classObj").get("uuid").in(enrollments.classObj.uuid) : cb.or()
							}
						}
						Specifications.where(Spec.spec("plannerEntry.uuid", "=", plannerEntryUUID)).and(enrolledFilter)
					}
				}, null)
								
			 } 
			 else{
				if( role == AppUserType.STUDENT ){
					return attemptRepo.findAllByPlannerEntryUuidAndUserUuid(pageable, UUID.fromString(plannerEntryUUID), UUID.fromString(userUUID))
				}
				else if( role == AppUserType.ADMIN){
					return attemptRepo.findAllByPlannerEntryUuid(pageable, UUID.fromString(plannerEntryUUID))
				}
				else if( role == AppUserType.TEACHER ){
					List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole( UUID.fromString(userUUID), Role.TEACHER)
					List<UUID> classUUIDs = new ArrayList<UUID>()
					for(Enrollment enrollment : enrollments ){
						classUUIDs.add(enrollment.classObj.uuid)
					}
					return attemptRepo.findAllByPlannerEntryUuidAndPlannerEntry_classObj_UuidIn(pageable, UUID.fromString(plannerEntryUUID), classUUIDs)

				}
			}
		}
		catch(Exception e){
			throw new InternalServerErrorException("Unable to retrieve a list of Attempts", Level.ERROR, e)
		}	
        	
	}

	@Transactional(readOnly = true)
	public Page<Attempt> getAttemptsByClass(String classUUID, String userUUID, AppUserType role, String filter, Pageable pageable){

		// if the planner entry uuid is not a valid UUID
		try{
			UUID.fromString(classUUID)
		}
		catch(Exception e){
			throw new NotFoundException("class uuid is not a valid UUID")
		}

		// if the class uuid does not exist in the database
		ClassObj classObj = classRepo.findByUuid(UUID.fromString(classUUID))
		if( !classObj ){
			throw new NotFoundException("class uuid does not exist")
		}
		
		// admin orgainization validation
		UUID organizationUUID = classObj?.organization?.uuid
		adminOrganizationValidation(UUID.fromString(userUUID), organizationUUID, role)

		try{
			if( filter) {

				Specification classFilter = new Specification<Attempt>() {
					@Override
					Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.get("plannerEntry").get("classObj").get("uuid"), UUID.fromString(classUUID))
					}
				}

				return filterService.find(filter, Attempt, attemptRepo, pageable, [:], {
					if( role == AppUserType.STUDENT ){
						Specifications.where(Spec.spec("user.uuid", "=", userUUID)).and(classFilter)
					}
					else if( role == AppUserType.ADMIN ){
						Specifications.where(classFilter)
					}
					else if( role == AppUserType.TEACHER ){
						Specification enrolledFilter = new Specification<Attempt>() {
							@Override
							Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
								Enrollment enrollment = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(UUID.fromString(classUUID), UUID.fromString(userUUID), Role.TEACHER)
								return cb.equal(root.get("plannerEntry").get("classObj").get("uuid"), enrollment?.classObj?.uuid)
							}
						}
						Specifications.where(classFilter).and(enrolledFilter)
					}
				}, null)

			}
			else{
				if( role == AppUserType.STUDENT ){
					return attemptRepo.findAllByPlannerEntry_ClassObj_UuidAndUserUuid(pageable, UUID.fromString(classUUID), UUID.fromString(userUUID))
				}
				else if( role == AppUserType.ADMIN){
					return attemptRepo.findAllByPlannerEntry_ClassObj_Uuid(pageable, UUID.fromString(classUUID))
				}
				else if( role == AppUserType.TEACHER ){
					Enrollment enrollment = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(UUID.fromString(classUUID), UUID.fromString(userUUID), Role.TEACHER)
					return attemptRepo.findAllByPlannerEntry_ClassObj_Uuid(pageable, enrollment?.classObj?.uuid)
				}
			}
		}
		catch(Exception e){
			throw new InternalServerErrorException("Unable to retrieve a list of Attempts", Level.ERROR, e)
		}

	}
   

	/**
	 * Only students can create an attempt. Admin's can not create an attempt.
	 * @param dto
	 * @param userUuid
	 * @param role
	 * @return
	 */
    @Transactional
    public AttemptDTO create(AttemptDTO dto, String token) {
		UUID userUuid = UUID.fromString(jwtService.getUuid(token))
		AppUserType role = jwtService.getRole(token)
		
		if( role == AppUserType.STUDENT && ( dto.getStatus() == AttemptState.PASSED.name() || dto.getStatus() == AttemptState.FAILED.name() ) ){
			throw new ForbiddenException(env.getProperty("student.create.attempt.status.invalid"))
		}

		//TODO simplify and move validation rules to AttemptValidationService
        PlannerEntry plannerEntry = plannerEntryRepo.findOne(dto.plannerEntryUuid)
        if(!plannerEntry){
            throw new NotFoundException( "Unable to find an PlannerEntry record for the uuid: " + dto.plannerEntryUuid )
        }

		// admin orgainization validation
		UUID organizationUUID = plannerEntry?.classObj?.organization?.uuid
		adminOrganizationValidation(userUuid, organizationUUID, role)

		if(role == AppUserType.TEACHER){
			if(!enrollmentRepo.countAllByUserUuidAndClassObjUuid(userUuid, plannerEntry.classObj.uuid)){
				throw new ForbiddenException("Teacher ${userUuid} is not enrolled in class ${plannerEntry.classObj.uuid}")
			}
		}
		else if(role == AppUserType.STUDENT){
			if(userUuid != dto.userUuid){
				throw new ForbiddenException("Student ${userUuid} cannot create attempt for user ${dto.userUuid}")
			}
		}
        
        //is the student enrolled in this class
        Enrollment enroll = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole( plannerEntry.classObj.uuid, dto.userUuid, Role.STUDENT )
        if(!enroll) {
           throw new BadRequestException( messagesUtil.get("attempt.create.enrolled.invalid") )
        }


		if(plannerEntry.status != PlannerEntryState.REASSIGNED) {
			SettingDTO settings = settingService.findClassSettings(plannerEntry.classObj.uuid)
			Integer attemptLimit = null
			if (plannerEntry.assignment.type == AssignmentType.LESSON) {
				attemptLimit = settings.value.classroom.lessons.attempts
			}
			else if (plannerEntry.assignment.type == AssignmentType.PROJECT) {
				attemptLimit = settings.value.classroom.projects.attempts
			}

			if (!attemptLimit) {
				throw new BadRequestException("Could not look up setting for ${plannerEntry.assignment.type}")
			}
			if (plannerEntry.attempts.size() >= attemptLimit) {
				throw new BadRequestException("Attempt limit of ${attemptLimit} reached. Cannot create additional attempts")
			}
		}

		if(plannerEntry.classObj.state == ClassObjState.COMPLETED){
			throw new BadRequestException( messagesUtil.get("attempt.create.class.completed.invalid") )
		}
	
		dto.activityId = plannerEntry.activityId

		Attempt attempt = attemptMapper.map(dto, Attempt.class, true)
        attempt.creditBearing = true

        attemptRepo.save(attemptRepo.findAllByPlannerEntryUuidAndCreditBearing(attempt.plannerEntry.uuid, true).collect{
            it.with {
                it.creditBearing = false
                it
            }
        })

		attempt =  attemptRepo.save(attempt)

		dto = attemptMapper.map(attempt, AttemptDTO.class, true)
		
        return dto

    } 
	
	public Map getAssignmentReview(String token, UUID attemptUuid, UUID plannerEntryUuid, String domain,String items) {
		//TODO simplify and move validation rules to AttemptValidationService
		UUID userUuid = UUID.fromString(jwtService.getUuid(token))
		AppUserType type = jwtService.getRole(token)

		Attempt attempt = attemptRepo.findByUuid(attemptUuid)
		PlannerEntry plannerEntry = plannerEntryRepo.findOne(plannerEntryUuid)

		if(!attempt || !plannerEntry || attempt.plannerEntry.uuid != plannerEntryUuid) {
			throw new InvalidInputException(env.getProperty("plannerEntry.attempt.invalid"))
		}
		
		// admin organization validation
		UUID organizationUUID = plannerEntry?.classObj?.organization?.uuid
		adminOrganizationValidation(userUuid, organizationUUID, type)


		if(type != AppUserType.ADMIN) {
			if(type == AppUserType.STUDENT && plannerEntry.user.uuid != userUuid) {
				throw new ClassObjNotFoundException("role_in_issuer", messagesUtil.get("plannerEntry.role.invalid.student"))
			}
			if (enrollmentRepo.countAllByUserUuidAndClassObjUuid(userUuid, plannerEntry.classObj.uuid) <= 0) {
				throw new ClassObjNotFoundException("role_in_issuer", messagesUtil.get("plannerEntry.role.invalid"))
			}
		}

		LearnosityConfig config = new LearnosityConfig(showCorrectAnswers: false, showInstructorStimulus: false, events: true)
		if(type != AppUserType.STUDENT) {
			config.showCorrectAnswers = true
			config.showInstructorStimulus = true
			config.events = true
		}

		List<String> learnosityItems = attempt.sectionItems.items.uuid.flatten()
		if(items) {
			List<String> itemsInRequest = items.split(",")
			if (!learnosityItems?.containsAll(itemsInRequest)) {
				throw new InvalidInputException(messagesUtil.get("attempts.learnosityitems.invalid",itemsInRequest - learnosityItems))
			} else {
				learnosityItems = itemsInRequest
			}
		}

		try {
			String response = assessmentService.generateSignedReviewInitialisationObject(attempt.user.uuid.toString(), attemptUuid.toString(), attempt.activityId.toString(),
					plannerEntry.assignment.title, domain, learnosityKey, learnositySecret, learnosityItems, config,organisationId)

			// If attempt overrides is empty, call Learnosity to get it
			if(!attempt.responseOverrides) {
				try {
					Map learnosityResponse = learnosityDataService.getClient(domain).getAllSessionsResponsesBySessions([attempt.uuid.toString()])

					if (learnosityResponse.get(attempt.uuid.toString()) != null ) {
						attempt.responseOverrides = new HashMap<>(learnosityResponse.get(attempt.uuid.toString()).responses.collectEntries{resp ->
							return [(resp.responseId):null]
						})
					}
					attemptRepo.save(attempt)
				} catch (LearnosityStatusCodeException learnosityError) {
					logger.error("Failed to update responseIDs for attempt "+ attempt.uuid + " because of learnosity error: "+ learnosityError.jsonObject?.body)
				} catch (Exception e ) {
					logger.error( e )
				}
			}
			Map jsonResp = convertLearnosityRespToJSON(response, attempt.sectionItems, attempt.responseOverrides)
			return jsonResp
		} catch (Exception e) {
			throw new LearnocityClientException(e.message)
		}
	}

	public Attempt validatePatchUpdate(String state, UUID plannerEntryUuid, UUID attemptUuid, String token){

		if (AttemptState.valueOf(state) in [AttemptState.PASSED, AttemptState.FAILED]) {
			throw new BadRequestException("Unable to process the request to update an attempt because the new 'state' passed in is " + state)
		}

		Attempt attempt

		UUID userUuid = UUID.fromString(jwtService.getUuid(token))
		UUID orgUuid = jwtService.getOrgUuid(token)
		AppUserType role = jwtService.getRole(token)

		PlannerEntry plannerEntry = plannerEntryRepo.findByUuid(plannerEntryUuid)
		if(!plannerEntry) {
			throw new NotFoundException("planner entry uuid does not exist")
		}

		// admin organization validation
		UUID organizationUUID = plannerEntry?.classObj?.organization?.uuid
		adminOrganizationValidation(userUuid, organizationUUID, role)

		if(role == AppUserType.STUDENT) {
			attempt = attemptRepo.findByUuidAndUserUuidAndPlannerEntryUuid(attemptUuid, userUuid, plannerEntryUuid)
			if (!attempt) {
				throw new NotFoundException("Unable to find an attempt record.")
			}
		}
		else if(role == AppUserType.ADMIN) {
			attempt = attemptRepo.findByUuidAndPlannerEntryUuid(attemptUuid, plannerEntryUuid)

			if (!attempt) {
				throw new NotFoundException("Unable to find an attempt record.")
			}
			else {
				User student = attempt.user
				// only allow update same school student attempt
				Organization school = student.organizations.find { it.type == OrganizationType.SCHOOL }
				if (school?.uuid != orgUuid) {
					throw new ForbiddenException("User does not have permission to update attempt.", Level.ERROR)
				}
			}
		}
		else if(role == AppUserType.TEACHER) {
			attempt = attemptRepo.findByUuidAndPlannerEntryUuid(attemptUuid, plannerEntryUuid)
			if (!attempt) {
				throw new NotFoundException("Unable to find an attempt record.")
			}
			else {
				PlannerEntry pe = plannerEntryRepo.findOne(attempt.plannerEntry.uuid)
				//only allow attempt from Teacher's classes
				Enrollment enroll = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(pe.classObj.uuid, userUuid, Role.TEACHER)

				if (!enroll) {
					throw new ForbiddenException("User does not have permission to update attempt.", Level.ERROR)
				}
			}
		}

		if (attempt.state in [AttemptState.SUBMITTED, AttemptState.PASSED, AttemptState.FAILED]) {
			throw new BadRequestException("Unable to process the request to update an attempt because the currently existing 'state' is " + attempt.state)
		}

		return attempt
	}

	@Transactional
	public AttemptDTO patch(AttemptDTO dto, UUID plannerEntryUuid, UUID attemptUuid, String token) {
		Attempt existing = validatePatchUpdate(dto.getState(), plannerEntryUuid, attemptUuid, token)
		existing.updatedAt = new Date()
		existing.updatedBy = UUID.fromString(jwtService.getUuid(token))

		// only update fields on the attempt entity if the field is passed in (in the dto).
		attemptMapper.map(dto, existing, false)
		// return a dto with a value for all fields (independent of whether the field was updated or not).
		return (AttemptDTO)attemptMapper.map(existing, AttemptDTO, true)
	}

	@Transactional
    public AttemptDTO update(AttemptDTO dto, UUID plannerEntryUuid, UUID attemptUuid, String token, String domain) {
		//TODO simplify and move validation rules to AttemptValidationService

		Attempt attempt = validatePatchUpdate(dto.getState(), plannerEntryUuid, attemptUuid, token)
		dto.updatedAt = new Date()  


		// only student can submit attempt for one time
		if (AttemptState.valueOf(dto.state) == AttemptState.SUBMITTED && ( attempt.state == AttemptState.IN_PROGRESS ||  attempt.state == AttemptState.SAVED) ) {
			dto = aggregateDtoAndAttempt(dto, attempt)
			handleAttemptSubmit(dto, attempt, domain)
		} 
		else if(AttemptState.valueOf(dto.state) == AttemptState.SAVED){
			AttemptSave attemptSave = attemptSaveService.save(new AttemptSave(
					attempt: attempt,
					sequence: attemptSaveService.getNextSequence(attemptUuid),
					sectionsViewed: dto.sectionsViewed?.sort() ?: [],
					questionsViewed: dto.questionsViewed?.sort() ?: [],
					timeOnTaskSeconds: dto.timeOnTaskSeconds ?: 0,
					createdAt: new Date(),
					createdBy: UUID.fromString(jwtService.getUuid(token))
			))
			dto = aggregateDtoAndAttempt(dto, attempt)
			attempt.saves.add(attemptSave)
		}
		// only update fields on the attempt entity if the field is passed in (in the dto).
		attemptMapper.map(dto, attempt, false)
		// return a dto with a value for all fields (independent of whether the field was updated or not).
		return (AttemptDTO)attemptMapper.map(attempt, AttemptDTO, true)

    }

	private static AttemptDTO aggregateDtoAndAttempt(AttemptDTO dto, Attempt attempt){
		dto.timeOnTaskSeconds = (attempt.timeOnTaskSeconds ?: 0) + (dto.timeOnTaskSeconds ?: 0)
		dto.sectionsViewed = ((attempt.sectionsViewed ?: []) + (dto.sectionsViewed ?: [])).unique().sort()
		dto.sectionCount = dto.sectionsViewed.size()
		dto.questionsViewed = ((attempt.questionsViewed ?: []) + (dto.questionsViewed ?: [])).unique().sort()
		//if check only here to make sure service still works before client begins sending questions_viewed field
		if(dto.questionsViewed) {
			dto.questionsAttemptedCount = dto.questionsViewed.size()
		}
		return dto
	}


	/**
	 * process attempt submission
	 * only student can submit attempt
	 * @param dto
	 * @return
	 */
	private void handleAttemptSubmit(AttemptDTO dto, Attempt attempt, String domain){

		try {
			Map learnosityResponse = learnosityDataService.getClient(domain).getAllSessionsResponsesBySessions([attempt.uuid.toString()])


			if(!learnosityResponse) {
				logger.error( "Failed to update responseIDs for attempt "+ attempt.uuid + " as getAllSessionsResponsesBySessions came back empty");
			}

			if (learnosityResponse.get(attempt.uuid.toString()) != null ) {
				LearnosityGetAllSessionsResponse sessionsResponse = learnosityResponse.get(attempt.uuid.toString())

				attempt.responseOverrides = new HashMap<>(sessionsResponse.responses.collectEntries{response ->
					return [(response.responseId):null]
				})

				//TODO simplify and move validation rules to AttemptValidationService
				// default to PlannerEntry.status to COMPLETED
				attempt.plannerEntry.status = PlannerEntryState.COMPLETED

				if(dto.questionCount > 0 && dto.questionsAttemptedCount == dto.questionCount && !dto.includedManualGraded) {

					Double threshold = findThresholdByAttemptType(attempt.plannerEntry.assignment.type, attempt.plannerEntry.classObj.uuid)

					GpaScoresInput gpaInput = new GpaScoresInput(
							questions: sessionsResponse.responses.collect{new GpaScoresInput.Question(score: it.score ?: 0, max_score: it.maxScore, id: it.responseId)},
							settings: new GpaScoresInput.Settings(threshold: (threshold as Integer)),
							learnosity : new GpaScoresInput.Learnosity(session_id : attempt.uuid.toString(), client_domain : domain),
							user_id : attempt.user.uuid
					)
					OutcomeResponse result = gpaService.calculateScores(gpaInput)

					dto.state = result.status.toString()
					dto.assessmentScore = result.score

					attempt.plannerEntry.status = PlannerEntryState.GRADED
				}
				if(dto.completedAt){
					attempt.completedAt = dto.completedAt
				}

			} else {
				throw new BadRequestException("Failed to update responseIDs for attempt "+ attempt.uuid + ". Learnosity returned "+learnosityResponse, Level.ERROR)
			}
		} catch (LearnosityStatusCodeException learnosityError ) {
			throw new BadRequestException("Failed to update responseIDs for attempt "+ attempt.uuid + " because of learnosity error: "+ learnosityError.jsonObject?.body, Level.ERROR, learnosityError)
		} catch (Exception e ) {
			throw new BadRequestException(e.message, Level.ERROR, e)
		}
	}


	private static Map convertLearnosityRespToJSON(String learnosityResponse, def attemptSections, Map responseOverrides) {
		def jsonMap = [learnosity_initialization_object: learnosityResponse, section_items: attemptSections,response_overrides:responseOverrides]
		return jsonMap
	}
	
	
	@Transactional( isolation=Isolation.READ_COMMITTED )
	public Attempt deleteAttempt( UUID plannerEntryUuid, UUID attemptUuid, UUID userUuid, UUID orgUuid, AppUserType role ){
		try{
			Attempt attempt = attemptValidationService.validateDeleteAttempt(plannerEntryUuid, attemptUuid, userUuid, orgUuid, role)
            attemptRepo.delete(attempt.uuid)

            Attempt newLatest = attemptRepo.findFirstByPlannerEntryUuidAndStateNotOrderByCreatedAtDesc(plannerEntryUuid, AttemptState.OBE)
            if(newLatest){
                newLatest.creditBearing = true
                attemptRepo.save(newLatest)
            }

			return attempt
		}
		catch( CustomException ex ){
			throw ex
		}
		catch( Exception ex ){
			throw new InternalServerErrorException( "An error occurred when trying to delete an Attempt.", Level.ERROR , ex )
		}
	}
	
	Page findByPageUuid(UUID pageUuid, String filter, Boolean latest, Boolean includeOBE, OffsetBasedPageRequest pageable) {
		attemptDao.findByPageUuid(pageUuid, filter, latest, includeOBE, pageable)
	}


	@Transactional( isolation=Isolation.READ_COMMITTED )
	PageAttemptDTO updateResponses(UUID plannerEntryUuid, UUID attemptUuid, ResponseOverridesDTO responseOverridesDTO, String domain, String token) {
		PlannerEntry plannerEntry = plannerEntryRepo.findOne(plannerEntryUuid)
		Attempt attempt = attemptRepo.findOne(attemptUuid)
		AppUserType type = jwtService.getRole(token)
		User user = userRepo.findByUuid(UUID.fromString(jwtService.getUuid(token)))
		
		if(type != AppUserType.ADMIN && type != AppUserType.TEACHER){
			throw new ForbiddenException("Only ADMINS and TEACHERS are authorized to use this service", Level.INFO)
		}
		if(!attempt || !plannerEntry){
			String message = !attempt ? "Invalid attempt uuid" : "Invalid planner entry uuid"
			throw new NotFoundException(message)
		}
		if(type == AppUserType.TEACHER){
			Enrollment enroll = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(plannerEntry.classObj.uuid, UUID.fromString(jwtService.getUuid(token)), Role.TEACHER)
			if(!enroll) {
				throw new ForbiddenException("Teacher must be enrolled to modify responses", Level.INFO)
			}
		}
		
		if(type == AppUserType.ADMIN) {
			User student = attempt.user
			Organization school = student.organizations.find{it.type == OrganizationType.SCHOOL}
			if (school.uuid != jwtService.getOrgUuid(token)) {
				throw new ForbiddenException("Admin does not have access to this organization ${school.uuid}", Level.WARN)
			}
		}

		if(!attempt.responseOverrides){
			throw new BadRequestException("Attempt ${attempt.uuid} does not have existing responses to override", Level.ERROR)
		}

		Lock lock = lockRepo.findByResourceUuidAndLockedByUserUuid(attempt.uuid, user.uuid)
		if(!lock) {
			throw new ForbiddenException("User does not have a valid lock on the attempt", Level.INFO)
		}

		Map<String, Boolean> responseOverrides = (HashMap<String, Boolean>)responseOverridesDTO.responseOverrides.collectEntries {
			return [(it.responseId): it.credit]
		}

		List<String> missingKeys = responseOverrides.keySet().asList().findAll{
			return !attempt.responseOverrides.keySet().contains(it)
		}
		if(missingKeys){
			throw new BadRequestException("Response ids ${missingKeys} were not found in the original attempt responses")
		}
		
		// compare responseOverrides passed in the request with the responseOverrides associated with the attempt object. for each entry in responseOverrides that has changed, create a new record in the AttemptOverridesHistory table
		Map<String, Boolean> changedResponseOverrides = responseOverrides - attempt.responseOverrides
		if( changedResponseOverrides && !changedResponseOverrides.isEmpty() ){
			Date now = new Date()
			for(Map.Entry<String, Boolean> changedResponseOverride : changedResponseOverrides ){
				AttemptOverridesHistory history = new AttemptOverridesHistory()
				history.dateOverridden = now
				history.firstName = user.firstName
				history.lastName = user.lastName
				history.attemptUUID = attempt.uuid
				history.userUUID = user.uuid
				history.createdAt = now
				history.createdBy = user.uuid
				history.assignmentUUID = plannerEntry.assignment.uuid
				history.pageAssignmentUUID = plannerEntry.activityId
				history.responseID = changedResponseOverride.getKey()
				history.credit = changedResponseOverride.getValue()
				attemptOverridesHistoryRepo.save(history)
			}
		}	
		

		Double threshold = findThresholdByAttemptType(attempt.plannerEntry.assignment.type, plannerEntry.classObj.uuid)

		OutcomeResponse outcomeResponse
		try {
			outcomeResponse = calculateOutcome(responseOverrides, threshold, attempt.uuid.toString(), attempt.user.uuid.toString(), domain, true)
		}
		catch(LearnosityStatusCodeException e){
			String message = "Attempt ${attempt.uuid}, Learnosity error: ${e.jsonObject}"
			throw new BadRequestException(message, Level.ERROR, e)
		}
		catch(LearnosityUpdateScoreException e){
			String message = "Attempt ${attempt.uuid}, Learnosity error: " + [message: e.learnosityMessage, code: e.learnosityCode]
			throw new BadRequestException(message, Level.ERROR, e)
		}

		Map<String,Boolean> newTeacherOverrides = attempt.responseOverrides + responseOverrides

		attempt.state = AttemptUtil.convertOutcomeState(outcomeResponse.status)
		attempt.assessmentScore = outcomeResponse.score
		attempt.responseOverrides = newTeacherOverrides
		attempt.updatedAt = new Date()

		if(attempt.state in [AttemptState.PASSED, AttemptState.FAILED]){
			plannerEntry.status = PlannerEntryState.GRADED
		}
		else{
			plannerEntry.status = PlannerEntryState.COMPLETED
		}
		plannerEntry.updated = new Date()
		plannerEntryRepo.save(plannerEntry)

		PageAttemptDTO pageAttemptDto = AttemptUtil.convertAttemptToPageAttempt(attemptRepo.save(attempt))

		return setScoreMap(pageAttemptDto)
	}

	public Map getAttemptsByPageAssignmentReport(PageAssignment pageAssignment, String prefix, String domain){
		List<LearnositySessionListByItemRequest> requestList = generateLearnosityReportList(pageAssignment, prefix)
		if(requestList) {
			String initObj = learnosityReportingService.getClient(domain).generateSignedSessionsListByItemReportInitialisationObject(pageAssignment.uuid.toString(), requestList)
			return [learnosity_initialization_object: initObj, report_ids: requestList.report_id]
		}
		return [:]
	}

	public List<LearnositySessionListByItemRequest> generateLearnosityReportList(PageAssignment pageAssignment, String prefix){
		List<User> users = attemptDao.findUserAttemptsByPageAssignment(pageAssignment)
		List<LearnositySessionListByItemRequest> requestList = []
		if(users) {
			List<User> unprocessedUsers = users.sort { a1, a2 ->
				a1.lastName <=> a2.lastName
			}
			Integer curReportNum = 1
			Integer curUsersInReport = 0
			List<LearnosityReportUser> curUserList = []

			while (unprocessedUsers.size()) {
				User first = unprocessedUsers.first()
				List<User> workingSet = unprocessedUsers.takeWhile {
					it.uuid == first.uuid
				}
				unprocessedUsers.removeAll(workingSet)
				if ((workingSet.size() + curUsersInReport) > attemptsPerReport) {
					requestList.add(
							new LearnositySessionListByItemRequest(
									report_id: "${prefix}-${curReportNum++}",
									users: curUserList
							)
					)
					curUserList = []
					curUsersInReport = 0
				}
				curUsersInReport += workingSet.size()
				curUserList.add(
						new LearnosityReportUser(uuid: first.uuid.toString(), displayName: "${first.firstName} ${first.lastName}")
				)
			}

			requestList.add(
					new LearnositySessionListByItemRequest(
							report_id: "${prefix}-${curReportNum}",
							users: curUserList
					)
			)
		}

		return requestList
	}

    public Page<ItemAnalysisReportAttempt> getItemAnalysisReport(PageAssignment pageAssignment, String filter, Map<String, String> mappings, String domain, Pageable pageable) {


        Specification statusFilter = new Specification<Attempt>() {
            @Override
            Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                return root.get("state").in([AttemptState.SUBMITTED, AttemptState.PASSED, AttemptState.FAILED])
            }
        }
        Specification plannerEntryFilter = new Specification<Attempt>() {
            @Override
            Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.notEqual(root.get("plannerEntry").get("status"), PlannerEntryState.OBE)
            }
        }
        Specification enrolledFilter = new Specification<Attempt>() {
            @Override
            Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Enrollment> enrollments = enrollmentRepo.findAllByClassObjUuid(pageAssignment.pageObj.classObj.uuid)
                return enrollments ? root.get("user").get("uuid").in(enrollments.user.uuid) : cb.or()
            }
        }
        Specification assignmentFilter = new Specification<Attempt>() {
            @Override
            Predicate toPredicate(Root<Attempt> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                return cb.equal(root.get("activityId"), pageAssignment.uuid)
            }
        }

        Specification spec = Specifications.where(assignmentFilter).and(statusFilter).and(plannerEntryFilter).and(enrolledFilter)

        Page<Attempt> attemptPage
        if(filter){
            attemptPage = filterService.find(filter, Attempt, attemptRepo, pageable, mappings, {
                spec
            })
        }
        else {
            attemptPage = attemptRepo.findAll(spec, pageable)
        }

        List<String> sessions = attemptPage.content.uuid*.toString()
        if(!sessions) {
            return attemptPage
        }

        LearnosityDataClient learnosityDataClient = learnosityDataService.getClient(domain)
        Map<String, LearnosityGetAllSessionsResponse> learnosityScoresMap = learnosityDataClient.getAllSessionsResponsesBySessions(sessions)
        return attemptPage.map(new Converter<Attempt, ItemAnalysisReportAttempt>() {
            @Override
            ItemAnalysisReportAttempt convert(Attempt source) {
				return new ItemAnalysisReportAttempt(
                        creditBearing: source.creditBearing,
                        userUuid: source.user.uuid,
                        firstName: source.user.firstName,
                        lastName: source.user.lastName,
                        activityId: source.activityId,
                        sessionId: source.uuid,
                        dateSubmitted: source.completedAt,
                        status: source.state,
						plannerEntryUuid: source.plannerEntry.uuid,
                        questions: learnosityScoresMap.get(source.uuid.toString()).responses.collect{ response ->
                            new Question(
                                    responseId: response.responseId,
                                    itemReference: response.itemReference,
                                    questionReference: response.questionReference,
                                    score: response.score,
                                    maxScore: response.maxScore,
                                    attempted: response.attempted,
                                    overridden: source.responseOverrides?.get(response.responseId) != null
                            )
                        }
                )
            }
        })
    }

	private Double findThresholdByAttemptType(AssignmentType type, UUID classUuid){
		Double threshold = null
		SettingDTO settings = settingService.findClassSettings(classUuid)
		if (type == AssignmentType.LESSON) {
			threshold = settings.value.classroom.lessons.threshold as Double
		}
		else if (type == AssignmentType.PROJECT) {
			threshold = settings.value.classroom.projects.threshold as Double
		}
		if(!threshold){
			throw new BadRequestException("Could not look up threshold setting for ${type}")
		}
		return threshold
	}

	private OutcomeResponse calculateOutcome(HashMap<String, Boolean> responseMap, Double threshold, String sessionId, String userUuid, String domain, Boolean includeSubmitted = false) {

		LearnosityDataClient learnosityDataClient = learnosityDataService.getClient(domain)

		LearnosityGetAllSessionsResponse result = learnosityDataClient.getAllSessionsResponsesBySessions([sessionId]).get(sessionId)
		if (!result) {
			throw new BadRequestException("Empty result from learnosity, possible unknown sessionId ${sessionId}", Level.ERROR)
		}
		List<LearnosityResponse> scores = responseMap.collect { String key, Boolean value ->
			return new LearnosityResponse(
					responseId: key,
					score: value ? MAX_SCORE : value == false ? MIN_SCORE : null,
					maxScore: MAX_SCORE
			)
		}

		LearnosityUpdateSessionResponse jobRef = learnosityDataClient.updateSessionResponsesWithScore(userUuid, sessionId, scores)

		learnosityJobStatusJmsService.create(new LearnosityJobStatusJmsDTO(
				jobId: jobRef.jobReferenceID,
				domain: domain
		))


		responseMap.each { key, value ->
			def target = result.responses.find { it.responseId == key }

			target.maxScore = MAX_SCORE
			if (value == true) {
				target.score = target.maxScore
			}
			else if (value == false) {
				target.score = MIN_SCORE
			}
		}

		GpaScoresInput gpaInput = new GpaScoresInput(
				questions: result.responses.collect{new GpaScoresInput.Question(score: it.score ?: 0, max_score: it.maxScore, id: it.responseId)},
				settings: new GpaScoresInput.Settings(threshold: (threshold as Integer)),
				learnosity : new GpaScoresInput.Learnosity(session_id : sessionId, client_domain : domain),
				user_id : userUuid
		)
		OutcomeResponse outcomeResponse = new OutcomeResponse()

		if (includeSubmitted && result.responses.any { it.score == null }) {
			outcomeResponse.status = OutcomeStatus.SUBMITTED
			outcomeResponse.score = null
		}
		else{
			outcomeResponse = gpaService.calculateScores(gpaInput)
		}
		return outcomeResponse
	}
	
	
	public AttemptOverridesHistoryWrapperDTO getAttemptOverridesHistories(Pageable pageable, String filter, UUID attemptUUID, UUID plannerEntryUUID, String userUUID, AppUserType role){
		
		PlannerEntry plannerEntry = plannerEntryRepo.findByUuid(plannerEntryUUID)
		Attempt attempt = attemptRepo.findByUuid(attemptUUID)
		if( !plannerEntry || !attempt || attempt.plannerEntry.uuid != plannerEntry.uuid ){
			throw new NotFoundException(env.getProperty("plannerentry.attempt.not.valid"))
		}
		
		// admin organization validation
		adminOrganizationValidation(UUID.fromString(userUUID), plannerEntry?.classObj?.organization?.uuid, role)
		
		// teacher class validation
		teacherClassValidation(UUID.fromString(userUUID), plannerEntry.classObj, role)
		
		Page<AttemptOverridesHistory> historiesPage
		if( filter ){
			// create a Specification that appends to the query the where clause by attempt_uuid
			Closure<Specification> mainFilter = {
				return new Specification<AttemptOverridesHistory>(){
					@Override
					Predicate toPredicate(Root<AttemptOverridesHistory> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
						return cb.equal(root.getAt("attemptUUID"), attemptUUID)
					}
				}
			}
			historiesPage = filterService.find(filter, AttemptOverridesHistory, attemptOverridesHistoryRepo, pageable, [:], mainFilter)
		}
		else{
			historiesPage = attemptOverridesHistoryRepo.findAllByAttemptUUID(attemptUUID, pageable)

		}	
		List<AttemptOverridesHistoryDTO> historiesDTO = mapper.listMapAll(historiesPage.getContent(), AttemptOverridesHistoryDTO.class)
		return new AttemptOverridesHistoryWrapperDTO(historiesDTO, historiesPage)
	}

	public PageAttemptDTO setScoreMap(PageAttemptDTO attempt) {
		UUID classUuid = UUID.fromString(classRepo.findClassUuidByAttempt(attempt.attemptUuid))
		attempt.earnedScore = scoreMapUtil.getScoreAsMap(classUuid, attempt.assessmentScore?.toBigDecimal())

		return attempt
	}
	
}
