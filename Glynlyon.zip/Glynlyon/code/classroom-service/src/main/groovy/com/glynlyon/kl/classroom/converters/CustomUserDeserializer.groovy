package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.UserRepo
import org.springframework.beans.factory.annotation.Autowired

class CustomUserDeserializer extends StdDeserializer<User> {

    @Autowired
    UserRepo userRepo

    protected CustomUserDeserializer() {
        super(User)
    }

    @Override
    User deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        return LocalDeserializerHelper.deserialize(p, ctxt, userRepo, "user_uuid", "user")
    }
}
