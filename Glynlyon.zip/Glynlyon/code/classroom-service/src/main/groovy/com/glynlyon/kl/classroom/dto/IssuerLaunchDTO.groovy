package com.glynlyon.kl.classroom.dto

import javax.validation.constraints.NotNull

class IssuerLaunchDTO {

    @NotNull
    String action
}
