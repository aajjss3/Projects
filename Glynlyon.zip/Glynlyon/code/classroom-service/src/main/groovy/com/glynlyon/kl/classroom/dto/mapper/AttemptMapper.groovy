package com.glynlyon.kl.classroom.dto.mapper

import com.glynlyon.kl.classroom.dao.AttemptDao
import com.glynlyon.kl.classroom.dto.AttemptDTO
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.util.ScoreMapUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Component
/**
 * Migrates data from an Attempt to an AttempDTO and visa versa.
 * @author asparago
 *
 */
@Component
class AttemptMapper extends AbstractMapper{

	@Autowired
	ScoreMapUtil scoreMapUtil
	
	@Autowired
	ClassRepo classRepo

	protected void custom (Object source, Object destination, boolean mapIfNull){
		// map specific field names that don't match between AttemptDTO and Attempt
		if( source instanceof AttemptDTO) {
			if( source.state ){
				((Attempt)destination).state = AttemptState.valueOf(source.state)
			}
			else if(source.status){
				((Attempt)destination).state = AttemptState.valueOf(source.status)
			}
			else if( mapIfNull ){
				((Attempt)destination).state = null
			}
			if( source.sectionItems ){
				((Attempt)destination).sectionItems = source.sectionItems
			}
			else if( mapIfNull ){
				((Attempt)destination).sectionItems = null
			}
			if( source.plannerEntryUuid ){
				PlannerEntry plannerEntry = new PlannerEntry()
				plannerEntry.uuid = source.plannerEntryUuid
				((Attempt)destination).plannerEntry = plannerEntry
			}
			if( source.userUuid ){
				User user= new User()
				user.uuid = source.userUuid
				((Attempt)destination).user = user
			}
		}
		// map specific field names that don't match between Attempt and AttemptDTO
		else if (source instanceof Attempt){
			UUID classUuid = UUID.fromString(classRepo.findClassUuidByAttempt(source.uuid))

			((AttemptDTO)destination).sectionItems = source.sectionItems
			((AttemptDTO)destination).plannerEntryUuid = source.plannerEntry.uuid
			((AttemptDTO)destination).userUuid = source.user.uuid
			((AttemptDTO)destination).saves = source?.saves?.sort { a, b ->
				a.sequence <=> b.sequence
			}
			((AttemptDTO)destination).earnedScore = scoreMapUtil.getScoreAsMap(classUuid, source.assessmentScore?.toBigDecimal())
		}
		
	}
	
}
