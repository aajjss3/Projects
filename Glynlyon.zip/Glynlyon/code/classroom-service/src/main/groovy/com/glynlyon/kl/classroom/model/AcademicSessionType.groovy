package com.glynlyon.kl.classroom.model

public enum AcademicSessionType {
    TERM,
    GRADING_PERIOD,
    SEMESTER
}