package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.service.AcademicSessionService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes
import javax.servlet.http.HttpServletRequest

class CustomAcademicSessionSerializer extends JsonSerializer<AcademicSession> {

    @Autowired
    AcademicSessionService academicSessionService

    @Override
    void serialize(AcademicSession academicsession, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
        
        //AcademicSession academicsession = academicSessionService.findOne(value)


        gen.writeStartObject()
        gen.writeStringField("academic_session_uuid", academicsession.uuid.toString())
        gen.writeStringField("name", academicsession.name)
        gen.writeStringField("type", academicsession.type.toString())
        gen.writeObjectField("start_date", academicsession.startDate)
        gen.writeObjectField("end_date", academicsession.endDate)
        gen.writeObjectField("_links", ["self": ["href": serverRoot + "/academicsessions/" + academicsession.uuid.toString()]])
        gen.writeEndObject()

    }

}
