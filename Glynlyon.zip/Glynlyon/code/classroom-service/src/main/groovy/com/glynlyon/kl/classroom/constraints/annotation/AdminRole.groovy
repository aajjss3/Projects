package com.glynlyon.kl.classroom.constraints.annotation

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target
import javax.validation.Constraint
import javax.validation.Payload
import com.glynlyon.kl.classroom.constraints.validator.AdminRoleValidator



@Target([ElementType.FIELD, ElementType.TYPE, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = AdminRoleValidator.class)
@Documented
@Inherited
public @interface AdminRole {
	String message() default "not an admin"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
