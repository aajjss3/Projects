package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.hibernate.PGEnumUserType

import org.hibernate.annotations.Parameter
import org.hibernate.annotations.Type
import org.hibernate.annotations.TypeDef
import org.hibernate.annotations.TypeDefs

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Table
import javax.persistence.Version

@Entity
@Table(name = 'sync')
@TypeDefs([
        @TypeDef(name = 'enum', typeClass = PGEnumUserType)
])
class Sync implements GroovyObject, Serializable {
	
	@JsonIgnore
	@Version
	public long version
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "uuid", nullable = false)
    UUID uuid

    //OW Shard ID against which the sync ran.
    @Column(name = "origination_id", nullable = false)
    @JsonProperty(value = "origination_id")
    String originationId

    //Classroom server instance on which this job ran (for debugging).
    @Column(name = "server_name", nullable = false)
    @JsonProperty(value = "server_name")
    String serverName

    @Column(name = "started_at", nullable = false)
    @JsonProperty(value = "started_at")
    Date startedAt

    @Column(name = "ended_at", nullable = true)
    @JsonProperty(value = "ended_at")
    Date endedAt

    @Column(nullable = false)
    @Type(type = 'enum', parameters = [
            @Parameter(name = 'enumClassName', value = 'com.glynlyon.kl.classroom.model.SyncStatus')
    ])
    SyncStatus status

}
