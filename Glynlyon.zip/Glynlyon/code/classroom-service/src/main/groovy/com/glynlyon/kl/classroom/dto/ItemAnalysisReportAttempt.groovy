package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.model.AttemptState

class ItemAnalysisReportAttempt {

    @JsonProperty("credit_bearing")
    Boolean creditBearing

    @JsonProperty("user_uuid")
    UUID userUuid

    @JsonProperty("first_name")
    String firstName

    @JsonProperty("last_name")
    String lastName

    @JsonProperty("activity_id")
    String activityId

    @JsonProperty("session_id")
    String sessionId

    @JsonProperty("planner_entry_uuid")
    String plannerEntryUuid

    @JsonProperty("date_submitted")
    Date dateSubmitted

    @JsonProperty("status")
    AttemptState status

    List<Question> questions

}

public class Question {
    @JsonProperty("response_id")
    String responseId

    @JsonProperty("item_reference")
    String itemReference

    @JsonProperty("question_reference")
    String questionReference

    BigDecimal score

    @JsonProperty("max_score")
    BigDecimal maxScore

    Boolean attempted

    Boolean overridden
}