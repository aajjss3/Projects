package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Launch
import org.springframework.data.repository.CrudRepository

interface LaunchRepo extends CrudRepository<Launch, UUID>{

    Launch findByUuid(UUID launchUuid)
}