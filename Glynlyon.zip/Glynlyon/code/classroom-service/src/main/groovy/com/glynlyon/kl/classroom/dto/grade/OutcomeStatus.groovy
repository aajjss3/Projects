package com.glynlyon.kl.classroom.dto.grade

enum OutcomeStatus {
    PASSED,
    FAILED,
    SUBMITTED
}
