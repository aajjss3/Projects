package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.DefaultSubject
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.CrudRepository

interface DefaultSubjectRepo extends CrudRepository<DefaultSubject, UUID>, JpaSpecificationExecutor{
    List<DefaultSubject> findAllByNameIgnoreCase(String name)
}