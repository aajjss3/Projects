package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty

class CourseSuccessMsg extends CourseMessage {

    @Override
    String getContainer() {
        return "successes"
    }

    @JsonProperty(value = "course_uuid")
    UUID courseUuid
}
