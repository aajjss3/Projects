package com.glynlyon.kl.classroom.constraints

import com.glynlyon.kl.classroom.repo.OrganizationRepo
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class OrgValidator implements ConstraintValidator<ValidOrg, UUID> {

    @Autowired
    OrganizationRepo organizationRepo

    @Override
    void initialize(ValidOrg constraintAnnotation) {}

    @Override
    boolean isValid(UUID uuid, ConstraintValidatorContext context) {
        return !uuid || organizationRepo.findOne(uuid)
    }
}
