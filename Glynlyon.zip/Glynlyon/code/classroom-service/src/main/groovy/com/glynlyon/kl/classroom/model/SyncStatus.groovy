package com.glynlyon.kl.classroom.model

enum SyncStatus {
    IN_PROGRESS,
    SUCCESS,
    ERROR
}
