package com.glynlyon.kl.classroom.constraints

import com.glynlyon.kl.classroom.repo.UserRepo
import org.springframework.beans.factory.annotation.Autowired

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class UserValidator implements ConstraintValidator<ValidUser, UUID> {

    @Autowired
    UserRepo userRepo

    @Override
    void initialize(ValidUser constraintAnnotation) {}

    @Override
    boolean isValid(UUID uuid, ConstraintValidatorContext context) {
        return !uuid || userRepo.findOne(uuid)
    }
}
