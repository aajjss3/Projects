package com.glynlyon.kl.classroom.exceptions

class InvalidRoleException extends RuntimeException {
    InvalidRoleException() {
        super()
    }

    InvalidRoleException(String message) {
        super(message)
    }

    InvalidRoleException(String message, Throwable cause) {
        super(message, cause)
    }

    InvalidRoleException(Throwable cause) {
        super(cause)
    }

    protected InvalidRoleException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
