package com.glynlyon.kl.classroom.model

enum OrganizationType {
    SCHOOL,
    CAMPUS
}
