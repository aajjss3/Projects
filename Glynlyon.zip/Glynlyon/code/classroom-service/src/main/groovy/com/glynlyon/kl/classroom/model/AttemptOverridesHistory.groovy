package com.glynlyon.kl.classroom.model

import groovy.lang.GroovyObject
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

import java.io.Serializable
import java.util.Date
import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table
import javax.persistence.Version

import org.hibernate.annotations.DynamicInsert

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty


@Entity
@Table(name="attempt_overrides_history", indexes=[@Index(name="attempt_overrides_history_indx", columnList="attempt_uuid, response_id")])
@EqualsAndHashCode(includes=['uuid'])
@ToString
class AttemptOverridesHistory implements GroovyObject, Serializable {
	
	@JsonIgnore
	@Version
	public long version
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JsonProperty(value = "attempt_overrides_uuid", access = JsonProperty.Access.READ_ONLY)
	public UUID uuid
	
	@Column(name = "created_at", nullable = true)
	@JsonProperty(value = "created_at")
	public Date createdAt

	@Column(name = "created_by", nullable = true)
	@JsonProperty(value = "created_by")
	public UUID createdBy
	
	@Column(name = "attempt_uuid", nullable = false)
	@JsonProperty(value = "attempt_uuid")
	public UUID attemptUUID
	
	
	@Column(name = "response_id", nullable = false)
	@JsonProperty(value = "response_id")
	public String responseID
	
	@Column(name = "page_assignment_uuid", nullable = false)
	@JsonProperty(value = "page_assignment_uuid")
	public UUID pageAssignmentUUID
	
	@Column(name = "assignment_uuid", nullable = false)
	@JsonProperty(value = "assignment_uuid")
	public UUID assignmentUUID
	
	@Column(name = "credit", nullable = true)
	@JsonProperty(value = "credit")
	public Boolean credit
	
	@Column(name = "date_overridden", nullable = false)
	@JsonProperty(value = "date_overridden")
	public Date dateOverridden

	@Column(name = "user_uuid", nullable = false)
	@JsonProperty(value = "user_uuid")
	public UUID userUUID
	
	@Column(name = "first_name", nullable = true)
	@JsonProperty(value = "first_name")
	public String firstName
	
	@Column(name = "last_name", nullable = true)
	@JsonProperty(value = "last_name")
	public String lastName
	
}
