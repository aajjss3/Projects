package com.glynlyon.kl.classroom.util

import com.fasterxml.jackson.databind.util.ISO8601Utils

import java.text.FieldPosition
import java.text.ParseException
import java.text.ParsePosition

class DateFormat extends java.text.DateFormat{

    @Override
    StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
        String value = ISO8601Utils.format(date, false, TimeZone.getDefault())
        toAppendTo.append(value)
        return toAppendTo
    }

    @Override
    Date parse(String source, ParsePosition pos) {
        return ISO8601Utils.parse(source, pos)
    }

    //supply our own parse(String) since pos isn't updated during parsing,
    //but the exception should have the right error offset.
    @Override
    public Date parse(String source) throws ParseException {
        return parse(source, new ParsePosition(0))
    }

    @Override
    public Object clone() {
        /* Jackson calls clone for every call. Since this instance is
         * immutable (and hence thread-safe)
         * we can just return this instance
         */
        return this
    }

}
