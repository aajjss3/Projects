package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.AttemptUuidSerializer

import groovy.transform.EqualsAndHashCode

import org.hibernate.annotations.Parameter
import org.hibernate.annotations.Type

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.Version
import javax.validation.constraints.NotNull

@Entity
@EqualsAndHashCode(includeFields = true)
class AttemptSave implements GroovyObject, Serializable {
	
	@JsonIgnore
	@Version
	public long version

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonProperty(value = "attempt_save_uuid", access = JsonProperty.Access.READ_ONLY)
    UUID uuid

	@JsonProperty(value = "attempt_uuid")
    @JsonSerialize(using = AttemptUuidSerializer)
	@JoinColumn(name = "attempt_uuid", nullable = false)
	@ManyToOne
    @NotNull(message = "Missing required field attempt_uuid")
	Attempt attempt

    Integer sequence

    @Column(name = 'sections_viewed', nullable = false)
    @Type(type = 'jsonb', parameters = [
            @Parameter(name = 'jsonClass', value = 'java.util.List')
    ])
    @NotNull(message = "Missing required field sections_viewed")
    @JsonProperty(value = "sections_viewed")
    List sectionsViewed

    @Column(name = 'questions_viewed', nullable = false)
    @Type(type = 'jsonb', parameters = [
            @Parameter(name = 'jsonClass', value = 'java.util.List')
    ])
    @NotNull(message = "Missing required field questions_viewed")
    @JsonProperty(value = "questions_viewed")
    List questionsViewed

    @Column(name = 'time_on_task_seconds', nullable = true)
    @JsonProperty(value = "time_on_task_seconds")
    @NotNull(message = "Missing required field time_on_task_seconds")
    Integer timeOnTaskSeconds

    @Column(name = "created_at", nullable = false)
	@JsonProperty(value = "created_at")
    Date createdAt
	
	@JsonIgnore
	@Column(name = "created_by", nullable = false)
	UUID createdBy

}