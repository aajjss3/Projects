package com.glynlyon.kl.classroom.model


import java.util.UUID

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

import javax.persistence.Column
import javax.persistence.Id
import javax.persistence.MappedSuperclass
import javax.persistence.Version


@MappedSuperclass
class BaseEntity{
		
	@JsonIgnore
    @Version
	public long version
	
	@JsonIgnore
	@Column(name = "updated_by")
	public UUID updatedBy
	@JsonIgnore
	public UUID getUpdatedBy() {
		return updatedBy;
	}

	@JsonProperty("updated_by")
	public void setUpdatedBy(UUID updatedBy) {
		this.updatedBy = updatedBy;
	}
		
}

