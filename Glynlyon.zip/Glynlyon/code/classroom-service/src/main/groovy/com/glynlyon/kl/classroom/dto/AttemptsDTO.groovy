package com.glynlyon.kl.classroom.dto


class AttemptsDTO {
	
	public List<AttemptDTO> attempts = new ArrayList<AttemptDTO>()
	
	public AttemptsDTO(){
	}
	
	public AttemptsDTO( List<AttemptDTO> attempts ){
		this.attempts = attempts
	}
	
}

