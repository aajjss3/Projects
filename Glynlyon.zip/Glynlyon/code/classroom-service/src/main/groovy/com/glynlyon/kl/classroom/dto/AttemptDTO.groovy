package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.constraints.annotation.NotBlankStateAndStatus
import com.glynlyon.kl.classroom.constraints.annotation.NotValidAttemptState
import com.glynlyon.kl.classroom.constraints.group.AttemptCreate
import com.glynlyon.kl.classroom.constraints.group.AttemptUpdate
import com.glynlyon.kl.classroom.constraints.group.AttemptPatch
import com.glynlyon.kl.classroom.model.AttemptSave

import javax.validation.constraints.NotNull

@NotBlankStateAndStatus(message = "{input.field.required}", groups=[AttemptCreate.class, AttemptPatch.class])
@JsonIgnoreProperties(value=["saves"], allowGetters=true)
class AttemptDTO extends BaseDTO{
	
	@JsonProperty(value="attempt_uuid")
	public UUID uuid
	
	@JsonProperty(value="planner_entry_uuid")
	@NotNull(message = "{input.field.required}", groups=[AttemptCreate.class])
	public UUID plannerEntryUuid
	
	@JsonProperty(value="user_uuid")
	@NotNull(message = "{input.field.required}", groups=[AttemptCreate.class])
	public UUID userUuid
	
	@JsonProperty(value="activity_id")
	public UUID activityId
	
	@JsonProperty(value="section_count")
	public Integer sectionCount
	
	@JsonProperty(value="section_total_count")
	public Integer sectionTotalCount
	
	@JsonProperty(value="question_count")
	public Integer questionCount
	
	@JsonProperty(value="questions_attempted_count")
	public Integer questionsAttemptedCount

	@JsonProperty(value="questions_correct_count")
	public Integer questionsCorrectCount

	@JsonProperty(value="questions_incorrect_count")
	public Integer questionsIncorrectCount

	@JsonProperty(value="questions_not_scored_count")
	public Integer questionsNotScoredCount
	
	@JsonProperty(value="state")
	@NotValidAttemptState(message = "{input.attemptstate.notvalid}", groups=[AttemptCreate.class, AttemptUpdate.class, AttemptPatch.class])
	public String state
	
	@JsonProperty(value="time_on_task_seconds")
	public Integer timeOnTaskSeconds

    @JsonProperty(value="assessment_score")
	public Double assessmentScore

	@JsonProperty(value="earned_score")
	public Map<String,Object> earnedScore
	
	@JsonProperty(value="created_at")
	public Date createdAt
	
	@JsonProperty(value="last_modified")
	public Date updatedAt

	@JsonProperty(value="section_items")
	public List sectionItems

	@JsonProperty(value="sections_viewed")
	public List sectionsViewed

	@JsonProperty(value="questions_viewed")
	public List questionsViewed

    @JsonProperty(value="questions_answered")
    public List questionsAnswered
	
	@JsonProperty(value="included_manual_graded")
	public Boolean includedManualGraded
	
	@JsonProperty(value = "response_overrides")
	public HashMap<String, Boolean> responseOverrides
	
	@JsonProperty(value = "completed_at")
	public Date completedAt

	public List<AttemptSave> saves
	
	@JsonProperty(value="status")
	@NotValidAttemptState(message = "{input.attemptstatus.notvalid}", groups=[AttemptCreate.class, AttemptUpdate.class, AttemptPatch.class])
	public String status

    @JsonIgnore
    public Boolean creditBearing


	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public UUID getPlannerEntryUuid() {
		return plannerEntryUuid;
	}

	public void setPlannerEntryUuid(UUID plannerEntryUuid) {
		this.plannerEntryUuid = plannerEntryUuid;
	}

	public UUID getUserUuid() {
		return userUuid;
	}

	public void setUserUuid(UUID userUuid) {
		this.userUuid = userUuid;
	}

	public UUID getActivityId() {
		return activityId;
	}

	public void setActivityId(UUID activityId) {
		this.activityId = activityId;
	}

	public Integer getSectionCount() {
		return sectionCount;
	}

	public void setSectionCount(Integer sectionCount) {
		this.sectionCount = sectionCount;
	}

	public Integer getSectionTotalCount() {
		return sectionTotalCount;
	}

	public void setSectionTotalCount(Integer sectionTotalCount) {
		this.sectionTotalCount = sectionTotalCount;
	}

	public void setEarnedScore(Map<String,Object> earnedScore) {
		this.earnedScore = earnedScore
	}

	public Map<String,Object> getEarnedScore() {
		return earnedScore
	}

	public Integer getQuestionCount() {
		return questionCount;
	}

	public void setQuestionCount(Integer questionCount) {
		this.questionCount = questionCount;
	}

	public Integer getQuestionsAttemptedCount() {
		return questionsAttemptedCount;
	}

	public void setQuestionsAttemptedCount(Integer questionsAttemptedCount) {
		this.questionsAttemptedCount = questionsAttemptedCount;
	}

	public Integer getQuestionsCorrectCount() {
		return questionsCorrectCount;
	}

	public void setQuestionsCorrectCount(Integer questionsCorrectCount) {
		this.questionsCorrectCount = questionsCorrectCount;
	}

	public Integer getQuestionsIncorrectCount() {
		return questionsIncorrectCount;
	}

	public void setQuestionsIncorrectCount(Integer questionsIncorrectCount) {
		this.questionsIncorrectCount = questionsIncorrectCount;
	}

	public Integer getQuestionsNotScoredCount() {
		return questionsNotScoredCount;
	}

	public void setQuestionsNotScoredCount(Integer questionsNotScoredCount) {
		this.questionsNotScoredCount = questionsNotScoredCount;
	}

	public String getState() {
		return (state) ? state : status
	}

	public void setState(String state) {
		this.state = (state) ? state : this.status;
	}

	public Integer getTimeOnTaskSeconds() {
		return timeOnTaskSeconds;
	}

	public void setTimeOnTaskSeconds(Integer timeOnTaskSeconds) {
		this.timeOnTaskSeconds = timeOnTaskSeconds;
	}

	public Double getAssessmentScore() {
		return assessmentScore;
	}

	public void setAssessmentScore(Double assessmentScore) {
		this.assessmentScore = assessmentScore;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List getSectionItems() {
		return sectionItems;
	}

	public void setSectionItems(List sectionItems) {
		this.sectionItems = sectionItems;
	}

	public List getSectionsViewed() {
		return sectionsViewed;
	}

	public void setSectionsViewed(List sectionsViewed) {
		this.sectionsViewed = sectionsViewed;
	}

	public List getQuestionsViewed() {
		return questionsViewed;
	}

	public void setQuestionsViewed(List questionsViewed) {
		this.questionsViewed = questionsViewed;
	}

    public List getQuestionsAnswered() {
        return questionsAnswered
    }

    public void setQuestionsAnswered(List questionsAnswered) {
        this.questionsAnswered = questionsAnswered
    }

	public Boolean getIncludedManualGraded() {
		return includedManualGraded;
	}

	public void setIncludedManualGraded(Boolean includedManualGraded) {
		this.includedManualGraded = includedManualGraded;
	}

	public HashMap<String, Boolean> getResponseOverrides() {
		return responseOverrides;
	}

	public void setResponseOverrides(HashMap<String, Boolean> responseOverrides) {
		this.responseOverrides = responseOverrides;
	}

	public Date getCompletedAt() {
		return completedAt;
	}

	public void setCompletedAt(Date completedAt) {
		this.completedAt = completedAt;
	}

	public List<AttemptSave> getSaves() {
		return saves;
	}

	public void setSaves(List<AttemptSave> saves) {
		this.saves = saves;
	}

	public String getStatus() {
		return (status) ? status : state
	}

	public void setStatus(String status) {
		this.status = (this.state)? this.state : status
	}
	
		
}	

