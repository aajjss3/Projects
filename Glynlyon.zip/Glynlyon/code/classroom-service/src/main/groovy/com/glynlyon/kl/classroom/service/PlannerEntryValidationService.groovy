package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

/**
 * Created by etatarzycki on 5/12/17.
 */

@Service
class PlannerEntryValidationService {

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    JwtService jwtService

    @Autowired
    MessagesUtil messages

    ValidationResult<PlannerEntry> validatePlannerEntry(String token, UUID uuid) {
        PlannerEntry plannerEntry = plannerEntryRepo.findOne(uuid)
        if(!plannerEntry){
            return new ValidationResult<PlannerEntry>(valid: false, message: "Planner entry ${uuid} does not exist")
        }
        UUID userUuid = UUID.fromString(jwtService.getUuid(token))
        AppUserType type = jwtService.getRole(token)

        if(type == AppUserType.ADMIN ||
                (type == AppUserType.TEACHER && enrollmentRepo.countAllByUserUuidAndClassObjUuidAndRole(userUuid, plannerEntry.classObj.uuid, Role.TEACHER) > 0) ||
                (type == AppUserType.STUDENT && userUuid == plannerEntry.user.uuid)){
            return new ValidationResult<PlannerEntry>(obj: plannerEntry, valid: true)
        }

        return new ValidationResult<PlannerEntry>(valid: false, message: "User ${userUuid} does have access to entry ${uuid}")
    }

    PageAssignment validateCreatePlannerEntry(PlannerEntry plannerEntry,
                                                              InputMapperService.MappingResult<PlannerEntry> mappingResult,
                                                              String token){

        //is student still enrolled in this class?
        if(plannerEntry.user.type == AppUserType.STUDENT &&
                enrollmentRepo.countAllByUserUuidAndClassObjUuidAndRole(plannerEntry.user.uuid, plannerEntry.classObj.uuid, Role.STUDENT) == 0){
            mappingResult.errors.add(["field": "planner_entry_uuid", message: messages.get("plannerEntry.create.enrolled.invalid")])
        }

        Long existingSlotHolderCount = plannerEntryRepo.countByUserUuidAndSlot(plannerEntry.user.uuid, plannerEntry.slot)

        UUID userUuid = UUID.fromString(jwtService.getUuid(token))
        AppUserType role = jwtService.getRole(token)
        if(role == AppUserType.STUDENT && plannerEntry.user.uuid != userUuid) {
            mappingResult.errors.add(["field": "user_uuid", message: "STUDENT can only create a planner entry for themselves."])
        }
        if(role != AppUserType.STUDENT) {
            mappingResult.errors.add(["field": "role_in_issuer", message: "Only STUDENT role is allowed to add planner entries."])
        }
        if(plannerEntry.slot <= 0) {
            mappingResult.errors.add(["field": "slot", message: "Slot must be a number greater than 0."])
        }
        if(existingSlotHolderCount > 0) {
            mappingResult.errors.add(["field": "slot", message: "The selected slot is already in use."])
        }
        if(plannerEntry.pageObj.status in [PageState.INACTIVE, PageState.COMPLETED]){
            mappingResult.errors.add(["field": "page_uuid", message: "Cannot create planner entries referencing an INACTIVE or COMPLETED page."])
        }
        if(plannerEntry.classObj.state == ClassObjState.COMPLETED){
            mappingResult.errors.add(["field": "class_uuid", message: messages.get("plannerEntry.create.class.completed.invalid")])
        }
        PageAssignment pageAssignment = pageAssignmentRepo.findByPageObjUuidAndAssignmentUuid(plannerEntry.pageObj.uuid, plannerEntry.assignment.uuid)
        if(!pageAssignment){
            mappingResult.errors.add(["field": "assignment_uuid", message: "Could not find assignment with uuid " + plannerEntry.assignment.uuid])
        }
        
        return pageAssignment
    }

    boolean validateStudentEnrolledInClass(PlannerEntry existing) {
        boolean result = true

        //is student still enrolled in this class?  We only validate the enrollment for slot = -1 that indicates
        //the card / planner entry is not on the canvas
        if(existing.user.type == AppUserType.STUDENT &&
                existing.status != PlannerEntryState.OBE &&
                enrollmentRepo.countAllByUserUuidAndClassObjUuidAndRole(existing.user.uuid, existing.classObj.uuid, Role.STUDENT) == 0){
                result = false
        }
        return result
    }

    boolean validateClassNotEnded(PlannerEntry existing) {
        boolean result = true

        //is the class COMPLETED? We only validate this for slot = -1 that indicates
        //the card / planner entry is not on the canvas
        if(existing.user.type == AppUserType.STUDENT &&
                existing.status != PlannerEntryState.OBE &&
                existing.classObj.state == ClassObjState.COMPLETED){
                result = false
        }
        return result
    }
}
