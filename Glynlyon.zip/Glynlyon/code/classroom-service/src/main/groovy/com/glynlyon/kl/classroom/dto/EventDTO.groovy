package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.constraints.annotation.CustomEnum
import com.glynlyon.kl.classroom.util.EventEnum


/**
 *  This DTO is used for both the request and response for the EventController endpoints
 *  The fields 'time' and 'event' are passed in the request
 *  The field 'eventID' is returned in the reply
 *  To include the fields 'time' and 'event' during json to dto deserialization (ie input) but exclude these fields during dto to json serialization (ie output) see the placement of JsonProperty and JsonIgnore annotations below
 *
 */
class EventDTO {
	
	@JsonIgnore
	private Date time // can be null or empty in request

	@CustomEnum( enumType = EventEnum.class, message = "{input.field.type}", required = true )
	@JsonIgnore
	private EventEnum event // required in request
	
	@JsonProperty(value="event_id")
	private UUID eventID // reply field
	// if no value is passed in for time (time is null) then set the time to be the current time.
	@JsonIgnore
	public Date getTime(){
		return (this.time) ? time : new Date()
	}
	@JsonProperty(value="time")
	public void setTime(Date time) {
		this.time = time
	}
	@JsonIgnore
	public EventEnum getEvent() {
		return event
	}
	@JsonProperty(value="event")
	public void setEvent(EventEnum event) {
		this.event = event
	}
	public UUID getEventID() {
		return eventID
	}
	public void setEventID(UUID eventID) {
		this.eventID = eventID
	}
	
	
}
