package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import org.apache.logging.log4j.Level
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

/**
 * Created by etatarzycki on 5/22/17.
 */

@Service
class AttemptValidationService {

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    Attempt validateDeleteAttempt(UUID plannerEntryUuid, UUID attemptUuid, UUID userUuid, UUID orgUuid, AppUserType role) {

        Attempt attempt = null
        if( role == AppUserType.STUDENT ) {
            attempt = attemptRepo.findByUuidAndUserUuidAndPlannerEntryUuid( attemptUuid, userUuid, plannerEntryUuid )
        }
        else  if( role == AppUserType.ADMIN ){
            attempt = attemptRepo.findByUuidAndPlannerEntryUuid( attemptUuid, plannerEntryUuid )
            if( attempt ){
                User student = attempt.user
                Organization school = student.organizations.find{it.type == OrganizationType.SCHOOL}
                if (!school || school.uuid != orgUuid) {
                    throw new ForbiddenException( "The request to delete an attempt is by an Admin but the admin does not have rights to delete this attempt.", Level.WARN )
                }
            }
        }
        else if( role == AppUserType.TEACHER )  {
            attempt = attemptRepo.findByUuidAndPlannerEntryUuid(attemptUuid, plannerEntryUuid)
            if ( attempt ) {
                PlannerEntry plannerEntry = plannerEntryRepo.findOne(attempt.plannerEntry.uuid)
                Enrollment enroll = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole( plannerEntry.classObj.uuid, userUuid, Role.TEACHER )
                if(!enroll) {
                    throw new ForbiddenException( "The request to delete an attempt is by a Teacher but the teacher does not have rights to delete this attempt.", Level.WARN )
                }
            }
        }

        if( !attempt ){
            throw new NotFoundException("Unable to find an attempt record.")
        }

        if( attempt.state == AttemptState.SUBMITTED || attempt.state == AttemptState.PASSED || attempt.state == AttemptState.FAILED ) {
            throw new ForbiddenException( "Unable to delete the Attempt since its 'state' is : " + attempt.state, Level.WARN  )
        }

        return attempt
    }

    boolean validateStudentEnrolledInClass(Attempt existing) {
        boolean result = true

        //is student still enrolled in this class?  We only validate the enrollment for slot = -1 that indicates
        if(existing.user.type == AppUserType.STUDENT &&
                enrollmentRepo.countAllByUserUuidAndClassObjUuidAndRole(existing.user.uuid, existing.plannerEntry.classObj.uuid, Role.STUDENT) == 0){
            result = false
        }
        return result
    }

    boolean validateClassNotEnded(Attempt existing) {
        boolean result = true

        //is the class COMPLETED?
        if(existing.user.type == AppUserType.STUDENT &&
                existing.plannerEntry.classObj.state == ClassObjState.COMPLETED){
            result = false
        }
        return result
    }
}
