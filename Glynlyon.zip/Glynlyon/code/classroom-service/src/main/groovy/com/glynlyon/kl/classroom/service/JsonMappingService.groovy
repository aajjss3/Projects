package com.glynlyon.kl.classroom.service

import com.fasterxml.jackson.databind.ObjectMapper
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class JsonMappingService {

    @Autowired
    ObjectMapper mapper

    public String getEntityFieldName(String jsonName, Class clazz){

        Class curClass = clazz

        return jsonName.split(/\./).inject("", { String prev, String cur ->
            if(prev) {
                prev.split(/\./).each {
                    curClass = curClass.declaredFields.find { f -> f.name == it }.type
                }
            }
            def type = mapper.getTypeFactory().constructType(curClass)
            def introspection = mapper.getSerializationConfig().introspect(type)
            def props = introspection.findProperties()
            def prop = props.find{ prop ->
                prop.name == cur
            }
            def next = prop?.internalName
            if(!next) {
                throw new UnsupportedFieldException(jsonName)
            }
            if (prop?.findObjectIdInfo() && prop?.findObjectIdInfo()?.alwaysAsId) {
                next = next + "." + prop.findObjectIdInfo().propertyName
            }
            return (prev == "" ? "" : prev + ".") + next
        })
    }
}
