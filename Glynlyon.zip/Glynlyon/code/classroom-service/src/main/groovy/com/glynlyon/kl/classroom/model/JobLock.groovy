package com.glynlyon.kl.classroom.model

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table
import javax.persistence.Version

@Table(name="job_lock", indexes = [ @Index(columnList ="acquired", name="job_lock_acquired_idx"), @Index(columnList ="purpose", name="job_lock_purpose_idx") ])
@Entity
class JobLock {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "job_lock_uuid", nullable = false)
	public UUID uuid
	
	@Version
	public long version

	@Column(name = "acquired", nullable = true)
	public Boolean acquired
	
	@Column(name = "locked_at", nullable = true)
	public Date lockedAt
	
	@Column(name = "locked_by", nullable = true)
	public String lockedBy
	
	@Column(name = "purpose", nullable = true)
	public String purpose

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public Boolean getAcquired() {
		return acquired;
	}

	public void setAcquired(Boolean acquired) {
		this.acquired = acquired;
	}

	public Date getLockedAt() {
		return lockedAt;
	}

	public void setLockedAt(Date lockedAt) {
		this.lockedAt = lockedAt;
	}

	public String getLockedBy() {
		return lockedBy;
	}

	public void setLockedBy(String lockedBy) {
		this.lockedBy = lockedBy;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}


}
