package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.UserRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value

class CustomUserSerializer extends JsonSerializer<User> {

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    @Override
    void serialize(User user, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        gen.writeStartObject()
        gen.writeStringField("user_uuid", user.uuid.toString())
        gen.writeStringField("first_name", user.firstName)
        gen.writeStringField("last_name", user.lastName)
        gen.writeObjectField("last_logged_in_at",user.lastLoggedInAt)
        gen.writeObjectField("_links", ["self": ["href": "${rosteringBaseUri}" + "/users/" + user.uuid]])
        gen.writeEndObject()
    }
}
