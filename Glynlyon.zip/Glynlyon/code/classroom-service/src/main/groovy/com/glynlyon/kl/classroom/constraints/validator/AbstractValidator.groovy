package com.glynlyon.kl.classroom.constraints.validator

import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.apache.logging.log4j.LogManager
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.util.MessagesUtil


class AbstractValidator {

	Logger logger = LogManager.getLogger(this.class)
	
	@Autowired
	JwtService jwtService
	
	@Autowired
	MessagesUtil messages
	
	protected static final int JWT_STARTING_INDEX = 7;
	

	public void initialize(Object constraintAnnotation) {
	}
	
}
