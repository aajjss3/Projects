package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.service.AcademicSessionService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

@RestController
class AcademicSessionController extends AbstractController {

    @Autowired
    AcademicSessionService academicSessionService

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    PageableService pageableService

    @Autowired
    JwtService jwtUtil

    @RequestMapping(path = "/academicsessions", method = RequestMethod.GET, produces = Constants.ACADEMICSESSIONS_VERSION_1)
    public ResponseEntity list(
        @RequestParam(name = "limit", required = false) Integer limit,
        @RequestParam(name = "offset", required = false) Integer offset,
        @RequestParam(name = "sort", required = false) String sort,
        @RequestParam(name = "orderBy", required = false) String orderBy,
        @RequestParam(name = "filter", required = false) String filter,
        @RequestHeader(name = "authorization") auth)
    {
        String token = auth.substring(7)

        //default sort by latest chronological Start Date
        if (!orderBy) orderBy = 'desc'

        Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_ACADEMICDESSION_SORT, AcademicSession)

        Page<AcademicSession> academicSessions = academicSessionService.find(pageable, filter, token)
        HttpHeaders responseHeaders = new LinkHeaderBuilder(academicSessions).addCommonLinks().build(new HttpHeaders())

        if (academicSessions.content.size() == 0) {
            return PagedResponse.createResponse("academic_sessions", academicSessions.content, academicSessions.getNumber() + 1, academicSessions.getNumberOfElements(), academicSessions.getTotalPages(), responseHeaders)
        }

        if (!AcademicSession.isInstance(academicSessions.content[0])) {
            return new ResponseEntity([errors: academicSessions.content], responseHeaders, HttpStatus.BAD_REQUEST)
        } else {
            return PagedResponse.createResponse("academic_sessions", academicSessions.content, academicSessions.getNumber() + 1, academicSessions.getNumberOfElements(), academicSessions.getTotalPages(), responseHeaders)
        }
    }

    @RequestMapping(path = "/academicsessions", method = RequestMethod.POST, produces = Constants.ACADEMICSESSIONS_VERSION_1, consumes = Constants.ACADEMICSESSIONS_VERSION_1)
    ResponseEntity<?> createAcademicsession(
        @RequestBody ObjectNode json, 
        HttpServletRequest req, 
        @RequestHeader(name = "Authorization", required = true) authHeader) 
    {

        String token = authHeader.substring(7)

        if(jwtUtil.getRole(token) != AppUserType.ADMIN) {
            return ResponseEntity.badRequest().body([errors: [ field: "role_in_issuer", message: "User is not authorized to create academic session" ] ])
        }

        def mappingResult = inputMapperService.processInput(json, AcademicSession)
        AcademicSession input = mappingResult.obj

        if(input == null){
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        input.created = new Date()
        input.updated = new Date()
        input.uuid = null

        try {
            def s = academicSessionService.create(input, mappingResult, token)
            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/academicsessions/" + s.uuid)).body(s)
        } catch (Throwable t) {

            if(t?.cause?.cause instanceof ConstraintViolationException){

                ConstraintViolationException constraintViolationException = (ConstraintViolationException)t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, AcademicSession)])
            }
            return  ResponseEntity.badRequest().body([errors: mappingResult.errors])

        }
    }


    @RequestMapping(path = "/academicsessions/{uuid}", method = RequestMethod.PATCH, produces = Constants.ACADEMICSESSIONS_VERSION_1, consumes = Constants.ACADEMICSESSIONS_VERSION_1)
    ResponseEntity<?> patchAcademicSession(
            @RequestBody ObjectNode json,
            @PathVariable("uuid") UUID uuid,
            @RequestHeader(name = "Authorization", required = true) authHeader)
    {

        String token = authHeader.substring(JWT_STARTING_INDEX)

        if(jwtUtil.getRole(token) != AppUserType.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body([errors: [ field: "role_in_issuer", message: "User is not authorized to update academic session" ] ])
        }

        def mappingResult = inputMapperService.processInput(json, AcademicSession)
        AcademicSession input = mappingResult.obj

        if(input == null){
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        try {
            AcademicSession updated = academicSessionService.update(mappingResult, uuid, token)
            return ResponseEntity.ok(updated)
        } catch (Throwable t) {
            if(t?.cause?.cause instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException)t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, AcademicSession)])
            }
            return  ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @DeleteMapping(path = "/academicsessions/{uuid}")
    ResponseEntity<?> deleteAcademicSession(@PathVariable("uuid") UUID uuid, @RequestHeader(name = "Authorization", required = true) authHeader){
        String token = authHeader.substring(JWT_STARTING_INDEX)

        if(jwtUtil.getRole(token) != AppUserType.ADMIN) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body([errors: [ field: "role_in_issuer", message: "User is not authorized to update academic session" ] ])
        }
        academicSessionService.delete(uuid, token)
        return ResponseEntity.noContent().build()
    }

}
