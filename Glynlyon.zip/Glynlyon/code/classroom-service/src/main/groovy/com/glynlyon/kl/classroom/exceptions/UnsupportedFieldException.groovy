package com.glynlyon.kl.classroom.exceptions

class UnsupportedFieldException extends RuntimeException {

    UnsupportedFieldException() {
        super()
    }

    UnsupportedFieldException(String message) {
        super(message)
    }

    UnsupportedFieldException(String message, Throwable cause) {
        super(message, cause)
    }

    UnsupportedFieldException(Throwable cause) {
        super(cause)
    }

    protected UnsupportedFieldException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
