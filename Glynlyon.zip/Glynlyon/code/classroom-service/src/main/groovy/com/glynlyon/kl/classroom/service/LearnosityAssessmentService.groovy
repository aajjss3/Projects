package com.glynlyon.kl.classroom.service
import com.glynlyon.learnosity.client.LearnosityAssessmentClient
import com.glynlyon.learnosity.model.LearnosityConfig
import org.springframework.stereotype.Service

@Service
class LearnosityAssessmentService {

    public String generateSignedReviewInitialisationObject(String userId, String sessionId, String activityId, String assessmentName, String domain, String key, String secret, List<String> items, LearnosityConfig learnosityConfig,Integer organisationId) {
        LearnosityAssessmentClient assessmentClient = new LearnosityAssessmentClient()
        return assessmentClient.generateSignedReviewInitialisationObject(userId, sessionId, activityId,assessmentName, domain, key, secret, items, learnosityConfig,organisationId)
    }
}