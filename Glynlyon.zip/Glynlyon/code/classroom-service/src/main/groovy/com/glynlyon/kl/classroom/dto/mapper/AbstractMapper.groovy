package com.glynlyon.kl.classroom.dto.mapper

import org.springframework.beans.factory.annotation.Autowired


/**
 * All custom DTO and Entity mappings must extend from this class and implement the custom() method.
 * @author asparago
 *
 */
abstract class AbstractMapper{
	
	@Autowired
	BaseMapper baseMapper
	
	/**
	 * 
	 * @param source - can be a List or an object.
	 * @param clazz
	 * @param mapIfNull
	 * @return
	 */
	public Object map( Object source, Class clazz, boolean mapIfNull ){
		Object destination
		if( mapIfNull ){
			if( source instanceof List ){
				destination = baseMapper.listMapAll(source, clazz)
			}
			else{
				destination = baseMapper.defaultMapAll(source, clazz)
			}
		}
		else{
			if( source instanceof List ){
				destination = baseMapper.listMapNonNulls(source, clazz)
			}
			else{
				destination = baseMapper.defaultMapNonNulls(source, clazz)
			}
		}
		if( source instanceof List && destination instanceof List ){
			Iterator itSource = source.iterator()
			Iterator itDestination = destination.iterator()
			while( itSource.hasNext() && itDestination.hasNext() ){
				Object src = itSource.next()
				Object dest = itDestination.next()
				custom(src, dest, mapIfNull)
			}
			return destination
		}
		else{
			custom(source, destination, mapIfNull)
			return destination
		}
	}
	
	/**
	 * 
	 * @param source - cannot be a List, only an object.
	 * @param destination
	 * @param mapIfNull
	 */
	public void map( Object source, Object destination, boolean mapIfNull ){
		if( mapIfNull ){
			baseMapper.defaultMapAll(source, destination)
		}
		else{
			baseMapper.defaultMapNonNulls(source, destination)
		}
		custom(source, destination, mapIfNull)
	}
	
	
	/**
	 * This method must be overridden with custom mapping.
	 * @param source
	 * @param destination
	 * @param mapIfNull - boolean indicating if a field should be mapped if the source value is null
	 */
	protected abstract void custom( Object source, Object destination, boolean mapIfNull )


}
