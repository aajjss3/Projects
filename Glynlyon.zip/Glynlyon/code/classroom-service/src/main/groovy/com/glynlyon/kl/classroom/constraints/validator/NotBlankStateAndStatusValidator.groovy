package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.dto.AttemptDTO
import com.glynlyon.kl.classroom.constraints.annotation.NotBlankStateAndStatus



class NotBlankStateAndStatusValidator  implements ConstraintValidator<NotBlankStateAndStatus, Object>{
	
	@Override
	public void initialize(NotBlankStateAndStatus constraintAnnotation) {
	}
	
	@Override
	/**
	 * dto - Object. either an AttemptDTO or an AttemptPatchDTO
	 */
	public boolean isValid(Object dto, ConstraintValidatorContext context) {
		if (!dto.state && !dto.status){
			// if validation fails, remove the existing failed validation for this field
			context.disableDefaultConstraintViolation()
			//then add a validation -set the field that failed validation to 'state' and use the default message. this is to ensure the field and message for failed validations is backwards compatiblity.
			String message = context.getDefaultConstraintMessageTemplate()
			context.buildConstraintViolationWithTemplate(message).addPropertyNode("state").addConstraintViolation()
			return false
		}
		else{
			return true
		}
	}
	
}
