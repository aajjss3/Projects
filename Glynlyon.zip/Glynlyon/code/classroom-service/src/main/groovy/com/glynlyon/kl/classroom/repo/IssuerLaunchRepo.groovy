package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.IssuerLaunch
import org.springframework.data.repository.CrudRepository

interface IssuerLaunchRepo extends CrudRepository<IssuerLaunch, UUID> {
}
