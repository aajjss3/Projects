package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.Role
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.repository.query.Param

interface PageRepo extends PagingAndSortingRepository<PageObj, UUID>, LocalRepo<PageObj>, JpaSpecificationExecutor<PageObj> {

    Integer countByClassObjUuid(UUID classObjUuid)

    List<PageObj> findAllByClassObjUuidAndSequenceGreaterThanEqual(UUID classObjUuid, Integer sequenceId)
    List<PageObj> deleteAllByClassObjUuid(UUID classObjUuid)

    List<PageObj> findAllByClassObjUuid(UUID classUuid)

	@Query(value = '''select count(*) from {h-schema}page,{h-schema}class,{h-schema}organization where
            page.page_uuid = :pageUUID and page.class_uuid = class.class_uuid and
            class.organization_uuid = organization.organization_uuid and
            (class.organization_uuid = :orgUUID or organization.parent = :orgUUID)
            ''', nativeQuery = true)
	int validatePageAndOrgForAdmin(@Param("pageUUID") UUID pageUUID, @Param("orgUUID") UUID orgUUID);


	@Query(value = '''select count(*) from {h-schema}page,{h-schema}enrollment where
            page.page_uuid = :pageUUID and
            page.class_uuid = enrollment.class_uuid and
            enrollment.user_uuid = :userUUID
            and enrollment.role = :userRole
            ''', nativeQuery = true)
	int validatePageAndOrgForTeacherOrStudent(@Param("pageUUID") UUID pageUUID, @Param("userUUID") UUID userUUID, @Param("userRole") String userRole);


}
