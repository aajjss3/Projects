package com.glynlyon.kl.classroom.constraints

import javax.validation.Constraint
import javax.validation.Payload
import java.lang.annotation.ElementType
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = MatchingEnrollmentRoleValidator)
public @interface MatchingEnrollmentRole {
    String message() default "can only enroll users as their existing system role"
    Class<?>[] groups() default []
    Class<? extends Payload>[] payload() default []
}