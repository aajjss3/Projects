package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.PlannerEntryState
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

@ToString(includeNames = true)
@EqualsAndHashCode
class PageAttemptDTO{

    @JsonProperty(value = "user_uuid")
    UUID userUuid

    @JsonProperty(value = "page_assignment_uuid")
    UUID pageAssignmentUuid

    @JsonProperty(value = "planner_entry_uuid")
    UUID plannerEntryUuid

    @JsonProperty(value = "planner_entry_status")
    PlannerEntryState plannerEntryStatus

    @JsonProperty(value = "attempt_uuid")
    UUID attemptUuid

    @JsonProperty(value = "state")
    AttemptState state

    @JsonProperty(value = "status")
    AttemptState status

    @JsonProperty(value="assessment_score")
    Double assessmentScore

    @JsonProperty(value="earned_score")
    public Map<String,Object> earnedScore

    @JsonProperty(value = "completed_at")
    Date completedAt

    @JsonProperty(value = "attempt_number")
    @JsonInclude(value = JsonInclude.Include.NON_NULL)
    Integer attemptNumber
}
