package com.glynlyon.kl.classroom.dao

import javax.persistence.EntityManager
import javax.persistence.LockModeType
import javax.persistence.NoResultException
import javax.persistence.PersistenceContext
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.stereotype.Repository
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.service.ConfigurationService

@Repository
class SettingDao {
	
	@PersistenceContext
	protected EntityManager entityManager
	
	@Autowired
	JdbcTemplate jdbcTemplate
	
	@Autowired
	ConfigurationService configurationService
	
	
	public Setting getSettingBySourcePessimistically(UUID sourceUUID){
		try{
			return entityManager.createQuery("select s from Setting s where s.sourceUUID = :sourceUUID", Setting.class).setParameter("sourceUUID", sourceUUID).setLockMode( LockModeType.PESSIMISTIC_WRITE ).getSingleResult()
		}
		catch(NoResultException nre){
			return null
		}
	}
	
	/**
	 * Find all class and org uuids for the user uuid passed in. 
	 * return a Map of uuids. the map key is the organization uuid. the map value is a list of associated class uuid's. 
	 * 
	 * @param userUUID
	 * @param excludeExpiredClasses - boolean. if true then do not included soft deleted classes.
	 * @return Map - key is organization uuid, value is a List of class uuid's that belong to that organization
	 */
	public Map<UUID, List<UUID>> findAllSourceUUIDsByUser(UUID userUUID, boolean excludeExpiredClasses){
		String sql = "select distinct CAST (c.class_uuid AS text) as classUUID, CAST (c.organization_uuid AS text) as orgUUID, CAST( o.type AS text) as type, CAST(o.parent AS text) as parent  from class c, enrollment e, organization o where c.class_uuid = e.class_uuid and o.organization_uuid = c.organization_uuid and e.user_uuid = ? "
		if( excludeExpiredClasses ){
			Integer duration = configurationService.getConfigurationByKey(Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY).value as Integer
			sql = sql + " and ( c.state <> 'COMPLETED' or ( (c.completed_at + interval '" + duration + " hour') > now() ) )"
		}
		Map<UUID, List<UUID>> uuids = new HashMap<UUID, List<UUID>>() 

		List<Map> rows = getJdbcTemplate().queryForList(sql, userUUID)
		for (Map row : rows) {
			UUID classUUID = UUID.fromString(row.get("classUUID"))
			String orgUUID = row.get("orgUUID")
			String parent = row.get("parent")
			String type  = row.get("type")
			
			UUID school = ( parent && type == OrganizationType.CAMPUS.toString() ) ? UUID.fromString(parent) : UUID.fromString(orgUUID)
			if ( uuids.containsKey( school ) ){
				List<UUID> classUUIDs = uuids.get(school)
				classUUIDs.add(classUUID)
			}
			else{
				List<UUID> classUUIDs = new ArrayList<UUID>()
				classUUIDs.add(classUUID)
				uuids.put(school, classUUIDs)
			}
		}
		return uuids
	}


}
