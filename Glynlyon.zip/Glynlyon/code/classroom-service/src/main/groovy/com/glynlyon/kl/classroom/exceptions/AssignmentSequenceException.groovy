package com.glynlyon.kl.classroom.exceptions

class AssignmentSequenceException extends RuntimeException {
    AssignmentSequenceException() {
        super()
    }

    AssignmentSequenceException(String message) {
        super(message)
    }

    AssignmentSequenceException(String message, Throwable cause) {
        super(message, cause)
    }

    AssignmentSequenceException(Throwable cause) {
        super(cause)
    }

    protected AssignmentSequenceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
