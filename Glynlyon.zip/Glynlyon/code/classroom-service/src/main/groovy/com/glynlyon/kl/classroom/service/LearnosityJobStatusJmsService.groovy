package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.LearnosityJobStatusJmsDTO
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.learnosity.model.LearnosityCheckJobStatusResponse
import com.glynlyon.learnosity.model.LearnosityJobStatus
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.jms.core.JmsMessagingTemplate
import org.springframework.messaging.Message
import org.springframework.messaging.MessageHeaders
import org.springframework.messaging.support.GenericMessage
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.stereotype.Service

@Service
class LearnosityJobStatusJmsService {
    Logger logger = LogManager.getLogger(this.class)

    @Autowired
    LearnosityDataService learnosityDataService

    @Autowired
    JmsMessagingTemplate jmsMessagingTemplate

    @Value('${jms.learnosity.jobstatus.queueName}')
    String jobStatusQueue

    @Value('${jms.learnosity.jobstatus.retryLimit}')
    Integer retryLimit

    @Value('${jms.learnosity.jobstatus.batchSize}')
    Integer batchSize

    void create(LearnosityJobStatusJmsDTO jmsDTO){
        try {
            Message<LearnosityJobStatusJmsDTO> message = createMessage(jmsDTO)
            jmsMessagingTemplate.send(jobStatusQueue, message)
        } catch (RuntimeException re) {
            throw new ForbiddenException(re.message, Level.ERROR, re)
        }
    }

    @Scheduled(cron = '${jms.learnosity.jobstatus.timer}')
    public void run(){
        List<Message<LearnosityJobStatusJmsDTO>> messages = dequeueBatch()
        processMessages(messages)
    }

    public List<Message<LearnosityJobStatusJmsDTO>> dequeueBatch() {
        List<Message<LearnosityJobStatusJmsDTO>> messages = (1..batchSize).collect {
            return (Message<LearnosityJobStatusJmsDTO>)jmsMessagingTemplate.receive(jobStatusQueue)
        }.findAll{it}
        return messages
    }

    public void processMessages(List<Message<LearnosityJobStatusJmsDTO>> messages){
        messages.each { message ->
            Map<String, LearnosityCheckJobStatusResponse> learnosityResp = learnosityDataService.getClient(message.payload.domain).checkJobs([message.payload.jobId.toString()])
            LearnosityCheckJobStatusResponse jobResp = learnosityResp[message.payload.jobId.toString()]
            Integer currentAttempt = (Integer)message.headers.attempt

            if(currentAttempt <= retryLimit && jobResp.jobStatus == LearnosityJobStatus.completed) {
                logger.info("Success for job " + messageToString(message))
            }
            else if(currentAttempt <= retryLimit && jobResp.jobStatus != LearnosityJobStatus.completed) {
                Message<LearnosityJobStatusJmsDTO> newMessage = createMessage(message)
                logger.info("Requeue job " + messageToString(newMessage) + " response ${jobResp}")
                jmsMessagingTemplate.send(jobStatusQueue, newMessage)
            }
            else {
                logger.error("Retry limit reached for job " + messageToString(message) + " response ${jobResp}")
            }
        }
    }

    private static Message<LearnosityJobStatusJmsDTO> createMessage(Message<LearnosityJobStatusJmsDTO> message){
        return createMessage(message.payload, message.headers.attempt + 1)
    }

    private static Message<LearnosityJobStatusJmsDTO> createMessage(LearnosityJobStatusJmsDTO jmsDTO, attempt = 1){
        return new GenericMessage<>(jmsDTO, new MessageHeaders([attempt: attempt]))
    }

    private static messageToString(Message<LearnosityJobStatusJmsDTO> message){
        return "${message.payload.jobId} [attempt ${message.headers.attempt}]"
    }

}
