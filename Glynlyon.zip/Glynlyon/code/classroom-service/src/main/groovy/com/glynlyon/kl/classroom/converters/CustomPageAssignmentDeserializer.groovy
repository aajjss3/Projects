package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.core.TreeNode
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.repo.PageRepo
import org.springframework.beans.factory.annotation.Autowired

class CustomPageAssignmentDeserializer extends StdDeserializer<PageAssignment>{

    @Autowired
    PageRepo pageRepo

    protected CustomPageAssignmentDeserializer() {
        super(PageAssignment)
    }

    @Override
    PageAssignment deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        TreeNode node = ctxt.parser.readValueAsTree()
        Assignment a =  new Assignment(
                uuid: convert(p, node, "assignment_uuid", UUID),
                title: convert(p, node, "assignment_title", String),
                type: convert(p, node, "assignment_type", AssignmentType)
        )
        UUID pageUuid = convert(p, node, "page_uuid", UUID)
        PageAssignment pa = new PageAssignment(
                uuid: convert(p, node, "page_assignment_uuid", UUID),
                pageObj: pageUuid ? pageRepo.findOne(pageUuid) : null,
                sequence: convert(p, node, "sequence", Integer),
                assignment: a
        )
        return pa
    }

    private static <T> T convert(JsonParser p, TreeNode node, String key, Class<T> clazz){
        if(node.get(key) != null) {
            return p.codec.treeToValue(node.get(key), clazz)
        }
        return null
    }
}
