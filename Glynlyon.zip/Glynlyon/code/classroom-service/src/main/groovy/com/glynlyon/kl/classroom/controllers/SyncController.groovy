package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.model.Sync
import com.glynlyon.kl.classroom.pagination.OffsetBasedPageRequest
import com.glynlyon.kl.classroom.service.SyncService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
class SyncController extends AbstractController {

    @Autowired
    SyncService syncService


	/**
	 * Migrate data from the Odysseyware db into the Classroom-Service database. 
	 * Retrieve data from the 'app_user', 'school', and 'campus_identifier' tables in the odysseyware database and insert into the 'user' and 'organization' tables in the classroom-service database.
	 * @param authorization - String
	 * @return ResponseEntity
	 * @throws InvalidRoleException - if the request does not contain the appropriate role. 
	 */
    @RequestMapping(path = "sync", method = RequestMethod.POST)
    ResponseEntity sync(@RequestHeader(name = "authorization") String authorization,
            @RequestParam(name = "fullSync", required = false) Boolean fullSync) {

		// only allow syncing if the role in the request header is SUPPORT_ADMINISTRATOR
		AppUserType role = jwtService.getRole( authorization.substring( JWT_STARTING_INDEX ) )
		if ( role != AppUserType.SUPPORT_ADMINISTRATOR ){
			return ResponseEntity.badRequest().body(new ErrorOutput(field: "role_in_issuer", message: messages.get( "sync.allowed.role", AppUserType.SUPPORT_ADMINISTRATOR.name())))
		}	
		
        syncService.sync(fullSync)
        return ResponseEntity.ok().build()
		
    }

    @GetMapping(value = "/sync")
    ResponseEntity<?> getSyncStatus(
            @RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") String auth) {

        AppUserType role = jwtService.getRole(auth.substring(JWT_STARTING_INDEX))
        if (!(role in [AppUserType.SUPPORT_ADMINISTRATOR, AppUserType.ADMIN])) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new ErrorOutput(field: "role_in_issuer", message: messages.get("sync.allowed.role", "${AppUserType.SUPPORT_ADMINISTRATOR.name()} or ${AppUserType.ADMIN.name()}")))
        }

        if(!sort && !orderBy){
            orderBy = "desc"
        }
        OffsetBasedPageRequest pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_SYNC_SORT, Sync)
        Page<Sync> page = syncService.getStatusList(filter, pageable)
        HttpHeaders responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        return PagedResponse.createResponse("syncs", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }
}
