package com.glynlyon.kl.classroom.constraints

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class DateOrderValidator implements ConstraintValidator<DateOrder, Object> {
    String first
    String second

    @Override
    void initialize(DateOrder constraintAnnotation) {
        first = constraintAnnotation.firstDate()
        second = constraintAnnotation.secondDate()
    }

    @Override
    boolean isValid(Object value, ConstraintValidatorContext context) {
        Date firstDate = value."$first"?.clone()
        Date secondDate = value."$second"?.clone()

        Boolean valid = ((!firstDate || !secondDate) || secondDate.clearTime().after(firstDate.clearTime()))
        if(!valid){
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate()).addPropertyNode(second).addConstraintViolation()
        }
        return valid
    }
}
