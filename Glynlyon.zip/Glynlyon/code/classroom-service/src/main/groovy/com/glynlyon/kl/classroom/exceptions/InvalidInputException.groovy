package com.glynlyon.kl.classroom.exceptions

import com.glynlyon.kl.classroom.model.ErrorOutput

class InvalidInputException extends RuntimeException {
    List<ErrorOutput> errors
    InvalidInputException() {
        super()
    }

    InvalidInputException(String message) {
        super(message)
    }

    InvalidInputException(String message, Throwable cause) {
        super(message, cause)
    }

    InvalidInputException(Throwable cause) {
        super(cause)
    }

    protected InvalidInputException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}
