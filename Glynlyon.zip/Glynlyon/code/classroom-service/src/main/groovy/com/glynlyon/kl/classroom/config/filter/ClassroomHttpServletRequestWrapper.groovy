package com.glynlyon.kl.classroom.config.filter

import javax.servlet.ReadListener
import javax.servlet.ServletInputStream
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletRequestWrapper
import java.util.stream.Collectors
import java.util.regex.Pattern
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.apache.logging.log4j.Level

/**
 * This class is necessary since the http request body needs to be modified to include the updated_by field and an input stream cannot be read twice
 * Therefore, the http request body is read and stored, then modified to include the updated_by field, and then a new input stream is returned with the modified content.
 * It works in conjunction with the UpdatedByFilter class
 * 
 *
 */
public class ClassroomHttpServletRequestWrapper extends HttpServletRequestWrapper {
    // contains the body of the http request. for HTTP PUT and HTTP POST this will be the json data passed in.
    private String contents = null
    // original HttpServletRequest object passed in the request.
    HttpServletRequest request

	private static final Pattern PATTERN = Pattern.compile("{", Pattern.LITERAL)
	Logger logger = LogManager.getLogger(this.getClass())


    public ClassroomHttpServletRequestWrapper(HttpServletRequest request, String userUUID) {
        super(request)
        this.request = request

        BufferedReader reader = null
        try {
            reader = new BufferedReader(new InputStreamReader(request.getInputStream()))
			contents = reader.lines().collect(Collectors.joining("\n"))
			//add updated_by to request body
			if( contents && contents.trim() && contents.trim().startsWith("{") ){
				String comma 
				if( contents.trim().substring(1, contents.length()-1).trim() ){
					comma = ", "
				}
				else{
					comma = " "
				}
				contents = PATTERN.matcher(contents).replaceFirst("{ \"updated_by\": \"" + userUUID  + "\" " + comma )
			}
        } 
		catch(Exception exc){
			logger.log( Level.WARN, exc.getLocalizedMessage(), exc.getCause() )	
		}
		finally {
            if( reader != null ){
	            try { reader.close() } catch (Exception e) {}
			}
        }


    }


    @Override
    public ServletInputStream getInputStream() throws IOException {

        if (contents == null) {
            return request.getInputStream()
        } else {

            // create a new ServletInputStream object and return it. 
            final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(contents.getBytes())
            ServletInputStream servletInputStream = new ServletInputStream() {
				
				public int read() throws IOException {
					return byteArrayInputStream.read()
				}

				// No need to override these method since NOT using non-blocking I/O for asynchronous requests.
                @Override
                public boolean isFinished() {
                    return true
                }
                @Override
                public boolean isReady() {
                    return true
                }
                @Override
                public void setReadListener(ReadListener readListener) {
                }

            }

            return servletInputStream

        }

    }


    @Override
    public BufferedReader getReader() throws IOException {
        if (contents == null) {
            return request.getReader()
        } else {
            return new BufferedReader(new StringReader(contents))
        }
    }

}
