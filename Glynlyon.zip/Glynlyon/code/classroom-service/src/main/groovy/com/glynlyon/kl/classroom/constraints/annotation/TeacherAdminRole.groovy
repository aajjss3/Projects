package com.glynlyon.kl.classroom.constraints.annotation

import com.glynlyon.kl.classroom.constraints.validator.TeacherAdminRoleValidator

import javax.validation.Constraint
import java.lang.annotation.*
import javax.validation.Payload

@Target([ElementType.FIELD, ElementType.TYPE, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TeacherAdminRoleValidator.class)
@Documented
@Inherited
public @interface TeacherAdminRole {
	String message() default "not a teacher or admin"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
