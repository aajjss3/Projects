package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.dto.PlannerEntryPatchDTO
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.InvalidInputException
import com.glynlyon.kl.classroom.exceptions.InvalidRoleException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryParams
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.service.PlannerEntryService
import com.glynlyon.kl.classroom.service.PlannerEntryValidationService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException
import com.glynlyon.kl.classroom.model.PlannerEntryState


@RestController
class PlannerEntryController extends AbstractController  {

    @Autowired
    PageableService pageableService

    @Autowired
    PlannerEntryService plannerEntryService

    @Autowired
    PlannerEntryValidationService plannerEntryValidationService

    @Autowired
    InputMapperService inputMapperService

    @GetMapping(value="/plannerentries", produces = Constants.PLANNER_ENTRIES_VERSION_1)
    ResponseEntity<?> getPlannerEntries(@RequestParam(name = "limit", required = false) Integer limit,
                               @RequestParam(name = "offset", required = false) Integer offset,
                               @RequestParam(name = "orderBy", required = false) String orderBy,
                               @RequestParam(name = "sort", required = false) String sort,
                               @RequestParam(name = "filter", required = false) String filter,
                               @RequestHeader(name = "authorization") String auth) {
        Page page
        HttpHeaders responseHeaders = null
        String token = auth.substring(JWT_STARTING_INDEX)
        AppUserType role = jwtService.getRole(token)

        if ( role != AppUserType.STUDENT ){
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "role_in_issuer", message: messages.get( "plannerEntry.allowed.role", AppUserType.STUDENT.name())))
        }

        try {
            Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_PLANNER_ENTRY_SORT, PlannerEntry)
            page = plannerEntryService.findAllPlannerEntries(token, filter, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch (UnsupportedFieldException e) {
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        catch (OrgNotFoundException onfe) {
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "school_uuid", message: onfe.message))
        }
        return PagedResponse.createResponse("planner_entries", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }

    @DeleteMapping(path = "/plannerentries/{uuid}")
    ResponseEntity<?> deleteEntry(@PathVariable("uuid") UUID uuid, @RequestHeader(name = "authorization") String auth) {

        String token = auth.substring(JWT_STARTING_INDEX)

        ValidationResult<PlannerEntry> validationResult = plannerEntryValidationService.validatePlannerEntry(token, uuid)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }
        plannerEntryService.delete(validationResult.obj)
        //sat-1846
        if (!plannerEntryValidationService.validateClassNotEnded(validationResult.obj) ||
                !plannerEntryValidationService.validateStudentEnrolledInClass(validationResult.obj)) {
            return ResponseEntity.status(HttpStatus.RESET_CONTENT).build()
        }else{
            return ResponseEntity.noContent().build()
        }
    }

    @DeleteMapping(path = "/plannerentries", consumes = Constants.PLANNER_ENTRY_PARAMS_VERSION_1)
    ResponseEntity<?> deleteEntries(@RequestBody ObjectNode jsonInput,
            @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)

        def mappingResult = inputMapperService.processInput(jsonInput, PlannerEntryParams)
        PlannerEntryParams input = mappingResult.obj

        if(!input){
            return ResponseEntity.badRequest().body([errors: [[field: "body", message: "Could not process input ${jsonInput}"]]])
        }

        try {
            plannerEntryService.deleteByParams(token, input)
            return ResponseEntity.noContent().build()
        }
        catch (InvalidRoleException e){
            return ResponseEntity.badRequest().body([errors: [new ErrorOutput(field: "role_in_issuer", message: messages.get("privileged.allowed.role", "Planner entry"))]])
        }
        catch (InvalidInputException e){
            return ResponseEntity.badRequest().body([errors: e.errors])
        }
    }

    @PatchMapping(path = "/plannerentries/{uuid}", consumes = Constants.PLANNER_ENTRIES_VERSION_1, produces = Constants.PLANNER_ENTRIES_VERSION_1)
    ResponseEntity<?> updateEntry(@RequestBody ObjectNode jsonInput,
            @PathVariable("uuid") UUID uuid, @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PlannerEntry> validationResult = plannerEntryValidationService.validatePlannerEntry(token, uuid)
        boolean resetContentFlag = false

        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }

        def mappingResult = inputMapperService.processInput(jsonInput, PlannerEntryPatchDTO)
        PlannerEntryPatchDTO input = mappingResult.obj

        if (!input) {
            return ResponseEntity.badRequest().body([errors: [[field: "body", message: "Could not process input ${jsonInput}"]]])
        }
		
		//A Student is not able to set the PlannerEntryStatus to OBE
		if( (input.status == PlannerEntryState.OBE) && ((super.token(auth)).role == AppUserType.STUDENT) ){
			throw new ForbiddenException(message.getMessage("student.plannerentry.status.invalid", null, locale))
		}

        //sat-1846
        if (!plannerEntryValidationService.validateClassNotEnded(validationResult.obj)) {
            //slot -1 indicates the kid is trying to remove the planner entry card from the canvas
            //we want to permit the update - but return RESET_CONTENT HTTPStatus.
            //lets just mark this case with a flag so we can return that HTTPStatus.RESET_CONTENT down below
            //otherwise, throw error.
            if (input.slot == -1){
                resetContentFlag = true
            }else{
                return ResponseEntity.badRequest().body([errors: [[field: "class_uuid", message: messages.get("plannerEntry.update.class.completed.invalid")]]])
            }
        }
        //sat-1846
        if (!plannerEntryValidationService.validateStudentEnrolledInClass(validationResult.obj)) {
            if (input.slot == -1){
                resetContentFlag = true
            }else{
                return ResponseEntity.badRequest().body([errors: [[field: "class_uuid", message: messages.get("plannerEntry.update.enrolled.invalid")]]])
            }
        }

        try {
            PlannerEntry updated = plannerEntryService.update(token, validationResult.obj, input, mappingResult.errors)
            if (resetContentFlag) {
                return ResponseEntity.status(HttpStatus.RESET_CONTENT).body(updated)
            }else{
                return ResponseEntity.ok(updated)
            }
        }
        catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            if (t instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @PatchMapping(path = "/plannerentries", consumes = Constants.PLANNER_ENTRY_PARAMS_VERSION_1)
    ResponseEntity<?> updateEntries(@RequestBody ObjectNode jsonInput,
            @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        def mappingResult = inputMapperService.processInput(jsonInput, PlannerEntryParams)
        PlannerEntryParams input = mappingResult.obj
        if (!input) {
            return ResponseEntity.badRequest().body([errors: [[field: "body", message: "Could not process input ${jsonInput}"]]])
        }
		UUID updatedBy = UUID.fromString(jsonInput.get("updated_by").asText())
        try {
            plannerEntryService.updateByParams(token, input, mappingResult, updatedBy)
            return ResponseEntity.noContent().build()
        }
        catch (InvalidRoleException e) {
            return ResponseEntity.badRequest().body([errors: [new ErrorOutput(field: "role_in_issuer", message: messages.get("privileged.allowed.role", "Planner entry"))]])
        }
        catch (InvalidInputException e) {
            return ResponseEntity.badRequest().body([errors: e.errors])
        }
        catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            if (t instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }


    @PostMapping(path = "/plannerentries", produces = Constants.PLANNER_ENTRIES_VERSION_1, consumes = Constants.PLANNER_ENTRIES_VERSION_1)
    ResponseEntity<?> createPlannerEntry(@RequestBody ObjectNode json, HttpServletRequest req,
                                         @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(7)

        def mappingResult = inputMapperService.processInput(json, PlannerEntry)
        PlannerEntry input = mappingResult.obj
        if (input == null) {
            return ResponseEntity.badRequest().body("Couldn't process input")
        }
		//A Student is not able to set the PlannerEntryStatus to OBE
		if( (input.status == PlannerEntryState.OBE) && ((super.token(auth)).role == AppUserType.STUDENT) ){
			throw new ForbiddenException(message.getMessage("student.plannerentry.status.invalid", null, locale))
		}
        input.created = new Date()
        input.updated = new Date()
        input.uuid = null
        try {
            PlannerEntry plannerEntry = plannerEntryService.create(input, mappingResult, token)
            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/plannerentries/" + plannerEntry.uuid)).body(plannerEntry)
        } catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            if(t instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PlannerEntry)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }

    }
}
