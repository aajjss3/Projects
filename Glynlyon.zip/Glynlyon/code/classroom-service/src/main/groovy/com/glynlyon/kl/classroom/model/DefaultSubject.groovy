package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@Entity
@ToString
@EqualsAndHashCode
class DefaultSubject extends BaseEntity implements Serializable, GroovyObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "subject_uuid", nullable = false)
    @JsonProperty(value = "subject_uuid", access = JsonProperty.Access.READ_ONLY)
    UUID uuid

    @Column(name = "name", nullable = false)
    String name

    @Column(name = "created_at", nullable = true)
    @JsonIgnore
    Date createdAt

    @Column(name = "updated_at", nullable = true)
    @JsonIgnore
    Date updatedAt

    DefaultSubject() {}

}
