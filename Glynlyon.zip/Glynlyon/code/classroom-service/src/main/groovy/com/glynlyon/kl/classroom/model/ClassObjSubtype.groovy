package com.glynlyon.kl.classroom.model

public enum ClassObjSubtype {
    STANDARD,
    MIXED,
    INDEPENDENT_STUDY,
    ASSESSMENT_BASED,
    CREDIT_RECOVERY
}