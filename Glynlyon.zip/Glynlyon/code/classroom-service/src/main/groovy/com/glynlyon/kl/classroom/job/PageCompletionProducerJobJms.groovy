package com.glynlyon.kl.classroom.job

import com.glynlyon.kl.classroom.dao.JobLockDao
import com.glynlyon.kl.classroom.model.JobLock
import com.glynlyon.kl.classroom.repo.JobLockRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.jms.core.JmsMessagingTemplate
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.stereotype.Component
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionStatus
import org.springframework.beans.factory.annotation.Value
import org.springframework.messaging.support.GenericMessage
import org.springframework.transaction.support.TransactionCallback
import org.springframework.transaction.support.TransactionCallbackWithoutResult
import org.springframework.transaction.support.TransactionTemplate

import java.time.temporal.ChronoUnit
import java.time.Instant
import java.net.InetAddress

@Component
public class PageCompletionProducerJobJms extends AbstractJob{

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Autowired
	PageRepo pageRepo

	@Autowired
	JobLockDao jobLockDao

	@Autowired
	JobLockRepo jobLockRepo

	@Autowired
	JmsMessagingTemplate jmsMessagingTemplate

	@Value('${jms.page.completion.queueName}')
	String jobStatusQueue

	@Value('${jms.page.completion.producer.batch.size}')
	int batchSize


	/**
	 * schedule a reocurring task. 
	 * when the task starts up, acquire a lock.
	 * if its able to acquire a lock then create and send a JMS message.
	 * If it cannot acquire a lock then do nothing. 
	 */
	@Scheduled(cron = '${jms.page.completion.producer.timer}')
	public void run(){
		String id = UUID.randomUUID().toString() // unique id representing the particular task
		if( acquireJobLock(id) ){
			createAndSendMessage(id)
		}
	}


	/**
	 * Acquire a lock pessimistically. 
	 * If an error occurs then release the lock, there is no need to rollback any database changes.
	 *
	 * @return boolean indicating if the lock is acquirable
	 */
	public boolean acquireJobLock(String id){
		TransactionTemplate template = new TransactionTemplate(transactionManager);

		template.execute(new TransactionCallback() {
			@Override
			Boolean doInTransaction(TransactionStatus status) {
				try {
					JobLock jobLock = jobLockDao.getJobLockPessimistically()
					if (!jobLock.getAcquired() || (jobLock.getAcquired() && (Date.from(Instant.now().plus(1L, ChronoUnit.HOURS)) > jobLock.getLockedAt()))) {
						jobLock.setAcquired(Boolean.TRUE)
						jobLock.setLockedAt(new Date())
						jobLock.setLockedBy(InetAddress.getLocalHost().getHostAddress())
						return true
					} else {
						return false
					}
				}
				catch (Exception ex) {
					logger.error("COMPLETE PAGE JOB: " + id + " - error. Unable to acquire a lock. NODE: " + InetAddress.getLocalHost().getHostAddress(), ex)
					status.setRollbackOnly() // Roll back the transaction
					return false
				}
			}
		})
	}


	/**
	 * create a message (which is a list of page uuids that should be marked as completed) and place this message into a JMS queue.
	 * if the number of page uuids is greater than the configurable batch size, then place the page uuids into multiple messages and place each message in the JMS queue.
	 * Whether an error occurs or not, release the lock when the method exits.
	 */
	public void createAndSendMessage(String id) {
		TransactionTemplate template = new TransactionTemplate(transactionManager);
		template.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				try {
					logger.info("COMPLETE PAGE JOB: " + id + " - started. NODE: " + InetAddress.getLocalHost().getHostAddress())
					List<String> pageUUIDs = jobLockRepo.getPagesToComplete()
					logger.info("COMPLETE PAGE JOB: " + id + " - page uuids. PAGE UUIDS: " + pageUUIDs.toString())
					if (!pageUUIDs.isEmpty()) {
						int totalUUIDs = pageUUIDs.size()
						int numberBatches = Math.floorDiv(totalUUIDs, batchSize)
						int remainderUUIDs = totalUUIDs - (numberBatches * batchSize)
						if (numberBatches >= 1) {
							for (int inx = 1; inx <= numberBatches; inx++) {
								List<String> partialPageUUIDs = pageUUIDs.subList(batchSize * (inx - 1), batchSize * inx).collect {
									UUID.fromString(it)
								}
								jmsMessagingTemplate.send(jobStatusQueue, new GenericMessage(partialPageUUIDs))
							}
						}
						if (remainderUUIDs >= 1) {
							List<UUID> partialPageUUIDs = pageUUIDs.subList(totalUUIDs - remainderUUIDs, totalUUIDs).collect {
								UUID.fromString(it)
							}
							jmsMessagingTemplate.send(jobStatusQueue, new GenericMessage(partialPageUUIDs))
						}
					}
					logger.info("COMPLETE PAGE JOB: " + id + " - finished.")
				}
				catch (Exception ex) {
					logger.error("COMPLETE PAGE JOB: " + id + " - error. Unable to create and send message.", ex)
				}
				// no matter the circumstance, release the lock when this method exits
				finally{
					JobLock jobLock = jobLockDao.getJobLockPessimistically()
					jobLock.setAcquired(Boolean.FALSE)
				}
			}
		})
	}
}
