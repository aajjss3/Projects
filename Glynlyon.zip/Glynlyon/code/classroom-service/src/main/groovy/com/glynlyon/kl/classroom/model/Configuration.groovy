package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table
import org.hibernate.annotations.DynamicInsert


@Entity
@ToString
@EqualsAndHashCode
@DynamicInsert
class Configuration extends BaseEntity implements Serializable, GroovyObject{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public UUID uuid
	
	@Column(nullable = false, length = 25, unique=true)
	public String key
	
	@Column(nullable = false, length = 255)
	public String value
	
	@Column( nullable = true, length = 255)
	public String description
	
	@JsonIgnore
	@Column(name = "created_at")
	Date createdAt

	@JsonIgnore
	@Column(name = "updated_at")
	Date updatedAt

}
