package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.pagination.OffsetBasedPageRequest
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Sort
import org.springframework.stereotype.Service

@Service
class PageableService {

    @Autowired
    JsonMappingService jsonMappingService

    public OffsetBasedPageRequest createPageable(Integer limit, Integer offset, String orderBy, String sort, String defaultSort, Class clazz, List<String> unsupportedFields = [], Map<String, String> customMappings = [:]) {
        List<Sort.Direction> directions
        directions = [Sort.Direction.ASC]
        if (orderBy) {
            Sort.Direction direction
            directions = orderBy.split(",").collect { order ->
                if ('desc'.equalsIgnoreCase(order)) {
                    direction = Sort.Direction.DESC
                } else {
                    direction = Sort.Direction.ASC
                }
            }
        }

        sort = sort ?: defaultSort

        List<Sort.Order> sortCollection = []
        sort.split(",").eachWithIndex { String field, Integer index ->
            if(unsupportedFields.any { f -> field == f || field.startsWith("${f}.") }){
                throw new UnsupportedFieldException(field)
            }

            if(customMappings.containsKey(field)){
                field = customMappings.get(field)
            }

            sortCollection << new Sort.Order(directions[index], jsonMappingService.getEntityFieldName(field, clazz))
        }
        Sort sortObj = new Sort(sortCollection)
        return new OffsetBasedPageRequest(offset ?: Constants.PAGE_OFFSET_DEFAULT, limit == null ? Constants.PAGE_LIMIT_DEFAULT : limit, sortObj)
    }
}

