package com.glynlyon.kl.classroom.dao.filter

import com.glynlyon.kl.classroom.exceptions.InvalidFilterException
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.util.DateFormat

import java.lang.reflect.Field
import java.text.ParseException

public class PageAttemptSearchBuilder {

    private List<DBQueryExpression> params;

    private static final String UUID_FORMAT = "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"

    public PageAttemptSearchBuilder() {
        params = new ArrayList<DBQueryExpression>();
    }

    public append(String jsonName,String fieldName, final String operation, String value, String conjunctiveOperator) {
        Field attemptField = null
        if (!operation) {
            throw new InvalidFilterException("Filter is not in expected format for: " + fieldName ?: ' ' + operation ?: ' ' + value ?: ' ')
        }
        if (fieldName) {
            attemptField = Attempt.getDeclaredField(fieldName)
        }

        if (!attemptField) {
            throw new InvalidFilterException("Invalid field '${jsonName}' in the filter")
        }


        OneRosterPredicate predicate = OneRosterPredicate.find(operation)


        if (predicate != null) {
            if(predicate.equals(OneRosterPredicate.CONTAINS)){
                if(attemptField.type != String) {
                    throw new InvalidFilterException("Predicate '${predicate.oneRosterRepresentation}' is not supported for '${jsonName}'")
                } else {
                    params.add(new DBQueryExpression(attemptField,predicate,value,conjunctiveOperator))
                }
            } else if(attemptField.type == Date) {
                if(isValidDateFormat(value)){
                    params.add(new DBQueryExpression(attemptField,predicate,value,conjunctiveOperator))
                } else {
                    throw new InvalidFilterException("${value} is an invalid Date format for ${jsonName}. Please use ISO 8601 format (ex: 2016-08-13T09:31:00-07:00).")
                }
            } else if(attemptField.type == UUID) {
                if (value.matches(UUID_FORMAT)) {
                    params.add(new DBQueryExpression(attemptField, predicate, value, conjunctiveOperator))
                } else {
                    throw new InvalidFilterException("${value} is an invalid UUID format for field '${jsonName}'")
                }
            }else if (attemptField.type == Boolean){
                if("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
                    params.add(new DBQueryExpression(attemptField, predicate, value, conjunctiveOperator))
                } else {
                    throw new InvalidFilterException("${value} is an invalid boolean value for field '${jsonName}'")
                }
            } else {
                params.add(new DBQueryExpression(attemptField,predicate,value,conjunctiveOperator))
            }
        }
        else {
            throw new InvalidFilterException("Invalid operator '${operation}' in the filter")
        }
    }

    //as per OneRoster-v1
    public boolean isValidDateFormat(String input){
        try {
            def dateFormat = new DateFormat()
            dateFormat.parse(input)
        }
        catch (ParseException e) {
            return false
        }
        return true
    }



    public String generateDBQuery() {
        StringBuilder whereClause = new StringBuilder()
        if (params.size() == 0) {
            return whereClause;
        }

        for (DBQueryExpression dbExp : params) {
            whereClause << dbExp.render()
        }

        return whereClause

    }
}
