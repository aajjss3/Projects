package com.glynlyon.kl.classroom.constraints.validator

import com.glynlyon.kl.classroom.dto.GradeDisplay

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class CustomGradeDisplayValidator implements ConstraintValidator<CustomGradeDisplay, GradeDisplay> {


    @Override
    public void initialize(CustomGradeDisplay constraintAnnotation) {}

    @Override
    public boolean isValid(GradeDisplay gradeDisplay, ConstraintValidatorContext context) {
        boolean isValid = true

        if( gradeDisplay) {
            if(!gradeDisplay.getLetter() && !gradeDisplay.getPercentage()) {
                isValid = false
                context.buildConstraintViolationWithTemplate("{input.gradedisplay.selection.required}").addConstraintViolation()
            }
            else if (gradeDisplay.getPercentage() == null) {
                isValid = false
                context.buildConstraintViolationWithTemplate("{input.field.required}").addPropertyNode("percentage").addConstraintViolation()
            }
            else if (gradeDisplay.getLetter() == null) {
                isValid = false
                context.buildConstraintViolationWithTemplate("{input.field.required}").addPropertyNode("letter").addConstraintViolation()
            }

        }

        if(!isValid) {
            context.disableDefaultConstraintViolation()
        }
        return isValid

    }
}
