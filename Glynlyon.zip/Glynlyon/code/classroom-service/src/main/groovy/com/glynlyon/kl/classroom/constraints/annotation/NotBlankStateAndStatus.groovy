package com.glynlyon.kl.classroom.constraints.annotation

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target
import javax.validation.Constraint
import com.glynlyon.kl.classroom.constraints.validator.SupportAdminRoleValidator
import com.glynlyon.kl.classroom.constraints.validator.NotBlankStateAndStatusValidator
import javax.validation.Payload

@Target([ElementType.TYPE, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NotBlankStateAndStatusValidator.class)
@Documented
@Inherited
public @interface NotBlankStateAndStatus {
	String message() default "not a valid state or status"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
