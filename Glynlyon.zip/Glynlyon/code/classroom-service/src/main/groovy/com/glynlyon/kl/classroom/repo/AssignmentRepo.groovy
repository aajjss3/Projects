package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Assignment
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface AssignmentRepo extends PagingAndSortingRepository<Assignment, UUID>, LocalRepo<Assignment>, JpaSpecificationExecutor<Assignment>, JpaRepository<Assignment, UUID> {
}
