package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

class CustomSubjectSerializer extends JsonSerializer<SubjectsView> {

    @Override
    void serialize(SubjectsView value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String serverRoot = req.getScheme() + "://" + req.getHeader("Host")

        gen.writeStartObject()
        gen.writeStringField("subject_uuid", value.uuid.toString())
        gen.writeStringField("name", value.name)
        gen.writeObjectField("_links", ["self": ["href": serverRoot + "/subjects/" + value.uuid]])
        gen.writeEndObject()
    }
}
