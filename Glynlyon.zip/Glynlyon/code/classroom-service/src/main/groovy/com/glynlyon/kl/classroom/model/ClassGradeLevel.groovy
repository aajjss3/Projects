package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.*
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import java.util.UUID
import javax.persistence.*

@Entity
@ToString
@EqualsAndHashCode
@IdClass(ClassGradeLevelId.class)
class ClassGradeLevel extends BaseEntity implements Serializable, GroovyObject {
	
    @Id
    @Column(name = "class_uuid", nullable = false)
    @JsonProperty(value = "class_uuid")
    UUID classUuid

    @Id
    @Column(name = "grade_level", nullable = false)
    @Enumerated(EnumType.STRING)
    Grade grade

    @Column(name = "created_at", nullable = true)
    @JsonIgnore
    Date createdAt

    @Column(name = "updated_at", nullable = true)
    @JsonIgnore
    Date updatedAt
	
    ClassGradeLevel() {}


}
