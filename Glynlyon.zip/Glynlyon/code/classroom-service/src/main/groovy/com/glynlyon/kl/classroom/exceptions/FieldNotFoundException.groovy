package com.glynlyon.kl.classroom.exceptions

class FieldNotFoundException extends RuntimeException {
    private String field
    private String message

    FieldNotFoundException() {
        super()
    }

    FieldNotFoundException(String message) {
        super(message)
    }

    FieldNotFoundException(String message, Throwable cause) {
        super(message, cause)
    }

    FieldNotFoundException(Throwable cause) {
        super(cause)
    }

    protected FieldNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }

    public String getField(){
        return field
    }

    public FieldNotFoundException(String field, String message) {
        super(message)
        this.field = field
        this.message = message
    }
}
