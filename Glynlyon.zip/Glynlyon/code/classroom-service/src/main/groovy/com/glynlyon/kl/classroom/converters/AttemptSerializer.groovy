package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.dto.AttemptDTO
import com.glynlyon.kl.classroom.dto.mapper.AttemptMapper
import com.glynlyon.kl.classroom.model.Attempt
import org.springframework.beans.factory.annotation.Autowired

class AttemptSerializer extends JsonSerializer<List<Attempt>> {

    @Autowired
    AttemptMapper mapper

    @Override
    void serialize(List<Attempt> value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        gen.writeStartArray()
        value.sort{a, b ->
            a.createdAt <=> b.createdAt
        }.each {
            def a = mapper.map(it, AttemptDTO, true)
            gen.writeObject(a)
        }
        gen.writeEndArray()
    }
}
