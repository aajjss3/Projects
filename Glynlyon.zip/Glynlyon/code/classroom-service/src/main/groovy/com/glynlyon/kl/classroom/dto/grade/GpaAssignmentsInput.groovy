package com.glynlyon.kl.classroom.dto.grade

import com.fasterxml.jackson.annotation.JsonProperty
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

@ToString(includeNames = true)
@EqualsAndHashCode
public class GpaAssignmentsInput {
    List<Assignment> assignments

    @ToString(includeNames = true)
    @EqualsAndHashCode
    static class Assignment {
        String id
        List<Score> students
    }

    @ToString(includeNames = true)
    @EqualsAndHashCode
    static class Score {
        Double score

        @JsonProperty(value = "max_score")
        Double maxScore
    }
}