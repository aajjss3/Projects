package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.exceptions.AssignmentSequenceException
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.repo.AssignmentRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root

@Service
class PageAssignmentService {

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    PageRepo pageRepo

    @Autowired
    JwtService jwtService

    @Autowired
    FilterService filterService

    @Autowired
    AssignmentRepo assignmentRepo

    @Autowired
    MessagesUtil messagesUtil

    static Logger logger = LogManager.getLogger(PageAssignmentService)

    public Page findAllPageAssignments(UUID pageUuid, String filter, Pageable pageable) {
        if (filter) {
            return filterService.find(filter, PageAssignment, pageAssignmentRepo, pageable, [:], {
                return new Specification<PageAssignment>(){
                    @Override
                    Predicate toPredicate(Root<PageAssignment> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                        return cb.equal(root.get("pageObj").get("uuid"), pageUuid)
                    }
                }
            }, null)
        } else {
            return pageAssignmentRepo.findAllByPageObjUuid(pageUuid, pageable)
        }
    }

    @Transactional
    public void updateAll(List<PageAssignment> pageAssignments, UUID pageUuid) {
        List<PageAssignment> existingAssignments = pageAssignmentRepo.findAllByPageObjUuid(pageUuid)
        def sequenceDuplicates = pageAssignments.sequence.findAll { pageAssignments.sequence.count(it) > 1 }.unique()

        if (sequenceDuplicates) {
            throw new AssignmentSequenceException(messagesUtil.get("pageAssignment.error.duplicateSequences"))
        }
        if (pageAssignments.size() == existingAssignments.size()
                && pageAssignments.uuid.containsAll(existingAssignments.uuid)) {
            pageAssignments.each { assignment ->
                def existingAssignment = existingAssignments.find { it.uuid == assignment.uuid }
                if (existingAssignment.sequence != assignment.sequence) {
                    if (assignment.sequence <= 0) {
                        throw new AssignmentSequenceException(messagesUtil.get("pageAssignment.error.sequence"))
                    }
                    def existingSequenceHolder = pageAssignmentRepo.findOneByPageObjUuidAndSequence(pageUuid, assignment.sequence)
                    if (existingSequenceHolder) {
                        existingSequenceHolder.sequence = 0
                        existingSequenceHolder = pageAssignmentRepo.saveAndFlush(existingSequenceHolder)

                        Integer existingSequence = existingAssignment.sequence
                        existingAssignment.sequence = assignment.sequence
                        pageAssignmentRepo.saveAndFlush(existingAssignment)

                        existingSequenceHolder.sequence = existingSequence
                        pageAssignmentRepo.saveAndFlush(existingSequenceHolder)
                    }
                    else {
                        existingAssignment.sequence = assignment.sequence
                        pageAssignmentRepo.saveAndFlush(existingAssignment)
                    }
                }
            }
        }
        else {
            throw new AssignmentSequenceException(messagesUtil.get("pageAssignment.error.nonMatchingAssignments"))
        }
    }

    @Transactional
    public void createAll(List<PageAssignment> pageAssignments) {
        pageAssignments = pageAssignments.collect {
            Assignment existingAssignment = assignmentRepo.findOne(it.assignment.uuid)
            if(existingAssignment) {
                existingAssignment.updated = new Date()
				existingAssignment.title = it.assignment.title
				existingAssignment.type = it.assignment.type
            }
			else{
	            it.assignment.updated = new Date()
	            it.assignment = assignmentRepo.save(it.assignment)
			}
            it
        }
		
        pageAssignmentRepo.save((List<PageAssignment>)pageAssignments)
    }

    ValidationResult<PageAssignment> validatePageAssignment(UUID pageUuid, UUID pageAssignmentUuid) {
        PageAssignment pageAssignment = pageAssignmentRepo.findByPageObjUuidAndUuid(pageUuid, pageAssignmentUuid)
        if(!pageAssignment){
            return new ValidationResult<PageAssignment>(valid: false, message: "Could not find page assignment ${pageAssignmentUuid} in page ${pageUuid}", httpStatus: HttpStatus.NOT_FOUND)
        }
        return new ValidationResult<PageAssignment>(valid: true, obj: pageAssignment)
    }

    void delete(PageAssignment pageAssignment) {
        pageAssignmentRepo.delete(pageAssignment.uuid)
    }

    public PageAssignment findOne(UUID uuid) {
        return pageAssignmentRepo.findOneByUuid(uuid)
    }
}
