package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonProperty

class PlannerEntryFilter {

    PlannerEntryState status
    @JsonProperty("page_uuid")
    UUID pageObjUuid

    @JsonProperty("assignment_uuid")
    UUID assignmentUuid

    @JsonProperty("class_uuid")
    UUID classUuid
}
