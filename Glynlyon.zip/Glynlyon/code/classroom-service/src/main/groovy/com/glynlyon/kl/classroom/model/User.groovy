package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.CustomOrganizationsCollectionSerializer
import java.util.UUID
import javax.persistence.*

@Entity
@Table(name="user")
class User extends BaseEntity implements GroovyObject, Serializable {
	
    @Id
    @Column(name = "app_user_uuid", nullable = false)
    @JsonProperty(value = "user_uuid", access = JsonProperty.Access.READ_ONLY) //access is needed for JsonIdentityInfo on PE object.
    UUID uuid = UUID.randomUUID()

    @Column(name = 'app_user_status', nullable = false)
    @Enumerated(EnumType.STRING)
    @JsonProperty(value = "status")
    AppUserStatus status

    @Column(name = "updated_at", nullable = false)
    @JsonIgnore
    Date updated

    @Column(name = "username", nullable = true)
    @JsonProperty(value = "username")
    String userName

    @Column(name = "sso_id", nullable = true)
    @JsonProperty(value = "sso_id")
    String ssoId

    @Column(name = "first_name", nullable = true)
    @JsonProperty(value = "first_name")
    String firstName

    @Column(name = "last_name", nullable = true)
    @JsonProperty(value = "last_name")
    String lastName

    @Column(name = 'app_user_type', nullable = false)
    @Enumerated(EnumType.STRING)
    @JsonProperty(value = "role")
    AppUserType type

    @ManyToMany
    @JoinTable(
            name = "user_organization",
            joinColumns = @JoinColumn(name = "user_uuid"),
            inverseJoinColumns = @JoinColumn(name = "organization_uuid")
    )
    @JsonProperty(value = "orgs")
    @JsonSerialize(using = CustomOrganizationsCollectionSerializer)
    List<Organization> organizations

    @Column(name = 'super_teacher', nullable = false)
    @JsonIgnore
    Boolean superTeacher

    @Column(name = 'origination_id', nullable = false)
    @JsonIgnore
    String originationId

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date created

    @Column(name = "last_logged_in_at", nullable = true)
    Date lastLoggedInAt


    User() {}
}
