package com.glynlyon.kl.classroom.dto

import com.glynlyon.kl.classroom.model.Course

class CoursesDTO {
    public List<Course> courses = new ArrayList<Course>()
}
