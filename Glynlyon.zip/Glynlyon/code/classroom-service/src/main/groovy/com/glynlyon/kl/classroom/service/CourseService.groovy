package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.model.Course
import com.glynlyon.kl.classroom.repo.CourseRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class CourseService {

    @Autowired
    CourseRepo courseRepo

    public List<Course> getAllCourses() {
        return courseRepo.findAll()
    }

    @Transactional
    public Long deleteByUuid(UUID courseUuid) {
        return courseRepo.deleteByUuid(courseUuid)
    }

    @Transactional
    public Course create(Course course) {
        Course exists = courseRepo.findByUuid(course.uuid)
        if(!exists) {
            courseRepo.save(course)
        } else {
            throw new ForbiddenException('Course already exists.')
        }
    }
}