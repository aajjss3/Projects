package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.ClassGradeLevel

class CustomGradeSerializer extends JsonSerializer<List<ClassGradeLevel>> {

    @Override
    void serialize(List<ClassGradeLevel> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeStartArray()
        value.grade.sort().each {
            gen.writeString(it.type)
        }
        gen.writeEndArray()
    }
}
