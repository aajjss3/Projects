package com.glynlyon.kl.classroom.service

import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.MessageSource
import org.springframework.core.env.Environment
import com.glynlyon.kl.classroom.dto.mapper.BaseMapper
import com.glynlyon.kl.classroom.exceptions.UnauthorizedException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.UserRepo

abstract class AbstractService {

	@Autowired
	UserRepo userRepo
	
	@Autowired
	EnrollmentRepo enrollmentRepo
	
	@Autowired
	protected MessageSource messageSource
	
	@Autowired
	protected JwtService jwtService
	
	@Autowired
	protected BaseMapper mapper
	
	@Autowired
	Environment env


	protected String getMessage( String message, List<String> values ){
		return messageSource.getMessage( message, values as String[], Locale.getDefault() )
	}
	
	protected String getMessage( String message ){
		return messageSource.getMessage( message, null, Locale.getDefault() )
	}
	
	protected void adminOrganizationValidation(UUID userUUID, UUID organizationUUID, AppUserType role) {
		if (role == AppUserType.ADMIN && (!userUUID || !organizationUUID || userRepo.countByUserAndOrganization(userUUID, organizationUUID) == 0L)) {
			throw new UnauthorizedException( getMessage("admin.organization.not.valid") )
		}
	}
	
	protected void teacherClassValidation(UUID userUUID, ClassObj classObj, AppUserType role) {
		if (role == AppUserType.TEACHER && (!userUUID || !classObj || enrollmentRepo.countAllByUserUuidAndClassObjUuid(userUUID, classObj.uuid) == 0L)) {
			throw new UnauthorizedException( getMessage("teacher.class.not.valid") )
		}
	}
	
	/**
	 * wrapper method that calls adminOrganizationValidation() and teacherClassValidation()
	 * @param userUUID
	 * @param organizationUUID
	 * @param classObj
	 * @param role
	 */
	protected void adminTeacherValidation(UUID userUUID, UUID organizationUUID, ClassObj classObj, AppUserType role){
		adminOrganizationValidation(userUUID, organizationUUID, role)
		teacherClassValidation(userUUID, classObj, role)
	}

}

