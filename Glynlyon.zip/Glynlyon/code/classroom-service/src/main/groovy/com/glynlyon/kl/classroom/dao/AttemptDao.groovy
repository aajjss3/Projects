package com.glynlyon.kl.classroom.dao

import com.glynlyon.kl.classroom.dao.filter.PageAttemptSearchBuilder
import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.exceptions.InvalidFilterException
import com.glynlyon.kl.classroom.model.*
import com.glynlyon.kl.classroom.pagination.OffsetBasedPageRequest
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.service.JsonMappingService
import com.glynlyon.kl.classroom.util.ScoreMapUtil
import org.apache.commons.lang3.StringUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.stereotype.Repository

import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query
import java.util.regex.Matcher
import java.util.regex.Pattern

@Repository
class AttemptDao {

    @PersistenceContext
    private EntityManager entityManager

    @Autowired
    JsonMappingService jsonMappingService

    @Autowired
    ScoreMapUtil scoreMapUtil

    @Autowired
    ClassRepo classRepo

    private Map<String, String> customMappings = [
            page_assignment_uuid : "activity_id"
    ]

    private String createFilterDbQuery(String filter) {
        String filterDBQuery = ""
        if (filter) {
            if (filter.find("^\\s*(AND|OR)\\s+")) {
                throw new InvalidFilterException("Filter cannot start with AND or OR")
            }
            PageAttemptSearchBuilder builder = new PageAttemptSearchBuilder()
            Pattern pattern = Pattern.compile("((?:(?:AND|OR)\\s+)*)((?:(?!contains)\\w)+\\.?(?:(?!contains)\\w)*)([^']*)'([^']*)'\\s?")
            Matcher matcher = pattern.matcher(filter)
            StringBuilder reconstruct = new StringBuilder()
            while (matcher.find()) {
                String fieldName = matcher.group(2)
                if(customMappings.containsKey(fieldName)){
                    fieldName = customMappings.get(fieldName)
                }
                builder.append(matcher.group(2), jsonMappingService.getEntityFieldName(fieldName, Attempt), matcher.group(3), matcher.group(4), matcher.group(1))
                reconstruct << matcher.group()
            }

            String filtersDidNotMatch = StringUtils.difference(reconstruct.toString(), filter)

            if (filtersDidNotMatch != '') {
                throw new InvalidFilterException("Invalid field '$filtersDidNotMatch' in the filter")
            }
            filterDBQuery = builder?.generateDBQuery()
        }
        return filterDBQuery
    }

    List<PageAttemptDTO> findLatestByPageUuid(UUID pageUuid){
        String baseQuery = createBaseQuery(true, false, null)
        Query query = entityManager.createNativeQuery(baseQuery)
        query.setParameter("pageUuid", pageUuid)
        return mapQueryToDto(query)
    }

    List<PageAttemptDTO> findLatestByClassUuid(UUID classUuid){
        String baseQuery = createBaseQuery(true, false, null, false)
        Query query = entityManager.createNativeQuery(baseQuery)
        query.setParameter("classUuid", classUuid)
        return mapQueryToDto(query)
    }

    Page<PageAttemptDTO> findByPageUuid(UUID pageUuid, String queryStringFilter, Boolean latest, Boolean includeOBE, OffsetBasedPageRequest pageable) {
        String filter = createFilterDbQuery(queryStringFilter)

        String baseQuery = createBaseQuery(latest, includeOBE, filter)

        String countQuery = """select count(*) from (${baseQuery}) q"""
        Query queryTotal = entityManager.createNativeQuery(countQuery);
        queryTotal.setParameter("pageUuid", pageUuid)
        long countResult = (long)queryTotal.getSingleResult();

        Query query = entityManager.createNativeQuery(baseQuery)
        query.setParameter("pageUuid", pageUuid)
        query.setFirstResult(pageable.offset)
        query.setMaxResults(pageable.limit)

        List<PageAttemptDTO> mappedAttempts = mapQueryToDto(query)
        if(mappedAttempts) {
            UUID classUuid = UUID.fromString(classRepo.findClassUuidByAttempt(mappedAttempts[0]?.attemptUuid)) // All attempts for a given page are from the same class
            mappedAttempts.each { attempt ->
                attempt.earnedScore = scoreMapUtil.getScoreAsMap(classUuid, attempt.assessmentScore?.toBigDecimal())
            }
        }
        return new PageImpl<PageAttemptDTO>(mappedAttempts, pageable, countResult)
    }

    private static List<PageAttemptDTO> mapQueryToDto(Query query){
        return query.resultList.collect{ def attempt ->
            return new PageAttemptDTO(
                    userUuid: UUID.fromString(attempt[0]),
                    pageAssignmentUuid: UUID.fromString(attempt[1]),
                    plannerEntryUuid: UUID.fromString(attempt[2]),
                    attemptUuid: UUID.fromString(attempt[3]),
                    state: attempt[4],
                    status: attempt[4],
                    assessmentScore: attempt[5],
                    completedAt: attempt[6]? new Date(attempt[6].getTime()):null,
                    plannerEntryStatus: attempt[7],
                    attemptNumber: attempt[8]
            )
        }
    }

    private static String createBaseQuery(Boolean latest, Boolean includeOBE, String filter, Boolean limitByPage = true){
        String columns = "attempt.uuid, attempt.planner_entry_uuid, attempt.user_uuid, " +
                "attempt.activity_id, attempt.section_count, attempt.section_total_count, " +
                "attempt.question_count, attempt.state, attempt.time_on_task_seconds, attempt.assessment_score, " +
                "attempt.sections, attempt.sections_viewed, attempt.included_manual_graded, attempt.created_at, attempt.updated_at, " +
                "attempt.version, attempt.questions_attempted_count, attempt.questions_correct_count, attempt.questions_incorrect_count, " +
                "attempt.questions_not_scored_count, attempt.response_overrides, attempt.completed_at, attempt.updated_by, pe.status, attempt.credit_bearing"
        String aggregates = "row_number() over (partition by a2.planner_entry_uuid order by attempt.created_at) as attempt_num"

        String columnsAndAggregates = "${columns}, ${aggregates}"

        String pageAttemptDTOColumns= " cast (user_uuid as text),cast (activity_id as text),cast (planner_entry_uuid as text),cast (uuid as text), attempt.state,assessment_score, completed_at, status, attempt_num, credit_bearing"

        String latestQuery = latest ? "DISTINCT ON (attempt.planner_entry_uuid)" : ""

        String innerQuery = """
        (SELECT ${latestQuery} ${columnsAndAggregates}
        FROM   {h-schema}attempt attempt
               INNER JOIN {h-schema}planner_entry pe ON pe.planner_entry_uuid = attempt.planner_entry_uuid
               INNER JOIN {h-schema}attempt a2 ON a2.planner_entry_uuid = pe.planner_entry_uuid
               INNER JOIN {h-schema}enrollment e on e.user_uuid = pe.user_uuid and e.class_uuid = pe.class_uuid
               INNER JOIN {h-schema}page_assignment pa on pa.assignment_uuid = pe.assignment_uuid and pa.page_uuid = pe.page_uuid
        WHERE  ${limitByPage ? "pe.page_uuid = :pageUuid" : "pe.class_uuid = :classUuid"}
        ${includeOBE ? "" : " AND pe.status != 'OBE' "}
        GROUP BY ${columns}, a2.planner_entry_uuid
        ORDER BY attempt.planner_entry_uuid, attempt.created_at DESC) attempt
        """

        String baseQuery = """
        SELECT ${pageAttemptDTOColumns} FROM ${innerQuery}
        ${filter ? 'WHERE '+filter : ''}
        """

        return baseQuery
    }

    void deleteSavedInProgressForPage(UUID pageUuid){
        String sql = """
        DELETE
        FROM {h-schema}attempt attempt
        USING {h-schema}planner_entry pe
        WHERE pe.planner_entry_uuid = attempt.planner_entry_uuid
        AND pe.page_uuid = :pageUuid
        AND (attempt.state = 'IN_PROGRESS' OR attempt.state = 'SAVED')
        """
        Query query = entityManager.createNativeQuery(sql)
        query.setParameter("pageUuid", pageUuid)
        query.executeUpdate()
    }

    void deleteSavedInProgressForClass(UUID classUuid){
        String sql = """
        DELETE
        FROM {h-schema}attempt attempt
        USING {h-schema}planner_entry pe
        WHERE pe.planner_entry_uuid = attempt.planner_entry_uuid
        AND pe.class_uuid = :classUuid
        AND (attempt.state = 'IN_PROGRESS' OR attempt.state = 'SAVED')
        """
        Query query = entityManager.createNativeQuery(sql)
        query.setParameter("classUuid", classUuid)
        query.executeUpdate()
    }

    List<User> findUserAttemptsByPageAssignment(PageAssignment pageAssignment) {
        String baseQuery = """
SELECT user0.app_user_uuid,
       user0.created_at,
       user0.first_name,
       user0.last_name,
       user0.origination_id,
       user0.sso_id,
       user0.app_user_status,
       user0.super_teacher,
       user0.app_user_type,
       user0.updated_at,
       user0.username,
	   user0.version,
	   user0.updated_by,
       user0.last_logged_in_at
FROM   {h-schema}attempt attempt
       INNER JOIN {h-schema}planner_entry pe
               ON attempt.planner_entry_uuid = pe.planner_entry_uuid
       INNER JOIN {h-schema}class class
               ON pe.class_uuid = class.class_uuid
       INNER JOIN {h-schema}enrollment enrollment
               ON class.class_uuid = enrollment.class_uuid
              AND attempt.user_uuid = enrollment.user_uuid
       INNER JOIN {h-schema}USER user0
               ON attempt.user_uuid = user0.app_user_uuid
WHERE  attempt.activity_id = '${pageAssignment.uuid.toString()}'
       AND ( attempt.state NOT IN ( '${AttemptState.SAVED}', '${AttemptState.IN_PROGRESS}' ) )
       AND enrollment.role = '${Role.STUDENT}'
"""
        Query query = entityManager.createNativeQuery(baseQuery, User)
        return query.resultList

    }



}
