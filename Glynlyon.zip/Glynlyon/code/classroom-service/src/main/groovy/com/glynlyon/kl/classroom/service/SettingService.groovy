package com.glynlyon.kl.classroom.service


import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Transactional
import com.glynlyon.kl.classroom.dao.SettingDao
import com.glynlyon.kl.classroom.dto.Admin
import com.glynlyon.kl.classroom.dto.Org
import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.dto.SettingsDTO
import com.glynlyon.kl.classroom.dto.Value
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.NotAcceptableException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.exceptions.UnauthorizedException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SettingRepo
import com.glynlyon.kl.classroom.util.Token

@Service
class SettingService extends AbstractService{
	
	@Autowired
	SettingRepo settingRepo
	
	@Autowired
	SettingDao settingDao
	
	@Autowired
	OrganizationRepo organizationRepo

	@Autowired
	ClassRepo classRepo

	@Autowired
	EnrollmentRepo enrollmentRepo


	public SettingDTO getSettings(UUID orgUuid, UUID classUuid, Token token){
		Organization organization = organizationRepo.findOne(orgUuid)
		if(!organization){
			throw new NotFoundException("Organization ${orgUuid} does not exist")
		}

		ClassObj classObj = classRepo.findOne(classUuid)
		if(!classObj){
			throw new NotFoundException("Class ${classUuid} does not exist")
		}

		Organization school = classObj.organization.type == OrganizationType.SCHOOL ? classObj.organization : classObj.organization.parent

		Organization tokenOrg = organizationRepo.findOne(token.schoolUUID)
		AppUserType role = token.role
		UUID userUuid = token.userUUID

		List<AppUserType> allowedRoles = [AppUserType.ADMIN, AppUserType.TEACHER, AppUserType.STUDENT]

		if(!(role in allowedRoles)){
			throw new ForbiddenException("Only Admins, Teachers, and Students can access this resource")
		}


		if(school.uuid != organization.uuid){
			throw new ForbiddenException("Class ${classObj.uuid} does not exist in school ${organization.uuid}")
		}

		if(role == AppUserType.ADMIN){
			if(tokenOrg != school){
				throw new ForbiddenException("User does not have access to class in school ${school.uuid}")
			}
		}
		else if(role == AppUserType.TEACHER || role == AppUserType.STUDENT){
			if(enrollmentRepo.countAllByUserUuidAndClassObjUuid(userUuid, classUuid) <= 0){
				throw new ForbiddenException("User must be enrolled in class to get class level settings")
			}
		}

		return findClassSettings(classUuid)
	}

	
	public SettingDTO getSettings(UUID orgUuid, Token token){
		Organization organization = organizationRepo.findOne(orgUuid)
		Organization tokenOrg = organizationRepo.findOne(token.schoolUUID)
		if(tokenOrg != organization){
			throw new UnauthorizedException("Unauthorized - the request is for the organization: " + orgUuid.toString() + ", but the user's organization is: " + tokenOrg.uuid.toString())
		}
		return findOrgSettings(orgUuid)
	}

	
	SettingDTO findClassSettings(UUID classUuid){
		Setting settings = settingRepo.findBySourceUUIDAndType(classUuid, SettingType.CLASS)
		if(!settings) {
			ClassObj classObj = classRepo.findOne(classUuid)
			if (classObj) {
				Organization school = classObj.organization.type == OrganizationType.SCHOOL ? classObj.organization : classObj.organization.parent
				return findOrgSettings(school.uuid)
			}
			return findGlobalSettings()
		}
		return settingToSettingDto(settings)
	}

	
	SettingDTO findOrgSettings(UUID orgUuid) {
		Setting settings = settingRepo.findBySourceUUIDAndType(orgUuid, SettingType.ORG)
		if(!settings){
			return findGlobalSettings()
		}
		return settingToSettingDto(settings)
	}

	
	SettingDTO findGlobalSettings(){
		return settingToSettingDto(settingRepo.findByType(SettingType.GLOBAL))
	}

	
	private SettingDTO settingToSettingDto(Setting setting){
		SettingDTO settingDTO = (SettingDTO)mapper.defaultMapAll(setting, SettingDTO.class)
		settingDTO.value = (Value)mapper.defaultMapAll(setting.value, Value.class)
		return settingDTO
	}
	
	
	/**
	 * If a settings record exists for the organization then update it. otherwise, create a new settings record for the organization.
	 * since multiple users can update the same record concurrently, use pessimistic locking. 
	 * If the organization passed in the url does not matches the organization in the token throw an UnauthorizedException
	 * 
	 * @param orgUUID - organizationUUID
	 * @param settingDTO
	 * @param organizationUUID
	 * @param userUUID
	 * @return
	 * @throws UnauthorizedException
	 */
	@Transactional(isolation=Isolation.READ_COMMITTED)
	public SettingDTO saveOrUpdateOrgSettings( UUID orgUUID, SettingDTO settingDTO, Token token ){
		
		// if the organization passed in the url does not match the organization in the request header then throw an exception
		if( token.schoolUUID != orgUUID ){
			throw new UnauthorizedException( super.getMessage( "setting.organization.invalid", [orgUUID.toString(), token.schoolUUID.toString()] ) )
		}
		
		Setting orgSetting = saveOrUpdateSetting(settingDTO, token.userUUID, orgUUID, SettingType.ORG)
				
		// if admin.override is false and if any records exist in the setting table for type CLASS that belong to this organization then delete those setting records. 
		if ( !settingDTO.value.admin.override ){
			List<UUID> classUuids = classRepo.findAllUUIDBySchool(orgUUID)?.collect{UUID.fromString(it)}
			if( classUuids ){
				settingRepo.deleteByTypeAndSourceUUIDIn(SettingType.CLASS, classUuids)
			}
		}
		
		return settingToSettingDto(orgSetting)
	}
	
	
	/**
	 * If a settings record exists for the class then update it. otherwise, create a new settings record for the class.
	 * since multiple users can update the same record concurrently, use pessimistic locking. 
	 * If the organization passed in the url does not matches the organization in the token throw an UnauthorizedException
	 * If the schools override value is false then do not insert/update class setting record and throw a NotAcceptableException
	 * 
	 * @param classUUID - class UUID from url
	 * @param orgUUID - organization UUID from the url
	 * @param settingDTO - settingDTO
	 * @param organizationUUID - organization UUID from request header
	 * @param userUUID - user UUID from request header
	 * @return
	 * @throws UnauthorizedException, NotAcceptableException
	 */
	@Transactional(isolation=Isolation.READ_COMMITTED)
	public SettingDTO saveOrUpdateClassSettings( UUID classUUID, UUID orgUUID, SettingDTO settingDTO, Token token ){
		
		// if the organization passed in the url does not match the organization in the request header then throw an exception
		if( token.schoolUUID != orgUUID ){
			throw new UnauthorizedException( super.getMessage( "setting.organization.invalid", [orgUUID.toString(), token.schoolUUID.toString()] ) )
		}
		
		// if the teacher is not enrolled in the class then throw an exception
		if( token.role == AppUserType.TEACHER ){
			Integer teacherEnrolled = enrollmentRepo.countByUserUuidAndClassObjUuid(token.userUUID, classUUID)
			if(!teacherEnrolled){
				throw new ForbiddenException( super.getMessage( "setting.teacher.not.enrolled" ) )
			}
		}
		
		// if the school's (organization) admin.override is false then throw an exception
		Setting schoolSetting = settingRepo.findBySourceUUIDAndType(orgUUID, SettingType.ORG)
		if( schoolSetting && !schoolSetting.value['admin']['override']){
			throw new NotAcceptableException( super.getMessage( "setting.school.override.false" ) )
		}
		
		// set admin.override to true
		settingDTO.value.admin = new Admin(true)
		Setting classSetting = saveOrUpdateSetting(settingDTO, token.userUUID, classUUID, SettingType.CLASS)
		
		return settingToSettingDto(classSetting)
	}
	
	@Transactional
	private Setting saveOrUpdateSetting(SettingDTO settingDTO, UUID userUUID, UUID uuid, SettingType type){
		Setting setting = settingDao.getSettingBySourcePessimistically(uuid)
		if( !setting ){
			setting = new Setting(createdAt: new Date(), updatedAt: new Date(), createdBy: userUUID, updatedBy: userUUID, type: type, sourceUUID: uuid, value: [admin: settingDTO.value.admin, classroom: settingDTO.value.classroom])
			setting = settingRepo.save(setting)
		}
		else{
			setting.value = [admin: settingDTO.value.admin, classroom: settingDTO.value.classroom]
			setting.updatedAt = new Date()
			setting.updatedBy = userUUID
		}
		return setting
	}
	
	
	/**
	 * Retrieve all org and class settings for the user uuid passed in.
	 * Org setting defaults to global setting if there is no explicit org setting. 
	 * @param userUUIDFromRequest
	 * @param excludeExpiredClasses if true then do not include/return any soft deleted classes
	 * @param token Token
	 * @return SettingsDTO
	 * @throws UnauthorizedException
	 */
	public SettingsDTO getSettingsForUser( UUID userUUIDFromRequest, boolean excludeExpiredClasses, Token token ){
		
		if(userUUIDFromRequest != token.userUUID){
			throw new UnauthorizedException("The user uuid in the request does not match the user uuid in the token.")
		}
		
		SettingsDTO settingsDTO = new SettingsDTO()
		List<Org> orgs = new ArrayList<Org>()
		settingsDTO.orgs = orgs
		
		// get a list of org and class uuids for the user 
		// sourceUUIDs is a map - the key is an organization uuid, the value is a list of class uuids for that organization
		Map<UUID, List<UUID>> sourceUUIDs = settingDao.findAllSourceUUIDsByUser(userUUIDFromRequest, excludeExpiredClasses)

		sourceUUIDs.each{ key, value ->
			Org org = new Org()
			orgs.add(org)
			org.orgUUID = key
			org.classes = value.collect{it.toString()}
			
			// set org settings
			org.orgSetting = this.findOrgSettings(key)
			
			// set class settings
			List<SettingDTO> classSettings = new ArrayList<SettingDTO>()
			org.classSettings = classSettings
			List<Setting> settings = settingRepo.findAllBySourceUUIDIn(value)
			for(Setting setting : settings){
				classSettings.add(settingToSettingDto(setting))
			}
			
		}
				
		return settingsDTO
		
	}
	

}

