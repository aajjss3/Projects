package com.glynlyon.kl.classroom.model

import java.util.Date
import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.Table

import org.hibernate.annotations.DynamicInsert



@Entity
@DynamicInsert
@Table(name="event_login_logout", indexes = [ @Index(columnList ="user_uuid", name="event_login_logout_user_idx") ])
class EventLoginLogout extends BaseEntity{
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "event_login_logout_uuid", nullable = false)
	public UUID uuid
	
	@Column(name = "created_at")
	public Date createdAt

	@Column(name = "updated_at")
	public Date updatedAt
	
	@Column(name = "created_by")
	public UUID createdBy
	
	@Column(name = "user_uuid")
	public UUID userUUID
	
	@Column(name = "logged_in")
	public Date loggedin
	
	@Column(name = "logged_out")
	public Date loggedout

}
