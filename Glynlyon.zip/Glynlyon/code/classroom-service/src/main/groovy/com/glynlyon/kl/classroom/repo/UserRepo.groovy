package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.User
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param

import javax.transaction.Transactional

interface UserRepo extends CrudRepository<User, UUID>, JpaSpecificationExecutor, LocalRepo<User> {

	public static final String QUERY_ADMIN_ORGANIZATION = "select sum(numberRows) from( select count(*) as numberRows from {h-schema}user_organization where user_uuid=:userUUID and organization_uuid =:organizationUUID union all select count(*) as numberRows from {h-schema}user_organization uo inner join {h-schema}organization o on uo.organization_uuid = o.parent where uo.user_uuid =:userUUID and o.organization_uuid=:organizationUUID) admin;"

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO {h-schema}User(app_user_uuid, first_name, last_name, username, sso_id, app_user_type, app_user_status, origination_id, version) VALUES (:uuid, :firstName, :lastName, :username, :ssoId, :appUserType, :appUserStatus, :originationId, 0)",nativeQuery = true)
    void createUser(
            @Param("uuid") UUID uuid,
            @Param("firstName") String firstName,
            @Param("lastName") String lastName,
            @Param("username") String username,
            @Param("ssoId") String ssoId,
            @Param("appUserType") String appUserType,
            @Param("appUserStatus") String appUserStatus,
            @Param("originationId") String originationId)

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO {h-schema}user_organization(user_uuid, organization_uuid) VALUES (:userUuid, :orgUuid)",nativeQuery = true)
    void addUserToOrg(@Param("userUuid") UUID userUuid, @Param("orgUuid") UUID orgUuid)

	// this query determines if an admin belongs to an organization. an admin can belong to an organization in 1 of 2 ways.
	// 1) if the admin's id and the organizations id has a record in the user_ogranization table
	// 2) if the organization is the parent of a child organization that exists in the user_organization table and the admin has a record in that table for the child organization.
	@Query(value = UserRepo.QUERY_ADMIN_ORGANIZATION, nativeQuery = true)
	Long countByUserAndOrganization(@Param("userUUID") UUID userUUID, @Param("organizationUUID") UUID organizationUUID)

}