package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIdentityInfo
import com.fasterxml.jackson.annotation.JsonIdentityReference
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.ObjectIdGenerators
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.constraints.MatchingEnrollmentRole
import com.glynlyon.kl.classroom.constraints.PrimaryRoleValid
import com.glynlyon.kl.classroom.converters.CustomClassObjDeserializer
import com.glynlyon.kl.classroom.converters.CustomClassObjSerializer
import com.glynlyon.kl.classroom.converters.CustomUserDeserializer
import com.glynlyon.kl.classroom.converters.CustomUserSerializer
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import org.hibernate.annotations.DynamicInsert
import java.util.UUID
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.FetchType
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.Transient
import javax.validation.constraints.NotNull

@Entity
@ToString
@EqualsAndHashCode
@DynamicInsert
@PrimaryRoleValid
@MatchingEnrollmentRole
class Enrollment  extends BaseEntity implements Serializable, GroovyObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "enrollment_uuid", nullable = false)
    @JsonProperty(value = "enrollment_uuid", access = JsonProperty.Access.READ_ONLY)
    UUID uuid

    @JsonProperty(value = "class_uuid")
    @JoinColumn(name = "class_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field class_uuid")
    @JsonIdentityReference(alwaysAsId = true)
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "uuid")
    @JsonDeserialize(using = CustomClassObjDeserializer)
    @JsonSerialize(using = CustomClassObjSerializer)
    ClassObj classObj

    @NotNull(message = "Missing required field user_uuid")
    @JoinColumn(name = "user_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @JsonIgnore
    User user

    @JsonProperty(value = "user_uuid")
    @JsonDeserialize(using = CustomUserDeserializer)
    void setUser(User user){
        this.user = user
    }

    @JsonProperty(value = "user")
    @JsonSerialize(using = CustomUserSerializer)
    User getUser(){
        return user
    }

    @Column(name = 'role', nullable = false)
    @NotNull(message = "Missing required field role")
    @Enumerated(EnumType.STRING)
    Role role

    @Column(name = "primary_role")
    @JsonProperty(value = "primary_role")
    Boolean primaryRole

    @Column(name = "status", nullable = false)
    @NotNull(message = "Missing required field status")
    @Enumerated(EnumType.STRING)
    Status status

    @Column(name = "created_at")
    @JsonIgnore
    Date created

    @Column(name = "updated_at")
    @JsonIgnore
    Date updated

	// the total time on task for all attempts associated with this enrollment
	// this value is not stored in the database and not passed in (deserialized) but it is calculated and pass out (serialized) (see placement of annotations: @JsonProperty and @JsonIgnore)
	@Transient
	@JsonIgnore
    private Integer timeOnTaskSeconds
	
	@JsonProperty(value = "time_on_task_seconds")
	public Integer getTimeOnTaskSeconds() {
		return timeOnTaskSeconds;
	}

	@JsonIgnore
	public void setTimeOnTaskSeconds(Integer timeOnTaskSeconds) {
		this.timeOnTaskSeconds = timeOnTaskSeconds;
	}

    Enrollment() {}

}
