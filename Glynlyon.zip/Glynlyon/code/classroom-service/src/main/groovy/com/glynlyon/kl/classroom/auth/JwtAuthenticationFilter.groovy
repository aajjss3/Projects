package com.glynlyon.kl.classroom.auth

import io.jsonwebtoken.Jwts
import org.springframework.http.HttpStatus
import org.springframework.web.filter.GenericFilterBean

import javax.servlet.FilterChain
import javax.servlet.ServletException
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import java.nio.charset.StandardCharsets

class JwtAuthenticationFilter extends GenericFilterBean {

    String jwtSecretKey

    JwtAuthenticationFilter(String jwtSecretKey) {
        this.jwtSecretKey = jwtSecretKey
    }

    @Override
    void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest request = req as HttpServletRequest
        HttpServletResponse response = res as HttpServletResponse

        if (request.getMethod() == "OPTIONS") {
            //this path shouldn't be filtered because it's needed to get the jwt
            chain.doFilter(req, res)
        } else {
            String authHeader = request.getHeader('Authorization')
            if (authHeader == null || !authHeader.startsWith('Bearer ')) {
                response.sendError(HttpStatus.UNAUTHORIZED.value(), 'Authorization header is missing or invalid')
                return
            }

            // The part after "Bearer " is the jwt
            final String token = authHeader.substring(7)
            
            try {
                Jwts.parser().setSigningKey(jwtSecretKey.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(token)
            }
            catch (Exception ignore) {
                response.sendError(HttpStatus.UNAUTHORIZED.value(), 'Invalid token')
                return
            }
            chain.doFilter(req, res)
        }
    }

}
