package com.glynlyon.kl.classroom.exceptions

import org.springframework.http.HttpStatus

class ClassObjNotFoundException extends RuntimeException {
    private String field
    private String message
    private HttpStatus status = HttpStatus.BAD_REQUEST

    ClassObjNotFoundException() {
        super()
    }

    ClassObjNotFoundException(String message) {
        super(message)
    }

    ClassObjNotFoundException(String message, Throwable cause) {
        super(message, cause)
    }

    ClassObjNotFoundException(Throwable cause) {
        super(cause)
    }

    protected ClassObjNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }

    public String getField(){
        return field
    }

    public String getStatus(){
        return status
    }

    public ClassObjNotFoundException(String field, String message, HttpStatus status = HttpStatus.BAD_REQUEST) {
        super(message)
        this.field = field
        this.message = message
        this.status = status
    }
}
