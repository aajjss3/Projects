package com.glynlyon.kl.classroom.util

import com.glynlyon.kl.classroom.model.AppUserType

class Token {
	public UUID userUUID
	public UUID schoolUUID
	public AppUserType role}
