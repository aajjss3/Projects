package com.glynlyon.kl.classroom.job

import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.service.PageService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.jms.annotation.JmsListener
import org.springframework.stereotype.Component

import javax.transaction.Transactional

@Component
class PageCompletionConsumerJob extends AbstractJob {

    @Autowired
    PageService pageService

    @Autowired
    PageRepo pageRepo


    @JmsListener(destination = '${jms.page.completion.queueName}')
    @Transactional
    public void recieveMessage(List<UUID> messages){
        processMessages(messages)
    }

    public void processMessages(List<UUID> messages){
        messages.each { pageUUID ->
            try {
                pageService.completeByPageUuid(pageUUID)
                PageObj page = pageRepo.findByUuid(pageUUID)
                page.completedDate = new Date()
                page.status = PageState.COMPLETED
            } catch (Exception e) {
                logger.error("Hourly job failed to process overdue page: ${pageUUID}")
            }
        }
    }
}