package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.constraints.DateOrder
import com.glynlyon.kl.classroom.constraints.ValidUser
import com.glynlyon.kl.classroom.converters.ClassObjSerializer
import com.glynlyon.kl.classroom.converters.CustomAcademicSessionDeserializer
import com.glynlyon.kl.classroom.converters.CustomAcademicSessionSerializer
import com.glynlyon.kl.classroom.converters.CustomGradeDeserializer
import com.glynlyon.kl.classroom.converters.CustomGradeSerializer
import com.glynlyon.kl.classroom.converters.CustomOrganizationDeserializer
import com.glynlyon.kl.classroom.converters.CustomOrganizationSerializer
import com.glynlyon.kl.classroom.converters.CustomSubjectDeserializer
import com.glynlyon.kl.classroom.converters.CustomSubjectSerializer
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import org.hibernate.annotations.DynamicInsert
import org.hibernate.validator.constraints.NotEmpty

import javax.persistence.CascadeType
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.FetchType
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.JoinColumns
import javax.persistence.ManyToOne
import javax.persistence.OneToMany
import javax.persistence.Table
import javax.persistence.Transient
import javax.validation.constraints.NotNull

@Entity
@Table(name="class")
@DynamicInsert
@DateOrder(message="stop_date must be at least one day after access_date", firstDate = "accessDate", secondDate = "stopDate")
@JsonSerialize(using = ClassObjSerializer)
@EqualsAndHashCode
@ToString(includeNames=true)
class ClassObj  extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "class_uuid", nullable = false)
    @JsonProperty(value = "class_uuid", access = JsonProperty.Access.READ_ONLY)
    UUID uuid

    @Column(name = 'type', nullable = false)
    @NotNull(message = "Missing required field type")
    @Enumerated(EnumType.STRING)
    ClassObjType type

    @Column(name = 'sub_type', nullable = false)
    @JsonProperty(value = 'sub_type')
    @NotNull(message = "Missing required field sub_type")
    @Enumerated(EnumType.STRING)
    ClassObjSubtype subtype

    @Column(name = 'state', nullable = false)
    @NotNull(message = "Missing required field state")
    @Enumerated(EnumType.STRING)
    ClassObjState state

    @JsonProperty(value = "state")
    void setState(ClassObjState classObjState) {
        this.state = classObjState
    }

    @JsonProperty(value = "status")
    void setStatus(ClassObjState classObjState) {
        if(!this.state) {
            this.state = classObjState
        }
    }

    @JsonProperty(value = "creator_uuid")
    @Column(name = "creator_uuid", nullable = false)
    @NotNull(message = "Missing required field creator_uuid")
    @ValidUser(message = "Could not find user with uuid \${validatedValue}")
    UUID creatorUuid

    @Column(name = "name", nullable = false)
    @NotEmpty(message = "Missing required field name")
    String name

    @Column(name = "class_id", nullable = false)
    @JsonProperty(value = "class_id")
    String classId

    @JoinColumns([
        @JoinColumn(name = "subject_uuid", referencedColumnName = "subject_uuid", nullable = false),
        @JoinColumn(name = "subject_organization_uuid", referencedColumnName = "organization_uuid", nullable = false)
    ])
    @ManyToOne(fetch=FetchType.LAZY)
    @JsonIgnore
    SubjectsView subject


    @JsonProperty(value = "subject_uuid")
    @JsonDeserialize(using = CustomSubjectDeserializer)
    void setSubject(SubjectsView s) {
        this.subject = s
    }

    @JsonProperty(value = "subject")
    @JsonSerialize(using = CustomSubjectSerializer)
    SubjectsView getSubject() {
        return subject
    }

    @JoinColumn(name = "organization_uuid")
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field organization_uuid")
    Organization organization



    @JsonProperty(value = "organization_uuid")
    @JsonDeserialize(using = CustomOrganizationDeserializer)
    Organization setOrganization (Organization org) {
        this.organization = org
    }

    @JsonProperty(value = "organization")
    @JsonSerialize(using = CustomOrganizationSerializer)
    Organization getOrganization() {
        return organization
    }

    @Column(name = "notes", nullable = false)
    String notes

    @JoinColumn(name = "academic_session_uuid", nullable = true)
    @ManyToOne(fetch=FetchType.LAZY)
    @JsonIgnore
    AcademicSession academicSession

    @JsonProperty(value = "academic_session_uuid")
    @JsonDeserialize(using = CustomAcademicSessionDeserializer)
    void setAcademicSession(AcademicSession a) {
        this.academicSession = a
    }
    
    @JsonProperty(value = "academic_session")
    @JsonSerialize(using = CustomAcademicSessionSerializer)
    AcademicSession getAcademicSession() {
        return academicSession
    }

    @Column(name = "access_date", nullable = false)
    @JsonProperty(value = "access_date")
    Date accessDate

    @Column(name = "stop_date", nullable = false)
    @JsonProperty(value = "stop_date")
    Date stopDate

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date created

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    Date updated


    @Column(name = "completed_at", nullable = true)
    @JsonProperty(value = "completed_at")
    Date completed

    @JsonProperty(value = "grade_level")
    @OneToMany(mappedBy = "classUuid", cascade = CascadeType.REMOVE)
    @JsonDeserialize(using = CustomGradeDeserializer)
    @JsonSerialize(using = CustomGradeSerializer)
    List<ClassGradeLevel> grades

    /**
     * TODO: rename done and doneDate fields to completed and completedDate if state COMPLETED ever gets renamed
     */
	Boolean done

    @Column(name = "done_date", nullable = true)
    @JsonProperty(value = "done_date")
    Date doneDate

    @Transient
    Map metadata

    ClassObj() {}

}
