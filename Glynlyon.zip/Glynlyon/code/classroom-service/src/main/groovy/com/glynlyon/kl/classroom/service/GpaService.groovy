package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsInput
import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsResponse
import com.glynlyon.kl.classroom.dto.grade.GpaScoresInput
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsInput
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsResponse
import com.glynlyon.kl.classroom.dto.grade.OutcomeResponse
import com.glynlyon.kl.classroom.exceptions.BadRequestException
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.web.client.RestTemplateBuilder
import org.springframework.core.env.Environment
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Service
import org.springframework.web.client.HttpStatusCodeException
import org.springframework.web.client.RestTemplate
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.annotation.PostConstruct
import javax.servlet.http.HttpServletRequest

@Service
class GpaService {

    @Autowired
    RestTemplateBuilder restTemplateBuilder

    Integer readTimeout

    Integer connectTimeout

    String gpaBaseUri

    @Autowired
    Environment env

    @PostConstruct()
    private void init() {
        gpaBaseUri = env.getRequiredProperty("gpa.base.uri")
        connectTimeout = env.getRequiredProperty("rest.timeout.connect.milliseconds", Integer)
        readTimeout = env.getRequiredProperty("rest.timeout.read.milliseconds", Integer)
    }

    Logger logger = LogManager.getLogger(this.class)

    OutcomeResponse calculateScores(GpaScoresInput input){
        return getScores(new MediaType("application", "vnd.attempts.v1+json"), input){Map response ->
            new OutcomeResponse(status: response.state, score: response.score)
        }
    }

    GpaAssignmentsResponse calculateAssignmentScores(GpaAssignmentsInput input){
        return getScores(new MediaType("application", "vnd.assignments.students.scores.v1+json"),input, GpaAssignmentsResponse){GpaAssignmentsResponse response ->
            return response
        }
    }

    GpaStudentsResponse calculateStudentScores(GpaStudentsInput input){
        return getScores(new MediaType("application", "vnd.students.assignments.scores.v1+json"),input, GpaStudentsResponse){GpaStudentsResponse response ->
            return response
        }
    }

    private <T> T getScores(MediaType contentType, Object body, Class clazz=Map, Closure<T> transform) {
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String authHeader = req.getHeader("Authorization")
        HttpHeaders headers = new HttpHeaders()
        headers.add("Authorization", authHeader)
        headers.setContentType(contentType)
        HttpEntity entity = new HttpEntity(body, headers)
        try {
            ResponseEntity response = getRestTemplate().exchange("${gpaBaseUri}/scores", HttpMethod.PUT, entity, clazz)
            return transform(response.body)
        }
        catch (HttpStatusCodeException e) {
            throw new BadRequestException("Error from gpa service: ${e.statusCode} ${e.responseBodyAsString}", Level.ERROR, e)
        }
        catch (Exception e) {
            throw new BadRequestException("Error communicating with gpa service: ${e.message}", Level.ERROR, e)
        }
    }


    private RestTemplate getRestTemplate(){
        return restTemplateBuilder.setConnectTimeout(connectTimeout).setReadTimeout(readTimeout).build()
    }
}