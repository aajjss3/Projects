package com.glynlyon.kl.classroom.hibernate

import org.hibernate.HibernateException
import org.hibernate.engine.spi.SessionImplementor
import org.hibernate.usertype.EnhancedUserType
import org.hibernate.usertype.ParameterizedType

import java.sql.PreparedStatement
import java.sql.ResultSet
import java.sql.SQLException

class PGEnumUserType implements EnhancedUserType, ParameterizedType {
    public static final int PG_ENUM_TYPE = 1111

    private Class<Enum> enumClass

    @Override
    String objectToSQLString(Object value) {
        return "'${((Enum)value).name()}"
    }

    @Override
    String toXMLString(Object value) {
        return ((Enum) value).name()
    }

    @Override
    Object fromXMLString(String xmlValue) {
        return Enum.valueOf(enumClass, xmlValue)
    }

    @Override
    void setParameterValues(Properties parameters) {
        String enumClassName = parameters.getProperty('enumClassName')
        try {
            enumClass = (Class<Enum>) Class.forName(enumClassName)
        } catch (ClassNotFoundException ex) {
            throw new HibernateException("Enum class not found: ${enumClassName}", ex)
        }
    }

    @Override
    int[] sqlTypes() {
        return [ PG_ENUM_TYPE ]
    }

    @Override
    Class returnedClass() {
        return enumClass
    }

    @Override
    boolean equals(Object x, Object y) throws HibernateException {
        return x == y
    }

    @Override
    int hashCode(Object x) throws HibernateException {
        return x.hashCode()
    }

    @Override
    Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {
        Object object = rs.getObject(names[0])

        if (rs.wasNull())
            return null

        return Enum.valueOf(enumClass, object)
    }

    @Override
    void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException {
        if (value == null) {
            st.setNull(index, PG_ENUM_TYPE)
        } else {
            st.setObject(index, ((Enum) value), PG_ENUM_TYPE)
        }
    }

    @Override
    Object deepCopy(Object value) throws HibernateException {
        return value
    }

    @Override
    boolean isMutable() {
        return false
    }

    @Override
    Serializable disassemble(Object value) throws HibernateException {
        return (Enum) value
    }

    @Override
    Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached
    }

    @Override
    Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original
    }
}

