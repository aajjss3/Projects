package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.hibernate.PGEnumUserType
import org.hibernate.annotations.Parameter
import org.hibernate.annotations.Type
import org.hibernate.annotations.TypeDef
import org.hibernate.annotations.TypeDefs

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.FetchType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.JoinTable
import javax.persistence.ManyToMany
import javax.persistence.ManyToOne
import javax.persistence.OneToMany
import javax.persistence.Table

@Entity
@Table(name="organization")
@TypeDefs([
        @TypeDef(name = 'enum', typeClass = PGEnumUserType)
])
class Organization extends BaseEntity implements Serializable, GroovyObject {
	
    @Id
    @JsonProperty(value = "organization_uuid")
    @Column(name = "organization_uuid")
    UUID uuid = UUID.randomUUID()

    @JsonIgnore
    @ManyToMany
    @JoinTable(
            name = "user_organization",
            joinColumns = @JoinColumn(name = "organization_uuid"),
            inverseJoinColumns = @JoinColumn(name = "user_uuid")
    )
    Set<User> users

    @Column(name = "name", nullable = false)
    String name

    @Column(nullable = false)
    @Type(type = 'enum', parameters = [
            @Parameter(name = 'enumClassName', value = 'com.glynlyon.kl.classroom.model.OrganizationType')
    ])
    OrganizationType type

    @Column(name = "origination_id", nullable = false)
    String originationId

    @Column(name = "created_at", nullable = false)
    Date created

    @Column(name = "updated_at", nullable = false)
    Date updated

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="parent") //default value is parent_organization_uuid
    Organization parent

    @OneToMany(mappedBy = "parent")
    @JsonIgnore
    Set<Organization> children

    @Column(name = "timezone", nullable = true)
    String timezone

    Organization() {}

}
