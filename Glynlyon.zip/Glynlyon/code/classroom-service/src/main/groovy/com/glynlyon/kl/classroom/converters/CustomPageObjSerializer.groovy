package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.BeanDescription
import com.fasterxml.jackson.databind.JavaType
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.fasterxml.jackson.databind.ser.BeanSerializerFactory
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value

class CustomPageObjSerializer extends JsonSerializer<PageObj> {
    @Autowired
    PageAssignmentRepo pageAssignmentRepo;

    @Value('${cltSearch.base.uri}')
    String cltBaseUri

    @Override
    void serialize(PageObj value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        def assignments = []
        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAllByPageObjUuidOrderBySequenceAsc(value.uuid)
        pageAssignments.each { assignment ->
            assignments << [page_assignment_uuid: assignment.uuid,
                            "sequence": assignment.sequence,
                            assignment: assignment.assignment
            ]
        }

        gen.writeStartObject()
        JavaType javaType = serializers.constructType(PageObj.class);
        BeanDescription beanDesc = serializers.getConfig().introspect(javaType);
        JsonSerializer<Object> serializer = BeanSerializerFactory.instance.findBeanSerializer(serializers, javaType, beanDesc);
        serializer.unwrappingSerializer(null).serialize(value, gen, serializers)
        gen.writeObjectField("page_assignments", assignments)
        gen.writeEndObject()
    }
}
