package com.glynlyon.kl.classroom.exceptions

/**
 *  This exception is thrown if no match found for filter
 *
 */
class InvalidFilterException extends RuntimeException {
    InvalidFilterException() {
        super()
    }

    InvalidFilterException(String message) {
        super(message)
    }

    InvalidFilterException(String message, Throwable cause) {
        super(message, cause)
    }

    InvalidFilterException(Throwable cause) {
        super(cause)
    }

    protected InvalidFilterException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}

