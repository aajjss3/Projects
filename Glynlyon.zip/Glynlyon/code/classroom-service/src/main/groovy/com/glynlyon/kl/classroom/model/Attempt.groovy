package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.clt.hibernate.JsonbUserType
import com.glynlyon.kl.classroom.hibernate.HstoreUserType
import groovy.transform.EqualsAndHashCode
import org.hibernate.annotations.DynamicInsert
import org.hibernate.annotations.Parameter
import org.hibernate.annotations.Type
import org.hibernate.annotations.TypeDef
import org.hibernate.annotations.TypeDefs

import javax.persistence.CascadeType
import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.FetchType
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Index
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.OneToMany
import javax.persistence.Table
import javax.validation.constraints.NotNull

@Entity
@DynamicInsert
@EqualsAndHashCode(includeFields = true)
@Table(indexes = [ @Index(columnList ="planner_entry_uuid", name="planner_entry_uuid_idx") ])
@TypeDefs([
		@TypeDef(name = 'jsonb', typeClass = JsonbUserType),
        @TypeDef(name = 'hstore', typeClass = HstoreUserType)
])
class Attempt extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @JsonProperty(value = "attempt_uuid", access = JsonProperty.Access.READ_ONLY)
    public UUID uuid

	@JsonProperty(value = "planner_entry_uuid")
	@JoinColumn(name = "planner_entry_uuid", nullable = true)
	@ManyToOne(fetch=FetchType.LAZY)
	public PlannerEntry plannerEntry

    @OneToMany(mappedBy = "attempt", cascade = CascadeType.REMOVE)
    List<AttemptSave> saves

    @JsonProperty(value = "user_uuid")
    @NotNull(message = "Missing required field user_uuid")
    @JoinColumn(name = "user_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    public User user

    @Column(name = "activity_id", nullable = true)
    @JsonProperty(value = "activity_id")
    public UUID activityId

    @Column(name = 'section_count', nullable = true)
	@JsonProperty(value = "section_count")
    public Integer sectionCount

    @Column(name = 'section_total_count', nullable = true)
	@JsonProperty(value = "section_total_count")
    public Integer sectionTotalCount

    @Column(name = 'question_count', nullable = true)
	@JsonProperty(value = "question_count")
    public Integer questionCount

    @Column(name = 'questions_attempted_count', nullable = true)
	@JsonProperty(value = "questions_attempted_count")
    public Integer questionsAttemptedCount

    @Column(name = 'questions_correct_count', nullable = true)
    @JsonProperty(value = "questions_correct_count")
    public Integer questionsCorrectCount

    @Column(name = 'questions_incorrect_count', nullable = true)
    @JsonProperty(value = "questions_incorrect_count")
    public Integer questionsIncorrectCount

    @Column(name = 'questions_not_scored_count', nullable = true)
    @JsonProperty(value = "questions_not_scored_count")
    public Integer questionsNotScoredCount

    @Type(type = "hstore")
    @Column(name= "response_overrides", columnDefinition = "hstore", nullable = true)
    @JsonProperty(value = "response_overrides")
    public HashMap<String, Boolean> responseOverrides

    // map: key is response id that is returned from Learnosity, value is teacher override (default to Null)
    HashMap<String, Boolean> getResponseOverrides() {
        // In Postgres, hstore is (key, value). value is string or sql Null.
        //so converting it back to Boolean.
        if ( responseOverrides ){
            return responseOverrides.collectEntries {k,v -> [k,(v != "null" && v )?v.toBoolean():null]}
        }
    }

    @Column(name = 'state', nullable = false)
    @NotNull(message = "Missing required field state")
    @Enumerated(EnumType.STRING)
    public AttemptState state

    @Column(name = 'time_on_task_seconds', nullable = true)
	@JsonProperty(value = "time_on_task_seconds")
    public Integer timeOnTaskSeconds

    @Column(name = 'assessment_score', nullable = true)
	@JsonProperty(value = "assessment_score")
    public Double assessmentScore

    @Column(name = 'sections')
	@Type(type = 'jsonb', parameters = [
			@Parameter(name = 'jsonClass', value = 'java.util.List')
	])
	public List sectionItems

    @Column(name = 'sections_viewed')
    @Type(type = 'jsonb', parameters = [
            @Parameter(name = 'jsonClass', value = 'java.util.List')
    ])
    public List sectionsViewed

    @Column(name = 'questions_viewed')
    @Type(type = 'jsonb', parameters = [
            @Parameter(name = 'jsonClass', value = 'java.util.List')
    ])
    public List questionsViewed

    @Column(name = 'questions_answered')
    @Type(type = 'jsonb', parameters = [
            @Parameter(name = 'jsonClass', value = 'java.util.List')
    ])
    public List questionsAnswered

    @Column(name = 'included_manual_graded', nullable = true)
	@JsonProperty(value = "included_manual_graded")
    public Boolean includedManualGraded

    @Column(name = "completed_at", nullable = true)
    @JsonProperty(value = "completed_at")
    public Date completedAt

    @Column(name = "created_at", nullable = false)
	@JsonProperty(value = "created_at")
    public Date createdAt

    @Column(name = "updated_at", nullable = false)
	@JsonProperty(value = "updated_at")
    public Date updatedAt
	
    @Column(name = "credit_bearing")
    @JsonProperty(value = "credit_bearing")
    public Boolean creditBearing

}