package com.glynlyon.kl.classroom.model

public enum PageState {
    ACTIVE,
    INACTIVE,
    COMPLETED
}