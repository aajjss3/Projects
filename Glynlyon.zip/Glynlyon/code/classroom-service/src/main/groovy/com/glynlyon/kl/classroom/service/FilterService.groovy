package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.InvalidFilterException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.ErrorOutput
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.dao.InvalidDataAccessApiUsageException
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.stereotype.Service

import javax.persistence.criteria.Predicate
import java.util.regex.Matcher
import java.util.regex.Pattern

import static com.glynlyon.kl.classroom.specs.Spec.spec
import static org.springframework.data.jpa.domain.Specifications.where

@Service
class FilterService {

    @Autowired
    JsonMappingService jsonMappingService

    @Autowired
    PageableService pageableService

    static Logger logger = LogManager.getLogger(FilterService)

    public <T> Page<T> find(String filter, Class<T> clazz, JpaSpecificationExecutor repo, Pageable pageable, Map<String, String> customMappings, Closure<Specification> extraSpecs, Closure<Predicate> listContains = null){
        try {
            Pattern primaryPattern = ~/(([a-zA-Z0-9_]+)(\.[a-zA-Z0-9_]+)?)(!=|>=|<=|>|<|=|contains)'([^']*)'+( .*)?/
            Pattern extraPattern = ~/(AND|and|OR|or) (([a-zA-Z0-9_]+)(\.[a-zA-Z0-9_]+)?)(!=|>=|<=|>|<|=|contains)'([^']*)'/
            Matcher matcher = primaryPattern.matcher(filter)

            if (matcher.find()) {
                String entireField = matcher.group(1)
                String operator = matcher.group(4)
                String value = matcher.group(5)
                String extra = matcher.group(6)

                if(customMappings.containsKey(entireField)){
                    entireField = customMappings.get(entireField)
                }

                def real_field = jsonMappingService.getEntityFieldName(entireField, clazz)

                def specs = spec(real_field, operator, value, listContains)

                if (extra) {
                    Matcher extraMatch = extraPattern.matcher(extra)
                    if(!extraMatch.find()){
                        throw new InvalidFilterException("Invalid filter expression " + extra)
                    }
                    extraMatch.reset()
                    while (extraMatch.find()) {
                        String logicalOp = extraMatch.group(1)
                        String entireSubField = extraMatch.group(2)
                        String subOp = extraMatch.group(5)
                        String subVal = extraMatch.group(6)

                        if(customMappings.containsKey(entireSubField)){
                            entireSubField = customMappings.get(entireSubField)
                        }

                        def real_subField = jsonMappingService.getEntityFieldName(entireSubField, clazz)

                        if (logicalOp.equalsIgnoreCase("and")) {
                            specs = where(specs).and(spec(real_subField, subOp, subVal, listContains))
                        } else if (logicalOp.equalsIgnoreCase("or")) {
                            specs = where(specs).or(spec(real_subField, subOp, subVal, listContains))
                        }
                    }
                }

                if(extraSpecs){
                    Specification specification = extraSpecs()
                    if(specification){
                        specs = where(specs).and(extraSpecs())
                    }
                }

                return repo.findAll(specs, pageable)

            } else {
                logger.info("Invalid filter " + filter)
                throw new InvalidFilterException("Invalid filter " + filter)
            }
        } catch(InvalidDataAccessApiUsageException | InvalidFilterException | UnsupportedFieldException e){
            logger.info(e.getMessage() ?: "Unknown error", e)
            String message = e.getMessage()
            if(message.startsWith("Illegal attempt to dereference path source") || e instanceof  UnsupportedFieldException){
                message = "Unavailable filter path"
            }
            return handleError(pageable, filter, message)
        } catch (Throwable t) {
            logger.error(t.getMessage() ?: "Unknown error", t)
            return handleError(pageable, filter, t.getMessage())
        }
    }

    private static PageImpl handleError(Pageable pageable, String filter, String message){
        return new PageImpl([new ErrorOutput(field: 'filter - ' + filter, message: message)], pageable, pageable.getOffset())
    }
}
