package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Lock
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.JpaRepository

interface LockRepo extends JpaRepository<Lock, UUID>, JpaSpecificationExecutor, LocalRepo<Lock>  {
    Lock findByResourceUuid(UUID resourceUuid)
    Lock findByResourceUuidAndLockedByUserUuid(UUID resourceUuid, UUID userUuid)
}
