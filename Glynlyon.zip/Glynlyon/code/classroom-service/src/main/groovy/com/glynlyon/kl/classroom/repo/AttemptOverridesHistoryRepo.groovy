package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.AttemptOverridesHistory

import org.springframework.data.domain.Pageable
import org.springframework.data.domain.Page
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository


public interface AttemptOverridesHistoryRepo extends PagingAndSortingRepository<AttemptOverridesHistory, UUID>, JpaSpecificationExecutor{
	
	public Page<AttemptOverridesHistory> findAllByAttemptUUID(UUID attemptUUID, Pageable pageable)

}
