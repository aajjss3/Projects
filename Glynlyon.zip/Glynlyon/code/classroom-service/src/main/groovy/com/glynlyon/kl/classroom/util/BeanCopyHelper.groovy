package com.glynlyon.kl.classroom.util

import org.springframework.beans.BeanUtils
import org.springframework.beans.BeanWrapper
import org.springframework.beans.BeanWrapperImpl

import java.beans.PropertyDescriptor

class BeanCopyHelper {

    /**
     * Copies the not-null properties from src to target
     * @param src
     * @param target
     */
    public static void copyPropertiesExcludeNulls(Object src, Object target) {
        BeanUtils.copyProperties(src, target, getNullPropertyNames(src))
    }

    private static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source)
        PropertyDescriptor[] pds = src.getPropertyDescriptors()

        Set<String> emptyNames = pds.findAll{pd -> return src.getPropertyValue(pd.name) == null}.collect{it.name}
        return emptyNames.toArray()
    }
}
