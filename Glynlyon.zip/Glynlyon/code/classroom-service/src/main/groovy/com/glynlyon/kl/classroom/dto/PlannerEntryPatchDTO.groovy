package com.glynlyon.kl.classroom.dto

import com.glynlyon.kl.classroom.model.PlannerEntryState

class PlannerEntryPatchDTO extends BaseDTO{
    Integer slot
    PlannerEntryState status
}
