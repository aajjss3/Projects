package com.glynlyon.kl.classroom.constraints

import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Role

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class PrimaryRoleValidator implements ConstraintValidator<PrimaryRoleValid, Enrollment> {

    @Override
    void initialize(PrimaryRoleValid constraintAnnotation) {
    }

    @Override
    boolean isValid(Enrollment enrollment, ConstraintValidatorContext context) {

        Boolean valid = !enrollment?.primaryRole || Role.TEACHER.equals(enrollment?.role) || Role.ADMINISTRATOR.equals(enrollment?.role)
        if(!valid){
            context.buildConstraintViolationWithTemplate(context.getDefaultConstraintMessageTemplate()).addPropertyNode("primaryRole").addConstraintViolation()
        }
        return valid
    }
}
