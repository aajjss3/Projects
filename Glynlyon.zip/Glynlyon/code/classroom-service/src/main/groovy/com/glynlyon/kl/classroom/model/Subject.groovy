package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.constraints.ValidOrg
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString
import org.hibernate.validator.constraints.NotBlank

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.Transient
import javax.validation.constraints.NotNull

@Entity
@ToString(includeNames = true)
@EqualsAndHashCode
class Subject extends BaseEntity implements Serializable, GroovyObject {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "subject_uuid", nullable = false)
    @JsonProperty(value = "subject_uuid")
    UUID uuid

    @Column(name = "name", nullable = false)
    @NotBlank(message = "Missing required field name")
    String name

    @JsonProperty(value = "organization_uuid")
    @Column(name = "organization_uuid")
    @NotNull(message = "Missing required field organization_uuid")
    @ValidOrg(message = "Could not find organization with uuid \${validatedValue}")
    UUID organizationUuid

    @Column(name = "created_at", nullable = true)
    @JsonIgnore
    Date createdAt

    @Column(name = "updated_at", nullable = true)
    @JsonIgnore
    Date updatedAt

    @Transient
    @JsonProperty(value = "disabled")
    Boolean disabled

    Subject() {}

}
