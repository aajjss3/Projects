package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.dto.IssuerLaunchDTO
import com.glynlyon.kl.classroom.model.IssuerLaunch
import com.glynlyon.kl.classroom.service.IssuerLaunchesService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletResponse

@RestController
class IssuerLaunchesController extends AbstractController {

    @Autowired
    IssuerLaunchesService issuerLaunchesService

    @GetMapping(path = "/issuerlaunches/{uuid}")
    @ResponseStatus(value = HttpStatus.OK)
    Map markToken(@PathVariable('uuid') UUID uuid) {
        IssuerLaunch newLaunch = issuerLaunchesService.markExisting(uuid)
        return [jwt : newLaunch.jwt]
    }

    @PostMapping(path = "/issuerlaunches")
    @ResponseStatus(value = HttpStatus.CREATED)
    void create(
            @RequestHeader(name = "Authorization", required = true) authHeader,
            @Validated @RequestBody IssuerLaunchDTO dto, HttpServletResponse response) {
        String jwt = authHeader.substring(JWT_STARTING_INDEX)
        String url = issuerLaunchesService.saveLaunchAndGenerateRedirectUrl(jwt, dto)

        response.setHeader("Location", url)
        response.setHeader("Access-Control-Expose-Headers", "Location")
    }
}
