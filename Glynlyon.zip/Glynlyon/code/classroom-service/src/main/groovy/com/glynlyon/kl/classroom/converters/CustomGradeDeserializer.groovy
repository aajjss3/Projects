package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.fasterxml.jackson.databind.node.ArrayNode
import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.Grade

class CustomGradeDeserializer extends StdDeserializer<List<ClassGradeLevel>>{

    protected CustomGradeDeserializer() {
        super(ClassGradeLevel)
    }

    @Override
    List<ClassGradeLevel> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        ArrayNode node = p.readValueAsTree()
        List<ClassGradeLevel> grades = node.collect {
            new ClassGradeLevel(grade: p.codec.treeToValue(it, Grade))
        }
        return grades
    }
}
