package com.glynlyon.kl.classroom.dto.grade

import java.util.Map

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

public class GpaAssignmentsResponse {
    List<AssignmentResponse> assignments
    List failures

    static class AssignmentResponse {
        @JsonIgnore
        String id

        @JsonProperty(value = "uuid")
        public String getId(){
            return id
        }

        @JsonProperty(value = "id")
        public void setId(String id){
            this.id = id
        }

        @JsonProperty(value="average_score")
        BigDecimal averageScore

        @JsonProperty(value = "total_students")
        Integer totalStudents
		
		@JsonProperty(value="average_scores")
		Map<String, Object> averageScores = new HashMap<String, Object>()
    }
}