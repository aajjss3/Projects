package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Sync
import com.glynlyon.kl.classroom.model.SyncStatus
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SyncRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.util.DateFormat
import groovyx.gpars.GParsPool
import jsr166y.ForkJoinPool
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.web.client.RestTemplateBuilder
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.orm.jpa.JpaSystemException
import org.springframework.stereotype.Service
import org.springframework.transaction.CannotCreateTransactionException
import org.springframework.web.client.HttpStatusCodeException
import org.springframework.web.client.RestTemplate
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

@Service
class SyncService {

    @Autowired
    RestTemplateBuilder restTemplateBuilder

    @Autowired
    JwtService jwtUtil

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    SyncRepo syncRepo

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    @Value('${rest.timeout.read.milliseconds}')
    Integer readTimeout

    @Value('${rest.timeout.connect.milliseconds}')
    Integer connectTimeout

    @Autowired
    ForkJoinPool forkJoinPool

    @Autowired
    FilterService filterService

    Logger logger = LogManager.getLogger(SyncService)

    private static final Integer ORG_RESULT_LIMIT = 100
    private static final Integer USER_RESULT_LIMIT = 500

    public Page<Sync> getStatusList(String filter, Pageable pageable){
        if(filter) {
            return filterService.find(filter, Sync, syncRepo, pageable, [:], null, null)
        }
        return syncRepo.findAll(pageable)
    }

    public void sync(Boolean fullSync){
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String authHeader = req.getHeader("Authorization")

        HttpHeaders headers = new HttpHeaders()
        headers.add("Authorization", authHeader)
        HttpEntity entity = new HttpEntity(headers)
        String token = authHeader.substring(7)
        String datasource = jwtUtil.getDatasource(token)

        Sync sync = syncRepo.save(new Sync(
                originationId: datasource,
                serverName: req.serverName,
                startedAt: new Date(),
                status: SyncStatus.IN_PROGRESS
        ))

        String filterDate = getFilterDate(datasource)
        String dateFilter = (filterDate && !fullSync) ? "dateLastModified>'${filterDate}'" : ""
        try {
            ["school", "campus"].each { orgType ->
                boolean finished = false
                int offset = 0
                while(!finished) {
                    Map body = getRosterOrgs(orgType, dateFilter, offset, entity)
                    if(body?.orgs?.size){
                        logger.debug("Processing ${body?.orgs?.size} ${orgType}(s)")
                    }
                    GParsPool.withExistingPool(forkJoinPool) {
                        body.orgs.eachParallel { Map org ->
                            try {
                                saveOrUpdateOrganization(org, datasource)
                            }
                            catch (Throwable t) {
                                sync.status = SyncStatus.ERROR
                                logger.error("error saving org: ${org}", t)
                            }
                        }
                    }
                    if(body.current_page == null || body.total_pages == null || (body.current_page >= body.total_pages)) {
                        finished = true
                    }
                    offset += ORG_RESULT_LIMIT
                }
            }
        }
        catch (Throwable t) {
            sync.status = SyncStatus.ERROR
            logger.error(t.message, t)
        }

        GParsPool.withExistingPool(forkJoinPool) {
            organizationRepo.findAllByTypeAndOriginationId(OrganizationType.SCHOOL, datasource).collectParallel { it.uuid }.eachParallel { schoolUuid ->
                try {
                    String tmpToken = jwtUtil.updateOrgUuid(token, schoolUuid)
                    HttpHeaders userHeaders = new HttpHeaders()
                    userHeaders.add("Authorization", "Bearer ${tmpToken}")
                    HttpEntity userEntity = new HttpEntity(userHeaders)

                    boolean finished = false
                    int offset = 0
                    while (!finished) {
                        try {
                            Map body = getRosterUsers(dateFilter, offset, userEntity)
                            if (body?.users?.size) {
                                logger.debug("Processing ${body?.users?.size} user(s) for school ${schoolUuid}")
                            }
                            GParsPool.withExistingPool(forkJoinPool) {
                                body.users.eachParallel { Map user ->
                                    if (user.userId || user.username) {
                                        try {
                                            saveOrUpdateUser(user, datasource)
                                        }
                                        catch (Throwable t) {
                                            logger.error("error saving user: ${user}", t)
                                            sync.status = SyncStatus.ERROR
                                        }
                                    }
                                    else {
                                        logger.warn("user missing both ssoId and username: #${user}")
                                    }
                                }
                            }

                            if (body.current_page == null || body.total_pages == null || (body.current_page >= body.total_pages)) {
                                finished = true
                            }
                            offset += USER_RESULT_LIMIT
                        }
                        catch (HttpStatusCodeException e){
                            if(e.statusCode == HttpStatus.GONE) {
                                logger.info("Skipping users for hidden school ${schoolUuid}")
                            }
                            else {
                                sync.status = SyncStatus.ERROR
                                logger.error(e.responseBodyAsString, e)
                            }
                            finished = true
                        }
                    }
                }
                catch (Throwable t){
                    sync.status = SyncStatus.ERROR
                    logger.error(t.message, t)
                }
            }
        }
        if (sync.status == SyncStatus.IN_PROGRESS) {
            sync.status = SyncStatus.SUCCESS
        }
        sync.endedAt = new Date()
        syncRepo.save(sync)
    }

    Map getRosterOrgs(String orgType, String dateFilter, Integer offset, HttpEntity entity){
        HttpEntity resp = getRestTemplate().exchange("${rosteringBaseUri}/orgs?filter=type='${orgType}'${dateFilter ? " AND ${dateFilter}" : ""}&limit=${ORG_RESULT_LIMIT}&offset=${offset}", HttpMethod.GET, entity, Map)
        return resp.body
    }

    Map getRosterUsers(String dateFilter, Integer offset, HttpEntity entity){
        HttpEntity resp = getRestTemplate().exchange("${rosteringBaseUri}/users?filter=${dateFilter}&limit=${USER_RESULT_LIMIT}&offset=${offset}", HttpMethod.GET, entity, Map)
        return resp.body
    }

    private User saveOrUpdateUser(Map inputUser, String dataSource, Integer retryCount = 0){
        try {
            UUID uuid = UUID.fromString(inputUser.sourcedId)
            User existing = userRepo.findByUuid(uuid)
            if(existing){
                Date created = existing?.created ?: new Date()
                User user = new User(
                        uuid: uuid,
                        firstName: inputUser.givenName,
                        lastName: inputUser.familyName,
                        userName: inputUser.username,
                        ssoId: inputUser.userId,
                        type: inputUser.role.toUpperCase() as AppUserType,
                        status: convertStatus(inputUser.status),
                        originationId: dataSource,
                        created: created,
                        updated: new Date(),
                        organizations: organizationRepo.findAllByUuidIn(inputUser.orgs.collect{UUID.fromString(it.sourcedId)}.toSet()),
                        version: existing.version
                )
                return userRepo.save(user)
            }
            else {
                userRepo.createUser(uuid, inputUser.givenName, inputUser.familyName, inputUser.username, inputUser.userId, (inputUser.role.toUpperCase() as AppUserType).toString(), convertStatus(inputUser.status).toString(), dataSource)
                inputUser.orgs.collect{UUID.fromString(it.sourcedId)}.toSet().each {
                    userRepo.addUserToOrg(uuid, it)
                }
                return null
            }

        }
        catch(JpaSystemException | CannotCreateTransactionException e ){
            if(retryCount == 0) {
                if ((e?.cause?.cause?.message && e.cause.cause.message.contains("FATAL: sorry, too many clients already")) ||
                        (e?.cause?.cause?.cause?.message && e.cause.cause.cause.message.contains("FATAL: sorry, too many clients already"))) {
                    logger.warn("failed to get db connection, sleeping and then retrying")
                    sleep(1000)
                    return saveOrUpdateUser(inputUser, dataSource, 1)
                }
            }
            throw e
        }
    }

    private static AppUserStatus convertStatus(String status){
        switch(status.toUpperCase()){
            case "ACTIVE":
                return AppUserStatus.ACTIVE
            case "INACTIVE":
                return AppUserStatus.ON_HOLD
            case "TOBEDELETED":
                return AppUserStatus.PENDING_ARCHIVE
            case "ARCHIVED":
                return AppUserStatus.ARCHIVE
            default:
                throw new RuntimeException("Cannot convert status ${status} to AppUserType")
        }
    }

    private Organization saveOrUpdateOrganization(Map inputOrg, String dataSource){
        UUID uuid = UUID.fromString(inputOrg.sourcedId)
        Organization existing = organizationRepo.findOne(uuid)
        Long version = 0
        Date created = new Date()
        Set<User> users = []
        if(existing){
            created = existing.created
            users = existing.users
            version = existing.version
        }
        Organization organization = new Organization(
                uuid: uuid,
                name: inputOrg.name,
                type: inputOrg.type.toUpperCase() as OrganizationType,
                originationId: dataSource,
                created: created,
                updated: new Date(),
                users: users,
                version: version,
                timezone: inputOrg?.metadata?.timezone
        )

        if(inputOrg.parent){
            UUID parentUuid = UUID.fromString(inputOrg.parent.sourcedId)
            Organization parent = organizationRepo.findByUuid(parentUuid)
            organization.parent = parent
        }
        if(!existing){
            if (organization.parent){
                return organizationRepo.createOrgWithParent(organization.uuid,organization.name,organization.type.toString(),organization.originationId,organization.parent.uuid)
            }
            else {
                return organizationRepo.createOrgWithoutParent(organization.uuid,organization.name,organization.type.toString(),organization.originationId)
            }
        }
        return organizationRepo.save(organization)
    }

    String getFilterDate(String datasource){
        Date startedAt = syncRepo.findFirstByStatusAndOriginationIdOrderByStartedAtDesc(SyncStatus.SUCCESS, datasource)?.startedAt
        if(startedAt){
            DateFormat dateFormat = new DateFormat()
            return dateFormat.format(startedAt)
        }
        return ""
    }

    private RestTemplate getRestTemplate(){
        return restTemplateBuilder.setConnectTimeout(connectTimeout).setReadTimeout(readTimeout).build()
    }
}
