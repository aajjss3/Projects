package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.dto.EnrollmentsResponseDTO
import com.glynlyon.kl.classroom.dto.messages.EnrollmentFailureMsg
import com.glynlyon.kl.classroom.dto.messages.EnrollmentSuccessMsg
import com.glynlyon.kl.classroom.exceptions.CustomException
import com.glynlyon.kl.classroom.exceptions.InternalServerErrorException
import com.glynlyon.kl.classroom.exceptions.InvalidRoleException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.service.EnrollmentService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.apache.logging.log4j.Level
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

import javax.validation.ConstraintViolationException

@RestController
class EnrollmentController extends AbstractController{

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    EnrollmentService enrollmentService


    @RequestMapping(path = "/enrollments", method = RequestMethod.POST, produces = Constants.ENROLLMENT_MESSAGES_VERSION_1, consumes = Constants.ENROLLMENT_VERSION_1)
    ResponseEntity<?> createEnrollment(@RequestBody ObjectNode jsonInput, @RequestHeader(name = "authorization") String auth) {
        List<JsonNode> jsonList = jsonInput.get("enrollments").toList()
        return ResponseEntity.ok([successes:[], failures:[]] + jsonList.collect { json ->
            ObjectNode origJson = json.deepCopy()
            def mappingResult = inputMapperService.processInput((ObjectNode)json, Enrollment)
            def input = mappingResult.obj

            if(!input){
                return new EnrollmentFailureMsg(userUuid: null, classUuid: null, errors: ["Failed to process input ${origJson}"])
            }
            input.uuid = null

            try {
                Enrollment enrollment = enrollmentService.create(input, mappingResult, auth.substring(7))
                return new EnrollmentSuccessMsg(userUuid: enrollment.user.uuid, classUuid: enrollment.classObj.uuid, enrollmentUuid: enrollment.uuid)
            }
            catch (Throwable t) {
                List errors = mappingResult.errors
                if (t?.cause?.cause instanceof ConstraintViolationException) {
                    ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                    errors = inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, Enrollment)
                }
                return new EnrollmentFailureMsg(userUuid: origJson.findValue("user_uuid")?.textValue(), classUuid: origJson.findValue("class_uuid")?.textValue(), errors: errors)
            }
        }.groupBy{it.container})
    }

    @RequestMapping(path = "/enrollments", method = RequestMethod.GET, produces = Constants.ENROLLMENT_VERSION_1)
    ResponseEntity<?> getEnrollments(@RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") auth){

        String token = auth.substring(7)
        Page page
        HttpHeaders responseHeaders = null
        try {
            Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_ENROLLMENT_SORT, Enrollment)
            page = enrollmentService.findAllEnrollments(token, filter, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch(UnsupportedFieldException e){
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        PagedResponse.createResponse("enrollments", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)

    }

    @RequestMapping(path = "/enrollments/{uuid}", method = RequestMethod.GET, produces = Constants.ENROLLMENT_VERSION_1)
    ResponseEntity<?> getEnrollment(@PathVariable('uuid') UUID uuid, @RequestHeader(name = "authorization") auth){
        String token = auth.substring(7)
        Enrollment enrollment
        try{
            enrollment = enrollmentService.findEnrollment(token, uuid)
        }
        catch(OrgNotFoundException onfe){
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "sub / school_uuid", message: onfe.message))
        }
        catch(InvalidRoleException ire){
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "role_in_issuer", message: ire.message))
        }
        if(enrollment == null){
            return ResponseEntity.notFound().build()
        }
        return ResponseEntity.ok(enrollment)
    }

    @RequestMapping(path = "/enrollments/{uuid}", method = RequestMethod.PUT, produces = Constants.ENROLLMENT_VERSION_1, consumes = Constants.ENROLLMENT_VERSION_1)
    ResponseEntity<?> updateEnrollment(@PathVariable UUID uuid, @RequestBody ObjectNode jsonInput, @RequestHeader(name = "authorization") String auth) {

        String token = auth.substring(7)
        Enrollment enrollment
        def mappingResult = inputMapperService.processInput(jsonInput, Enrollment)
        def input = mappingResult.obj

        if(!input){
            return ResponseEntity.badRequest().body([errors: [[field: "body", message: "Could not process input ${jsonInput}"]]])
        }

        input.uuid = uuid
        input.updated = new Date()

        try {
            enrollment = enrollmentService.update(input, mappingResult, auth.substring(7))
            return ResponseEntity.ok(enrollment) 
        }
        catch (Throwable t) {
            List errors = mappingResult.errors 
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                errors = inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, Enrollment)
            }
            return ResponseEntity.badRequest().body([errors: errors]) 
        }
    }

    @ExceptionHandler(value = HttpMessageNotReadableException)
    public ResponseEntity jsonError(HttpMessageNotReadableException e){
        def message = e.message
        if(message.contains("Can not deserialize instance of java.util.ArrayList")){
            message = "Expected list of enrollments but got single enrollment"
        }
        return ResponseEntity.badRequest().body([errors: [[field: "body", message: message]]])
    }
	
	/**
	 * Delete enrollments
	 * To delete an enrollment:
	 * 		1)if the enrollments PlannerEntry's status is NOT_STARTED then also delete the PlannerEntry
	 * 		2)if the enrollments PlannerEntry's status is IN_PROGRESS then set its status to OBE
	 * 		3)if any Attempt associated with the enrollment is either IN_PROGRESS or SAVED then set its state to OBE
	 * 		4)delete the enrollment record
	 * 
	 * @param enrollments - Map.Entry<String, List<Map>>. the map entries value is a List<Map>. The maps key is 'enrollment_uuid'. The maps value is the enrollment uuids value as a string. 
	 * @param auth
	 * @return EnrollmentsResponseDTO
	 */
	@DeleteMapping(path="/enrollments", produces = Constants.ENROLLMENT_MESSAGES_VERSION_1, consumes = Constants.ENROLLMENT_PARAMS_VERSION_1)
	@ResponseStatus(HttpStatus.OK)
	public EnrollmentsResponseDTO deleteEnrollments( @RequestBody Map.Entry<String, List<Map<String, String>>> enrollments, @RequestHeader(name = "authorization") String auth ){
		try{
			return enrollmentService.deleteEnrollments( enrollments.getValue(), 
														UUID.fromString(jwtService.getUuid(auth.substring( JWT_STARTING_INDEX ))), 
														jwtService.getOrgUuid(auth.substring( JWT_STARTING_INDEX )), 
														jwtService.getRole(auth.substring( JWT_STARTING_INDEX )))
		}
		catch(CustomException e){
			throw e
		}
		catch(Exception e){
			throw new InternalServerErrorException("Unable to delete enrollments", Level.ERROR, e)
		}
	}
	
}
