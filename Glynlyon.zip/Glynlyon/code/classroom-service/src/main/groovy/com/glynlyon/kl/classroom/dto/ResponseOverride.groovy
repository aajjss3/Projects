package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty

class ResponseOverride {

    @JsonProperty(value = "response_id")
    String responseId

    Boolean credit

    String type

}
