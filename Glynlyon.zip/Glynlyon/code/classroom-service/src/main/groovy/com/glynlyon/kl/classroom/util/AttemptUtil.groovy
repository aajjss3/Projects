package com.glynlyon.kl.classroom.util

import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.dto.grade.OutcomeStatus
import com.glynlyon.kl.classroom.exceptions.InternalServerErrorException
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState

class AttemptUtil {

    public static PageAttemptDTO convertAttemptToPageAttempt(Attempt attempt) {
        return new PageAttemptDTO(
                userUuid: attempt.user.uuid,
                pageAssignmentUuid: attempt.activityId,
                plannerEntryUuid: attempt.plannerEntry.uuid,
                attemptUuid: attempt.uuid,
                state: attempt.state,
                status: attempt.state,
                assessmentScore: attempt.assessmentScore,
                completedAt: attempt.completedAt,
                plannerEntryStatus: attempt.plannerEntry.status
        )
    }

    public static AttemptState convertOutcomeState(OutcomeStatus outcomeStatus){
        try {
            return AttemptState.valueOf(outcomeStatus.name())
        }
        catch(Throwable t) {
            throw new InternalServerErrorException("Unknown outcome state " + outcomeStatus)
        }
    }
}
