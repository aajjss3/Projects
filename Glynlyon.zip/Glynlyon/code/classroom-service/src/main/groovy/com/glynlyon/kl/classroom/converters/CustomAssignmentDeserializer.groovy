package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.DeserializationContext
import com.fasterxml.jackson.databind.deser.std.StdDeserializer
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.repo.AssignmentRepo
import org.springframework.beans.factory.annotation.Autowired

class CustomAssignmentDeserializer extends StdDeserializer<Assignment> {

    @Autowired
    AssignmentRepo assignmentRepo

    protected CustomAssignmentDeserializer() {
        super(Assignment)
    }

    @Override
    Assignment deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        return LocalDeserializerHelper.deserialize(p, ctxt, assignmentRepo, "assignment_uuid", "assignment")
    }
}
