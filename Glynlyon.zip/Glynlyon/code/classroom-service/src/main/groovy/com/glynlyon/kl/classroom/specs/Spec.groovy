package com.glynlyon.kl.classroom.specs

import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.data.jpa.domain.Specification

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Expression
import javax.persistence.criteria.Path
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root
import java.text.DateFormat
import java.text.SimpleDateFormat

public class Spec<T> {

    static Logger logger = LogManager.getLogger(Spec)

    public static Specification<T> spec(String fieldStr, String operator, String valStr, Closure<Predicate> listContains = null) {
        return new Specification<T>() {
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                Expression field
                if(fieldStr.contains(".")) {
                    field = (Expression)fieldStr.split(/\./).inject((Path)root, {Path prev, String cur -> prev.get(cur)})
                }
                else {
                    field = root.get(fieldStr)
                }
                def value = valStr
                if(field.javaType == UUID){
                    value = UUID.fromString(valStr)
                }
                else if(field.javaType == Boolean) {
                    if (valStr.equalsIgnoreCase("true") || valStr.equalsIgnoreCase("false")) {
                        value = Boolean.valueOf(valStr)
                    }
                    else {
                        throw new RuntimeException("${valStr} is not a boolean value")
                    }
                }
                else if(field.javaType == Date) {
                    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd")
                    value = formatter.parse((String)value)
                }
                else {
                    try {
                        value = valStr.asType(field.javaType)
                    }
                    catch(Throwable t){
                        logger.error(t)
                    }
                }
                switch (operator){
                    case "=":
                        return builder.equal(field, value)
                    case "!=":
                        return builder.notEqual(field, value)
                    case "<":
                        return builder.lessThan(field, value)
                    case "<=":
                        return builder.lessThanOrEqualTo(field, value)
                    case ">":
                        return builder.greaterThan(field, value)
                    case ">=":
                        return builder.greaterThanOrEqualTo(field, value)
                    case "contains":
                        if(field.javaType == List){
                            if(listContains) {
                                Predicate listPred = listContains(root, query, builder, field, value)
                                if (listPred) {
                                    return listPred
                                }
                            }
                        }
                        return builder.like(builder.upper(field), "%" + String.valueOf(value).toUpperCase() + "%")
                    default:
                        throw new RuntimeException("Unknown operator " + operator)
                }
            }
        }
    }
}
