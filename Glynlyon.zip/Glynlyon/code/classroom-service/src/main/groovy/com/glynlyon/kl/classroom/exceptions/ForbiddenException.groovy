package com.glynlyon.kl.classroom.exceptions


import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus
import org.apache.logging.log4j.Level


/**
 * Exception to throw when a Http Status FORBIDDEN (403) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
class ForbiddenException extends CustomException{
	
	public ForbiddenException(String message){
		super(message)
	}
	
	public ForbiddenException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public ForbiddenException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
	
}
