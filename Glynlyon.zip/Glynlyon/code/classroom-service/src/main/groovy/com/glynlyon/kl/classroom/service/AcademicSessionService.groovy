package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.BadRequestException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.specs.Spec
import com.glynlyon.kl.classroom.util.BeanCopyHelper
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class AcademicSessionService extends AbstractService {

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    FilterService filterService

    @Autowired
    JwtService jwtService

    @Autowired
    MessagesUtil messagesUtil

    @Autowired
    ClassRepo classRepo

    @Autowired
    ConfigurationService configurationService

    Logger logger = LogManager.getLogger(AcademicSessionService)

    Page<AcademicSession> find(Pageable pageable, String filter, String token) {
        UUID orgUuid = jwtService.getOrgUuid(token)
        
        if(filter) {
           return filterService.find(filter, AcademicSession, academicSessionRepo, pageable, [:], {
               Spec.spec("organizationUuid", "=", orgUuid.toString())
           }, null)
        } else {
            return academicSessionRepo.findByOrganizationUuid(pageable,orgUuid)
        }
    }

    Page<AcademicSession> findByOrganizationUuid(Pageable pageable, UUID organization_uuid) {

        return academicSessionRepo.findByOrganizationUuid(pageable,organization_uuid)
    }

    AcademicSession findOne(UUID academicsession_uuid) {

            return academicSessionRepo.findOne(academicsession_uuid)
    }        
 
    @Transactional
    AcademicSession create(AcademicSession academicSession, InputMapperService.MappingResult<AcademicSession> mappingResult, String token) {

        validate(academicSession, mappingResult, token)

        def returnedAcademicSession = academicSessionRepo.save(academicSession)

        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        return returnedAcademicSession
    }

    @Transactional
    public AcademicSession update(InputMapperService.MappingResult<AcademicSession> mappingResult, UUID uuid, String token) {
        AcademicSession input = mappingResult.obj

        AcademicSession existing = academicSessionRepo.findOne(uuid)
        try {
            adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), existing.organizationUuid, jwtService.getRole(token))
        } catch (e) {
            mappingResult.errors.add("field": "organization", message: e.message)
        }
        input.updated = new Date()
        BeanCopyHelper.copyPropertiesExcludeNulls(input, existing)

        validate(existing, mappingResult, token)

        existing = academicSessionRepo.save(existing)
        if(mappingResult.errors){
            throw new RuntimeException()
        }
        return existing
    }

    @Transactional
    public void delete(UUID uuid, String token){
        AcademicSession existing = academicSessionRepo.findOne(uuid)

        if(!existing){
            throw new NotFoundException("Academic Session ${uuid} does not exist")
        }

        Organization org = organizationRepo.findByUuid(existing.organizationUuid)
        UUID orgUuid = org?.parent?.uuid ?: org.uuid
        adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), orgUuid, jwtService.getRole(token))

        List<ClassObj> classes = classRepo.findAllByAcademicSession(existing)

        Long durationInMilliSeconds = Long.parseLong(configurationService.getConfigurationByKey(Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY).value) * 3600000
        def (List<ClassObj> softDeleted, List<ClassObj> inUse) = classes.split { classObj ->
            return classObj.state == ClassObjState.COMPLETED && (classObj.completed.getTime() + durationInMilliSeconds) <= (new Date()).getTime()
        }
        if(inUse){
            List<String> classNames = inUse.collect{"{${it.uuid}, ${it.name}}"}
            throw new BadRequestException(messagesUtil.get("academicSession.error.inUse", classNames))
        }
        softDeleted.each { classObj ->
            classObj.academicSession = null
        }
        academicSessionRepo.delete(existing.uuid)
    }

    private validate(AcademicSession academicSession, InputMapperService.MappingResult<AcademicSession> mappingResult, String token){
        AppUserType type = jwtService.getRole(token)

        // admin organization validation
        Organization org = organizationRepo.findByUuid(academicSession.organizationUuid)

        if(!org) {
            mappingResult.errors.add("field": "organization_uuid", message: "Organization does not exist.")
        }

        UUID organizationUUID = org?.parent?.uuid ?: org.uuid

        try {
            adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), organizationUUID, type)
        } catch (e) {
            mappingResult.errors.add("field": "organization", message: e.message)
        }
        if (findExisting(academicSession)) {
            mappingResult.errors.add("field": "name", message: messagesUtil.get("academicSession.error.existing"))
        }

        if(academicSession.startDate && academicSession.endDate && academicSession.startDate >= academicSession.endDate) {
            mappingResult.errors.add("field": "start_date", message: messagesUtil.get("academicSession.error.startDateb4endDate"))
        }
    }

    private AcademicSession findExisting(AcademicSession academicSession){
        if(academicSession.uuid){
            return academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuidAndUuidNot(academicSession.name, academicSession.organizationUuid, academicSession.uuid)
        }
        return academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuid(academicSession.name, academicSession.organizationUuid)
    }
}
