package com.glynlyon.kl.classroom.exceptions

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus
import org.apache.logging.log4j.Level


/**
 * Exception to throw when a Http Status INTERNAL_SERVER_ERROR (500) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
class InternalServerErrorException extends CustomException{
	
	public InternalServerErrorException(String message){
		super(message)
	}
	
	public InternalServerErrorException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public InternalServerErrorException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
	
}
