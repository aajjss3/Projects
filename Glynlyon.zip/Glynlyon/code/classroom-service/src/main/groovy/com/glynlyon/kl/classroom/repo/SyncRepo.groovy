package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Sync
import com.glynlyon.kl.classroom.model.SyncStatus
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface SyncRepo extends PagingAndSortingRepository<Sync, UUID>, JpaSpecificationExecutor{

    Sync findFirstByStatusAndOriginationIdOrderByStartedAtDesc(SyncStatus status, String originationId)
}
