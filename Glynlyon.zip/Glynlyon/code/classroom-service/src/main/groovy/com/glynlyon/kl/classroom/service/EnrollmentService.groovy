package com.glynlyon.kl.classroom.service

import java.util.List

import com.glynlyon.kl.classroom.dto.EnrollmentsResponseDTO
import com.glynlyon.kl.classroom.dto.Error
import com.glynlyon.kl.classroom.dto.Failure
import com.glynlyon.kl.classroom.dto.Success
import com.glynlyon.kl.classroom.dto.EnrollmentTimeOnTaskDTO
import com.glynlyon.kl.classroom.exceptions.InvalidRoleException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnauthorizedException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo

import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.stereotype.Service
import org.springframework.transaction.PlatformTransactionManager
import org.springframework.transaction.TransactionDefinition
import org.springframework.transaction.TransactionStatus
import org.springframework.transaction.annotation.Isolation
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional
import org.springframework.transaction.support.TransactionCallback
import org.springframework.transaction.support.TransactionTemplate

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root

import static com.glynlyon.kl.classroom.specs.Spec.spec
import static org.springframework.data.jpa.domain.Specifications.where

@Service
class EnrollmentService {

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    PlatformTransactionManager txManager

    @Autowired
    ClassRepo classRepo

    @Autowired
    JwtService jwtService

    @Autowired
    OrganizationRepo organizationRepo
	
	@Autowired
	AttemptRepo attemptRepo
	
	@Autowired
	PlannerEntryRepo plannerEntryRepo

    @Autowired
    FilterService filterService
		
	Logger logger = LogManager.getLogger(this.class)

    @Transactional
    public Enrollment create(final Enrollment input, InputMapperService.MappingResult<Enrollment> mappingResult, final String jwt){

        /**
         * Transaction code below is a workaround for issues with the ConstraintValidator.
         * After a save with a ConstraintValidator violation, subsequent calls to save via the loop
         * in the EnrollmentController would end up continuing to pass the same invalid instance of
         * Enrollment to isValid() despite trying to save a different instance. Hours of troubleshooting
         * got me nowhere and this was the best I could do to make it actually function
         */
        TransactionTemplate txTemplate = new TransactionTemplate(txManager)
        txTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW)
        txTemplate.execute(new TransactionCallback<Enrollment>() {
            public Enrollment doInTransaction(TransactionStatus status) {
                if(!input.uuid && input.classObj?.uuid) {
                    if(AppUserType.TEACHER.equals(jwtService.getRole(jwt))){
                        UUID actingUserUuid = UUID.fromString(jwtService.getUuid(jwt))
                        Integer teacherEnrolled = enrollmentRepo.countByUserUuidAndClassObjUuid(actingUserUuid, input.classObj.uuid)
                        if(!teacherEnrolled){
                            mappingResult.errors.add([field: "user_uuid", message: "teachers cannot make enrollments for classes into which they are not enrolled"])
                        }
                    }

                    Integer num = enrollmentRepo.countByUserUuidAndClassObjUuid(input.user?.uuid, input.classObj.uuid)
                    if (num) {
                        mappingResult.errors.add([field: "user_uuid", message: "cannot enroll user multiple times into the same class"])
                    }
                }
                Enrollment enrollment = enrollmentRepo.save(input)
                if(mappingResult.errors){
                    throw new RuntimeException()
                }
                return enrollment
            }
        });
    }

    @Transactional
    public Enrollment update(final Enrollment input, InputMapperService.MappingResult<Enrollment> mappingResult, final String jwt){
        Enrollment existingEnrollment = findEnrollment(jwt, input.uuid)
        if (!existingEnrollment) {
            mappingResult.errors.add(["field": "uuid", message: "Invalid enrollment uuid " + input.uuid + "."])
        } else {
            input.created = existingEnrollment.created
            input.version = existingEnrollment.version
            if (input.primaryRole == null)  {
                input.primaryRole = existingEnrollment.primaryRole
            }
        }
        if(input.classObj?.uuid) {
            if(AppUserType.TEACHER.equals(jwtService.getRole(jwt))){
                UUID actingUserUuid = UUID.fromString(jwtService.getUuid(jwt))
                Integer teacherEnrolled = enrollmentRepo.countByUserUuidAndClassObjUuid(actingUserUuid, input.classObj.uuid)
                if(!teacherEnrolled){
                    mappingResult.errors.add([field: "user_uuid", message: "teachers cannot update enrollments for classes into which they are not enrolled"])
                }
            }
            Integer num = enrollmentRepo.countByUserUuidAndClassObjUuid(input.user?.uuid, input.classObj.uuid)
            if (!num) {
                mappingResult.errors.add([field: "user_uuid", message: "User not yet enrolled in this class.  Not able to update enrollment."])
            }
        }
        Enrollment enrollment = enrollmentRepo.save(input)
        if(mappingResult.errors){
            throw new RuntimeException()
        }
        return enrollment
    }

    private Specification<Enrollment> userOrgSpec(String token){
        AppUserType role = jwtService.getRole(token)
        UUID userUuid = UUID.fromString(jwtService.getUuid(token))
        UUID orgUuid = jwtService.getOrgUuid(token)
        Organization org = organizationRepo.findByUuid(orgUuid)

        if(!org){
            throw new OrgNotFoundException("no organizations found for user ${userUuid} in school ${orgUuid}");
        }

        if (role == AppUserType.ADMIN) {
            return new Specification<Enrollment>() {
                Predicate toPredicate(Root<Enrollment> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    return builder.or(builder.equal(root.get("classObj").get("organization").get('parent').get('uuid'), org.uuid),
                            builder.equal(root.get("classObj").get("organization").get('uuid'), org.uuid))
                }
            }
        }
        else if(role == AppUserType.TEACHER) {
            return new Specification<Enrollment>() {
                public Predicate toPredicate(Root<Enrollment> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    List campuses = organizationRepo.findAllByUsersUuidAndType(userUuid,OrganizationType.CAMPUS)*.uuid
                    return root.get("classObj").get("organization").get("uuid").in(campuses)
                }
            }
        }
        else {
            throw new InvalidRoleException("Only supported roles are ADMIN and TEACHER")
        }
    }

    public Enrollment findEnrollment(String token, UUID enrollmentUuid) {
        return enrollmentRepo.findOne((Specification)where(spec("uuid", "=", enrollmentUuid.toString()))
                                                     .and((Specification)userOrgSpec(token)))
    }

    public Page<?> findAllEnrollments(String token, String filter, Pageable pageable){
        String studentUuid = null
        Boolean studentRequest = jwtService.getRole(token) == AppUserType.STUDENT
        Specification userBelongsToEnrolledOrgSpec
        if (studentRequest) {
            studentUuid = jwtService.getUuid(token)
        }
        else {
            try {
                userBelongsToEnrolledOrgSpec = userOrgSpec(token)
            }
            catch(OrgNotFoundException onfe){
                return new PageImpl([new ErrorOutput(field: "sub / school_uuid", message: onfe.message)], pageable, 1)
            }
            catch(InvalidRoleException ire){
                return new PageImpl([new ErrorOutput(field: "role_in_issuer", message: ire.message)], pageable, 1)
            }
        }

		// page object can contain a collection of Enrollment and/or ErrorOutput objects
		Page<?> page
		
        if(filter) {
            page = filterService.find(filter, Enrollment, enrollmentRepo, pageable, [:], {
                if(studentUuid) {
                    return spec("user.uuid", "=", studentUuid)
                }
                return userBelongsToEnrolledOrgSpec
            }, null)
        }
		else{
	        if(studentRequest){
	            page = enrollmentRepo.findAllByUserUuid(UUID.fromString(studentUuid), pageable)
	        }
			else{
				page =  enrollmentRepo.findAll(where(userBelongsToEnrolledOrgSpec),pageable)
			}	
		}
		
		// get the total time on task for all attempts associated each enrollment and set it on enrollment.timeOnTaskSeconds
		// create a list of only Enrollment objects to pass into the query (page.content contains a list of Enrollments and/or a list of ErrorOutput). 
		if( page && page.content ){
			List<Enrollment> enrollments = page.content.findAll{ it instanceof Enrollment }
			if( enrollments && !enrollments.isEmpty() ){
				List<EnrollmentTimeOnTaskDTO> dtos = enrollmentRepo.getTotalTimeOnTask(enrollments)
				for( Enrollment enrollment : enrollments ){
					int index = dtos.findIndexOf { it.enrollmentUUID == enrollment.uuid }
					enrollment.timeOnTaskSeconds = ( index >= 0 ) ? dtos.get(index).time : 0
				}
			}	
		}
		
		return page
		
    }
	
	
	/**
	 * Delete a collection of enrollments. 
	 * Only a Teacher or Admin that is assigned to a class or organization that matches the enrollment's class or organization has rights to delete an enrollment. 
	 * All other roles do not have rights to delete an enrollment. 
	 * Return a collection of enrollment uuid's that were both successfully and unsuccessfully deleted (if an enrollment could not be deleted then also include a message indicating why) 
	 * To delete an enrollment:
	 * 		1)if the enrollments PlannerEntry's status is NOT_STARTED then also delete the PlannerEntry
	 * 		2)if the enrollments PlannerEntry's status is IN_PROGRESS then set its status to OBE
	 * 		3)if any Attempt associated with the enrollment is either IN_PROGRESS or SAVED then set its state to OBE
	 * 		4)delete the enrollment record
	 * 
	 * @param enrollments - List<Map>. A List of single entry maps. the map's key is the string 'enrollment_uuid'. the map's value is the value for the enrollment uuid as a string.
	 * @param userUuid - UUID
	 * @param orgUuid - UUID
	 * @param role - AppUserType
	 * @return EnrollmentsResponseDTO
	 */
    //Please dont put @transactional here. The method that deletes (processDelete) has @Transactional
	public EnrollmentsResponseDTO deleteEnrollments(List<Map<String, String>> enrollmentUuids, UUID userUuid, UUID orgUuid, AppUserType role){
		
		// only teachers or admins have the right to delete an enrollment
		if(role != AppUserType.TEACHER && role != AppUserType.ADMIN){
			throw new UnauthorizedException("Only a teacher or admin can drop an enrollment.")
		}
		
		// initialize response DTO
		EnrollmentsResponseDTO response = new EnrollmentsResponseDTO()
		List<Success> successes = new ArrayList<Success>()
		List<Failure> failures = new ArrayList<Failure>()
		response.successes = successes
		response.failures = failures
				
		// if a teacher - get the list of classes this teacher is assigned to
		List<String> teacherAssignedClasses
		if( role == AppUserType.TEACHER){
			teacherAssignedClasses = new ArrayList<String>()
			List<Enrollment> teacherEnrollments = enrollmentRepo.findAllByUserUuidAndRole (userUuid, Role.TEACHER )
			for( Enrollment teacherEnrollment : teacherEnrollments ){
				teacherAssignedClasses.add( teacherEnrollment.getClassObj().uuid.toString() )
			}
			if( !teacherAssignedClasses ){
				throw new UnauthorizedException("Your role is teacher but you do not have any classes assigned to you so you can not drop any enrollments.")
			}
		}
		
		// loop thru the collection of enrollments
		for(Map<String, String> enrollmentUuid : enrollmentUuids){
			
			UUID enrollmentUUID
			try{
				enrollmentUUID = UUID.fromString( enrollmentUuid.get("enrollment_uuid") )
			}
			catch(Exception ie){
				populateFailure( "unable to construct a UUID from the enrollment_uuid", "enrollment_uuid", enrollmentUuid.get("enrollment_uuid"), failures )
			}
		
			if( enrollmentUUID ){
				
				Enrollment enrollment = enrollmentRepo.findOne(enrollmentUUID)
				if( !enrollment ){
					populateFailure( "unable to find an enrollment record", "enrollment_uuid", enrollmentUuid.get("enrollment_uuid"), failures )
				}
				else{
					
					// determine if the user has the correct priviledges to delete this enrollment
					String failureMessage 
					if( role == AppUserType.ADMIN ){
						if( !( enrollment.classObj.organization.parent.uuid).toString().equals( orgUuid.toString() ) ){
							failureMessage = "The admin is not authorized to drop this enrollment"
						}
					} 
					else if( role == AppUserType.TEACHER )  {
						if( !teacherAssignedClasses.contains(enrollment.getClassObj().uuid.toString()) ){
							failureMessage = "The teacher is not authorized to drop this enrollment"
						}
					}
					
					// if the user does not have rights to delete this enrollment
					if( failureMessage ){
						logger.info( failureMessage + ". The users user_uuid is:  " + userUuid.toString() + ", and the enrollment_uuid is: " +  enrollmentUuid.get("enrollment_uuid") )
						populateFailure( failureMessage, enrollmentUuid.get("enrollment_uuid"), failures )
					}
					// if the use does have rights then update plannerentry.state and attempt.state and delete the enrollment
					else{
						try{
                            String enrollmentUserUuid = enrollment.user.uuid.toString()
                            processDelete(enrollment)
							populateSuccess(enrollmentUuid.get("enrollment_uuid"), enrollmentUserUuid, successes)
						}
						catch(Exception e){
							logger.error( "Unable to drop an enrollment record with a enrollment_uuid: " + enrollmentUuid.get("enrollment_uuid"), e )
							populateFailure( "Unable to drop the enrollment record. The reason is: " + e.getMessage(), enrollmentUuid.get("enrollment_uuid"), failures )
						}
					}
				
				}
			}	
			
		}
		
		return response
		
	}
	
	
	@Transactional( propagation = Propagation.REQUIRES_NEW, isolation=Isolation.REPEATABLE_READ )
	public void processDelete( Enrollment enrollment ) throws Exception{
        List<PlannerEntry> plannerEntries = plannerEntryRepo.findAllByUserUuidAndClassObjUuid( enrollment.user.uuid, enrollment.classObj.uuid )
		for( PlannerEntry plannerEntry : plannerEntries ){
			if( plannerEntry.status == PlannerEntryState.NOT_STARTED ){
				plannerEntryRepo.delete(plannerEntry.uuid)
			}
			else if( plannerEntry.status in [PlannerEntryState.IN_PROGRESS, PlannerEntryState.REASSIGNED_IN_PROGRESS]){
				plannerEntry.status = PlannerEntryState.OBE
				plannerEntry.slot = -1
			}
			if( plannerEntry.status != PlannerEntryState.NOT_STARTED ){
				List<Attempt> attempts = plannerEntry.attempts
				for(Attempt attempt : attempts){
					if( attempt.state == AttemptState.IN_PROGRESS || attempt.state == AttemptState.SAVED ){
						attempt.state = AttemptState.OBE
					}
				}
			}	
		}
		enrollmentRepo.delete(enrollment.uuid)
	}
	
	
	private void populateFailure( String message, String enrollmentUUID, List<Failure> failures ){
		populateFailure(message, null, enrollmentUUID, failures)
	}
	
	private void populateFailure( String message, String field, String enrollmentUUID, List<Failure> failures ){
		Failure failure = new Failure()
		failure.enrollmentUUID = enrollmentUUID
		Error error = new Error()
		error.message = message
		error.field = field
		failure.errors = Collections.singletonList(error)
		failures.add(failure)
	}
	
	private void populateSuccess( String enrollmentUUID, String userUuid, List<Success> successes ){
		successes.add(new Success(
                userUuid: userUuid,
                enrollmentUUID: enrollmentUUID
        ))
	}
	
}
