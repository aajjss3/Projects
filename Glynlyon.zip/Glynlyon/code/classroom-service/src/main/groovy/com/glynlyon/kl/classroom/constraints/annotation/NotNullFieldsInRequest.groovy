package com.glynlyon.kl.classroom.constraints.annotation

import java.lang.annotation.Documented
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import javax.validation.Constraint
import javax.validation.Payload
import com.glynlyon.kl.classroom.constraints.validator.NotNullFieldsInRequestValidator


@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = NotNullFieldsInRequestValidator.class)
@Documented
@Inherited
public @interface  NotNullFieldsInRequest {
	String[] fields()
	String message() default "field cannot be null"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
