package com.glynlyon.kl.classroom.exceptions

class LearnocityClientException extends RuntimeException {
    private String field
    private String message

    LearnocityClientException() {
        super()
    }

    LearnocityClientException(String message) {
        super(message)
    }

    LearnocityClientException(String message, Throwable cause) {
        super(message, cause)
    }

    LearnocityClientException(Throwable cause) {
        super(cause)
    }

    protected LearnocityClientException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }

    public String getField(){
        return field
    }

    public LearnocityClientException(String field, String message) {
        super(message)
        this.message = message
    }
}
