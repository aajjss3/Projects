package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.constraints.annotation.TeacherAdminRole
import com.glynlyon.kl.classroom.constraints.group.PagePatch
import com.glynlyon.kl.classroom.dto.PageDTO
import com.glynlyon.kl.classroom.dto.Status
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.pagination.OffsetBasedPageRequest
import com.glynlyon.kl.classroom.service.AttemptService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder

import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PatchMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

@RestController
@Validated
class PageController extends AbstractController {

    @Autowired
    PageService pageService

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    PageableService pageableService

    @Autowired
    JwtService jwtService

    @Autowired
    AttemptService attemptService

    Logger logger = LogManager.getLogger(PageController)

    @RequestMapping(path = "/pages", method = RequestMethod.GET, produces = Constants.PAGES_VERSION_1)
    ResponseEntity<?> getPages(@RequestParam(name = "limit", required = false) Integer limit,
                                 @RequestParam(name = "offset", required = false) Integer offset,
                                 @RequestParam(name = "orderBy", required = false) String orderBy,
                                 @RequestParam(name = "sort", required = false) String sort,
                                 @RequestParam(name = "filter", required = false) String filter,
                                 @RequestParam(name = "class_uuid", required = false) String classUuid,
                                 @RequestHeader(name = "authorization") String auth){


        Page page
        HttpHeaders responseHeaders = null
        String token = auth.substring(JWT_STARTING_INDEX)

        try {
            Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_PAGE_SORT, PageObj, ["page_assignments"])
            page = pageService.findAllPages(token, classUuid, filter, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch(UnsupportedFieldException e){
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        catch(OrgNotFoundException onfe){
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "school_uuid", message: onfe.message))
        }
        PagedResponse.createResponse("pages", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }

    @PostMapping(path = "/pages", produces = Constants.PAGES_VERSION_1, consumes = Constants.PAGES_VERSION_1)
    ResponseEntity<?> createPage(@RequestBody ObjectNode json, HttpServletRequest req,
                                  @RequestHeader(name = "authorization") String auth) {

        def mappingResult = inputMapperService.processInput(json, PageObj)
        PageObj input = mappingResult.obj
        if (input == null) {
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        input.type = 'CONCEPT'
        input.createdAt = new Date()
        input.updatedAt = new Date()
        input.uuid = null

        try {
            PageObj pageObj = pageService.create(input, mappingResult)
            String serverRoot = req.getScheme() + "://" + req.getHeader("Host")
            return ResponseEntity.created(new URI(serverRoot + "/pages/" + pageObj.uuid)).body(pageObj)
        } catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PageObj)])
            }
            if(t instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PageObj)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @PutMapping(path = "/pages/{uuid}", produces = Constants.PAGES_VERSION_1, consumes = Constants.PAGES_VERSION_1)
    ResponseEntity<?> updatePage(@PathVariable('uuid') UUID pageUuid, @RequestBody ObjectNode json, @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)

        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, true)
        if(!validationResult.valid){
            return ResponseEntity.badRequest().body([errors: [new ErrorOutput(field: "sub / school_uuid", message: validationResult.message)]])
        }
        PageObj existing = validationResult.obj

        def mappingResult = inputMapperService.processInput(json, PageObj)
        PageObj input = mappingResult.obj
        if (input == null) {
            return ResponseEntity.badRequest().body("Couldn't process input")
        }

        try {
            PageObj pageObj = pageService.update(input, existing, mappingResult)
            return ResponseEntity.ok(pageObj)
        } catch (Throwable t) {
            if (t?.cause?.cause instanceof ConstraintViolationException) {
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t.cause.cause
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PageObj)])
            }
            if(t instanceof ConstraintViolationException){
                ConstraintViolationException constraintViolationException = (ConstraintViolationException) t
                return ResponseEntity.badRequest().body([errors: inputMapperService.mergeErrors(mappingResult.errors, constraintViolationException.constraintViolations, PageObj)])
            }
            return ResponseEntity.badRequest().body([errors: mappingResult.errors])
        }
    }

    @PatchMapping(path = "/classes/{uuid}/pages", consumes = Constants.PAGES_VERSION_1)
    ResponseEntity<?> updatePagesByClass(@PathVariable('uuid') UUID classUuid, @RequestBody Status status, @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        pageService.updateAll(classUuid, status, token)
        return ResponseEntity.noContent().build()
    }

    @GetMapping(path = "/pages/{page_uuid}/attempts", produces = Constants.PAGE_ATTEMPTS_VERSION_1)
    ResponseEntity<?> getAttemptsByPage(@RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestParam(name = "latest_attempt", required = false) Boolean latest,
            @RequestParam(name = "include_obe", required = false) Boolean includeOBE,
            @RequestHeader(name = "authorization") String auth,
            @PathVariable("page_uuid") UUID pageUuid){

        Page page
        HttpHeaders responseHeaders = null
        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, false)
        if(!validationResult.valid){
            return new ResponseEntity([errors: [new ErrorOutput(field: "sub / school_uuid", message: validationResult.message)]], validationResult.httpStatus)
        }

        try {
            OffsetBasedPageRequest pageable = pageableService.createPageable(limit, offset, null, null, Constants.DEFAULT_PAGE_ATTEMPTS_SORT, Attempt)
            filter = filter?.replaceAll("status","state")
            page = attemptService.findByPageUuid(pageUuid, filter, latest, includeOBE, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch (UnsupportedFieldException e) {
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        catch (OrgNotFoundException onfe) {
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "sub / school_uuid", message: onfe.message))
        }
        PagedResponse.createResponse("attempts", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }
	
	@PatchMapping(value="pages/{uuid}", produces= Constants.PAGES_VERSION_1, consumes = Constants.PAGES_VERSION_1)
	@ResponseStatus(HttpStatus.OK)
	public PageDTO patchPage(	@PathVariable('uuid') UUID pageUUID, 
								@Validated(value=[PagePatch.class]) @RequestBody PageDTO pageDTO, 
								@TeacherAdminRole(message="{input.role.notallowed.teacheradmin}") @RequestHeader(name = "authorization") String auth){
		return pageService.patchPage( pageUUID, pageDTO, token(auth))
	}
}
