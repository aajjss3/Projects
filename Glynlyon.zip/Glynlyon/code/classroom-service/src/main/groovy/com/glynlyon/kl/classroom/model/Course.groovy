package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.constraints.DateOrder
import com.glynlyon.kl.classroom.constraints.ValidOrg
import com.glynlyon.kl.classroom.constraints.ValidUser
import com.glynlyon.kl.classroom.converters.*
import org.hibernate.validator.constraints.NotEmpty

import java.util.UUID

import javax.persistence.*
import javax.validation.constraints.NotNull

@Entity
class Course  extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @Column(name = "course_uuid", nullable = false)
    @JsonProperty(value = "course_uuid")
    UUID uuid
	
	@JsonIgnore
	@Column(name = "created_at")
	Date createdAt

	@JsonIgnore
	@Column(name = "updated_at")
	Date updatedAt
	
    Course() {}

}
