package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.DisabledSubject
import com.glynlyon.kl.classroom.repo.DisabledSubjectRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class DisabledSubjectService {

    @Autowired
    DisabledSubjectRepo disabledSubjectRepository

    @Transactional
    DisabledSubject save(DisabledSubject subject) {
        disabledSubjectRepository.save(subject)
    }
}
