package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.model.Launch
import com.glynlyon.kl.classroom.repo.LaunchRepo
import com.glynlyon.kl.classroom.service.LaunchesService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController

import javax.servlet.http.HttpServletResponse

@RestController
class LaunchesController {

    @Autowired
    LaunchRepo launchRepo

    @Autowired
    LaunchesService launchService

    @RequestMapping(path = "/launches/{uuid}", method = RequestMethod.GET)
    ResponseEntity markToken(@PathVariable('uuid') UUID uuid) {
        def token = launchService.findByUuid(uuid)

        if(token) {
            if (!token.launched) {
                token.launched = true
                token.date_launched = new Date()
                launchService.save(token)

                return new ResponseEntity([jwt: token.jwt], HttpStatus.OK)
            } else {
                return new ResponseEntity(HttpStatus.GONE)
            }
        } else {
            return new ResponseEntity(HttpStatus.NOT_FOUND)
        }
    }

    @RequestMapping(path = "/launches", method = RequestMethod.POST)
    def create(@RequestHeader(name = "Authorization", required = true) authHeader, HttpServletResponse response, @Value('${classroomUi.baseUri}') String classroomBaseUri){
        String jwt = authHeader.substring(7)
        Launch launch = new Launch(jwt)
        launchRepo.save(launch)

        String classroomUri = classroomBaseUri + "/#/launches/" + launch.uuid

        response.setHeader("Location", classroomUri)
        response.setStatus(HttpServletResponse.SC_FOUND)
    }
}
