package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

import org.hibernate.annotations.Type

import java.util.UUID

import javax.persistence.*

@Entity
@ToString
@EqualsAndHashCode
class Lock implements Serializable, GroovyObject {
	
	@JsonIgnore
	@Version
	public long version

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "lock_uuid", nullable = false)
    @JsonProperty(value = "lock_uuid")
    UUID uuid

    @JoinColumn(name="locked_by", referencedColumnName="app_user_uuid")
    @ManyToOne(fetch=FetchType.LAZY)
    @JsonProperty(value = "locked_by")
    User lockedByUser

    @Column(name = "locked_at", nullable = false)
    @JsonIgnore
    Date lockedAt

    @Column(name = "resource_type", nullable = true)
    @JsonProperty(value = "resource_type")
    @Type(type = 'enum', parameters = [
            @org.hibernate.annotations.Parameter(name = 'enumClassName', value = 'com.glynlyon.kl.classroom.model.ResourceType')
    ])
    ResourceType resourceType

    @Column(name = "resource_uuid", nullable = false)
    @JsonProperty(value = "resource_uuid")
    UUID resourceUuid

    Lock() {}


}
