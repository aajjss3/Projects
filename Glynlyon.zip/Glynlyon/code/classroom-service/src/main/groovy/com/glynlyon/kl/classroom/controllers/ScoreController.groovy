package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.service.ClassService
import com.glynlyon.kl.classroom.service.PageService
import com.glynlyon.kl.classroom.service.ScoreService
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestParam

@Controller
class ScoreController extends AbstractController {

    @Autowired
    PageService pageService

    @Autowired
    ClassService classService

    @Autowired
    ScoreService scoreService

    @GetMapping(path = "/pages/{page_uuid}/assignments/scores", produces = Constants.PAGES_ASSIGNMENTS_SCORES_VERSION_1)
    ResponseEntity<?> getAssignmentScoresByPage(@RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") String auth,
            @RequestHeader(name = "x-client-domain") String domain,
            @PathVariable("page_uuid") UUID pageUuid){

        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, true)
        if(!validationResult.valid){
            return new ResponseEntity([errors: [new ErrorOutput(field: "sub / school_uuid", message: validationResult.message)]], validationResult.httpStatus)
        }
        return ResponseEntity.ok(scoreService.getAssignmentScores(validationResult.obj, filter, domain))
    }

    @GetMapping(path = "/pages/{page_uuid}/students/scores", produces = Constants.STUDENTS_SCORES_VERSION_1)
    ResponseEntity<?> getStudentScoresByPage(@RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") String auth,
            @RequestHeader(name = "x-client-domain") String domain,
            @PathVariable("page_uuid") UUID pageUuid) {

        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, true)
        if (!validationResult.valid) {
            return new ResponseEntity([errors: [new ErrorOutput(field: "sub / school_uuid", message: validationResult.message)]], validationResult.httpStatus)
        }
        return ResponseEntity.ok(scoreService.getStudentScoresByPage(validationResult.obj, filter, domain))
    }

    @GetMapping(path = "/classes/{class_uuid}/students/scores", produces = Constants.STUDENTS_SCORES_VERSION_1)
    ResponseEntity<?> getStudentScoresByClass(@RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") String auth,
            @RequestHeader(name = "x-client-domain") String domain,
            @PathVariable("class_uuid") UUID classUuid) {

        String token = auth.substring(JWT_STARTING_INDEX)
        ClassObj classObj = classService.validateClass(classUuid, token)
        return ResponseEntity.ok(scoreService.getStudentScoresByClass(classObj, filter, domain))
    }
}
