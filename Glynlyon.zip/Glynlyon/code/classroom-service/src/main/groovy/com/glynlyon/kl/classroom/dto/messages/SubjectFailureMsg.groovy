package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.model.ErrorOutput

class SubjectFailureMsg extends SubjectMessage {

    @Override
    String getContainer() {
        return "failures"
    }

    @JsonProperty(value = "subject_uuid")
    String subjectUuid

    List<ErrorOutput> errors
}
