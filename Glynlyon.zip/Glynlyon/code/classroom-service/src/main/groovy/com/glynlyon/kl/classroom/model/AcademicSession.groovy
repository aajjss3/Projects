package com.glynlyon.kl.classroom.model

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.validation.constraints.NotNull

import com.glynlyon.kl.classroom.constraints.ValidOrg

@Entity
class AcademicSession extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "academic_session_uuid", nullable = false)
    @JsonProperty(value = "academic_session_uuid", access = JsonProperty.Access.READ_ONLY)  
    UUID uuid
    
    @JsonProperty(value = "name")
    @NotNull(message = "Missing required field name")
    @Column(name = "name", nullable = false)
    String name
    
    @JsonProperty(value = "organization_uuid")
    @Column(name = "organization_uuid")
    @NotNull(message = "Missing required field organization_uuid")
    @ValidOrg(message = "Could not find organization with uuid \${validatedValue}")
    UUID organizationUuid
    
    @Column(name = "type", nullable = false)
    @NotNull(message = "Missing required field type")
    @Enumerated(EnumType.STRING)
    AcademicSessionType type

    @Column(name = "start_date", nullable = false)
    @NotNull(message = "Missing required field start_date")
    @JsonProperty(value = "start_date")
    Date startDate

    @Column(name = "end_date", nullable = false)
    @NotNull(message = "Missing required field end_date")
    @JsonProperty(value = "end_date")
    Date endDate

    @Column(name = "parent_uuid", nullable = true)
    @JsonProperty(value = "parent_uuid")
    UUID parentUuid

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date created

    @Column(name = "updated_at", nullable = false)
    @JsonIgnore
    Date updated
	
    AcademicSession() {

    }
}
