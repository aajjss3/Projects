package com.glynlyon.kl.classroom.controllers


import javax.servlet.http.HttpServletRequest 
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.util.MessagesUtil
import com.glynlyon.kl.classroom.util.Token
import org.springframework.context.MessageSource
import org.springframework.context.i18n.LocaleContextHolder


abstract class AbstractController {

	@Autowired 
	HttpServletRequest request;
	
	@Autowired
	JwtService jwtService
	
	@Autowired
	PageableService pageableService
	
	@Autowired
	MessagesUtil messages
	
	@Autowired
	protected MessageSource message
	
	protected Locale locale = LocaleContextHolder.getLocale()
	
	Logger logger = LogManager.getLogger(this.class)
	
	protected static final int JWT_STARTING_INDEX = 7
	
	
	/**
	 * Create the ResponseEntity to return. This response contains a body and a header with a location
	 *
	 * @param obj - HTTP Body
	 * @param location - HTTP Header location
	 * @return ResponseEntity
	 */
	protected ResponseEntity createResponse(HttpStatus status, Object obj, String location ){
		HttpHeaders headers = new HttpHeaders()
		StringBuffer url = request.getRequestURL()
		headers.add("Location", url.substring(0, url.length() - request.getRequestURI().length() + request.getContextPath().length()) + location)
		return new ResponseEntity(obj, headers, status)
	}
	
	/**
	 * Create the ResponseEntity to return. This response contains a body only, no header.
	 *
	 * @param obj - HTTP Body
	 * @return ResponseEntity
	 */
	protected ResponseEntity createResponse( Object obj ){
		return new ResponseEntity(obj, HttpStatus.OK)
	}
	
	
	/**
	 * Parse the token in the header and store the fields (role, organizationUUID, userUUID) in a Token object
	 * @param auth
	 * @return Token
	 */
	protected Token token(String auth){
		UUID userUUID = UUID.fromString(jwtService.getUuid( auth.substring(JWT_STARTING_INDEX) ))
		UUID orgUUID = jwtService.getOrgUuid( auth.substring(JWT_STARTING_INDEX) )
		AppUserType role = jwtService.getRole( auth.substring(JWT_STARTING_INDEX) )
		return new Token(userUUID: userUUID, schoolUUID: orgUUID, role: role)
	}
	

}
