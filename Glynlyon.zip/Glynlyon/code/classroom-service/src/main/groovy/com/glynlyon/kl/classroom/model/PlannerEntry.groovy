package com.glynlyon.kl.classroom.model

import java.util.UUID

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.EnumType
import javax.persistence.Enumerated
import javax.persistence.FetchType
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.JoinColumn
import javax.persistence.ManyToOne
import javax.persistence.OneToMany
import javax.validation.constraints.NotNull

import org.hibernate.annotations.DynamicInsert

import com.fasterxml.jackson.annotation.JsonIdentityInfo
import com.fasterxml.jackson.annotation.JsonIdentityReference
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.ObjectIdGenerators
import com.fasterxml.jackson.databind.annotation.JsonDeserialize
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.glynlyon.kl.classroom.converters.AttemptSerializer
import com.glynlyon.kl.classroom.converters.CustomAssignmentDeserializer
import com.glynlyon.kl.classroom.converters.CustomClassObjDeserializer
import com.glynlyon.kl.classroom.converters.CustomClassObjSerializer
import com.glynlyon.kl.classroom.converters.CustomPageObjDeserializer
import com.glynlyon.kl.classroom.converters.CustomUserDeserializer
import com.glynlyon.kl.classroom.converters.CustomUserPlannerEntrySerializer
import com.glynlyon.kl.classroom.converters.PlannerPageSerializer

@Entity
@DynamicInsert
class PlannerEntry extends BaseEntity implements GroovyObject, Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "planner_entry_uuid", nullable = false)
    @JsonProperty(value = "planner_entry_uuid")
    UUID uuid

    @JsonProperty(value = "user_uuid")
    @JoinColumn(name = "user_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field user_uuid")
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "uuid")
    @JsonIdentityReference(alwaysAsId = true)
    @JsonDeserialize(using = CustomUserDeserializer)
    @JsonSerialize(using = CustomUserPlannerEntrySerializer)
    User user

    @JoinColumn(name = "page_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field page_uuid")
    @JsonIgnore
    PageObj pageObj

    @JsonProperty(value = "page_uuid")
    @JsonDeserialize(using = CustomPageObjDeserializer)
    PageObj setPageObj(PageObj pageObj) {
        this.pageObj = pageObj
    }

    @JsonProperty(value = "page")
    @JsonSerialize(using = PlannerPageSerializer)
    PageObj getPageObj() {
        return pageObj
    }

    @JsonProperty(value = "class_uuid")
    @JoinColumn(name = "class_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    @NotNull(message = "Missing required field class_uuid")
    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "uuid")
    @JsonIdentityReference(alwaysAsId = true)
    @JsonDeserialize(using = CustomClassObjDeserializer)
    @JsonSerialize(using = CustomClassObjSerializer)
    ClassObj classObj


    @NotNull(message = "Missing required field assignment_uuid")
    @JoinColumn(name = "assignment_uuid", nullable = false)
    @ManyToOne(fetch=FetchType.LAZY)
    Assignment assignment

    @JsonProperty(value = "assignment")
    Assignment getAssignment(){
        return assignment
    }

    @JsonProperty(value = "assignment_uuid")
    @JsonDeserialize(using = CustomAssignmentDeserializer)
    void setAssignment(Assignment assignment){
        this.assignment = assignment
    }

    @Column(name = "activity_id", nullable = true)
    @JsonProperty(value = "activity_id")
    UUID activityId

    @Column(name = 'status', nullable = false)
    @NotNull(message = "Missing required field status")
    @Enumerated(EnumType.STRING)
    PlannerEntryState status

    @JsonProperty(value = "slot")
    @Column(name = "slot", nullable = false)
    @NotNull(message = "Missing required field slot")
    Integer slot

    @OneToMany(mappedBy = "plannerEntry")
    @JsonSerialize(using = AttemptSerializer)
    List<Attempt> attempts

    @Column(name = "created_at", nullable = false)
    @JsonIgnore
    Date created

    @JsonIgnore
    @Column(name = "updated_at", nullable = false)
    Date updated

    PlannerEntry() {}

}
