package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty

class ResponseOverridesDTO extends BaseDTO{

    @JsonProperty(value = "response_overrides")
    List<ResponseOverride> responseOverrides
}
