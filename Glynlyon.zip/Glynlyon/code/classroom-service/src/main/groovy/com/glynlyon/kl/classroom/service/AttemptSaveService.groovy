package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.AttemptSave
import com.glynlyon.kl.classroom.repo.AttemptSaveRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class AttemptSaveService {

    @Autowired
    AttemptSaveRepo attemptSaveRepo

    Integer getNextSequence(UUID attemptUuid){
        return (attemptSaveRepo.maxSequenceByAttemptUuid(attemptUuid) ?: 0) + 1
    }

    @Transactional
    AttemptSave save(AttemptSave attemptSave){
        attemptSaveRepo.save(attemptSave)
    }
}
