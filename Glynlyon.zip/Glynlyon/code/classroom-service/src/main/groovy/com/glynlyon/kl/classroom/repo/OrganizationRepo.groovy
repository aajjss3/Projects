package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param

import javax.transaction.Transactional

interface OrganizationRepo extends CrudRepository<Organization, UUID>, JpaSpecificationExecutor, LocalRepo<Organization> {

    Organization findByUuid(UUID uuid)
    Organization findByUuidAndOriginationId(UUID uuid, String originationId)

    List<Organization> findAllByUsersUuidAndType(UUID userUUID, OrganizationType type)
    List<Organization> findAllByParent(Organization parent)
    List<Organization> findAllByTypeAndOriginationId(OrganizationType type, String originationId)
    List<Organization> findAllByUuidIn(Set<UUID> orgUuids)

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO {h-schema}Organization(organization_uuid, name, type,origination_id, version) VALUES (:uuid,:name,cast(:type as {h-schema}organization_type),:origination_id, 0)",nativeQuery = true)
    void createOrgWithoutParent(@Param("uuid") UUID uuid, @Param("name") String name,@Param("type") String type,@Param("origination_id") String originationId);


    @Transactional
    @Modifying
    @Query(value = "INSERT INTO {h-schema}Organization(organization_uuid, name, type,origination_id,parent, version) VALUES (:uuid,:name,cast(:type as {h-schema}organization_type),:origination_id,:parentUuid, 0)",nativeQuery = true)
    void createOrgWithParent(@Param("uuid") UUID uuid, @Param("name") String name,@Param("type") String type,@Param("origination_id") String originationId, @Param("parentUuid") UUID parentUuid);


}