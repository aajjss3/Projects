package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.PageObj
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

import javax.servlet.http.HttpServletRequest

class PlannerPageSerializer  extends JsonSerializer<PageObj> {
    @Override
    void serialize(PageObj pageObj, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest()
        String serverRoot = req.getScheme() + "://" + req.getHeader("Host")

        gen.writeStartObject()
        gen.writeStringField("page_uuid", pageObj.uuid.toString())
        gen.writeStringField("name", pageObj.name)
        gen.writeObjectField("status", pageObj.status)
        gen.writeObjectField("_links", ["self": ["href": serverRoot + "/pages?filter=page_uuid='${pageObj.uuid.toString()}'"]])
        gen.writeEndObject()
    }
}
