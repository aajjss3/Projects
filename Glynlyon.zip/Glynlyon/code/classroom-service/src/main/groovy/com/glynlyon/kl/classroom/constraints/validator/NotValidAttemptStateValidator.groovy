package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.NotValidAttemptState
import com.glynlyon.kl.classroom.model.AttemptState


/**
 * Determine if the 'state' or 'status'  value is valid based on the enum AttemptState.
 * A missing value for 'state' or 'status' is also considered valid 
 * @author asparago
 *
 */
class NotValidAttemptStateValidator extends AbstractValidator implements ConstraintValidator<NotValidAttemptState, String>{

    @Override
    void initialize(NotValidAttemptState constraintAnnotation) {

    }

    @Override
	public boolean isValid(String field, ConstraintValidatorContext context) {
		if( !field ){
			return true
		}
		try{
			AttemptState.valueOf(field)
			return true
		}
		catch(Exception e){
			return false
		}
	}

}
