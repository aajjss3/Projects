package com.glynlyon.kl.classroom.job

import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger

abstract class AbstractJob {

	Logger logger = LogManager.getLogger(this.class)

}

