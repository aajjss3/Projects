package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty

class EnrollmentSuccessMsg extends EnrollmentMessage {

    @Override
    String getContainer() {
        return "successes"
    }

    @JsonProperty(value = "user_uuid")
    UUID userUuid

    @JsonProperty(value = "class_uuid")
    UUID classUuid

    @JsonProperty(value = "enrollment_uuid")
    UUID enrollmentUuid
}
