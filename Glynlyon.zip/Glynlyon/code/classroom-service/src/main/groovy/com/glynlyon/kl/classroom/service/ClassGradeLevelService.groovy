package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class ClassGradeLevelService {

    @Autowired
    ClassGradeLevelRepo gradeLevelRepo

    @Transactional
    List<ClassGradeLevel> save(UUID uuid, List<Grade> grades){
        List<ClassGradeLevel> existing = gradeLevelRepo.findAllByClassUuid(uuid)
        List<Grade> existingGrades = existing.collect{it.grade}
        //grades in input that don't already exist
        if(grades){
            (grades - existingGrades).each {
                gradeLevelRepo.save(new ClassGradeLevel(classUuid: uuid, grade: it, updatedAt: new Date(), createdAt: new Date()))
            }
        }
        List<Grade> toDelete = existingGrades - grades
        if(toDelete) {
            gradeLevelRepo.deleteAllByGradeInAndClassUuid(toDelete,uuid)
        }
        return gradeLevelRepo.findAllByClassUuid(uuid).sort()
    }
}
