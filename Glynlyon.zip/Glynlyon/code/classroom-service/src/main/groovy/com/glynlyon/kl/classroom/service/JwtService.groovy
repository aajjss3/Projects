package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.model.AppUserType
import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Service

import java.nio.charset.StandardCharsets

@Service
public class JwtService {

    @Value('${jwt.secret.key}')
    String secret

    String getUuid(String token) {
        Claims claims = getClaims(token)
        return claims.getSubject()
    }

    AppUserType getRole(String token) {
        Claims claims = getClaims(token)
        def glCustom = claims.get('gl_custom')

        return glCustom.role_in_issuer.toUpperCase() as AppUserType
    }

    UUID getOrgUuid(String token) {
        Claims claims = getClaims(token)
        def glCustom = claims.get('gl_custom')

        return UUID.fromString(glCustom.school_uuid)
    }

    String getDatasource(String token){
        Claims claims = getClaims(token)
        Map glCustom = claims.get("gl_custom", Map)
        return glCustom.get("datasource")
    }

    String updateOrgUuid(String token, UUID orgUuid){
        Claims claims = getClaims(token)
        claims.gl_custom.school_uuid = orgUuid
        return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS256, secret.getBytes(StandardCharsets.UTF_8)).compact()
    }

    String getIssuerUrl(String token) {
        Claims claims = getClaims(token)
        Map glCustom = claims.get("gl_custom", Map)
        return glCustom.get("issuer_base_url")
    }

    String getIssuer(String token) {
        Claims claims = getClaims(token)
        return claims.getIssuer()
    }

    private Claims getClaims(String token){
        return Jwts.parser().setSigningKey(secret.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(token).getBody()
    }
}