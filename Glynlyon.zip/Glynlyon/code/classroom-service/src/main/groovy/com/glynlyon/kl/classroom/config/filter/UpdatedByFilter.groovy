package com.glynlyon.kl.classroom.config.filter

import java.io.IOException
import javax.servlet.Filter
import javax.servlet.FilterChain
import javax.servlet.FilterConfig
import javax.servlet.ServletException
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.annotation.WebFilter
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.env.Environment
import org.springframework.stereotype.Component
import java.nio.charset.StandardCharsets
import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts



/**
 * This filter is registered by spring when the application starts up. 
 * It will retrieve the users uuid from the http header and place it in the body of all PUT and POST requests by assigning its value to a json field called updated_by (ex  "updated_by" : "<user uuid>", )
 * It works in conjunction with the ClassroomHttpServletRequestWrapper class
 *
 */
@Component
public class UpdatedByFilter implements Filter {
	
	String jwtSecret
	
	@Autowired
	Environment env

    @Override
    void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest)req
        HttpServletResponse response = (HttpServletResponse)res

		boolean userFound = false
		
		if ("POST".equalsIgnoreCase(request.getMethod()) || "PUT".equalsIgnoreCase(request.getMethod()) || "PATCH".equalsIgnoreCase(request.getMethod())) {
			String authorizationHTTPHeader = request.getHeader("authorization")
			if(authorizationHTTPHeader){
				Claims claims = Jwts.parser().setSigningKey(jwtSecret.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(authorizationHTTPHeader.substring(7)).getBody()
				if(claims){
					String userUUID = claims.getSubject()
					if(userUUID){
						userFound = true
						chain.doFilter(new ClassroomHttpServletRequestWrapper(request, userUUID), response)
					}	
				} 
			}	

		}
		
		if( !userFound ){
			chain.doFilter(request, response)
		}	

    }

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		jwtSecret = env.getProperty("jwt.secret.key")

	}

	@Override
	public void destroy() {
	}

}
