package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.Constraint
import javax.validation.Payload
import java.lang.annotation.*

@Target([ElementType.TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CustomGradeDisplayValidator.class)
@Documented
@Inherited
public @interface CustomGradeDisplay {
    String message() default "Field not valid"
    Class<?>[] groups() default []
    Class<? extends Payload>[] payload() default []
}
