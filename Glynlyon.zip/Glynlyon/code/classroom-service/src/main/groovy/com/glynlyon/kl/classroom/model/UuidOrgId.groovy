package com.glynlyon.kl.classroom.model

class UuidOrgId implements Serializable, GroovyObject {
    UUID uuid
    UUID organizationUuid

    UuidOrgId(){}

    UuidOrgId(UUID uuid, UUID organizationUuid){
        this.uuid = uuid
        this.organizationUuid = organizationUuid
    }

    @Override
    int hashCode() {
        return Objects.hash(uuid, organizationUuid)
    }

    @Override
    boolean equals(Object o) {
        if (getClass() != o.getClass()) {
            return false
        }
        UuidOrgId other = (UuidOrgId)o
        return Objects.equals(uuid, other.uuid) && Objects.equals(organizationUuid, other.organizationUuid)
    }
}
