package com.glynlyon.kl.classroom.model

class ClassGradeLevelId implements Serializable, GroovyObject {
    UUID classUuid
    Grade grade

    @Override
    int hashCode() {
        return Objects.hash(classUuid, grade)
    }

    @Override
    boolean equals(Object o) {
        if (getClass() != o.getClass()) {
            return false
        }
        ClassGradeLevelId cglid = (ClassGradeLevelId)o
        return Objects.equals(classUuid, cglid.classUuid) && Objects.equals(grade, cglid.grade)
    }
}
