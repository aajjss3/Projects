package com.glynlyon.kl.classroom.dto

import org.springframework.http.HttpStatus

class ValidationResult<T> {
    T obj
    String message
    Boolean valid
    HttpStatus httpStatus=HttpStatus.BAD_REQUEST
}
