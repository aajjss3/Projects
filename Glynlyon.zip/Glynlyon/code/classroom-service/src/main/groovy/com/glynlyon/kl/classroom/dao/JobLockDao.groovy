package com.glynlyon.kl.classroom.dao

import javax.persistence.EntityManager
import javax.persistence.PersistenceContext

import java.util.UUID

import javax.persistence.LockModeType
import javax.persistence.NoResultException

import org.hibernate.LockOptions
import org.hibernate.NonUniqueResultException
import org.hibernate.Query
import org.hibernate.Session
import org.hibernate.SessionFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Propagation
import org.springframework.transaction.annotation.Transactional
import org.hibernate.LockMode

import com.glynlyon.kl.classroom.model.JobLock
import com.glynlyon.kl.classroom.model.Lock


@Repository
class JobLockDao {
	
	@PersistenceContext
	protected EntityManager entityManager

	public JobLock getJobLockPessimistically() {
		try{
			return entityManager.createQuery("select l from JobLock l where l.purpose='COMPLETE_PAGE'", JobLock.class).setLockMode( LockModeType.PESSIMISTIC_WRITE ).getSingleResult()
		}
		catch(NoResultException nre){
			return null
		}
	}
	
	public void flush(){
		entityManager.flush()
	}

}
