package com.glynlyon.kl.classroom.exceptions

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus
import org.apache.logging.log4j.Level


/**
 * Exception to throw when a Http Status NOT_ACCEPTABLE (406) is desired.
 * @see CustomException for furthur documentation
 * @author asparago
 *
 */
@ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
class NotAcceptableException extends CustomException{
	
	public NotAcceptableException(String message){
		super(message)
	}
	
	public NotAcceptableException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public NotAcceptableException(String message, Level logLevel, Exception rootCause){
		super(message, logLevel, rootCause)
	}
	
}
