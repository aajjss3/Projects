package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.IssuerLaunchDTO
import com.glynlyon.kl.classroom.exceptions.BadRequestException
import com.glynlyon.kl.classroom.exceptions.GoneException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.IssuerLaunch
import com.glynlyon.kl.classroom.repo.IssuerLaunchRepo
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

import javax.transaction.Transactional

@Service
class IssuerLaunchesService {

    @Autowired
    IssuerLaunchRepo issuerLaunchRepo

    @Autowired
    JwtService jwtService

    @Transactional
    String saveLaunchAndGenerateRedirectUrl(String token, IssuerLaunchDTO dto) {
        String issuer = jwtService.getIssuer(token)
        if(issuer != Constants.OW_ISSUER){
            throw new BadRequestException("unknown issuer ${issuer}")
        }
        if(!["students", "home"].any{dto.action.equalsIgnoreCase(it)}){
            throw new BadRequestException("unknown action ${dto.action}")
        }

        IssuerLaunch issuerLaunch = issuerLaunchRepo.save(new IssuerLaunch(token))

        return jwtService.getIssuerUrl(token) + "/launches?launchId=" + issuerLaunch.uuid + "&action=" + dto.action
    }

    @Transactional
    IssuerLaunch markExisting(UUID uuid){
        IssuerLaunch existing = issuerLaunchRepo.findOne(uuid)

        if (existing) {
            if (!existing.launched) {
                existing.launched = true
                existing.date_launched = new Date()
                return existing
            }
            throw new GoneException("${uuid} already launched")
        }
        else {
            throw new NotFoundException("Could not find issuer launch with uuid ${uuid}")
        }
    }
}
