package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Configuration
import org.springframework.data.jpa.repository.JpaRepository

interface ConfigurationRepo extends JpaRepository<Configuration, UUID> {

    Configuration findByKey(String key)
}