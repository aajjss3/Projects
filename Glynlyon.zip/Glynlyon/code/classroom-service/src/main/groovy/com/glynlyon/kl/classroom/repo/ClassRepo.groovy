package com.glynlyon.kl.classroom.repo

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.repository.query.Param

import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.SubjectsView

interface ClassRepo extends PagingAndSortingRepository<ClassObj, UUID>, LocalRepo<ClassObj>, JpaRepository<ClassObj, UUID>, JpaSpecificationExecutor<ClassObj> {

    List<ClassObj> findAllByAcademicSession(AcademicSession academicSession)
    List<ClassObj> findAllBySubject( SubjectsView subjectsView )
	
	@Query(value = "SELECT CAST (class_uuid AS text) FROM {h-schema}class c inner join {h-schema}organization o on (c.organization_uuid = o.organization_uuid) where o.parent = :schoolUuid", nativeQuery = true)
	List<String> findAllUUIDBySchool( @Param("schoolUuid") UUID schoolUuid )
	
	
	@Query(value = "SELECT CAST  (pe.class_uuid as text) FROM {h-schema}attempt attempt INNER JOIN {h-schema}planner_entry pe ON attempt.planner_entry_uuid = pe.planner_entry_uuid WHERE attempt.uuid = :attemptUuid", nativeQuery = true)
	String findClassUuidByAttempt(@Param("attemptUuid") UUID attemptUuid)

}
