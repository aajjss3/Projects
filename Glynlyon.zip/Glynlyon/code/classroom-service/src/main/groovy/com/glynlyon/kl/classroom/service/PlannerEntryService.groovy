package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.PlannerEntryPatchDTO
import com.glynlyon.kl.classroom.exceptions.InvalidInputException
import com.glynlyon.kl.classroom.exceptions.InvalidRoleException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryFilter
import com.glynlyon.kl.classroom.model.PlannerEntryParams
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.stereotype.Service

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root
import javax.transaction.Transactional

import static org.springframework.data.jpa.domain.Specifications.where

@Service
class PlannerEntryService {

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    PlannerEntryValidationService plannerEntryValidationService

    @Autowired
    JwtService jwtService

    @Autowired
    FilterService filterService

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Transactional
    void delete(PlannerEntry plannerEntry) {
        plannerEntryRepo.delete(plannerEntry.uuid)
    }

    public Page findAllPlannerEntries(String jwtToken, String filter, Pageable pageable) {
        AppUserType role = jwtService.getRole(jwtToken)
        String userUuid = jwtService.getUuid(jwtToken)

        Page plannerEntryResult

        //Adding filter to restrict the planner entries to the user making GET request.
        Closure<Specification> mainFilter = {
            return new Specification<PlannerEntry>() {
                public Predicate toPredicate(Root<PlannerEntry> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    return builder.equal(root.get("user").get('uuid'), UUID.fromString(userUuid))
                }
            }
        }

        if (role == AppUserType.STUDENT) {
            if (filter) {
                def mappings = [:]
                plannerEntryResult = filterService.find(filter, PlannerEntry, plannerEntryRepo, pageable, mappings, mainFilter, null)
            } else {
                plannerEntryResult = plannerEntryRepo.findAll(mainFilter(), pageable)
            }
        }
        return plannerEntryResult
    }

    @Transactional
    public deleteByParams(String token, PlannerEntryParams params) {
        plannerEntryRepo.delete((List<PlannerEntry>)findByParams(token, params.filter))
    }

    @Transactional
    void updateByParams(String token, PlannerEntryParams params, InputMapperService.MappingResult<PlannerEntryParams> mappingResult, UUID updatedByUUID) {

        Integer newSlot = null
        if(params.plannerEntry?.slot != null){
            if(params.plannerEntry.slot != -1){
                mappingResult.errors.add(new ErrorOutput(field: "slot", message: "Cannot bulk update planner entries to any slot other than -1."))
            }
            else {
                newSlot = -1
            }
        }

        List<PlannerEntry> entries = findByParams(token, params.filter)
        plannerEntryRepo.save((List<PlannerEntry>)entries.collect {
            if(params.plannerEntry.status) {
                it.status = params.plannerEntry.status
            }
            it.updated = new Date()
			it.updatedBy = updatedByUUID

            if(params.plannerEntry.status == PlannerEntryState.OBE) {
                it.slot = -1
            }
            if(newSlot != null){
                it.slot = newSlot
            }
            return it
        })
        if(mappingResult.errors){
            throw new RuntimeException()
        }
    }

    @Transactional
    PlannerEntry update(String token, PlannerEntry existing, PlannerEntryPatchDTO input, List errors) {
        if(!input.slot && !input.status) {
            errors.add(new ErrorOutput(field: "slot / status", message: "One of slot or status is required for planner entry update"))
        }

        validateStatus(jwtService.getRole(token), input?.status, existing?.status, errors)

        PlannerEntry target = existing.with {
            if(input.slot) {
                it.slot = input.slot
            }
            if(input.status) {
                it.status = input.status
            }
            it.updated = new Date()
			it.updatedBy = input.updatedBy
            return it
        }

        if(target.slot == -1 && target.status == PlannerEntryState.NOT_STARTED){
            errors.add(new ErrorOutput(field: "slot / status", message: "Cannot have planner entry with status NOT_STARTED and slot -1."))
        }

        if(input.slot != null && input.slot > 0){
            List<PlannerEntry> collisions = plannerEntryRepo.findAllByUserUuidAndSlot(existing.user.uuid, input.slot)
            if(collisions?.size() > 1 || (collisions.size() == 1 && collisions.first().uuid != existing.uuid)){
                errors.add(new ErrorOutput(field: "slot", message: "Slot ${input.slot} is already in use."))
            }
        }

        PlannerEntry entry = plannerEntryRepo.save(target)
        if(errors){
            throw new RuntimeException()
        }
        return entry
    }

    private List<PlannerEntry> findByParams(String token, PlannerEntryFilter filter) {
        AppUserType type = jwtService.getRole(token)
        if (type != AppUserType.ADMIN && type != AppUserType.TEACHER) {
            throw new InvalidRoleException()
        }

        if (!filter?.classUuid) {
            List<ErrorOutput> errors = []
            if (!filter?.classUuid) {
                errors.add(new ErrorOutput(field: "class_uuid", message: "Missing required field class_uuid"))
            }
            throw new InvalidInputException(errors: errors)
        }

        def mainFilter = new Specification<PlannerEntry>() {
            @Override
            Predicate toPredicate(Root<PlannerEntry> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                Predicate pageOrClassFilter
                if(filter.pageObjUuid){
                    pageOrClassFilter = cb.equal(root.get("pageObj").get("uuid"), filter.pageObjUuid)
                }
                else {
                    pageOrClassFilter = cb.equal(root.get("classObj").get("uuid"), filter.classUuid)
                }
                if(filter.status){
                    return cb.and(
                            pageOrClassFilter,
                            cb.equal(root.get("status"), filter.status)
                    )
                }
                return pageOrClassFilter
            }
        }

        if (type == AppUserType.TEACHER) {
            def enrolledFilter = new Specification<PlannerEntry>() {
                @Override
                Predicate toPredicate(Root<PlannerEntry> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                    UUID userUuid = UUID.fromString(jwtService.getUuid(token))
                    Enrollment enrollment = enrollmentRepo.findByClassObjUuidAndUserUuidAndRole(filter.classUuid, userUuid, Role.TEACHER)
                    return enrollment ? cb.equal(root.get("classObj").get("uuid"), filter.classUuid) : cb.or()
                }
            }
            mainFilter = where(mainFilter).and(enrolledFilter)
        }

        if (filter.assignmentUuid) {
            def assignmentFilter = new Specification<PlannerEntry>() {
                @Override
                Predicate toPredicate(Root<PlannerEntry> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                    return cb.equal(root.get("assignment").get("uuid"), filter.assignmentUuid)
                }
            }

            mainFilter = where(mainFilter).and(assignmentFilter)
        }

        return plannerEntryRepo.findAll(mainFilter)
    }

    @Transactional
    public PlannerEntry create(PlannerEntry input, InputMapperService.MappingResult<PlannerEntry> mappingResult, String token) {

        PageAssignment pageAssignment = plannerEntryValidationService.validateCreatePlannerEntry(input, mappingResult, token)

        PlannerEntry plannerEntry = input
        plannerEntry.activityId = pageAssignment.uuid
        plannerEntry.attempts = []

        validateStatus(jwtService.getRole(token), input?.status, null, mappingResult.errors)

        plannerEntryRepo.save(plannerEntry)

        if(mappingResult.errors) {
            throw new RuntimeException()
        }

        return plannerEntry
    }

    private static validateStatus(AppUserType role, PlannerEntryState input, PlannerEntryState existing, List errors){
        if(role == AppUserType.STUDENT){
            if(input != existing && input == PlannerEntryState.REASSIGNED && existing != PlannerEntryState.REASSIGNED_IN_PROGRESS){
                errors.add(new ErrorOutput(field: "status", message: "Students cannot set planner entries to be REASSIGNED unless current state is REASSIGNED_IN_PROGRESS"))
            }
            if(input != existing && input == PlannerEntryState.REASSIGNED_IN_PROGRESS && existing != PlannerEntryState.REASSIGNED){
                errors.add(new ErrorOutput(field: "status", message: "Students cannot set planner entries to be REASSIGNED_IN_PROGRESS unless current state is REASSIGNED"))
            }
        }
    }
}
