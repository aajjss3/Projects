package com.glynlyon.kl.classroom.util

public enum EventEnum {
		loggedin, loggedout
}
