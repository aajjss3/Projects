package com.glynlyon.kl.classroom.constraints.validator

import java.lang.reflect.Field
import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.constraints.annotation.NotBlankStateAndStatus
import com.glynlyon.kl.classroom.constraints.annotation.NotNullFieldsInRequest
import com.glynlyon.kl.classroom.dto.BaseDTO


/**
 * Validation for required fields that do not need to be present in the json request. This validation is only used on HTTP PATCH endpoints.
 * This validation differs from the standard @NotNull bean validation in that if the field is not present in the json request then its ok for its DTO value to remain null (i.e. it will pass validation).
 * It will fail validation only if ALL of the following 3 field requirements are met:
 * 		1)a field was passed in the json request (for a list of these fields see BaseDTO.requestFields) 
 * 		2)this field is one of the required fields (see the 'fields' parameter in this class for a list of these required fields)
 * 		3)this field's value is null.
 *
 */
class NotNullFieldsInRequestValidator  implements ConstraintValidator<NotNullFieldsInRequest, Object>{
	
	private String[] fields

	@Override
	public void initialize(NotNullFieldsInRequest constraintAnnotation) {
		this.fields = constraintAnnotation.fields()
	}
	
	
	@Override
	/**
	 * dto - DTO object
	 */
	public boolean isValid(Object dto, ConstraintValidatorContext context) {
		boolean ok = true
		if (fields){
			for(String fieldName : fields){
				Field field = dto.getClass().getDeclaredField(fieldName)
				field.setAccessible(true)
				if( field.get(dto) == null && ((BaseDTO)dto).requestFields.contains( fieldName ) ){
					ok = false
					// if validation fails, remove the existing failed validation for this field
					context.disableDefaultConstraintViolation()
					//then add a validation -set the field that failed validation to 'state' and use the default message. this is to ensure the field and message for failed validations is backwards compatiblity.
					String message = context.getDefaultConstraintMessageTemplate()
					context.buildConstraintViolationWithTemplate(message).addPropertyNode(fieldName).addConstraintViolation()
				}
			}
		}
		return ok
	}
}
