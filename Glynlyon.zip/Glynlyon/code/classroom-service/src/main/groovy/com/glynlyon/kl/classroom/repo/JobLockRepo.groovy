package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.JobLock
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query


interface JobLockRepo extends JpaRepository<JobLock, UUID> {
	
	public static final String QUERY_COMPLETED_PAGES = "select CAST (page.page_uuid AS text) from {h-schema}page, {h-schema}class, {h-schema}organization school, {h-schema}academic_session where completed_date is null and page.class_uuid = class.class_uuid and class.academic_session_uuid = academic_session.academic_session_uuid and academic_session.organization_uuid = school.organization_uuid and CURRENT_TIMESTAMP at time zone school.timezone > coalesce(page.due_date, academic_session.end_date);"
	
	@Query(value = JobLockRepo.QUERY_COMPLETED_PAGES, nativeQuery = true)
	List<String> getPagesToComplete()

}
