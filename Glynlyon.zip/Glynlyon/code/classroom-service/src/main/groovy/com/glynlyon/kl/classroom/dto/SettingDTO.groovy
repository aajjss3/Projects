package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.classroom.constraints.group.ClassSetting
import com.glynlyon.kl.classroom.constraints.group.OrganizationSetting
import com.glynlyon.kl.classroom.constraints.validator.CustomGradeDisplay
import com.glynlyon.kl.classroom.constraints.validator.MapUniqueDouble
import com.glynlyon.kl.classroom.model.SettingType

import javax.validation.Valid
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull

public class SettingDTO extends BaseDTO{
	
	public static final long ATTEMPT_LOWER_LIMIT = 0L
	public static final long THRESHOLD_LOWER_LIMIT = 0L
	public static final long THRESHOLD_UPPER_LIMIT = 100L
	
	@JsonProperty(value="setting_uuid")
	public UUID uuid
	
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Valid
	public Value value
	
	public SettingType type
	
	@JsonProperty(value="source_uuid")
	public UUID sourceUUID


	public UUID getUuid() {
		return uuid
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid
	}

	public Value getValue() {
		return value
	}

	public void setValue(Value value) {
		this.value = value
	}

	public SettingType getType() {
		return type
	}

	public void setType(SettingType type) {
		this.type = type
	}

	public UUID getSourceUUID() {
		return sourceUUID
	}

	public void setSourceUUID(UUID sourceUUID) {
		this.sourceUUID = sourceUUID
	}
}


class Value {
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class])
	@Valid
	public Admin admin
	
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Valid
	public Classroom classroom


	public Admin getAdmin() {
		return admin
	}

	public void setAdmin(Admin admin) {
		this.admin = admin
	}

	public Classroom getClassroom() {
		return classroom
	}

	public void setClassroom(Classroom classroom) {
		this.classroom = classroom
	}
}


class Admin {
	
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class])
	public Boolean override

	Admin(){}
	
	Admin(Boolean override){this.override = override}

	public Boolean getOverride() {
		return override
	}

	public void setOverride(Boolean override) {
		this.override = override
	}
}


class Classroom {
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Valid
	public ClassType lessons
	
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Valid
	public ClassType projects


	@JsonProperty(value="grade_display")
	@Valid
    public GradeDisplay gradeDisplay

	@JsonProperty("grade_scale")
	@MapUniqueDouble(groups=[OrganizationSetting.class, ClassSetting.class])
	public Map<String,Double> gradeScale


	public ClassType getLessons() {
		return lessons
	}

	public void setLessons(ClassType lessons) {
		this.lessons = lessons
	}

	public ClassType getProjects() {
		return projects
	}
	public void setProjects(ClassType projects) {
		this.projects = projects
	}

	public GradeDisplay getGradeDisplay() {
		return gradeDisplay
	}

	public void setGradeDisplay(GradeDisplay gradeDisplay) {
		this.gradeDisplay = gradeDisplay
	}

	public Map<String,Double> getGradeScale() {
		return gradeScale
	}

	public void setGradeScale(Map<String,Double> gradeScale) {
		this.gradeScale = gradeScale
	}

}


class ClassType {
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Min(value=SettingDTO.ATTEMPT_LOWER_LIMIT, message = "{input.integer.min}", groups=[OrganizationSetting.class, ClassSetting.class])
	public Integer attempts
	
	@NotNull(message = "{input.field.required}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Min(value=SettingDTO.THRESHOLD_LOWER_LIMIT, message = "{input.integer.min}", groups=[OrganizationSetting.class, ClassSetting.class])
	@Max(value=SettingDTO.THRESHOLD_UPPER_LIMIT, message = "{input.integer.max}", groups=[OrganizationSetting.class, ClassSetting.class])
	public Integer threshold


	public Integer getAttempts() {
		return attempts
	}

	public void setAttempts(Integer attempts) {
		this.attempts = attempts
	}

	public Integer getThreshold() {
		return threshold
	}

	public void setThreshold(Integer threshold) {
		this.threshold = threshold
	}
}

@CustomGradeDisplay(groups=[OrganizationSetting.class, ClassSetting.class])
class GradeDisplay {
	public Boolean percentage

	public Boolean letter

	public Boolean getPercentage() {
		return percentage
	}

	public void setPercentage(Boolean percentage) {
		this.percentage = percentage
	}

	public Boolean getLetter() {
		return letter
	}

	public void setLetter(Boolean letter) {
		this.letter = letter
	}
}




