package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.AcademicSession

import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.CrudRepository

interface AcademicSessionRepo extends CrudRepository<AcademicSession, UUID>, JpaSpecificationExecutor, LocalRepo<AcademicSession> {

    Page<AcademicSession> findAll(Pageable pageable)
    Page<AcademicSession> findByOrganizationUuid(Pageable pageable, UUID organization_uuid)
    
    List<AcademicSession> findAllByOrganizationUuid(UUID organization_uuid)

    AcademicSession findByNameIgnoreCaseAndOrganizationUuid(String name, UUID orgUuid)
    AcademicSession findByNameIgnoreCaseAndOrganizationUuidAndUuidNot(String name, UUID orgUuid, UUID uuid)
}
