package com.glynlyon.kl.classroom.dto.messages

import com.fasterxml.jackson.annotation.JsonProperty

class SubjectSuccessMsg extends SubjectMessage {

    @Override
    String getContainer() {
        return "successes"
    }

    @JsonProperty(value = "subject_uuid")
    UUID subjectUuid
}
