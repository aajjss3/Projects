package com.glynlyon.kl.classroom.controllers

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.glynlyon.kl.classroom.dto.AssignmentReportRequestDTO
import com.glynlyon.kl.classroom.dto.ValidationResult
import com.glynlyon.kl.classroom.exceptions.AssignmentSequenceException
import com.glynlyon.kl.classroom.exceptions.OrgNotFoundException
import com.glynlyon.kl.classroom.exceptions.UnsupportedFieldException
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PagedResponse
import com.glynlyon.kl.classroom.service.AttemptService
import com.glynlyon.kl.classroom.service.InputMapperService
import com.glynlyon.kl.classroom.service.PageAssignmentService
import com.glynlyon.kl.classroom.service.PageService
import com.glynlyon.kl.classroom.service.PageableService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.LinkHeaderBuilder
import org.hibernate.exception.ConstraintViolationException
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.http.HttpHeaders
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
class PageAssignmentController extends AbstractController {

    @Autowired
    PageAssignmentService pageAssignmentService

    @Autowired
    InputMapperService inputMapperService

    @Autowired
    PageableService pageableService

    @Autowired
    PageService pageService

    @Autowired
    AttemptService attemptService

    @PostMapping(path = "/pages/{uuid}/assignments", produces = Constants.PAGE_ASSIGNMENTS_VERSION_1, consumes = Constants.PAGE_ASSIGNMENTS_VERSION_1)
    ResponseEntity createAssignments(
            @PathVariable('uuid') UUID pageUuid,
            @RequestBody ObjectNode jsonInput,
            @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, true)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }
        try {
            List<JsonNode> jsonList = jsonInput.get("page_assignments").toList()
            List<PageAssignment> pageAssignments = jsonList.collect { json ->
                def mappingResult = inputMapperService.processInput((ObjectNode) json, PageAssignment)
                PageAssignment input = mappingResult.obj
                if (input == null) {
                    throw new RuntimeException("Couldn't process input")
                }

                input.uuid = null
                input.pageObj = validationResult.obj
                return input
            }

            pageAssignmentService.createAll(pageAssignments)
            return ResponseEntity.noContent().build()
        }
        catch (Throwable t) {
            String message = "Could not save input"
            if (t?.cause instanceof ConstraintViolationException) {
                message = ((ConstraintViolationException) t.cause).SQLException.toString()
            }
            logger.error(t.message, t)
            return ResponseEntity.badRequest().body([error: message])
        }
    }

    @PutMapping(path = "/pages/{uuid}/assignments", produces = Constants.PAGE_ASSIGNMENTS_VERSION_1, consumes = Constants.PAGE_ASSIGNMENTS_VERSION_1)
    ResponseEntity updateAssignments(
            @PathVariable('uuid') UUID pageUuid,
            @RequestBody ObjectNode jsonInput,
            @RequestHeader(name = "authorization") String auth) {
        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, false)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }
        try {
            List<JsonNode> jsonList = jsonInput.get("page_assignments").toList()
            List<PageAssignment> pageAssignments = jsonList.collect { json ->
                def mappingResult = inputMapperService.processInput((ObjectNode) json, PageAssignment)
                PageAssignment input = mappingResult.obj
                if (input == null) {
                    throw new RuntimeException("Couldn't process input")
                }

                return input
            }

            pageAssignmentService.updateAll(pageAssignments, pageUuid)
            return ResponseEntity.ok().build()

        }
        catch (Throwable t) {
            String message = "Could not save input"
            if(t?.cause instanceof ConstraintViolationException){
                message = ((ConstraintViolationException)t.cause).SQLException.toString()
            }
            if(t instanceof AssignmentSequenceException) {
                message = t.message
            }
            logger.error(t.message, t)
            return ResponseEntity.badRequest().body([error: message])
        }
    }

    @RequestMapping(path = "/pages/{uuid}/assignments", method = RequestMethod.GET, produces = Constants.PAGE_ASSIGNMENTS_VERSION_1)
    ResponseEntity<?> getAssignments(@PathVariable('uuid') UUID pageUuid,
            @RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "authorization") String auth) {

        Page page
        HttpHeaders responseHeaders = null
        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, true, false)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "sub / school_uuid", message: validationResult.message))
        }

        try {
            Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_PAGE_ASSIGNMENT_SORT, PageAssignment)
            page = pageAssignmentService.findAllPageAssignments(pageUuid, filter, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch (UnsupportedFieldException e) {
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        catch (OrgNotFoundException onfe) {
            return ResponseEntity.badRequest().body(new ErrorOutput(field: "sub / school_uuid", message: onfe.message))
        }
        PagedResponse.createResponse("page_assignments", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }

    @DeleteMapping(path = "/pages/{pageUuid}/assignments/{pageAssignmentUuid}")
    ResponseEntity<?> deleteAssignment(
            @PathVariable("pageUuid") UUID pageUuid,
            @PathVariable("pageAssignmentUuid") UUID pageAssignmentUuid,
            @RequestHeader(name = "authorization") String auth){

        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, false)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }

        ValidationResult<PageAssignment> result = pageAssignmentService.validatePageAssignment(pageUuid, pageAssignmentUuid)
        if(!result.valid){
            return ResponseEntity.badRequest().body([error: result.message])
        }

        pageAssignmentService.delete(result.obj)
        return ResponseEntity.noContent().build()
    }

    @PostMapping(path = "/pages/{pageUuid}/assignments/{pageAssignmentUuid}/reports", produces = Constants.PAGE_ASSIGNMENTS_REPORT_VERSION_1, consumes = Constants.PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1)
    ResponseEntity<?> getReport(@PathVariable("pageUuid") UUID pageUuid,
            @PathVariable("pageAssignmentUuid") UUID pageAssignmentUuid,
            @Validated @RequestBody AssignmentReportRequestDTO assignmentReportRequestDTO,
            @RequestHeader(name = "x-client-domain") String domain,
            @RequestHeader(name = "authorization") String auth){

        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, false)
        if (!validationResult.valid) {
            return ResponseEntity.badRequest().body([error: validationResult.message])
        }

        ValidationResult<PageAssignment> result = pageAssignmentService.validatePageAssignment(pageUuid, pageAssignmentUuid)
        if(!result.valid){
            return ResponseEntity.badRequest().body([error: result.message])
        }

        def resp = attemptService.getAttemptsByPageAssignmentReport(result.obj, assignmentReportRequestDTO.report_id_prefix, domain)
        if(resp){
            return ResponseEntity.ok(resp)
        }
        return ResponseEntity.noContent().build()
    }

    @GetMapping(path = "/pages/{pageUuid}/assignments/{pageAssignmentUuid}/reports/itemAnalysis", produces = Constants.ITEM_ANALYSIS_REPORT_VERSION_1)
    ResponseEntity<?> getItemAnalysisReport(@PathVariable("pageUuid") UUID pageUuid,
            @PathVariable("pageAssignmentUuid") UUID pageAssignmentUuid,
            @RequestParam(name = "limit", required = false) Integer limit,
            @RequestParam(name = "offset", required = false) Integer offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "filter", required = false) String filter,
            @RequestHeader(name = "x-client-domain") String domain,
            @RequestHeader(name = "authorization") String auth){

        String token = auth.substring(JWT_STARTING_INDEX)
        ValidationResult<PageObj> validationResult = pageService.validateOrgAndPage(token, pageUuid, false, false)
        if (!validationResult.valid) {
            return new ResponseEntity([error: validationResult.message], validationResult.httpStatus)
        }

        ValidationResult<PageAssignment> result = pageAssignmentService.validatePageAssignment(pageUuid, pageAssignmentUuid)
        if(!result.valid) {
            return new ResponseEntity([error: result.message], result.httpStatus)
        }

        /* default sort is date_submitted DESC */
        if(!orderBy && !sort){
            orderBy = "DESC"
        }

        Map mappings =  [
                /**
                 * yeah the user ones look weird, but user prop on Attempt is annotated
                 * as user_uuid already for a different endpoint to work
                 */
                "user_uuid" : "user_uuid.user_uuid",
                "first_name" : "user_uuid.first_name",
                "last_name" : "user_uuid.last_name",
                "session_id" : "attempt_uuid",
                "status" : "state",
                "date_submitted" : 'completed_at'
        ]

        Page page
        HttpHeaders responseHeaders = null
        try {
            Pageable pageable = pageableService.createPageable(limit, offset, orderBy, sort, Constants.DEFAULT_ITEM_ANALYSIS_SORT, Attempt.class, [], mappings)
            page = attemptService.getItemAnalysisReport(result.obj, filter, mappings, domain, pageable)
            responseHeaders = new LinkHeaderBuilder(page).addCommonLinks().build(new HttpHeaders())
        }
        catch (UnsupportedFieldException e) {
            page = new PageImpl([new ErrorOutput(field: "sort", message: "invalid sort field '${e.message}'")])
        }
        catch (OrgNotFoundException onfe) {
            page = new PageImpl([new ErrorOutput(field: "sub / school_uuid", message: onfe.message)])
        }
        catch(Throwable t){
            logger.error(t.message, t)
            return ResponseEntity.badRequest().body([error: t.message])
        }
        PagedResponse.createResponse("attempts", page.content, page.getNumber() + 1, page.getNumberOfElements(), page.getTotalPages(), responseHeaders)
    }
}
