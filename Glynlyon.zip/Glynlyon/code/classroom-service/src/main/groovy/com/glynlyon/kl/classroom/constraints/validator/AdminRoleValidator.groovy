package com.glynlyon.kl.classroom.constraints.validator

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.constraints.annotation.AdminRole

class AdminRoleValidator extends AbstractValidator implements ConstraintValidator<AdminRole, String>{
		
	// only allow if the role is ADMIN

    @Override
    void initialize(AdminRole constraintAnnotation) {

    }

    public boolean isValid(String auth, ConstraintValidatorContext constraintContext) {
		return (jwtService.getRole( auth.substring( JWT_STARTING_INDEX ) ) == AppUserType.ADMIN) ? true : false
	}
			
}
