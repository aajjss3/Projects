package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.BeanDescription
import com.fasterxml.jackson.databind.JavaType
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.fasterxml.jackson.databind.ser.BeanSerializerFactory
import com.glynlyon.kl.classroom.model.ClassObj

class ClassObjSerializer extends JsonSerializer<ClassObj>{

    @Override
    void serialize(ClassObj value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        gen.writeStartObject()
        JavaType javaType = serializers.constructType(ClassObj.class);
        BeanDescription beanDesc = serializers.getConfig().introspect(javaType);
        JsonSerializer<Object> serializer = BeanSerializerFactory.instance.findBeanSerializer(serializers, javaType, beanDesc);
        serializer.unwrappingSerializer(null).serialize(value, gen, serializers)
        gen.writeObjectField("status", value.state)
        gen.writeEndObject()
    }
}
