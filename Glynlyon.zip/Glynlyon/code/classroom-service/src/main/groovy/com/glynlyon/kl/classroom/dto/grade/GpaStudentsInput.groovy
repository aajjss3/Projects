package com.glynlyon.kl.classroom.dto.grade

import com.fasterxml.jackson.annotation.JsonProperty
import groovy.transform.EqualsAndHashCode
import groovy.transform.ToString

@ToString(includeNames = true)
@EqualsAndHashCode
public class GpaStudentsInput {
    List<Student> students

    @ToString(includeNames = true)
    @EqualsAndHashCode
    static class Student {
        String id
        List<Score> assignments
    }

    @ToString(includeNames = true)
    @EqualsAndHashCode
    static class Score {
        BigDecimal score

        @JsonProperty(value = "max_score")
        BigDecimal maxScore
    }
}