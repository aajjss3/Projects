package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.dto.EventDTO
import com.glynlyon.kl.classroom.model.EventLoginLogout
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.EventRepo
import com.glynlyon.kl.classroom.repo.UserRepo

import javax.transaction.Transactional
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class EventService{
	
	
	@Autowired
	EventRepo eventRepo

	@Autowired
	UserRepo userRepo

	
	
	/**
	 * set the logged in time for the user by inserting into the event_login_logout table. 
	 * Do this by inserting a record into the event_login_logout table and set the logged_in field to the time passed in.
	 *
	 * If user exists then Last_Logged_In_At column in User is also updated.
	 * @param dto
	 * @param userUUID
	 * @return String representing the event uuid for the row inserted
	 */
	@Transactional
	public UUID loggedIn(EventDTO dto, UUID userUUID){
		User user = userRepo.findByUuid(userUUID)
		if(user) {
			user.setLastLoggedInAt(dto.getTime())
		}

		EventLoginLogout newEvent = new EventLoginLogout(createdAt: new Date(), createdBy: userUUID, loggedin: dto.getTime(), userUUID: userUUID )
		return eventRepo.save(newEvent).uuid
	}
	
	
	/**
	 * Set the logged out time for the user by inserting or updating into the event_login_logout table.
	 * To do this... 
	 * First retrieve the latest event_login_logout record for the userUUID passed in. the latest record is determined by the latest/max value for the logged_in field for the given userUUID. 
	 * if no record exists then insert a record in the event_login_logout table - set the logged_out field to the time passed in and the logged_in field to null.
	 * if a record exists then determine if the record already contains a value for the logged_out field. if a value exists for the logged_out field then insert a new record in the event_login_logout table. 
	 * if a value does not exist for the logged_out field then update this record by setting the logged_out field to the time passed in. 
	 * @param dto
	 * @param userUUID
	 * @return String representing the event uuid for the row inserted/updated
	 */
	@Transactional
	public UUID loggedOut(EventDTO dto, UUID userUUID){
		EventLoginLogout existingEvent = eventRepo.retrieveCurrentLogin(userUUID)
		if( !existingEvent ){
			EventLoginLogout newEvent = new EventLoginLogout(createdAt: new Date(), createdBy: userUUID, loggedout: dto.getTime(), userUUID: userUUID )
			return eventRepo.save(newEvent).uuid
		}
		else{
			existingEvent.loggedout = dto.getTime()
			existingEvent.updatedBy = userUUID
			existingEvent.updatedAt = new Date()
			return existingEvent.uuid
		}
	}

}
