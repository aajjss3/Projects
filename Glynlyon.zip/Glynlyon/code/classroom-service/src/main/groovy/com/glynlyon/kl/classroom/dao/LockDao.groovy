package com.glynlyon.kl.classroom.dao

import com.glynlyon.kl.classroom.model.Lock

import java.util.UUID
import javax.persistence.LockModeType
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.NoResultException
import org.hibernate.LockOptions
import org.hibernate.NonUniqueResultException
import org.hibernate.Query
import org.hibernate.Session
import org.hibernate.SessionFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Repository
import org.springframework.transaction.annotation.Transactional
import org.hibernate.LockMode

@Repository
class LockDao {
	
	@PersistenceContext
	protected EntityManager entityManager
	

	/**
	 * Retrieve a Lock object for a given resourceUuid using pessimistic locking. 
	 * @param resourceUuid
	 * @return Lock object or null if no lock exists
	 * @throws NonUniqueResultException
	 */
	public Lock getLockByResourcePessimistically(UUID resourceUuid) throws NonUniqueResultException{
		try{
			return entityManager.createQuery("select l from Lock l where l.resourceUuid = :resourceUuid", Lock.class).setParameter("resourceUuid", resourceUuid).setLockMode( LockModeType.PESSIMISTIC_WRITE ).getSingleResult()
		}
		catch(NoResultException nre){
			return null
		}	
	}
   

}
