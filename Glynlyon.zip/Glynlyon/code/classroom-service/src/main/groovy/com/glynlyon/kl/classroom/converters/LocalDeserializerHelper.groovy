package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.databind.DeserializationContext
import com.glynlyon.kl.classroom.exceptions.FieldNotFoundException
import com.glynlyon.kl.classroom.repo.LocalRepo

class LocalDeserializerHelper {
    static <T> T deserialize(JsonParser p,
                             DeserializationContext context,
                             LocalRepo<T> crudRepository, String field, String objName) {
        UUID uuid = UUID.fromString(p.getValueAsString())
        T obj = crudRepository.findByUuid(uuid)
        if (obj == null) {
            throw new FieldNotFoundException(field, "Could not find ${objName} with uuid ${uuid}")
        }
        return obj
    }
}

