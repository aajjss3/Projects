package com.glynlyon.kl.classroom.repo

import java.util.Map
import java.util.UUID
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.PagingAndSortingRepository
import org.springframework.data.repository.query.Param
import com.glynlyon.kl.classroom.dto.EnrollmentTimeOnTaskDTO
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Role

interface EnrollmentRepo extends PagingAndSortingRepository<Enrollment, UUID>, JpaSpecificationExecutor<Enrollment> {
	
    Integer countByUserUuidAndClassObjUuid(UUID uuid, UUID classObjUuid)

    @Query(value = "select role, count(*) from Enrollment e where e.classObj.uuid = :classUuid group by e.role")
    List countEnrollmentsByRole(@Param("classUuid") UUID classObjUuid)
    Integer countAllByUserUuidAndClassObjUuid(UUID uuid, UUID classUuid)
    Integer countAllByUserUuidAndClassObjUuidAndRole(UUID uuid, UUID classUuid, Role role)

    List<Enrollment> findAllByUserUuid(UUID uuid)
    List<Enrollment> findAllByUserUuidAndRole(UUID uuid, Role role)
    List<Enrollment> findAllByClassObjUuid(UUID uuid)
    List<Enrollment> findAllByClassObjUuidAndRole(UUID classUuid, Role role)
    Page<Enrollment> findAllByUserUuid(UUID uuid, Pageable pageable)

    Enrollment findByClassObjUuidAndUserUuidAndRole(UUID classUuid, UUID userUuid, Role role)

    List<Enrollment> deleteAllByClassObjUuid(UUID uuid)
		
	// determine the total time on task for all attempts for a given enrollment. this method accepts a collection of enrollments. 
	// the list returned contains a collection of TimeOnTaskDTO objects - each DTO contains the enrollment uuid and the total time on task for that enrollment.
	// This can NOT be a native query - injecting a DTO (i.e. TimeOnTaskDTO) in sql does not work with native queries
	@Query(value = "select new com.glynlyon.kl.classroom.dto.EnrollmentTimeOnTaskDTO( e.uuid, sum(att.timeOnTaskSeconds) ) from PageAssignment pa, PlannerEntry pe, Enrollment e, Attempt att where e.user = pe.user and att.plannerEntry = pe and e.classObj = pe.classObj and pa.pageObj = pe.pageObj and pe.assignment = pa.assignment and e in (:enrollments) group by e.uuid")
	List<EnrollmentTimeOnTaskDTO> getTotalTimeOnTask(@Param("enrollments") List<Enrollment> enrollments)
}
