package com.glynlyon.kl.classroom.converters

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonSerializer
import com.fasterxml.jackson.databind.SerializerProvider
import com.glynlyon.kl.classroom.model.Organization
import org.springframework.beans.factory.annotation.Value

class CustomOrganizationSerializer extends JsonSerializer<Organization> {


    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    @Override
    void serialize(Organization org, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {

        gen.writeStartObject()
        gen.writeStringField("organization_uuid", org.uuid.toString())
        gen.writeStringField("name", org.name)
        gen.writeObjectField("_links", ["self": ["href": "${rosteringBaseUri}" + "/orgs/" + org.uuid]])
        gen.writeEndObject()
    }
}