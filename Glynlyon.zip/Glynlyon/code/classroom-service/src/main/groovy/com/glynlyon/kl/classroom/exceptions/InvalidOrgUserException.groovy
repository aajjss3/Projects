package com.glynlyon.kl.classroom.exceptions

/**
 *  This exception is thrown if no match found for filter
 *
 */
class InvalidOrgUserException extends RuntimeException {
    InvalidOrgUserException() {
        super()
    }

    InvalidOrgUserException(String message) {
        super(message)
    }

    InvalidOrgUserException(String message, Throwable cause) {
        super(message, cause)
    }

    InvalidOrgUserException(Throwable cause) {
        super(cause)
    }

    protected InvalidOrgUserException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}

