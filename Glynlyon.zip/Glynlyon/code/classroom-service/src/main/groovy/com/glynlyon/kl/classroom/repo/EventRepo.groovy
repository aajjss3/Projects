package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.EventLoginLogout

import java.util.UUID

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param



interface EventRepo extends CrudRepository<EventLoginLogout, UUID>, LocalRepo<EventLoginLogout>{
	
	@Query(value = "select * from {h-schema}event_login_logout where user_uuid = :userUUID and logged_out is null and logged_in = (select max(logged_in) from {h-schema}event_login_logout where user_uuid = :userUUID)", nativeQuery = true)
	public EventLoginLogout retrieveCurrentLogin(@Param("userUUID") UUID userUUID)

}
