package com.glynlyon.kl.classroom.model

enum Status {
    ACTIVE,
    INACTIVE
}