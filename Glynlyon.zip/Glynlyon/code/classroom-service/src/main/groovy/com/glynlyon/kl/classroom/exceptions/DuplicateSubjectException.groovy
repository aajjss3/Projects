package com.glynlyon.kl.classroom.exceptions

/**
 *  This exception is thrown if no match found for filter
 *
 */
class DuplicateSubjectException extends RuntimeException {
    DuplicateSubjectException() {
        super()
    }

    DuplicateSubjectException(String message) {
        super(message)
    }

    DuplicateSubjectException(String message, Throwable cause) {
        super(message, cause)
    }

    DuplicateSubjectException(Throwable cause) {
        super(cause)
    }

    protected DuplicateSubjectException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace)
    }
}

