package com.glynlyon.kl.classroom.util

import org.springframework.http.MediaType


class Constants {
    public static final Integer PAGE_OFFSET_DEFAULT = 0
    public static final Integer PAGE_LIMIT_DEFAULT = 10
    public static final String PAGE_SIZE = "page_size"
    public static final String TOTAL_PAGES = "total_pages"
    public static final String CURRENT_PAGE = "current_page"
    public static final String DEFAULT_SUBJECT_SORT = "name"
    public static final String DEFAULT_CLASS_SORT = "name"
    public static final String DEFAULT_PAGE_SORT = "sequence"
    public static final String DEFAULT_PAGE_ASSIGNMENT_SORT = "sequence"
    public static final String DEFAULT_PLANNER_ENTRY_SORT = "slot,status"
    public static final String DEFAULT_ENROLLMENT_SORT = "class_uuid"
	public static final String DEFAULT_ATTEMPT_SORT = "created_at"
    public final static String DEFAULT_ACADEMICDESSION_SORT = "start_date"
    public static final String DEFAULT_USER_SORT = "last_name"
    public static final String DEFAULT_PAGE_ATTEMPTS_SORT = "state"
    public static final String DEFAULT_ITEM_ANALYSIS_SORT = "completed_at"
    public static final String DEFAULT_SYNC_SORT = "started_at"
    public final static String SUBJECTS_VERSION_1 = 'application/vnd.subjects.v1+json'
    public final static MediaType SUBJECTS_VERSION_1_MT = new MediaType(SUBJECTS_VERSION_1.split('/')[0], SUBJECTS_VERSION_1.split('/')[1])
    public final static String SUBJECTS_MESSAGES_VERSION_1 = 'application/vnd.subjects.messages.v1+json'
    public final static MediaType SUBJECTS_MESSAGES_VERSION_1_MT = new MediaType(SUBJECTS_MESSAGES_VERSION_1.split('/')[0], SUBJECTS_MESSAGES_VERSION_1.split('/')[1])
    public final static String CLASSES_VERSION_1 = 'application/vnd.classes.v1+json'
    public final static MediaType CLASSES_VERSION_1_MT = new MediaType(CLASSES_VERSION_1.split('/')[0], CLASSES_VERSION_1.split('/')[1])
    public final static String COURSES_VERSION_1 = 'application/vnd.courses.v1+json'
    public final static MediaType COURSES_VERSION_1_MT = new MediaType(COURSES_VERSION_1.split('/')[0], COURSES_VERSION_1.split('/')[1])
    public final static String PAGES_VERSION_1 = 'application/vnd.pages.v1+json'
    public final static MediaType PAGES_VERSION_1_MT = new MediaType(PAGES_VERSION_1.split('/')[0], PAGES_VERSION_1.split('/')[1])
    public final static String PAGE_ASSIGNMENTS_VERSION_1 = 'application/vnd.pages.assignments.v1+json'
    public final static MediaType PAGE_ASSIGNMENTS_VERSION_1_MT = new MediaType(PAGE_ASSIGNMENTS_VERSION_1.split('/')[0], PAGE_ASSIGNMENTS_VERSION_1.split('/')[1])
    public final static String ENROLLMENT_VERSION_1 = 'application/vnd.enrollments.v1+json'
    public final static MediaType ENROLLMENT_VERSION_1_MT = new MediaType(ENROLLMENT_VERSION_1.split('/')[0], ENROLLMENT_VERSION_1.split('/')[1])
    public final static String ENROLLMENT_MESSAGES_VERSION_1 = 'application/vnd.enrollments.messages.v1+json'
    public final static MediaType ENROLLMENT_MESSAGES_VERSION_1_MT = new MediaType(ENROLLMENT_MESSAGES_VERSION_1.split('/')[0], ENROLLMENT_MESSAGES_VERSION_1.split('/')[1])
    public final static String ENROLLMENT_PARAMS_VERSION_1 = 'application/vnd.enrollments.params.v1+json'
    public final static MediaType ENROLLMENT_PARAMS_VERSION_1_MT = new MediaType(ENROLLMENT_PARAMS_VERSION_1.split('/')[0], ENROLLMENT_PARAMS_VERSION_1.split('/')[1])
    public final static String ACADEMICSESSIONS_VERSION_1 = 'application/vnd.academicsessions.v1+json'
    public final static MediaType ACADEMICSESSIONS_VERSION_1_MT = new MediaType(ACADEMICSESSIONS_VERSION_1.split('/')[0], ACADEMICSESSIONS_VERSION_1.split('/')[1])
    public final static String USERS_VERSION_1 = 'application/vnd.gl.users.v1+json'
    public final static MediaType USERS_VERSION_1_MT = new MediaType(USERS_VERSION_1.split('/')[0], USERS_VERSION_1.split('/')[1])
    public final static String PLANNER_ENTRIES_VERSION_1 = 'application/vnd.plannerentries.v1+json'
    public final static MediaType PLANNER_ENTRIES_VERSION_1_MT = new MediaType(PLANNER_ENTRIES_VERSION_1.split('/')[0], PLANNER_ENTRIES_VERSION_1.split('/')[1])
    public final static String PLANNER_ENTRIES_REVIEWS_VERSION_1 = 'application/vnd.attempts.reviews.init.v1+json'
    public final static MediaType PLANNER_ENTRIES_REVIEWS_VERSION_1_MT = new MediaType(PLANNER_ENTRIES_REVIEWS_VERSION_1.split('/')[0], PLANNER_ENTRIES_REVIEWS_VERSION_1.split('/')[1])
    public final static String PLANNER_ENTRY_PARAMS_VERSION_1 = 'application/vnd.plannerentries.params.v1+json'
    public final static MediaType PLANNER_ENTRY_PARAMS_VERSION_1_MT = new MediaType(PLANNER_ENTRY_PARAMS_VERSION_1.split('/')[0], PLANNER_ENTRY_PARAMS_VERSION_1.split('/')[1])
    public final static String ATTEMPTS_VERSION_1 = 'application/vnd.plannerentries.attempts.v1+json'
    public final static MediaType ATTEMPTS_VERSION_1_MT = new MediaType(ATTEMPTS_VERSION_1.split('/')[0], ATTEMPTS_VERSION_1.split('/')[1])
    public final static String PAGE_ATTEMPTS_VERSION_1 = 'application/vnd.pages.attempts.v1+json'
    public final static MediaType PAGE_ATTEMPTS_VERSION_1_MT = new MediaType(PAGE_ATTEMPTS_VERSION_1.split('/')[0], PAGE_ATTEMPTS_VERSION_1.split('/')[1])
    public final static String REVIEWS_OVERRIDES_VERSION_1 = 'application/vnd.attempts.reviews.overrides.v1+json'
    public final static MediaType REVIEWS_OVERRIDES_VERSION_1_MT = new MediaType(REVIEWS_OVERRIDES_VERSION_1.split('/')[0], REVIEWS_OVERRIDES_VERSION_1.split('/')[1])
    public final static String PAGE_ASSIGNMENTS_REPORT_VERSION_1 = 'application/vnd.pages.assignments.attempts.reports.init.v1+json'
    public final static MediaType PAGE_ASSIGNMENTS_REPORT_VERSION_1_MT = new MediaType(PAGE_ASSIGNMENTS_REPORT_VERSION_1.split('/')[0], PAGE_ASSIGNMENTS_REPORT_VERSION_1.split('/')[1])
    public final static String LOCKS_VERSION_1 = 'application/vnd.locks.v1+json'
    public final static MediaType LOCKS_VERSION_1_MT = new MediaType(LOCKS_VERSION_1.split('/')[0], LOCKS_VERSION_1.split('/')[1])
    public final static String PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1 = 'application/vnd.pages.assignments.attempts.reports.request.v1+json'
    public final static MediaType PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1_MT = new MediaType(PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1.split('/')[0], PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1.split('/')[1])
	public final static String SETTING_VERSION_1 = 'application/vnd.settings.v1+json'
	public final static MediaType SETTING_VERSION_1_MT = new MediaType(SETTING_VERSION_1.split('/')[0], SETTING_VERSION_1.split('/')[1])
	public final static String SETTING_ALL_CLASSES_VERSION_1 = 'application/vnd.orgs.users.settings.v1+json'
	public final static MediaType SETTING_ALL_CLASSES_VERSION_1_MT = new MediaType(SETTING_ALL_CLASSES_VERSION_1.split('/')[0], SETTING_ALL_CLASSES_VERSION_1.split('/')[1])
    public final static String PAGES_ASSIGNMENTS_SCORES_VERSION_1 = 'application/vnd.pages.assignments.scores.v1+json'
    public final static MediaType PAGES_ASSIGNMENTS_SCORES_VERSION_1_MT = new MediaType(PAGES_ASSIGNMENTS_SCORES_VERSION_1.split('/')[0], PAGES_ASSIGNMENTS_SCORES_VERSION_1.split('/')[1])
    public final static String STUDENTS_SCORES_VERSION_1 = 'application/vnd.students.scores.v1+json'
    public final static MediaType STUDENTS_SCORES_VERSION_1_MT = new MediaType(STUDENTS_SCORES_VERSION_1.split('/')[0], STUDENTS_SCORES_VERSION_1.split('/')[1])
    public final static String ITEM_ANALYSIS_REPORT_VERSION_1 = 'application/vnd.pages.assignments.reports.itemAnalysis.v1+json'
    public final static MediaType ITEM_ANALYSIS_REPORT_VERSION_1_MT = new MediaType(ITEM_ANALYSIS_REPORT_VERSION_1.split('/')[0], ITEM_ANALYSIS_REPORT_VERSION_1.split('/')[1])
	public static final String ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1 = "application/vnd.attempts.reviews.histories.v1+json"
	public static final String EVENT_CONTENT_TYPE = "application/vnd.events.v1+json"
	public static final String EVENT_ACCEPT = "application/vnd.events.v1+json"
	
    public final static String CLASS_DELETE_GRACE_PERIOD_HOURS_KEY = "class_delete_grace_period_hours"

    public final static String OW_ISSUER = "ow-v2"
}
