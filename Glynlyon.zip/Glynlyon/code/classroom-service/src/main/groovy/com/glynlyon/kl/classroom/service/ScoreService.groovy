package com.glynlyon.kl.classroom.service

import java.util.List
import com.glynlyon.kl.classroom.dao.AttemptDao
import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsInput
import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsResponse
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsInput
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsResponse
import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsResponse.AssignmentResponse
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsResponse.StudentsResponse
import com.glynlyon.kl.classroom.exceptions.BadRequestException
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.util.ScoreMapUtil
import com.glynlyon.learnosity.exception.LearnosityStatusCodeException
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import org.apache.logging.log4j.Level
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ScoreService {

    static final MAX_SESSIONS_PER_REQUEST = 1000

    @Autowired
    AttemptDao attemptDao

    @Autowired
    GpaService gpaService

    @Autowired
    LearnosityDataService learnosityDataService

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    EnrollmentRepo enrollmentRepo
	
	@Autowired
	SettingService settingService
	
	@Autowired
	ScoreMapUtil scoreMapUtil

    public GpaAssignmentsResponse getAssignmentScores(PageObj pageObj, String filter, String domain) {
        Map<UUID, List<PageAttemptDTO>> groupedFilteredAttempts = groupAndFilterAttemptsByAssignment(pageObj.uuid, filter)
        List<String> learnositySessionKeys = groupedFilteredAttempts.values().findAll{it.first()}.collect{String.valueOf(it.first().attemptUuid)}
        Map<String, LearnosityGetAllSessionsResponse> learnosityResponse = getLearnositySessions(learnositySessionKeys, domain)
        GpaAssignmentsResponse response = gpaService.calculateAssignmentScores(createGpaAssignmentsInput(groupedFilteredAttempts, learnosityResponse))
		
		// get score setting values and set the earned scores grade and numeric value on the GpaAssignmentsResponse as a map
		SettingDTO settingDTO = settingService.findClassSettings(pageObj.classObj.uuid)
		for( AssignmentResponse assignment : response.assignments ){
			assignment.averageScores.putAll( scoreMapUtil.getScoreAsMap( settingDTO.value.classroom.gradeDisplay.letter, settingDTO.value.classroom.gradeDisplay.percentage, settingDTO.value.classroom.gradeScale, assignment.averageScore ) )
		}
		
		return response
    }


    public GpaStudentsResponse getStudentScoresByPage(PageObj pageObj, String filter, String domain) {
        Map<UUID, List<PageAttemptDTO>> studentGrouped = groupAndFilterAttemptsByStudent(pageObj, filter)
        return getStudentScores(studentGrouped, domain, pageObj.classObj)
    }

    public GpaStudentsResponse getStudentScoresByClass(ClassObj classObj, String filter, String domain) {
        Map<UUID, List<PageAttemptDTO>> studentGrouped = groupAndFilterAttemptsByStudent(classObj, filter)
        return getStudentScores(studentGrouped, domain, classObj)
    }

    public GpaStudentsResponse getStudentScores(Map<UUID, List<PageAttemptDTO>> studentGrouped, String domain, ClassObj classObj) {
        Map<UUID, String> learnosityMap = (Map<UUID, String>)studentGrouped.collect{userUuid, listOfAttempts ->
            listOfAttempts.collect{
                [(it.pageAssignmentUuid): listOfAttempts.first().attemptUuid.toString()]
            }.sum()
        }.sum()
		
		if( learnosityMap == null ){
			return new GpaStudentsResponse(students : new ArrayList(), failures :new ArrayList())
		}
			
		List<String> learnositySessionKeys = learnosityMap.values().collect{it.toString()}.unique()
		Map<String, LearnosityGetAllSessionsResponse> learnosityResponse = getLearnositySessions(learnositySessionKeys, domain)
        GpaStudentsResponse response =  gpaService.calculateStudentScores(createGpaStudentsInput(studentGrouped, learnosityResponse, learnosityMap))
	
		// get score setting values and set the earned scores grade and numeric value on the GpaStudentsResponse as a map
		SettingDTO settingDTO = settingService.findClassSettings(classObj.uuid)
		for( StudentsResponse student : response.students ){
			student.earnedScores.putAll( scoreMapUtil.getScoreAsMap( settingDTO.value.classroom.gradeDisplay.letter, settingDTO.value.classroom.gradeDisplay.percentage, settingDTO.value.classroom.gradeScale, student.scoreEarned ) )
		}
		
		return response
    }

    /**
     * @param learnositySessionKeys
     * @param domain
     * @return call learnosity sessions endpoint for all input sessions (batched in chunks of 1000 for safety) and return
     * merged map of results
     */
    Map<String, LearnosityGetAllSessionsResponse> getLearnositySessions(List<String> learnositySessionKeys, String domain){

        return (Map<String, LearnosityGetAllSessionsResponse>)learnositySessionKeys.collate(MAX_SESSIONS_PER_REQUEST).collect {
            if(it.size()) {
                try {
                    return learnosityDataService.getClient(domain).getAllSessionsResponsesBySessions(it)
                }
                catch (LearnosityStatusCodeException e){
                    throw new BadRequestException("failed to get scores from learnosity. domain: ${domain}, sessions: ${it}", Level.ERROR, e)
                }
            }
            return [:]
        }.sum()
    }

    /**
     * @param groupedFilteredAttempts
     * @param learnosityResponse
     * @return assemble input payload for gpa assignments endpoint
     */
    static GpaAssignmentsInput createGpaAssignmentsInput(Map<UUID, List<PageAttemptDTO>> groupedFilteredAttempts, Map<String, LearnosityGetAllSessionsResponse> learnosityResponse){
        return new GpaAssignmentsInput(
                assignments : groupedFilteredAttempts.collect {UUID pageAssignmentUuid, List<PageAttemptDTO> values ->
                    String learnosityKey = String.valueOf(values.first().attemptUuid)
                    return new GpaAssignmentsInput.Assignment(
                            id: pageAssignmentUuid,
                            students : values.collect {
                                Double maxScore = learnosityResponse.get(learnosityKey).maxScore
                                return new GpaAssignmentsInput.Score(
                                        score: it.assessmentScore * maxScore,
                                        maxScore: maxScore
                                )
                            }
                    )
                }
        )
    }

    /**
     * @param groupedFilteredAttempts
     * @param learnosityResponse
     * @return assemble input payload for gpa students endpoint
     */
    static GpaStudentsInput createGpaStudentsInput(Map<UUID, List<PageAttemptDTO>> groupedFilteredAttempts, Map<String, LearnosityGetAllSessionsResponse> learnosityResponse, Map<UUID, String> learnosityMap){
		 return new GpaStudentsInput(
                students : groupedFilteredAttempts.collect {UUID studentUuid, List<PageAttemptDTO> values ->
                    return new GpaStudentsInput.Student(
                            id: studentUuid,
                            assignments : values.collect {
                                BigDecimal maxScore = learnosityResponse.get(learnosityMap.get(it.pageAssignmentUuid)).maxScore
                                return new GpaStudentsInput.Score(
                                        score: it.assessmentScore * maxScore,
                                        maxScore: maxScore
                                )
                            }
                    )
                }
        )
    }


    /**
     * @param pageUuid
     * @param filter
     * @return Map of pageAssignmentUuidA -> [PageAttemptDTO1, PageAttemptDTO2...]
     * pageAssignments that aren't in page and optional filter are not included
     * pageAssignments that don't have any attempts with an assessment score aren't included
     */
    Map<UUID, List<PageAttemptDTO>> groupAndFilterAttemptsByAssignment(UUID pageUuid, String filter){
        List<UUID> pageAssignmentUuids = []
        if(filter){
            try {
                pageAssignmentUuids = filter.split(",").collect{UUID.fromString(it.trim())}
            }
            catch (Throwable t) {
                throw new BadRequestException("Invalid filter input ${filter}", Level.ERROR, t)
            }
        }
        else {
            pageAssignmentUuids = pageAssignmentRepo.findAllByPageObjUuid(pageUuid).uuid
        }

        return attemptDao.findLatestByPageUuid(pageUuid).findAll {
            it.pageAssignmentUuid in pageAssignmentUuids && it.assessmentScore != null
        }.groupBy {
            it.pageAssignmentUuid
        }
    }

    /**
     * @param pageObj
     * @param filter
     * @return Map of pageAssignmentUuidA -> [PageAttemptDTO1, PageAttemptDTO2...]
     * students that aren't in optional filter are not included
     * students that don't have any attempts with an assessment score aren't included
     */
    Map<UUID, List<PageAttemptDTO>> groupAndFilterAttemptsByStudent(PageObj pageObj, String filter){
        List<UUID> studentUuids = getUuidsByFilterOrClass(filter, pageObj.classObj.uuid)

        return attemptDao.findLatestByPageUuid(pageObj.uuid).findAll {
            it.userUuid in studentUuids && it.assessmentScore != null
        }.groupBy {
            it.userUuid
        }
    }

    /**
     * @param classObj
     * @param filter
     * @return Map of pageAssignmentUuidA -> [PageAttemptDTO1, PageAttemptDTO2...]
     * students that aren't in optional filter are not included
     * students that don't have any attempts with an assessment score aren't included
     */
    Map<UUID, List<PageAttemptDTO>> groupAndFilterAttemptsByStudent(ClassObj classObj, String filter){
        List<UUID> studentUuids = getUuidsByFilterOrClass(filter, classObj.uuid)

        return attemptDao.findLatestByClassUuid(classObj.uuid).findAll {
            it.userUuid in studentUuids && it.assessmentScore != null
        }.groupBy {
            it.userUuid
        }
    }

    private List<UUID> getUuidsByFilterOrClass(String filter, UUID classUuid){
        if(filter){
            try {
                return filter.split(",").collect{UUID.fromString(it.trim())}
            }
            catch (Throwable t) {
                throw new BadRequestException("Invalid filter input ${filter}", Level.ERROR, t)
            }
        }
        else {
            return enrollmentRepo.findAllByClassObjUuidAndRole(classUuid, Role.STUDENT).collect{it.user.uuid}
        }
    }
		
	
}
