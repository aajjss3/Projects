package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.DisabledSubject
import com.glynlyon.kl.classroom.model.UuidOrgId
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.CrudRepository

interface DisabledSubjectRepo extends CrudRepository<DisabledSubject, UuidOrgId>, JpaSpecificationExecutor{

}