package com.glynlyon.kl.classroom.exceptions

import org.apache.logging.log4j.Level

/**
 * Base Exception class that all exceptions should extend from. 
 * 
 * @author asparago
 *
 */
abstract class CustomException extends RuntimeException{
	
	
	boolean isLoggable = false   // if the exception should be logged. default to no logging
	Throwable rootCause //the root exception if there is one
	Level logLevel // the log level to use if the exception should be logged

	/**
	 * call this constructor if no logging is desired
	 * @param message - the message to send back to the client
	 */
	public CustomException(String message){
		super(message)
	}
	
	/**
	 * call this constructor if logging is desired but there is no underlying exception to log
	 * @param message - the message to log and to send back to the client
	 * @param logLevel  - the log level to use
	 */
	public CustomException(String message, Level logLevel){
		super(message)
		this.isLoggable = true
		this.logLevel = logLevel
	}
	
	/**
	 * call this constructor if logging is desired and you wish to log the underlying exception
	 * @param message - the message to log and to send back to the client
	 * @param logLevel - the log level to use
	 * @param rootCause - the underlying exception to log
	 */
	public CustomException(String message, Level logLevel, Throwable rootCause){
		super(message)
		this.isLoggable = true
		this.logLevel = logLevel
		this.rootCause = rootCause
	}

}
