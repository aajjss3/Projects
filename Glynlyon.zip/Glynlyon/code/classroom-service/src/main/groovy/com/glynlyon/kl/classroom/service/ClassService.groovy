package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.exceptions.BadRequestException
import com.glynlyon.kl.classroom.exceptions.ClassObjNotFoundException
import com.glynlyon.kl.classroom.exceptions.ForbiddenException
import com.glynlyon.kl.classroom.exceptions.NotFoundException
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.ErrorOutput
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.util.Constants
import groovy.time.TimeCategory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.domain.Specification
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

import javax.persistence.criteria.CriteriaBuilder
import javax.persistence.criteria.CriteriaQuery
import javax.persistence.criteria.Expression
import javax.persistence.criteria.JoinType
import javax.persistence.criteria.ListJoin
import javax.persistence.criteria.Predicate
import javax.persistence.criteria.Root

import static org.springframework.data.jpa.domain.Specifications.where

@Service
class ClassService extends AbstractService{

    @Autowired
    ClassRepo classRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    JwtService jwtService

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    ClassGradeLevelService classGradeLevelService

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    FilterService filterService

    @Autowired
    PageRepo pageRepo

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    ConfigurationService configurationService

    @Transactional
    public ClassObj create(ClassObj input, InputMapperService.MappingResult<ClassObj> mappingResult, String token) {
        AppUserType appUserType = jwtService.getRole(token)
		
		if( !input.subject && !mappingResult.errors.findAll { e -> e.field == "subject_uuid" } ){
			mappingResult.errors.add("field": "subject_uuid", message: "Missing required field subject_uuid")
		}

        UUID organizationUUID = input?.organization?.uuid
        if(organizationUUID) {
            // Check admin permissions
            try {
                adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), organizationUUID, appUserType)
            } catch (e) {
                mappingResult.errors.add("field": "organization_uuid", message: e.message)
            }
        }
		
        def errors = mappingResult.errors.findAll { e -> e.field == "grade_level" || e.field == "academic_session_uuid" || e.field == "organization_uuid" || e.field == "subject_uuid"}
        def grades = input.grades?.grade ?: []
        input.grades = []
        def classObj = classRepo.saveAndFlush(input)
        if (errors) {
            throw new RuntimeException()
        }
        classObj.grades = classGradeLevelService.save(classObj.uuid, grades)

        if(appUserType == AppUserType.TEACHER) {
            enrollmentRepo.save(new Enrollment(primaryRole: true, classObj: classObj, user: userRepo.findOne(classObj.creatorUuid),
                    role: Role.TEACHER, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        }

        return classObj
    }

    @Transactional
    public ClassObj update(ClassObj input, InputMapperService.MappingResult<ClassObj> mappingResult, String token) {
        AppUserType appUserType = jwtService.getRole(token)
        UUID userUuid = UUID.fromString(jwtService.getUuid(token))
		
		if( !input.subject && !mappingResult.errors.findAll { e -> e.field == "subject_uuid" } ){
			mappingResult.errors.add("field": "subject_uuid", message: "Missing required field subject_uuid")
		}

        UUID organizationUUID = input?.organization?.uuid
        if(organizationUUID) {
            // Check admin permissions
            try {
                adminOrganizationValidation(UUID.fromString(jwtService.getUuid(token)), organizationUUID, appUserType)
            } catch (e) {
                mappingResult.errors.add("field": "organization_uuid", message: e.message)
            }
        }

        if(appUserType == AppUserType.TEACHER) {
            if(enrollmentRepo.countAllByUserUuidAndClassObjUuidAndRole(userUuid, input.uuid, Role.TEACHER) <= 0) {
                throw new ClassObjNotFoundException("role_in_issuer", "TEACHER is not able to edit a class they are not enrolled in.")
            }
        }
        def errors = mappingResult.errors.findAll { e -> e.field == "grade_level" || e.field == "academic_session_uuid" || e.field == "organization_uuid" || e.field == "subject_uuid"}
        def grades = input.grades?.grade ?: []
        input.grades = []
        def classObj = classRepo.saveAndFlush(input)
        if (errors) {
            throw new RuntimeException()
        }
        classObj.grades = classGradeLevelService.save(classObj.uuid, grades)
        return classObj
    }

    ClassObj validateClass(UUID classUuid, String token) {
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)
        String userUuid = jwtService.getUuid(token)

        ClassObj classObj
        if (role == AppUserType.ADMIN) {
            def filter = new Specification<ClassObj>() {
                public Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    def inOrg = builder.or(root.get("organization").get('parent').get('uuid').in(orgUuid), root.get("organization").get('uuid').in(orgUuid))
                    def uuid = builder.equal(root.get("uuid"), classUuid)
                    return builder.and(uuid, inOrg)
                }
            }
            classObj = classRepo.findOne(filter)
        }
        else if(role == AppUserType.TEACHER){
            List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole(UUID.fromString(userUuid), Role.TEACHER)
            def filter = new Specification<ClassObj>() {
                public Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                    def enrolled = enrollments ? root.get("uuid").in(enrollments.classObj.uuid) : builder.or()
                    def uuid = builder.equal(root.get("uuid"), classUuid)
                    return builder.and(uuid, enrolled)
                }
            }
            classObj = classRepo.findOne(filter)
        }
        else {
            throw new ForbiddenException("Only supported roles are ADMIN and TEACHER")
        }
        if(!classObj){
            throw new NotFoundException("Could not find class with uuid ${classUuid}")
        }
        return classObj
    }

    @Transactional
    public void delete(UUID classUuid, String token) {
        ClassObj classObj = validateClass(classUuid, token)
        if(attemptRepo.countByPlannerEntryClassObjUuid(classObj.uuid)){
            throw new BadRequestException("Cannot delete a class that has associated attempts")
        }
        enrollmentRepo.deleteAllByClassObjUuid(classObj.uuid)
        plannerEntryRepo.deleteAllByClassObjUuid(classObj.uuid)
        pageAssignmentRepo.deleteAllByPageObjClassObjUuid(classObj.uuid)
        pageRepo.deleteAllByClassObjUuid(classObj.uuid)
        classRepo.delete(classObj.uuid)
    }


    public Page findAllClasses(String token, String filter, UUID enrolledUserUuid, Boolean excludeExpiredClasses, Pageable pageable) {
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)
        String userUuid = jwtService.getUuid(token)

        Page classPage
        Closure<Specification> mainFilter

        Specification enrolledUserFilter = new Specification<ClassObj>(){
            @Override
            Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                if (enrolledUserUuid) {
                    Set<UUID> classObjUuids = new HashSet<UUID>(enrollmentRepo.findAllByUserUuid(enrolledUserUuid).classObj?.uuid)
                    if(classObjUuids) {
                        return root.get("uuid").in(classObjUuids)
                    }
                    return cb.or()
                }
                return cb.and()
            }
        }

        Specification expiredClassFilter = new Specification<ClassObj>(){
            @Override
            Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                if (excludeExpiredClasses) {

                    Integer gracePeriod = configurationService.getConfigurationByKey(Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY).value as Integer

                    def normalStates = cb.notEqual(root.get("state"), ClassObjState.COMPLETED)
                    def completedAndGracePeriod = cb.and(
                            cb.equal(root.get("state"), ClassObjState.COMPLETED),
                            cb.or(
                                    cb.greaterThan(root.get("completed"), use(TimeCategory){gracePeriod.hours.ago}),
                                    cb.isNull(root.get("completed"))
                            )
                    )
                    return cb.or(normalStates, completedAndGracePeriod)
                }
                return cb.and()
            }
        }


        Specification queryParamsFilter = where(enrolledUserFilter).and(expiredClassFilter)


        if (role == AppUserType.ADMIN) {
            Organization org = organizationRepo.findOne(orgUuid)

            if (!org) {
                return new PageImpl([new ErrorOutput(field: "sub / school_uuid", message: "no organizations found for user ${userUuid} in school ${orgUuid}")], pageable, 1)
            }

            mainFilter = (Closure<Specification>){
                def roleFilter = new Specification<ClassObj>() {
                    public Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                        return builder.or(root.get("organization").get('parent').get('uuid').in(orgUuid), root.get("organization").get('uuid').in(orgUuid))
                    }
                }
                return (Specification)(where(roleFilter).and(queryParamsFilter))
            }
        }
        else if (role == AppUserType.TEACHER) {
            List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole(UUID.fromString(userUuid), Role.TEACHER)
            mainFilter = {
                def roleFilter = new Specification<ClassObj>() {
                    public Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                        return enrollments ? root.get("uuid").in(enrollments.classObj.uuid) : builder.or()
                    }
                }
                return (Specification)(where(roleFilter).and(queryParamsFilter))
            }
        }
        else if (role == AppUserType.STUDENT) {
                List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole(UUID.fromString(userUuid), Role.STUDENT)
                mainFilter = {
                    def studentFilter = new Specification<ClassObj>() {
                        public Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                            return enrollments ? root.get("uuid").in(enrollments.classObj.uuid) : builder.or()
                        }
                    }
                    return (Specification)(where(studentFilter).and(queryParamsFilter))
                }
        }
        else {
            mainFilter = {
                return new Specification<ClassObj>(){
                    @Override
                    Predicate toPredicate(Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                        return cb.or()
                    }
                }
            }
        }

        if (filter) {
            Map<String, String> mappings = ["status":"state"]

            def listFilter = { Root<ClassObj> root, CriteriaQuery<?> query, CriteriaBuilder builder, Expression field, List value ->
                ListJoin<ClassObj, ClassGradeLevel> grades = root.joinList("grades", JoinType.LEFT)
                query.distinct(true)
                return builder.or(
                        (Predicate[])value.join('').split(',').collect {
                            builder.equal(grades.get("grade"), Grade.fromString(String.valueOf(it)))
                        }.toArray()
                )
            }
            classPage = filterService.find(filter, ClassObj, classRepo, pageable, mappings, mainFilter, listFilter)
        }
        else {
            classPage = classRepo.findAll(mainFilter(), pageable)
        }

        if (classPage.content.every{it instanceof ClassObj}) {
            classPage.content.each { ClassObj classObj ->
                addTransients(classObj, role)
            }
        }

        return classPage
    }

    public ClassObj findClass(String token, UUID uuid) {
        ClassObj classPage = findClassWithoutTransients(token, uuid)
        if (classPage) {
            classPage.each { ClassObj classObj ->
                addTransients(classObj)
            }
        }
        return classPage
    }

    public ClassObj addTransients(ClassObj classObj, AppUserType role=null){
        def teacherList
        def countList = enrollmentRepo.countEnrollmentsByRole(classObj.uuid)

        if (role && role == AppUserType.STUDENT) {
            teacherList = enrollmentRepo.findAllByClassObjUuidAndRole(classObj.uuid, Role.TEACHER)
        }
        classObj.metadata = makeMetadata(countList, teacherList)
        return classObj
    }

    private ClassObj findClassWithoutTransients(String token, UUID uuid) {
        AppUserType role = jwtService.getRole(token)
        UUID orgUuid = jwtService.getOrgUuid(token)
        String userUuid = jwtService.getUuid(token)

        Organization org = organizationRepo.findOne(orgUuid)
        if(!org){
            throw new ClassObjNotFoundException("sub / school_uuid", "no organizations found for user ${userUuid} in school ${orgUuid}", HttpStatus.UNAUTHORIZED)
        }

        ClassObj returnedClass = classRepo.findByUuid(uuid)

        if(returnedClass) {
            if (role == AppUserType.ADMIN) {
                if (returnedClass && (returnedClass.organization.uuid == orgUuid || returnedClass.organization.parent.uuid == orgUuid)) {
                    return returnedClass
                }
                return returnedClass
            } else if (role == AppUserType.TEACHER) {
                List<Enrollment> enrollments = enrollmentRepo.findAllByUserUuidAndRole(UUID.fromString(userUuid), Role.TEACHER)
                if (returnedClass in enrollments.classObj) {
                    return returnedClass
                } else {
                    throw new ClassObjNotFoundException("role_in_issuer", "Class is not visible to this user", HttpStatus.UNAUTHORIZED)
                }
            } else {
                throw new ClassObjNotFoundException("role_in_issuer", "only supported roles are ADMIN and TEACHER")
            }
        } else {
            throw new ClassObjNotFoundException("uuid", "Class does not exist", HttpStatus.NOT_FOUND)
        }
    }

    private static Map makeMetadata(List enrollmentCountList, List teacherList){
        def countMap = enrollmentCountList.collectEntries{[(((Role)it[0]).countKeyName):it[1]]}
        def defaultCountMap = [students: 0, admins: 0, teachers: 0]

        return teacherList? [counts: defaultCountMap + countMap, enrollments: teacherList] : [counts: defaultCountMap + countMap]
    }

    private static Date hoursAgo(Integer hours){
        use(TimeCategory){
            return hours.hours.ago
        }
    }
}
