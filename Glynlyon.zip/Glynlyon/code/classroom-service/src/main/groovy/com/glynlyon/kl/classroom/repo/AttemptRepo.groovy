package com.glynlyon.kl.classroom.repo

import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import org.springframework.data.jpa.repository.JpaSpecificationExecutor
import org.springframework.data.repository.PagingAndSortingRepository

interface AttemptRepo extends PagingAndSortingRepository<Attempt, UUID>, JpaSpecificationExecutor, LocalRepo<Attempt> {
	Attempt findByUuidAndUserUuidAndPlannerEntryUuid(UUID attemptUuid, UUID userUuid, UUID plannerEntryUuid)
	Attempt findByUuidAndPlannerEntryUuid(UUID uuid, UUID PlannerEntryUuid)

	Page<Attempt> findAllByPlannerEntryUuid(Pageable pageable, UUID plannerEntryUUID)
	Page<Attempt> findAllByPlannerEntryUuidAndUserUuid(Pageable pageable, UUID plannerEntryUUID, UUID userUUID)
	Page<Attempt> findAllByPlannerEntryUuidAndPlannerEntry_classObj_UuidIn(Pageable pageable, UUID plannerEntryUUID, List<UUID> classUUIDs)

	Page<Attempt> findAllByPlannerEntry_ClassObj_UuidAndUserUuid(Pageable pageable, UUID classUUID, UUID userUUID)
	Page<Attempt> findAllByPlannerEntry_ClassObj_Uuid(Pageable pageable, UUID classUUID)
	Long countByPlannerEntryClassObjUuid(UUID classUuid)

    List<Attempt> findAllByPlannerEntryUuidAndCreditBearing(UUID plannerEntryUuid, Boolean creditBearing)
    Attempt findFirstByPlannerEntryUuidAndStateNotOrderByCreatedAtDesc(UUID plannerEntryUuid, AttemptState state)

}
