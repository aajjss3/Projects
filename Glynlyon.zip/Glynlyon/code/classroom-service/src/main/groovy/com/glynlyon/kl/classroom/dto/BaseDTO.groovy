package com.glynlyon.kl.classroom.dto

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import java.lang.reflect.Field

/**
 * The input json from the request contains the field 'updateBy'. 
 * To include the field 'updateBy during json to dto deserialization (ie input) but exclude this field during dto to json serialization (ie output) see the placement of JsonProperty and JsonIgnore annotations below
 * 
 */
class BaseDTO {
	
	@JsonIgnore
	public List<String> requestFields = new ArrayList<String>()

	@JsonIgnore
	private UUID updatedBy
	
	@JsonIgnore
	public UUID getUpdatedBy() {
		return updatedBy
	}
	
	@JsonProperty(value="updated_by")
	public void setUpdatedBy(UUID updatedBy) {
		this.updatedBy = updatedBy
	}
		
}
