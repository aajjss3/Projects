package com.glynlyon.kl.classroom.dto


class LearnosityJobStatusJmsDTO implements Serializable {
    String jobId
    String domain
}
