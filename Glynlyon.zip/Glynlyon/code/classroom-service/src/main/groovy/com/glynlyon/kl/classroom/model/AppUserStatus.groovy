package com.glynlyon.kl.classroom.model

public enum AppUserStatus {
    ACTIVE("Active"),
    ON_HOLD("On Hold"),
    PENDING_ARCHIVE("Archived"),
    ARCHIVE("Archived")

    private final String displayName

    AppUserStatus(String displayName) {
         this.displayName = displayName
    }
    String getDisplayName() { return displayName }
}