databaseChangeLog logicalFilePath:'sat-3044', {

    changeSet(author: 'acaniff', id: 'add-questions-answered', context: 'schema') {
        addColumn(tableName: "attempt") {
            column(name: 'questions_answered', type: 'jsonb') {
                constraints(nullable: 'true')
            }
        }
    }
}