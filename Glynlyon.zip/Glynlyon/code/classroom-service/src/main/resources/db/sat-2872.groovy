databaseChangeLog logicalFilePath:'sat-2872', {
	
	changeSet(author: 'asparago', id: 'create_table_attempt_overrides_history', context:'schema') {
		createTable(tableName: 'attempt_overrides_history') {
			column(name: 'uuid', type: 'uuid') {
				constraints(nullable: 'false', primaryKey: 'true')
			}
			column(name: 'attempt_uuid', type: 'uuid') {
				constraints(nullable: 'false')
			}
			column(name: 'response_id', type: 'text') {
				constraints(nullable: 'false')
			}
			column(name: 'page_assignment_uuid', type: 'uuid') {
				constraints(nullable: 'false')
			}
			column(name: 'assignment_uuid', type: 'uuid') {
				constraints(nullable: 'false')
			}
			column(name: 'credit', type: 'boolean') {
				constraints(nullable: 'true')
			}
			column(name: 'date_overridden', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'false')
			}
			column(name: 'user_uuid', type: 'uuid') {
				constraints(nullable: 'false')
			}
			column(name: 'first_name', type: 'text') {
				constraints(nullable: 'true')
			}
			column(name: 'last_name', type: 'text') {
				constraints(nullable: 'true')
			}
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
			column(name: 'created_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
			column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'create_index_attempt_overrides_history', context:'schema') {
		sql("create index attempt_overrides_history_indx on \${database.defaultSchemaName}.attempt_overrides_history (attempt_uuid, response_id);")
	}
	
}