databaseChangeLog logicalFilePath:'sat-2020', {
	
		changeSet(author: 'asparago', id: 'add_updated_by', context:'schema') {
			addColumn(tableName: "launch") {
				column(name: 'updated_by', type: 'uuid') {
					constraints(nullable: 'true')
				}
			}
		}
				
	}