databaseChangeLog logicalFilePath:'sat-2936', {

    changeSet(author: 'acaniff', id: 'add-class-done', context: 'schema') {
        addColumn(tableName: "class") {
            column(name: 'done', type: 'boolean', defaultValue: 'false')
            column(name: 'done_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
        }
        addNotNullConstraint(tableName: "class", columnName: "done", columnDataType: "boolean", defaultNullValue: "false")
    }
}