databaseChangeLog logicalFilePath:'sat-2199', {

	changeSet(author: 'asparago', id: 'add_page_due_date', context:'schema') {
		
		addColumn(tableName: "page") {
			column(name: 'due_date', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		
		createIndex(indexName: "page_due_date_idx", tableName: "page") {
			column(name: "due_date")
		}

	}
	
}