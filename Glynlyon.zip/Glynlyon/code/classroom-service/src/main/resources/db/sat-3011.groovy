databaseChangeLog logicalFilePath:'sat-3011', {

	changeSet(author: 'asparago', id: 'delete_all_attempt_overrides_history', context:'schema') {
		sql("delete from \${database.defaultSchemaName}.attempt_overrides_history;")
	}
}