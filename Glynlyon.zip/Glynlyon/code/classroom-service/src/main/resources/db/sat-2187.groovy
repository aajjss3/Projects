databaseChangeLog logicalFilePath:'sat-2187', {
	
	changeSet(author: "asparago", id: "delete_records_setting_table", context:"schema") {
		sql("delete from \${database.defaultSchemaName}.setting where key = 'attempt_count_limit' or key ='project_pass_threshold' or key ='lesson_pass_threshold';")
	}
	
	changeSet(author: "asparago", id: "rename_setting_table", context:"schema") {
		sql("ALTER TABLE \${database.defaultSchemaName}.setting RENAME TO configuration;")
	}
	
	changeSet(author: "asparago", id: "rename_configuration_key_index", context:"schema") {
		sql("ALTER INDEX \${database.defaultSchemaName}.setting_key_idx RENAME TO configuration_key_idx;")
	}
	
	changeSet(author: "asparago", id: "rename_configuration_primary_key", context:"schema") {
		sql("ALTER TABLE \${database.defaultSchemaName}.configuration RENAME CONSTRAINT pk_setting TO pk_configuration;")
	}
	
	changeSet(author: "asparago", id: "recreate_setting_table", context:"schema") {
		sql("CREATE TABLE \${database.defaultSchemaName}.setting( uuid uuid NOT NULL, source_uuid uuid, value jsonb NOT NULL, type text NOT NULL, created_at timestamp with time zone, created_by uuid, updated_at timestamp with time zone, updated_by uuid, version bigint, PRIMARY KEY (uuid), CONSTRAINT setting_source_uniq_const UNIQUE (source_uuid))	WITH ( OIDS = FALSE	) TABLESPACE pg_default;")
	}
	
	changeSet(author: "asparago", id: "change_owner_setting_table", context:"schema") {
		sql("ALTER TABLE \${database.defaultSchemaName}.setting OWNER to classroom_service;")
	}
	
	changeSet(author: "asparago", id: "setting_source_index", context:"schema") {
		createIndex(indexName: "setting_source_idx", tableName: "setting") {
			column(name: "source_uuid")
		}
	}
	
	changeSet(author: "asparago", id: "setting_type_index", context:"schema") {
		createIndex(indexName: "setting_type_idx", tableName: "setting") {
			column(name: "type")
		}
	}

	changeSet(author: "acaniff", id: "setting_data_load", context:"bootstrap") {
		insert(tableName:"setting") {
			column(name: 'uuid', valueComputed: "uuid_generate_v4()")
			column(name: 'type', value: 'GLOBAL')
			column(name: 'created_at', value: 'now()')
			column(name: 'updated_at', value: 'now()')
			column(name: 'version', value: '0')
			column(name: 'value', value: '{"admin": {"override": true}, "classroom": {"lessons": {"attempts": 2, "threshold": 70}, "projects": {"attempts": 2, "threshold": 70}}}')
		}
	}
}