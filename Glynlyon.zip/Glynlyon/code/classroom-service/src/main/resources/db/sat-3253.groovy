databaseChangeLog logicalFilePath:'sat-3253', {

    changeSet(author: 'acaniff', id: 'add-timezone', context: 'schema') {
        addColumn(tableName: "organization") {
            column(name: 'timezone', type: 'text') {
                constraints(nullable: 'true')
            }
        }

        rollback {
            dropColumn(tableName: "organization", columnName: "timezone")
        }
    }
}