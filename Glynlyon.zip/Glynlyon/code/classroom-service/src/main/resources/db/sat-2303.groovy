databaseChangeLog logicalFilePath:'bootstrap', {

    changeSet(author: "acaniff", id: 'update_subjects_view_with_version', context: 'schema') {
        dropView(viewName: "subjects")
        createView(viewName: 'subjects') {
            """
        (SELECT
         ds.subject_uuid,
         o.organization_uuid,
         ds.name,
         TRUE            AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = ds.subject_uuid AND
                         o.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         ds.created_at,
         ds.updated_at,
         ds.version
     FROM \${database.defaultSchemaName}.organization o CROSS JOIN \${database.defaultSchemaName}.default_subject ds
     WHERE o.type = 'SCHOOL'
    )
    UNION
    (SELECT
         s.subject_uuid,
         s.organization_uuid,
         s.name,
         FALSE           AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = s.subject_uuid AND
                         s.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         s.created_at,
         s.updated_at,
         s.version
     FROM \${database.defaultSchemaName}.subject s)"""
        }
    }

    changeSet(author: 'acaniff', id: 'more_course_codes', context:'bootstrap') {
        loadData(tableName: 'course', file: 'data/uuid-bll_course_codes2.csv') {}
    }
}