databaseChangeLog logicalFilePath:'sat-3300', {
    changeSet(author: 'spillai', id: 'user_last_logged_in_at', context: 'schema') {
        addColumn(tableName: "user") {
            column(name: 'last_logged_in_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
        }
    }
}
