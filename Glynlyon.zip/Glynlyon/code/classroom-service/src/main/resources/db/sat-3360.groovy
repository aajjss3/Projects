databaseChangeLog logicalFilePath:'sat-3360', {

    changeSet(author: 'mbarreda', id: 'add-grade-scale-display-settings', context: 'schema') {
        sql("""UPDATE \${database.defaultSchemaName}.setting
            SET value = jsonb_set(value, 
            '{classroom}', 
            (SELECT (value -> 'classroom') || TO_JSONB('{"grade_scale": {"A":90, "B":80, "C":70, "D":60}, "grade_display": {"percentage":true, "letter":false}}'::jsonb)),
            false)""")

        rollback {
            sql("""UPDATE \${database.defaultSchemaName}.setting
                SET value =  jsonb_set(value, '{classroom}',  (value->'classroom') - 'grade_scale');""")
            sql("""UPDATE \${database.defaultSchemaName}.setting
                set value =  jsonb_set(value, '{classroom}',  (value->'classroom') - 'grade_display');""")
        }
    }
}