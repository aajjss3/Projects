databaseChangeLog logicalFilePath:'sat-2233', {
	
	changeSet(author: "asparago", id: "truncate_lock", context:"schema") {
		sql("TRUNCATE \${database.defaultSchemaName}.lock;")
	}
	
	changeSet(author: 'asparago', id: 'create_lock_index', context:'schema') {
		createIndex(indexName: "resource_uuid_idx", tableName: "lock") {
			column(name: "resource_uuid")
		}
		rollback {
			dropIndex(tableName: "lock", indexName: "resource_uuid_idx")
		}
	}
	
	changeSet(author: 'asparago', id: 'create_lock_resourceuuid_constraint', context:'schema') {
		addUniqueConstraint(tableName: "lock", columnNames: "resource_uuid", constraintName: "lock_resourceuuid_uniq_const")
		rollback {
			dropUniqueConstraint(tableName: "lock", constraintName: "lock_resourceuuid_uniq_const")
		}
	}
	
}
