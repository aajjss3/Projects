databaseChangeLog logicalFilePath:'sat-2200-producer', {

	changeSet(author: 'asparago', id: 'create_table_job_lock', context:'schema') {
		
		createTable(tableName: 'job_lock') {
			column(name: 'job_lock_uuid', type: 'uuid') {
				constraints(nullable: 'false', primaryKey: 'true')
			}
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'false')
			}
			column(name: 'acquired', type: 'boolean') {
				constraints(nullable: 'true')
			}
			column(name: 'locked_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
			column(name: 'locked_by', type: 'text') {
				constraints(nullable: 'true')
			}
			column(name: 'purpose', type: 'text') {
				constraints(nullable: 'true')
			}
		}
		
		createIndex(indexName: "job_lock_acquired_idx", tableName: "job_lock") {
			column(name: "acquired")
		}
		
		createIndex(indexName: "job_lock_purpose_idx", tableName: "job_lock") {
			column(name: "purpose")
		}
		
		insert(tableName:"job_lock") {
			column(name: 'job_lock_uuid', valueComputed: "uuid_generate_v4()")
			column(name: 'version', value: '0')
			column(name: 'acquired', value: false)
			column(name: 'purpose', value: 'COMPLETE_PAGE')
		}
	}
	
}