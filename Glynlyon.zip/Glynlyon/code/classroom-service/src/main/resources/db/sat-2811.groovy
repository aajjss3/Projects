databaseChangeLog logicalFilePath:'sat-2811', {
	
	// there is no rollback needed for setting assessment_score to null
	changeSet(author: 'asparago', id: 'update_version_subject', context:'schema') {
		sql("update \${database.defaultSchemaName}.attempt set assessment_score = null where state='SUBMITTED';")
	}

}