databaseChangeLog logicalFilePath:'sat-2164', {
	changeSet(author: 'asparago', id: 'remove_class_subject_uuid_required_constraint', context:'schema') {
		dropNotNullConstraint(columnName: "subject_uuid", tableName: "class")
	}
	
	changeSet(author: 'asparago', id: 'remove_class_subject_organization_uuid_required_constraint', context:'schema') {
		dropNotNullConstraint(columnName: "subject_organization_uuid", tableName: "class")
	}
}