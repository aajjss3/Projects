databaseChangeLog logicalFilePath:'sat-2267', {

    changeSet(author: 'acaniff', id: 'subject-name-index', context: 'schema') {
        createIndex(indexName: "subject_name_idx", tableName: "subject") {
            column(name: "name")
        }
    }
}