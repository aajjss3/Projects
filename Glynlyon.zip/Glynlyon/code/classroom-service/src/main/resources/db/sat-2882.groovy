databaseChangeLog logicalFilePath:'sat-2882', {

    changeSet(author: 'acaniff', id: 'add-credit-bearing', context: 'schema') {
        addColumn(tableName: "attempt") {
            column(name: 'credit_bearing', type: 'boolean')
        }

        addNotNullConstraint(tableName: "attempt", columnName: "credit_bearing", columnDataType: "boolean", defaultNullValue: 'false')

        sql("""
            UPDATE \${database.defaultSchemaName}.attempt
            SET credit_bearing = TRUE
            WHERE uuid in (select attempt.uuid FROM (SELECT DISTINCT ON (attempt.planner_entry_uuid) attempt.uuid, attempt.planner_entry_uuid, attempt.created_at
                    FROM   \${database.defaultSchemaName}.attempt attempt
                           INNER JOIN \${database.defaultSchemaName}.planner_entry pe ON pe.planner_entry_uuid = attempt.planner_entry_uuid
                           INNER JOIN \${database.defaultSchemaName}.attempt a2 ON a2.planner_entry_uuid = pe.planner_entry_uuid
                           INNER JOIN \${database.defaultSchemaName}.enrollment e on e.user_uuid = pe.user_uuid and e.class_uuid = pe.class_uuid
                           INNER JOIN \${database.defaultSchemaName}.page_assignment pa on pa.assignment_uuid = pe.assignment_uuid and pa.page_uuid = pe.page_uuid
                    GROUP BY attempt.uuid, a2.planner_entry_uuid
                    ORDER BY attempt.planner_entry_uuid, attempt.created_at DESC) attempt);
        """)

        rollback {
            dropColumn(tableName: "attempt", columnName: "credit_bearing")
        }
    }
}