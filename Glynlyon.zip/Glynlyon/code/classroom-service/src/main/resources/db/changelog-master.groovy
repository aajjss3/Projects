databaseChangeLog logicalFilePath:'changelog-master', {
	include file: "bootstrap.groovy", relativeToChangelogFile: true
	include file: "sat-1559.groovy", relativeToChangelogFile: true
    include file: "sat-2303.groovy", relativeToChangelogFile: true
    include file: "sat-2267.groovy", relativeToChangelogFile: true
	include file: "sat-2233.groovy", relativeToChangelogFile: true
	include file: "sat-2164.groovy", relativeToChangelogFile: true
	include file: "sat-2187.groovy", relativeToChangelogFile: true
	include file: "sat-2283.groovy", relativeToChangelogFile: true
	include file: "sat-2497.groovy", relativeToChangelogFile: true
    include file: "sat-2631.groovy", relativeToChangelogFile: true
	include file: "sat-2811.groovy", relativeToChangelogFile: true
	include file: "sat-2872.groovy", relativeToChangelogFile: true
    include file: "sat-2882.groovy", relativeToChangelogFile: true
    include file: "sat-2936.groovy", relativeToChangelogFile: true
	include file: "sat-3011.groovy", relativeToChangelogFile: true
	include file: "sat-2020.groovy", relativeToChangelogFile: true
	include file: "sat-3110.groovy", relativeToChangelogFile: true
    include file: "sat-3044.groovy", relativeToChangelogFile: true
    include file: "sat-3047.groovy", relativeToChangelogFile: true
    include file: "sat-3253.groovy", relativeToChangelogFile: true
	include file: "sat-2199.groovy", relativeToChangelogFile: true
	include file: "sat-3360.groovy", relativeToChangelogFile: true
	include file: "sat-2200-producer.groovy", relativeToChangelogFile: true
	include file: "sat-3300.groovy", relativeToChangelogFile: true
}

