databaseChangeLog logicalFilePath:'sat-2283', {

	changeSet(author: 'acaniff', id: 'attempt_save', context: 'schema') {
		createTable(tableName: 'attempt_save') {
			column(name: 'uuid', type: 'uuid') {
				constraints(nullable: 'false', primaryKey: 'true')
			}
			column(name: 'attempt_uuid', type: 'uuid') {
				constraints(nullable: 'false', foreignKeyName: "fk_attempt_save_attempt", references:"attempt(uuid)")
			}
			column(name: 'sequence', type: 'integer') {
				constraints(nullable: 'false')
			}
			column(name: 'sections_viewed', type: 'jsonb') {
				constraints(nullable: 'false')
			}
			column(name: 'questions_viewed', type: 'jsonb') {
				constraints(nullable: 'false')
			}
			column(name: 'time_on_task_seconds', type: 'integer') {
				constraints(nullable: 'false')
			}
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
			column(name: 'created_by', type: 'uuid') {
				constraints(nullable: 'false')
			}
			column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'false')
			}
		}
	}

	changeSet(author: 'acaniff', id: 'attempt_questions_viewed', context: 'schema') {
		addColumn(tableName: "attempt") {
			column(name: 'questions_viewed', type: 'jsonb') {
				constraints(nullable: 'true')
			}
		}
	}
}