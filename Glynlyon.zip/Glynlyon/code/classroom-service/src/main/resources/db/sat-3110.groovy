databaseChangeLog logicalFilePath:'sat-3110', {

	changeSet(author: 'asparago', id: 'create_table_event_login_logout', context:'schema') {
		
		createTable(tableName: 'event_login_logout') {
			column(name: 'event_login_logout_uuid', type: 'uuid') {
				constraints(nullable: 'false', primaryKey: 'true')
			}
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'false')
			}
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
			column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
			column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
			column(name: 'created_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
			column(name: 'user_uuid', type: 'uuid') {
				constraints(nullable: 'true')
			}
			column(name: 'logged_in', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
			column(name: 'logged_out', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		
		createIndex(indexName: "event_login_logout_user_idx", tableName: "event_login_logout") {
			column(name: "user_uuid")
		}
		
		createIndex(indexName: "event_login_logout_loggedin_idx", tableName: "event_login_logout") {
			column(name: "logged_in")
		}
		
		createIndex(indexName: "event_login_logout_loggedout_idx", tableName: "event_login_logout") {
			column(name: "logged_out")
		}

	}
	
}