databaseChangeLog logicalFilePath:'sat-3047', {

    changeSet(author: 'acaniff', id: 'create_issuer_launch_table', context:'schema') {
        createTable(tableName: 'issuer_launch') {
            column(name: 'launch_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'jwt', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'launched', type: 'boolean') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'date_launched', type: 'date') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'version', type: 'bigint') {
                constraints(nullable: 'true')
            }
            column(name: 'updated_by', type: 'uuid') {
                constraints(nullable: 'true')
            }
        }
    }
}