databaseChangeLog logicalFilePath:'sat-2631', {

    changeSet(author: 'acaniff', id: 'add-completed-date', context: 'schema') {
        dropForeignKeyConstraint(baseTableName: "attempt_save", constraintName:"fk_attempt_save_attempt")
        addForeignKeyConstraint(baseColumnNames: "attempt_uuid", baseTableName: "attempt_save", constraintName: "fk_attempt_save_attempt", referencedColumnNames: "uuid", referencedTableName: "attempt", onDelete: "CASCADE")

        addColumn(tableName: "page") {
            column(name: 'completed_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
        }
    }
}