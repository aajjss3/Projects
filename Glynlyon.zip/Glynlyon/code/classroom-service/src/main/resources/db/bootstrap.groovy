databaseChangeLog logicalFilePath:'bootstrap', {
    changeSet(author: 'mbarreda', id: 'create_launch_table', context:'schema') {
        createTable(tableName: 'launch') {
            column(name: 'launch_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'jwt', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'launched', type: 'boolean') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'date_launched', type: 'date') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
        }
    }

    changeSet(author: 'knellutla', id: 'create_organization_table', context:'schema') {
        createTable(tableName: 'organization') {
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'source', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

            column(name: 'name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
    }

	changeSet(author: 'asparago', id: 'create_setting_table', context:'schema') {
		createTable(tableName: 'setting') {
			column(name: 'uuid', type: 'uuid') {
				constraints(nullable: 'false', primaryKey: 'true')
			}
			column(name: 'key', type: 'text') {
				constraints(nullable: 'false', primaryKey: 'false')
			}
			column(name: 'value', type: 'text') {
				constraints(nullable: 'false', primaryKey: 'false')
			}
			column(name: 'description', type: 'text') {
				constraints(nullable: 'true', primaryKey: 'false')
			}
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'false', primaryKey: 'false')
			}

		}
		createIndex(indexName: "setting_key_idx", tableName: "setting") {
			column(name: "key")
		}
	}
	
	changeSet(author: "asparago", id: "insert-default-setting", context:"schema") {

				sql("TRUNCATE \${database.defaultSchemaName}.setting;")
		
				insert(tableName:"setting") {
					column(name: 'uuid', valueComputed: "uuid_generate_v4()")
					column(name: 'version', value: '0')
					column(name: 'key', value: 'project_pass_threshold')
					column(name: 'value', value: '70')
					column(name: 'description', value: 'pass threshold for project assignments')
				}
		
				insert(tableName:"setting") {
					column(name: 'uuid', valueComputed: "uuid_generate_v4()")
					column(name: 'version', value: '0')
					column(name: 'key', value: 'lesson_pass_threshold')
					column(name: 'value', value: '70')
					column(name: 'description', value: 'pass threshold for lesson assignments')
				}
	}

	
	
    changeSet(author: 'knellutla', id: 'create_subject_table', context:'schema') {
        createTable(tableName: 'subject') {
            column(name: 'subject_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

        }

        addForeignKeyConstraint(baseColumnNames: "organization_uuid", baseTableName: "subject", constraintName: "fk_subject_organization", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "organization_uuid", referencedTableName: "organization")
    }

    changeSet(author: "knellutla", id: "subject-insert-data-1b", context:"schema") {

        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Advanced Placement')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Blended')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Career and Technical Education')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Elective')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'English Language Arts')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'History')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Mathematics')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Science')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Social Studies')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Test Prep')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }

        rollback {
            
        }
    }

    changeSet(author: 'mbarreda', id: 'create_academic_session_table', context:'schema') {
        createTable(tableName: 'academic_session') {
            column(name: 'academic_session_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'type', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'start_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'end_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'parent_uuid', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

        }

        addForeignKeyConstraint(baseColumnNames: "parent_uuid", baseTableName: "academic_session", constraintName: "fk_academic_session", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "academic_session_uuid", referencedTableName: "academic_session")
        createIndex(indexName: "academic_session_parent_uuid_idx", tableName: "academic_session") {
            column(name: "parent_uuid")
        }
    }

    changeSet(author: 'mbarreda', id: 'create_user_table', context:'schema') {
        createTable(tableName: 'user') {
            column(name: 'user_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'source', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'full_name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
    }

    changeSet(author: 'mbarreda', id: 'create_class_table', context:'schema') {
        createTable(tableName: 'class') {
            column(name: 'class_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'type', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'sub_type', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'state', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'creator_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'class_id', type: 'text') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'subject_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'notes', type: 'text') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'academic_session_uuid', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'access_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'stop_date', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
        addForeignKeyConstraint(baseColumnNames: "academic_session_uuid", baseTableName: "class", constraintName: "fk_classObj_academic_session", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "academic_session_uuid", referencedTableName: "academic_session")
        addForeignKeyConstraint(baseColumnNames: "creator_uuid", baseTableName: "class", constraintName: "fk_classObj_user", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "user_uuid", referencedTableName: "user")
        addForeignKeyConstraint(baseColumnNames: "organization_uuid", baseTableName: "class", constraintName: "fk_classObj_organization", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "organization_uuid", referencedTableName: "organization")

        createIndex(indexName: "class_creator_uuid_idx", tableName: "class") {
            column(name: "creator_uuid")
        }
        createIndex(indexName: "class_organization_uuid_idx", tableName: "class") {
            column(name: "organization_uuid")
        }
        createIndex(indexName: "class_academic_session_uuid_idx", tableName: "class") {
            column(name: "academic_session_uuid")
        }
    }

    changeSet(author: "mbarreda", id: "user-insert-data-1b", context:"schema") {

        insert(tableName: "user") {
            column(name: 'user_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'source', value: 'sorce')
            column(name: 'full_name', value: 'MB')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
    }

    changeSet(author: "mbarreda", id: "org-insert-data-1b", context:"schema") {

        insert(tableName: "organization") {
            column(name: 'organization_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'source', value: 'sorce')
            column(name: 'name', value: 'MBORG')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
    }

    changeSet(author: 'mbarreda', id: 'create_grade_table', context:'schema') {
        createTable(tableName: 'class_grade_level') {
            column(name: 'class_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'grade_level', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
        addForeignKeyConstraint(baseColumnNames: "class_uuid", baseTableName: "class_grade_level", constraintName: "fk_class_grade_level_class", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "class_uuid", referencedTableName: "class")

        createIndex(indexName: "class_grade_level_class_uuid_idx", tableName: "class_grade_level") {
            column(name: "class_uuid")
        }
    }

    changeSet(author: 'acaniff', id: 'remove-user-org', context:'schema') {
        dropForeignKeyConstraint(baseTableName: "class", constraintName:"fk_classObj_user")
        dropTable(tableName: "user")

        dropForeignKeyConstraint(baseTableName: "class", constraintName:"fk_classObj_organization")
        dropForeignKeyConstraint(baseTableName: "subject", constraintName:"fk_subject_organization")
        dropTable(tableName: "organization")
    }

    changeSet(author: 'acaniff', id: 'create_enrollment_table', context:'schema') {
        createTable(tableName: 'enrollment') {
            column(name: 'enrollment_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'class_uuid', type: 'uuid') {
                constraints(nullable: 'false', foreignKeyName: "fk_class_class_uuid", references:"class(class_uuid)")
            }
            column(name: 'user_uuid', type: 'uuid') {
                constraints(nullable: 'false')
            }
            column(name: 'role', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'primary_role', type: 'boolean', defaultValueBoolean: "false") {
                constraints(nullable: 'false')
            }
            column(name: 'status', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false')
            }
        }

        createIndex(indexName: "enrollment_class_uuid_idx", tableName: "enrollment") {
            column(name: "class_uuid")
        }

        createIndex(indexName: "enrollment_user_uuid_idx", tableName: "enrollment") {
            column(name: "user_uuid")
        }
		
    }

    changeSet(author: 'mbarreda', id: 'create_organization_table', context:'schema') {
        createTable(tableName: 'organization') {
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
    }

    changeSet(author: 'mbarreda', id: 'create_default_subject_table', context:'schema') {
        createTable(tableName: 'default_subject') {
            column(name: 'subject_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'name', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
        createIndex(indexName: "default_subject_name_idx", tableName: "default_subject") {
            column(name: "name")
        }
    }

    changeSet(author: 'mbarreda', id: 'create_disabled_subject_table', context:'schema') {
        createTable(tableName: 'disabled_subject') {
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'true')
            }
            column(name: 'subject_uuid', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'true')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
    }

    changeSet(author: "mbarreda", id: 'create_subjects_view', context:'schema') {
        createView(viewName: 'subjects') {
            """
        (SELECT
         subject_uuid,
         organization_uuid,
         name,
         TRUE            AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = ds.subject_uuid AND
                         o.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         ds.created_at,
         ds.updated_at
     FROM \${database.defaultSchemaName}.organization o CROSS JOIN \${database.defaultSchemaName}.default_subject ds
    )
    UNION
    (SELECT
         subject_uuid,
         organization_uuid,
         name,
         FALSE           AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = s.subject_uuid AND
                         s.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         s.created_at,
         s.updated_at
     FROM \${database.defaultSchemaName}.subject s)"""
        }
    }

    changeSet(author: "mbarreda", id: "insert-default-subjects", context:"schema") {
        validCheckSum("7:6ed041be7120e7025cb3bd4198e06955")
        validCheckSum("7:95d1154cc4d9a8182dc517a851064b23")
        sql("TRUNCATE \${database.defaultSchemaName}.subject;")

        insert(tableName:"organization") {
            column(name: 'organization_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }

        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Advanced Placement')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Blended')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Career and Technical Education')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Elective')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'English Language Arts')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'History')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Mathematics')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Science')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Social Studies')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }
        insert(tableName:"default_subject") {
            column(name: 'subject_uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'name', value: 'Test Prep')
            column(name: 'created_at', value: 'now()')
            column(name: 'updated_at', value: 'now()')
        }

        rollback {

        }
    }

    changeSet(author: "mbarreda", id: "truncate-class", context:"schema") {
        validCheckSum("7:fbf014f76c18c4a8fef4311a2a012460")
        validCheckSum("7:521678cd570e70d8565e641b4a310a1a")
        sql("TRUNCATE \${database.defaultSchemaName}.class CASCADE;")

        rollback {

        }
    }

    changeSet(author: "acaniff", id: "add-subject_org-class", context: "schema") {
        validCheckSum("7:6db194ed5617915f1e50c3325d284f8b")
        validCheckSum("7:30a4e54e9c3d54e97728291ce948e68e")
        sql("TRUNCATE \${database.defaultSchemaName}.class CASCADE;")

        addColumn(tableName: "class") {
            column(name: 'subject_organization_uuid', type: 'uuid') {
                constraints(nullable: 'false')
            }
        }
    }

    changeSet(author: "xliu", id: "add-organization_uuid-AcademicSession", context: "schema") {
        validCheckSum("7:94e697bfa39ab56334c7467b571c9eb9")
        validCheckSum("7:b86d5ec3666c97e90149b3892cbc57d9")
        sql("TRUNCATE \${database.defaultSchemaName}.academic_session CASCADE;")

        addColumn(tableName: "academic_session") {
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'false')
            }
        }
    }

    changeSet(author: 'mbarreda', id: 'truncate_class_table', context:'schema') {
        sql("TRUNCATE \${database.defaultSchemaName}.class CASCADE;")
    }

    changeSet(author: 'mbarreda', id: 'create_page_table', context:'schema') {
        createTable(tableName: 'page') {
            column(name: 'page_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'class_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'name', type: 'text') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'status', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'type', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'sequence', type: 'integer') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

        }

        addForeignKeyConstraint(baseColumnNames: "class_uuid", baseTableName: "page", constraintName: "fk_page_class", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "class_uuid", referencedTableName: "class")
    }

    changeSet(author: 'mbarreda', id: 'create_page_assignment_table', context:'schema') {
        createTable(tableName: 'page_assignment') {
            column(name: 'page_assignment_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'page_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'assignment_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'assignment_title', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'assignment_type', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'status', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'sequence', type: 'integer') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }

        }

        addForeignKeyConstraint(baseColumnNames: "page_uuid", baseTableName: "page_assignment", constraintName: "fk_page_assignment", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "page_uuid", referencedTableName: "page")
    }

    changeSet(author: 'mbarreda', id: 'user_table', context:'schema') {
        createTable(tableName: 'user') {
            column(name: 'app_user_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'first_name', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'last_name', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'username', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'sso_id', type: 'text') {
                constraints(nullable: 'true')
            }
            column(name: 'app_user_type', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'app_user_status', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'super_teacher', type: 'boolean') {
                constraints(nullable: 'true')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false')
            }
            column(name: 'origination_id', type: 'text') {
                constraints(nullable: 'false')
            }
        }
    }

    changeSet(author: 'mbarreda', id: 'updated_organization_table', context:'schema') {
        sql("TRUNCATE \${database.defaultSchemaName}.organization CASCADE;")

        addColumn(tableName: "organization") {
            column(name: 'name', type: 'text') {
                constraints(nullable: 'false')
            }
        }
        addColumn(tableName: "organization") {
            column(name: 'origination_id', type: 'text') {
                constraints(nullable: 'false')
            }
        }
    }

    changeSet(author: 'spillai',id: 'add_type_parent_to_organization',context: 'schema'){
        sql('CREATE TYPE \${database.defaultSchemaName}.organization_type AS ENUM (\'SCHOOL\', \'CAMPUS\');')

        addColumn(tableName: "organization") {
            column(name: 'type', type: '\${database.defaultSchemaName}.organization_type') {
                constraints(nullable: 'false')
            }
        }

        addColumn(tableName: "organization") {
            column(name: 'parent', type: 'uuid') {
                constraints(nullable: 'true')
            }
        }

    }

    changeSet(author: "etatarzycki", id: "sat-1161-truncate-class", context:"schema") {
        validCheckSum("7:fbf014f76c18c4a8fef4311a2a012460")
        validCheckSum("7:521678cd570e70d8565e641b4a310a1a")
        sql("TRUNCATE \${database.defaultSchemaName}.class CASCADE;")

        rollback {

        }
    }

    changeSet(author: 'mbarreda', id: 'update_class_table', context:'schema') {
        addForeignKeyConstraint(baseColumnNames: "organization_uuid", baseTableName: "class", constraintName: "fk_classObj_org", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "organization_uuid", referencedTableName: "organization")
    }

    changeSet(author: 'mbarreda', id: 'create_user_organization_table', context:'schema') {
        createTable(tableName: 'user_organization') {
            column(name: 'user_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'organization_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
        }
    }

    changeSet(author: "mbarreda", id: 'update_subjects_view', context:'schema') {
        dropView(viewName: "subjects")
        createView(viewName: 'subjects') {
            """
        (SELECT
         subject_uuid,
         organization_uuid,
         ds.name,
         TRUE            AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = ds.subject_uuid AND
                         o.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         ds.created_at,
         ds.updated_at
     FROM \${database.defaultSchemaName}.organization o CROSS JOIN \${database.defaultSchemaName}.default_subject ds
     WHERE o.type = 'SCHOOL'
    )
    UNION
    (SELECT
         subject_uuid,
         organization_uuid,
         name,
         FALSE           AS default_subject,
         COALESCE((SELECT TRUE
                   FROM \${database.defaultSchemaName}.disabled_subject
                   WHERE subject_uuid = s.subject_uuid AND
                         s.organization_uuid = organization_uuid),
                  FALSE) AS disabled,
         s.created_at,
         s.updated_at
     FROM \${database.defaultSchemaName}.subject s)"""
        }
    }

    changeSet(author: 'spillai', id: 'SAT-1163', context:'schema') {
        sql('CREATE TYPE \${database.defaultSchemaName}.sync_status AS ENUM (\'IN_PROGRESS\', \'SUCCESS\', \'ERROR\');')

        createTable(tableName: 'sync') {
            column(name: 'uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'origination_id', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'server_name', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'started_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false')
            }
            column(name: 'ended_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
            column(name: 'status', type: '\${database.defaultSchemaName}.sync_status') {
                constraints(nullable: 'false')
            }
        }
    }

    changeSet(author: 'acaniff', id: 'default-date-columns', context:'schema') {
        addDefaultValue(tableName:'organization', columnName:'created_at', defaultValueComputed:'now()')
        addDefaultValue(tableName:'organization', columnName:'updated_at', defaultValueComputed:'now()')
    }


    changeSet(author: 'acaniff', id: 'add-org-type-index', context:'schema') {
        createIndex(indexName: "organization_type_idx", tableName: "organization") {
            column(name: "type")
        }
    }

    changeSet(author: 'acaniff', id: 'relex-user-table-constraints', context: 'schema') {
        dropNotNullConstraint(columnName: "first_name", tableName: "user")
        dropNotNullConstraint(columnName: "last_name", tableName: "user")
        dropNotNullConstraint(columnName: "username", tableName: "user")
    }
    
    changeSet(author: 'mbarreda', id: 'create_course_table', context:'schema') {
        createTable(tableName: 'course') {
            column(name: 'course_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
        }
        loadData(tableName: 'course', file: 'data/uuid-course_codes-phantom.csv') {}
    }

    changeSet(author: 'acaniff', id: 'SAT-1346', context:'schema') {
        addDefaultValue(tableName:'page_assignment', columnName:'created_at', defaultValueComputed:'now()')
        addDefaultValue(tableName:'page_assignment', columnName:'updated_at', defaultValueComputed:'now()')

        addUniqueConstraint(tableName: "page_assignment", columnNames: "page_uuid, sequence", constraintName: "page_uuid_sequence_const")
        addUniqueConstraint(tableName: "page_assignment", columnNames: "page_uuid, assignment_uuid", constraintName: "page_uuid_assignment_uuid_const")

        rollback {
            dropDefaultValue(tableName:"page_assignment", columnName:"created_at")
            dropDefaultValue(tableName:"page_assignment", columnName:"updated_at")

            dropUniqueConstraint(tableName: "page_assignment", constraintName: "page_uuid_sequence_const")
            dropUniqueConstraint(tableName: "page_assignment", constraintName: "page_uuid_assignment_uuid_const")
        }
    }

    changeSet(author: 'acaniff', id: 'SAT-1124', context:'schema') {
        dropColumn(tableName: "page_assignment", columnName: "status")
    }

    changeSet(author: 'spillai', id: 'create_org_parent_index', context:'schema') {
        createIndex(indexName: "organization_parent_idx", tableName: "organization") {
            column(name: "parent")
        }
    }

    changeSet(author: 'acaniff', id: 'user-org-join-index', context:'schema') {
        createIndex(indexName: "user_organization_user_uuid_idx", tableName: "user_organization") {
            column(name: "user_uuid")
        }
        createIndex(indexName: "user_organization_organization_uuid_idx", tableName: "user_organization") {
            column(name: "organization_uuid")
        }
    }


    changeSet(author: 'xliu', id: 'create_planner_entry_table', context:'schema') {
        createTable(tableName: 'planner_entry') {
            column(name: 'planner_entry_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'user_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'page_uuid', type: 'uuid') {
                constraints(nullable: 'false', foreignKeyName: "fk_planner_page", references:"page(page_uuid)")
            }
            column(name: 'class_uuid', type: 'uuid') {
                constraints(nullable: 'false', foreignKeyName: "fk_planner_class", references:"class(class_uuid)")
            }
            column(name: 'assignment_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'activity_id', type: 'uuid') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'status', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'slot', type: 'integer') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
		

    }

	

    changeSet(author: 'acaniff', id: 'create_assignment_table', context:'schema') {
        createTable(tableName: 'assignment') {
            column(name: 'assignment_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'assignment_type', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'assignment_title', type: 'text') {
                constraints(nullable: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }

        createIndex(indexName: "assignment_uuid_idx", tableName: "assignment") {
            column(name: "assignment_uuid")
        }

        dropColumn(tableName: "page_assignment", columnName: "assignment_type")
        dropColumn(tableName: "page_assignment", columnName: "assignment_title")

        sql("TRUNCATE \${database.defaultSchemaName}.planner_entry CASCADE;")
        sql("TRUNCATE \${database.defaultSchemaName}.page_assignment CASCADE;")

        addForeignKeyConstraint(baseColumnNames: "assignment_uuid", baseTableName: "planner_entry", constraintName: "fk_assignment_planner_entry", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "assignment_uuid", referencedTableName: "assignment")
        addForeignKeyConstraint(baseColumnNames: "assignment_uuid", baseTableName: "page_assignment", constraintName: "fk_assignment_planner_entry", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "assignment_uuid", referencedTableName: "assignment")
    }

    changeSet(author: 'xliu', id: 'create_attempt_table and attempt_limit setting', context:'schema') {
        createTable(tableName: 'attempt') {
            column(name: 'uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'planner_entry_uuid', type: 'uuid') {
                constraints(nullable: 'false', foreignKeyName: "fk_planner_entry", references:"planner_entry(planner_entry_uuid)")
            }
            column(name: 'user_uuid', type: 'uuid') {
                constraints(nullable: 'false', foreignKeyName: "fk_user", references:"user(app_user_uuid)")
            }
            column(name: 'activity_id', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'section_count', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'section_total_count', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'question_count', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'question_total_count', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }       
            column(name: 'state', type: 'text') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'time_on_task_seconds', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }        
            column(name: 'assessment_score', type: 'integer') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'sections', type: 'jsonb') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'included_manual_graded', type: 'boolean') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
            column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE', defaultValueComputed: "now()") {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'version', type: 'bigint') {
				constraints(nullable: 'false', primaryKey: 'false')
			}
        }
        createIndex(indexName: "planner_entry_uuid_idx", tableName: "attempt") {
			column(name: "planner_entry_uuid")
		}
		insert(tableName:"setting") {
					column(name: 'uuid', valueComputed: "uuid_generate_v4()")
					column(name: 'version', value: '0')
					column(name: 'key', value: 'attempt-count-limit')
					column(name: 'value', value: '2')
					column(name: 'description', value: 'limit for planner entry attempt')
				}
    }

    changeSet(author: 'mbarreda', id: 'update_attempt_table', context:'schema') {

        sql("TRUNCATE \${database.defaultSchemaName}.attempt CASCADE;")

        dropColumn(tableName: "attempt", columnName: "question_total_count")

        addColumn(tableName: "attempt") {
            column(name: 'questions_attempted_count', type: 'integer') {
                constraints(nullable: 'true')
            }
        }
        addColumn(tableName: "attempt") {
            column(name: 'questions_correct_count', type: 'integer') {
                constraints(nullable: 'true')
            }
        }
        addColumn(tableName: "attempt") {
            column(name: 'questions_incorrect_count', type: 'integer') {
                constraints(nullable: 'true')
            }
        }
        addColumn(tableName: "attempt") {
            column(name: 'questions_not_scored_count', type: 'integer') {
                constraints(nullable: 'true')
            }
        }
        addColumn(tableName: "attempt") {
            column(name: 'response_overrides', type: 'hstore') {
                constraints(nullable: 'true')
            }
        }
        addColumn(tableName: "attempt") {
            column(name: 'completed_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
        }
    }

    changeSet(author: 'etatarzycki', id: 'sat-1437', context:'schema') {
        dropColumn(tableName: "attempt", columnName: "assessment_score")

        addColumn(tableName: "attempt") {
           column(name: 'assessment_score', type: 'double precision') {
                constraints(nullable: 'true', primaryKey: 'false')
            }
        }
    }
	
	changeSet(author: 'xliu', id: 'create_planner_entry_indexes_table', context:'schema') {
		createIndex(indexName: "planner_entry_class_uuid_idx", tableName: "planner_entry") {
			column(name: "class_uuid")
		}

		createIndex(indexName: "planner_entry_user_uuid_idx", tableName: "planner_entry") {
			column(name: "user_uuid")
		}
	}
	
	changeSet(author: 'acaniff', id: 'create_enrollment_indexed_table', context:'schema') {
		createIndex(indexName: "enrollment_role_idx", tableName: "enrollment") {
			column(name: "role")
		}	
	}


    changeSet(author: 'mbarreda', id: 'update_course_table', context:'schema') {
        sql("TRUNCATE \${database.defaultSchemaName}.course;")

        loadData(tableName: 'course', file: 'data/uuid-bll_course_codes.csv') {}
    }

    changeSet(author: 'mbarreda', id: 'update_attempt_table_sections_viewed', context:'schema') {
        addColumn(tableName: "attempt") {
            column(name: 'sections_viewed', type: 'jsonb') {
                constraints(nullable: 'true')
            }
        }
    }
	
	changeSet(author: 'asparago', id: 'update_attempt_count_limit_record', context:'schema') {
		sql("update \${database.defaultSchemaName}.setting set key = 'attempt_count_limit' where key = 'attempt-count-limit';")
		
		rollback{
			sql("update \${database.defaultSchemaName}.setting set key = 'attempt-count-limit' where key = 'attempt_count_limit';")
		}
	}

    changeSet(author: 'mbarreda', id: 'update_course_table_updated_at_column', context:'schema') {
        addColumn(tableName: "class") {
            column(name: 'completed_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'true')
            }
        }
    }

    changeSet(author: 'mbarreda', id: 'create_lock_table', context:'schema') {

        sql('CREATE TYPE \${database.defaultSchemaName}.resource_type AS ENUM (\'ATTEMPT\');')

        createTable(tableName: 'lock') {
            column(name: 'lock_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'true')
            }
            column(name: 'locked_by', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'locked_at', type: 'TIMESTAMP WITH TIME ZONE') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'resource_type', type: '\${database.defaultSchemaName}.resource_type') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
            column(name: 'resource_uuid', type: 'uuid') {
                constraints(nullable: 'false', primaryKey: 'false')
            }
        }
        addForeignKeyConstraint(baseColumnNames: "locked_by", baseTableName: "lock", constraintName: "fk_lock_user", deferrable: "false", initiallyDeferred: "false", referencedColumnNames: "app_user_uuid", referencedTableName: "user")

    }

    changeSet(author: 'acaniff', id: 'add-class-delete-grace-period-setting', context: 'bootstrap') {
        insert(tableName:"setting") {
            column(name: 'uuid', valueComputed: "uuid_generate_v4()")
            column(name: 'version', value: '0')
            column(name: 'key', value: 'class_delete_grace_period_hours')
            column(name: 'value', value: '24')
            column(name: 'description', value: 'Hours for class deletion grade period')
        }
    }

    changeSet(author: 'acaniff', id: 'fix-class-subject-columns', context:'bootstrap') {
        sql("UPDATE \${database.defaultSchemaName}.class SET subject_uuid = subject_organization_uuid, subject_organization_uuid = subject_uuid;")
    }

}
