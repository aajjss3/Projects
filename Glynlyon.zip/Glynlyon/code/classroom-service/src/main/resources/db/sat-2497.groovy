databaseChangeLog logicalFilePath:'sat-2497', {

    changeSet(author: 'asparago', id: 'organization-origination-id-index', context: 'schema') {
        createIndex(indexName: "organization_origination_idx", tableName: "organization") {
            column(name: "origination_id")
        }
    }
		
		changeSet(author: 'asparago', id: 'page-class-uuid-index', context: 'schema') {
			createIndex(indexName: "page_class_uuid_idx", tableName: "page") {
				column(name: "class_uuid")
			}
		}

}