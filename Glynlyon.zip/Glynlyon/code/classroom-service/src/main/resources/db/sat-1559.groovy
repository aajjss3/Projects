databaseChangeLog logicalFilePath:'sat-1559', {
	
	changeSet(author: 'asparago', id: 'add_version_to_launch', context:'schema') {
		addColumn(tableName: "launch") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
        }
	}
		
	changeSet(author: 'asparago', id: 'add_createdat_updatedat_updatedby_version_to_course', context:'schema') {
		addColumn(tableName: "course") {
			column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "course") {
			column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "course") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "course") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_createdat_updatedat_updatedby_version_to_setting', context:'schema') {
		addColumn(tableName: "setting") {
			column(name: 'created_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "setting") {
			column(name: 'updated_at', type: 'TIMESTAMP WITH TIME ZONE') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "setting") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
	}

	changeSet(author: 'asparago', id: 'add_updatedby_version_to_academic_session', context:'schema') {
		addColumn(tableName: "academic_session") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "academic_session") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_assignment', context:'schema') {
		addColumn(tableName: "assignment") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "assignment") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
		
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_attempt', context:'schema') {
		addColumn(tableName: "attempt") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_class', context:'schema') {
		addColumn(tableName: "class") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "class") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_class_grade_level', context:'schema') {
		addColumn(tableName: "class_grade_level") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "class_grade_level") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}

	changeSet(author: 'asparago', id: 'add_updatedby_version_to_default_subject', context:'schema') {
		addColumn(tableName: "default_subject") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "default_subject") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	

	changeSet(author: 'asparago', id: 'add_updatedby_version_to_disabled_subject', context:'schema') {
		addColumn(tableName: "disabled_subject") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "disabled_subject") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_enrollment', context:'schema') {
		addColumn(tableName: "enrollment") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "enrollment") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_version_to_lock', context:'schema') {
		addColumn(tableName: "lock") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_organization', context:'schema') {
		addColumn(tableName: "organization") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "organization") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_page', context:'schema') {
		addColumn(tableName: "page") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "page") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_page_assignment', context:'schema') {
		addColumn(tableName: "page_assignment") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "page_assignment") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_planner_entry', context:'schema') {
		addColumn(tableName: "planner_entry") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "planner_entry") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_version_to_subject', context:'schema') {
		addColumn(tableName: "subject") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "subject") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_version_to_sync', context:'schema') {
		addColumn(tableName: "sync") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	changeSet(author: 'asparago', id: 'add_updatedby_user', context:'schema') {
		addColumn(tableName: "user") {
			column(name: 'updated_by', type: 'uuid') {
				constraints(nullable: 'true')
			}
		}
		addColumn(tableName: "user") {
			column(name: 'version', type: 'bigint') {
				constraints(nullable: 'true')
			}
		}
	}
	
	// seed data in the course table
	changeSet(author: 'asparago', id: 'update_course_data', context:'schema') {
		sql("TRUNCATE \${database.defaultSchemaName}.course;")
		loadData(tableName: 'course', file: 'data/uuid-bll_course_codes.csv') {}
	}
	
	// update any db rows added by the boostrap.groovy file - set the version field to 0
	changeSet(author: 'asparago', id: 'update_version_subject', context:'schema') {
		sql("update \${database.defaultSchemaName}.subject set version = 0 where version is null;")
	}
	changeSet(author: 'asparago', id: 'update_version_user', context:'schema') {
		sql("update \${database.defaultSchemaName}.user set version = 0 where version is null;")
	}
	changeSet(author: 'asparago', id: 'update_version_organization', context:'schema') {
		sql("update \${database.defaultSchemaName}.organization set version = 0 where version is null;")
	}
	changeSet(author: 'asparago', id: 'update_version_default_subject', context:'schema') {
		sql("update \${database.defaultSchemaName}.default_subject set version = 0 where version is null;")
	}

	
	// update any existing database rows (all rows in all tables) - set version = 0 where version of null. 
	changeSet(author: 'asparago', id: 'update_version_academic_session', context:'schema') {
		sql("update \${database.defaultSchemaName}.academic_session set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_assignment', context:'schema') {
		sql("update \${database.defaultSchemaName}.assignment set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_attempt', context:'schema') {
		sql("update \${database.defaultSchemaName}.attempt set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_class', context:'schema') {
		sql("update \${database.defaultSchemaName}.class set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_class_grade_level', context:'schema') {
		sql("update \${database.defaultSchemaName}.class_grade_level set version = 0 where version is null;")
	}
		
	changeSet(author: 'asparago', id: 'update_version_course', context:'schema') {
		sql("update \${database.defaultSchemaName}.course set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_disabled_subject', context:'schema') {
		sql("update \${database.defaultSchemaName}.disabled_subject set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_version_enrollment', context:'schema') {
		sql("update \${database.defaultSchemaName}.enrollment set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_launch', context:'schema') {
		sql("update \${database.defaultSchemaName}.launch set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_lock', context:'schema') {
		sql("update \${database.defaultSchemaName}.lock set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_page', context:'schema') {
		sql("update \${database.defaultSchemaName}.page set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_page_assignment', context:'schema') {
		sql("update \${database.defaultSchemaName}.page_assignment set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_planner_entry', context:'schema') {
		sql("update \${database.defaultSchemaName}.planner_entry set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_setting', context:'schema') {
		sql("update \${database.defaultSchemaName}.setting set version = 0 where version is null;")
	}
	
	changeSet(author: 'asparago', id: 'update_sync', context:'schema') {
		sql("update \${database.defaultSchemaName}.sync set version = 0 where version is null;")
	}
	
	
}	