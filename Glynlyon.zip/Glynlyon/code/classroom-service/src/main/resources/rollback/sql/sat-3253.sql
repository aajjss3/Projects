ALTER TABLE classroom_service.organization DROP COLUMN timezone;
DELETE FROM classroom_service.databasechangelog WHERE id ='add-timezone' AND filename='sat-3253';
COMMIT;