ALTER TABLE classroom_service.attempt DROP TABLE issuer_launch;
DELETE FROM classroom_service.databasechangelog WHERE id ='create_issuer_launch_table' AND filename='sat-3047';
COMMIT;