ALTER TABLE classroom_service.launch DROP COLUMN updated_by;
DELETE FROM classroom_service.databasechangelog WHERE id ='add_updated_by' AND filename='sat-2020';
COMMIT;