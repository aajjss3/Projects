ALTER TABLE classroom_service.page DROP COLUMN completed_date;
ALTER TABLE classroom_service.attempt_save
  DROP CONSTRAINT fk_attempt_save_attempt;
ALTER TABLE classroom_service.attempt_save
  ADD CONSTRAINT fk_attempt_save_attempt
  FOREIGN KEY (attempt_uuid)
  REFERENCES classroom_service.attempt (uuid)
  MATCH SIMPLE
  ON UPDATE NO ACTION ON DELETE NO ACTION;
DELETE FROM classroom_service.databasechangelog WHERE id ='add-completed-date' AND filename='sat-2631';
COMMIT;