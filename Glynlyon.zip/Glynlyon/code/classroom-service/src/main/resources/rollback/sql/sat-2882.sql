ALTER TABLE classroom_service.attempt DROP COLUMN credit_bearing;
DELETE FROM classroom_service.databasechangelog WHERE id ='add-credit-bearing' AND filename='sat-2882';
COMMIT;