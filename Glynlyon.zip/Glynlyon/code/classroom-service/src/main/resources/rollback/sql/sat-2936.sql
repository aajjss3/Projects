ALTER TABLE classroom_service.class DROP COLUMN done;
ALTER TABLE classroom_service.class DROP COLUMN done_date;
DELETE FROM classroom_service.databasechangelog WHERE id ='add-class-done' AND filename='sat-2936';
COMMIT;