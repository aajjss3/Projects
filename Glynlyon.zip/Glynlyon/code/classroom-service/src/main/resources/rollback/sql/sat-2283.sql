DROP TABLE classroom_service.attempt_save;
ALTER TABLE classroom_service.attempt DROP COLUMN questions_viewed;
DELETE FROM classroom_service.databasechangelog WHERE id ='attempt_save' AND filename='sat-2283';
DELETE FROM classroom_service.databasechangelog WHERE id ='attempt_questions_viewed' AND filename='sat-2283';
COMMIT;