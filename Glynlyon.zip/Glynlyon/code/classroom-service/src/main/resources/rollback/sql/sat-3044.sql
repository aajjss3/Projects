ALTER TABLE classroom_service.attempt DROP COLUMN questions_answered;
DELETE FROM classroom_service.databasechangelog WHERE id ='add-questions-answered' AND filename='sat-3044';
COMMIT;