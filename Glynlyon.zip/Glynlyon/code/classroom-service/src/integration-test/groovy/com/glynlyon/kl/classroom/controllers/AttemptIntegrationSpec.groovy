package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AssignmentRepo
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.service.AttemptService
import com.glynlyon.kl.classroom.service.JsonMappingService
import com.glynlyon.kl.classroom.service.LearnosityDataService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.learnosity.client.LearnosityDataClient
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityResponse
import groovy.json.JsonSlurper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class AttemptIntegrationSpec extends BaseRestSpec{

    User admin, student, student2, teacher
    Organization school

    @Autowired
    AttemptService attemptService

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    AssignmentRepo assignmentRepo

    @Autowired
    JsonMappingService jsonMappingService

    @Autowired
    LearnosityDataService learnosityDataService

    @Value('${learnosity.key}')
    String learnosityKey

    @Value('${learnosity.secret}')
    String learnositySecret

    @Value('${learnosity.organisationId}')
    Integer organisationId


    def setup() {
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		
        teacher = userRepo.save(new User(firstName: 'some', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        student = userRepo.save(new User(firstName: 'some', lastName: 's', userName: 'studnet', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        student2 = userRepo.save(new User(firstName: 'some', lastName: 's', userName: 'studnet', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
		
        learnosityDataService.metaClass.getClient = { String domain ->
            return new LearnosityDataClient("", "", ""){
                @Override
                Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
                    return sessionIds.collectEntries {
                        [(it): new LearnosityGetAllSessionsResponse(
                                userId: UUID.randomUUID(),
                                activityId: UUID.randomUUID(),
                                sessionId: it,
                                numAttempted: 2,
                                numQuestions: 4,
                                score: 100,
                                maxScore: 100,
                                status: "DONE",
                                responses: [
                                        new LearnosityResponse(
                                                responseId: '1f8934cc-9680-4a98-a537-6f9cbfadfc40',
                                                score: 70,
                                                maxScore: 1.0
                                        )
                                ]
                        )]
                    }
                }
            }
        }
    }

	@Unroll
    def "test get assignment review for teacher/student"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        plannerEntryRepo.save(plannerEntry)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))


        def sectionMap =
                [
                   [
                    items: [
                         [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                          sequence: 1 ],
                         [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                          sequence: 2]
                    ],
                    uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                    sequence: 1
                   ],
                   [
                    items: [
                            uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                            sequence: 1
                           ],
                    uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                    sequence: 2
                   ]
                ]

        HashMap responseOverrides = [responseId1:true, responseId2: false, responseId3: null]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(),responseOverrides: responseOverrides, creditBearing: true)
        attemptRepo.save(attempt)

        String token
        if(tokenUser == "teacher") {
            token = createToken(teacher, school.uuid)
        } else if (tokenUser == "admin") {
            token = createToken(admin, school.uuid)
        }
        else {
            token = createToken(student, school.uuid)
        }
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)

        then:
        def expectedItems = attempt.sectionItems.collect { it.items.uuid }.flatten()

        def learnosityInitObjectJSON = new JsonSlurper().parseText(resp.body.learnosity_initialization_object)


        learnosityInitObjectJSON.security.consumer_key == learnosityKey
        learnosityInitObjectJSON.request.activity_id == attempt.activityId.toString()
        learnosityInitObjectJSON.request.items == expectedItems
        learnosityInitObjectJSON.request.events == true
        learnosityInitObjectJSON.request.name == pageAssignment.assignment.title
        learnosityInitObjectJSON.request.state == "review"
        learnosityInitObjectJSON.request.config.showInstructorStimulus == instructorInfo
        learnosityInitObjectJSON.request.config.showCorrectAnswers == instructorInfo
        learnosityInitObjectJSON.request.config.configuration.events == true
        learnosityInitObjectJSON.request.user_id == student.uuid.toString() // we need student id so that teacher can view student's response
        learnosityInitObjectJSON.request.type == "submit_practice"
        learnosityInitObjectJSON.request.rendering_type == "inline"
        learnosityInitObjectJSON.request.organisation_id == organisationId
        resp.body.section_items == sectionMap

        resp.body.response_overrides == responseOverrides

        where:
        tokenUser | instructorInfo
        "teacher" | true
        "student" | false
        "admin"   | true
    }

    def "test get assignment review will re-call Learnosity to fill in blank response overrides"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        plannerEntryRepo.save(plannerEntry)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))

        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(),responseOverrides: null, creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)


        then:
        def expectedItems = attempt.sectionItems.collect { it.items.uuid }.flatten()

        def learnosityInitObjectJSON = new JsonSlurper().parseText(resp.body.learnosity_initialization_object)


        learnosityInitObjectJSON.security.consumer_key == learnosityKey
        learnosityInitObjectJSON.request.activity_id == attempt.activityId.toString()
        learnosityInitObjectJSON.request.items == expectedItems
        learnosityInitObjectJSON.request.events == true
        learnosityInitObjectJSON.request.name == pageAssignment.assignment.title
        learnosityInitObjectJSON.request.state == "review"
        learnosityInitObjectJSON.request.config.showInstructorStimulus == true
        learnosityInitObjectJSON.request.config.showCorrectAnswers == true
        learnosityInitObjectJSON.request.config.configuration.events == true
        learnosityInitObjectJSON.request.user_id == student.uuid.toString() // we need student id so that teacher can view student's response
        learnosityInitObjectJSON.request.type == "submit_practice"
        learnosityInitObjectJSON.request.rendering_type == "inline"
        resp.body.section_items == sectionMap

        resp.body.response_overrides == ['1f8934cc-9680-4a98-a537-6f9cbfadfc40': null]

    }


    def "test get assignment review will return null responses if it can not get responses from learnosity"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        plannerEntryRepo.save(plannerEntry)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))

        learnosityDataService.metaClass.getClient = { String domain ->
            return new LearnosityDataClient("", "", ""){
                @Override
                Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
                    return sessionIds.collectEntries {
                        [(it): new LearnosityGetAllSessionsResponse(
                                userId: UUID.randomUUID(),
                                activityId: UUID.randomUUID(),
                                sessionId: it,
                                numAttempted: 2,
                                numQuestions: 4,
                                score: 100,
                                maxScore: 100,
                                status: "DONE",
                                responses: null
                        )]
                    }
                }
            }
        }

        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(),responseOverrides: null, creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)


        then:
        def expectedItems = attempt.sectionItems.collect { it.items.uuid }.flatten()

        def learnosityInitObjectJSON = new JsonSlurper().parseText(resp.body.learnosity_initialization_object)

        learnosityInitObjectJSON.security.consumer_key == learnosityKey
        learnosityInitObjectJSON.request.activity_id == attempt.activityId.toString()
        learnosityInitObjectJSON.request.items == expectedItems
        learnosityInitObjectJSON.request.events == true
        learnosityInitObjectJSON.request.name == pageAssignment.assignment.title
        learnosityInitObjectJSON.request.state == "review"
        learnosityInitObjectJSON.request.config.showInstructorStimulus == true
        learnosityInitObjectJSON.request.config.showCorrectAnswers == true
        learnosityInitObjectJSON.request.config.configuration.events == true
        learnosityInitObjectJSON.request.user_id == student.uuid.toString() // we need student id so that teacher can view student's response
        learnosityInitObjectJSON.request.type == "submit_practice"
        learnosityInitObjectJSON.request.rendering_type == "inline"
        resp.body.section_items == sectionMap

        resp.body.response_overrides == null

    }

    def "test get assignment review when duplicate activity ids exist"(){
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        PlannerEntry plannerEntryObe = setupPlannerEntry(-11, PlannerEntryState.OBE, classObj, page, pageAssignment, student)
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page, pageAssignment, student)

        Attempt attempt = setupAttempt(plannerEntry, student)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
    }

    def "test get assignment review failure for invalid class / user association"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)

        plannerEntryRepo.save(plannerEntry)

        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        resp.body.errors == "User is not able to review assignment in a class they are not enrolled in."
    }

    def "test get assignment review failure for student accessing another student's review"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student2, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        plannerEntryRepo.save(plannerEntry)

        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(student2, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        resp.body.errors == "User is not able to review assignment that belongs to another student."
    }

    def "test get assignment review internal failure"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))

        plannerEntryRepo.save(plannerEntry)

        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${UUID.randomUUID()}/attempts/${attempt.uuid}/reviews", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        resp.body.errors == "The attempt specified does not belong to the chosen planner entry."
    }

    @Unroll
    def "get assignment review with 'items' request param"(){
        given:
        UUID activityId = UUID.randomUUID()
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        Assignment assignment = new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.LESSON, title: "Assignment Test", created: new Date(), updated: new Date())
        assignmentRepo.save(assignment)
        PlannerEntry plannerEntry = new PlannerEntry(user: student, pageObj: page, classObj: classObj, assignment: pageAssignment.assignment,
                activityId: activityId, status: PlannerEntryState.NOT_STARTED, slot: 1)
        plannerEntryRepo.save(plannerEntry)
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, created: new Date(), updated: new Date()))
        enrollmentRepo.save(new Enrollment(classObj: classObj, user: student, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, created: new Date(), updated: new Date()))


        def sectionMap =
                [
                        [
                                items: [
                                        [uuid: "d3d98ee4-85f6-4fdb-8949-04526389b03e",
                                         sequence: 1 ],
                                        [uuid: "7a4f8026-b991-4a1e-84d0-77a282c298d8",
                                         sequence: 2]
                                ],
                                uuid: "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                sequence: 1
                        ],
                        [
                                items: [
                                        uuid: "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                        sequence: 1
                                ],
                                uuid: "d7ceb274-e1ac-456b-91e5-851f89fa072d",
                                sequence: 2
                        ]
                ]

        HashMap responseOverrides = [responseId1:true, responseId2: false, responseId3: null]

        Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: student, activityId: activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1,
                state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 5, assessmentScore: 5, sectionItems: sectionMap, includedManualGraded: 5, createdAt: new Date(), updatedAt: new Date(),responseOverrides: responseOverrides, creditBearing: true)
        attemptRepo.save(attempt)

        String token = createToken(teacher, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-Client-Domain", "localhost")
        headers.setContentType(Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_REVIEWS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews?items=${items}", HttpMethod.GET, req, Map)

        then:
        def expectedItems = sectionMap.items[0].uuid.flatten()

        resp.statusCode == statusCode
        resp.body.errors == errorMessage
        if(statusCode == HttpStatus.OK) {
            def learnosityInitObjectJSON = new JsonSlurper().parseText(resp.body.learnosity_initialization_object)
            assert learnosityInitObjectJSON.request.items == expectedItems
        }



        where:
        items                                                                           || statusCode            | errorMessage
        'd3d98ee4-85f6-4fdb-8949-04526389b03e,7a4f8026-b991-4a1e-84d0-77a282c298d8'     || HttpStatus.OK         | null
        'i-dont-exist,hi-there'                                                         || HttpStatus.BAD_REQUEST| 'The item(s) [i-dont-exist, hi-there] does not belong to the attempt.'
        'd3d98ee4-85f6-4fdb-8949-04526389b03e,i-dont-exist'                             || HttpStatus.BAD_REQUEST| 'The item(s) [i-dont-exist] does not belong to the attempt.'

    }

    def cleanup() {
        learnosityDataService.metaClass.getClient = null
    }

}
