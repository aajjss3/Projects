package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Configuration
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.embedded.LocalServerPort
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

import java.text.SimpleDateFormat

class ClassControllerIntegrationSpec extends BaseRestSpec {

    @LocalServerPort
    Integer port

    @Autowired
    ClassRepo classRepo

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    ClassGradeLevelRepo gradeLevelRepo

    @Autowired
    ClassGradeLevelService gradeLevelIdService

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    SubjectsService subjectsService

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    User teacher
    User admin, admin2
    User teacher2
    User teacher3
    Organization school
    Organization nullSchool
    Organization campus1
    Organization campus2
    Organization campus3

    List<User> students = []

    def setup(){
        teacher = new User(firstName: 'Teacher 1', lastName: 'teacher Last', userName: 'Teacher1', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        teacher2 = new User(firstName: 'Teacher 2', lastName: 'teacher Last', userName: 'Teacher2', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        teacher3 = new User(firstName: 'Teacher 3', lastName: 'teacher Last', userName: 'Teacher3', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        admin = new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        admin2 = new User(firstName: 'Admin 2', lastName: 'teacher Last 2', userName: 'Test Admin 2', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        school = new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date(), children: [campus1, campus3])
        nullSchool = new Organization(name: 'Null School', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())

        organizationRepo.save(school)
        organizationRepo.save(nullSchool)

        campus1 = new Organization(name: 'Campus 1', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school)
        campus2 = new Organization(name: 'Campus 2', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date())
        campus3 = new Organization(name: 'Campus 3', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school)

        organizationRepo.save(campus1)
        organizationRepo.save(campus2)
        organizationRepo.save(campus3)

        userRepo.save(teacher)
        userRepo.save(teacher2)
        userRepo.save(teacher3)
        admin.organizations = [school, campus1, campus2, campus3]
        admin2.organizations = [nullSchool]
        userRepo.save(admin)
        userRepo.save(admin2)


        (1..5).each {
            students.add(new User(firstName: "testStudent${it}", lastName: "testStudent${it}", userName: 'Test Admin', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date()))
        }

        students.each {
            userRepo.save(it)
        }

        ClassObj.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return classRepo.save(delegate)
        }

        configurationRepo.save(new Configuration(key: Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY, value: 24, description: "test hours"))
    }

    def "should create a class only required fields"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : school.uuid.toString(),
                "creator_uuid"          : teacher.uuid.toString(),
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        ClassObj actual = classRepo.findByUuid(uuid)

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.status as ClassObjState
        assert actual.creatorUuid == teacher.uuid
        assert actual.organization.uuid == school.uuid
        assert actual.subject.uuid == subject.uuid

        def expectedSubject = [
                "subject_uuid" : subject.uuid.toString(),
                "name" : subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+subject.uuid.toString()]
                ]
        ]
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == teacher.uuid.toString()

        def expectedOrg = [
                "organization_uuid" : school.uuid.toString(),
                "name" : school.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + school.uuid.toString()]
                ]
        ]
        assert resp.body.subject == expectedSubject
        assert resp.body.organization == expectedOrg
    }

    @Unroll
    def "should create a class with state, status, or both"() {
        given:
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "name"             : "Biology Period 1",
                "subject_uuid"     : subject.uuid.toString(),
                "organization_uuid": school.uuid.toString(),
                "creator_uuid"     : teacher.uuid.toString(),
        ]

        if(status) {
            body.status = status
        }
        if(state) {
            body.state = state
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.CREATED){
            assert resp.body.status == result
            assert resp.body.state == result
        }

        where:
        status     | state      | expectedStatus          | result
        null       | "BUILDING" | HttpStatus.CREATED      | "BUILDING"
        "BUILDING" | null       | HttpStatus.CREATED      | "BUILDING"
        "BUILDING" | "READY"    | HttpStatus.CREATED      | "READY"
        null       | null       | HttpStatus.BAD_REQUEST  | null

    }


    def "should create a class all fields"() {

        given:
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : school.uuid.toString(),
                "creator_uuid"          : teacher.uuid.toString(),
                "class_id"              : "ID",
                "grade_level"           : ["4", "5"],
                "notes"                 : "NOTE",
                "academic_session_uuid" : academicSession.uuid.toString(),
                "access_date"           : "2016-08-13T09:31:00-07:00",
                "stop_date"             : "2018-08-14T09:31:00-07:00",
                "done"                  : false
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        ClassObj actual = classRepo.findByUuid(uuid)
        List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(uuid)

        def dateFormat = new DateFormat()

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.status as ClassObjState
        assert actual.creatorUuid == teacher.uuid
        assert actual.organization.uuid == school.uuid
        assert actual.subject.uuid == subject.uuid
        assert actual.classId == body.class_id
        assert actual.notes == body.notes
        assert actual.academicSession.uuid == academicSession.uuid
        assert dateFormat.format(actual.accessDate) == body.access_date
        assert dateFormat.format(actual.stopDate) == body.stop_date
        assert actual.completed == null

        assert grades.size() == body.grade_level.size()
        grades.each {
            assert body.grade_level.contains(it.grade.type)
        }

        def expectedSubject = [
                "subject_uuid" : subject.uuid.toString(),
                "name" : subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+subject.uuid.toString()]
                ]
        ]
        assert resp.body.size() == body.size() + 3 //class uuid and metadata and status
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == teacher.uuid.toString()

        def expectedOrg = [
                "organization_uuid" : school.uuid.toString(),
                "name" : school.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + school.uuid.toString()]
                ]
        ]

        assert resp.body.organization == expectedOrg
        assert resp.body.subject == expectedSubject
        assert resp.body.class_id == body.class_id
        assert resp.body.grade_level == body.grade_level
        assert resp.body.notes == body.notes

        def expectedAcademicSession = [
                "academic_session_uuid" : academicSession.uuid.toString(),
                "name" : academicSession.name,
                "type" : academicSession.type.toString(),
                "start_date" : dateFormat.format(academicSession.startDate),
                "end_date" : dateFormat.format(academicSession.endDate),
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/academicsessions/"+academicSession.uuid.toString()]
                ]
        ]
        assert resp.body.academic_session == expectedAcademicSession
        assert resp.body.access_date == body.access_date
        assert resp.body.stop_date == body.stop_date
        assert resp.body.completed_at == null
        assert resp.body.metadata.counts == [students: 0, teachers: 0, admins: 0]
        assert resp.body.done == false
    }

    def "Admin cannot create a class for org they do not belong to"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : nullSchool.uuid.toString(),
                "creator_uuid"          : admin.uuid.toString(),
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        resp.body.errors.field[0] == "organization_uuid"
        resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."
    }

    def "Admin can create a class for a campus that is part of their school"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                 : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : campus1.uuid.toString(),
                "creator_uuid"          : admin.uuid.toString(),
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        ClassObj actual = classRepo.findByUuid(uuid)

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.status as ClassObjState
        assert actual.creatorUuid == admin.uuid
        assert actual.organization.uuid == campus1.uuid
        assert actual.subject.uuid == subject.uuid

        def expectedSubject = [
                "subject_uuid" : subject.uuid.toString(),
                "name" : subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+subject.uuid.toString()]
                ]
        ]
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == admin.uuid.toString()

        def expectedOrg = [
                "organization_uuid" : campus1.uuid.toString(),
                "name" : campus1.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + campus1.uuid.toString()]
                ]
        ]
        assert resp.body.subject == expectedSubject
        assert resp.body.organization == expectedOrg
    }

    @Unroll
    def "should get error message for invalid fields in class creation"(){

        given:
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "status"           : "BUILDING",
                "name"             : "Biology Period 1",
                "subject_uuid"     : subject.uuid.toString(),
                "organization_uuid": school.uuid.toString(),
                "creator_uuid"     : teacher.uuid.toString(),
                "access_date"      : "2016-01-01T12:13:14-07:00",
        ]

        body[invalidField] = value

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:invalidField,message: expectedMessage]]]
        assert expected == resp.body
        assert classRepo.findAll().size() == 0

        where:
        invalidField            | value                                  || expectedMessage
        "creator_uuid"          | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find user with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "creator_uuid"          | ""                                     || "Missing required field creator_uuid"
        "creator_uuid"          | "asdfasfgasd"                          || "Invalid value for creator_uuid asdfasfgasd"
		"subject_uuid"          | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find subject with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "organization_uuid"     | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find organization with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "type"                  | "INVALID"                              || "Invalid value for type INVALID"
        "sub_type"              | "INVALID"                              || "Invalid value for sub_type INVALID"
        "status"                | "INVALID"                              || "Invalid value for status INVALID"
        "type"                  | 8                                      || "Invalid value for type 8 (hint: enum values must be Strings)"
        "name"                  | ""                                     || "Missing required field name"
        "stop_date"             | "2016-01-01T13:13:14-07:00"            || "stop_date must be at least one day after access_date"
        "grade_level"           | [4]                                    || "Invalid value for grade_level 4 (hint: enum values must be Strings)"
        "academic_session_uuid" | "ba5e2e36-488b-47c1-aac8-b9b65fec2b08" || "Could not find academic session with uuid ba5e2e36-488b-47c1-aac8-b9b65fec2b08"
    }

    @Unroll
    def "should get error message for missing required fields"(){
        given:
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "state"            : "BUILDING",
                "name"             : "Biology Period 1",
                "subject_uuid"     : subject.uuid.toString(),
                "organization_uuid": school.uuid.toString(),
                "creator_uuid"     : teacher.uuid.toString(),
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:missingField,message: expectedMessage]]]
        assert expected == resp.body

        where:
        missingField        | expectedMessage
        "creator_uuid"      | "Missing required field creator_uuid"
		"subject_uuid"      | "Missing required field subject_uuid"
        "organization_uuid" | "Missing required field organization_uuid"
        "type"              | "Missing required field type"
        "sub_type"          | "Missing required field sub_type"
        "state"             | "Missing required field state"
        "name"              | "Missing required field name"
    }

    def "test multiple errors for class create"(){

        def body = [
                "status"           : "INVALID",
                "name"             : "Biology Period 1",
                "subject_uuid"     : "50ae4678-83cf-4cae-babb-6be88752593f",
                "organization_uuid": school.uuid.toString(),
                "creator_uuid"     : teacher.uuid.toString(),
                "access_date"      : "blah"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[
                [field:"type",message: "Missing required field type"],
                [field:"sub_type",message: "Missing required field sub_type"],
                [field:"subject_uuid", message:"Could not find subject with uuid 50ae4678-83cf-4cae-babb-6be88752593f"],
                [field:"status", message: "Invalid value for status INVALID"],
                [field:"access_date", message: "Invalid value for access_date blah"]
        ]]
        assert expected.errors.size() == resp.body.errors.size()
        expected.errors.each {e ->
            assert resp.body.errors.contains(e)
        }
    }

    def "should update a class with only required fields"() {
        given:
        def classObj = setupValidClass()

        def body = [
                "type"                 : "CLASS",
                "sub_type"             : "STANDARD",
                "status"               : "BUILDING",
                "name"                 : "Biology Period 1",
                "subject_uuid"         : classObj.subject.uuid.toString(),
                "organization_uuid"    : classObj.organization.uuid.toString(),
                "creator_uuid"         : classObj.creatorUuid.toString()
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        ClassObj actual = classRepo.findByUuid(classObj.uuid)

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.status as ClassObjState
        assert actual.creatorUuid == classObj.creatorUuid
        assert actual.organization.uuid == classObj.organization.uuid
        assert actual.subject.uuid == classObj.subject.uuid

        def expectedSubject = [
                "subject_uuid": classObj.subject.uuid.toString(),
                "name"        : classObj.subject.name,
                "_links"      : [
                        "self": ["href": "http://localhost:" + port + "/subjects/" + classObj.subject.uuid.toString()]
                ]
        ]
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == body.creator_uuid
        def expectedOrg = [
                "organization_uuid" : school.uuid.toString(),
                "name" : school.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + school.uuid.toString()]
                ]
        ]

        assert resp.body.organization == expectedOrg
        assert resp.body.subject == expectedSubject
    }

    def "should update a class with state, status, or both"() {
        given:
        def classObj = setupValidClass()

        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "name"             : "Biology Period 1",
                "subject_uuid"     : subject.uuid.toString(),
                "organization_uuid": school.uuid.toString(),
                "creator_uuid"     : teacher.uuid.toString(),
        ]

        if(status) {
            body.status = status
        }
        if(state) {
            body.state = state
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.OK) {
            assert resp.body.status == result
            assert resp.body.state == result
        }

        where:
        status     | state      | expectedStatus          | result
        null       | "BUILDING" | HttpStatus.OK           | "BUILDING"
        "BUILDING" | null       | HttpStatus.OK           | "BUILDING"
        "BUILDING" | "READY"    | HttpStatus.OK           | "READY"
        null       | null       | HttpStatus.BAD_REQUEST  | null
    }

    def "admin should not be able to update a class not in their org"() {
        given:
        def classObj = setupValidClass()
        Subject newSubject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: nullSchool.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        classObj.subject = subjectsService.findOne(newSubject.uuid, nullSchool.uuid)
        classRepo.save(classObj)

        def body = [
                "type"                 : "CLASS",
                "sub_type"             : "STANDARD",
                "status"               : "BUILDING",
                "name"                 : "Biology Period 1",
                "subject_uuid"         : classObj.subject.uuid.toString(),
                "organization_uuid"    : classObj.organization.uuid.toString(),
                "creator_uuid"         : classObj.creatorUuid.toString()
        ]
        String token = createToken(admin2, nullSchool.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST

        assert resp.body.errors.field[0] == "organization_uuid"
        assert resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."

    }

    def "Soft deleting a class by marking state as completed"() {
        given:
        def classObj = setupValidClass()

        def requestBody = [
                "type"                  : "CLASS",
                "sub_type"             : "STANDARD",
                "name"                 : "Algebra 1",
                "subject_uuid"         : classObj.subject.uuid.toString(),
                "organization_uuid"    : classObj.organization.uuid.toString(),
                "creator_uuid"         : classObj.creatorUuid.toString(),
                "status"               : "COMPLETED",
                "completed_at"         : completedDateInput
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(requestBody, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        DateFormat formatter = new DateFormat()
        assert resp.statusCode == HttpStatus.OK
        ClassObj dbObj = classRepo.findByUuid(classObj.uuid)
        assert dbObj.state == requestBody.status as ClassObjState
        assert resp.body.state == requestBody.status
        assert resp.body.status == requestBody.status

        if(requestBody.completed_at) {
            assert resp.body.completed_at == requestBody.completed_at
            assert formatter.format(dbObj.completed)  == requestBody.completed_at
        }

        else {
            assert resp.body.completed_at != null
            assert dbObj.completed != null
        }

        where:
        completedDateInput << ["2017-01-01T12:13:14-07:00", null]

    }

    def "setting class to done sets the done date"() {
        given:
        def classObj = setupValidClass()

        def requestBody = [
                "type"                 : "CLASS",
                "sub_type"             : "STANDARD",
                "name"                 : "Algebra 1",
                "subject_uuid"         : classObj.subject.uuid.toString(),
                "organization_uuid"    : classObj.organization.uuid.toString(),
                "creator_uuid"         : classObj.creatorUuid.toString(),
                "status"               : "BUILDING",
                "done"                 : done
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(requestBody, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        DateFormat formatter = new DateFormat()
        assert resp.statusCode == HttpStatus.OK
        ClassObj dbObj = classRepo.findByUuid(classObj.uuid)
        assert dbObj.state == requestBody.status as ClassObjState
        assert resp.body.state == requestBody.status
        assert resp.body.status == requestBody.status
        assert resp.body.done == requestBody.done

        if(done) {
            assert resp.body.done_date != null
            assert formatter.format(dbObj.doneDate) == resp.body.done_date
            assert dbObj.done == true
        }

        else {
            assert resp.body.done_date == null
            assert dbObj.doneDate == null
            assert dbObj.done == false
        }

        where:
        done << [true, false]

    }


    @Unroll
    def "should update a class"(){
        given:
        def classObj = setupValidClass()

        if(enrollments){
            createEnrollments(classObj)
        }

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : classObj.subject.uuid.toString(),
                "organization_uuid"     : classObj.organization.uuid.toString(),
                "creator_uuid"          : classObj.creatorUuid.toString(),
                "class_id"              : "ID",
                "grade_level"           : ["4", "5"],
                "notes"                 : "NOTE",
                "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                "access_date"           : "2016-08-13T09:31:00-07:00",
                "stop_date"             : "2018-08-14T09:31:00-07:00"
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        ClassObj actual = classRepo.findByUuid(classObj.uuid)
        List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(classObj.uuid)

        def dateFormat = new DateFormat()

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.status as ClassObjState
        assert actual.creatorUuid == classObj.creatorUuid
        assert actual.organization.uuid == classObj.organization.uuid
        assert actual.subject.uuid == classObj.subject.uuid
        assert actual.classId == body.class_id
        assert actual.notes == body.notes
        assert actual.academicSession.uuid == classObj.academicSession.uuid
        assert dateFormat.format(actual.accessDate) == body.access_date
        assert dateFormat.format(actual.stopDate) == body.stop_date

        assert grades.size() == body.grade_level.size()
        grades.each {
            assert body.grade_level.contains(it.grade.type)
        }

        def expectedSubject = [
                "subject_uuid" : classObj.subject.uuid.toString(),
                "name" : classObj.subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+classObj.subject.uuid.toString()]
                ]
        ]
        assert resp.body.size() == body.size() + 4 //class uuid and metadata and status and done
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == body.creator_uuid

        def expectedOrg = [
                "organization_uuid" : school.uuid.toString(),
                "name" : school.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + school.uuid.toString()]
                ]
        ]

        assert resp.body.organization == expectedOrg
        assert resp.body.subject == expectedSubject
        assert resp.body.class_id == body.class_id
        assert resp.body.grade_level == body.grade_level
        assert resp.body.notes == body.notes

        def expectedAcademicSession = [
                "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                "name" : classObj.academicSession.name,
                "type" : classObj.academicSession.type.toString(),
                "start_date" : dateFormat.format(classObj.academicSession.startDate),
                "end_date" : dateFormat.format(classObj.academicSession.endDate),
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/academicsessions/"+classObj.academicSession.uuid.toString()]
                ]
        ]
        assert resp.body.academic_session == expectedAcademicSession


        assert resp.body.access_date == body.access_date
        assert resp.body.stop_date == body.stop_date
        assert resp.body.metadata.counts == expectedCounts.counts

        where:
        enrollments || expectedCounts
        true        || [counts: [students: 5, teachers: 2, admins: 1]]
        false       || [counts: [students: 0, teachers: 0, admins: 0]]
    }

    @Unroll
    def "should get error message for invalid fields in class update"(){

        given:
        ClassObj classObj = setupValidClass()

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "status"           : "BUILDING",
                "name"             : "Biology Period 1",
                "subject_uuid"     : classObj.subject.uuid.toString(),
                "organization_uuid": classObj.organization.uuid.toString(),
                "creator_uuid"     : classObj.creatorUuid.toString(),
                "access_date"      : "2016-01-01T12:13:14-07:00",
        ]

        body[invalidField] = value

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid , HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:invalidField,message: expectedMessage]]]
        assert expected == resp.body

        def actual = classRepo.findByUuid(classObj.uuid)
        assert actual.type != body.type

        where:
        invalidField            | value                                  || expectedMessage
        "creator_uuid"          | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find user with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "creator_uuid"          | ""                                     || "Missing required field creator_uuid"
        "creator_uuid"          | "asdfasfgasd"                          || "Invalid value for creator_uuid asdfasfgasd"
		"subject_uuid"          | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find subject with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "organization_uuid"     | "50ae4678-83cf-4cae-babb-6be88752593f" || "Could not find organization with uuid 50ae4678-83cf-4cae-babb-6be88752593f"
        "type"                  | "INVALID"                              || "Invalid value for type INVALID"
        "sub_type"              | "INVALID"                              || "Invalid value for sub_type INVALID"
        "status"                | "INVALID"                              || "Invalid value for status INVALID"
        "type"                  | 8                                      || "Invalid value for type 8 (hint: enum values must be Strings)"
        "name"                  | ""                                     || "Missing required field name"
        "stop_date"             | "2016-01-01T13:13:14-07:00"            || "stop_date must be at least one day after access_date"
        "grade_level"           | [4]                                    || "Invalid value for grade_level 4 (hint: enum values must be Strings)"
        "academic_session_uuid" | "ba5e2e36-488b-47c1-aac8-b9b65fec2b08" || "Could not find academic session with uuid ba5e2e36-488b-47c1-aac8-b9b65fec2b08"

    }

    @Unroll
    def "should get error message for missing required fields in class update"(){
        given:
        ClassObj classObj = setupValidClass()

        def body = [
                "type"             : "CLASS",
                "sub_type"         : "STANDARD",
                "state"            : "BUILDING",
                "name"             : "Biology Period 1",
                "subject_uuid"     : classObj.subject.uuid.toString(),
                "organization_uuid": classObj.organization.uuid.toString(),
                "creator_uuid"     : classObj.creatorUuid.toString(),
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/" + classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:missingField,message: expectedMessage]]]
        assert expected == resp.body

        where:
        missingField        | expectedMessage
        "creator_uuid"      | "Missing required field creator_uuid"
		"subject_uuid"      | "Missing required field subject_uuid"
        "organization_uuid" | "Missing required field organization_uuid"
        "type"              | "Missing required field type"
        "sub_type"          | "Missing required field sub_type"
        "state"             | "Missing required field state"
        "name"              | "Missing required field name"
    }


    def "test multiple errors for class update"(){

        ClassObj classObj = setupValidClass()

        def body = [
                "status"           : "INVALID",
                "name"             : "Biology Period 1",
                "subject_uuid"     : "50ae4678-83cf-4cae-babb-6be88752593f",
                "organization_uuid": classObj.organization.uuid.toString(),
                "creator_uuid"     : classObj.creatorUuid.toString(),
                "access_date"      : "blah"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[
                [field:"type",message: "Missing required field type"],
                [field:"sub_type",message: "Missing required field sub_type"],
                [field:"subject_uuid", message:"Could not find subject with uuid 50ae4678-83cf-4cae-babb-6be88752593f"],
                [field:"status", message: "Invalid value for status INVALID"],
                [field:"access_date", message: "Invalid value for access_date blah"]
        ]]
        assert expected.errors.size() == resp.body.errors.size()
        expected.errors.each {e ->
            assert resp.body.errors.contains(e)
        }
    }


    def "test get classes for admin"(){

        given:
        Map<String, ClassObj> classes = setupClasses()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = [classes.teacherCampus1, classes.adminCampus1, classes.adminSchool, classes.teacherSchool].collect{it.uuid.toString()}
        def counts = [counts: [students: 0, admins: 0, teachers: 2]]
        checkClassResponse(resp, expectedUuids, classes, counts)
    }

    @Unroll
    def "test get with and without expired classes"(){

        given:
        Map<String, ClassObj> classes = [
                noDate : (ClassObj)setupValidClass().updateField("state", ClassObjState.COMPLETED),
                completedToday : (ClassObj)setupValidClass().updateField("state", ClassObjState.COMPLETED).updateField("completed", new Date()),
                completedYest : (ClassObj)setupValidClass().updateField("state", ClassObjState.COMPLETED).updateField("completed", new Date() - 1),
                notCompleteToday : (ClassObj)setupValidClass().updateField("state", ClassObjState.READY).updateField("completed", new Date()),
                notCompleteYest : (ClassObj)setupValidClass().updateField("state", ClassObjState.READY).updateField("completed", new Date() - 1)
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?excludeExpiredClasses=${excludeExpiredClasses}", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedClasses.collect{classes."${it}".uuid.toString()}
        checkClassResponse(resp, expectedUuids, classes)

        where:
        excludeExpiredClasses | expectedClasses
        false                 | ["noDate", "completedToday", "completedYest", "notCompleteToday", "notCompleteYest"]
        true                  | ["noDate", "completedToday", "notCompleteToday", "notCompleteYest"]
    }

    @Unroll
    def "test get classes for teacher"(){

        given:
        Map<String, ClassObj> classes = setupClasses()
        User user = null
        if(username == "teacher"){
            user = teacher
        }
        else if(username == "teacher2"){
            user = teacher2
        }

        String token = createToken(user, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedClasses.collect{ classes."${it}".uuid.toString() }
        def counts = [counts: [students: 0, admins: 0, teachers: 2]]
        checkClassResponse(resp, expectedUuids, classes, counts)

        where:
        username   | expectedClasses
        "teacher"  | ["teacherCampus1", "adminCampus1"]
        "teacher2" | ["teacherCampus1", "adminCampus1", "teacherCampus2", "adminCampus2"]
    }

    def "test get classes for student"(){

        given:
        ClassObj classObj = setupValidClass()
        createEnrollments(classObj)

        String token = createToken(new User(type: AppUserType.STUDENT, uuid: students[0].uuid), school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?user_uuid="+students[0].uuid, HttpMethod.GET, req, Map)

        then:
        def counts = [counts: [students: 5, admins: 1, teachers: 2]]
        List<String> expectedUuids = [classObj.uuid.toString()]
        checkClassResponse(resp, expectedUuids, ["c": classObj], counts)

        List<String> expectedTeacherEnrollmentUuids = enrollmentRepo.findAllByClassObjUuidAndRole(classObj.uuid, Role.TEACHER).collect{ it.uuid.toString() }
        List<String> respTeacherEnrollmentUuids = resp.body.classes[0].metadata.enrollments.collect{ it.enrollment_uuid.toString() }
        assert expectedTeacherEnrollmentUuids == respTeacherEnrollmentUuids
    }

    def "test get classes empty result"(){
        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.classes == []
    }

    def "test get classes unknown organization"(){
        given:
        UUID randomOrgUuid = UUID.randomUUID()
        String token = createToken(admin, randomOrgUuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "sub / school_uuid", message: "no organizations found for user ${admin.uuid} in school ${randomOrgUuid}"]]
    }

    @Unroll
    def "test get classes sorting"(){
        given:
        List<ClassObj> classes = setupClassesForSorting(sort)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == classes.size()

        ClassObj expectedFirstClass = classes.find { it.name == expectedFirstClassName}

        def responseClass = resp.body.classes[0]

        assert responseClass.name == expectedFirstClass.name

        where:

        sort                                     | dir              || expectedFirstClassName
        "type"                                   | "asc"            || "typeFirst"
        "type"                                   | "desc"           || "typeLast"
        "status"                                 | "asc"            || "statusFirst"
        "status"                                 | "desc"           || "statusLast"
        "name"                                   | "asc"            || "a first name"
        "name"                                   | "desc"           || "z last name"
        "notes"                                  | "asc"            || "note3"
        "notes"                                  | "desc"           || "note1"
        "class_uuid"                             | "asc"            || "first"
        "class_uuid"                             | "desc"           || "last"
        "sub_type"                               | "asc"            || "subtype2"
        "sub_type"                               | "desc"           || "subtype4"
        "creator_uuid"                           | "asc"            || "c"
        "creator_uuid"                           | "desc"           || "a"
        "class_id"                               | "asc"            || "a"
        "class_id"                               | "desc"           || "c"
        "subject.name"                           | "asc"            || "a"
        "subject.name"                           | "desc"           || "c"
        "subject.subject_uuid"                   | "asc"            || "c"
        "subject.subject_uuid"                   | "desc"           || "a"
        "academic_session.academic_session_uuid" | "asc"            || "c"
        "academic_session.academic_session_uuid" | "desc"           || "a"
        "academic_session.type"                  | "asc"            || "gp"
        "academic_session.type"                  | "desc"           || "t"
        "access_date"                            | "asc"            || "dateFirst"
        "access_date"                            | "desc"           || "dateLast"
        "stop_date"                              | "asc"            || "dateFirst"
        "stop_date"                              | "desc"           || "dateLast"
        "notes,class_id,type"                    | "asc,asc,asc"    || "a"
        "notes,class_id,type"                    | "asc,asc,desc"   || "b"
        "notes,class_id,type"                    | "asc,desc,asc"   || "c"
        "notes,class_id,type"                    | "asc,desc,desc"  || "d"
        "notes,class_id,type"                    | "desc,asc,asc"   || "e"
        "notes,class_id,type"                    | "desc,asc,desc"  || "f"
        "notes,class_id,type"                    | "desc,desc,asc"  || "g"
        "notes,class_id,type"                    | "desc,desc,desc" || "h"

    }

    @Unroll
    def "test get classes sorting errors"() {
        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?sort=${sort}", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [[field:"sort",message: "invalid sort field '${sort}'"]]
        assert expected == resp.body.errors

        where:
        sort << ["organization", "organization.organization_uuid", "organization.name", "foo"]
    }

    def "test get classes with enrollments"(){
        def classObj = setupValidClass()

        createEnrollments(classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = [classObj.uuid.toString()]
        def counts = [counts: [students: 5, admins: 1, teachers: 2]]
        checkClassResponse(resp, expectedUuids, ["c": classObj], counts)
    }

    @Unroll
    def "test teacher can't classes they aren't enrolled in for GET multiple classes"(){
        ClassObj classObj = setupValidClass().updateField("organization", campus1)

        if(enrollments) {
            createEnrollments(classObj)
        }

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        if(enrollments) {
            List<String> expectedUuids = [classObj.uuid.toString()]
            def counts = [counts: [students: 5, admins: 1, teachers: 2]]
            checkClassResponse(resp, expectedUuids, ["c": classObj], counts)
        } else {
            resp.statusCode == HttpStatus.OK
            resp.body.classes.size() == 0
        }

        where:
        enrollments << [false, true]
    }

    def "test teacher can't classes they aren't enrolled in for GET single classes"(){
        def classObj = setupValidClass().updateField("organization", campus1)

        if(enrollments) {
            createEnrollments(classObj)
        }

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}", HttpMethod.GET, req, Map)

        then:
        if(enrollments) {
            resp.statusCode == HttpStatus.OK
            List<String> expectedUuids = [classObj.uuid.toString()]
            def counts = [counts: [students: 5, admins: 1, teachers: 2]]
            checkSingleClassResponse(resp, classObj, counts)

        } else {
            resp.statusCode == HttpStatus.UNAUTHORIZED
            resp.body.errors.field == "role_in_issuer"
            resp.body.errors.message == "Class is not visible to this user"
        }

        where:
        enrollments << [true]
    }

    @Unroll
    def "Test teacher is not allowed to update class they are not enrolled in"(){
        given:
        def classObj = setupValidClass("test name", [Grade.FOUR, Grade.THREE, Grade.EIGHT], campus1)

        if(enrollments){
            createEnrollments(classObj)
        }

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : classObj.subject.uuid.toString(),
                "organization_uuid"     : classObj.organization.uuid.toString(),
                "creator_uuid"          : classObj.creatorUuid.toString(),
                "class_id"              : "ID",
                "grade_level"           : ["4", "5"],
                "notes"                 : "NOTE",
                "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                "access_date"           : "2016-08-13T09:31:00-07:00",
                "stop_date"             : "2018-08-14T09:31:00-07:00"
        ]
        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        if (enrollments) {
            assert resp.statusCode == HttpStatus.OK
            ClassObj actual = classRepo.findByUuid(classObj.uuid)
            List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(classObj.uuid)

            def dateFormat = new DateFormat()

            assert actual != null
            assert actual.type == body.type as ClassObjType
            assert actual.subtype == body.sub_type as ClassObjSubtype
            assert actual.name == body.name
            assert actual.state == body.status as ClassObjState
            assert actual.creatorUuid == classObj.creatorUuid
            assert actual.organization.uuid == classObj.organization.uuid
            assert actual.subject.uuid == classObj.subject.uuid
            assert actual.classId == body.class_id
            assert actual.notes == body.notes
            assert actual.academicSession.uuid == classObj.academicSession.uuid
            assert dateFormat.format(actual.accessDate) == body.access_date
            assert dateFormat.format(actual.stopDate) == body.stop_date

            assert grades.size() == body.grade_level.size()
            grades.each {
                assert body.grade_level.contains(it.grade.type)
            }

            def expectedSubject = [
                    "subject_uuid": classObj.subject.uuid.toString(),
                    "name"        : classObj.subject.name,
                    "_links"      : [
                            "self": ["href": "http://localhost:" + port + "/subjects/" + classObj.subject.uuid.toString()]
                    ]
            ]
            assert resp.body.size() == body.size() + 4 //class uuid and metadata and status abd done
            assert resp.body.type == body.type
            assert resp.body.sub_type == body.sub_type
            assert resp.body.name == body.name
            assert resp.body.state == body.status
            assert resp.body.status == body.status
            assert resp.body.creator_uuid == body.creator_uuid

            def expectedOrg = [
                    "organization_uuid": campus1.uuid.toString(),
                    "name"             : campus1.name,
                    "_links"           : [
                            "self": ["href": "${rosteringBaseUri}" + "/orgs/" + campus1.uuid.toString()]
                    ]
            ]

            assert resp.body.organization == expectedOrg
            assert resp.body.subject == expectedSubject
            assert resp.body.class_id == body.class_id
            assert resp.body.grade_level == body.grade_level
            assert resp.body.notes == body.notes

            def expectedAcademicSession = [
                    "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                    "name" : classObj.academicSession.name,
                    "type" : classObj.academicSession.type.toString(),
                    "start_date" : dateFormat.format(classObj.academicSession.startDate),
                    "end_date" : dateFormat.format(classObj.academicSession.endDate),
                    "_links" : [
                            "self": ["href": "http://localhost:" + port + "/academicsessions/"+classObj.academicSession.uuid.toString()]
                    ]
            ]
            assert resp.body.academic_session == expectedAcademicSession
            assert resp.body.access_date == body.access_date
            assert resp.body.stop_date == body.stop_date
            assert resp.body.metadata.counts == expectedCounts.counts
        } else {
            resp.statusCode == HttpStatus.BAD_REQUEST
            resp.body.errors.field == "role_in_issuer"
            resp.body.errors.message= "TEACHER is not able to edit a class they are not enrolled in."
        }

        where:
        enrollments || expectedCounts
        true        || [counts: [students: 5, teachers: 2, admins: 1]]
        false       || null
    }

    def "test get single class with enrollments"(){
        ClassObj classObj = setupValidClass()
        createEnrollments(classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}", HttpMethod.GET, req, Map)

        then:
        def counts = [counts: [students: 5, admins: 1, teachers: 2]]
        checkSingleClassResponse(resp, classObj, counts)
        
    }

    @Unroll
    def "test get classes with filtering"(){
        List<ClassObj> classList = setupClassesForSorting(field)

        Map<String, ClassObj> classes = classList.collectEntries{[(it.name):it]}

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        if(field == "class_uuid") {
            filter = filter.replace("SOMEID", classes['first'].uuid.toString())
        }
        if(field == "creator_uuid"){
            filter = filter.replace("SOMEID", classes['a'].creatorUuid.toString())
        }
        if(field == "subject.subject_uuid"){
            filter = filter.replace("SOMEID", classes['a'].subject.uuid.toString())
        }
        if(field == "academic_session.academic_session_uuid"){
            filter = filter.replace("SOMEID", classes['b'].academicSession.uuid.toString())
        }

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedNames.collect{classes[it].uuid.toString()}
        checkClassResponse(resp, expectedUuids, classes)

        where:
        field                                    | filter                                                   | expectedNames
        "type"                                   | "type='CLASS'"                                           | ['typeFirst']
        "type"                                   | "type='ILP'"                                             | ['typeLast']
        "status"                                 | "status='BUILDING'"                                      | ['statusFirst']
        "status"                                 | "status='READY'"                                         | ['statusMid1']
        "status"                                 | "status='STARTED'"                                       | ['statusLast']
        "name"                                   | "name='a first name'"                                    | ['a first name']
        "name"                                   | "namecontains'name'"                                     | ['a first name', 'z last name']
        "notes"                                  | "notes='a'"                                              | ['note3']
        "class_uuid"                             | "class_uuid='SOMEID'"                                    | ['first']
        "sub_type"                               | "sub_type='CREDIT_RECOVERY'"                             | ['subtype1']
        "sub_type"                               | "sub_type='ASSESSMENT_BASED'"                            | ['subtype2']
        "sub_type"                               | "sub_type='MIXED'"                                       | ['subtype3']
        "sub_type"                               | "sub_type='STANDARD'"                                    | ['subtype4']
        "sub_type"                               | "sub_type='INDEPENDENT_STUDY'"                           | ['subtype5']
        "creator_uuid"                           | "creator_uuid='SOMEID'"                                  | ['a']
        "class_id"                               | "class_id='b'"                                           | ['b']
        "subject.name"                           | "subject.name='mid z'"                                   | ['b']
        "subject.name"                           | "subject.name='mid z' OR subject.name='a first subj'"    | ['a', 'b']
        "subject.name"                           | "subject.namecontains'subj'"                             | ['a', 'c']
        "subject.name"                           | "subject.namecontains'subj' AND subject.namecontains'z'" | ['c']
        "subject.subject_uuid"                   | "subject.subject_uuid='SOMEID'"                          | ['a']
        "academic_session.academic_session_uuid" | "academic_session.academic_session_uuid='SOMEID'"        | ['b']
        "academic_session.type"                  | "academic_session.type='TERM'"                           | ['t']
        "access_date"                            | "access_date>'${date(-9)}'"                              | ['dateMid', 'dateLast']
        "access_date"                            | "access_date<'${date(-9)}'"                              | ['dateFirst']
        "stop_date"                              | "stop_date>'${date(2)}'"                                 | ['dateMid', 'dateLast']
        "stop_date"                              | "stop_date<'${date(2)}'"                                 | ['dateFirst']
        "grade_level"                            | "grade_levelcontains'1'"                                 | ['a', 'b']
        "grade_level"                            | "grade_levelcontains'PK'"                                | ['a', 'd']
        "grade_level"                            | "grade_levelcontains'PK' AND grade_levelcontains'1'"     | ['a']
        "grade_level"                            | "grade_levelcontains'PK' OR grade_levelcontains'12'"     | ['a', 'c', 'd']
        "grade_level"                            | "grade_levelcontains'PK,12'"                             | ['a', 'c', 'd']
        "grade_level"                            | "grade_levelcontains'PK,1,10'"                           | ['a', 'b', 'c', 'd']
    }

    private static String date(int num){
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date()+num)
    }

    def "test get classes by enrolled user"(){
        given:

        Map<String, ClassObj> classes = [
                a : setupValidClass("a").updateField("notes", "a"),
                b : setupValidClass("b").updateField("notes", "a"),
                c : setupValidClass("c").updateField("notes", "b"),
                d : setupValidClass("d").updateField("notes", "b"),
                e : setupValidClass("e").updateField("notes", "b"),
        ]

        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classes.a, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: students[0], classObj: classes.b, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: students[0], classObj: classes.c, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes?user_uuid=${teacher.uuid}", HttpMethod.GET, req, Map)
        List<String> expectedUuids = ["a"].collect{classes[it].uuid.toString()}
        def counts = [counts: [students: 0, admins: 0, teachers: 1]]

        then:
        checkClassResponse(resp, expectedUuids, classes, counts)

        when:
        resp = testRestTemplate.exchange("/classes?user_uuid=${students[0].uuid}", HttpMethod.GET, req, Map)
        expectedUuids = ["b", "c"].collect{classes[it].uuid.toString()}
        counts = [counts: [students: 1, admins: 0, teachers: 0]]

        then:
        checkClassResponse(resp, expectedUuids, classes, counts)

        when:
        resp = testRestTemplate.exchange("/classes?user_uuid=${students[0].uuid}&filter=notes='b'", HttpMethod.GET, req, Map)
        expectedUuids = ["c"].collect{classes[it].uuid.toString()}
        counts = [counts: [students: 1, admins: 0, teachers: 0]]

        then:
        checkClassResponse(resp, expectedUuids, classes, counts)

        when:
        resp = testRestTemplate.exchange("/classes?user_uuid=74f9a22c-77a8-483a-a415-108aa66cf719", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.classes.size() == 0

        when:
        resp = testRestTemplate.exchange("/classes?user_uuid=blah", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size == 1
        assert resp.body.errors[0].field == "user_uuid"
        assert resp.body.errors[0].message == "invalid uuid blah"

    }

    def "test get single class for admin"(){
        given:
        Map<String, ClassObj> classes = setupClasses()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        UUID adminClassUuid = classes.adminCampus1.uuid

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${adminClassUuid}", HttpMethod.GET, req, Map)

        then:
        resp.body.name == "test name"
        resp.body.class_uuid == adminClassUuid.toString()
    }

    def "test get single class for a teacher"(){
        given:
        Map<String, ClassObj> classes = setupClasses()
        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classes.teacherCampus1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        UUID classUuid = classes.teacherCampus1.uuid

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classUuid}", HttpMethod.GET, req, Map)

        then:
        resp.body.name == "test name"
        resp.body.class_uuid == classUuid.toString()
    }

    def "test get single class that does not exist will throw error"(){
        given:
        setupClasses()

        UUID invalidSchool = UUID.randomUUID()
        String token = createToken(admin, invalidSchool)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${UUID.randomUUID()}", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.UNAUTHORIZED
        resp.body.errors.field == "sub / school_uuid"
        resp.body.errors.message == "no organizations found for user ${admin.uuid} in school ${invalidSchool}"
    }

    def "test get single class for a student will throw error"(){
        given:
        Map<String, ClassObj> classes = setupClasses()

        String token = createToken(new User(type: AppUserType.STUDENT, uuid: UUID.randomUUID()), school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        UUID classUuid = classes.teacherCampus1.uuid

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classUuid}", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        resp.body.errors.field == "role_in_issuer"
        resp.body.errors.message == "only supported roles are ADMIN and TEACHER"
    }

    def "test invalid uuid returns error for single class"(){
        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${UUID.randomUUID()}", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.NOT_FOUND
        resp.body.errors.field == "uuid"
        resp.body.errors.message == "Class does not exist"
    }

    def "test teacher restrictions on a single class"(){
        given:
        ClassObj extraClass = setupValidClass().updateField("organization", campus3)

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        UUID classUuid = extraClass.uuid

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classUuid}", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.UNAUTHORIZED
        resp.body.errors.field == "role_in_issuer"
        resp.body.errors.message == "Class is not visible to this user"
    }

    def "teacher is auto-enrolled when creating a class"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "status"                : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : campus1.uuid.toString(),
                "creator_uuid"          : teacher.uuid.toString(),
        ]
        String token
        if(userType == 'TEACHER') {
            token = createToken(teacher, school.uuid)
        } else {
            token = createToken(admin, school.uuid)
        }
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.CREATED

        if(userType == 'TEACHER') {
            def createdEnrollment = enrollmentRepo.findAll()
            assert createdEnrollment.size() == 1
            createdEnrollment[0].user.uuid.toString() == body.creator_uuid
            createdEnrollment[0].primaryRole == true
            createdEnrollment[0].role == Role.TEACHER
        } else {
            def createdEnrollments = enrollmentRepo.findAll()
            assert createdEnrollments.size() == 0
        }

        def expectedSubject = [
                "subject_uuid" : subject.uuid.toString(),
                "name" : subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+subject.uuid.toString()]
                ]
        ]
        assert resp.body.type == body.type
        assert resp.body.sub_type == body.sub_type
        assert resp.body.name == body.name
        assert resp.body.state == body.status
        assert resp.body.status == body.status
        assert resp.body.creator_uuid == teacher.uuid.toString()

        def expectedOrg = [
                "organization_uuid" : campus1.uuid.toString(),
                "name" : campus1.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + campus1.uuid.toString()]
                ]
        ]
        assert resp.body.subject == expectedSubject
        assert resp.body.organization == expectedOrg
        assert resp.body.metadata.counts == expectedCounts.counts

        where:
        userType    || expectedCounts
        'TEACHER'   || [counts: [students: 0, teachers: 1, admins: 0]]
        'ADMIN'     || [counts: [students: 0, teachers: 0, admins: 0]]
    }

    def cleanup() {
    }

    private List<ClassObj> setupClassesForSorting(String field){
        List<ClassObj> classes = []
        switch (field){
            case "type":
                classes.add(setupValidClass("typeFirst").updateField("type", ClassObjType.CLASS))
                classes.add(setupValidClass("typeLast").updateField("type", ClassObjType.ILP))
                break
            case "status":
                classes.add(setupValidClass("statusFirst").updateField("state", ClassObjState.BUILDING))
                classes.add(setupValidClass("statusMid1").updateField("state", ClassObjState.READY))
                classes.add(setupValidClass("statusLast").updateField("state", ClassObjState.STARTED))
                break
            case "name":
                classes.add(setupValidClass("a first name"))
                classes.add(setupValidClass("middle"))
                classes.add(setupValidClass("z last name"))
                break
            case "notes":
                classes.add(setupValidClass("note3").updateField("notes", "a"))
                classes.add(setupValidClass("note2").updateField("notes", "b"))
                classes.add(setupValidClass("note1").updateField("notes", "c"))
                break
            case "class_uuid":
                ClassObj c1 = setupValidClass()
                ClassObj c2 = setupValidClass()
                ClassObj c3 = setupValidClass()
                def temp = [c1, c2, c3].sort(false) { a, b ->
                    a.uuid.toString() <=> b.uuid.toString()
                }
                classes.add(temp[0].updateField("name", "first"))
                classes.add(temp[1].updateField("name", "a"))
                classes.add(temp[2].updateField("name", "last"))
                break
            case "sub_type":
                classes.add(setupValidClass("subtype1").updateField("subtype", ClassObjSubtype.CREDIT_RECOVERY))
                classes.add(setupValidClass("subtype2").updateField("subtype", ClassObjSubtype.ASSESSMENT_BASED))
                classes.add(setupValidClass("subtype3").updateField("subtype", ClassObjSubtype.MIXED))
                classes.add(setupValidClass("subtype4").updateField("subtype", ClassObjSubtype.STANDARD))
                classes.add(setupValidClass("subtype5").updateField("subtype", ClassObjSubtype.INDEPENDENT_STUDY))
                break
            case "creator_uuid":
                def temp = [teacher, teacher2, teacher3].sort(false) { a, b ->
                    a.uuid.toString() <=> b.uuid.toString()
                }
                classes.add(setupValidClass("c").updateField("creatorUuid", temp[0].uuid))
                classes.add(setupValidClass("b").updateField("creatorUuid", temp[1].uuid))
                classes.add(setupValidClass("a").updateField("creatorUuid", temp[2].uuid))
                break
            case "class_id":
                classes.add(setupValidClass("a").updateField("classId", "a"))
                classes.add(setupValidClass("b").updateField("classId", "b"))
                classes.add(setupValidClass("c").updateField("classId", "c"))
                break
            case "subject.name":
                Subject s1 = subjectRepo.save(new Subject(name: "a first subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                Subject s2 = subjectRepo.save(new Subject(name: "mid z", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                Subject s3 = subjectRepo.save(new Subject(name: "z last subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                classes.add(setupValidClass("a").updateField("subject", subjectsService.findOne(s1.uuid, school.uuid)))
                classes.add(setupValidClass("b").updateField("subject", subjectsService.findOne(s2.uuid, school.uuid)))
                classes.add(setupValidClass("c").updateField("subject", subjectsService.findOne(s3.uuid, school.uuid)))
                break
            case "subject.subject_uuid":
                Subject s1 = subjectRepo.save(new Subject(name: "s1", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                Subject s2 = subjectRepo.save(new Subject(name: "s2", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                Subject s3 = subjectRepo.save(new Subject(name: "s3", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
                def temp = [s1, s2, s3].sort(false) { a, b ->
                    a.uuid.toString() <=> b.uuid.toString()
                }
                classes.add(setupValidClass("c").updateField("subject", subjectsService.findOne(temp[0].uuid, school.uuid)))
                classes.add(setupValidClass("b").updateField("subject", subjectsService.findOne(temp[1].uuid, school.uuid)))
                classes.add(setupValidClass("a").updateField("subject", subjectsService.findOne(temp[2].uuid, school.uuid)))
                break
            case "academic_session.type":
                AcademicSession a1 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                AcademicSession a2 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.GRADING_PERIOD, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                AcademicSession a3 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.SEMESTER, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                classes.add(setupValidClass("t").updateField("academicSession", a1))
                classes.add(setupValidClass("gp").updateField("academicSession", a2))
                classes.add(setupValidClass("s").updateField("academicSession", a3))
                break
            case "academic_session.academic_session_uuid":
                AcademicSession a1 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                AcademicSession a2 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                AcademicSession a3 = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid,  startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
                def temp = [a1, a2, a3].sort(false) { a, b ->
                    a.uuid.toString() <=> b.uuid.toString()
                }
                classes.add(setupValidClass("c").updateField("academicSession", temp[0]))
                classes.add(setupValidClass("b").updateField("academicSession", temp[1]))
                classes.add(setupValidClass("a").updateField("academicSession", temp[2]))
                break
            case "access_date":
                classes.add(setupValidClass("dateFirst").updateField("accessDate", new Date()-10))
                classes.add(setupValidClass("dateMid").updateField("accessDate", new Date()-9))
                classes.add(setupValidClass("dateLast").updateField("accessDate", new Date()-8))
                break
            case "stop_date":
                classes.add(setupValidClass("dateFirst").updateField("stopDate", new Date()+1))
                classes.add(setupValidClass("dateMid").updateField("stopDate", new Date()+2))
                classes.add(setupValidClass("dateLast").updateField("stopDate", new Date()+3))
                break
            case "notes,class_id,type":
                classes.add(setupValidClass("a").updateField("notes", "s").updateField("classId", "y").updateField("type", ClassObjType.CLASS))
                classes.add(setupValidClass("b").updateField("notes", "s").updateField("classId", "y").updateField("type", ClassObjType.ILP))
                classes.add(setupValidClass("c").updateField("notes", "s").updateField("classId", "z").updateField("type", ClassObjType.CLASS))
                classes.add(setupValidClass("d").updateField("notes", "s").updateField("classId", "z").updateField("type", ClassObjType.ILP))
                classes.add(setupValidClass("e").updateField("notes", "t").updateField("classId", "y").updateField("type", ClassObjType.CLASS))
                classes.add(setupValidClass("f").updateField("notes", "t").updateField("classId", "y").updateField("type", ClassObjType.ILP))
                classes.add(setupValidClass("g").updateField("notes", "t").updateField("classId", "z").updateField("type", ClassObjType.CLASS))
                classes.add(setupValidClass("h").updateField("notes", "t").updateField("classId", "z").updateField("type", ClassObjType.ILP))
                break
            case "grade_level":
                classes.add(setupValidClass("a", [Grade.PK, Grade.ONE]))
                classes.add(setupValidClass("b", [Grade.ONE]))
                classes.add(setupValidClass("c", [Grade.TEN, Grade.TWELVE]))
                classes.add(setupValidClass("d", [Grade.PK]))
        }
        return classes
    }

    private void checkSingleClassResponse(HttpEntity resp, ClassObj expectedClass, Map counts){
        def expectedOrg = [
                "organization_uuid" : expectedClass.organization.uuid.toString(),
                "name" : expectedClass.organization.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + expectedClass.organization.uuid.toString()]
                ]
        ]

        def expectedSubject = [
                "subject_uuid" : expectedClass.subject.uuid.toString(),
                "name" : expectedClass.subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+expectedClass.subject.uuid.toString()]
                ]
        ]

        def dateFormat = new DateFormat()

        def expectedAcademicSession = [
                "academic_session_uuid" : expectedClass.academicSession.uuid.toString(),
                "name" : expectedClass.academicSession.name,
                "type" : expectedClass.academicSession.type.toString(),
                "start_date" : dateFormat.format(expectedClass.academicSession.startDate),
                "end_date" : dateFormat.format(expectedClass.academicSession.endDate),
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/academicsessions/"+expectedClass.academicSession.uuid.toString()]
                ]
        ]

        def responseClass = resp.body

        assert expectedClass.type == responseClass.type as ClassObjType
        assert expectedClass.subtype == responseClass.sub_type as ClassObjSubtype
        assert expectedClass.name == responseClass.name
        assert expectedClass.state == responseClass.state as ClassObjState
        assert expectedClass.state == responseClass.status as ClassObjState
        assert expectedClass.creatorUuid.toString() == responseClass.creator_uuid
        assert expectedOrg == responseClass.organization
        assert expectedSubject == responseClass.subject
        assert expectedClass.classId == responseClass.class_id
        assert expectedClass.notes == responseClass.notes
        assert expectedAcademicSession == responseClass.academic_session
        assert dateFormat.format(expectedClass.accessDate) == responseClass.access_date
        assert dateFormat.format(expectedClass.stopDate) == responseClass.stop_date

        List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(expectedClass.uuid)
        assert grades.size() > 0 && grades.size() == responseClass.grade_level.size()
        grades.each {
            assert responseClass.grade_level.contains(it.grade.type)
        }
        assert counts.counts == responseClass.metadata.counts
    }

    private void checkClassResponse(HttpEntity resp, List<String> expectedUuids, Map<String, ClassObj> classes, Map counts = null){
        ClassObj classObj1 = classes.values().find { it.uuid.toString() == expectedUuids.first()}

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == expectedUuids.size()

        assert resp.body.classes.size == expectedUuids.size()
        resp.body.classes.each { c ->
            assert expectedUuids.contains(c.class_uuid)
            expectedUuids.remove(c.class_uuid)
        }

        def dateFormat = new DateFormat()

        def expectedOrg = [
                "organization_uuid" : classObj1.organization.uuid.toString(),
                "name" : classObj1.organization.name,
                "_links" : [
                        "self": ["href": "${rosteringBaseUri}" + "/orgs/" + classObj1.organization.uuid.toString()]
                ]
        ]

        def expectedSubject = [
                "subject_uuid" : classObj1.subject.uuid.toString(),
                "name" : classObj1.subject.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/subjects/"+classObj1.subject.uuid.toString()]
                ]
        ]

        def expectedAcademicSession = [
                "academic_session_uuid" : classObj1.academicSession.uuid.toString(),
                "name" : classObj1.academicSession.name,
                "type" : classObj1.academicSession.type.toString(),
                "start_date" : dateFormat.format(classObj1.academicSession.startDate),
                "end_date" : dateFormat.format(classObj1.academicSession.endDate),
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/academicsessions/"+classObj1.academicSession.uuid.toString()]
                ]
        ]

        def responseClass = resp.body.classes.find { it.class_uuid == classObj1.uuid.toString() }

        assert classObj1.type == responseClass.type as ClassObjType
        assert classObj1.subtype == responseClass.sub_type as ClassObjSubtype
        assert classObj1.name == responseClass.name
        assert classObj1.state == responseClass.state as ClassObjState
        assert classObj1.state == responseClass.status as ClassObjState
        assert classObj1.creatorUuid.toString() == responseClass.creator_uuid
        assert expectedOrg == responseClass.organization
        assert expectedSubject == responseClass.subject
        assert classObj1.classId == responseClass.class_id
        assert classObj1.notes == responseClass.notes
        assert expectedAcademicSession == responseClass.academic_session
        assert dateFormat.format(classObj1.accessDate) == responseClass.access_date
        assert dateFormat.format(classObj1.stopDate) == responseClass.stop_date

        List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(classObj1.uuid)
        assert grades.size() > 0 && grades.size() == responseClass.grade_level.size()
        grades.each {
            assert responseClass.grade_level.contains(it.grade.type)
        }
        if(counts){
            assert counts.counts == responseClass.metadata.counts
        }
        else{
            assert [students: 0, teachers: 0, admins: 0] == responseClass.metadata.counts
        }

    }

    private Map<String, ClassObj> setupClasses(){
        ClassObj classObj1 = setupValidClass().updateField("organization", campus1)
        ClassObj classObj2 = setupValidClass().updateField("organization", campus1).updateField("creatorUuid", admin.uuid)
        ClassObj classObj3 = setupValidClass().updateField("organization", campus2)
        ClassObj classObj4 = setupValidClass().updateField("organization", campus2).updateField("creatorUuid", admin.uuid)
        ClassObj classObj5 = setupValidClass()
        ClassObj classObj6 = setupValidClass().updateField("creatorUuid", admin.uuid)

        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj2, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher2, classObj: classObj1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher2, classObj: classObj2, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher2, classObj: classObj3, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher2, classObj: classObj4, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        return [
                teacherCampus1 : classObj1,
                adminCampus1 : classObj2,
                teacherCampus2 : classObj3,
                adminCampus2 : classObj4,
                teacherSchool : classObj5,
                adminSchool : classObj6
        ]
    }

    private void createEnrollments(ClassObj classObj){
        enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher2, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

        students.each {
            enrollmentRepo.save(new Enrollment(user: it, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        }
    }

    private ClassObj setupValidClass(String name = "test name", List<Grade> grades = [Grade.FOUR, Grade.THREE, Grade.EIGHT], Organization org = school)
    {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid:school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: name,
                subject: subjectsService.findOne(subject.uuid, school.uuid),
                organization: org,
                creatorUuid: teacher.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                done: false
        )
        classObj = classRepo.save(classObj)
        gradeLevelIdService.save(classObj.uuid, grades)
        return classObj
    }
}
