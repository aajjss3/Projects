package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import com.glynlyon.learnosity.client.LearnosityDataClient
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class ItemAnalysisReportIntegrationSpec extends BaseRestSpec {

    @Autowired
    LearnosityDataService learnosityDataService

    User admin, teacher, jasnah, shallan, adolin
    Organization school, campus1

    Map<String, Attempt> attemptMap = [:]
    Map<String, PlannerEntry> peMap = [:]
    Map<String, PageAssignment> paMap = [:]
    Map<String, PageObj> pageMap = [:]

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        teacher = userRepo.save(new User(firstName: 'Ned', lastName: 'Stark', userName: 'nstark', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        campus1 = organizationRepo.save(new Organization(name: 'campus1', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))

        shallan = userRepo.save(new User(firstName: 'shallan', lastName: 'davar', userName: 'sdavar', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        adolin = userRepo.save(new User(firstName: 'adolin', lastName: 'kholin', userName: 'akholin', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        jasnah = userRepo.save(new User(firstName: 'jasnah', lastName: 'kholin', userName: 'jkholin', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))


        learnosityDataService.metaClass.getClient = { String domain ->
            return new LearnosityDataClient("", "", ""){
                @Override
                Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
                    return sessionIds.collectEntries {
                        [(it): new LearnosityGetAllSessionsResponse(
                                responses: [[null, 1, false], [0, 1, true], [1, 1, true]].collect {
                                    return new LearnosityResponse(
                                            responseId: "respId",
                                            itemReference: "itemRef",
                                            questionReference: "qRef",
                                            score: it[0],
                                            maxScore: it[1],
                                            attempted: it[2],
                                    )
                                }
                        )]
                    }
                }
            }
        }
    }

    private void setupData(Boolean enrollAll = false){
        ClassObj class1 = setupValidClass(admin, campus1)

        [adolin, jasnah].each {
            createEnrollment(class1, it, Role.STUDENT)
        }
        if(enrollAll){
            createEnrollment(class1, shallan, Role.STUDENT)
        }

        PageObj page1 = setupValidPage("page1", class1, 1)
        PageObj page2 = setupValidPage("page2", class1, 2)

        pageMap = [
                page1: page1,
                page2: page2
        ]

        PageAssignment p1pa1 = setupValidPageAssignment("p1pa1", page1, 1)
        PageAssignment p1pa2 = setupValidPageAssignment("p1pa2", page1, 2)
        PageAssignment p1pa3 = setupValidPageAssignment("p1pa3", page1, 3)
        PageAssignment p2pa1 = setupValidPageAssignment("p2pa1", page2, 1)

        paMap = [
                p1pa1: p1pa1,
                p1pa2: p1pa2,
                p1pa3: p1pa3,
                p2pa1: p2pa1
        ]

        PlannerEntry peA1 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa1, adolin)
        PlannerEntry peA2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa2, adolin)
        PlannerEntry peA21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p2pa1, adolin)

        PlannerEntry peJ1 = setupPlannerEntry(-1, PlannerEntryState.OBE, class1, page1, p1pa1, jasnah)
        PlannerEntry peJ2 = setupPlannerEntry(-1, PlannerEntryState.OBE, class1, page1, p1pa2, jasnah)
        PlannerEntry peJ21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa1, jasnah)

        PlannerEntry peS1 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa1, shallan)
        PlannerEntry peS2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa2, shallan)
        PlannerEntry peS21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa1, shallan)

        peMap = [
                peA1: peA1,
                peA2: peA2,
                peA21: peA21,
                peJ1: peJ1,
                peJ2: peJ2,
                peJ21: peJ21,
                peS1: peS1,
                peS2: peS2,
                peS21: peS21,
        ]

        attemptMap = [:]
        [adolin, jasnah, shallan].each { User user ->
            Map<String, PlannerEntry> active = [:]
            if(user == adolin){
                active = peMap.take(3)
            }
            else if(user == jasnah){
                active = peMap.take(6).drop(3)
            }
            else if(user == shallan){
                active = peMap.drop(6)
            }
            active.each { key, pe ->
                attemptMap["${key.replaceAll("pe", "")}_1"] = setupAttempt(pe, user, AttemptState.OBE, 0.75, null, new Date(), false)
                attemptMap["${key.replaceAll("pe", "")}_2"] = setupAttempt(pe, user, AttemptState.IN_PROGRESS, null, null, null, false)
                attemptMap["${key.replaceAll("pe", "")}_3"] = setupAttempt(pe, user, AttemptState.SAVED, null, null, null, false)
                attemptMap["${key.replaceAll("pe", "")}_4"] = setupAttempt(pe, user, AttemptState.SUBMITTED, null, null, new Date()+1, false)
                attemptMap["${key.replaceAll("pe", "")}_5"] = setupAttempt(pe, user, AttemptState.FAILED, 0.4, null, new Date()-1, false)
                attemptMap["${key.replaceAll("pe", "")}_6"] = setupAttempt(pe, user, AttemptState.PASSED, 0.8, null, new Date(), true)
            }
        }
    }

    private Map createExpectedResp(Attempt expected){
        DateFormat dateFormat = new DateFormat()

        return [
                credit_bearing: expected.creditBearing,
                user_uuid     : expected.user.uuid.toString(),
                first_name    : expected.user.firstName,
                last_name     : expected.user.lastName,
                activity_id   : expected.activityId.toString(),
                session_id    : expected.uuid.toString(),
                date_submitted: dateFormat.format(expected.completedAt),
                status        : expected.state.toString(),
                planner_entry_uuid : expected.plannerEntry.uuid.toString(),
                questions : [
                        [
                                response_id: "respId",
                                item_reference: "itemRef",
                                question_reference: "qRef",
                                score: null,
                                max_score: 1,
                                attempted: false,
                                overridden: false
                        ],
                        [
                                response_id: "respId",
                                item_reference: "itemRef",
                                question_reference: "qRef",
                                score: 0,
                                max_score: 1,
                                attempted: true,
                                overridden: false
                        ],
                        [
                                response_id: "respId",
                                item_reference: "itemRef",
                                question_reference: "qRef",
                                score: 1,
                                max_score: 1,
                                attempted: true,
                                overridden: false
                        ]
                ]
        ]
    }

    @Unroll
    def "should get item analysis report"(){
        given:
        setupData()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("x-client-domain", "localhost")
        headers.setAccept([Constants.ITEM_ANALYSIS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        DateFormat dateFormat = new DateFormat()

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageMap[page].uuid}/assignments/${paMap[pa].uuid}/reports/itemAnalysis", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.OK
        assert resp.body.attempts.size() == expectedAttempts.size()

        if(expectedAttempts) {
            expectedAttempts.eachWithIndex { String key, Integer index ->
                Attempt expected = attemptMap[key]
                Map expectedResp = createExpectedResp(expected)

                assert resp.body.attempts[index] == expectedResp
            }
        }

        where:
        page    | pa      || expectedAttempts
        "page1" | "p1pa1" || ["A1_4", "A1_6", "A1_5"]
        "page1" | "p1pa2" || ["A2_4", "A2_6", "A2_5"]
        "page1" | "p1pa3" || []
        "page2" | "p2pa1" || ["J21_4", "A21_4", "J21_6", "A21_6", "J21_5", "A21_5"]
    }

    @Unroll
    def "should test errors and role permissions for item analysis report"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus1)
        PageObj page = setupValidPage(classObj)
        Map<String, User> users = [admin: admin, teacher: teacher, student: jasnah]
        Map<String, UUID> orgs = [school : school.uuid, random: UUID.randomUUID()]
        Map<String, UUID> pages = [page: page.uuid, random: UUID.randomUUID()]

        if (enroll) {
            if (user == "teacher") {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
            }
            else {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            }
        }

        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        Map<String, UUID> pageAssignments = [pa: existing.uuid, random: UUID.randomUUID()]

        String token = createToken(users[user], orgs[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-CLIENT-DOMAIN", "domain")
        headers.setAccept([Constants.ITEM_ANALYSIS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        message = message.replaceAll("PAGE_UUID", pages[pageid].toString())
        message = message.replaceAll("ORG_UUID", orgs[org].toString())
        message = message.replaceAll("PA_UUID", pageAssignments[page_assignment].toString())

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pages[pageid]}/assignments/${pageAssignments[page_assignment]}/reports/itemAnalysis", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == expectedStatus
        assert resp.body.error == message

        where:
        user      | org      | pageid   | page_assignment | enroll || expectedStatus       | message
        "teacher" | "school" | "page"   | "pa"            | false  || HttpStatus.NOT_FOUND | "Could not find page PAGE_UUID in organization ORG_UUID"
        "student" | "school" | "page"   | "pa"            | false  || HttpStatus.FORBIDDEN | "only supported roles are ADMIN, TEACHER"
        "student" | "school" | "page"   | "pa"            | true   || HttpStatus.FORBIDDEN | "only supported roles are ADMIN, TEACHER"
        "admin"   | "random" | "page"   | "pa"            | false  || HttpStatus.NOT_FOUND | "Could not find page PAGE_UUID in organization ORG_UUID"
        "admin"   | "school" | "random" | "pa"            | false  || HttpStatus.NOT_FOUND | "Could not find page PAGE_UUID in organization ORG_UUID"
        "admin"   | "school" | "page"   | "random"        | false  || HttpStatus.NOT_FOUND | "Could not find page assignment PA_UUID in page PAGE_UUID"
    }

    @Unroll
    def "should test filtering and sorting"(){
        setupData(true)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("x-client-domain", "localhost")
        headers.setAccept([Constants.ITEM_ANALYSIS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        filter = filter.replaceAll("JASNAH_UUID", jasnah.uuid.toString())
        filter = filter.replaceAll("S21_5_UUID", attemptMap["S21_5"].uuid.toString())

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageMap["page2"].uuid}/assignments/${paMap["p2pa1"].uuid}/reports/itemAnalysis?filter=${filter}&sort=${sort}&orderBy=${orderBy}", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == HttpStatus.OK
        assert resp.body.attempts.size() == expectedAttempts.size()

        if (expectedAttempts) {
            expectedAttempts.eachWithIndex { String key, Integer index ->
                Attempt expected = attemptMap[key]
                Map expectedResp = createExpectedResp(expected)

                assert resp.body.attempts[index] == expectedResp
            }
        }

        where:
        filter                     | sort                            | orderBy    | expectedAttempts
        "credit_bearing='true'"    | ""                              | ""         | ["S21_6", "J21_6", "A21_6"]
        "credit_bearing='false'"   | ""                              | ""         | ["S21_4", "J21_4", "A21_4", "S21_5", "J21_5", "A21_5"]
        "user_uuid='JASNAH_UUID'"  | ""                              | ""         | ["J21_4", "J21_6", "J21_5"]
        "first_name='jasnah'"      | ""                              | ""         | ["J21_4", "J21_6", "J21_5"]
        "last_name='kholin'"       | ""                              | ""         | ["J21_4", "A21_4", "J21_6", "A21_6", "J21_5", "A21_5"]
        "session_id='S21_5_UUID'"  | ""                              | ""         | ["S21_5"]
        "status='SUBMITTED'"       | ""                              | ""         | ["S21_4", "J21_4", "A21_4"]
        "last_name='kholin'"       | "first_name,date_submitted"     | "asc,desc" | ["A21_4", "A21_6", "A21_5", "J21_4", "J21_6", "J21_5"]
        "credit_bearing='true'"    | "last_name,first_name"          | ""         | ["S21_6", "A21_6", "J21_6"]
        "first_name='jasnah'"      | "credit_bearing,date_submitted" | "desc,asc" | ["J21_6", "J21_5", "J21_4"]
        "first_name='jasnah'"      | "status"                        | ""         | ["J21_5", "J21_6", "J21_4"]
    }

}
