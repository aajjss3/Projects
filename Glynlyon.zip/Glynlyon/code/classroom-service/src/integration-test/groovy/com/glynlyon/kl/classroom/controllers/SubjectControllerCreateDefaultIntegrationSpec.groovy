package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.DefaultSubject
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.SubjectsViewRepo
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class SubjectControllerCreateDefaultIntegrationSpec extends BaseRestSpec {

    @Autowired
    SubjectsViewRepo subjectsViewRepo

    User admin
    User supportAdmin
    Organization school, school2

    def setup() {
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date()))
        admin = userRepo.save(new User(firstName: 'testAdmin', lastName: 'admin Last', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))
        supportAdmin = userRepo.save(new User(firstName: 'support', lastName: 'sadmin', userName: 'support', type: AppUserType.SUPPORT_ADMINISTRATOR, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date()))
    }

    @Unroll
    def "Support Admin should be able to create default subjects"() {
        given:
        def body = [
                "name"             : "new default",
        ]
        String token = createToken(supportAdmin, null)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/defaultsubjects", HttpMethod.POST, req, Map)

        then:
        assert defaultSubjectRepo.findAll().size() == 1
        SubjectsView actual = subjectsViewRepo.findByNameIgnoreCaseAndOrganizationUuid("new default", school.uuid)
        assert actual.organizationUuid == school.uuid
        assert actual.defaultSubject == true

        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.name == actual.name
    }

    @Unroll
    def "Should get error if default subject name already exists"() {
        given:
        DefaultSubject existing = defaultSubjectRepo.save(new DefaultSubject(name: "existing", createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "name"             : existing.name,
        ]
        String token = createToken(supportAdmin, null)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/defaultsubjects", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "name", message: messagesUtil.get("subjects.default.error.existing")]]
        assert defaultSubjectRepo.findAll().size() == 1
    }

    @Unroll
    def "Should get error if custom subject name already exists"() {
        given:
        Subject existing = subjectRepo.save(new Subject(name: 'Existing Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        Subject existing2 = subjectRepo.save(new Subject(name: 'Existing Subject', organizationUuid: school2.uuid, disabled: true, createdAt: new Date(), updatedAt: new Date()))

        def body = [
                "name"             : existing.name,
        ]
        String token = createToken(supportAdmin, null)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/defaultsubjects", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "name", message: messagesUtil.get("subjects.default.error.custom.existing", ["{${school.uuid}, ${school.name}}", "{${school2.uuid}, ${school2.name}}"])]]
        assert defaultSubjectRepo.findAll().size() == 0
    }

    @Unroll
    def "should validate roles for create default subject"(){
        given:
        def body = [
                "name"             : "new default",
        ]
        User user = userRepo.save(new User(firstName: 'test', lastName: 'user', userName: 'uname', type: role, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))

        String token = createToken(user, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/defaultsubjects", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.FORBIDDEN
        assert defaultSubjectRepo.findAll().size() == 0

        where:
        role << AppUserType.values().findAll{it != AppUserType.SUPPORT_ADMINISTRATOR}

    }

}
