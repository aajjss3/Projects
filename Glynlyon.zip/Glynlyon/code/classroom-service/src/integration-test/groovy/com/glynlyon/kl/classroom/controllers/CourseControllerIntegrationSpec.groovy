package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.*
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.CourseRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.embedded.LocalServerPort
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

import java.text.SimpleDateFormat

class CourseControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    CourseRepo courseRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    OrganizationRepo organizationRepo


    User admin, supportAdmin
    RosteringOrganization school
    Course course1, course2

    def setup(){
        supportAdmin = new User(userName: 's. admin', firstName: 'first', lastName: 'last', type: AppUserType.SUPPORT_ADMINISTRATOR, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin = new User(userName:'admin',firstName: "test", lastName: "admin", type: AppUserType.ADMIN,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        school = new RosteringOrganization(uuid: UUID.randomUUID())
        course1 = new Course(uuid: UUID.randomUUID())
        course2 = new Course(uuid: UUID.randomUUID())
        courseRepo.save(course1)
        courseRepo.save(course2)

        userRepo.save(admin)


    }

    def "test get whitelist of courses"(){

        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.COURSES_VERSION_1_MT)
        headers.setAccept([Constants.COURSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)



        when:
        HttpEntity resp = testRestTemplate.exchange("/courses", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = [course1.uuid, course2.uuid].collect{it.toString()}
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.courses.size == expectedUuids.size()
        resp.body.courses.each { c ->
            assert expectedUuids.contains(c.course_uuid)
        }

    }

    def "test add courses to whitelist"() {
        given:
        UUID course1Uuid = UUID.randomUUID()
        UUID course2Uuid = UUID.randomUUID()

        def body = [courses: [[
                                 "course_uuid": course1Uuid
                              ],
                              [
                                 "course_uuid": course2Uuid
                              ]
        ]]

        String token = createToken(supportAdmin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.COURSES_VERSION_1_MT)
        headers.setAccept([Constants.COURSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/courses", HttpMethod.POST, req, Map)

        then:
        resp.body.successes.size == 2
        Course course1 = courseRepo.findByUuid(course1Uuid)
        Course course2 = courseRepo.findByUuid(course2Uuid)
        assert course1.uuid == course1Uuid
        assert course2.uuid == course2Uuid
    }

    def "test failure for adding duplicate to whitelist"() {
        given:
        UUID course1Uuid = UUID.randomUUID()
        UUID course2Uuid = UUID.randomUUID()

        courseRepo.save(new Course(uuid: course1Uuid))

        def body = [courses: [[
                                      "course_uuid": course1Uuid
                              ],
                              [
                                      "course_uuid": course2Uuid
                              ]
        ]]

        String token = createToken(supportAdmin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.COURSES_VERSION_1_MT)
        headers.setAccept([Constants.COURSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/courses", HttpMethod.POST, req, Map)

        then:
        resp.body.successes.size == 1
        resp.body.failures.size == 1
        resp.body.failures[0].errors[0] == "Course already exists."

        Course course2 = courseRepo.findByUuid(course2Uuid)
        assert course2.uuid == course2Uuid

    }

    def "delete courses from whitelist"() {
        given:
        UUID randomUUID = UUID.randomUUID()
        UUID courseToDelete = course1.uuid

        def body = [courses: [[
                                      "course_uuid": courseToDelete
                              ],
                              [
                                      "course_uuid": randomUUID
                              ]
        ]]

        String token = createToken(supportAdmin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.COURSES_VERSION_1_MT)
        headers.setAccept([Constants.COURSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/courses", HttpMethod.DELETE, req, Map)

        then:
        resp.body.successes.size == 1
        resp.body.failures.size == 1
        resp.body.failures[0].errors[0] == env.getProperty("course.error.notfound")
        courseRepo.findByUuid(courseToDelete) == null

    }

}