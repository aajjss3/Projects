package com.glynlyon.kl.classroom.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpRequest
import org.springframework.http.HttpStatus

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.Launch
import com.glynlyon.kl.classroom.repo.LaunchRepo

class LaunchControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    LaunchesController controller

    @Autowired
    LaunchRepo launchRepo

    def "A GET request will mark a token as launched"(){
        given:
        def token = createToken()

        Launch existingJwt = new Launch(token)
        existingJwt.launched = tokenUsed
        launchRepo.save(existingJwt)

        if(expectedStatus == HttpStatus.NOT_FOUND) {
            existingJwt.uuid = UUID.randomUUID()
        }

        when:
        def resp = controller.markToken(existingJwt.uuid)

        then:
        assert resp.statusCode == expectedStatus
        if(expectedBody == true) {
            assert resp.body.jwt == existingJwt.jwt
        } else {
            assert resp.body == expectedBody
        }

        where:
        tokenUsed | expectedStatus         | expectedBody
        false     | HttpStatus.OK          | true
        false     | HttpStatus.NOT_FOUND   | null
        true      | HttpStatus.GONE        | null
    }

    def "should create Launch and associated jwt with random uuid"(){
        when:
        HttpRequest req = createRequest()
        HttpEntity resp = testRestTemplate.exchange("/launches", HttpMethod.POST, req.entity, String.class)

        then:
        assert resp.statusCode == HttpStatus.FOUND
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.fragment.substring(location.fragment.lastIndexOf("/") + 1))
        Launch actual = launchRepo.findOne(uuid)
        assert actual.jwt == req.token
        assert actual.date_launched == null
        assert !actual.launched
    }
}