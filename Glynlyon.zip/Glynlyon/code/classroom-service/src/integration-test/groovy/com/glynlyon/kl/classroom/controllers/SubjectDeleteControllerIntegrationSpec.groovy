package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Configuration
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll
/**
 * Contains integration tests for deleting a subject and unassigning any soft deleted classes associated with that subject. 
 * @author asparago
 * tests:
 * 1) unsuccessful delete - the subject_uuid passed in does not exist in the database
 * 2) unsuccessful delete - role is TEACHER, STUDENT, SUPPORT_ADMINISTRATOR, PARENT,  SUPPORT_LICENSING, SUPPORT_USER, SUPPORT_CEM
 * 3) unsuccessful delete - role is ADMIN but admin belong to a different organization than the subject
 * 4) unsuccessful delete - subject contains 2 classes: one is soft deleted and the other class has the state of: BUILDING, READY, STARTED
 * 5) unsuccessful delete - subject contains 2 classes: one is soft deleted and the other class has a state of COMPLETED with a completed_at time that is equal to the current time
 * 6) successful delete - for a subject with no classes
 * 7) successful delete - for a subject with 2 soft deleted classes
 *
 */
class SubjectDeleteControllerIntegrationSpec  extends BaseRestSpec{
	
	Organization school1, school2, campus1, campus3
	User user1, user2
	
	
	def setup() {
		configurationRepo.save(new Configuration("key": Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY, "value":"24", "description":"duration"))
		school1 = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date(), children: [campus1, campus3]))
		school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date()))
		campus1 = organizationRepo.save(new Organization(name: 'Campus 1', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school1))
		campus3 = organizationRepo.save(new Organization(name: 'Campus 3', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school1))
		user1 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test1', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school1]))
		user2 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test2', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school2]))
	}
	
	def "unsuccessful delete for a subject uuid that does not exist"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
			
			String token = createToken(user1, school1.uuid)
			
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/53bf0e2b-1152-4807-b67b-7264e9fc21d6", HttpMethod.DELETE, req, Object)
		then:
			assert response.statusCode == HttpStatus.NOT_FOUND
	}
	
	@Unroll
	def "successful delete for an ADMIN and unsuccessful delete for any other role"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
			user1.type = role
			String token = createToken(user1, school1.uuid)
			
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/"+subject.uuid.toString(), HttpMethod.DELETE, req, Object)
		then:
			assert response.statusCode == expectedStatusCode
		
		where:	
			role								|	expectedStatusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT					|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM				|	HttpStatus.FORBIDDEN
			AppUserType.TEACHER					|	HttpStatus.FORBIDDEN
			AppUserType.STUDENT					|	HttpStatus.FORBIDDEN
			AppUserType.ADMIN					|	HttpStatus.NO_CONTENT
	}

	
	def "unsuccessful delete for an ADMIN that does not have access to the subjects organization"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
			
			String token = createToken(user2, school2.uuid)
			
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/"+subject.uuid.toString(), HttpMethod.DELETE, req, Object)
		then:
			assert response.statusCode == HttpStatus.UNAUTHORIZED
	}
	
	def "successful delete for subject that has 2 soft deleted classes associated with it"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
						
			createClass(subject, ClassObjState.COMPLETED, new Date()-10, school1)
			createClass(subject, ClassObjState.COMPLETED, new Date()-11, school1)
			
			String token = createToken(user1, school1.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/"+subject.uuid.toString(), HttpMethod.DELETE, req, Object)
		then:
			List<ClassObj> classes = retrieveClasses(school1.uuid, subject.uuid)
			assert response.statusCode == HttpStatus.NO_CONTENT
			assert classes[0].subject == null
			assert classes[1].subject == null

	}
	
	@Unroll
	def "unsuccessful delete for subject that has 2 classes - one class is not soft deleted due to a non COMPLETED state"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
						
			createClass(subject, status, new Date()-10, school1)
			createClass(subject, status, new Date()-11, school1)
			
			String token = createToken(user1, school1.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/"+subject.uuid.toString(), HttpMethod.DELETE, req, Object)
		then:
			List<ClassObj> classes = retrieveClasses(school1.uuid, subject.uuid)
			assert response.statusCode == result
			assert classes[0].subject != null
			assert classes[1].subject != null
			
		where:
			status | result
			ClassObjState.BUILDING	| HttpStatus.FORBIDDEN
			ClassObjState.READY		| HttpStatus.FORBIDDEN
			ClassObjState.STARTED	| HttpStatus.FORBIDDEN
	}
	
	def "unsuccessful delete for subject that has 2 classes - one class is not soft deleted due to a completed date equal to the currrent date"(){
		given:
			Subject subject = new Subject(name: 'Default Subject', organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
			subjectRepo.save(subject)
			
			createClass(subject, ClassObjState.COMPLETED, new Date()-10, school1)
			createClass(subject, ClassObjState.COMPLETED, new Date(), school1)
			
			String token = createToken(user1, school1.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
		when:
			def response = testRestTemplate.exchange("/subjects/"+subject.uuid.toString(), HttpMethod.DELETE, req, Object)
		then:
			List<ClassObj> classes = retrieveClasses(school1.uuid, subject.uuid)
			assert response.statusCode == HttpStatus.FORBIDDEN
			assert classes[0].subject != null
			assert classes[1].subject != null
	}
	
	private List<ClassObj> retrieveClasses(UUID schoolUUID, UUID subjectUUID){
		SubjectsView subjectsView = subjectsViewRepo.findByOrganizationUuidAndUuid(schoolUUID, subjectUUID)
		return classRepo.findAllBySubject(subjectsView)
	}
	

	private void createClass(Subject subject, ClassObjState state, Date completed, Organization school){
		AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid:school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
		User teacher = userRepo.save(new User(firstName: 'Teacher 1', lastName: 'teacher Last', userName: 'Teacher1', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date()))
		SubjectsView subjectsView = subjectsViewRepo.findByOrganizationUuidAndUuid(school.uuid, subject.uuid)
		ClassObj classObj = new ClassObj(
				type: ClassObjType.CLASS,
				subtype: ClassObjSubtype.STANDARD,
				state: state,
				name: "testing",
				subject: subjectsView,
				organization: school,
				creatorUuid: teacher.uuid,
				classId: "test classId",
				notes: "some notes",
				academicSession: academicSession,
				created: new Date(),
				updated: new Date(),
				completed: completed
		)
		classObj = classRepo.save(classObj)
	}

}
