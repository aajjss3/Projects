package com.glynlyon.kl.classroom.auth

import com.glynlyon.kl.classroom.BaseRestSpec
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus

import java.nio.charset.StandardCharsets

class JwtFilterIntegrationSpec extends BaseRestSpec {

    private String secureEndpoint = "/env"

    def "requests to a protected endpoint should return 401 without a token"(){
        when:
        def resp = testRestTemplate.getForEntity(secureEndpoint, Object)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED
    }

    def "requests to a protected endpoint should return 401 with an invalid token"(){
        when:
        def req = createRequest("blah")

        HttpEntity resp = testRestTemplate.exchange(secureEndpoint, HttpMethod.GET, req.entity, String.class)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED
    }

    def "requests to a protected endpoint should return 200 with a valid token"(){
        when:
        def req = createRequest()

        HttpEntity resp = testRestTemplate.exchange(secureEndpoint, HttpMethod.GET, req.entity, String.class)

        then:
        assert resp.statusCode == HttpStatus.OK
    }

    def "requests to a protected endpoint should return 401 with an expired token"(){
        when:
        def token = Jwts.builder().setExpiration(new Date().plus(-1)).setSubject("test").signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8)).compact()

        def req = createRequest(token)

        HttpEntity resp = testRestTemplate.exchange(secureEndpoint, HttpMethod.GET, req.entity, String.class)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED
    }
}
