package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.learnosity.model.LearnositySessionListByItemRequest
import org.springframework.beans.factory.annotation.Autowired
import spock.lang.Unroll

class AttemptServiceIntegrationSpec extends BaseRestSpec {

    User admin
    Organization school

    @Autowired
    AttemptService attemptService

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
    }

    @Unroll
    def "test student report by page assignment"(){
        given:

        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("page 1", classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("assignment 1", pageObj)

        List<User> users = (1..4).collect{
            User user = userRepo.save(
                    new User(
                            firstName: "test first",
                            lastName: Character.toString(it+65 as char),
                            userName: 'testusername',
                            type: AppUserType.STUDENT,
                            status: AppUserStatus.ACTIVE,
                            originationId: 'test',
                            updated: new Date(),
                            created: new Date()
                    )
            )
            createEnrollment(classObj, user, Role.STUDENT)
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment, user)
            setupAttempt(plannerEntry, user)
            setupAttempt(plannerEntry, user)
            setupAttempt(plannerEntry, user)
            return user
        }

        when:
        attemptService.attemptsPerReport = maxRows
        List<LearnositySessionListByItemRequest> actual = attemptService.generateLearnosityReportList(pageAssignment, "p")

        then:
        assert result.keySet().size() == actual.size()
        result.eachWithIndex { key, value, index ->
            assert actual[index].report_id == key
            assert actual[index].users.size() == value.size()
            assert actual[index].users.uuid.containsAll(value.collect{users.get(it).uuid.toString()})
            assert actual[index].users.displayName.containsAll(value.collect{users.get(it).firstName + " " + users.get(it).lastName})
        }

        where:
        maxRows || result
        3       || ["p-1": [0], "p-2": [1], "p-3": [2], "p-4": [3]]
        6       || ["p-1": [0, 1], "p-2": [2, 3]]
        10      || ["p-1": [0, 1, 2], "p-2": [3]]
        20      || ["p-1": [0, 1, 2, 3]]
    }

    @Unroll
    def "test student report ignores in_progress and saved"(){
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("page 1", classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("assignment 1", pageObj)

        List<User> users = (1..2).collect{
            User user = userRepo.save(
                    new User(
                            firstName: "test first",
                            lastName: Character.toString(it+65 as char),
                            userName: 'testusername',
                            type: AppUserType.STUDENT,
                            status: AppUserStatus.ACTIVE,
                            originationId: 'test',
                            updated: new Date(),
                            created: new Date()
                    )
            )
            createEnrollment(classObj, user, Role.STUDENT)
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment, user)
            setupAttempt(plannerEntry, user)
            setupAttempt(plannerEntry, user, AttemptState.SAVED)
            setupAttempt(plannerEntry, user, AttemptState.IN_PROGRESS)
            return user
        }

        when:
        attemptService.attemptsPerReport = 2
        List<LearnositySessionListByItemRequest> actual = attemptService.generateLearnosityReportList(pageAssignment, "p")

        then:
        assert actual.size() == 1
        assert actual[0].users.size() == 2
    }

    @Unroll
    def "should ignore unenrolled students in attempt report"(){
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("page 1", classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("assignment 1", pageObj)

        List<User> users = (1..2).collect{
            User user = userRepo.save(
                    new User(
                            firstName: "test first",
                            lastName: Character.toString(it+65 as char),
                            userName: 'testusername',
                            type: AppUserType.STUDENT,
                            status: AppUserStatus.ACTIVE,
                            originationId: 'test',
                            updated: new Date(),
                            created: new Date()
                    )
            )
            if(it == 1) {
                createEnrollment(classObj, user, Role.STUDENT)
            }
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment, user)
            setupAttempt(plannerEntry, user)
            return user
        }

        when:
        attemptService.attemptsPerReport = 2
        List<LearnositySessionListByItemRequest> actual = attemptService.generateLearnosityReportList(pageAssignment, "p")

        then:
        assert actual.size() == 1
        assert actual[0].users.size() == 1
    }

    def "should return empty list if no attempts"(){
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("page 1", classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("assignment 1", pageObj)

        List<User> users = (1..2).collect{
            User user = userRepo.save(
                    new User(
                            firstName: "test first",
                            lastName: Character.toString(it+65 as char),
                            userName: 'testusername',
                            type: AppUserType.STUDENT,
                            status: AppUserStatus.ACTIVE,
                            originationId: 'test',
                            updated: new Date(),
                            created: new Date()
                    )
            )
            createEnrollment(classObj, user, Role.STUDENT)
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment, user)
            return user
        }

        when:
        List<LearnositySessionListByItemRequest> actual = attemptService.generateLearnosityReportList(pageAssignment, "p")

        then:
        assert actual.size() == 0
    }
}