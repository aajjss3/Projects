package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable

class SubjectServiceIntegrationSpec extends BaseRestSpec{

    @Autowired
    SubjectsService subjectsService

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    OrganizationRepo organizationRepo

    Organization school, school2, school3

    User admin

    def setup() {
        admin = userRepo.save(new User(firstName: 'testAdmin', lastName: 'admin Last', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date()))

        school = new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
        school2 = new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
        school3 = new Organization(name: 'School 3', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())

        organizationRepo.save(school)
        organizationRepo.save(school2)
        organizationRepo.save(school3)

    }

    def "find() should return proper results for given params"() {
        given:
        Subject subject1 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject subject2 = new Subject(name: 'Blended', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject2)
        Subject subject3 = new Subject(name: 'Career and Technical Education', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-1, updatedAt: new Date())
        subjectRepo.save(subject3)
        Subject subject4 = new Subject(name: 'Advanced Placement', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-1, updatedAt: new Date())
        subjectRepo.save(subject4)
        Subject subject5 = new Subject(name: 'Social Studies', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-2, updatedAt: new Date())
        subjectRepo.save(subject5)
        Subject subject6 = new Subject(name: 'Social Studies', organizationUuid: school2.uuid, disabled: false, createdAt: new Date()-2, updatedAt: new Date())
        subjectRepo.save(subject6)
        Subject subject7 = new Subject(name: 'Math', organizationUuid: school2.uuid, disabled: false, createdAt: new Date()-2, updatedAt: new Date())
        subjectRepo.save(subject7)

        def sortedResults = []

        String token = createToken(admin, school.uuid)

        Pageable pageable = new PageRequest(0, 10)
        Page<SubjectsView> subjects
        List<SubjectsView> results

        when: "organization_uuid exists"
        subjects = subjectsService.find(pageable, school.getUuid(), null, token)
        results = subjects.getContent()

        then:
        assert results.size() == 5
        results.each {
            assert it.organizationUuid == school.uuid
        }


        when: "no organization_uuid exists"
        subjects = subjectsService.find(pageable, null, null, token)
        results = subjects.getContent()

        then:
        assert results.size() == 5
        results.each {
            assert it.organizationUuid == school.uuid
        }

        when: "filter test with =(Equals) operator"
        subjects = subjectsService.find(pageable, null, "name='Career and Technical Education'", token)
        results = subjects.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'Career and Technical Education'
        assert results[0].uuid == subject3.uuid

        when: "filter test with !=(Not Equals) operator"
        subjects = subjectsService.find(pageable, null, "name!='Career and Technical Education'", token)
        results = subjects.getContent()

        then:
        assert results.size() == 4
        assert results[0].uuid != subject3.uuid
        assert results[0].name != 'Career and Technical Education'
        assert results[1].name != 'Career and Technical Education'
        assert results[2].name != 'Career and Technical Education'
        assert results[3].name != 'Career and Technical Education'


        when: "filter test with contains operators"
        subjects = subjectsService.find(pageable, null, "namecontains'Advanced Placement'", token)
        results = subjects.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'Advanced Placement'
        assert results[0].organizationUuid == school.uuid


        when: "filter test with AND operators"
        subjects = subjectsService.find(pageable, null, "name='Advanced Placement' AND organization_uuid='${school.uuid}'", token)
        results = subjects.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'Advanced Placement'
        assert results[0].organizationUuid == school.uuid

        when: "filter test with OR operators"
        subjects = subjectsService.find(pageable, null, "filter=name='Elective' OR name='Blended'", token)
        results = subjects.getContent()
        sortedResults = results.collect().sort{ it.name }

        then:
        assert results.size() == 2
        assert sortedResults[0].name == 'Blended'
        assert sortedResults[1].name == 'Elective'


        when: "filter test with UUID"
        subjects = subjectsService.find(pageable, null, "subject_uuid='${subject1.uuid}'", token)
        results = subjects.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'Elective'
        assert results[0].uuid == subject1.uuid
    }
}
