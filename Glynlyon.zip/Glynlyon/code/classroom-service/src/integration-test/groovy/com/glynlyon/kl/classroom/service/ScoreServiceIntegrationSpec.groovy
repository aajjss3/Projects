package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.dto.PageAttemptDTO
import com.glynlyon.kl.classroom.dto.grade.GpaAssignmentsInput
import com.glynlyon.kl.classroom.dto.grade.GpaStudentsInput
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import org.springframework.beans.factory.annotation.Autowired
import spock.lang.Unroll

class ScoreServiceIntegrationSpec extends BaseRestSpec {

    @Autowired
    ScoreService scoreService

    User admin, sansa, arya, bran, jon
    Organization school, campus1

    Map<String, PageObj> pageMap
    Map<String, PageAssignment> paMap
    Map<String, Attempt> attemptMap
    Map<String, User> userMap
    Map<String, ClassObj> classMap

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        campus1 = organizationRepo.save(new Organization(name: 'campus1', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))

        sansa = userRepo.save(new User(firstName: 'sansa', lastName: 'stark', userName: 'sstark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        arya = userRepo.save(new User(firstName: 'arya', lastName: 'stark', userName: 'astark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        bran = userRepo.save(new User(firstName: 'bran', lastName: 'stark', userName: 'bstark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        jon = userRepo.save(new User(firstName: 'jon', lastName: 'snow', userName: 'jsnow', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))

        ClassObj class1 = setupValidClass(admin, campus1)
        ClassObj class2 = setupValidClass(admin, campus1)

        [sansa, arya, bran, jon].each {
            createEnrollment(class1, it, Role.STUDENT)
            createEnrollment(class2, it, Role.STUDENT)
        }

        PageObj page1 = setupValidPage("page1", class1, 1)
        PageObj page2 = setupValidPage("page2", class1, 2)

        PageAssignment p1pa1 = setupValidPageAssignment("p1pa1", page1, 1)
        PageAssignment p1pa2 = setupValidPageAssignment("p1pa2", page1, 2)
        PageAssignment p1pa3 = setupValidPageAssignment("p1pa3", page1, 3)
        PageAssignment p1pa4 = setupValidPageAssignment("p1pa4", page1, 4)
        PageAssignment p1pa5 = setupValidPageAssignment("p1pa5", page1, 5)
        PageAssignment p1pa6 = setupValidPageAssignment("p1pa6", page1, 6)
        PageAssignment p2pa1 = setupValidPageAssignment("p2pa1", page2, 1)
        PageAssignment p2pa2 = setupValidPageAssignment("p2pa2", page2, 2)

        PlannerEntry peArya1 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa1, arya)
        PlannerEntry peArya2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa2, arya)
        PlannerEntry peArya3 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa3, arya)
        PlannerEntry peArya4 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa4, arya)
        PlannerEntry peArya5 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa5, arya)
        PlannerEntry peArya6 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa6, arya)
        PlannerEntry peArya21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa1, arya)
        PlannerEntry peArya22 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa2, arya)

        PlannerEntry peBran1 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa1, bran)
        PlannerEntry peBran2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa2, bran)
        PlannerEntry peBran3 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa3, bran)
        PlannerEntry peBran4 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa4, bran)
        PlannerEntry peBran5 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa5, bran)
        PlannerEntry peBran6 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa6, bran)
        PlannerEntry peBran21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa1, bran)
        PlannerEntry peBran22 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa2, bran)

        PlannerEntry peSansa1 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa1, sansa)
        PlannerEntry peSansa2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa2, sansa)
        PlannerEntry peSansa3 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa3, sansa)
        PlannerEntry peSansa4 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa4, sansa)
        PlannerEntry peSansa5 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa5, sansa)
        PlannerEntry peSansa6 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page1, p1pa6, sansa)
        PlannerEntry peSansa21 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa1, sansa)
        PlannerEntry peSansa22 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class1, page2, p2pa2, sansa)

        // fail first, every status 2nd time
        Attempt a1 = setupAttemptByDate(peArya1, arya, cdate(0), AttemptState.FAILED, 0.1)
        Attempt a2 = setupAttemptByDate(peArya1, arya, cdate(1), AttemptState.IN_PROGRESS, null)
        Attempt a3 = setupAttemptByDate(peArya2, arya, cdate(2), AttemptState.FAILED, 0.1)
        Attempt a4 = setupAttemptByDate(peArya2, arya, cdate(3), AttemptState.SAVED, null)
        Attempt a5 = setupAttemptByDate(peArya3, arya, cdate(4), AttemptState.FAILED, 0.1)
        Attempt a6 = setupAttemptByDate(peArya3, arya, cdate(5), AttemptState.SUBMITTED, null)
        Attempt a7 = setupAttemptByDate(peArya4, arya, cdate(6), AttemptState.FAILED, 0.1)
        Attempt a8 = setupAttemptByDate(peArya4, arya, cdate(7), AttemptState.PASSED, 1.0)
        Attempt a9 = setupAttemptByDate(peArya5, arya, cdate(8), AttemptState.FAILED, 0.1)
        Attempt a10 = setupAttemptByDate(peArya5, arya, cdate(9), AttemptState.FAILED, 0.2)
        Attempt a21 = setupAttemptByDate(peArya21, arya, cdate(10), AttemptState.FAILED, 0.2)
        Attempt a22 = setupAttemptByDate(peArya22, arya, cdate(11), AttemptState.FAILED, 0.4)

        // every status first, submitted second time
        Attempt b1 = setupAttemptByDate(peBran1, bran, cdate(12), AttemptState.IN_PROGRESS, null)
        Attempt b2 = setupAttemptByDate(peBran1, bran, cdate(13), AttemptState.SUBMITTED, null)
        Attempt b3 = setupAttemptByDate(peBran2, bran, cdate(14), AttemptState.SAVED, null)
        Attempt b4 = setupAttemptByDate(peBran2, bran, cdate(15), AttemptState.SUBMITTED, null)
        Attempt b5 = setupAttemptByDate(peBran3, bran, cdate(16), AttemptState.SUBMITTED, null)
        Attempt b6 = setupAttemptByDate(peBran3, bran, cdate(17), AttemptState.SUBMITTED, null)
        Attempt b7 = setupAttemptByDate(peBran4, bran, cdate(18), AttemptState.PASSED, 0.9)
        Attempt b8 = setupAttemptByDate(peBran4, bran, cdate(19), AttemptState.SUBMITTED, null)
        Attempt b9 = setupAttemptByDate(peBran5, bran, cdate(20), AttemptState.FAILED, 0.1)
        Attempt b10 = setupAttemptByDate(peBran5, bran, cdate(21), AttemptState.SUBMITTED, null)
        Attempt b21 = setupAttemptByDate(peBran21, bran, cdate(22), AttemptState.PASSED, 0.8)
        Attempt b22 = setupAttemptByDate(peBran22, bran, cdate(23), AttemptState.PASSED, 1.0)

        //every status
        Attempt s1 = setupAttemptByDate(peSansa1, sansa, cdate(24), AttemptState.SAVED, null)
        Attempt s2 = setupAttemptByDate(peSansa2, sansa, cdate(25), AttemptState.SUBMITTED, null)
        Attempt s3 = setupAttemptByDate(peSansa3, sansa, cdate(26), AttemptState.FAILED, 0.4)
        Attempt s4 = setupAttemptByDate(peSansa4, sansa, cdate(27), AttemptState.PASSED, 0.8)
        Attempt s5 = setupAttemptByDate(peSansa5, sansa, cdate(28), AttemptState.IN_PROGRESS, null)
        Attempt s21 = setupAttemptByDate(peSansa21, sansa, cdate(29), AttemptState.PASSED, 0.75)
        Attempt s22 = setupAttemptByDate(peSansa22, sansa, cdate(30), AttemptState.FAILED, 0.25)


        PageObj pageClass2 = setupValidPage("page1", class2, 1)
        PageAssignment paClass2 = setupValidPageAssignment("paClass2", pageClass2, 1)
        PlannerEntry peSansaClass2 = setupPlannerEntry(-1, PlannerEntryState.COMPLETED, class2, pageClass2, paClass2, sansa)
        Attempt sClass2 = setupAttemptByDate(peSansaClass2, sansa, cdate(31), AttemptState.PASSED, 0.8)

        pageMap = [
                page1: page1,
                page2: page2,
                pageClass2: pageClass2
        ]

        paMap = [
                p1pa1: p1pa1,
                p1pa2: p1pa2,
                p1pa3: p1pa3,
                p1pa4: p1pa4,
                p1pa5: p1pa5,
                p1pa6: p1pa6,
                p2pa1: p2pa1,
                p2pa2: p2pa2,
                paClass2 : paClass2
        ]

        attemptMap = [
                a1 : a1,
                a2 : a2,
                a3 : a3,
                a4 : a4,
                a5 : a5,
                a6 : a6,
                a7 : a7,
                a8 : a8,
                a9 : a9,
                a10: a10,
                a21: a21,
                a22: a22,
                b1 : b1,
                b2 : b2,
                b3 : b3,
                b4 : b4,
                b5 : b5,
                b6 : b6,
                b7 : b7,
                b8 : b8,
                b9 : b9,
                b10: b10,
                b21: b21,
                b22: b22,
                s1 : s1,
                s2 : s2,
                s3 : s3,
                s4 : s4,
                s5 : s5,
                s21: s21,
                s22: s22,
                sClass2 : sClass2
        ]

        userMap = [
                arya: arya,
                bran: bran,
                sansa: sansa,
                jon: jon
        ]

        classMap = [
                class1: class1,
                class2: class2
        ]
    }

    @Unroll
    def "should return correct attempts grouped by assignment"() {
        given:
        paMap.each { String key, PageAssignment value ->
            filter = filter.replaceAll(key, value.uuid.toString())
        }

        when:
        Map<UUID, List<PageAttemptDTO>> result = scoreService.groupAndFilterAttemptsByAssignment(pageMap[pageId].uuid, filter)

        then:
        assert result.keySet().size() == expected.keySet().size()
        assert result.keySet().containsAll(expected.keySet().collect { paMap[it].uuid })

        if (expected){
            expected.each { key, value ->
                assert result[paMap[key].uuid].size() == value.size()
                assert result[paMap[key].uuid].attemptUuid.containsAll(value.collect { attemptMap[it].uuid })
            }
        }

        where:
        pageId  | filter        || expected
        "page1" | ""            || ["p1pa3": ["s3"], "p1pa4": ["a8", "s4"], "p1pa5": ["a10"]]
        "page1" | "p1pa3"       || ["p1pa3": ["s3"]]
        "page1" | "p1pa4,p2pa1" || ["p1pa4": ["a8", "s4"]]
        "page1" | "p2pa1"       || [:]
        "page2" | ""            || ["p2pa1" : ["a21", "b21", "s21"], "p2pa2" : ["a22", "b22", "s22"]]
        "page2" | "p2pa1"       || ["p2pa1" : ["a21", "b21", "s21"]]
    }


    @Unroll
    def "should return correct attempts grouped by student"() {
        given:
        userMap.each { String key, User value ->
            filter = filter.replaceAll(key, value.uuid.toString())
        }

        when:
        Map<UUID, List<PageAttemptDTO>> result = scoreService.groupAndFilterAttemptsByStudent(pageMap[pageId], filter)

        then:
        assert result.keySet().size() == expected.keySet().size()
        assert result.keySet().containsAll(expected.keySet().collect { userMap[it].uuid })

        if (expected){
            expected.each { key, value ->
                assert result[userMap[key].uuid].size() == value.size()
                assert result[userMap[key].uuid].attemptUuid.containsAll(value.collect { attemptMap[it].uuid })
            }
        }

        where:
        pageId  | filter        || expected
        "page1" | ""            || [sansa: ["s3", "s4"], arya: ["a8", "a10"]]
        "page1" | "arya"        || [arya: ["a8", "a10"]]
        "page1" | "arya,bran"   || [arya: ["a8", "a10"]]
        "page1" | "jon"         || [:]
        "page2" | ""            || [arya: ["a21", "a22"], bran: ["b21", "b22"], sansa: ["s21", "s22"]]
        "page2" | "bran"        || [bran: ["b21", "b22"]]
    }

    @Unroll
    def "should return correct class attempts grouped by student"() {
        given:
        userMap.each { String key, User value ->
            filter = filter.replaceAll(key, value.uuid.toString())
        }

        when:
        Map<UUID, List<PageAttemptDTO>> result = scoreService.groupAndFilterAttemptsByStudent(classMap[classId], filter)

        then:
        assert result.keySet().size() == expected.keySet().size()
        assert result.keySet().containsAll(expected.keySet().collect { userMap[it].uuid })

        if (expected){
            expected.each { key, value ->
                assert result[userMap[key].uuid].size() == value.size()
                assert result[userMap[key].uuid].attemptUuid.containsAll(value.collect { attemptMap[it].uuid })
            }
        }

        where:
        classId  | filter        || expected
        "class1" | ""            || [sansa: ["s3", "s4", "s21", "s22"], bran: ["b21", "b22"], arya: ["a8", "a10", "a21", "a22"]]
        "class1" | "arya"        || [arya: ["a8", "a10", "a21", "a22"]]
        "class1" | "arya,bran"   || [arya: ["a8", "a10", "a21", "a22"], bran: ["b21", "b22"]]
        "class1" | "jon"         || [:]
        "class2" | ""            || [sansa: ["sClass2"]]
    }


    @Unroll
    def "should return correct gpa assignment payload"() {
        given:
        paMap.each { String key, PageAssignment value ->
            filter = filter.replaceAll(key, value.uuid.toString())
        }

        Map<UUID, List<PageAttemptDTO>> input = scoreService.groupAndFilterAttemptsByAssignment(pageMap[pageId].uuid, filter)

        Map<String, LearnosityGetAllSessionsResponse> learnosity = input.values().collectEntries {
            [(it.first().attemptUuid.toString()):new LearnosityGetAllSessionsResponse(maxScore: 10)]
        }


        GpaAssignmentsInput expectedInput = new GpaAssignmentsInput(
                assignments: expected.collect { paUuid, attemptUuids ->
                    return new GpaAssignmentsInput.Assignment(
                            id: paMap[paUuid].uuid,
                            students: attemptUuids.collect {
                                new GpaAssignmentsInput.Score(
                                        score: attemptMap[it].assessmentScore * 10,
                                        maxScore: 10
                                )
                            }
                    )
                }
        )

        when:
        def actual = scoreService.createGpaAssignmentsInput(input, learnosity)

        then:

        assert actual.assignments.size() == expectedInput.assignments.size()
        assert actual.assignments.id.containsAll(expectedInput.assignments.id)
        if(expected){
            actual.assignments.each { actualAssignment ->
                def expectedAssignment = expectedInput.assignments.find{it.id == actualAssignment.id}
                assert actualAssignment.students.containsAll(expectedAssignment.students)
            }
        }

        where:
        pageId  | filter        || expected
        "page1" | ""            || ["p1pa3": ["s3"], "p1pa4": ["a8", "s4"], "p1pa5": ["a10"]]
        "page1" | "p1pa3"       || ["p1pa3": ["s3"]]
        "page1" | "p1pa4,p2pa1" || ["p1pa4": ["a8", "s4"]]
        "page1" | "p2pa1"       || [:]
        "page2" | ""            || ["p2pa1" : ["a21", "b21", "s21"], "p2pa2" : ["a22", "b22", "s22"]]
        "page2" | "p2pa1"       || ["p2pa1" : ["a21", "b21", "s21"]]
    }

    @Unroll
    def "should return correct gpa student payload"() {
        given:
        userMap.each { String key, User value ->
            filter = filter.replaceAll(key, value.uuid.toString())
        }

        Map<UUID, List<PageAttemptDTO>> input = scoreService.groupAndFilterAttemptsByStudent(pageMap[pageId], filter)

        Map<UUID, String> learnosityMap = (Map<UUID, String>)input.collect{userUuid, listOfAttempts ->
            listOfAttempts.collect{
                [(it.pageAssignmentUuid): listOfAttempts.first().attemptUuid.toString()]
            }.sum()
        }.sum()

        Map<String, LearnosityGetAllSessionsResponse> learnosity = input.values().collectEntries {
            [(it.first().attemptUuid.toString()):new LearnosityGetAllSessionsResponse(maxScore: 10)]
        }


        GpaStudentsInput expectedInput = new GpaStudentsInput(
                students: expected.collect { user, attemptUuids ->
                    return new GpaStudentsInput.Student(
                            id: userMap[user].uuid,
                            assignments: attemptUuids.collect {
                                new GpaStudentsInput.Score(
                                        score: attemptMap[it].assessmentScore * 10,
                                        maxScore: 10
                                )
                            }
                    )
                }
        )

        when:
        def actual = scoreService.createGpaStudentsInput(input, learnosity, learnosityMap)

        then:

        assert actual.students.size() == expectedInput.students.size()
        assert actual.students.id.containsAll(expectedInput.students.id)
        if(expected){
            actual.students.each { actualStudent ->
                def expectedStudent = expectedInput.students.find{it.id == actualStudent.id}
                assert actualStudent.assignments.containsAll(expectedStudent.assignments)
            }
        }

        where:
        pageId  | filter        || expected
        "page1" | ""            || [sansa: ["s3", "s4"], arya: ["a8", "a10"]]
        "page1" | "arya"        || [arya: ["a8", "a10"]]
        "page1" | "arya,bran"   || [arya: ["a8", "a10"]]
        "page1" | "jon"         || [:]
        "page2" | ""            || [arya: ["a21", "a22"], bran: ["b21", "b22"], sansa: ["s21", "s22"]]
        "page2" | "bran"        || [bran: ["b21", "b22"]]
    }
}
