package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.dto.grade.GpaScoresInput
import com.glynlyon.kl.classroom.dto.grade.OutcomeResponse
import com.glynlyon.kl.classroom.dto.grade.OutcomeStatus
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptSave
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Lock
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.ResourceType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.service.GpaService
import com.glynlyon.kl.classroom.service.LearnosityDataService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import com.glynlyon.learnosity.client.LearnosityDataClient
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityResponse
import groovy.time.TimeCategory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class AttemptControllerIntegrationSpec extends BaseRestSpec{
	User admin, student, student1, student2, student3, studentOther, teacher, teacher1, admin1, adminBelongingToSchool1

	Organization school, campus, school1, campus1

	@Autowired
	LearnosityDataService learnosityDataService

	@Autowired
	GpaService gpaService

	def setup() {

		school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		campus = organizationRepo.save(new Organization(name: 'Winterfell', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))
		student = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'testing', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		student1 = userRepo.save(new User(firstName: 'John', lastName: 'Snow', userName: 'jSnow', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		student2 = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		student3 = userRepo.save(new User(firstName: 'Mega', lastName: 'Man', userName: 'mMan', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		studentOther = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		teacher = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		teacher1 = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school, campus]))
		school1 = organizationRepo.save(new Organization(name: 'Thrones1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		adminBelongingToSchool1 = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))

		settingRepo.save(new Setting(
				value: [
						admin: [override: true],
						classroom: [
								lessons: [
										threshold: 70,
										attempts: 2
								],
								projects: [
										threshold: 70,
										attempts: 2
								],
								grade_display: [
										percentage: true,
										letter: false
								],
								grade_scale: [
										A:90,
										B:80,
										C:70,
										D:60
								]
						]
				],
				type: SettingType.GLOBAL
		))

		learnosityDataService.metaClass.getClient = { String domain ->
			return new LearnosityDataClient("", "", ""){
				@Override
				Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
					return sessionIds.collectEntries {
						[(it): new LearnosityGetAllSessionsResponse(
								userId: UUID.randomUUID(),
								activityId: UUID.randomUUID(),
								sessionId: it,
								numAttempted: 2,
								numQuestions: 4,
								score: 100,
								maxScore: 100,
								status: "DONE",
								responses: [
										new LearnosityResponse(
												responseId: UUID.randomUUID(),
												score: 70,
												maxScore: 1.0
										)
								]
						)]
					}
				}
			}
		}
	}
	
	
	// GET
	def "GET attempt data for ADMIN role - should pass since admin's organization is the parent to the requests organization "(){
		given:	
			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")
	
			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
	
			and: "Create 1 attempt"
			Attempt attempt = createAttempt(plannerEntry, student, AttemptState.PASSED)
	
			student.type = AppUserType.ADMIN
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)
	
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.OK
	}
	
	// GET
	def "GET attempt data for ADMIN role - should fail since admin's organization is NOT the parent to the requests organization"(){
		given:
			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")
	
			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
	
			and: "Create 1 attempt"
			Attempt attempt = createAttempt(plannerEntry, student, AttemptState.PASSED)
	
			student.type = AppUserType.ADMIN
			String token = createToken(adminBelongingToSchool1, school1.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)
	
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.UNAUTHORIZED
	}


	// GET
	def "GET attempt data - should pass ADMIN role"(){
		given:
			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			and: "Create 2 attempts"
			Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, true, 1)
			Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.PASSED, true, 2)

			student.type = AppUserType.ADMIN
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.OK
			def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
			assert results.size() == 2
			assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
			assert results[0].user_uuid == student.uuid.toString()
			assert results[0].activity_id == plannerEntry.activityId.toString()
			assert results[0].section_count == attempt1.sectionCount
			assert results[0].section_total_count == attempt1.sectionTotalCount
			assert results[0].question_count == attempt1.questionCount
			assert results[0].state == attempt1.state.toString()
			assert results[0].status == attempt1.state.toString()
			assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
			assert results[0].assessment_score == attempt1.assessmentScore
			assert results[0].section_items == ["abc", "def"]
			assert results[0].included_manual_graded == true
			assert results[0].sections_viewed == ["1", "2"]

			assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
			assert results[1].user_uuid == student1.uuid.toString()
			assert results[1].activity_id == plannerEntry.activityId.toString()
			assert results[1].section_count == attempt2.sectionCount
			assert results[1].section_total_count == attempt2.sectionTotalCount
			assert results[1].question_count == attempt2.questionCount
			assert results[1].state == attempt2.state.toString()
			assert results[1].status == attempt2.state.toString()
			assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
			assert results[1].assessment_score == attempt2.assessmentScore
			assert results[1].section_items == ["abc", "def"]
			assert results[1].included_manual_graded == true
			assert results[1].sections_viewed == ["1", "2"]

	}

	// GET
	def "GET attempt data - should pass STUDENT role"(){
		given:

		ClassObj classObj = setupValidClass(student, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa 1", pageObj, 1)


		and: "create 1 planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, pageAssignment, student)

		
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, false, 1)
		Attempt attempt2 = createAttempt(plannerEntry, student, AttemptState.PASSED, true, 2)
		AttemptSave attemptSave = attemptSaveRepo.save(
				new AttemptSave(
						attempt: attempt2,
						sequence: 1,
						sectionsViewed: ["1", "2"],
						questionsViewed: ["1", "3", "4"],
						timeOnTaskSeconds: 54,
						createdAt: new Date(),
						createdBy: student.uuid
				)
		)

		Attempt attempt3 = createAttempt(plannerEntry, student1, AttemptState.PASSED, false)

		student.type = AppUserType.STUDENT
		String token = createToken(student, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		DateFormat dateFormat = new DateFormat()

		when:
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
		assert results.size() == 2
		assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[0].user_uuid == student.uuid.toString()
		assert results[0].activity_id == plannerEntry.activityId.toString()
		assert results[0].section_count == attempt1.sectionCount
		assert results[0].section_total_count == attempt1.sectionTotalCount
		assert results[0].question_count == attempt1.questionCount
		assert results[0].state == attempt1.state.toString()
		assert results[0].status == attempt1.state.toString()
		assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
		assert results[0].assessment_score == attempt1.assessmentScore
		assert results[0].section_items == ["abc", "def"]
		assert results[0].included_manual_graded == true

		assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[1].user_uuid == student.uuid.toString()
		assert results[1].activity_id == plannerEntry.activityId.toString()
		assert results[1].section_count == attempt2.sectionCount
		assert results[1].section_total_count == attempt2.sectionTotalCount
		assert results[1].question_count == attempt2.questionCount
		assert results[1].state == attempt2.state.toString()
		assert results[1].status == attempt2.state.toString()
		assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
		assert results[1].assessment_score == attempt2.assessmentScore
		assert results[1].section_items == ["abc", "def"]
		assert results[1].included_manual_graded == true
		assert results[1].saves == [[
		        attempt_uuid : attemptSave.attempt.uuid.toString(),
				attempt_save_uuid : attemptSave.uuid.toString(),
				sequence: attemptSave.sequence,
				questions_viewed: attemptSave.questionsViewed,
				sections_viewed: attemptSave.sectionsViewed,
				time_on_task_seconds: attemptSave.timeOnTaskSeconds,
				created_at: dateFormat.format(attemptSave.createdAt)
		]]


	}

	// GET
	def "GET attempt data - should pass TEACHER role"(){
		given:

			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		    PageAssignment pageAssignment = setupValidPageAssignment("pa 1", pageObj, 1)
			Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, pageAssignment, teacher)

			and: "Create 2 attempts"
			Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, false, 1)
			Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.PASSED, false, 2)

			String token = createToken(teacher, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.OK
			def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
			assert results.size() == 2
			assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
			assert results[0].user_uuid == student.uuid.toString()
			assert results[0].activity_id == plannerEntry.activityId.toString()
			assert results[0].section_count == attempt1.sectionCount
			assert results[0].section_total_count == attempt1.sectionTotalCount
			assert results[0].question_count == attempt1.questionCount
			assert results[0].state == attempt1.state.toString()
			assert results[0].status == attempt1.state.toString()
			assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
			assert results[0].assessment_score == attempt1.assessmentScore
			assert results[0].section_items == ["abc", "def"]
			assert results[0].included_manual_graded == true

			assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
			assert results[1].user_uuid == student1.uuid.toString()
			assert results[1].activity_id == plannerEntry.activityId.toString()
			assert results[1].section_count == attempt2.sectionCount
			assert results[1].section_total_count == attempt2.sectionTotalCount
			assert results[1].question_count == attempt2.questionCount
			assert results[1].state == attempt2.state.toString()
			assert results[1].status == attempt2.state.toString()
			assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
			assert results[1].assessment_score == attempt2.assessmentScore
			assert results[1].section_items == ["abc", "def"]
			assert results[1].included_manual_graded == true


	}
	
	
	// GET
	def "GET attempt data by class for ADMIN role - should fail since admin does not have access to the requests organization"(){
		given:

		ClassObj classObj = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")

		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		Attempt attempt = createAttempt(plannerEntry, student, AttemptState.PASSED)

		String token = createToken(adminBelongingToSchool1, school1.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.UNAUTHORIZED
		assert resp.body.errors.message[0] ==  "The user is an 'Admin' but the admin does not have access to the organization."
	}
	
	
	// GET
	def "GET attempt data - should be able to GET by class for ADMIN"(){
		given:

		ClassObj classObj = setupValidClass(teacher, campus)
		ClassObj classObj2 = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageObj pageObj2 = setupValidPage("Page 1", classObj2, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")

		and: "create 2 planner entries"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		PlannerEntry plannerEntry2 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		PlannerEntry plannerEntry3 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj2, pageObj2, assignment, student)

		and: "Create 2 attempts and 1 attempt in a seperate class"
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, true, 1)
		Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.PASSED, true, 2)
		Attempt attempt3 = createAttempt(plannerEntry2, student2, AttemptState.PASSED, true, 3)
		Attempt attempt4 = createAttempt(plannerEntry3, student1, AttemptState.PASSED, true, 4)

		student.type = AppUserType.ADMIN
		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
		assert results.size() == 3
		assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[0].user_uuid == student.uuid.toString()
		assert results[0].activity_id == plannerEntry.activityId.toString()
		assert results[0].section_count == attempt1.sectionCount
		assert results[0].section_total_count == attempt1.sectionTotalCount
		assert results[0].question_count == attempt1.questionCount
		assert results[0].state == attempt1.state.toString()
		assert results[0].status == attempt1.state.toString()
		assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
		assert results[0].assessment_score == attempt1.assessmentScore
		assert results[0].section_items == ["abc", "def"]
		assert results[0].included_manual_graded == true
		assert results[0].sections_viewed == ["1", "2"]

		assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[1].user_uuid == student1.uuid.toString()
		assert results[1].activity_id == plannerEntry.activityId.toString()
		assert results[1].section_count == attempt2.sectionCount
		assert results[1].section_total_count == attempt2.sectionTotalCount
		assert results[1].question_count == attempt2.questionCount
		assert results[1].state == attempt2.state.toString()
		assert results[1].status == attempt2.state.toString()
		assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
		assert results[1].assessment_score == attempt2.assessmentScore
		assert results[1].section_items == ["abc", "def"]
		assert results[1].included_manual_graded == true
		assert results[1].sections_viewed == ["1", "2"]

		assert results[2].planner_entry_uuid == plannerEntry2.uuid.toString()
		assert results[2].user_uuid == student2.uuid.toString()
		assert results[2].activity_id == plannerEntry3.activityId.toString()
		assert results[2].section_count == attempt3.sectionCount
		assert results[2].section_total_count == attempt3.sectionTotalCount
		assert results[2].question_count == attempt3.questionCount
		assert results[2].state == attempt3.state.toString()
		assert results[2].status == attempt3.state.toString()
		assert results[2].time_on_task_seconds == attempt3.timeOnTaskSeconds
		assert results[2].assessment_score == attempt3.assessmentScore
		assert results[2].section_items == ["abc", "def"]
		assert results[2].included_manual_graded == true
		assert results[2].sections_viewed == ["1", "2"]

	}

	// GET
	def "GET attempt data - should be able to GET by class for TEACHER"(){
		given:

		ClassObj classObj = setupValidClass(teacher, campus)
		ClassObj classObj2 = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageObj pageObj2 = setupValidPage("Page 1", classObj2, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))
		Enrollment enrollment2 = enrollmentRepo.save(new Enrollment(classObj: classObj2, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))


		and: "create 2 planner entries for class 1 and 2"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, teacher)
		PlannerEntry plannerEntry2 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj2, pageObj2, assignment, teacher)

		and: "Create 3 attempts - 2 for selected class, 1 for different class"
		
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, true, 1)
		Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.PASSED, true, 2)
		Attempt attempt3 = createAttempt(plannerEntry2, student, AttemptState.PASSED, true, 3)


		String token = createToken(teacher, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
		assert results.size() == 2
		assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[0].user_uuid == student.uuid.toString()
		assert results[0].activity_id == plannerEntry.activityId.toString()
		assert results[0].section_count == attempt1.sectionCount
		assert results[0].section_total_count == attempt1.sectionTotalCount
		assert results[0].question_count == attempt1.questionCount
		assert results[0].state == attempt1.state.toString()
		assert results[0].status == attempt1.state.toString()
		assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
		assert results[0].assessment_score == attempt1.assessmentScore
		assert results[0].section_items == ["abc", "def"]
		assert results[0].included_manual_graded == true

		assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[1].user_uuid == student1.uuid.toString()
		assert results[1].activity_id == plannerEntry.activityId.toString()
		assert results[1].section_count == attempt2.sectionCount
		assert results[1].section_total_count == attempt2.sectionTotalCount
		assert results[1].question_count == attempt2.questionCount
		assert results[1].state == attempt2.state.toString()
		assert results[1].status == attempt2.state.toString()
		assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
		assert results[1].assessment_score == attempt2.assessmentScore
		assert results[1].section_items == ["abc", "def"]
		assert results[1].included_manual_graded == true
	}

	// GET
	def "GET attempt data - should be able to GET by class for STUDENT role"(){
		given:

		ClassObj classObj = setupValidClass(student, campus)
		ClassObj classObj2 = setupValidClass(student, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageObj pageObj2 = setupValidPage("Page 1", classObj2, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")

		and: "create 2 planner entries"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		PlannerEntry plannerEntry2 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj2, pageObj2, assignment, student)

		and: "Create 2 attempts"
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED, false, 1)
		Attempt attempt2 = createAttempt(plannerEntry, student, AttemptState.PASSED, false, 2)
		Attempt attempt3 = createAttempt(plannerEntry2, student1, AttemptState.PASSED, false, 3)

		student.type = AppUserType.STUDENT
		String token = createToken(student, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }.sort { a, b -> a.question_count <=> b.question_count }
		assert results.size() == 2
		assert results[0].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[0].user_uuid == student.uuid.toString()
		assert results[0].activity_id == plannerEntry.activityId.toString()
		assert results[0].section_count == attempt1.sectionCount
		assert results[0].section_total_count == attempt1.sectionTotalCount
		assert results[0].question_count == attempt1.questionCount
		assert results[0].state == attempt1.state.toString()
		assert results[0].status == attempt1.state.toString()
		assert results[0].time_on_task_seconds == attempt1.timeOnTaskSeconds
		assert results[0].assessment_score == attempt1.assessmentScore
		assert results[0].section_items == ["abc", "def"]
		assert results[0].included_manual_graded == true

		assert results[1].planner_entry_uuid == plannerEntry.uuid.toString()
		assert results[1].user_uuid == student.uuid.toString()
		assert results[1].activity_id == plannerEntry.activityId.toString()
		assert results[1].section_count == attempt2.sectionCount
		assert results[1].section_total_count == attempt2.sectionTotalCount
		assert results[1].question_count == attempt2.questionCount
		assert results[1].state == attempt2.state.toString()
		assert results[1].status == attempt2.state.toString()
		assert results[1].time_on_task_seconds == attempt2.timeOnTaskSeconds
		assert results[1].assessment_score == attempt2.assessmentScore
		assert results[1].section_items == ["abc", "def"]
		assert results[1].included_manual_graded == true


	}

	// GET
	@Unroll
	def "GET attempt data - should fail due to invalid role"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			and: "Create 1 attempts"
			
			Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED)

			student.type = role
			String token = createToken(student, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == expectedStatusCode

		where:
			role								|	expectedStatusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT					|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM				|	HttpStatus.FORBIDDEN
	}

	// GET
	def "GET attempt data - should fail since planner_entry_uuid does not exist in the database"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			and: "Create 1 attempts"
			
			Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED)

			String token = createToken(student, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/c8b6eed4-0b48-49a3-b3da-b583d4c120cc/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			assert resp.body.errors[0].message

	}

	// GET
	def "GET attempt data - should fail since planner_entry_uuid is not a valid UUID"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			and: "Create 1 attempts"
			
			Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED)

			String token = createToken(student, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/xxxx/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			assert resp.body.errors[0].message

	}

	// GET
	def "GET attempt data - should return a null since there are no attempts associated with the valid planner entry id"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			String token = createToken(student, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.attempts == null
	}

	// GET
	def "GET attempt data - should return null when a student tries to get attempt records for another student"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")


			and: "create 1 planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			String token = createToken(studentOther, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.attempts == null
	}

	//GET
	@Unroll
	def "GET attempt data with sorting for STUDENT role"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

		and: "create 1 planner entries"
			PlannerEntry plannerEntry =  setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

		and: "create 3 attempts"
			List sections = ["abc", "def"]
			Attempt attempt1 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 222, assessmentScore: 22, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
			Attempt attempt2 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 2, sectionTotalCount: 1, questionCount: 2, questionsAttemptedCount: 2, questionsCorrectCount: 2, questionsIncorrectCount: 2, questionsNotScoredCount: 2, state: AttemptState.SAVED, timeOnTaskSeconds: 333, assessmentScore: 33, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
			Attempt attempt3 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 3, sectionTotalCount: 1, questionCount: 3, questionsAttemptedCount: 3, questionsCorrectCount: 3, questionsIncorrectCount: 3, questionsNotScoredCount: 3, state: AttemptState.SUBMITTED, timeOnTaskSeconds: 444, assessmentScore: 44, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		student.type = AppUserType.STUDENT
		String token = createToken(student, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

		then:
			resp.statusCode == HttpStatus.OK
			def results = resp.body.attempts.collect { it }
			assert results.size() == 3
			if(dir == "asc") {
				verifyAttempt(results[0].attempt_uuid, attempt1)
			} else {
				verifyAttempt(results[0].attempt_uuid, attempt3)
			}


		where:
			  dir    | sort
			 "asc"   | "section_count"
			 "desc"  | "section_count"
			 "asc"   | "question_count"
			 "desc"  | "question_count"
			 "asc"   | "questions_attempted_count"
			 "desc"  | "questions_attempted_count"
		     "asc"   | "questions_correct_count"
		     "desc"  | "questions_correct_count"
		     "asc"   | "questions_incorrect_count"
		     "desc"  | "questions_incorrect_count"
		     "asc"   | "questions_not_scored_count"
		     "desc"  | "questions_not_scored_count"
			 "asc"   | "time_on_task_seconds"
			 "desc"  | "time_on_task_seconds"
			 "asc"   | "assessment_score"
			 "desc"  | "assessment_score"
			 "asc"   | "state"
			 "desc"  | "state"
			 "asc"   | "status"
			 "desc"  | "status"
	}

	//GET
	@Unroll
	def "GET attempt data with filtering for STUDENT role"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			Assignment assignment = setupValidAssignment("Assignment 1")

			and: "create 1 planner entries"
			PlannerEntry plannerEntry =  setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

			and: "create 3 attempts"
            List sections = ["abc", "def"]
			Attempt attempt1 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 222, assessmentScore: 22, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
			Attempt attempt2 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 2, sectionTotalCount: 1, questionCount: 2, state: AttemptState.PASSED, timeOnTaskSeconds: 333, assessmentScore: 33, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
			Attempt attempt3 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 3, sectionTotalCount: 1, questionCount: 3, state: AttemptState.SAVED, timeOnTaskSeconds: 444, assessmentScore: 44, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

			student.type = AppUserType.STUDENT
			String token = createToken(student, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		def expectedAttempt
		if( attempt == "attempt2-section_count" || attempt == "attempt2-question_count"){
			expectedAttempt = attempt2
		}
		if( attempt == "attempt1-2-3-section_total_count"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2, attempt3))
		}
		if( attempt == "attempt3-question_count"){
			expectedAttempt = attempt3
		}
		if( attempt == "attempt1-2-state" ){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2))
		}
		if( attempt == "attempt1-2-or"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt2, attempt3))
		}
		if( attempt == "attempt1-2-and"){
			expectedAttempt = attempt3
		}

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts?filter=${criteria}", HttpMethod.GET, req, Map)

		then:
			resp.statusCode == HttpStatus.OK
			def results = resp.body.attempts.collect { it }
			if(attempt == 'attempt1-2-3-section_total_count') {
				assert results.size() == 3
				assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
				assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
				assert verifyAttempt(results[2].attempt_uuid, expectedAttempt)

			}
			else if( attempt == "attempt1-2-state" ||  attempt == "attempt1-2-or" ){
				assert results.size() == 2
				assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
				assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
			}
			else if( attempt == "attempt-invalid"){
				assert results.size() == 0
			}
			else {
				assert results.size() == 1
				verifyAttempt(results[0].attempt_uuid, expectedAttempt)
			}

		where:
			attempt                  			|  criteria
			"attempt2-section_count"       		| "section_count='2'"
			"attempt2-question_count"       	| "question_count='2'"
			"attempt1-2-3-section_total_count"	| "section_total_count='1'"
			"attempt3-question_count"			| "question_count='3'"
			"attempt-invalid"					| "question_count='1000'"
			"attempt1-2-state"					| "state='PASSED'"
			"attempt1-2-state"					| "status='PASSED'"
			"attempt1-2-or"             		| "section_count='2' OR question_count='3'"
			"attempt1-2-and"             		| "section_total_count='1' AND question_count='3'"
	}

	//GET
	@Unroll
	def "GET attempt data by class with filtering for ADMIN role"(){
		given:
		ClassObj classObj = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")

		and: "create 1 planner entries"
		PlannerEntry plannerEntry =  setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

		and: "create 3 attempts"
        List sections = ["abc", "def"]
		Attempt attempt1 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 222, assessmentScore: 22, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
		Attempt attempt2 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 2, sectionTotalCount: 1, questionCount: 2, state: AttemptState.PASSED, timeOnTaskSeconds: 333, assessmentScore: 33, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
		Attempt attempt3 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 3, sectionTotalCount: 1, questionCount: 3, state: AttemptState.SAVED, timeOnTaskSeconds: 444, assessmentScore: 44, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		def expectedAttempt
		if( attempt == "attempt2-section_count" || attempt == "attempt2-question_count"){
			expectedAttempt = attempt2
		}
		if( attempt == "attempt1-2-3-section_total_count"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2, attempt3))
		}
		if( attempt == "attempt3-question_count"){
			expectedAttempt = attempt3
		}
		if( attempt == "attempt1-2-state" ){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2))
		}
		if( attempt == "attempt1-2-or"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt2, attempt3))
		}
		if( attempt == "attempt1-2-and"){
			expectedAttempt = attempt3
		}

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}/attempts?filter=${criteria}", HttpMethod.GET, req, Map)

		then:
		resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }
		if(attempt == 'attempt1-2-3-section_total_count') {
			assert results.size() == 3
			assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[2].attempt_uuid, expectedAttempt)

		}
		else if( attempt == "attempt1-2-state" ||  attempt == "attempt1-2-or" ){
			assert results.size() == 2
			assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
		}
		else if( attempt == "attempt-invalid"){
			assert results.size() == 0
		}
		else {
			assert results.size() == 1
			verifyAttempt(results[0].attempt_uuid, expectedAttempt)
		}

		where:
		attempt                  			|  criteria
		"attempt2-section_count"       		| "section_count='2'"
		"attempt2-question_count"       	| "question_count='2'"
		"attempt1-2-3-section_total_count"	| "section_total_count='1'"
		"attempt3-question_count"			| "question_count='3'"
		"attempt-invalid"					| "question_count='1000'"
		"attempt1-2-state"					| "state='PASSED'"
		"attempt1-2-state"					| "status='PASSED'"
		"attempt1-2-or"             		| "section_count='2' OR question_count='3'"
		"attempt1-2-and"             		| "section_total_count='1' AND question_count='3'"
	}

	//GET
	@Unroll
	def "GET attempt data by class with filtering for TEACHER role"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")

		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

		and: "create 1 planner entries"
		PlannerEntry plannerEntry =  setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

		and: "create 3 attempts"
        List sections = ["abc", "def"]
		Attempt attempt1 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 222, assessmentScore: 22, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
		Attempt attempt2 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 2, sectionTotalCount: 1, questionCount: 2, state: AttemptState.PASSED, timeOnTaskSeconds: 333, assessmentScore: 33, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: false))
		Attempt attempt3 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 3, sectionTotalCount: 1, questionCount: 3, state: AttemptState.SAVED, timeOnTaskSeconds: 444, assessmentScore: 44, sectionItems: sections, includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		String token = createToken(teacher, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		def expectedAttempt
		if( attempt == "attempt2-section_count" || attempt == "attempt2-question_count"){
			expectedAttempt = attempt2
		}
		if( attempt == "attempt1-2-3-section_total_count"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2, attempt3))
		}
		if( attempt == "attempt3-question_count"){
			expectedAttempt = attempt3
		}
		if( attempt == "attempt1-2-state" ){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt1, attempt2))
		}
		if( attempt == "attempt1-2-or"){
			expectedAttempt = new ArrayList<>(Arrays.asList(attempt2, attempt3))
		}
		if( attempt == "attempt1-2-and"){
			expectedAttempt = attempt3
		}

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}/attempts?filter=${criteria}", HttpMethod.GET, req, Map)

		then:
		resp.statusCode == HttpStatus.OK
		def results = resp.body.attempts.collect { it }
		if(attempt == 'attempt1-2-3-section_total_count') {
			assert results.size() == 3
			assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[2].attempt_uuid, expectedAttempt)

		}
		else if( attempt == "attempt1-2-state" ||  attempt == "attempt1-2-or" ){
			assert results.size() == 2
			assert verifyAttempt(results[0].attempt_uuid, expectedAttempt)
			assert verifyAttempt(results[1].attempt_uuid, expectedAttempt)
		}
		else if( attempt == "attempt-invalid"){
			assert results.size() == 0
		}
		else {
			assert results.size() == 1
			verifyAttempt(results[0].attempt_uuid, expectedAttempt)
		}

		where:
		attempt                  			|  criteria
		"attempt2-section_count"       		| "section_count='2'"
		"attempt2-question_count"       	| "question_count='2'"
		"attempt1-2-3-section_total_count"	| "section_total_count='1'"
		"attempt3-question_count"			| "question_count='3'"
		"attempt-invalid"					| "question_count='1000'"
		"attempt1-2-state"					| "state='PASSED'"
		"attempt1-2-or"             		| "section_count='2' OR question_count='3'"
		"attempt1-2-and"             		| "section_total_count='1' AND question_count='3'"
	}



	// GET
	def "GET attempt data by class - should return null when a student tries to get attempt records for another student"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")


		and: "create 1 planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

		and: "Create an attempt"
		
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED)


		String token = createToken(studentOther, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		assert resp.body.attempts == null
	}

	// GET
	def "GET attempt data by class - should return null when a teacher tries to get attempts from a class that doesn't belong to them"(){
		given:
		ClassObj classObj = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = setupValidAssignment("Assignment 1")
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))


		and: "create 1 planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)

		and: "Create an attempt"
		
		Attempt attempt1 = createAttempt(plannerEntry, student, AttemptState.PASSED)

		String token = createToken(teacher1, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid+"/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		assert resp.body.attempts == null
	}

	// GET
	def "GET attempt data by class - test errors"() {
		given:

		String badClassUuid = UUID.randomUUID()
		if (error == 'bad_uuid') {
			badClassUuid = '0451'
		}

		String token = createToken(admin, null)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/classes/" + badClassUuid + "/attempts", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.NOT_FOUND
		if (error == 'bad_uuid') {
			assert resp.body.errors.message[0] == "class uuid is not a valid UUID"
		} else {
			assert resp.body.errors.message[0] == "class uuid does not exist"
		}

		where:
		error << ['invalid_class', 'bad_uuid']
	}
	
	@Unroll
	def "test post attempt endpoint with only required fields"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		//enroll the kid in the class
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)


		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"state"                           : state,
				"status"						: status
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		resp.statusCode == expectedResult
		if( resp.statusCode == HttpStatus.CREATED){
			assert attemptRepo.findAll().size() == 1
	
			List<Attempt> actual = attemptRepo.findAll()
			assert actual[0].plannerEntry.uuid == body.planner_entry_uuid
			assert actual[0].user.uuid == body.user_uuid
			assert actual[0].state == "IN_PROGRESS" as AttemptState
            assert actual[0].creditBearing == true
			assert actual[0].updatedBy == student1.uuid
	
			resp.body.planner_entry_uuid == actual[0].plannerEntry.uuid.toString()
			resp.body.user_uuid == actual[0].user.uuid.toString()
			resp.body.state == "IN_PROGRESS"
			resp.body.status == "IN_PROGRESS"
		}
		else{
			assert resp.body.errors.message[0] == "Missing required field."
			assert resp.body.errors.field[0] == "state"
		}	
		
		where:
		state			| status			| expectedResult
		null			|	"IN_PROGRESS"	| 	HttpStatus.CREATED
		"IN_PROGRESS"	|	null			| 	HttpStatus.CREATED
		"IN_PROGRESS"	|	"SAVED"			| 	HttpStatus.CREATED
		null			|	null			|	HttpStatus.BAD_REQUEST
	}


    @Unroll
    def "test multiple create credit bearing"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus)
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

        def body = [
                "planner_entry_uuid": plannerEntry.uuid,
                "user_uuid"         : student1.uuid,
                "status"            : "IN_PROGRESS"
        ]

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
        headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.CREATED

        assert attemptRepo.findAll().size() == 1

        List<Attempt> actual = attemptRepo.findAll().asList()
        assert actual[0].plannerEntry.uuid == body.planner_entry_uuid
        assert actual[0].user.uuid == body.user_uuid
        assert actual[0].state == "IN_PROGRESS" as AttemptState
        assert actual[0].creditBearing

        when:
        body.status = "SAVED"
        resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.CREATED

        assert attemptRepo.findAll().size() == 2

        Attempt newest = attemptRepo.findAll().find{it.state == AttemptState.SAVED}
        assert newest.plannerEntry.uuid == body.planner_entry_uuid
        assert newest.user.uuid == body.user_uuid
        assert newest.state == AttemptState.SAVED
        assert newest.creditBearing

        Attempt other = attemptRepo.findAll().find{it.state == AttemptState.IN_PROGRESS}
        assert other.plannerEntry.uuid == body.planner_entry_uuid
        assert other.user.uuid == body.user_uuid
        assert other.state == "IN_PROGRESS" as AttemptState
        assert !other.creditBearing
    }



	def "test post attempt endpoint"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		//enroll the kid in the class
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)


		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"section_count"                   : 1,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"state"                           : "IN_PROGRESS",
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,
				"completed_at"                    : dateFormat.format(new Date()-1)
		]

        if(questionsAnswered){
            body["questions_answered"] = questionsAnswered
        }

		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		resp.statusCode == HttpStatus.CREATED
		assert attemptRepo.findAll().size() == 1

		List<Attempt> actual = attemptRepo.findAll()
		assert actual[0].plannerEntry.uuid == body.planner_entry_uuid
		assert actual[0].user.uuid == body.user_uuid
		assert actual[0].activityId == plannerEntry.activityId
		assert actual[0].sectionCount == body.section_count
		assert actual[0].sectionTotalCount == body.section_total_count
		assert actual[0].questionCount == body.question_count
		assert actual[0].state == body.state as AttemptState
		assert actual[0].timeOnTaskSeconds == body.time_on_task_seconds
		assert actual[0].assessmentScore == body.assessment_score
        assert actual[0].creditBearing == true
		assert dateFormat.format(actual[0].completedAt) == body.completed_at
        assert actual[0].questionsAnswered == questionsAnswered

		resp.body.planner_entry_uuid == actual[0].plannerEntry.uuid.toString()
		resp.body.user_uuid == actual[0].user.uuid.toString()
		resp.body.activity_id == actual[0].activityId.toString()
		resp.body.section_count == actual[0].sectionCount
		resp.body.section_total_count == actual[0].sectionTotalCount
		resp.body.question_count == actual[0].questionCount
		resp.body.state == actual[0].state.toString()
		resp.body.time_on_task_seconds == actual[0].timeOnTaskSeconds
		resp.body.assessment_score == actual[0].assessmentScore
		resp.body.completed_at == dateFormat.format(actual[0].completedAt)
        resp.body.questions_answered == actual[0].questionsAnswered

        where:
        questionsAnswered << [null, ["1"]]
	}

	@Unroll
	def "Verify POST endpoint roles"(){
		given:

		def userMap = [admin:admin, adminBelongingToSchool1: adminBelongingToSchool1, student: student, student1: student1, teacher: teacher, teacher1: teacher1]

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

		String token = createToken(userMap[user], userMap[user].organizations.find{it.type == OrganizationType.SCHOOL}.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student.uuid,
				"section_count"                   : 1,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"state"                           : "IN_PROGRESS",
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,

		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		resp.statusCode == expectedStatus


		where:
		user                      || expectedStatus
		'admin'                   || HttpStatus.CREATED
		'adminBelongingToSchool1' || HttpStatus.UNAUTHORIZED
		'teacher'                 || HttpStatus.CREATED
		'student'                 || HttpStatus.CREATED
		'student1'                || HttpStatus.FORBIDDEN
		'teacher1'                || HttpStatus.FORBIDDEN
	}
	
	
	@Unroll
	def "POST student creates an attempt and sets status to either PASSED or FAILED"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"status"						: status
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		resp.statusCode == expectedResult
		resp.body.errors[0].message == env.getProperty("student.create.attempt.status.invalid")
		
		where:
		 status			| expectedResult
			"PASSED"	| 	HttpStatus.FORBIDDEN
			"FAILED"	| 	HttpStatus.FORBIDDEN
	}


	def "test post attempt endpoint missing required fields"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)


		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"section_count"                   : 1,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,

		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		resp.statusCode == HttpStatus.BAD_REQUEST
		(resp.body.errors[0].field in ['userUuid','state'] ) == true
		(resp.body.errors[1].field in ['userUuid','state'] ) == true
		resp.body.errors[0].message == 'Missing required field.'
		resp.body.errors[1].message == 'Missing required field.'
	}

	def "test post attempt endpoint with bad typed/formatted json"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : entryUuid,
				"user_uuid"                       : student1.uuid,
				"section_count"                   : count,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,
				"state"                           : state,

		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)

		then:

		resp.statusCode == statusCode
		assert resp.body.errors.size == 1
		assert resp.body.errors[0].message.startsWith(expectedError)

		where:
		entryUuid                               | count | state         | statusCode                    | expectedError
		"malformatuuid"                         | "a"   |"IN_PROGRESS"  | HttpStatus.BAD_REQUEST        | "invalid input malformatuuid"
		"cb6460fc-9f68-45c7-ac72-c427887da76c"  | "a"   |"IN_PROGRESS"  | HttpStatus.BAD_REQUEST        | "invalid input a"
		"cb6460fc-9f68-45c7-ac72-c427887da76c"  | 1     |"INPROGRESS"   | HttpStatus.BAD_REQUEST        | "The attempt state is not valid."
		"cb6460fc-9f68-45c7-ac72-c427887da76c"  | 1     |"IN_PROGRESS"  | HttpStatus.NOT_FOUND          | "Unable to find an PlannerEntry record for the uuid:"

	}

	def "test post attempt limit"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)

		//enroll the kid in the class
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, peState, classObj, pageObj, assignment, student1)

		(1..2).collect {
			setupAttempt(plannerEntry, student, AttemptState.FAILED, 0)
		}

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"state"                           : "IN_PROGRESS"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)


		then:
		if(statusCode == HttpStatus.BAD_REQUEST) {
			assert resp.statusCode == statusCode
			assert resp.body.errors.size() == 1
			assert resp.body.errors[0].message == "Attempt limit of 2 reached. Cannot create additional attempts"
			assert attemptRepo.findAll().size() == 2
		}
		else {
			assert resp.statusCode == statusCode
			assert attemptRepo.findAll().size() == 3
		}

		where:
		peState                       || statusCode             | message
		PlannerEntryState.IN_PROGRESS || HttpStatus.BAD_REQUEST | "Attempt limit of 2 reached. Cannot create additional attempts"
		PlannerEntryState.REASSIGNED  || HttpStatus.CREATED     | ""

	}

	@Unroll
	def "test post attempt completed class restriction"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		classObj.state = ClassObjState.COMPLETED
		classRepo.save(classObj)

		//enroll the kid in the class
		enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"state"                           : "IN_PROGRESS"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)

		then:
		assert resp.statusCode == HttpStatus.BAD_REQUEST
		assert resp.body.errors.size() == 1
		assert resp.body.errors[0].message == messagesUtil.get("attempt.create.class.completed.invalid")
	}

    /**
     * sat-1846
     * Kid should not be permitted to start an assignment associated
     * to a class in which he/she is no longer enrolled
     */
	def "test post attempt NOT enrolled restriction"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		classObj.state = ClassObjState.STARTED
		classRepo.save(classObj)

		//DO NOT enroll the kid in the class

		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"planner_entry_uuid"              : plannerEntry.uuid,
				"user_uuid"                       : student1.uuid,
				"state"                           : "IN_PROGRESS"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/attempts", HttpMethod.POST, req, Map)

		then:
		assert resp.statusCode == HttpStatus.BAD_REQUEST
		assert resp.body.errors.size() == 1
		assert resp.body.errors[0].message == messagesUtil.get("attempt.create.enrolled.invalid")
	}
	
	
	def "PUT attempt for ADMIN role - should fail since admin does not have access to the requests organization"(){
		given:

		ClassObj classObj = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.PASSED)


		String token = createToken(adminBelongingToSchool1, school1.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

		when:
		def body = [
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,
				"state"                           : "IN_PROGRESS",
				"completed_at"                    : dateFormat.format(new Date()-1)
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


		then:
		resp.statusCode == HttpStatus.UNAUTHORIZED
	}
	
	
	
	
	@Unroll
	def "test put attempt endpoint"(){
        given:

        ClassObj classObj = setupValidClass(admin, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

        and: "One planner entry"
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

        and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)


		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

        when:
        def body = [
                "time_on_task_seconds"            : 250,
                "assessment_score"                : 82,
				"state"                           : state,
				"status"							: status,
				"completed_at"                    : dateFormat.format(new Date()-1)
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


        then:
        resp.statusCode == expectedResult

        assert attemptRepo.findAll().size() == 1

        List<Attempt> actual = attemptRepo.findAll()
        assert actual[0].plannerEntry.uuid == plannerEntry.uuid
        assert actual[0].user.uuid == student1.uuid
        assert actual[0].state == "IN_PROGRESS" as AttemptState
        assert actual[0].timeOnTaskSeconds == body.time_on_task_seconds
        assert actual[0].assessmentScore == body.assessment_score
		assert actual[0].updatedBy == student1.uuid
		assert dateFormat.format(actual[0].completedAt) == body.completed_at

        resp.body.planner_entry_uuid == plannerEntry.uuid.toString()
        resp.body.user_uuid == student1.uuid.toString()
        resp.body.state == "IN_PROGRESS"
		resp.body.status == "IN_PROGRESS"
        resp.body.time_on_task_seconds == actual[0].timeOnTaskSeconds
        resp.body.assessment_score == actual[0].assessmentScore
		resp.body.completed_at == dateFormat.format(actual[0].completedAt)

        // only change the fields in the payload body 
        assert actual[0].sectionCount == attempt.sectionCount
        assert actual[0].sectionTotalCount == attempt.sectionTotalCount

		where:
		state			| status			| expectedResult
		null			|	"IN_PROGRESS"	| 	HttpStatus.OK
		"IN_PROGRESS"	|	null			| 	HttpStatus.OK
		"IN_PROGRESS"	|	"SAVED"			| 	HttpStatus.OK

    }
	
	def "test put attempt endpoint with bad typed/formatted json"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

        and: " planner entry"
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

        and: "Create attempts"
        Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.PASSED)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])



		when:
		def body = [
				"section_count"                   : count,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,
				"state"                           : state,

		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)

		then:

		resp.statusCode == statusCode
		assert resp.body.errors.size == 1
		assert resp.body.errors[0].message.startsWith(expectedError)

		where:
		count | state         | statusCode                    		| expectedError
		"a"   |"IN_PROGRESS"  | HttpStatus.BAD_REQUEST        		| "invalid input a"
		 1    |"INPROGRESS"   | HttpStatus.BAD_REQUEST			    | "The attempt state is not valid."

	}

	@Unroll
	def "test put attempt endpoint with roles restriction"(){
		given:

        def userMap = [admin:admin,  student: student, student1: student1, teacher1: teacher1, teacher: teacher]
        def schoolMap = [school1: school1.uuid, school: school.uuid]

		ClassObj classObj = setupValidClass(teacher, school)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		Enrollment teacherEnroll = enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))


		ClassObj classObj1 = setupValidClass(teacher1, school)
		PageObj pageObj1 = setupValidPage("Page 1", classObj1, 1)
		PageAssignment assignment1 = setupValidPageAssignment("Assignment 1",pageObj1,1)
		Enrollment teacher1Enroll = enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

        and: " planner entry"
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		PlannerEntry plannerEntry1 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj1, pageObj1, assignment1, student1)

        and: "Create attempts"
        Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS, false)
        Attempt attempt1 = createAttempt(plannerEntry, student1, AttemptState.PASSED)

 		String token = createToken(userMap[user], schoolMap[orgInJwt])
		
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:

		def body = [
				"section_count"                   : 1,
				"section_total_count"             : 1,
				"question_count"                  : 1,
				"time_on_task_seconds"            : 250,
				"assessment_score"                : 82,
				"state"                           : "IN_PROGRESS"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)

		then:

		resp.statusCode == statusCode
		if (statusCode != HttpStatus.OK) {
			assert resp.body.errors[0].message.startsWith(expectedError)
		}		

		where:
        user        | orgInJwt   | statusCode			| expectedError	  					
		"admin"     | "school"   | HttpStatus.OK		| ""     			  					
		"admin"     | "school1"  | HttpStatus.FORBIDDEN	| "User does not have permission to update attempt."
		"teacher"   | "school"   | HttpStatus.OK		| "" 
		"teacher1"  | "school"   | HttpStatus.FORBIDDEN	| "User does not have permission to update attempt."
		"student"   | "school"   | HttpStatus.NOT_FOUND	| "Unable to find an attempt record."
		"student1"  | "school"   | HttpStatus.OK		| "" 
	}

	@Unroll
	def "test put attempt endpoint with grading service"() {
		given:

        def userMap = [admin:admin,  student: student, student1: student1, teacher1: teacher1, teacher: teacher]


		ClassObj classObj = setupValidClass(teacher, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		Assignment assignment = assignmentRepo.save(
				new Assignment(
						uuid: UUID.randomUUID(),
						title: "Assignment 1",
						type: AssignmentType.LESSON
				)
		)
		Assignment assignment1 = assignmentRepo.save(
				new Assignment(
						uuid: UUID.randomUUID(),
						title: "Assignment 1",
						type: AssignmentType.PROJECT
				)
		)


        and: " planner entry"
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		PlannerEntry plannerEntry1 = setupPlannerEntry(2, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment1, student)
		def plannerEntryMap = ["lesson":plannerEntry, "project":plannerEntry1]

        and: "Create attempts"
        Attempt attempt = createAttempt(plannerEntry, student, AttemptState.IN_PROGRESS)
		Attempt attempt1 = createAttempt(plannerEntry1, student, AttemptState.IN_PROGRESS)
		def attemptsMap = ["lesson":attempt, "project":attempt1]

 		String token = createToken(userMap[user], school.uuid)
		
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		gpaService.metaClass.calculateScores = { GpaScoresInput input ->
			Double score = ((questionCorrectCount as Double) / (questionCount as Double))
			OutcomeStatus status = OutcomeStatus.FAILED
			if(score * 100 >= input.settings.threshold){
				status = OutcomeStatus.PASSED
			}
			return new OutcomeResponse(score: score, status: status)
		}

		when:

		def body = [
				"questions_attempted_count"       : attemptQuestionCount,
				"question_count"                  : questionCount,
				"questions_correct_count"         : questionCorrectCount,
				"included_manual_graded"		  : manualGraded,
				"state"                           : "SUBMITTED"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntryMap[assignmentType].uuid}/attempts/${attemptsMap[assignmentType].uuid}", HttpMethod.PUT, req, Map)

		Attempt actual = attemptRepo.findOne(attemptsMap[assignmentType].uuid)

		then:

		resp.statusCode == statusCode
		resp.body.state == resultState.toString()
		resp.body.response_overrides.size() == 1
		resp.body.response_overrides.values().toArray()[0] == null

		actual.responseOverrides.size() == 1
		actual.responseOverrides.values().toArray()[0] == null


		where:
		user        | assignmentType | manualGraded | attemptQuestionCount | questionCount | questionCorrectCount  | resultState	 		| statusCode
		"student"   |"lesson"   	 | true   		| 1					   | 1			   | 1					   | AttemptState.SUBMITTED	| HttpStatus.OK
		"student"   |"lesson"   	 | false   		| 1					   | 2			   | 1					   | AttemptState.SUBMITTED	| HttpStatus.OK
		"student"   |"lesson"   	 | false   		| 2					   | 2			   | 1					   | AttemptState.FAILED	| HttpStatus.OK
		"student"   |"lesson"   	 | false   		| 2					   | 2			   | 2					   | AttemptState.PASSED	| HttpStatus.OK
		"student"   |"project"   	 | false   		| 2					   | 2			   | 1					   | AttemptState.FAILED	| HttpStatus.OK
		"student"   |"project"   	 | false   		| 2					   | 2			   | 2					   | AttemptState.PASSED	| HttpStatus.OK

	}

	def "test put saved state with existing save"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student1, activityId: plannerEntry.activityId,
				sectionCount: 1, sectionTotalCount: 1, questionCount: 1, sectionsViewed: ["1", "2"], questionsViewed: ["1", "3", "4"], timeOnTaskSeconds: 54, state: AttemptState.SAVED, creditBearing: true))

		AttemptSave attemptSave = attemptSaveRepo.save(
				new AttemptSave(
						attempt: attempt,
						sequence: 1,
						sectionsViewed: ["1", "2"],
						questionsViewed: ["1", "3", "4"],
						timeOnTaskSeconds: 54,
						createdAt: new Date(),
						createdBy: student1.uuid
				)
		)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

		when:
		def body = [
				"time_on_task_seconds"            : 250,
				"sections_viewed"                 : ["5", "3"],
				"questions_viewed"                : ["4", "2"],
                "questions_answered"              : ["1", "2"],
				"state"                           : AttemptState.SAVED,
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


		then:
		resp.statusCode == HttpStatus.OK
		assert attemptRepo.findAll().size() == 1
		Attempt actual = attemptRepo.findAll().first()

		List<AttemptSave> saves = attemptSaveRepo.findAll().asList()
		assert saves.size() == 2
		assert saves[1].timeOnTaskSeconds == body.time_on_task_seconds
		assert saves[1].sectionsViewed == body.sections_viewed.sort()
		assert saves[1].questionsViewed == body.questions_viewed.sort()
		assert saves[1].attempt.uuid == attempt.uuid
		assert saves[1].sequence == 2

		assert resp.body.saves == [
				[
						attempt_uuid : attemptSave.attempt.uuid.toString(),
						attempt_save_uuid : attemptSave.uuid.toString(),
						sequence: attemptSave.sequence,
						questions_viewed: attemptSave.questionsViewed,
						sections_viewed: attemptSave.sectionsViewed,
						time_on_task_seconds: attemptSave.timeOnTaskSeconds,
						created_at: dateFormat.format(attemptSave.createdAt)
				],
				[
						attempt_uuid : attempt.uuid.toString(),
						attempt_save_uuid : saves[1].uuid.toString(),
						sequence: 2,
						questions_viewed: body.questions_viewed.sort(),
						sections_viewed: body.sections_viewed.sort(),
						time_on_task_seconds: body.time_on_task_seconds,
						created_at: dateFormat.format(saves[1].createdAt)
				]
		]

		assert actual.timeOnTaskSeconds == 304
		assert actual.sectionsViewed == ["1", "2", "3", "5"]
		assert actual.questionsViewed == ["1", "2", "3", "4"]
        assert actual.questionsAnswered == ["1", "2"]
		assert actual.state == AttemptState.SAVED

	}

	def "test put submit state with existing save"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student1, activityId: plannerEntry.activityId,
				sectionCount: 1, sectionTotalCount: 1, questionCount: 4, sectionsViewed: ["1", "2"], questionsViewed: ["1", "3", "4"], timeOnTaskSeconds: 54, state: AttemptState.SAVED, creditBearing: true))

		AttemptSave attemptSave = attemptSaveRepo.save(
				new AttemptSave(
						attempt: attempt,
						sequence: 1,
						sectionsViewed: ["1", "2"],
						questionsViewed: ["1", "3", "4"],
						timeOnTaskSeconds: 54,
						createdAt: new Date(),
						createdBy: student1.uuid
				)
		)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

		when:
		def body = [
				"time_on_task_seconds"            : 250,
				"sections_viewed"                 : ["5", "3"],
				"questions_viewed"                : ["4", "2"],
				"state"                           : AttemptState.SUBMITTED,
				"questions_attempted_count"       : 2,
				"question_count"                  : 4,
				"questions_correct_count"         : 4,
				"included_manual_graded"		  : false
		]


		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


		then:
		resp.statusCode == HttpStatus.OK
		assert attemptRepo.findAll().size() == 1
		Attempt actual = attemptRepo.findAll().first()

		List<AttemptSave> saves = attemptSaveRepo.findAll().asList()
		assert saves.size() == 1

		assert resp.body.saves == [
				[
						attempt_uuid : attemptSave.attempt.uuid.toString(),
						attempt_save_uuid : attemptSave.uuid.toString(),
						sequence: attemptSave.sequence,
						questions_viewed: attemptSave.questionsViewed,
						sections_viewed: attemptSave.sectionsViewed,
						time_on_task_seconds: attemptSave.timeOnTaskSeconds,
						created_at: dateFormat.format(attemptSave.createdAt)
				]
		]

		assert actual.timeOnTaskSeconds == 304
		assert actual.sectionsViewed == ["1", "2", "3", "5"]
		assert actual.questionsViewed == ["1", "2", "3", "4"]
		assert actual.state == AttemptState.PASSED

	}


	def "test put saved state without existing save"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student1, activityId: plannerEntry.activityId,
				sectionCount: 1, sectionTotalCount: 1, questionCount: 1, state: AttemptState.IN_PROGRESS, creditBearing: true))

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()

		when:
		def body = [
				"time_on_task_seconds"            : 250,
				"sections_viewed"                 : ["5", "3"],
				"questions_viewed"                : ["4", "2"],
                "questions_answered"              : ["1", "2"],
				"state"                           : AttemptState.SAVED,

		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


		then:
		resp.statusCode == HttpStatus.OK
		assert attemptRepo.findAll().size() == 1
		Attempt actual = attemptRepo.findAll().first()

		List<AttemptSave> saves = attemptSaveRepo.findAll().asList()
		assert saves.size() == 1
		assert saves[0].timeOnTaskSeconds == body.time_on_task_seconds
		assert saves[0].sectionsViewed == body.sections_viewed.sort()
		assert saves[0].questionsViewed == body.questions_viewed.sort()
		assert saves[0].attempt.uuid == attempt.uuid
		assert saves[0].sequence == 1

		assert resp.body.saves == [
				[
						attempt_uuid : attempt.uuid.toString(),
						attempt_save_uuid : saves[0].uuid.toString(),
						sequence: 1,
						questions_viewed: body.questions_viewed.sort(),
						sections_viewed: body.sections_viewed.sort(),
						time_on_task_seconds: body.time_on_task_seconds,
						created_at: dateFormat.format(saves[0].createdAt)
				]
		]

		assert actual.timeOnTaskSeconds == 250
		assert actual.sectionsViewed == ["3", "5"]
		assert actual.questionsViewed == ["2", "4"]
        assert actual.questionsAnswered == ["1", "2"]
		assert actual.state == AttemptState.SAVED

        assert resp.body.questions_answered == ["1", "2"]

	}


	def "test put save attempt sequences"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		DateFormat dateFormat = new DateFormat()
		def body = [
				"time_on_task_seconds"            : 1,
				"sections_viewed"                 : ["1"],
				"questions_viewed"                : ["1"],
				"state"                           : AttemptState.SAVED,

		]
		HttpEntity req = new HttpEntity(body, headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)


		then:
		resp.statusCode == HttpStatus.OK
		assert resp.body.saves.size() == 1
		assert resp.body.saves[0].sequence == 1

		when:
		resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)

		then:
		resp.statusCode == HttpStatus.OK
		assert resp.body.saves.size() == 2
		assert resp.body.saves[0].sequence == 1
		assert resp.body.saves[1].sequence == 2

		when:
		resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt2.uuid}", HttpMethod.PUT, req, Map)

		then:
		resp.statusCode == HttpStatus.OK
		assert resp.body.saves.size() == 1
		assert resp.body.saves[0].sequence == 1
	}

	def "ignore saves array in put request body"(){
		given:

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student1, activityId: plannerEntry.activityId,
				sectionCount: 1, sectionTotalCount: 1, questionCount: 4, sectionsViewed: ["1", "2"], questionsViewed: ["1", "3", "4"],
				timeOnTaskSeconds: 54, state: AttemptState.SAVED, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		AttemptSave attemptSave = attemptSaveRepo.save(
				new AttemptSave(
						attempt: attempt,
						sequence: 1,
						sectionsViewed: ["1", "2"],
						questionsViewed: ["1", "3", "4"],
						timeOnTaskSeconds: 54,
						createdAt: new Date(),
						createdBy: student1.uuid
				)
		)

		DateFormat dateFormat = new DateFormat()

		def body = [
			"saves": [
				[
					"sequence": 1,
					"attempt_save_uuid": attemptSave.uuid.toString(),
					"attempt_uuid": attempt.uuid.toString(),
					"sections_viewed": attemptSave.sectionsViewed,
					"questions_viewed": attemptSave.questionsViewed,
					"time_on_task_seconds": attemptSave.timeOnTaskSeconds,
					"created_at": dateFormat.format(attemptSave.createdAt)
				]
			],
			"attempt_uuid": attempt.uuid.toString(),
			"planner_entry_uuid": plannerEntry.uuid.toString(),
			"user_uuid": student1.uuid.toString(),
			"activity_id": attempt.activityId.toString(),
			"section_count": attempt.sectionCount,
			"section_total_count": attempt.sectionTotalCount,
			"question_count": attempt.questionCount,
			"questions_attempted_count": attempt.questionsAttemptedCount,
			"questions_correct_count": attempt.questionsCorrectCount,
			"questions_incorrect_count": attempt.questionsIncorrectCount,
			"questions_not_scored_count": attempt.questionsNotScoredCount,
			"state": attempt.state.toString(),
			"time_on_task_seconds": attempt.timeOnTaskSeconds,
			"assessment_score": null,
			"created_at": dateFormat.format(attempt.createdAt),
			"last_modified": dateFormat.format(attempt.updatedAt),
			"section_items": [
					[
							"uuid": "c576d793-4acd-3fea-b7d3-7d770fc37335",
							"items": [
									[
											"uuid": "7c3662ec-81b9-3b03-9078-8386b8e5ed92",
											"sequence": 1
									],
									[
											"uuid": "b98cb93d-36fe-3dca-902d-a7c1c6bbf14a",
											"sequence": 2
									],
									[
											"uuid": "a085c5db-a425-3c4a-b4e4-d7d0bea0cfe2",
											"sequence": 3
									],
									[
											"uuid": "87c5b6a9-3084-3356-b030-a7312760c1e3",
											"sequence": 4
									],
									[
											"uuid": "1af9d5b3-1c06-356c-9358-705fea59c7e9",
											"sequence": 5
									]
							],
							"sequence": 2
					]
			],
			"sections_viewed": attempt.sectionsViewed,
			"questions_viewed": attempt.questionsViewed,
			"included_manual_graded": false,
			"response_overrides": null,
			"completed_at": null
		]

		HttpHeaders headers = new HttpHeaders()
		String token = createToken(student1, school.uuid)
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])
		HttpEntity req = new HttpEntity(body, headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PUT, req, Map)

		then:
		resp.statusCode == HttpStatus.OK

	}

	@Unroll
	def "test patch attempt endpoint"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"state":state
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PATCH, req, Map)


		then:
		assert resp.statusCode == expectedStatus
		if(expectedStatus == HttpStatus.OK) {
			assert attemptRepo.findAll().size() == 1

			Attempt actual = attemptRepo.findAll().asList().first()
			assert actual.state == body.state as AttemptState
			assert actual.updatedAt > actual.createdAt
			assert actual.updatedBy == student1.uuid
			assert resp.body.planner_entry_uuid == plannerEntry.uuid.toString()
			assert resp.body.user_uuid == student1.uuid.toString()
			assert resp.body.state == actual.state.toString()
			assert resp.body.time_on_task_seconds == actual.timeOnTaskSeconds
			assert resp.body.assessment_score == actual.assessmentScore
			assert resp.body.saves == []
		}
		else {
			assert resp.body.errors == [expectedError]
		}

		where:
		state         || expectedStatus         | expectedError
		"IN_PROGRESS" || HttpStatus.OK          | ""
		"SAVED"       || HttpStatus.OK          | ""
		"SUBMITTED"   || HttpStatus.OK          | ""
		"PASSED"      || HttpStatus.BAD_REQUEST | [message:  "Unable to process the request to update an attempt because the new 'state' passed in is PASSED"]
		"FAILED"      || HttpStatus.BAD_REQUEST | [message:  "Unable to process the request to update an attempt because the new 'state' passed in is FAILED"]
		"OBE"         || HttpStatus.OK          | ""
		"FOO"         || HttpStatus.BAD_REQUEST | [field: "state", message: "The attempt state is not valid."]
	}
	
	@Unroll
	def "test patch attempt endpoint - status and state"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(student1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"state":state,
				"status":status
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PATCH, req, Map)


		then:
		assert resp.statusCode == expectedResult
		if(resp.statusCode == HttpStatus.OK) {
			assert resp.body.state == "IN_PROGRESS"
			assert resp.body.status == "IN_PROGRESS"
		}
		else {
			assert resp.body.errors.message[0] == "Missing required field."
			assert resp.body.errors.field[0] == "state"
		}

		where:
		state			| status			| expectedResult
		null			|	"IN_PROGRESS"	| 	HttpStatus.OK
		"IN_PROGRESS"	|	null			| 	HttpStatus.OK
		"IN_PROGRESS"	|	"SAVED"			| 	HttpStatus.OK
		null			|	null			|	HttpStatus.BAD_REQUEST
	}

	@Unroll
	def "test patch attempt roles"(){
		given:
		def userMap = [admin:admin,  student: student, student1: student1, teacher1: teacher1, teacher: teacher]
		def schoolMap = [school1: school1.uuid, school: school.uuid]

		ClassObj classObj = setupValidClass(teacher, school)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

		ClassObj classObj1 = setupValidClass(teacher1, school)
		PageObj pageObj1 = setupValidPage("Page 1", classObj1, 1)
		PageAssignment assignment1 = setupValidPageAssignment("Assignment 1",pageObj1,1)
		enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
		PlannerEntry plannerEntry1 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj1, pageObj1, assignment1, student1)

		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)
		Attempt attempt1 = createAttempt(plannerEntry1, student1, AttemptState.FAILED)

		String token = createToken(userMap[user], schoolMap[orgInJwt])

		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set("X-Client-Domain", "localhost")
		headers.setContentType(Constants.ATTEMPTS_VERSION_1_MT)
		headers.setAccept([Constants.ATTEMPTS_VERSION_1_MT])

		when:

		def body = [
				"state": "IN_PROGRESS"
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}", HttpMethod.PATCH, req, Map)

		then:

		assert resp.statusCode == statusCode
		if (statusCode != HttpStatus.OK) {
			assert resp.body.errors == [[message: expectedError]]
		}

		where:
		user        | orgInJwt   | statusCode			| expectedError
		"admin"     | "school"   | HttpStatus.OK		| ""
		"admin"     | "school1"  | HttpStatus.FORBIDDEN	| "User does not have permission to update attempt."
		"teacher"   | "school"   | HttpStatus.OK		| ""
		"teacher1"  | "school"   | HttpStatus.FORBIDDEN	| "User does not have permission to update attempt."
		"student"   | "school"   | HttpStatus.NOT_FOUND	| "Unable to find an attempt record."
		"student1"  | "school"   | HttpStatus.OK		| ""
	}


	//DELETE
	@Unroll
	def "DELETE attempt - failed delete for roles: SUPPORT_ADMINISTRATOR,  PARENT, SUPPORT_LICENSING,  SUPPORT_USER, SUPPORT_CEM. These roles cannot delete an attempt."(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
            //enroll the kid in the class
            enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			admin.type = role
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == expectedStatusCode
	
		where:
			role								|	expectedStatusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT					|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM				|	HttpStatus.FORBIDDEN
	}

    /**
     * sat-1846
     *  This will test both success and fail for these scenarios
     *  Kid closes out of Nova without Submitting.   DELETE /attempts
     *  The endpoint will validate that kid is still enrolled and class not COMPLETED.
     *  When fails, will return HttpStatus.RESET_CONTENT- but the attempt will be deleted
     */
	@Unroll
	def "DELETE attempt - successful delete for role: STUDENT"(){
		given:
			ClassObj classObj = setupValidClass(student1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)

            if (enrolledFlag == true) {
                //enroll the kid in the class
                enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            }
        	classObj.state = classState
        	classRepo.save(classObj)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(student1, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)

		then:
			assert resp.statusCode == expectedStatus

        where:
        enrolledFlag                | classState                | expectedStatus
        true                        | ClassObjState.STARTED     | HttpStatus.NO_CONTENT
        false                       | ClassObjState.STARTED     | HttpStatus.RESET_CONTENT
        true                        | ClassObjState.COMPLETED   | HttpStatus.RESET_CONTENT
			
	}

    @Unroll
    def "delete attempt should set a new credit_bearing attempt"() {
        given:
        ClassObj classObj = setupValidClass(student1, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
        createEnrollment(classObj, student1, Role.STUDENT)
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

        Attempt attempt1 = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS, false)
        Attempt attempt2 = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS, false)
        Attempt attempt3 = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS, true)

        Map<String, Attempt> attemptMap = [
                attempt1: attempt1,
                attempt2: attempt2,
                attempt3: attempt3
        ]

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/" + plannerEntry.uuid + "/attempts/" + attemptMap[id].uuid, HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        List<Attempt> attempts = attemptRepo.findAll().asList()
        assert attempts.size() == 2
        assert attempts.find{it.uuid == attemptMap[latest].uuid}.creditBearing
        assert !attempts.find{it.uuid != attemptMap[latest].uuid}.creditBearing

        where:
        id         | latest
        "attempt1" | "attempt3"
        "attempt2" | "attempt3"
        "attempt3" | "attempt2"

    }

	
	def "DELETE attempt - failed delete for role: STUDENT - student tries to access an Attempt associated with a different student"(){
		given:
			ClassObj classObj = setupValidClass(student1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(student, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			
	}


	/**
	 * sat-1846
	 *  This will test both success and fail for these scenarios
	 *  Kid closes out of Nova without Submitting.   DELETE /attempts
	 *  The endpoint will validate that kid is still enrolled and class not COMPLETED.
	 *  When fails, will return HttpStatus.RESET_CONTENT- but the attempt will be deleted
	 */
	@Unroll
	def "DELETE attempt - successful delete for role: ADMIN"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)

			if (enrolledFlag == true) {
				//enroll the kid in the class
				enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
			}
			classObj.state = classState
			classRepo.save(classObj)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == expectedStatus

		where:
		enrolledFlag                | classState                | expectedStatus
		true                        | ClassObjState.STARTED     | HttpStatus.NO_CONTENT
		false                       | ClassObjState.STARTED     | HttpStatus.RESET_CONTENT
		true                        | ClassObjState.COMPLETED   | HttpStatus.RESET_CONTENT
			
	}
	
	//DELETE
	def "DELETE attempt - failed delete for role: ADMIN - admin tries to access an Attempt associated with a different admin"(){
		given:
			school1 = organizationRepo.save(new Organization(name: 'XXX', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
			campus1 = organizationRepo.save(new Organization(name: 'YYY', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school1))
			admin1 = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
			
			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(adminBelongingToSchool1, school1.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == HttpStatus.FORBIDDEN
			
	}


	/**
	 * sat-1846
	 *  This will test both success and fail for these scenarios
	 *  Kid closes out of Nova without Submitting.   DELETE /attempts
	 *  The endpoint will validate that kid is still enrolled and class not COMPLETED.
	 *  When fails, will return HttpStatus.RESET_CONTENT- but the attempt will be deleted
	 */
	def "DELETE attempt - successful delete for role: TEACHER"(){
		given:
			ClassObj classObj = setupValidClass(teacher, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)

			if (enrolledFlag == true) {
				//enroll the kid in the class
				enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
			}
			classObj.state = classState
			classRepo.save(classObj)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
			
			and: "One Enrollment"
			Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))
			
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(teacher, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == expectedStatus

		where:
		enrolledFlag                | classState                | expectedStatus
		true                        | ClassObjState.STARTED     | HttpStatus.NO_CONTENT
		false                       | ClassObjState.STARTED     | HttpStatus.RESET_CONTENT
		true                        | ClassObjState.COMPLETED   | HttpStatus.RESET_CONTENT
			
	}
	
	
	//DELETE
	def "DELETE attempt - failed delete for role: TEACHER - teacher tries to access an Attempt associated with a different teacher"(){
		given:
			ClassObj classObj = setupValidClass(teacher, campus)
			ClassObj classObj1 = setupValidClass(teacher1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
			
			and: "One Enrollment"
			Enrollment enrollment1 = enrollmentRepo.save(new Enrollment(classObj: classObj1, user: teacher1, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))
			
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

			String token = createToken(teacher, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == HttpStatus.FORBIDDEN
			
	}
	

	//DELETE
	@Unroll
	def "DELETE attempt - failed delete for state: SUBMITTED,  PASSED,  FAILED. Attempts in these states cannot be deleted"(){
		given:
			ClassObj classObj = setupValidClass(student1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
	
			and: "One planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create an existing attempt"
			Attempt attempt = createAttempt(plannerEntry, student1, state)

			String token = createToken(student1, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts/"+attempt.uuid, HttpMethod.DELETE, req, Map)


		then:
			assert resp.statusCode == expectedStatusCode
	
		where:
			state								|	expectedStatusCode
			AttemptState.SUBMITTED				|	HttpStatus.FORBIDDEN
			AttemptState.PASSED					|	HttpStatus.FORBIDDEN
			AttemptState.FAILED					|	HttpStatus.FORBIDDEN
	}

	def "test post attempt lock endpoint"(){
		given:
		def userMap = [admin:admin, teacher: teacher]

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(userMap[user], school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, req, Map)

		then:
		resp.statusCode == HttpStatus.CREATED
		assert lockRepo.findAll().size() == 1

		List<Lock> actual = lockRepo.findAll()
		assert actual[0].lockedByUser.uuid == userMap[user].uuid
		assert actual[0].resourceUuid == attempt.uuid
		assert actual[0].resourceType == ResourceType.ATTEMPT

		resp.body.lock_uuid == actual[0].uuid.toString()
		resp.body.resource_type == ResourceType.ATTEMPT.toString()
		resp.body.resource_uuid == attempt.uuid.toString()
		resp.body.locked_by.user_uuid == userMap[user].uuid.toString()

		where:
		user << ["admin", "teacher"]
	}

	def "test admin can't lock an attempt outside of their school"(){
		given:
		admin1 = userRepo.save(new User(firstName: 'Admin2', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))

		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(admin1, school1.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, req, Map)

		then:
		resp.statusCode == HttpStatus.UNAUTHORIZED
		assert lockRepo.findAll().size() == 0
		resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."
	}

	def "test deleteing a lock"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		and: "Create an existing lock"
		Lock lock = lockRepo.save(new Lock(lockedByUser: admin, resourceType: ResourceType.ATTEMPT, lockedAt: new Date(), resourceUuid: attempt.uuid))

		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks/${lock.uuid}", HttpMethod.DELETE, req, Map)

		then:
		resp.statusCode == HttpStatus.NO_CONTENT
		assert lockRepo.findAll().size() == 0
	}

	def "test deleteing a lock with a user that didn't make the lock"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		and: "Create an existing lock"
		Lock lock = lockRepo.save(new Lock(lockedByUser: admin, resourceType: ResourceType.ATTEMPT, lockedAt: new Date(), resourceUuid: attempt.uuid))

		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks/${lock.uuid}", HttpMethod.DELETE, req, Map)

		then:
		resp.statusCode == HttpStatus.BAD_REQUEST
		assert lockRepo.findAll().size() == 1

		resp.body.errors.message[0] == "Lock does not belong to user ${teacher.uuid}"
	}

	def "test failure to acquire a lock"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		and: "Create an existing lock"
		lockRepo.save(new Lock(lockedByUser: admin, resourceType: ResourceType.ATTEMPT, lockedAt: new Date(), resourceUuid: attempt.uuid))

		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, req, Map)

		then:
		resp.statusCode == HttpStatus.CONFLICT
		assert lockRepo.findAll().size() == 1

		resp.body.errors.message[0] == "${admin.firstName} ${admin.lastName} is currently reviewing this assignment."
	}

	def "test failure for trying to lock an assignment from a class teacher is not enrolled in"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		String token = createToken(teacher1, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, req, Map)

		then:
		resp.statusCode == HttpStatus.FORBIDDEN
		assert lockRepo.findAll().size() == 0

		resp.body.errors.message[0] == "User is not an enrolled TEACHER or an ADMIN."
	}

	def "test lock override by another user after 6 hours"(){
		given:
		ClassObj classObj = setupValidClass(admin, campus)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
		Enrollment enrollment = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))

		and: "One planner entry"
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)

		and: "Create an existing attempt"
		Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.IN_PROGRESS)

		and: "Create an existing lock"
		use( TimeCategory ) {
			lockRepo.save(new Lock(lockedByUser: admin, resourceType: ResourceType.ATTEMPT, lockedAt: new Date() - 6.hours - 1.minutes, resourceUuid: attempt.uuid))
		}

		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.LOCKS_VERSION_1_MT)
		headers.setAccept([Constants.LOCKS_VERSION_1_MT])

		when:
		HttpEntity req = new HttpEntity(headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, req, Map)

		then:
		resp.statusCode == HttpStatus.CREATED
		assert lockRepo.findAll().size() == 1

		List<Lock> actual = lockRepo.findAll()
		assert actual[0].lockedByUser.uuid == teacher.uuid
		assert actual[0].resourceUuid == attempt.uuid
		assert actual[0].resourceType == ResourceType.ATTEMPT

		resp.body.lock_uuid == actual[0].uuid.toString()
		resp.body.resource_type == ResourceType.ATTEMPT.toString()
		resp.body.resource_uuid == attempt.uuid.toString()
		resp.body.locked_by.user_uuid == teacher.uuid.toString()
	}
	
	def"student successfully views an attempt that a teacher has currently locked for review"(){
		given:
			ClassObj classObj = setupValidClass(student1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
			Enrollment enrollmentTeacher = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))
			Enrollment enrollmentStudent = enrollmentRepo.save(new Enrollment(classObj: classObj, user: student1, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, updated: new Date(), created: new Date()))

			and: "create one planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create one attempt"

			Attempt attempt = createAttempt(plannerEntry, student1, AttemptState.PASSED)

			// lock headers
			HttpHeaders lockHeaders = new HttpHeaders()
			lockHeaders.set("Authorization", "Bearer ${createToken(teacher, campus.uuid)}")
			lockHeaders.setContentType(Constants.LOCKS_VERSION_1_MT)
			lockHeaders.setAccept([Constants.LOCKS_VERSION_1_MT])
			HttpEntity lockRequest = new HttpEntity(lockHeaders)
			
			// attempt headers
			HttpHeaders attemptHeaders = new HttpHeaders()
			attemptHeaders.set("Authorization", "Bearer ${createToken(student1, campus.uuid)}")
			attemptHeaders.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity attemptRequest = new HttpEntity(attemptHeaders)

		when:
			// teacher creates a Lock on an Attempt
			HttpEntity lockResponse = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, lockRequest, Map)
			
			// student tries to view the attempt the teacher has locked
			HttpEntity attemptResponse = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid+"/attempts", HttpMethod.GET, attemptRequest, Map)

		then:
			// the lock has been successfully created
			lockResponse.statusCode == HttpStatus.CREATED
			assert lockRepo.findAll().size() == 1
			List<Lock> actual = lockRepo.findAll()
			assert actual[0].lockedByUser.uuid == teacher.uuid
			assert actual[0].resourceUuid == attempt.uuid
			assert actual[0].resourceType == ResourceType.ATTEMPT
			
			// the student can view the locked attempt - no need to verify all fields
			assert attemptResponse.statusCode == HttpStatus.OK
			def attempts = attemptResponse.body.attempts
			assert attempts[0].planner_entry_uuid == plannerEntry.uuid.toString()
			assert attempts[0].attempt_uuid == attempt.uuid.toString()
			assert attempts[0].question_count == 1
			assert attempts[0].assessment_score == 40
	}
	
	
	def"teacher successfully extends a lock he/she currently owns"(){
		given:
			ClassObj classObj = setupValidClass(student1, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
			Enrollment enrollmentTeacher = enrollmentRepo.save(new Enrollment(classObj: classObj, user: teacher, role: Role.TEACHER, primaryRole: true, status: Status.ACTIVE, updated: new Date(), created: new Date()))
			Enrollment enrollmentStudent = enrollmentRepo.save(new Enrollment(classObj: classObj, user: student1, role: Role.STUDENT, primaryRole: false, status: Status.ACTIVE, updated: new Date(), created: new Date()))
			Date originalLockedAtDate = new Date(System.currentTimeMillis() - 10800000) // date that is 3 hours in the past

			and: "create one planner entry"
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student1)
	
			and: "Create one attempt"
			
			Attempt attempt = createAttempt(plannerEntry, student, AttemptState.PASSED)

			and: "Create an existing lock"
			Lock lock = lockRepo.save(new Lock(lockedByUser: teacher, resourceType: ResourceType.ATTEMPT, lockedAt: originalLockedAtDate, resourceUuid: attempt.uuid))
			
			// lock headers
			HttpHeaders lockHeaders = new HttpHeaders()
			lockHeaders.set("Authorization", "Bearer ${createToken(teacher, campus.uuid)}")
			lockHeaders.setContentType(Constants.LOCKS_VERSION_1_MT)
			lockHeaders.setAccept([Constants.LOCKS_VERSION_1_MT])
			HttpEntity lockRequest = new HttpEntity(lockHeaders)
			
		when:
			// teacher re-acquires the same Lock which results in it being extended
			HttpEntity lockResponse = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews/locks", HttpMethod.POST, lockRequest, Map)
			
		then:
			// the lock has been successfully updated with a new lockedAt date.
			lockResponse.statusCode == HttpStatus.CREATED
			assert lockRepo.findAll().size() == 1
			List<Lock> actual = lockRepo.findAll()
			assert actual[0].lockedByUser.uuid == teacher.uuid
			assert actual[0].lockedAt > originalLockedAtDate
		
	}
	
	private setupPlannerEntry(Integer slot, PlannerEntryState state, ClassObj classObj, PageObj pageObj, Assignment assignment,User user) {
		PlannerEntry plannerEntry = new PlannerEntry(
				slot: slot,
				status: state,
				classObj: classObj,
				pageObj: pageObj,
				activityId: assignment.uuid,
				assignment: assignment,
				user:user)
		plannerEntryRepo.save(plannerEntry)
		return plannerEntry
	}

	private void verifyAttempt(String uuid, Attempt attempt) {
		assert UUID.fromString(uuid) == attempt.uuid
	}
	
	private boolean verifyAttempt( String uuid, List<Attempt> attempts){
		for( Attempt attempt : attempts ){
			if( UUID.fromString(uuid) == attempt.uuid ){
				return true
			}
		}
		
	}


    private Attempt createAttempt(PlannerEntry plannerEntry, User student, AttemptState attemptState, creditBearing = true, Integer questionCount = 1) {
        return attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: questionCount, state: attemptState, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: ["abc", "def"], sectionsViewed: ["1", "2"], includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: creditBearing))
    }
}
