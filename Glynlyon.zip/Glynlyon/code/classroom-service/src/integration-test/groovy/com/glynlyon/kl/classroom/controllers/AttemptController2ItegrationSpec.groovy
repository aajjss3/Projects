package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.learnosity.client.LearnosityDataClient
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.service.LearnosityDataService
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityResponse

import spock.lang.Unroll

class AttemptController2ItegrationSpec  extends BaseRestSpec{
	
	User admin, student
	
	Organization school, campus

	Integer globalLessonThreshold = 70, globalLessonAttempt = 2, globalProjectThreshold = 70, globalProjectAttempt = 2
	Map globalGradeDisplay = [percentage: true, letter: false]
	Map globalGradeScale = [A:90,B:80,C:70,D:60]
	boolean globalThreshold = true

	@Autowired
	LearnosityDataService learnosityDataService
	
	def setup() {
		school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		campus = organizationRepo.save(new Organization(name: 'Winterfell', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))
		admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
		student = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'testing', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))

		def globalSettingValue = [admin: [override: globalThreshold], classroom: [lessons: [threshold: globalLessonThreshold, attempts: globalLessonAttempt],	projects: [threshold: globalProjectThreshold, attempts: globalProjectAttempt], grade_display:  globalGradeDisplay, grade_scale: globalGradeScale]]
		settingRepo.save(new Setting(sourceUUID: null, value: globalSettingValue, type: SettingType.GLOBAL, version: 0) )


		learnosityDataService.metaClass.getClient = { String domain ->
			return new LearnosityDataClient("", "", ""){
				@Override
				Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
					return sessionIds.collectEntries {
						[(it): new LearnosityGetAllSessionsResponse(
								userId: UUID.randomUUID(),
								activityId: UUID.randomUUID(),
								sessionId: it,
								numAttempted: 2,
								numQuestions: 4,
								score: 100,
								maxScore: 100,
								status: "DONE",
								responses: [
										new LearnosityResponse(
												responseId: UUID.randomUUID(),
												score: 70,
												maxScore: 1.0
										)
								]
						)]
					}
				}
			}
		}
	}
	
	// If current attempt.state is PASSED or FAILED or SUBMITTED then do not save attempt data, do not call the grading service and do not call learnosity. instead an error message is returned.
	// If the new attempt.state being passed in is SAVED or IN_PROGRESS then do not save attempt data, do not call the grading service and do not call learnosity. instead an error message is returned.
	@Unroll
	def "PUT - Do not save attempt data that is passed in, do not call grading service, and do not call learnosity"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
			Attempt currentAttempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: currentAttemptState, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		when:
			def body = [
				"planner_entry_uuid"            : plannerEntry.uuid,
				"user_uuid"                     : student.uuid,
				"state"                         : newAttemptState,
				"section_count"					: 55
			]
			String token = createToken(student, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.set("X-Client-Domain", "localhost")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(body, headers)
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${currentAttempt.uuid}", HttpMethod.PUT, req, Map)

		then:
			resp.statusCode == HttpStatus.BAD_REQUEST
			assert resp.body.errors.size == 1
			assert resp.body.errors[0].message
			
	
		where:
			currentAttemptState			|  newAttemptState				
			AttemptState.PASSED			|	AttemptState.SUBMITTED		
			AttemptState.FAILED			|	AttemptState.SUBMITTED		
			AttemptState.SUBMITTED		|	AttemptState.SUBMITTED	
			AttemptState.PASSED			|	AttemptState.PASSED			
			AttemptState.FAILED			|	AttemptState.PASSED			
			AttemptState.SUBMITTED		|	AttemptState.PASSED			
			AttemptState.PASSED			|	AttemptState.FAILED			
			AttemptState.FAILED			|	AttemptState.FAILED			
			AttemptState.SUBMITTED		|	AttemptState.FAILED			
			AttemptState.PASSED			|	AttemptState.IN_PROGRESS	
			AttemptState.FAILED			|	AttemptState.IN_PROGRESS	
			AttemptState.SUBMITTED		|	AttemptState.IN_PROGRESS	
			AttemptState.PASSED			|	AttemptState.SAVED			
			AttemptState.FAILED			|	AttemptState.SAVED			
			AttemptState.SUBMITTED		|	AttemptState.SAVED			
			AttemptState.PASSED			|	AttemptState.PASSED			
			AttemptState.FAILED			|	AttemptState.PASSED			
			AttemptState.SUBMITTED		|	AttemptState.PASSED			
			AttemptState.SAVED			|	AttemptState.FAILED		
			AttemptState.SAVED			|	AttemptState.PASSED		
			AttemptState.IN_PROGRESS	|	AttemptState.FAILED			
			AttemptState.IN_PROGRESS	|	AttemptState.PASSED			
		
	}
	
	
	// If current attempt.state is SAVED or IN_PROGRESS and the new attempt.state being passed in is SAVED or IN_PROGRESS then update the attempt entity but do not call the grading service and do not call learnosity
	// NOTE: saving individual fields is covered with the original PUT integration tests. this will only test the attempt fields: 'assessmentScore', 'responseOverrides', and 'state'
	@Unroll
	def "PUT - Save the attempt data that is passed in, do not call learnosity, do not call grading service"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
			Attempt currentAttempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: currentAttemptState, timeOnTaskSeconds: 250, assessmentScore: null, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		when:
			def body = [
				"planner_entry_uuid"            : plannerEntry.uuid,
				"user_uuid"                     : student.uuid,
				"state"                         : newAttemptState	
			]
			String token = createToken(student, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.set("X-Client-Domain", "localhost")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(body, headers)
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${currentAttempt.uuid}", HttpMethod.PUT, req, Map)

		then:
			resp.statusCode == HttpStatus.OK
			assert attemptRepo.findAll().size() == 1

			List<Attempt> actual = attemptRepo.findAll()
			assert actual[0].state == newAttemptState
			assert !actual[0].responseOverrides
			assert !actual[0].assessmentScore

	
		where:
			currentAttemptState			|  newAttemptState				
			AttemptState.SAVED			|	AttemptState.SAVED			
			AttemptState.SAVED			|	AttemptState.IN_PROGRESS	
			AttemptState.IN_PROGRESS	|	AttemptState.SAVED			
			AttemptState.IN_PROGRESS	|	AttemptState.IN_PROGRESS	
			
	}
			
	
	// If current attempt.state is SAVED or IN_PROGRESS and the new attempt.state being passed in is SUBMITTED and either includedManualGraded is true or questionsAttemptedCount < question count then update the attempt entity and call learnosity but do not call the grading service
	// NOTE: saving individual fields is covered with the original PUT integration tests. this will only test the attempt fields: 'assessmentScore', 'responseOverrides', and 'state' 
	@Unroll
	def "PUT - Save the attempt data that is passed in, call learnosity, do not call grading service"(){
		given:
			ClassObj classObj = setupValidClass(admin, campus)
			PageObj pageObj = setupValidPage("Page 1", classObj, 1)
			PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
			Attempt currentAttempt = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: currentAttemptState, timeOnTaskSeconds: 250, assessmentScore: null, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true))

		when:
			def body = [
				"planner_entry_uuid"            : plannerEntry.uuid,
				"user_uuid"                     : student.uuid,
				"state"                         : AttemptState.SUBMITTED,
				"included_manual_graded"		: includeManualGraded,
				"questions_attempted_count"		: questionAttemptedCount,
				"question_count"				: questionCount
			]
			String token = createToken(student, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.set("X-Client-Domain", "localhost")
			headers.add(HttpHeaders.CONTENT_TYPE, "application/vnd.plannerentries.attempts.v1+json")
			HttpEntity req = new HttpEntity(body, headers)
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${currentAttempt.uuid}", HttpMethod.PUT, req, Map)

		then:
			resp.statusCode == HttpStatus.OK
			assert attemptRepo.findAll().size() == 1

			List<Attempt> actual = attemptRepo.findAll()
			PlannerEntry pe = actual[0].plannerEntry
			assert pe.status == PlannerEntryState.COMPLETED
			assert actual[0].responseOverrides
			assert !actual[0].assessmentScore

	
		where:
			currentAttemptState			| includeManualGraded 	|	questionAttemptedCount	| questionCount		
			AttemptState.SAVED			|			false		|		10					|	50
			AttemptState.IN_PROGRESS	|			false		|		10					|	50
			AttemptState.SAVED			|			true		|		10					|	50
			AttemptState.IN_PROGRESS	|			true		|		10					|	50
			AttemptState.SAVED			|			true		|		50					|	50
			AttemptState.IN_PROGRESS	|			true		|		50					|	50
						
	}

}
