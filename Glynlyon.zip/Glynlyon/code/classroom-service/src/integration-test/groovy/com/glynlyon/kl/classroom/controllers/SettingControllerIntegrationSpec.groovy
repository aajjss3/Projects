package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.dto.SettingDTO
import com.glynlyon.kl.classroom.dto.Value
import com.glynlyon.kl.classroom.dto.mapper.BaseMapper
import com.glynlyon.kl.classroom.model.*
import com.glynlyon.kl.classroom.repo.SettingRepo
import com.glynlyon.kl.classroom.service.SettingService
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.jdbc.core.JdbcTemplate
import spock.lang.Unroll

@AutoConfigureJsonTesters
class SettingControllerIntegrationSpec  extends BaseRestSpec{
	
	@Autowired
	SettingService settingService
	
	@Autowired
	SettingRepo settingRepo
	
	@Autowired
	BaseMapper mapper
		
	@Autowired
	JdbcTemplate jdbcTemplate
	
	
	Organization school1, school2, schoolOverrideFalse, campus1, campus2
	Setting school1Setting, globalSetting, class1Setting, schoolOverrideFalseSetting
	User userBelongingToSchool1, userBelongingToSchool2, userBelongingToSchoolOverrideFalse, admin
	ClassObj class1BelongingToSchool1
	Integer globalLessonThreshold = 70, globalLessonAttempt = 2, globalProjectThreshold = 70, globalProjectAttempt = 2
	Map globalGradeDisplay = [percentage: true, letter: false]
	Map globalGradeScale = [A:90,B:80,C:70,D:60]
	boolean globalThreshold = true

	def setup() {
		school1 = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'school1', created: new Date(), updated: new Date()))
		school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'school2', created: new Date(), updated: new Date()))
		campus1 = organizationRepo.save(new Organization(name: 'Campus 1', type: OrganizationType.CAMPUS, parent: school1, originationId: 'test', created: new Date(), updated: new Date()))
		campus2 = organizationRepo.save(new Organization(name: 'Campus 1', type: OrganizationType.CAMPUS, parent: school2, originationId: 'test', created: new Date(), updated: new Date()))
		schoolOverrideFalse = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'school2', created: new Date(), updated: new Date()))
		
		userBelongingToSchool1 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1, campus1]))
		userBelongingToSchool2 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school2, campus2]))
		userBelongingToSchoolOverrideFalse = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [schoolOverrideFalse]))
		admin =  new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, organizations: [school1, schoolOverrideFalse], originationId: 'SHARD 1', updated: new Date(), created: new Date())
		
		// create a school1 setting
		def schoolSettingValue = [admin: [override: true], classroom: [lessons: [threshold: 50, attempts: 1],	projects: [threshold: 50, attempts: 1],grade_display: [percentage: true, letter: false], grade_scale: [A:90,B:80,C:70,D:60]]]
		school1Setting = settingRepo.save(new Setting(sourceUUID: school1.uuid, value: schoolSettingValue, type: SettingType.ORG, version: 0) )

		// create a schoolOverrideFalse setting with override = false
		def schoolOverrideFalseSettingValue = [admin: [override: false], classroom: [lessons: [threshold: 50, attempts: 1],	projects: [threshold: 50, attempts: 1],grade_display: [percentage: true, letter: false], grade_scale: [A:90,B:80,C:70,D:60]]]
		schoolOverrideFalseSetting = settingRepo.save(new Setting(sourceUUID: schoolOverrideFalse.uuid, value: schoolOverrideFalseSettingValue, type: SettingType.ORG, version: 0) )
				
		// create a global setting
		def globalSettingValue = [admin: [override: globalThreshold], classroom: [lessons: [threshold: globalLessonThreshold, attempts: globalLessonAttempt],	projects: [threshold: globalProjectThreshold, attempts: globalProjectAttempt], grade_display:  globalGradeDisplay, grade_scale: globalGradeScale]]
		globalSetting = settingRepo.save(new Setting(sourceUUID: null, value: globalSettingValue, type: SettingType.GLOBAL, version: 0) )
		
		// create a class1 and class1 setting belonging to school1
		class1BelongingToSchool1 = setupValidClass(userBelongingToSchool1, campus1, null)
		Setting class1Setting = settingRepo.save(new Setting(sourceUUID: class1BelongingToSchool1.uuid, value: [admin: [override: true], classroom: [lessons: [threshold: 50, attempts: 1],	projects: [threshold: 50, attempts: 1]]], type: SettingType.CLASS, version: 0) )

		// create an enrollment
		createEnrollment(class1BelongingToSchool1, userBelongingToSchool1, Role.ADMINISTRATOR )
	}
	
	
	def "GET SETTING - should fail - user belongs to school1 but the request is for a school2 setting"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool1, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school2.uuid, HttpMethod.GET, req, Map)
		then:
			response.statusCode == HttpStatus.UNAUTHORIZED
	}
	
	def "GET SETTING - should pass - return the ORG setting for school1"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool1, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.GET, req, Map)
		then:
			response.statusCode == HttpStatus.OK
			response.body.value.classroom.lessons.attempts == 1
			response.body.value.classroom.lessons.threshold == 50
			response.body.type == SettingType.ORG.toString()
	}
	
	def "GET SETTING - should pass - return the GLOBAL setting since there is not explicit ORG setting for school2"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool2, school2.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school2.uuid, HttpMethod.GET, req, Map)
		then:
			response.statusCode == HttpStatus.OK
			response.body.value.classroom.lessons.attempts == 2
			response.body.value.classroom.lessons.threshold == 70
			response.body.value.classroom.grade_display.percentage == true
			response.body.value.classroom.grade_display.letter == false
			response.body.value.classroom.grade_scale.A == 90
			response.body.value.classroom.grade_scale.B == 80
			response.body.value.classroom.grade_scale.C == 70
			response.body.value.classroom.grade_scale.D == 60
			response.body.type == SettingType.GLOBAL.toString()
	}


	@Unroll
	def "should verify class settings error conditions"(){
		given:
		ClassObj class1 = setupValidClass(userBelongingToSchool1, campus1)
		ClassObj class2 = setupValidClass(userBelongingToSchool2, campus2)

		User user = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: type, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))

		Map<String, UUID> orgUuidMap = [
		        school1  : school1.uuid,
				school2 : school2.uuid,
				random : UUID.randomUUID()
		]

		Map<String, UUID> classUuidMap = [
		        class1: class1.uuid,
				class2: class2.uuid,
				random : UUID.randomUUID()
		]

		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(user, school1.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity response = testRestTemplate.exchange("/settings/orgs/${orgUuidMap[org]}/classes/${classUuidMap[clazz]}", HttpMethod.GET, req, Map)

		then:
		response.statusCode == expectedResponse

		where:
		type                | org        | clazz    || expectedResponse
		AppUserType.ADMIN   | 'random'   | 'random' || HttpStatus.NOT_FOUND
		AppUserType.ADMIN   | 'random'   | 'class1' || HttpStatus.NOT_FOUND
		AppUserType.ADMIN   | 'school1'  | 'random' || HttpStatus.NOT_FOUND
		AppUserType.ADMIN   | 'school1'  | 'class2' || HttpStatus.FORBIDDEN
		AppUserType.ADMIN   | 'school2'  | 'class1' || HttpStatus.FORBIDDEN
		AppUserType.ADMIN   | 'school2'  | 'class2' || HttpStatus.FORBIDDEN
		AppUserType.TEACHER | 'school1'  | 'class1' || HttpStatus.FORBIDDEN
		AppUserType.STUDENT | 'school1'  | 'class1' || HttpStatus.FORBIDDEN

	}

	@Unroll
	def "should verify roles"(){
		given:
		ClassObj class1 = setupValidClass(userBelongingToSchool1, school1)

		User user = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: type, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))

		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(user, school1.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity response = testRestTemplate.exchange("/settings/orgs/${school1.uuid}/classes/${class1.uuid}", HttpMethod.GET, req, Map)

		then:
		response.statusCode == HttpStatus.FORBIDDEN

		where:
		type << AppUserType.values().findAll{!(it in [AppUserType.ADMIN, AppUserType.TEACHER, AppUserType.STUDENT])}
	}


	@Unroll
	def "should get correct settings for class endpoint"(){
		given:
		ClassObj classObj = setupValidClass(userBelongingToSchool2, campus2)

		if(classSettings){
			def val = [
					admin: [override: true],
					classroom: [
							lessons: [
									threshold: 10,
									attempts: 5
							],
							projects: [
									threshold: 20,
									attempts: 15
							],
							grade_display: [
									percentage: true,
									letter: false
							],
							grade_scale: [
									A:88,
									B:77,
									C:66,
									D:55
							]
					]
			]
			settingRepo.save(new Setting(sourceUUID: classObj.uuid, value: val, type: SettingType.CLASS))
		}
		if(orgSettings){
			def val = [
					admin: [override: true],
					classroom: [
							lessons: [
									threshold: 50,
									attempts: 3
							],
							projects: [
									threshold: 60,
									attempts: 4
							],
							grade_display: [
									percentage: false,
									letter: true
							],
							grade_scale: [
									A:67,
									B:57,
									C:47,
									D:35
							]
					]
			]
			settingRepo.save(new Setting(sourceUUID: school2.uuid, value: val, type: SettingType.ORG))
		}

		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool2, school2.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		HttpEntity req = new HttpEntity(headers)


		when:
		HttpEntity response = testRestTemplate.exchange("/settings/orgs/${school2.uuid}/classes/${classObj.uuid}", HttpMethod.GET, req, Map)

		then:
		response.statusCode == HttpStatus.OK
		response.body.value.classroom.lessons.attempts == values[0]
		response.body.value.classroom.lessons.threshold == values[1]
		response.body.value.classroom.projects.attempts == values[2]
		response.body.value.classroom.projects.threshold == values[3]
		response.body.value.classroom.grade_display.percentage == expected_grade_display.percentage
		response.body.value.classroom.grade_display.letter == expected_grade_display.letter
		response.body.value.classroom.grade_scale == expected_grade_scale
		response.body.type as SettingType == expectedType

		where:
		classSettings | orgSettings    || expectedType       | values               | expected_grade_display            | expected_grade_scale
		false         | false          || SettingType.GLOBAL | [2, 70, 2, 70]       | [percentage: true,letter: false]  | [A:90,B:80,C:70,D:60]
		false         | true           || SettingType.ORG    | [3, 50, 4, 60]       | [percentage: false, letter:true]  | [A:67, B:57, C:47, D:35]
		true          | false          || SettingType.CLASS  | [5, 10, 15, 20]      | [percentage: true,letter: false]  | [A:88, B:77, C:66, D:55]
		true          | true           || SettingType.CLASS  | [5, 10, 15, 20]      | [percentage: true,letter: false]  | [A:88, B:77, C:66, D:55]
	}
	
	
	@Unroll
	def "PUT ORG SETTING - test all roles"(){
		given:
			User person =  new User(firstName: 'test', lastName: 'test', userName: 'test', type: role, status: AppUserStatus.ACTIVE, organizations: [school1], originationId: 'SHARD 1', updated: new Date(), created: new Date())
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(person, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [  "override": true ], "classroom": [ "lessons": [ "attempts": 5, "threshold": 70 ], "projects": [ "attempts": 4, "threshold": 90 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == statusCode
			if( statusCode ==HttpStatus.BAD_REQUEST ){
				assert response.body.errors[0].message == env.getProperty("input.role.notallowed.admin")
			}
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT      			|	HttpStatus.FORBIDDEN
			AppUserType.STUDENT      			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM      		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.TEACHER					|	HttpStatus.FORBIDDEN
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
	
	def "PUT ORG SETTING - should fail - user belongs to school1 but the request is for a school2 setting"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool1, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [  "override": true ], "classroom": [ "lessons": [ "attempts": 5, "threshold": 70 ], "projects": [ "attempts": 4, "threshold": 90 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school2.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == HttpStatus.UNAUTHORIZED
			assert response.body.errors[0].message == super.getMessage("setting.organization.invalid", [school2.uuid.toString(), school1.uuid.toString()])
	}
	
	
	def "PUT ORG SETTING - should fail - missing required input fields: override, lesson.attempts, lesson.threshold, project.attempts, project.threshold"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [ "override": null ], "classroom": [ "lessons": [ "attempts": null, "threshold": null ], "projects": [ "attempts": null, "threshold": null ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == HttpStatus.BAD_REQUEST
			String result = response.body
			assert result.contains("projects.attempts")
			assert result.contains("projects.attempts")
			assert result.contains("lessons.threshold")
			assert result.contains("lessons.attempts")
			assert result.contains("admin.override")
			assert result.contains( env.getProperty("input.field.required") )
	}
	
	
	@Unroll
	def "PUT ORG SETTING - validate range of numeric input fields: lesson.attempts, lesson.threshold, project.attempts, project.threshold"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [  "admin": [ "override": true ], "classroom": [ "lessons": [ "attempts": lessonAttemptValue, "threshold": lessonThresholdValue ], "projects": [ "attempts": projectAttemptValue, "threshold": projectThresholdValue ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == result
			if( result == HttpStatus.BAD_REQUEST ){
				String message
				if( acceptableLimit == 0 ){
					message = env.getProperty("input.integer.min")
				}
				if( acceptableLimit == 100 ){
					message = env.getProperty("input.integer.max")
				}
				message = message.replace("{value}", acceptableLimit.toString())
				assert response.body.errors[0].message == message
			}
		where:
			lessonAttemptValue 		|	lessonThresholdValue	| 	projectAttemptValue		|	projectThresholdValue		|	result					| 	acceptableLimit
			-1						|	0						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.ATTEMPT_LOWER_LIMIT
			0						|	-1						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_LOWER_LIMIT
			0						|	0						|		-1					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.ATTEMPT_LOWER_LIMIT
			0						|	0						|		0					|			-1					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_LOWER_LIMIT
			0						|	101						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_UPPER_LIMIT
			0						|	0						|		0					|			101					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_UPPER_LIMIT
			0						|	0						|		0					|			0					|	HttpStatus.OK			|	null
			100						|	100						|		100					|			100					|	HttpStatus.OK			|	null
			0						|	0						|		101					|			0					|	HttpStatus.OK			| 	null
			101						|	0						|		0					|			0					|	HttpStatus.OK			|	null
	}
		
	
	def "PUT ORG SETTING - should pass - create new ORG setting for 'newSchool'"(){
		given:
			Organization newSchool = organizationRepo.save(new Organization(name: 'School 3', type: OrganizationType.SCHOOL, originationId: 'school3', created: new Date(), updated: new Date()))
			User userBelongingToNewSchool = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [newSchool]))
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, newSchool.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [ "override": true ], "classroom": [ "lessons": [ "attempts": 2, "threshold": 50 ], "projects": [ "attempts": 3, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+newSchool.uuid, HttpMethod.PUT, req, Map)
			Setting newSchoolSettingFromDB = settingRepo.findBySourceUUIDAndType(newSchool.uuid, SettingType.ORG)
			SettingDTO settingDTO = new SettingDTO()
			settingDTO.value = (Value)mapper.defaultMapAll(newSchoolSettingFromDB.value, Value.class)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.value.admin.override == true && true == settingDTO.value.admin.override
			assert response.body.value.classroom.lessons.attempts == 2 && 2 == settingDTO.value.classroom.lessons.attempts
			assert response.body.value.classroom.lessons.threshold == 50 && 50 == settingDTO.value.classroom.lessons.threshold
			assert response.body.value.classroom.projects.attempts == 3 && 3 == settingDTO.value.classroom.projects.attempts
			assert response.body.value.classroom.projects.threshold == 60 && 60 == settingDTO.value.classroom.projects.threshold
	}
	
	
	def "PUT ORG SETTING - should pass - update existing ORG setting for 'school1'"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [ "override": true ], "classroom": [ "lessons": [ "attempts": 2, "threshold": 50 ], "projects": [ "attempts": 3, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.PUT, req, Map)
			Setting school1SettingFromDB = settingRepo.findBySourceUUIDAndType(school1.uuid, SettingType.ORG)
			SettingDTO settingDTO = new SettingDTO()
			settingDTO.value = (Value)mapper.defaultMapAll(school1SettingFromDB.value, Value.class)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.value.admin.override == true && true == settingDTO.value.admin.override
			assert response.body.value.classroom.lessons.attempts == 2 && 2 == settingDTO.value.classroom.lessons.attempts
			assert response.body.value.classroom.lessons.threshold == 50 && 50 == settingDTO.value.classroom.lessons.threshold
			assert response.body.value.classroom.projects.attempts == 3 && 3 == settingDTO.value.classroom.projects.attempts
			assert response.body.value.classroom.projects.threshold == 60 && 60 == settingDTO.value.classroom.projects.threshold
	}
	
	
	@Unroll
	def "PUT ORG SETTING - admin override"(){
		given:
			// create 2 class settings. both class settings are for a class belonging to school1
			ClassObj class1 = setupValidClass(userBelongingToSchool1, campus1, null)
			ClassObj class2 = setupValidClass(userBelongingToSchool1, campus1, null)
			def class1SettingValue = [admin: [override: false], classroom: [lessons: [threshold: 50, attempts: 1],	projects: [threshold: 50, attempts: 1]]]
			def class2SettingValue = [admin: [override: false], classroom: [lessons: [threshold: 70, attempts: 4],	projects: [threshold: 70, attempts: 4]]]
			Setting class1Setting = settingRepo.save(new Setting(sourceUUID: class1.uuid, value: class1SettingValue, type: SettingType.CLASS, version: 0) )
			Setting class2Setting = settingRepo.save(new Setting(sourceUUID: class2.uuid, value: class2SettingValue, type: SettingType.CLASS, version: 0) )

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "admin": [ "override": override ], "classroom": [ "lessons": [ "attempts": 2, "threshold": 50 ], "projects": [ "attempts": 3, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid, HttpMethod.PUT, req, Map)
			int inx = 0
			if( settingRepo.findBySourceUUIDAndType(class1.uuid, SettingType.CLASS) ){ inx++ }
			if( settingRepo.findBySourceUUIDAndType(class2.uuid, SettingType.CLASS) ){ inx++ }
		then:	
			assert response.statusCode == HttpStatus.OK	
			assert inx == classSettingQuantity
		where: 
			override	| classSettingQuantity
			true		| 2
			false		| 0
	}
	
	
	@Unroll
	def "PUT CLASS SETTING - test all roles"(){
		given:
			User person =  userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: role, status: AppUserStatus.ACTIVE, organizations: [school1], originationId: 'SHARD 1', updated: new Date(), created: new Date()))
			if( isEnrolled ){
				Enrollment enrollment = createEnrollment(class1BelongingToSchool1, person, Role.TEACHER)
			}	
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(person, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": 5, "threshold": 70 ], "projects": [ "attempts": 4, "threshold": 90 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == statusCode
			if(statusCode == HttpStatus.BAD_REQUEST){
				assert response.body.errors[0].message == env.getProperty("input.role.notallowed.teacheradmin")
			}
			if( role == AppUserType.TEACHER && statusCode == HttpStatus.FORBIDDEN){
				assert response.body.errors[0].message == super.getMessage("setting.teacher.not.enrolled")
			}
		where:
			role								| isEnrolled 	|	statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	| false			|	HttpStatus.FORBIDDEN
			AppUserType.PARENT      			| false			|	HttpStatus.FORBIDDEN
			AppUserType.STUDENT      			| false			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM      		| false			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		| false			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			| false			|	HttpStatus.FORBIDDEN
			AppUserType.ADMIN					| false			|	HttpStatus.OK
			AppUserType.TEACHER					| true			|	HttpStatus.OK
			AppUserType.TEACHER					| false			|	HttpStatus.FORBIDDEN
	}
	
	
	def "PUT CLASS SETTING - should fail - user belongs to school2 but the request is for a school1 setting"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool2, school2.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": 5, "threshold": 70 ], "projects": [ "attempts": 4, "threshold": 90 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == HttpStatus.UNAUTHORIZED
			assert response.body.errors[0].message == super.getMessage("setting.organization.invalid", [school1.uuid.toString(), school2.uuid.toString()])
	}
	
	
	def "PUT CLASS SETTING - should fail - missing required input fields: lesson.attempts, lesson.threshold, project.attempts, project.threshold"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": null, "threshold": null ], "projects": [ "attempts": null, "threshold": null ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == HttpStatus.BAD_REQUEST
			String result = response.body
			assert result.contains("projects.attempts")
			assert result.contains("projects.attempts")
			assert result.contains("lessons.threshold")
			assert result.contains("lessons.attempts")
			assert result.contains( env.getProperty("input.field.required") )
	}
	
	@Unroll
	def "PUT CLASS SETTING - validate range of numeric input fields: lesson.attempts, lesson.threshold, project.attempts, project.threshold"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": lessonAttemptValue, "threshold": lessonThresholdValue ], "projects": [ "attempts": projectAttemptValue, "threshold": projectThresholdValue ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == result
			if( result == HttpStatus.BAD_REQUEST ){
				String message
				if( acceptableLimit == 0 ){
					message = env.getProperty("input.integer.min")
				}
				if( acceptableLimit == 100 ){
					message = env.getProperty("input.integer.max")
				}
				message = message.replace("{value}", acceptableLimit.toString())
				assert response.body.errors[0].message == message
			}
		where:
			lessonAttemptValue 		|	lessonThresholdValue	| 	projectAttemptValue		|	projectThresholdValue		|	result					| 	acceptableLimit
			-1						|	0						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.ATTEMPT_LOWER_LIMIT
			0						|	-1						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_LOWER_LIMIT
			0						|	0						|		-1					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.ATTEMPT_LOWER_LIMIT
			0						|	0						|		0					|			-1					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_LOWER_LIMIT
			0						|	101						|		0					|			0					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_UPPER_LIMIT
			0						|	0						|		0					|			101					|	HttpStatus.BAD_REQUEST	|	SettingDTO.THRESHOLD_UPPER_LIMIT
			0						|	0						|		0					|			0					|	HttpStatus.OK			|	null
			100						|	100						|		100					|			100					|	HttpStatus.OK			|	null
			0						|	0						|		101					|			0					|	HttpStatus.OK			| 	null
			101						|	0						|		0					|			0					|	HttpStatus.OK			|	null
	}


	def "PUT CLASS SETTING - should pass - create new CLASS setting for 'newClass'"(){
		given:
			ClassObj newClass = setupValidClass(userBelongingToSchool1, school1, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": 2, "threshold": 50 ], "projects": [ "attempts": 3, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+newClass.uuid, HttpMethod.PUT, req, Map)
			Setting newClassSettingFromDB = settingRepo.findBySourceUUIDAndType(newClass.uuid, SettingType.CLASS)
			SettingDTO settingDTO = new SettingDTO()
			settingDTO.value = (Value)mapper.defaultMapAll(newClassSettingFromDB.value, Value.class)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.value.admin.override == true && true == settingDTO.value.admin.override
			assert response.body.value.classroom.lessons.attempts == 2 && 2 == settingDTO.value.classroom.lessons.attempts
			assert response.body.value.classroom.lessons.threshold == 50 && 50 == settingDTO.value.classroom.lessons.threshold
			assert response.body.value.classroom.projects.attempts == 3 && 3 == settingDTO.value.classroom.projects.attempts
			assert response.body.value.classroom.projects.threshold == 60 && 60 == settingDTO.value.classroom.projects.threshold
	}
	
	
	def "PUT CLASS SETTING - should pass - update existing CLASS setting for 'class1BelongingToSchool1'"(){
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": 2, "threshold": 60 ], "projects": [ "attempts": 2, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
			Setting class1SettingFromDB = settingRepo.findBySourceUUIDAndType(class1BelongingToSchool1.uuid, SettingType.CLASS)
			SettingDTO settingDTO = new SettingDTO()
			settingDTO.value = (Value)mapper.defaultMapAll(class1SettingFromDB.value, Value.class)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.value.admin.override == true && true == settingDTO.value.admin.override
			assert response.body.value.classroom.lessons.attempts == 2 && 2 == settingDTO.value.classroom.lessons.attempts
			assert response.body.value.classroom.lessons.threshold == 60 && 60 == settingDTO.value.classroom.lessons.threshold
			assert response.body.value.classroom.projects.attempts == 2 && 2 == settingDTO.value.classroom.projects.attempts
			assert response.body.value.classroom.projects.threshold == 60 && 60 == settingDTO.value.classroom.projects.threshold
	}
	
	
	def "PUT CLASS SETTING - should fail - school's (organization) admin.override is false"(){
		given:
			ClassObj classForSchoolOverrideFalse = setupValidClass(userBelongingToSchoolOverrideFalse, schoolOverrideFalse, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin, schoolOverrideFalse.uuid)}")
			headers.setAccept([Constants.SETTING_VERSION_1_MT])
			headers.setContentType([Constants.SETTING_VERSION_1_MT])
			def body =  ["value": [ "classroom": [ "lessons": [ "attempts": 2, "threshold": 50 ], "projects": [ "attempts": 3, "threshold": 60 ] ] ] ]
			HttpEntity req = new HttpEntity(body, headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+schoolOverrideFalse.uuid+"/classes/"+classForSchoolOverrideFalse.uuid, HttpMethod.PUT, req, Map)
		then:
			assert response.statusCode == HttpStatus.NOT_ACCEPTABLE
			assert response.body.errors[0].message == super.getMessage("setting.school.override.false")
	}
	
	
	@Unroll
	def "GET ORG and CLASS SETTINGS - test all roles"(){
		given:
			User person =  new User(firstName: 'test', lastName: 'test', userName: 'test', type: role, status: AppUserStatus.ACTIVE, organizations: [school1], originationId: 'SHARD 1', updated: new Date(), created: new Date())
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(person, school1.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/"+person.uuid, HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == statusCode
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT      			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM      		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.STUDENT      			|	HttpStatus.OK
			AppUserType.TEACHER					|	HttpStatus.OK
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
	
	def "GET ORG and CLASS SETTINGS - should fail - user uuid in request does not match user uuid in token"(){
		given:
			User person =  new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, organizations: [school1], originationId: 'SHARD 1', updated: new Date(), created: new Date())
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(person, school1.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/ae3b1bb7-b937-4c75-a359-956f6c51cf37", HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == HttpStatus.UNAUTHORIZED

	}
	
	
	def "GET ORG and CLASS SETTINGS - should pass - return settings for all schools and for all classes"(){
		given:
			Organization school4 = organizationRepo.save(new Organization(name: 'School 4', type: OrganizationType.SCHOOL, originationId: 'school4', created: new Date(), updated: new Date()))
			Organization school5 = organizationRepo.save(new Organization(name: 'School 5', type: OrganizationType.SCHOOL, originationId: 'school5', created: new Date(), updated: new Date()))
			User student =  userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, organizations: [school4, school5], originationId: 'SHARD 1', updated: new Date(), created: new Date()))
			
			// create 2 classes for each school - class4a and class 4b belong to school4. class 5a and 5b belong to school5
			ClassObj class4a = setupValidClass(student, school4, null)
			ClassObj class4b = setupValidClass(student, school4, null)
			ClassObj class5a = setupValidClass(student, school5, null)
			ClassObj class5b = setupValidClass(student, school5, null)

			// create enrollments
			createEnrollment(class4a, student, Role.STUDENT )
			createEnrollment(class4b, student, Role.STUDENT )
			createEnrollment(class5a, student, Role.STUDENT )
			createEnrollment(class5b, student, Role.STUDENT )
			
			Integer school4Threshold = 20, school4Attempt = 8, school5Threshold = 30, school5Attempt = 9, class4aThreshold = 66, class4aAttempt = 2, class4bThreshold = 77, class4bAttempt = 3, class5aThreshold = 88, class5aAttempt = 3, class5bThreshold = 99, class5bAttempt = 4

		    Map school4GradeScale =  [A:99,B:55,C:7,D:1]
		    Map school5GradeScale =  [A:90,B:80,C:70,D:60]
		    Map class4aGradeScale =  [A:55,B:66,C:77,D:88]
			Map class4bGradeScale =  [A:44,B:55,C:66,D:77]
			Map class5aGradeScale =  [A:10,B:8,C:7,D:5]
			Map class5bGradeScale =  [A:90,B:50,C:40,D:30]
			Map school4GradeDisplay = [letter: false, percentage: true]
			Map school5GradeDisplay = [letter: false, percentage: true]
			Map class4aGradeDisplay = [letter: false, percentage: true]
			Map class4bGradeDisplay = [letter: true, percentage: false]
			Map class5aGradeDisplay = [letter: false, percentage: true]
			Map class5bGradeDisplay = [letter: true, percentage: false]

		    boolean override = true
			
			// create school4 and school5 setting
			def school4SettingValue = [admin: [override: override], classroom: [lessons: [threshold: school4Threshold, attempts: school4Attempt],	projects: [threshold: school4Threshold, attempts: school4Attempt], grade_display: school4GradeDisplay,grade_scale: school4GradeScale]]
			settingRepo.save(new Setting(sourceUUID: school4.uuid, value: school4SettingValue, type: SettingType.ORG, version: 0) )
			def school5SettingValue = [admin: [override: override], classroom: [lessons: [threshold: school5Threshold, attempts: school5Attempt],	projects: [threshold: school5Threshold, attempts: school5Attempt], grade_display: school5GradeDisplay,grade_scale: school5GradeScale]]
			settingRepo.save(new Setting(sourceUUID: school5.uuid, value: school5SettingValue, type: SettingType.ORG, version: 0) )
						
			// create class4a class4b, class5a and class5b settings
			def class4aSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class4aThreshold, attempts: class4aAttempt],	projects: [threshold: class4aThreshold, attempts: class4aAttempt], grade_display: class4aGradeDisplay,grade_scale: class4aGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class4a.uuid, value: class4aSettingValue, type: SettingType.CLASS, version: 0) )
			def class4bSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class4bThreshold, attempts: class4bAttempt],	projects: [threshold: class4bThreshold, attempts: class4bAttempt], grade_display: class4bGradeDisplay,grade_scale: class4bGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class4b.uuid, value: class4bSettingValue, type: SettingType.CLASS, version: 0) )
			def class5aSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class5aThreshold, attempts: class5aAttempt],	projects: [threshold: class5aThreshold, attempts: class5aAttempt], grade_display: class5aGradeDisplay,grade_scale: class5aGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class5a.uuid, value: class5aSettingValue, type: SettingType.CLASS, version: 0) )
			def class5bSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class5bThreshold, attempts: class5bAttempt],	projects: [threshold: class5bThreshold, attempts: class5bAttempt], grade_display: class5bGradeDisplay,grade_scale: class5bGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class5b.uuid, value: class5bSettingValue, type: SettingType.CLASS, version: 0) )

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(student, school4.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/"+student.uuid, HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == HttpStatus.OK

			// there should be 2 schools returned
			assert response.body.orgs.size() == 2
			for( int inx = 0; inx < 2; inx++ ){
				
				List classes = response.body.orgs[inx].classes
				if( classes.contains(class4a.uuid.toString()) || classes.contains(class4b.uuid.toString()) ){

					assert classes.contains(class4a.uuid.toString()) && classes.contains(class4b.uuid.toString())
					
					// school4 setting
					assert response.body.orgs[inx].org_uuid == school4.uuid.toString()
					assert response.body.orgs[inx].org_settings.source_uuid == school4.uuid.toString()
					assert response.body.orgs[inx].org_settings.value.classroom.lessons.attempts == school4Attempt
					assert response.body.orgs[inx].org_settings.value.classroom.lessons.threshold == school4Threshold
					assert response.body.orgs[inx].org_settings.value.classroom.projects.attempts == school4Attempt
					assert response.body.orgs[inx].org_settings.value.classroom.projects.threshold == school4Threshold
					assert response.body.orgs[inx].org_settings.value.classroom.grade_scale == school4GradeScale
					assert response.body.orgs[inx].org_settings.value.classroom.grade_display == school4GradeDisplay
					assert response.body.orgs[inx].org_settings.value.admin.override == override
					
					// class settings for school4
					// there should be 2 classes returned
					assert response.body.orgs[inx].class_settings.size() == 2
					for( int jnx = 0 ; jnx < 2; jnx++ ){
						if( response.body.orgs[inx].class_settings[jnx].source_uuid == class4a.uuid.toString() ){
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.attempts == class4aAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.threshold == class4aThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.attempts == class4aAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.threshold == class4aThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_scale == class4aGradeScale
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_display == class4aGradeDisplay
							assert response.body.orgs[inx].class_settings[jnx].value.admin.override == override
						}
						else if (response.body.orgs[inx].class_settings[jnx].source_uuid == class4b.uuid.toString()){
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.attempts == class4bAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.threshold == class4bThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.attempts == class4bAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.threshold == class4bThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_scale == class4bGradeScale
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_display == class4bGradeDisplay
							assert response.body.orgs[inx].class_settings[jnx].value.admin.override == override
						}
						else{
							assert false
						}
					}
				}
				else if( classes.contains(class5a.uuid.toString()) || classes.contains(class5b.uuid.toString()) ){

					assert classes.contains(class5a.uuid.toString()) && classes.contains(class5b.uuid.toString())
					
					// school5 setting
					assert response.body.orgs[inx].org_uuid == school5.uuid.toString()
					assert response.body.orgs[inx].org_settings.source_uuid == school5.uuid.toString()
					assert response.body.orgs[inx].org_settings.value.classroom.lessons.attempts == school5Attempt
					assert response.body.orgs[inx].org_settings.value.classroom.lessons.threshold == school5Threshold
					assert response.body.orgs[inx].org_settings.value.classroom.projects.attempts == school5Attempt
					assert response.body.orgs[inx].org_settings.value.classroom.projects.threshold == school5Threshold
					assert response.body.orgs[inx].org_settings.value.classroom.grade_scale == school5GradeScale
					assert response.body.orgs[inx].org_settings.value.classroom.grade_display == school5GradeDisplay
					assert response.body.orgs[inx].org_settings.value.admin.override == override
										
					// class settings for school5
					// there should be 2 classes returned
					assert response.body.orgs[inx].class_settings.size() == 2
					for( int jnx = 0 ; jnx < 2; jnx++ ){
						if( response.body.orgs[inx].class_settings[jnx].source_uuid == class5a.uuid.toString() ){
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.attempts == class5aAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.threshold == class5aThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.attempts == class5aAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.threshold == class5aThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_scale == class5aGradeScale
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_display == class5aGradeDisplay
							assert response.body.orgs[inx].class_settings[jnx].value.admin.override == override
						}
						else if (response.body.orgs[inx].class_settings[jnx].source_uuid == class5b.uuid.toString()){
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.attempts == class5bAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.lessons.threshold == class5bThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.attempts == class5bAttempt
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.projects.threshold == class5bThreshold
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_scale == class5bGradeScale
							assert response.body.orgs[inx].class_settings[jnx].value.classroom.grade_display == class5bGradeDisplay
							assert response.body.orgs[inx].class_settings[jnx].value.admin.override == override
						}
						else{
							assert false
						}
					}
				}
				else{
					assert false
				}
			}
	}
	
	
	def "GET ORG and CLASS SETTINGS - should pass - return settings for classes that are not soft deleted"(){
		given:
			configurationRepo.save(new Configuration("key": Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY, "value":"24", "description":"duration"))
			
			Organization school4 = organizationRepo.save(new Organization(name: 'School 4', type: OrganizationType.SCHOOL, originationId: 'school4', created: new Date(), updated: new Date()))
			User student =  userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, organizations: [school4], originationId: 'SHARD 1', updated: new Date(), created: new Date()))
			
			// create 2 classes, class4a is not soft delete. class4b is soft deleted
			ClassObj class4a = setupValidClass(student, school4, null)
			ClassObj class4b = setupSoftDeletedClass(student, school4, null)
			
			// create enrollments
			createEnrollment(class4a, student, Role.STUDENT )
			createEnrollment(class4b, student, Role.STUDENT )
			
			Integer school4Threshold = 20, school4Attempt = 8, class4aThreshold = 66, class4aAttempt = 2, class4bThreshold = 77, class4bAttempt = 3
		    Map class4aGradeScale =  [A:50,B:60,C:70,D:80]
		    Map class4bGradeScale =  [A:44,B:55,C:66,D:77]
		    Map class4aGradeDisplay = [letter: false, percentage: true]
		    Map class4bGradeDisplay = [letter: true, percentage: false]
			boolean override = true 
			
			// create school4 setting
			def school4SettingValue = [admin: [override: true], classroom: [lessons: [threshold: school4Threshold, attempts: school4Attempt],	projects: [threshold: school4Threshold, attempts: school4Attempt], grade_display: [letter: true, percentage: false],grade_scale: [A:20,B:30,C:40,D:50]]]
			settingRepo.save(new Setting(sourceUUID: school4.uuid, value: school4SettingValue, type: SettingType.ORG, version: 0) )
						
			// create class4a class4b settings
			def class4aSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class4aThreshold, attempts: class4aAttempt],	projects: [threshold: class4aThreshold, attempts: class4aAttempt], grade_display: class4aGradeDisplay,grade_scale: class4aGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class4a.uuid, value: class4aSettingValue, type: SettingType.CLASS, version: 0) )
			def class4bSettingValue = [admin: [override: override], classroom: [lessons: [threshold: class4bThreshold, attempts: class4bAttempt],	projects: [threshold: class4bThreshold, attempts: class4bAttempt], grade_display: class4bGradeDisplay,grade_scale: class4bGradeScale]]
			settingRepo.save(new Setting(sourceUUID: class4b.uuid, value: class4bSettingValue, type: SettingType.CLASS, version: 0) )

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(student, school4.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/"+student.uuid+"?excludeExpiredClasses=true", HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			
			List classes = response.body.orgs[0].classes
			assert classes.contains(class4a.uuid.toString())
					
			// class4a settings but not class4b settings (since class4b was soft deleted)
			assert response.body.orgs[0].class_settings.size() == 1
			assert response.body.orgs[0].class_settings[0].value.classroom.lessons.attempts == class4aAttempt
			assert response.body.orgs[0].class_settings[0].value.classroom.lessons.threshold == class4aThreshold
			assert response.body.orgs[0].class_settings[0].value.classroom.projects.attempts == class4aAttempt
			assert response.body.orgs[0].class_settings[0].value.classroom.projects.threshold == class4aThreshold
			assert response.body.orgs[0].class_settings[0].value.classroom.grade_scale == class4aGradeScale
			assert response.body.orgs[0].class_settings[0].value.classroom.grade_display == class4aGradeDisplay
			assert response.body.orgs[0].class_settings[0].value.admin.override == override
	}
	
	
	def "GET ORG and CLASS SETTINGS - should pass - return global setting for org since there is no explicit org setting"(){
		given:
			Organization school4 = organizationRepo.save(new Organization(name: 'School 4', type: OrganizationType.SCHOOL, originationId: 'school4', created: new Date(), updated: new Date()))
			User student4 =  userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, organizations: [school4], originationId: 'SHARD 1', updated: new Date(), created: new Date()))
			ClassObj class4 = setupValidClass(student4, school4, null)
			Enrollment enrollment4 = createEnrollment(class4, student4, Role.STUDENT )
						
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(student4, school4.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/"+student4.uuid, HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.orgs[0].org_settings.source_uuid == null
			assert response.body.orgs[0].org_settings.value.classroom.lessons.attempts == globalLessonAttempt
			assert response.body.orgs[0].org_settings.value.classroom.lessons.threshold == globalLessonThreshold
			assert response.body.orgs[0].org_settings.value.classroom.projects.attempts == globalProjectAttempt
			assert response.body.orgs[0].org_settings.value.classroom.projects.threshold == globalProjectThreshold
			assert response.body.orgs[0].org_settings.value.classroom.grade_scale == globalGradeScale
			assert response.body.orgs[0].org_settings.value.classroom.grade_display == globalGradeDisplay
			assert response.body.orgs[0].org_settings.value.admin.override == globalThreshold
	}
	
	def "GET ORG and CLASS SETTINGS - should pass - student is enrolled in a campus so return the org setting for the parent school"(){
		given:
			Organization school4 = organizationRepo.save(new Organization(name: 'School 4', type: OrganizationType.SCHOOL, originationId: 'campus4', created: new Date(), updated: new Date()))
			Organization campus4 = organizationRepo.save(new Organization(name: 'Campus 4', type: OrganizationType.CAMPUS, originationId: 'campus4', created: new Date(), updated: new Date(), parent: school4))
			User student4 =  userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, organizations: [campus4], originationId: 'SHARD 1', updated: new Date(), created: new Date()))
			ClassObj class4 = setupValidClass(student4, campus4, null)
			Enrollment enrollment4 = createEnrollment(class4, student4, Role.STUDENT )
			
			// school4 setting
			Integer school4Threshold = 10, school4Attempt = 9
			Map school4GradeScale =  [A:44,B:55,C:66,D:77]
			Map school4GradeDisplay = [letter: false, percentage: true]
			boolean override = true
			def school4SettingValue = [admin: [override: override], classroom: [lessons: [threshold: school4Threshold, attempts: school4Attempt],	projects: [threshold: school4Threshold, attempts: school4Attempt], grade_scale:school4GradeScale ,grade_display:school4GradeDisplay ]]
			settingRepo.save(new Setting(sourceUUID: school4.uuid, value: school4SettingValue, type: SettingType.ORG, version: 0) )
						
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(student4, campus4.uuid)}")
			headers.setAccept([Constants.SETTING_ALL_CLASSES_VERSION_1_MT])
			HttpEntity req = new HttpEntity(headers)
		when:
			HttpEntity response = testRestTemplate.exchange("/settings/users/"+student4.uuid, HttpMethod.GET, req, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.orgs[0].org_settings.source_uuid == school4.uuid.toString()
			assert response.body.orgs[0].org_settings.value.classroom.lessons.attempts == school4Attempt
			assert response.body.orgs[0].org_settings.value.classroom.lessons.threshold == school4Threshold
			assert response.body.orgs[0].org_settings.value.classroom.projects.attempts == school4Attempt
			assert response.body.orgs[0].org_settings.value.classroom.projects.threshold == school4Threshold
			assert response.body.orgs[0].org_settings.value.classroom.grade_scale == school4GradeScale
			assert response.body.orgs[0].org_settings.value.classroom.grade_display == school4GradeDisplay
			assert response.body.orgs[0].org_settings.value.admin.override == override
	}


	@Unroll
	def "PUT endpoint (ORG and CLASS) should fail for incorrect value of grade scale and display"(){
		given:
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		headers.setContentType([Constants.SETTING_VERSION_1_MT])
		def body =  ["value": [ "admin": [ "override": true ],
								"classroom": [
										"lessons": ["attempts": 2, "threshold": 10],
				  						"projects": ["attempts": 1, "threshold": 79],
										"grade_display": grade_display,
										"grade_scale": grade_scale
								]
							]
					]
		HttpEntity req = new HttpEntity(body, headers)
		when:
		String classEndpoint = "/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid
		String schoolendpoint = "/settings/orgs/"+school1.uuid
		HttpEntity response = testRestTemplate.exchange(type == "org"? schoolendpoint : classEndpoint, HttpMethod.PUT, req, Map)
		then:
		response.statusCode == HttpStatus.BAD_REQUEST
		response.body.errors[0] == errorMessage

		where:
		type      | grade_display 					|  grade_scale  || errorMessage
		"org"     |	[percentage:true]				| [A:40]        || [field:"value.classroom.gradeDisplay.letter", message:"Missing required field."]
		"class"   |	[percentage:true]				| [A:40]        || [field:"value.classroom.gradeDisplay.letter", message:"Missing required field."]

		"org"     |	[letter:true]					| [A:40]        || [field:"value.classroom.gradeDisplay.percentage", message:"Missing required field."]
		"class"   |	[letter:true]					| [A:40]        || [field:"value.classroom.gradeDisplay.percentage", message:"Missing required field."]

		"org"     |	[percentage:null,letter:null]	| [A:40]        || [field:"value.classroom.gradeDisplay", message:"At least one value must be true."]
		"class"   |	[percentage:null,letter:null]	| [A:40]        || [field:"value.classroom.gradeDisplay", message:"At least one value must be true."]

		"org"     |	[percentage:false,letter:false]	| [A:40]        || [field:"value.classroom.gradeDisplay", message:"At least one value must be true."]
		"class"   |	[percentage:false,letter:false]	| [A:40]        || [field:"value.classroom.gradeDisplay", message:"At least one value must be true."]

		"org"     |	[percentage:true,letter:false]	| [A:40,B:40]   || [field:"value.classroom.gradeScale", message:"Input cannot have duplicate value."]
		"class"   |	[percentage:true,letter:false]	| [A:40,B:40]   || [field:"value.classroom.gradeScale", message:"Input cannot have duplicate value."]
	}

	def "PUT CLASS - update existing setting for grade display and scale"(){
		given:
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		headers.setContentType([Constants.SETTING_VERSION_1_MT])
		def input =  ["value": [ "classroom": [
											   "lessons": [ "attempts": 2, "threshold": 60 ],
											   "projects": [ "attempts": 2, "threshold": 60 ],
											   "grade_scale":["Awesome":90,"Good":80],
											   "grade_display": [percentage:false,letter:true]
											  ]
								]
					]
		HttpEntity req = new HttpEntity(input, headers)
		when:
		HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		Setting class1SettingFromDB = settingRepo.findBySourceUUIDAndType(class1BelongingToSchool1.uuid, SettingType.CLASS)
		SettingDTO settingDTO = new SettingDTO()
		settingDTO.value = (Value)mapper.defaultMapAll(class1SettingFromDB.value, Value.class)

		then:
		response.statusCode == HttpStatus.OK

		response.body.value.classroom.grade_display ==  input.value.classroom.grade_display
		settingDTO.value.classroom.gradeDisplay.percentage == input.value.classroom.grade_display.percentage
		settingDTO.value.classroom.gradeDisplay.letter == input.value.classroom.grade_display.letter


		response.body.value.classroom.grade_scale == input.value.classroom.grade_scale
		settingDTO.value.classroom.gradeScale.Awesome == input.value.classroom.grade_scale.Awesome
		settingDTO.value.classroom.gradeScale.Good == input.value.classroom.grade_scale.Good

	}

	def "PUT setting - grade scale with duplicate keys"(){
		given:
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(admin, school1.uuid)}")
		headers.setAccept([Constants.SETTING_VERSION_1_MT])
		headers.setContentType([Constants.SETTING_VERSION_1_MT])
		def input =  ["value": [ "classroom": [
				"lessons": [ "attempts": 2, "threshold": 60 ],
				"projects": [ "attempts": 2, "threshold": 60 ],
				"grade_scale":["Awesome":90,"Awesome":80],
				"grade_display": [percentage:false,letter:true]
		]
		]
		]
		HttpEntity req = new HttpEntity(input, headers)
		when:
		HttpEntity response = testRestTemplate.exchange("/settings/orgs/"+school1.uuid+"/classes/"+class1BelongingToSchool1.uuid, HttpMethod.PUT, req, Map)
		Setting class1SettingFromDB = settingRepo.findBySourceUUIDAndType(class1BelongingToSchool1.uuid, SettingType.CLASS)
		SettingDTO settingDTO = new SettingDTO()
		settingDTO.value = (Value)mapper.defaultMapAll(class1SettingFromDB.value, Value.class)

		then:
		response.statusCode == HttpStatus.OK

		response.body.value.classroom.grade_scale == [Awesome:  80] // if key duplicates then it is not error. last value is considered
		settingDTO.value.classroom.gradeScale  == [Awesome:  80] // last one overrides

	}
	
}