package com.glynlyon.kl.classroom.controllers

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.MediaType
import spock.lang.Unroll
import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptSave
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.AssignmentType

class PagePatchControllerIntegrationSpec  extends BaseRestSpec{
	
	@Autowired
	PageRepo pageRepo
	
	@Autowired
	OrganizationRepo organizationRepo
	
	@Autowired
	EnrollmentRepo enrollmentRepo
	
	User admin1, teacher1, teacher2, student1
	Organization school1, school2
	ClassObj classObjAdmin1, classObjTeacher1
	
	public static final String UUID = "90c5a70e-3186-4c73-b151-253c319cacc7"

	def setup(){
		admin1 = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))
		student1 = userRepo.save(new User(firstName: 'some', lastName: 's', userName: 'studnet', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))
		teacher1 = userRepo.save(new User(firstName: 'some', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))
		teacher2 = userRepo.save(new User(firstName: 'some', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school2]))
		school1 = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		
		classObjAdmin1 = setupValidClass(admin1, school1)
		classObjTeacher1 = setupValidClass(teacher1, school1)
		enrollmentRepo.save(new Enrollment(user: admin1, classObj: classObjAdmin1, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObjTeacher1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

	}
		
	
	@Unroll
	def "role based validation"(){
		given:
			PageObj page1 = setupValidPage("Page 1 Class 1", classObjAdmin1)

			admin1.type = role
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin1, school1.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = ["name":null]
			HttpEntity req = new HttpEntity(body, headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+page1.uuid.toString(), HttpMethod.PATCH, req, Map)

		then:
			assert resp.statusCode == status

	
		where:
			role								|			 status		
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN
			AppUserType.PARENT					|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN
			AppUserType.SUPPORT_CEM				|	HttpStatus.FORBIDDEN
			AppUserType.STUDENT					|	HttpStatus.FORBIDDEN
			AppUserType.TEACHER					|	HttpStatus.OK	
	}
	
	
	def "admin1 does not belong to school2 validation"(){
		given:
			ClassObj classObj = setupValidClass(admin1, school2)
			PageObj page1 = setupValidPage("Page 1 Class 1", classObj)

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin1, school2.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = ["name":null]
			HttpEntity req = new HttpEntity(body, headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+page1.uuid.toString(), HttpMethod.PATCH, req, Map)

		then:
			assert resp.statusCode == HttpStatus.UNAUTHORIZED
	}
	
	def "teacher2 does not belong to class validation"(){
		given:
			ClassObj classObj = setupValidClass(teacher1, school1)
			PageObj page1 = setupValidPage("Page 1 Class 1", classObj)

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(teacher2, school2.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = ["name":null]
			HttpEntity req = new HttpEntity(body, headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+page1.uuid.toString(), HttpMethod.PATCH, req, Map)

		then:
			assert resp.statusCode == HttpStatus.UNAUTHORIZED
	}
	
	def "page not found for the page uuid passed in"(){
		given:
			ClassObj classObj = setupValidClass(admin1, school1)
			PageObj page1 = setupValidPage("Page 1 Class 1", classObj)

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin1, school1.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = ["name":null]
			HttpEntity req = new HttpEntity(body, headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+UUID, HttpMethod.PATCH, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
	}
	
	@Unroll
	def "data validation failures"(){
		given:
			ClassObj classObj = setupValidClass(admin1, school1)
			PageObj page1 = setupValidPage("Page 1 Class 1", classObj)

			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(admin1, school1.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = json
			HttpEntity req = new HttpEntity(body, headers)

		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+page1.uuid.toString(), HttpMethod.PATCH, req, Map)

		then:
			assert resp.statusCode == HttpStatus.BAD_REQUEST
			assert resp.body.errors[0].message == message
		where:
			json														|			message
			["name":"alan", "status": "xxxx" ]							|	"Not a valid status."
			["name":"alan", "sequence": -1 ]							|	"The minimum value allowed is 1."
			["type": null ]												|	"Field cannot be null."
			["status": null ]											|	"Field cannot be null."
			["sequence": null ]											|	"Field cannot be null."
	}

	@Unroll
	def "update page as ADMIN"(){
		given:
			User userBelongingToSchool1 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school1]))
			ClassObj class1BelongingToSchool1 = setupValidClass(userBelongingToSchool1, school1, null)
			createEnrollment(class1BelongingToSchool1, userBelongingToSchool1, Role.ADMINISTRATOR )
			PageObj page1 = setupValidPage("page name", class1BelongingToSchool1)
			PageAssignment pageAssignment1 = setupValidPageAssignment("assignment1", page1, 1)
			PageAssignment pageAssignment2 = setupValidPageAssignment("assignment2", page1, 2)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(userBelongingToSchool1, school1.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.PAGES_VERSION_1)
			headers.add(HttpHeaders.ACCEPT, Constants.PAGES_VERSION_1)
			def body  = json
			HttpEntity req = new HttpEntity(body, headers)


		when:
			HttpEntity resp = testRestTemplate.exchange("/pages/"+page1.uuid.toString(), HttpMethod.PATCH, req, Map)

		then:
			PageObj page = pageRepo.findByUuid( page1.uuid)
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.name == name && page.name == name
			assert resp.body.status ==  status && page.status.name() == status
			assert resp.body.type == type && page.type == type
			assert resp.body.sequence == sequence && page.sequence == sequence
			assert resp.body.page_uuid == page1.uuid.toString()
			
			assert resp.body.class.name == "test class name"
			assert resp.body.class.class_uuid == class1BelongingToSchool1.uuid.toString()
			 
			assert resp.body.page_assignments[0].sequence == 1
			assert resp.body.page_assignments[0].page_assignment_uuid == pageAssignment1.uuid.toString()
			assert resp.body.page_assignments[0].assignment.assignment_uuid == pageAssignment1.assignment.uuid.toString()
			assert resp.body.page_assignments[0].assignment.assignment_type == AssignmentType.LESSON.name()
			assert resp.body.page_assignments[0].assignment.assignment_title == "assignment1"
			
			assert resp.body.page_assignments[1].sequence == 2
			assert resp.body.page_assignments[1].page_assignment_uuid == pageAssignment2.uuid.toString()
			assert resp.body.page_assignments[1].assignment.assignment_uuid == pageAssignment2.assignment.uuid.toString()
			assert resp.body.page_assignments[1].assignment.assignment_type ==AssignmentType.LESSON.name()
			assert resp.body.page_assignments[1].assignment.assignment_title =="assignment2"
			
			if( json_due_date != null){
				assert resp.body.due_date == json_due_date && page.dueDate.toString() == java_due_date
			}
			else{
				assert resp.body.due_date == json_due_date && page.dueDate == java_due_date
			}
			
			// if the status is 'COMPLETED' the completed_date is set by the business logic in the service layer
			if( status == "COMPLETED" ){
				assert resp.body.completed_date != null && page.completedDate != null
			}
			else if( json_completed_date != null ){
				assert resp.body.completed_date == json_completed_date && page.completedDate.toString() == java_completed_date
			}
			else{
				assert resp.body.completed_date == json_completed_date && page.completedDate == java_completed_date
			}	
			
		where:
			json 																																						| name 		| status		| type		| sequence		| json_completed_date				| java_completed_date			| json_due_date						| java_due_date
			["name":null]																																				| null		| 'ACTIVE'		| 'CONCEPT'	|	1			|	null						|	null						|	null						|	null		
			["name":"alan"]																																				| "alan"	| 'ACTIVE'		| 'CONCEPT'	|	1			|	null						|	null						|	null						|	null
			["name":"alan", "sequence": 2]																																| "alan"	| 'ACTIVE'		| 'CONCEPT'	|	2			|	null						|	null						|	null						|	null
			["name":"alan", "status": "COMPLETED"]																														| "alan"	| 'COMPLETED'	| 'CONCEPT'	|	1			|	null						|	null						|	null						|	null
			["name":"alan", "status": "ACTIVE", "type":"type1"]																											| "alan"	| 'ACTIVE'		| 'type1'	|	1			|	null						|	null						|	null						|	null
			["name":"alan", "status": "ACTIVE", "type":"type1", "completed_date":"2016-10-17T17:00:00-07:00"]															| "alan"	| 'ACTIVE'		| 'type1'	|	1			|	"2016-10-17T17:00:00-07:00"	|	"2016-10-17 17:00:00.0"		|	null						|	null
			["name":"alan", "status": "ACTIVE", "type":"type1", "due_date": "2016-10-17T17:00:00-07:00"]																| "alan"	| 'ACTIVE'		| 'type1'	|	1			|	null						|	null						|"2016-10-17T17:00:00-07:00"	| "2016-10-17 17:00:00.0"	
			["name":"alan", "status": "ACTIVE", "type":"type1", "sequence": 2, "due_date": "2016-10-17T17:00:00-07:00", "completed_date":"2016-10-17T17:00:00-07:00"]	| "alan"	| 'ACTIVE'		| 'type1'	|	2			|	"2016-10-17T17:00:00-07:00"	|	"2016-10-17 17:00:00.0"		|"2016-10-17T17:00:00-07:00"	| "2016-10-17 17:00:00.0"
	}

}
