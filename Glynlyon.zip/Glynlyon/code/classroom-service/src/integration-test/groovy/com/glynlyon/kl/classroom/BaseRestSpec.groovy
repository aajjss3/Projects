package com.glynlyon.kl.classroom

import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.AssignmentRepo
import com.glynlyon.kl.classroom.repo.AttemptOverridesHistoryRepo
import com.glynlyon.kl.classroom.repo.AttemptRepo
import com.glynlyon.kl.classroom.repo.AttemptSaveRepo
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.ConfigurationRepo
import com.glynlyon.kl.classroom.repo.CourseRepo
import com.glynlyon.kl.classroom.repo.DefaultSubjectRepo
import com.glynlyon.kl.classroom.repo.DisabledSubjectRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.EventRepo
import com.glynlyon.kl.classroom.repo.IssuerLaunchRepo
import com.glynlyon.kl.classroom.repo.LaunchRepo
import com.glynlyon.kl.classroom.repo.LockRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PageAssignmentRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.repo.PlannerEntryRepo
import com.glynlyon.kl.classroom.repo.SettingRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.SubjectsViewRepo
import com.glynlyon.kl.classroom.repo.SyncRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.MessagesUtil
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.context.MessageSource
import org.springframework.core.env.Environment
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import spock.lang.Specification

import java.nio.charset.StandardCharsets
import java.time.Instant

@SpringBootTest(classes = Application, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(["classpath:application-test.properties", "classpath:ValidationMessages.properties", "classpath:messages.properties"])
@ContextConfiguration
class BaseRestSpec extends Specification {

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    ClassGradeLevelRepo classGradeLevelRepo

    @Autowired
    AttemptRepo attemptRepo

    @Autowired
    ClassRepo classRepo

    @Autowired
    LaunchRepo launchRepo

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    PageRepo pageRepo

    @Autowired
    PageAssignmentRepo pageAssignmentRepo

    @Autowired
    CourseRepo courseRepo

    @Autowired
    DisabledSubjectRepo disabledSubjectRepo

    @Autowired
    DefaultSubjectRepo defaultSubjectRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    SettingRepo settingRepo

    @Autowired
    SyncRepo syncRepo
	
	@Autowired
	SubjectsViewRepo subjectsViewRepo

    @Autowired
    TestRestTemplate testRestTemplate

    @Autowired
    ClassGradeLevelService classGradeLevelService

    @Autowired
    SubjectsService subjectsService

    @Value('${jwt.secret.key}')
    String secretKey

    @Autowired
    PlannerEntryRepo plannerEntryRepo

    @Autowired
    AssignmentRepo assignmentRepo

    @Autowired
    MessagesUtil messagesUtil

    @Autowired
    LockRepo lockRepo

    @Autowired
    ConfigurationRepo configurationRepo
	
	@Autowired
	Environment env
	
	@Autowired
	protected MessageSource messageSource

    @Autowired
    AttemptSaveRepo attemptSaveRepo
	
	@Autowired
	AttemptOverridesHistoryRepo attemptOverridesHistoryRepo
	
	@Autowired
	EventRepo eventRepo

    @Autowired
    IssuerLaunchRepo issuerLaunchRepo
	
	protected final static int ATTEMPT_TIME_ON_TASK = 13

    public HttpRequest createRequest() {
        def token = createToken()
        return createRequest(token)
    }

    public HttpRequest createRequest(String token){
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        return new HttpRequest(token, new HttpEntity(headers))
    }

    public String createToken(User user, UUID orgUuid){
        def glCustomInfo = [
                "sub_display_name" : user.lastName + ", " + user.firstName,
                "role_in_issuer"  : user.type,
                "school_uuid": orgUuid,
                "datasource" : "test"
        ]

        return Jwts.builder().setExpiration(new Date().plus(1)).setSubject(user.uuid.toString()).claim("gl_custom", glCustomInfo).signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8)).compact()
    }

    public String createToken(){
        return Jwts.builder().setExpiration(new Date().plus(1)).setSubject("test").signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8)).compact()
    }

    class HttpRequest {
        public String token
        public HttpEntity entity

        public HttpRequest(String token, HttpEntity entity){
            this.token = token
            this.entity = entity
        }
    }

    def cleanup(){
        launchRepo.deleteAll()
        lockRepo.deleteAll()
        attemptSaveRepo.deleteAll()
        attemptRepo.deleteAll()
        classGradeLevelRepo.deleteAll()
        enrollmentRepo.deleteAll()
        plannerEntryRepo.deleteAll()
        pageAssignmentRepo.deleteAll()
        assignmentRepo.deleteAll()
        pageRepo.deleteAll()
        courseRepo.deleteAll()
        classRepo.deleteAll()
        academicSessionRepo.deleteAll()
        subjectRepo.deleteAll()
        disabledSubjectRepo.deleteAll()
        organizationRepo.deleteAll()
        defaultSubjectRepo.deleteAll()
        userRepo.deleteAll()
        syncRepo.deleteAll()
        settingRepo.deleteAll()
        configurationRepo.deleteAll()
		// clear out all records in the AttemptOverridesHistory table
		attemptOverridesHistoryRepo.deleteAll()
		eventRepo.deleteAll()
        issuerLaunchRepo.deleteAll()
    }

    ClassObj setupValidClass(User user, Organization org, AcademicSession academicSession = null) {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: org.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        if(!academicSession){
            academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid:org.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
        }

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: "test class name",
                subject: subjectsService.findOne(subject.uuid, org.uuid),
                organization: org,
                creatorUuid: user.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                done: false
        )
        classObj = classRepo.save(classObj)
        classGradeLevelService.save(classObj.uuid, [Grade.FOUR, Grade.THREE, Grade.EIGHT])

        return classObj
    }

    ClassObj setupSoftDeletedClass(User user, Organization org, AcademicSession academicSession = null){
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: org.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        if(!academicSession) {
            academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: org.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))
        }

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.COMPLETED,
                name: "test class name",
                subject: subjectsService.findOne(subject.uuid, org.uuid),
                organization: org,
                creatorUuid: user.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                completed: new Date()-2,
                done: false
        )
        classObj = classRepo.save(classObj)
        classGradeLevelService.save(classObj.uuid, [Grade.FOUR, Grade.THREE, Grade.EIGHT])

        return classObj
    }
	

	
	PageObj setupValidPage(String name = "test name", ClassObj classObj, Integer sequence = 1) {
		PageObj pageObj = new PageObj(
				classObj: classObj,
				sequence: sequence,
				name: name,
				type: 'CONCEPT',
				status: PageState.ACTIVE,
				createdAt: new Date(),
				updatedAt: new Date()
		)
		pageObj = pageRepo.save(pageObj)
		return pageObj
	}
	
	PageObj setupValidPageWithDueDate(String name = "test name", ClassObj classObj, Date dueDate) {
		PageObj pageObj = new PageObj(
				classObj: classObj,
				sequence: 1,
				name: name,
				type: 'CONCEPT',
				status: PageState.ACTIVE,
				createdAt: new Date(),
				updatedAt: new Date(),
				dueDate: dueDate
		)
		pageObj = pageRepo.save(pageObj)
		return pageObj
	}
	

    PageObj setupValidPage(String name = "test name", ClassObj classObj, Integer sequence = 1, String type) {
        PageObj pageObj = new PageObj(
                classObj: classObj,
                sequence: sequence,
                name: name,
                type: type,
                status: PageState.ACTIVE,
                createdAt: new Date(),
                updatedAt: new Date()
        )
        pageObj = pageRepo.save(pageObj)
        return pageObj
    }
	
	
	PageObj setupValidPage(String name = "test name", ClassObj classObj, Integer sequence = 1, PageState status) {
		PageObj pageObj = new PageObj(
				classObj: classObj,
				sequence: sequence,
				name: name,
				type: 'CONCEPT',
				status: status,
				createdAt: new Date(),
				updatedAt: new Date()
		)
		pageObj = pageRepo.save(pageObj)
		return pageObj
	}
	
    PageAssignment setupValidPageAssignment(String name = "test assignment", PageObj page, Integer sequence = 1, UUID assignmentUuid = null) {
        PageAssignment pageAssignment = new PageAssignment(
                pageObj: page,
                sequence: sequence,
                assignment: setupValidAssignment(name, assignmentUuid),
                createdAt: new Date(),
                updatedAt: new Date()
        )
        pageAssignment = pageAssignmentRepo.save(pageAssignment)
        return pageAssignment
    }

    Assignment setupValidAssignment(String name, UUID assignmentUuid = null){
        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: assignmentUuid ?: UUID.randomUUID(),
                type: AssignmentType.LESSON,
                title: name,
                created: new Date(),
                updated: new Date()
        ))
        return assignment
    }

    PlannerEntry setupPlannerEntry(Integer slot, PlannerEntryState state, ClassObj classObj, PageObj pageObj, PageAssignment pageAssignment,User student) {
        PlannerEntry plannerEntry = new PlannerEntry(
                slot: slot,
                status: state,
                classObj: classObj,
                pageObj: pageObj,
                activityId: pageAssignment.uuid,
                assignment: pageAssignment.assignment,
                user:student)
        plannerEntryRepo.save(plannerEntry)
        return plannerEntry
    }

    PlannerEntry setupPlannerEntryWithoutPA(Integer slot, PlannerEntryState state, ClassObj classObj, PageObj pageObj, User student) {
        PlannerEntry plannerEntry = new PlannerEntry(
                slot: slot,
                status: state,
                classObj: classObj,
                pageObj: pageObj,
                activityId: UUID.randomUUID(),
                assignment: setupValidAssignment("None", UUID.randomUUID()),
                user:student)
        plannerEntryRepo.save(plannerEntry)
        return plannerEntry
    }

    Attempt setupAttempt(PlannerEntry entry, User user, AttemptState state = AttemptState.SUBMITTED, Double assessmentScore = 1, HashMap<String, Boolean> overrides = null, Date completedAt = new Date(), Boolean creditBearing = true){
        return attemptRepo.save(
                new Attempt(
                        plannerEntry: entry,
                        user: user,
                        activityId: entry.activityId,
                        sectionCount: 4,
                        sectionTotalCount: 6,
                        questionCount: 7,
                        questionsAttemptedCount: 5,
                        questionsCorrectCount: 4,
                        questionsIncorrectCount: 3,
                        questionsNotScoredCount: 2,
                        state: state,
                        timeOnTaskSeconds: ATTEMPT_TIME_ON_TASK,
                        assessmentScore: assessmentScore,
                        includedManualGraded: true,
                        createdAt: new Date(),
                        updatedAt: new Date(),
                        responseOverrides: overrides,
                        completedAt: completedAt,
                        sectionItems: [
                                [
                                        "section_uuid": "80f51db3-23c7-4cd0-8817-9bcf6146374c",
                                        "section_sequence": 1,
                                        "items": [
                                                [
                                                        "item_uuid": "c7024f8e-3542-4ad3-abc3-1448c88e355c",
                                                        "item_sequence": 1
                                                ]
                                        ]
                                ]
                        ],
                        sectionsViewed: ["1", "2"],
                        creditBearing: creditBearing
                )
        )
    }

    public static cdate(Integer s){
        Instant now = Instant.now()
        return Date.from(now.plusSeconds(s))
    }

	Attempt setupAttemptByDate(PlannerEntry entry, User user, Date createdAt, AttemptState state = AttemptState.SUBMITTED, Double assessmentScore = 1, HashMap<String, Boolean> overrides = null, Date completedAt = new Date(), Boolean creditBearing = true){
		return attemptRepo.save(
				new Attempt(
						plannerEntry: entry,
						user: user,
						activityId: entry.activityId,
						sectionCount: 4,
						sectionTotalCount: 6,
						questionCount: 7,
						questionsAttemptedCount: 5,
						questionsCorrectCount: 4,
						questionsIncorrectCount: 3,
						questionsNotScoredCount: 2,
						state: state,
						timeOnTaskSeconds: ATTEMPT_TIME_ON_TASK,
						assessmentScore: assessmentScore,
						includedManualGraded: true,
						createdAt: createdAt,
						updatedAt: new Date(),
						responseOverrides: overrides,
						completedAt: completedAt,
						sectionItems: [
								[
										"section_uuid": "80f51db3-23c7-4cd0-8817-9bcf6146374c",
										"section_sequence": 1,
										"items": [
												[
														"item_uuid": "c7024f8e-3542-4ad3-abc3-1448c88e355c",
														"item_sequence": 1
												]
										]
								]
						],
						sectionsViewed: ["1", "2"],
						creditBearing: creditBearing
				)
		)
	}

    Enrollment createEnrollment(ClassObj classObj, User user, Role role){
        enrollmentRepo.save(new Enrollment(
                classObj: classObj,
                user: user,
                role: role,
                primaryRole: false,
                status: Status.ACTIVE,
                created: new Date(),
                updated: new Date()))
    }
	
	protected String getMessage( String message, List<String> values ){
		return messageSource.getMessage( message, values as String[], Locale.getDefault() )
	}
	
	protected String getMessage( String message ){
		return messageSource.getMessage( message, null, Locale.getDefault() )
	}
}