package com.glynlyon.kl.classroom.job

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.*
import com.glynlyon.kl.classroom.repo.PageRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.messaging.Message
import org.springframework.messaging.MessageHeaders
import org.springframework.messaging.support.GenericMessage

import java.text.SimpleDateFormat

class PageCompletionConsumerIntegrationSpec extends BaseRestSpec {

    @Autowired
    PageRepo pageRepo

    @Autowired
    PageCompletionConsumerJob pageCompletionJob

    User admin
    Organization school
    ClassObj classObj
    PageObj page1, page2

    def setup() {
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))

    }

    def "PageCompletionJMS consumer method should set page to complete"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        page1 = pageRepo.save(new PageObj(classObj: classObj, sequence: 1, name: "Page 1", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date() - 10, updatedAt: new Date() - 10))
        page2 = pageRepo.save(new PageObj(classObj: classObj, sequence: 2, name: "Page 2", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date() - 10, updatedAt: new Date() - 10))
        List<UUID> message = [page1.uuid, page2.uuid]

        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd")
        String currentDate = dateFormatter.format(new Date())

        when: "organization_uuid exists"
        pageCompletionJob.recieveMessage(message)
        PageObj completedPage1 = pageRepo.findByUuid(page1.uuid)
        PageObj completedPage2 = pageRepo.findByUuid(page2.uuid)

        then:
        assert completedPage1.status == PageState.COMPLETED
        assert completedPage2.status == PageState.COMPLETED
        assert completedPage1.completedDate.toString().contains(currentDate)
        assert completedPage2.completedDate.toString().contains(currentDate)
    }
}
