package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.Links
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

/**
 * Created by etatarzycki on 2/28/17.
 */
class UserControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    UserRepo userRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    SubjectsService subjectsService

    User teacher1
    User teacher2
    User teacher3
    User admin1
    User student1

    List<User> school1Students = []
    List<User> school1ArchivedStudents = []
    List<User> school2Students = []
    List<User> school2ArchivedStudents = []

    Organization campus1
    Organization campus2
    Organization school1
    Organization school2

    def setup() {
        school1 = new Organization(type: OrganizationType.SCHOOL, name: 'Humboldt', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school1)

        school2 = new Organization(type: OrganizationType.SCHOOL, name: 'Sacramento', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school2)

        campus1 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school1)
        organizationRepo.save(campus1)

        campus2 = new Organization(type: OrganizationType.CAMPUS, name: 'Fresno', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school2)
        organizationRepo.save(campus2)

        teacher1 = new User(userName: 'teacher', firstName: "test", lastName: "teacher", type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        teacher1.setOrganizations([school1].asList() + [campus1].asList())
        teacher2 = new User(userName: 'teacher2', firstName: "test", lastName: "teacher2", type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        teacher2.setOrganizations([school2].asList() + [campus2].asList())
        teacher3 = new User(userName: 'teacher3', firstName: "test", lastName: "teacher3", type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin1 = new User(userName: 'admin', firstName: "test", lastName: "admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin1.setOrganizations([school1].asList() + [campus1].asList())
        student1 = new User(userName: 'student', firstName: "test", lastName: "student", type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        student1.setOrganizations([school1].asList() + [campus1].asList())

        userRepo.save(teacher1)
        userRepo.save(teacher2)
        userRepo.save(teacher3)
        userRepo.save(admin1)
        userRepo.save(student1)

        (1..5).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school1].asList() + [campus1].asList())
            school1Students.add(student)
        }

        school1Students.each {
            userRepo.save(it)
        }

        (1..5).each {
            User student = new User(userName: "archivedStudent${it}", firstName: "test", lastName: "archivedStudent${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ARCHIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school1].asList() + [campus1].asList())
            school1ArchivedStudents.add(student)
        }

        school1ArchivedStudents.each {
            userRepo.save(it)
        }

        (1..5).each {
            User student = new User(userName: "school2Student${it}", firstName: "test", lastName: "school2Student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school2].asList() + [campus2].asList())
            school2Students.add(student)
        }

        school2Students.each {
            userRepo.save(it)
        }

        (1..5).each {
            User student = new User(userName: "school2ArchivedStudent${it}", firstName: "test", lastName: "school2ArchivedStudent${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ARCHIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school2].asList() + [campus2].asList())
            school2ArchivedStudents.add(student)
        }

        school2ArchivedStudents.each {
            userRepo.save(it)
        }

        school1.setUsers(school1Students.toSet() + school1ArchivedStudents.toSet() + [teacher1].toSet())
        school2.setUsers(school2Students.toSet() + school2ArchivedStudents.toSet() + [teacher2].toSet())

        organizationRepo.save(school1)
        organizationRepo.save(school2)
        campus1.setUsers(school1Students.toSet() + school1ArchivedStudents.toSet() + [teacher1].toSet())
        campus2.setUsers(school2Students.toSet() + school2ArchivedStudents.toSet() + [teacher2].toSet())

        organizationRepo.save(campus1)
        organizationRepo.save(campus2)

        ClassObj.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return classRepo.save(delegate)
        }
    }

    def cleanup() {

    }

    @Unroll
    def "happy path GET users for a school using embedded school uuid in token"(){

        def userMap = [student1: student1, teacher1: teacher1, teacher2: teacher2, unknown: UUID.randomUUID()]
        def schoolMap = [school1: school1.uuid, school2: school2.uuid, unknown: UUID.randomUUID()]
        //the GET should exclude ARCHIVE users and only those users in school1
        //the GET should exclude ARCHIVE users and only those users in school2
        def schoolUsers = [school1Users: school1.getUsers().findAll {it.status != AppUserStatus.ARCHIVE},
                           school2Users: school2.getUsers().findAll {it.status != AppUserStatus.ARCHIVE}]

        String token = createToken(userMap[user], schoolMap[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK){
            assert resp.body.users.size() == schoolUsers[expectedCollection].size()
            verifyUserCollectionResponse(resp.body.users, schoolUsers[expectedCollection])
        } else {
            assert resp.body.errors[0].field == null
            assert resp.body.errors[0].message == "'Not authorized to search users. Need valid user and school'"
        }

        where:
        user        | org        | expectedCollection | result
        "teacher1"  | "school1"  | "school1Users"     | HttpStatus.OK
        "teacher2"  | "school2"  | "school2Users"     | HttpStatus.OK
        "teacher2"  | "unknown"  | "school2Users"     | HttpStatus.BAD_REQUEST
        //unknown teacher test was causing createToken to thrown bad signature error
    }

    @Unroll
    def "test GET users for campus"(){

        def userMap = [student1: student1, teacher1: teacher1, teacher2: teacher2]
        def schoolMap = [school1: school1.uuid, school2: school2.uuid]
        def campusMap = [campus1: campus1.uuid, campus2: campus2.uuid, unknown: UUID.randomUUID(), invalid: 12345]
        def resultMap = [result1: [field: null, message: "'campus " + campusMap[campusOrg].toString() + " not found in school " + schoolMap[org].toString() + ".'"],
                         result2: [field: "organization_uuid", message: "invalid organization_uuid " + campusMap[campusOrg].toString()]]

        //the GET should exclude ARCHIVE users and only those users in campus1
        //the GET should exclude ARCHIVE users and only those users in campus2
        def campusUsers = [campus1Users: campus1.getUsers().findAll {it.status != AppUserStatus.ARCHIVE},
                           campus2Users: campus2.getUsers().findAll {it.status != AppUserStatus.ARCHIVE}]

        String token = createToken(userMap[user], schoolMap[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users?organization_uuid=${campusMap[campusOrg]}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK){
            assert resp.body.users.size() == campusUsers[expectedCollection].size()
            verifyUserCollectionResponse(resp.body.users, campusUsers[expectedCollection])
        } else {
            assert resp.body.errors[0].field == resultMap[errorResult].field
            assert resp.body.errors[0].message == resultMap[errorResult].message
        }

        where:
        user        | org        |   campusOrg        | expectedCollection | result                 | errorResult
        "teacher1"  | "school1"  |   "campus1"        | "campus1Users"     | HttpStatus.OK          |   ""
        "teacher2"  | "school2"  |   "campus2"        | "campus2Users"     | HttpStatus.OK          |   ""
        "teacher2"  | "school2"  |   "campus1"        | ""                 | HttpStatus.BAD_REQUEST |   "result1"
        "teacher2"  | "school2"  |   "unknown"        | ""                 | HttpStatus.BAD_REQUEST |   "result1"
        "teacher2"  | "school2"  |   "invalid"        | ""                 | HttpStatus.BAD_REQUEST |   "result2"
    }

    @Unroll
    def "test ADMIN vs TEACHER GET users"(){

        Organization school10 = new Organization(type: OrganizationType.SCHOOL, name: 'Humboldt', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school10)

        Organization campus10 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school10)
        organizationRepo.save(campus10)
        Organization campus11 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school10)
        organizationRepo.save(campus11)
        Organization campus12 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school10)
        organizationRepo.save(campus12)

        User teacher10 = new User(userName: 'teacher', firstName: "test", lastName: "teacher", type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        //teacher10 is a member of two of the three campuses - so we will test that he/she receives only those two campuses of students
        teacher10.setOrganizations([school10].asList() + [campus10].asList() + [campus11].asList())
        userRepo.save(teacher10)
        //admin10 is not a member of any campuses but will get all students back for entire school
        User admin10 = new User(userName: 'admin', firstName: "test", lastName: "admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin10.setOrganizations([school10].asList() + [campus10].asList() + [campus11].asList() + [campus12].asList())
        userRepo.save(admin10)

        List<User> school10Students = []
        List<User> campus10Students = []
        List<User> campus11Students = []
        List<User> campus12Students = []
        List<User> adminResult = []
        List<User> teacherResult = []

        //students 1 through 3 are campus10
        (1..3).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school10].asList() + [campus10].asList())
            campus10Students.add(student)
            school10Students.add(student)
        }
        //students 4 through 6 are campus11
        (4..6).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school10].asList() + [campus11].asList())
            campus11Students.add(student)
            school10Students.add(student)
        }
        //students 7 through 10 are campus12
        (7..10).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school10].asList() + [campus12].asList())
            campus12Students.add(student)
            school10Students.add(student)
        }

        school10Students.each {
            userRepo.save(it)
        }

        school10.setUsers(school10Students.toSet() + [admin10].toSet() + [teacher10].toSet())
        organizationRepo.save(school10)

        campus10.setUsers(campus10Students.toSet() + [admin10].toSet() + [teacher10].toSet())
        organizationRepo.save(campus10)

        campus11.setUsers(campus11Students.toSet() + [admin10].toSet() + [teacher10].toSet())
        organizationRepo.save(campus11)

        campus12.setUsers(campus12Students.toSet() + [admin10].toSet())
        organizationRepo.save(campus12)

        def userMap = [teacher10: teacher10, admin10: admin10]

        adminResult.addAll(school10Students)
        adminResult.add(teacher10)
        adminResult.add(admin10)

        teacherResult.addAll(campus10Students)
        teacherResult.addAll(campus11Students)
        teacherResult.add(teacher10)
        teacherResult.add(admin10)

        def resultUsers = [adminResult: adminResult,
                           teacherResult: teacherResult]

        String token = createToken(userMap[user], school10.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users?limit=20", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        assert resp.body.users.size() == resultUsers[expectedCollection].size()
        verifyUserCollectionResponse(resp.body.users, resultUsers[expectedCollection])

        where:
        user         | expectedCollection | result
        "teacher10"  | "teacherResult"    | HttpStatus.OK
        "admin10"    | "adminResult"      | HttpStatus.OK
    }
    
    @Unroll
    def "test classroom-ui URL"(){
        //https://rostering-service-dev.owteam.com/users?limit=50&offset=0&filter=role='STUDENT'%20and%20status='ACTIVE'&sort=last_name,first_name

        Organization school20 = new Organization(type: OrganizationType.SCHOOL, name: 'Humboldt', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school20)

        Organization campus20 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school20)
        organizationRepo.save(campus20)
        Organization campus21 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school20)
        organizationRepo.save(campus21)
        Organization campus22 = new Organization(type: OrganizationType.CAMPUS, name: 'Bakersfield', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school20)
        organizationRepo.save(campus22)

        User teacher20 = new User(userName: 'teacher', firstName: "test", lastName: "teacher", type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        //teacher20 is a member of two of the three campuses - so we will test that he/she receives only those two campuses of students
        teacher20.setOrganizations([school20].asList() + [campus20].asList() + [campus21].asList())
        userRepo.save(teacher20)
        //admin20 is not a member of any campuses but will get all students back for entire school
        User admin20 = new User(userName: 'admin', firstName: "test", lastName: "admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin20.setOrganizations([school20].asList() + [campus20].asList() + [campus21].asList() + [campus22].asList())
        userRepo.save(admin20)

        List<User> school20Students = []
        List<User> campus20Students = []
        List<User> campus21Students = []
        List<User> campus22Students = []

        List<User> teacherClass1Students = []
        List<User> adminClass1Students = []
        List<User> teacherClass2Students = [] 
        List<User> adminClass2Students = []
        List<User> teacherClass1Teachers = []
        List<User> adminClass1Teachers = []
        List<User> teacherClass2Teachers = []
        List<User> adminClass2Teachers = []

        //students 1 through 3 are campus20
        (1..3).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school20].asList() + [campus20].asList())
            campus20Students.add(student)
            school20Students.add(student)
        }
        //students 4 through 6 are campus21
        (4..6).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school20].asList() + [campus21].asList())
            campus21Students.add(student)
            school20Students.add(student)
        }
        //students 7 through 10 are campus22
        (7..10).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school20].asList() + [campus22].asList())
            campus22Students.add(student)
            school20Students.add(student)
        }

        school20Students.each {
            userRepo.save(it)
        }

        school20.setUsers(school20Students.toSet() + [admin20].toSet() + [teacher20].toSet())
        organizationRepo.save(school20)

        campus20.setUsers(campus20Students.toSet() + [admin20].toSet() + [teacher20].toSet())
        organizationRepo.save(campus20)

        campus21.setUsers(campus21Students.toSet() + [admin20].toSet() + [teacher20].toSet())
        organizationRepo.save(campus21)

        campus22.setUsers(campus22Students.toSet() + [admin20].toSet())
        organizationRepo.save(campus22)

        //setup a campus20 class with one teacher and one student enrolled.  Setup another class no enrollments
        ClassObj class1 = setupValidClass()
        class1.setCreatorUuid(teacher20.uuid)
        class1.setOrganization(campus20)
        classRepo.save(class1)

        ClassObj class2NoEnrollments = setupValidClass()
        class2NoEnrollments.setCreatorUuid(teacher20.uuid)
        class2NoEnrollments.setOrganization(campus20)
        classRepo.save(class2NoEnrollments)

        List<Enrollment> enrollments = []
        enrollments.add(enrollmentRepo.save(new Enrollment(user: teacher20, classObj: class1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE)))
        enrollments.add(enrollmentRepo.save(new Enrollment(user: campus20Students[0], classObj: class1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)))

        def userMap = [teacher20: teacher20, admin20: admin20]
        def classMap = [class1: class1.uuid.toString(), class2NoEnrollments: class2NoEnrollments.uuid.toString()]

        //class1 has one enrolled student so we exclude that kid.
        teacherClass1Students.add(campus20Students[1])
        teacherClass1Students.add(campus20Students[2])

        //class1 has one enrolled student so we exclude that kid.
        adminClass1Students.add(campus20Students[1])
        adminClass1Students.add(campus20Students[2])

        //class2 has no enrollments.  teacher will get all kids from campus20
        teacherClass2Students.addAll(campus20Students)

        //class2 has no enrollments.  admin gets all kids from from campus20
        adminClass2Students.addAll(campus20Students)

        //teacher is enrolled in class1 so no teachers to return
        //teacherClass1Teachers = []

        //teacher is enrolled in class1 so no teachers to return
        //adminClass1Teachers = []

        //no teacher enrolled in class2 = return teacher20
        teacherClass2Teachers.add(teacher20)

        //no teacher enrolled in class2 = return teacher20
        adminClass2Teachers.add(teacher20)

        def resultUsers = [teacherClass1Students: teacherClass1Students,
                           adminClass1Students:  adminClass1Students,
                           teacherClass2Students: teacherClass2Students,
                           adminClass2Students: adminClass2Students,
                           teacherClass1Teachers: teacherClass1Teachers,
                           adminClass1Teachers: adminClass1Teachers,
                           teacherClass2Teachers: teacherClass2Teachers,
                           adminClass2Teachers: adminClass2Teachers]

        String token = createToken(userMap[user], school20.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users?organization_uuid=${campus20.uuid.toString()}&excluded_class_uuid=${classMap[excludeClassEnrollments]}&limit=50&offset=0&${filter}&sort=last_name,first_name", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        assert resp.body.users.size() == resultUsers[expectedCollection].size()
        verifyUserCollectionResponse(resp.body.users, resultUsers[expectedCollection])

        where:
        user         | expectedCollection         | excludeClassEnrollments   | filter                                      |  result
        "teacher20"  | "teacherClass1Students"    |   "class1"                | "filter=role='STUDENT' and status='ACTIVE'" | HttpStatus.OK
        "admin20"    | "adminClass1Students"      |   "class1"                | "filter=role='STUDENT' and status='ACTIVE'" | HttpStatus.OK
        "teacher20"  | "teacherClass2Students"    |   "class2NoEnrollments"   | "filter=role='STUDENT' and status='ACTIVE'" | HttpStatus.OK
        "admin20"    | "adminClass2Students"      |   "class2NoEnrollments"   | "filter=role='STUDENT' and status='ACTIVE'" | HttpStatus.OK
        "teacher20"  | "teacherClass1Teachers"    |   "class1"                | "filter=role='TEACHER' and status='ACTIVE'" | HttpStatus.OK
        "admin20"    | "adminClass1Teachers"      |   "class1"                | "filter=role='TEACHER' and status='ACTIVE'" | HttpStatus.OK
        "teacher20"  | "teacherClass2Teachers"    |   "class2NoEnrollments"   | "filter=role='TEACHER' and status='ACTIVE'" | HttpStatus.OK
        "admin20"    | "adminClass2Teachers"      |   "class2NoEnrollments"   | "filter=role='TEACHER' and status='ACTIVE'" | HttpStatus.OK
    }
    
    @Unroll
    def "test GET users for campus and exclude enrolled students in class"(){

        ClassObj class1 = setupValidClass()
        ClassObj class2NoEnrollments = setupValidClass()
        List<Enrollment> enrollments = []
        enrollments.add(enrollmentRepo.save(new Enrollment(user: teacher1, classObj: class1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE)))
        enrollments.add(enrollmentRepo.save(new Enrollment(user: school1Students[0], classObj: class1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)))
        enrollments.add(enrollmentRepo.save(new Enrollment(user: school1Students[1], classObj: class1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)))


        def userMap = [student1: student1, teacher1: teacher1, teacher2: teacher2, unknown: UUID.randomUUID()]
        def schoolMap = [school1: school1.uuid, school2: school2.uuid, unknown: UUID.randomUUID()]
        def campusMap = [campus1: campus1.uuid, campus2: campus2.uuid, unknown: UUID.randomUUID()]
        def classMap = [class1: class1.uuid, class2NoEnrollments: class2NoEnrollments.uuid, unknown: UUID.randomUUID()]

        def expectedResult = [expectedUsers: [school1Students[2],school1Students[3],school1Students[4]], expectedUsersNoEnrollments: campus1.getUsers().findAll {it.status != AppUserStatus.ARCHIVE}]

        String token = createToken(userMap[user], schoolMap[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users?organization_uuid=${campusMap[campusOrg]}&excluded_class_uuid=${classMap[classObj]}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK){
            assert resp.body.users.size() ==  expectedResult[expectedCollection].size()
            verifyUserCollectionResponse(resp.body.users, expectedResult[expectedCollection])
        } else {
            assert resp.body.errors[0].field == null
            assert resp.body.errors[0].message == "'campus " + campusMap[campusOrg].toString() + " not found in school " + schoolMap[org].toString() + ".'"
        }

        where:
        user        | org        |   campusOrg        |  classObj                   | expectedCollection              | result
        "teacher1"  | "school1"  |   "campus1"        |  "class1"                   | "expectedUsers"                 | HttpStatus.OK
        "teacher1"  | "school1"  |   "campus1"        |  "class2NoEnrollments"      | "expectedUsersNoEnrollments"    | HttpStatus.OK
        "teacher2"  | "school2"  |   "unknown"        |  "unknown"                  | ""                              | HttpStatus.BAD_REQUEST
    }

    @Unroll
    def "users GET endpoint pagination tests"(){

        Organization school3 = new Organization(type: OrganizationType.SCHOOL, name: 'Sacramento', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school3)
        Organization campus3 = new Organization(type: OrganizationType.CAMPUS, name: 'Fresno', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school3)
        organizationRepo.save(campus3)
        User admin3 = new User(userName: 'admin', firstName: "test", lastName: "admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin3.setOrganizations([school3].asList() + [campus3].asList())
        userRepo.save(admin3)

        List<User> school3Students = []

        (1..10).each {
            User student = new User(userName: "student${it}", firstName: "test", lastName: "student${it}", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
            student.setOrganizations([school3].asList() + [campus3].asList())
            school3Students.add(student)
        }

        school3Students.each {
            userRepo.save(it)
        }

        school3.setUsers(school3Students.toSet() + [admin3].toSet())
        organizationRepo.save(school3)

        campus3.setUsers(school3Students.toSet())
        organizationRepo.save(campus3)


        String token = createToken(admin3, school3.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/users?organization_uuid=${campus3.uuid.toString()}&limit=${limit}&offset=${offset}", HttpMethod.GET, req, Map)

        Links links = new Links(resp.getHeaders().get("Link")[0])
        
        then:

        assert first.on == links.links.containsKey("first")
        assert previous.on == links.links.containsKey("previous")
        assert next.on == links.links.containsKey("next")
        assert last.on == links.links.containsKey("last")

        if(first.on){
            assert links.links.get("first").limit == first.l
            assert links.links.get("first").offset == first.o
        }

        if(previous.on){
            assert links.links.get("previous").limit == previous.l
            assert links.links.get("previous").offset == previous.o
        }

        if(next.on){
            assert links.links.get("next").limit == next.l
            assert links.links.get("next").offset == next.o
        }

        if(last.on){
            assert links.links.get("last").limit == last.l
            assert links.links.get("last").offset == last.o
        }

        where:
        limit  | offset || first                   | previous                | next                   | last
        10     | 0      || [on: false]             | [on: false]             | [on: false]            | [on: false]
        10     | 5      || [on: true, l: 10, o: 0] | [on: true, l: 10, o: 0] | [on: false]            | [on: false]
        5      | 0      || [on: false]             | [on: false]             | [on: true, l: 5, o: 5] | [on: true, l: 5, o: 5]
        4      | 4      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
        4      | 6      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 2]  | [on: false]            | [on: false]
        2      | 2      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 4] | [on: true, l: 2, o: 8]
        4      | 5      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 1]  | [on: true, l: 1, o: 9] | [on: true, l: 1, o: 9]
        2      | 5      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 3]  | [on: true, l: 2, o: 7] | [on: true, l: 2, o: 8]

        // TODO: consider revisiting and making prev/first [on: true, l: 3, o: 0] for this case
        5      | 3      || [on: true, l: 5, o: 0]  | [on: true, l: 5, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
    }

    @Unroll
    def "users GET endpoint test of filter"(){

        User student = new User(userName: "studentHOLD", firstName: "EvanTest", lastName: "studentHOLD", ssoId: "studentHOLDId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ON_HOLD, created: new Date(), updated: new Date())
        student.setOrganizations([school1].asList() + [campus1].asList())
        userRepo.save(student)

        school1.setUsers(school1Students.toSet() + school1ArchivedStudents.toSet() + [teacher1].toSet() + [student].toSet())
        organizationRepo.save(school1)

        campus1.setUsers(school1Students.toSet() + school1ArchivedStudents.toSet() + [teacher1].toSet() + [student].toSet())
        organizationRepo.save(campus1)

        String token = createToken(teacher1, school1.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/users" + filter
        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Map)
        def results = response.getBody()

        then:
        assert response.statusCode == result
        if (response.statusCode == HttpStatus.OK) {
            assert results.total_pages == 1
            assert results.current_page == 1
            assert results.page_size == numberOfElements
        } else {
            assert response.body.errors[0].field == "filter - badFieldName"
            assert response.body.errors[0].message == "Invalid filter badFieldName"
        }

        where:
        filter                                                                      | result                 || numberOfElements
        "?filter=status='ACTIVE'"                                                   | HttpStatus.OK          || 6
        "?filter=status='ON_HOLD'"                                                  | HttpStatus.OK          || 1
        "?filter=usernamecontains'HOLD'"                                            | HttpStatus.OK          || 1
        "?filter=sso_idcontains'HOLD'"                                              | HttpStatus.OK          || 1
        "?filter=first_namecontains'ntes'"                                          | HttpStatus.OK          || 1
        "?filter=last_namecontains'HOLD'"                                           | HttpStatus.OK          || 1
        "?filter=role='TEACHER'"                                                    | HttpStatus.OK          || 1
        "?filter=role='STUDENT'"                                                    | HttpStatus.OK          || 6
        "?filter=first_namecontains'nTes' or last_namecontains'nTes' and status='ON_HOLD' and role='STUDENT'"   | HttpStatus.OK          || 1
        ""                                                                          | HttpStatus.OK          || 7
        "?filter=badFieldName"                                                      | HttpStatus.BAD_REQUEST || 0

    }

    @Unroll
    def "users GET endpoint test of single column sort"(){
        given:

        Organization school5 = new Organization(type: OrganizationType.SCHOOL, name: 'Sacramento', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school5)
        Organization campus5 = new Organization(type: OrganizationType.CAMPUS, name: 'Fresno', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school5)
        organizationRepo.save(campus5)

        User admin5 = new User(userName: 'admin', firstName: "Admin", lastName: "Admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin5.setOrganizations([school5].asList() + [campus5].asList())
        userRepo.save(admin5)

        User alexanderHamilton = new User(userName: "alexHam", firstName: "Alexander", lastName: "Hamilton", ssoId: "alexhamSSOId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.PENDING_ARCHIVE, created: new Date(), updated: new Date())
        alexanderHamilton.setOrganizations([school5].asList() + [campus5].asList())
        userRepo.save(alexanderHamilton)

        User thomasJefferson = new User(userName: "thomJeff", firstName: "Thomas", lastName: "Jefferson", ssoId: "ThomJeffSSOId", type: AppUserType.TEACHER, originationId: 'shard1', status: AppUserStatus.ON_HOLD, created: new Date(), updated: new Date())
        thomasJefferson.setOrganizations([school5].asList() + [campus5].asList())
        userRepo.save(thomasJefferson)


        def expectedSortMap = [
                roleAsc: [admin5.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString()],
                roleDesc: [thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString(), admin5.uuid.toString()],
                statusAsc: [admin5.uuid.toString(),  thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString()],
                statusDesc: [alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString(), admin5.uuid.toString()],
                first_nameAsc: [admin5.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString()],
                first_nameDesc: [thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString(), admin5.uuid.toString()],
                last_nameAsc: [admin5.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString()],
                last_nameDesc: [thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString(), admin5.uuid.toString()],
        ]

        String token = createToken(admin5, school5.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/users?sort=${sort}&orderBy=${dir}"
        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Map)
        def results = response.getBody()

        then:
        assert response.statusCode == HttpStatus.OK
        assert results.users.user_uuid == expectedSortMap[expectedResult]

        where:
        sort                    | dir            |  expectedResult
        "role"                  | "asc"          |  "roleAsc"
        "role"                  | "desc"         |  "roleDesc"
        "status"                | "asc"          |  "statusAsc"
        "status"                | "desc"         |  "statusDesc"
        "first_name"            | "asc"          |  "first_nameAsc"
        "first_name"            | "desc"         |  "first_nameDesc"
        "last_name"             | "asc"          |  "last_nameAsc"
        "last_name"             | "desc"         |  "last_nameDesc"

    }

    @Unroll
    def "users GET endpoint test of  multiple column sort"(){
        given:

        Organization school4 = new Organization(type: OrganizationType.SCHOOL, name: 'Sacramento', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(school4)
        Organization campus4 = new Organization(type: OrganizationType.CAMPUS, name: 'Fresno', created: new Date(), updated: new Date(), originationId: 'shard1', parent: school4)
        organizationRepo.save(campus4)

        User admin4 = new User(userName: 'admin', firstName: "Admin", lastName: "Admin", type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date(), originationId: 'shard1')
        admin4.setOrganizations([school4].asList() + [campus4].asList())
        userRepo.save(admin4)

        User alexanderHamilton = new User(userName: "alexHam", firstName: "Alexander", lastName: "Hamilton", ssoId: "alexhamSSOId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
        alexanderHamilton.setOrganizations([school4].asList() + [campus4].asList())
        userRepo.save(alexanderHamilton)

        User thomasJefferson = new User(userName: "thomJeff", firstName: "Thomas", lastName: "Jefferson", ssoId: "ThomJeffSSOId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ON_HOLD, created: new Date(), updated: new Date())
        thomasJefferson.setOrganizations([school4].asList() + [campus4].asList())
        userRepo.save(thomasJefferson)

        User bobSmith = new User(userName: "bobSmith", firstName: "Bob", lastName: "Smith", ssoId: "bobSmithSSOId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
        bobSmith.setOrganizations([school4].asList() + [campus4].asList())
        userRepo.save(bobSmith)

        User alSmith = new User(userName: "alSmith", firstName: "Al", lastName: "Smith", ssoId: "AlSmithSSOId", type: AppUserType.STUDENT, originationId: 'shard1', status: AppUserStatus.ACTIVE, created: new Date(), updated: new Date())
        alSmith.setOrganizations([school4].asList() + [campus4].asList())
        userRepo.save(alSmith)

        school4.setUsers([admin4].toSet() + [alexanderHamilton].toSet() + [thomasJefferson].toSet() + [bobSmith].toSet() + [alSmith].toSet())
        organizationRepo.save(school4)

        campus4.setUsers([admin4].toSet() + [alexanderHamilton].toSet() + [thomasJefferson].toSet() + [bobSmith].toSet() + [alSmith].toSet())
        organizationRepo.save(campus4)

        def expectedSortMap = [
                   roleAsc: [admin4.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString(), bobSmith.uuid.toString(), alSmith.uuid.toString()],
                   roleDesc: [alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString(), bobSmith.uuid.toString(), alSmith.uuid.toString(),admin4.uuid.toString()],
                   statusAsc: [admin4.uuid.toString(), alexanderHamilton.uuid.toString(), bobSmith.uuid.toString(), alSmith.uuid.toString(), thomasJefferson.uuid.toString()],
                   statusDesc: [thomasJefferson.uuid.toString(), admin4.uuid.toString(), alexanderHamilton.uuid.toString(), bobSmith.uuid.toString(), alSmith.uuid.toString()],
                   first_nameAsc: [admin4.uuid.toString(), alSmith.uuid.toString(),alexanderHamilton.uuid.toString(), bobSmith.uuid.toString(), thomasJefferson.uuid.toString()],
                   first_nameDesc: [thomasJefferson.uuid.toString(), bobSmith.uuid.toString(), alexanderHamilton.uuid.toString(), alSmith.uuid.toString(), admin4.uuid.toString()],
                   last_nameAsc: [admin4.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString(), bobSmith.uuid.toString(), alSmith.uuid.toString()],
                   last_nameDesc: [alSmith.uuid.toString(), bobSmith.uuid.toString(), thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString(), admin4.uuid.toString()],
                   last_namefirst_nameAsc: [admin4.uuid.toString(), alexanderHamilton.uuid.toString(), thomasJefferson.uuid.toString(), alSmith.uuid.toString(),bobSmith.uuid.toString()],
                   last_namefirst_nameDesc: [bobSmith.uuid.toString(), alSmith.uuid.toString(),thomasJefferson.uuid.toString(), alexanderHamilton.uuid.toString(),admin4.uuid.toString()]
                ]

        String token = createToken(admin4, school4.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.USERS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/users?sort=${sort}&orderBy=${dir}"
        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Map)
        def results = response.getBody()

        then:
        assert response.statusCode == HttpStatus.OK
        assert results.users.user_uuid == expectedSortMap[expectedResult]

        where:
        sort                                         | dir                      |  expectedResult
        "role,last_name,first_name"                  | "asc,asc,desc"           |  "roleAsc"
        "role,last_name,first_name"                  | "desc,asc,desc"          |  "roleDesc"
        "status,last_name,first_name"                | "asc,asc,desc"           |  "statusAsc"
        "status,last_name,first_name"                | "desc,asc,desc"          |  "statusDesc"
        "last_name,first_name"                       | "asc,asc"                |  "last_namefirst_nameAsc"
        "last_name,first_name"                       | "desc,desc"              |  "last_namefirst_nameDesc"

    }

    private void verifyUserCollectionResponse(respBodyUsers, expectedUserCollection){
        respBodyUsers.each { userObject ->
            def User user = expectedUserCollection.find {
                it.uuid.toString() == userObject.user_uuid
            }
            assert userObject.user_uuid == user.uuid.toString()
            assert userObject.status == user.status.toString()
            assert userObject.username == user.userName
            assert userObject.sso_id == user.ssoId
            assert userObject.first_name == user.firstName
            assert userObject.last_name == user.lastName
            assert userObject.role == user.type.toString()

            userObject.orgs.each { orgObject ->
                Organization org = user.organizations?.find {it.uuid.toString() == orgObject.organization_uuid}
                assert orgObject.organization_uuid == org.uuid.toString()
                assert orgObject.type == org.type.toString()
                assert orgObject.name == org.name
                assert orgObject._links.size() == 1
            }
        }
    }

    //TODO: move this to BaseRestSpec - this is used in EnrollmentControllerIntegerationSpec also
    private setupValidClass(){
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school1.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school1.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: "test class name",
                subject: subjectsService.findOne(subject.uuid, school1.uuid),
                organization: campus1,
                creatorUuid: teacher1.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                done: false
        )
        classObj = classRepo.save(classObj)
        return classObj
    }
}
