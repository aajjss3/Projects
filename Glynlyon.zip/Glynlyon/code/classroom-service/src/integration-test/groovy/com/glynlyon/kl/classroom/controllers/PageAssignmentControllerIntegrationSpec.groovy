package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.service.JsonMappingService
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class PageAssignmentControllerIntegrationSpec extends BaseRestSpec{

    User admin, student, teacher
    Organization school, school2, campus1, campus2

    @Autowired
    JsonMappingService jsonMappingService

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    @Value('${cltSearch.base.uri}')
    String cltBaseUri

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))

        campus1 = organizationRepo.save(new Organization(name: 'campus1', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))
        campus2 = organizationRepo.save(new Organization(name: 'campus2', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))

        teacher = userRepo.save(new User(firstName: 'some', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        student = userRepo.save(new User(firstName: 'some', lastName: 's', userName: 'studnet', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus2]))

        PageAssignment.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return pageAssignmentRepo.save(delegate)
        }
    }

    def "test get page assignments"(){
        given:
        def classObj = setupValidClass(admin, school)
        def page1 = setupValidPage("Page 1", classObj)
        def pageAssignment = setupValidPageAssignment('Test Page Assignment', page1, 1)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page1.uuid}/assignments", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = [pageAssignment.uuid].collect{it.toString()}
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.page_assignments.size == expectedUuids.size()
        resp.body.page_assignments.each { pa ->
            assert expectedUuids.contains(pa.page_assignment_uuid)
        }

        def responseClass = resp.body.page_assignments.find { it.page_assignment_uuid == pageAssignment.uuid.toString() }
        def expectedAssignment = [
                "assignment_uuid" : pageAssignment.assignment.uuid.toString(),
                "assignment_title" : pageAssignment.assignment.title,
                "assignment_type" : pageAssignment.assignment.type.toString(),
                "_links" : [
                        "self": ["href": cltBaseUri + "/nodes/"+pageAssignment.assignment.uuid]
                ]
        ]
        assert responseClass.page_assignment_uuid == pageAssignment.uuid.toString()
        assert responseClass.page_uuid == page1.uuid.toString()
        assert responseClass.sequence == pageAssignment.sequence
        assert responseClass.assignment == expectedAssignment

    }

    @Unroll
    def "test get pages with sorting"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("pageTest", classObj)
        List<PageAssignment> assignments = setupPageAssignmentsForSorting(sort, pageObj, classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/assignments?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == assignments.size()

        PageAssignment expectedFirstPage = assignments.find { it.assignment.title == expectedFirstPageName}

        def responseClass = resp.body.page_assignments[0]

        assert responseClass.assignment.assignment_title == expectedFirstPage.assignment.title

        where:

        sort                                      | dir              || expectedFirstPageName
        "sequence"                                | "asc"            || "sequenceFirst"
        "sequence"                                | "desc"           || "sequenceLast"
        "assignment.assignment_uuid"              | "asc"            || "uuidFirst"
        "assignment.assignment_uuid"              | "desc"           || "uuidLast"
        "assignment.assignment_title"             | "asc"            || "titleFirst"
        "assignment.assignment_title"             | "desc"           || "titleLast"
        "assignment.assignment_type"              | "asc"            || "typeFirst"
        "assignment.assignment_type"              | "desc"           || "typeLast"

    }

    def "test get pages with bad sorting fields"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("pageTest", classObj)
        List<PageAssignment> assignments = setupPageAssignmentsForSorting(sort, pageObj, classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/assignments?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == 1

        def responseError = resp.body.errors

        assert responseError.field[0] == 'sort'
        assert responseError.message[0] == expectedError

        where:

        sort                                                | dir              || expectedError
        "badfield"                                          | "asc"            || "invalid sort field 'badfield'"
        "assignment_assignment"                             | "desc"           || "invalid sort field 'assignment_assignment'"
    }

    @Unroll
    def "test get pages with filtering"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage("pageTest", classObj)
        List<PageAssignment> assignments = setupPageAssignmentsForSorting(field, pageObj, classObj)

        Map<String, PageAssignment> assignmentMap = assignments.collectEntries{[(it.assignment.title):it]}

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/assignments?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedNames.collect{assignmentMap[it].uuid.toString()}
        checkAssignmentResponse(resp, expectedUuids, assignmentMap)

        where:
        field                            | filter                                                    | expectedNames
        "sequence"                       | "sequence='2'"                                            | ['sequenceLast']
        "sequence"                       | "sequence='2' OR sequence='1'"                            | ['sequenceLast', 'sequenceFirst']
        "assignment.assignment_title"    | "assignment.assignment_title='titleFirst'"                | ['titleFirst']
        "assignment.assignment_title"    | "assignment.assignment_titlecontains'Last'"               | ['titleLast']
        "assignment.assignment_type"     | "assignment.assignment_type='LESSON'"                     | ['typeFirst']
        "assignment.assignment_type"     | "assignment.assignment_type='LESSON' AND sequence='1'"    | ['typeFirst']
    }


    def "should create page assignments"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)

        def body = [
                "page_assignments" : [
                        [
                                "assignment_uuid": UUID.randomUUID(),
                                "sequence": 1,
                                "assignment_title" : "title",
                                "assignment_type" : "LESSON"
                        ],
                        [
                                "assignment_uuid": UUID.randomUUID(),
                                "sequence": 2,
                                "assignment_title" : "other title",
                                "assignment_type" : "PROJECT"
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll().sort(false){ a, b ->
            a.sequence <=> b.sequence
        }
        assert pageAssignments.size() == 2

        pageAssignments.eachWithIndex { pa, i ->
            assert pa.assignment.uuid == body.page_assignments[i].assignment_uuid
            assert pa.sequence == body.page_assignments[i].sequence
            assert pa.assignment.title == body.page_assignments[i].assignment_title
            assert pa.assignment.type == body.page_assignments[i].assignment_type as AssignmentType
        }
    }
	
	
	def "should create page assignment and update an existing assignment"(){
		given:
		ClassObj classObj = setupValidClass(admin, school)
		PageObj page = setupValidPage(classObj)
		Assignment assigment = assignmentRepo.save(new Assignment(uuid: UUID.randomUUID(), type: AssignmentType.PROJECT, title: "not-test",  created: new Date(), updated: new Date()))

		def body = [
				"page_assignments" : [
						[
								"assignment_uuid": assigment.uuid,
								"sequence": 3,
								"assignment_title" : "test",
								"assignment_type" : "LESSON"
						]
				]
		]
		

		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
		HttpEntity req = new HttpEntity(body, headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.POST, req, Map)

		then:
		assert resp.statusCode == HttpStatus.NO_CONTENT

		List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

		assert pageAssignments.size() == 1
		for(PageAssignment pageAssignment : pageAssignments){
			assert pageAssignment.assignment.uuid == assigment.uuid
			assert pageAssignment.assignment.title == 'test'
			assert pageAssignment.assignment.type == AssignmentType.LESSON
		}

	}
	
	

    @Unroll
    def "should not allow duplicate sequence or assignment within a page"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        Map<String, PageObj> pages = [page1: setupValidPage("page1", classObj), page2: setupValidPage("page2", classObj)]

        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "test",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: pages["page1"]
        ))

        def body = [
                "page_assignments" : [
                        [
                                "assignment_uuid": UUID.randomUUID(),
                                "sequence": 27,
                                "assignment_title" : "title",
                                "assignment_type" : "LESSON"
                        ]
                ]
        ]

        body.page_assignments[0]."${field}" = internal.split(/\./).inject(existing, {def prev, def cur -> prev."${cur}"})

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pages[targetpage].uuid}/assignments", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == expectedStatus

        assert pageAssignmentRepo.findAll().size() == expectedCount

        where:
        field             | internal          | targetpage || expectedStatus         | expectedCount
        "sequence"        | "sequence"        | "page1"    || HttpStatus.BAD_REQUEST | 1
        "sequence"        | "sequence"        | "page2"    || HttpStatus.NO_CONTENT  | 2
        "assignment_uuid" | "assignment.uuid" | "page1"    || HttpStatus.BAD_REQUEST | 1
        "assignment_uuid" | "assignment.uuid" | "page2"    || HttpStatus.NO_CONTENT  | 2

    }

    def "should not allow user in different org to create page assignment"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)

        def body = [
                "page_assignments" : [
                        [
                                "assignment_uuid": UUID.randomUUID(),
                                "sequence": 1,
                                "assignment_title" : "title",
                                "assignment_type" : "LESSON"
                        ]
                ]
        ]

        String token = createToken(admin, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST

        assert pageAssignmentRepo.findAll().size() == 0

    }

    def "should be able to delete page assignment"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        List<PageAssignment> assignments = (1..3).collect{
            Assignment assignment = assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "title${it}",
                    type: "LESSON"
            ))
            pageAssignmentRepo.save(new PageAssignment(
                    sequence: it,
                    assignment: assignment,
                    pageObj: page
            ))
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/${assignments[1].uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        List<PageAssignment> actual = pageAssignmentRepo.findAll().asList()
        assert actual.size() == 2
        assert actual.uuid.containsAll([assignments[0], assignments[2]].uuid)

    }

    def "should not allow user in different org to delete page assignment"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))
        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        String token = createToken(admin, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert pageAssignmentRepo.findAll().size() == 1

    }

    @Unroll
    def "should test role permissions for delete page assignment"(){
        given:
        ClassObj classObj = setupValidClass(admin, campus1)
        PageObj page = setupValidPage(classObj)
        Map<String, User> users = [admin: admin, teacher: teacher, student: student]

        if(enroll) {
            if (user == "teacher") {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
            }
            else {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            }
        }

        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        String token = createToken(users[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.NO_CONTENT) {
            assert pageAssignmentRepo.findAll().size() == 0
        }
        else {
            assert pageAssignmentRepo.findAll().size() == 1
        }

        where:
        user      | enroll || expectedStatus
        "admin"   | false  || HttpStatus.NO_CONTENT
        "teacher" | false  || HttpStatus.BAD_REQUEST
        "teacher" | true   || HttpStatus.NO_CONTENT
        "student" | false  || HttpStatus.BAD_REQUEST
        "student" | true   || HttpStatus.BAD_REQUEST

    }

    def "should be able to edit page assignment sequences"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..3).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}
        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        PageAssignment assignment2 = new PageAssignment(pageObj: page, assignment: assignments[1], sequence: 2)
        PageAssignment assignment3 = new PageAssignment(pageObj: page, assignment: assignments[2], sequence: 3)
        pageAssignmentRepo.save(assignment1)
        pageAssignmentRepo.save(assignment2)
        pageAssignmentRepo.save(assignment3)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid.toString(),
                                "sequence": 3,
                        ],
                        [
                                "page_assignment_uuid": assignment2.uuid.toString(),
                                "sequence": 1,
                        ],
                        [
                                "page_assignment_uuid": assignment3.uuid.toString(),
                                "sequence": 2,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll().sort(false){ a, b ->
            a.sequence <=> b.sequence
        }
        assert pageAssignments.size() == 3

        assert pageAssignments[0].uuid == assignment2.uuid
        assert pageAssignments[1].uuid == assignment3.uuid
        assert pageAssignments[2].uuid == assignment1.uuid
    }

    def "another page assignment sequence"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..3).collect{
            assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "Assignment 1",
                type: "LESSON"
        ))}

        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        PageAssignment assignment2 = new PageAssignment(pageObj: page, assignment: assignments[1], sequence: 2)
        PageAssignment assignment3 = new PageAssignment(pageObj: page, assignment: assignments[2], sequence: 3)
        pageAssignmentRepo.save(assignment1)
        pageAssignmentRepo.save(assignment2)
        pageAssignmentRepo.save(assignment3)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid.toString(),
                                "sequence": 1,
                        ],
                        [
                                "page_assignment_uuid": assignment2.uuid.toString(),
                                "sequence": 3,
                        ],
                        [
                                "page_assignment_uuid": assignment3.uuid.toString(),
                                "sequence": 2,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll().sort(false){ a, b ->
            a.sequence <=> b.sequence
        }
        assert pageAssignments.size() == 3

        assert pageAssignments[0].uuid == assignment1.uuid
        assert pageAssignments[1].uuid == assignment3.uuid
        assert pageAssignments[2].uuid == assignment2.uuid
    }

    def "edit should fail if passed in assignments are less than original assignments"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..3).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}

        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        PageAssignment assignment2 = new PageAssignment(pageObj: page, assignment: assignments[1], sequence: 2)
        PageAssignment assignment3 = new PageAssignment(pageObj: page, assignment: assignments[2], sequence: 3)
        pageAssignmentRepo.save(assignment1)
        pageAssignmentRepo.save(assignment2)
        pageAssignmentRepo.save(assignment3)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid.toString(),
                                "sequence": 3,
                        ],
                        [
                                "page_assignment_uuid": assignment2.uuid.toString(),
                                "sequence": 1,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == "Assignments being reordered must include all original assignments."

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

        assert pageAssignments.size() == 3

        assert pageAssignments[0].uuid == assignment1.uuid
        assert pageAssignments[1].uuid == assignment2.uuid
        assert pageAssignments[2].uuid == assignment3.uuid

    }

    def "edit should fail if passed in assignments are greater than original assignments"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..3).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}
        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        PageAssignment assignment2 = new PageAssignment(pageObj: page, assignment: assignments[1], sequence: 2)
        PageAssignment assignment3 = new PageAssignment(pageObj: page, assignment: assignments[2], sequence: 3)
        pageAssignmentRepo.save(assignment1)
        pageAssignmentRepo.save(assignment2)
        pageAssignmentRepo.save(assignment3)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid.toString(),
                                "sequence": 1,
                        ],
                        [
                                "page_assignment_uuid": assignment2.uuid.toString(),
                                "sequence": 2,
                        ],
                        [
                                "page_assignment_uuid": assignment3.uuid.toString(),
                                "sequence": 3,
                        ],
                        [
                                "page_assignment_uuid": UUID.randomUUID().toString(),
                                "sequence": 4,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == "Assignments being reordered must include all original assignments."

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

        assert pageAssignments.size() == 3

        assert pageAssignments[0].uuid == assignment1.uuid
        assert pageAssignments[1].uuid == assignment2.uuid
        assert pageAssignments[2].uuid == assignment3.uuid

    }

    def "edit should fail if passed in assignments are invalid"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..1).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}
        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        pageAssignmentRepo.save(assignment1)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": UUID.randomUUID(),
                                "sequence": 2,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == "Assignments being reordered must include all original assignments."

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

        assert pageAssignments.size() == 1

        assert pageAssignments[0].uuid == assignment1.uuid
    }

    def "edit should fail if role is invalid"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..1).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}
        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        pageAssignmentRepo.save(assignment1)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid,
                                "sequence": 2,
                        ]
                ]
        ]

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == "Could not find page ${page.uuid.toString()} in organization ${school.uuid.toString()}"

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

        assert pageAssignments.size() == 1

        assert pageAssignments[0].uuid == assignment1.uuid
    }

    def "edit should fail if passed in assignment sequence is 0 or less"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        def assignments = (1..1).collect{
            assignmentRepo.save(new Assignment(
                    uuid: UUID.randomUUID(),
                    title: "Assignment 1",
                    type: "LESSON"
            ))}
        PageAssignment assignment1 = new PageAssignment(pageObj: page, assignment: assignments[0], sequence: 1)
        pageAssignmentRepo.save(assignment1)

        def body = [
                "page_assignments" : [
                        [
                                "page_assignment_uuid": assignment1.uuid.toString(),
                                "sequence": 0,
                        ]
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == "Assignment sequence number can not be 0 or less."

        List<PageAssignment> pageAssignments = pageAssignmentRepo.findAll()

        assert pageAssignments.size() == 1

        assert pageAssignments[0].uuid == assignment1.uuid
        assert pageAssignments[0].sequence == 1

    }

    @Unroll
    def "should test errors and role permissions for page assignment report"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus1)
        PageObj page = setupValidPage(classObj)
        Map<String, User> users = [admin: admin, teacher: teacher, student: student]
        Map<String, UUID> orgs = [school : school.uuid, random: UUID.randomUUID()]
        Map<String, UUID> pages = [page: page.uuid, random: UUID.randomUUID()]

        if (enroll) {
            if (user == "teacher") {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
            }
            else {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            }
        }

        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        Map<String, UUID> pageAssignments = [pa: existing.uuid, random: UUID.randomUUID()]

        def body = [
                "report_id_prefix" : "some_prefix",
                "report_type" : "SESSIONS_LIST_BY_ITEM"
        ]

        String token = createToken(users[user], orgs[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-CLIENT-DOMAIN", "domain")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        message = message.replaceAll("PAGE_UUID", pages[pageid].toString())
        message = message.replaceAll("ORG_UUID", orgs[org].toString())
        message = message.replaceAll("PA_UUID", pageAssignments[page_assignment].toString())

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pages[pageid]}/assignments/${pageAssignments[page_assignment]}/reports", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.error == message

        where:
        user      | org      | pageid   | page_assignment | enroll || message
        "teacher" | "school" | "page"   | "pa"            | false  || "Could not find page PAGE_UUID in organization ORG_UUID"
        "student" | "school" | "page"   | "pa"            | false  || "only supported roles are ADMIN, TEACHER"
        "student" | "school" | "page"   | "pa"            | true   || "only supported roles are ADMIN, TEACHER"
        "admin"   | "random" | "page"   | "pa"            | false  || "Could not find page PAGE_UUID in organization ORG_UUID"
        "admin"   | "school" | "random" | "pa"            | false  || "Could not find page PAGE_UUID in organization ORG_UUID"
        "admin"   | "school" | "page"   | "random"        | false  || "Could not find page assignment PA_UUID in page PAGE_UUID"
    }

    @Unroll
    def "should test page assignment report input errors"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus1)
        PageObj page = setupValidPage(classObj)
        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        def body = [
                "report_id_prefix" : prefix,
                "report_type" : type
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-CLIENT-DOMAIN", "domain")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/${existing.uuid}/reports", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == 1
        assert resp.body.errors[0] == expectedError

        where:
        prefix | type                    | expectedError
        null   | "SESSIONS_LIST_BY_ITEM" | [field: "report_id_prefix", message: "may not be null"]
        "pre"  | "SESSIONS_LIST_BY_ITE"  | [field: "report_type", message: "invalid input SESSIONS_LIST_BY_ITE"]
        "pre"  | null                    | [field: "report_type", message: "may not be null"]

    }

    def "should get empty page assignment report if no attempts"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus1)
        PageObj page = setupValidPage(classObj)
        Assignment assignment = assignmentRepo.save(new Assignment(
                uuid: UUID.randomUUID(),
                title: "title",
                type: "LESSON"
        ))

        PageAssignment existing = pageAssignmentRepo.save(new PageAssignment(
                sequence: 1,
                assignment: assignment,
                pageObj: page
        ))

        def body = [
                "report_id_prefix" : "something",
                "report_type" : "SESSIONS_LIST_BY_ITEM"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("X-CLIENT-DOMAIN", "domain")
        headers.setContentType(Constants.PAGE_ASSIGNMENTS_REPORT_REQUEST_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ASSIGNMENTS_REPORT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/${existing.uuid}/reports", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT
    }

    private List<PageAssignment> setupPageAssignmentsForSorting(String field, PageObj pageObj, ClassObj classObj){
        List<PageAssignment> assignments = []
        switch (field){
            case "sequence":
                assignments.add(setupValidPageAssignment("sequenceFirst", pageObj, 1))
                assignments.add(setupValidPageAssignment("sequenceLast", pageObj, 2))
                break
            case "assignment.assignment_uuid":

                def uuids = [UUID.randomUUID(), UUID.randomUUID()].sort(false){ a, b ->
                    a.toString() <=> b.toString()
                }
                Assignment assignment1 = assignmentRepo.saveAndFlush(
                        new Assignment(
                                uuid: uuids[0],
                                title: "uuidFirst",
                                type: AssignmentType.LESSON
                        )
                )

                Assignment assignment2 = assignmentRepo.saveAndFlush(
                        new Assignment(
                                uuid: uuids[1],
                                title: "uuidLast",
                                type: AssignmentType.LESSON
                        )
                )

                assignments.add(setupValidPageAssignment("tmp", pageObj, 1).updateField("assignment", assignment1))
                assignments.add(setupValidPageAssignment("tmp", pageObj, 2).updateField("assignment", assignment2))
                break
            case "assignment.assignment_title":
                assignments.add(setupValidPageAssignment("titleFirst", pageObj, 1))
                assignments.add(setupValidPageAssignment("titleLast", pageObj, 2))
                break
            case "assignment.assignment_type":

                Assignment assignment1 = assignmentRepo.save(
                        new Assignment(
                                uuid: UUID.randomUUID(),
                                title: "typeFirst",
                                type: AssignmentType.LESSON
                        )
                )

                Assignment assignment2 = assignmentRepo.save(
                        new Assignment(
                                uuid: UUID.randomUUID(),
                                title: "typeLast",
                                type: AssignmentType.PROJECT
                        )
                )


                assignments.add(setupValidPageAssignment("typeFirst", pageObj, 1).updateField("assignment", assignment1))
                assignments.add(setupValidPageAssignment("typeLast", pageObj, 2).updateField("assignment", assignment2))
                break
        }
        return assignments
    }

    private void checkAssignmentResponse(HttpEntity resp, List<String> expectedUuids, Map<String, PageAssignment> assignments){
        PageAssignment assignment = assignments.values().find { it.uuid.toString() == expectedUuids.first()}

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.page_assignments.size == expectedUuids.size()
        resp.body.page_assignments.each { p ->
            assert expectedUuids.contains(p.page_assignment_uuid)
        }
        def responseClass = resp.body.page_assignments.find { it.page_assignment_uuid == expectedUuids.first() }
        def expectedAssignment = [
                "assignment_uuid" : assignment.assignment.uuid.toString(),
                "assignment_title" : assignment.assignment.title,
                "assignment_type" : assignment.assignment.type.toString(),
                "_links" : [
                        "self": ["href": cltBaseUri + "/nodes/"+ assignment.assignment.uuid.toString()]
                ]
        ]
        assert responseClass.page_assignment_uuid == assignment.uuid.toString()
        assert responseClass.page_uuid == assignment.pageObj.uuid.toString()
        assert responseClass.sequence == assignment.sequence
        assert responseClass.assignment == expectedAssignment
    }
}
