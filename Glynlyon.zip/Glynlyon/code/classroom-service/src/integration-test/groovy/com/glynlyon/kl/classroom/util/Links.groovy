package com.glynlyon.kl.classroom.util

import groovy.transform.ToString

/**
 * Created by etatarzycki on 3/8/17.
 */
@ToString
class Links {
    Map<String, ParsedLink> links

    public Links(String header){
        def linkStrings = header.split(',')
        links = linkStrings.collectEntries {
            ParsedLink parsedLink = new ParsedLink(it)
            return [(parsedLink.rel):parsedLink]
        }
    }
}
