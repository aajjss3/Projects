package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.DefaultSubject
import com.glynlyon.kl.classroom.model.DisabledSubject
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.SubjectsView
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.model.UuidOrgId
import com.glynlyon.kl.classroom.repo.DefaultSubjectRepo
import com.glynlyon.kl.classroom.repo.DisabledSubjectRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.SubjectsViewRepo
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.Links
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class SubjectControllerIntegrationSpec extends BaseRestSpec{

    @Autowired
    SubjectsController controller

    @Autowired
    SubjectsViewRepo subjectsViewRepo

    @Autowired
    DisabledSubjectRepo disabledSubjectRepo

    @Autowired
    DefaultSubjectRepo defaultSubjectRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    SubjectRepo subjectRepo

    User teacher
    User admin
    User student
    Organization school, school2

    def setup() {
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date()))
        teacher = userRepo.save(new User(firstName: 'testTeacher', lastName: 'teacher Last', userName: 'Teacher1', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))
        admin = userRepo.save(new User(firstName: 'testAdmin', lastName: 'admin Last', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))
        student = userRepo.save(new User(firstName: 'testStudent', lastName: 'student Last', userName: 'testStudent', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))
    }

    def "GET subjects endpoint returns all expected fields"(){
        given:

        Subject subject1 = new Subject(name: 'Default Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=2", HttpMethod.GET, req, Object)

        then:
        assert response.statusCode == HttpStatus.OK
        assert response.getHeaders().get('X-total-count')[0].toInteger() == 1
        assert response.getHeaders().get('Link')[0] != null

        assert response.body.subjects.name[0] == subject1.name
        assert response.body.subjects.subject_uuid[0] == subject1.uuid.toString()
        assert response.body.subjects.organization_uuid[0] == school.uuid.toString()
        assert response.body.subjects.default_subject[0] == false
        assert response.body.subjects.disabled[0] == false

    }

    def "GET subjects endpoint will return disabled subject"(){
        given:
        Subject subject1 = new Subject(name: 'Default Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        DisabledSubject disabledSubject1 = new DisabledSubject(uuid: subject1.uuid, organizationUuid: school.uuid, createdAt: new Date(), updatedAt: new Date())
        disabledSubjectRepo.save(disabledSubject1)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=2", HttpMethod.GET, req, Object)

        then:
        assert response.statusCode == HttpStatus.OK
        assert response.getHeaders().get('X-total-count')[0].toInteger() == 1
        assert response.getHeaders().get('Link')[0] != null

        assert response.body.subjects.name[0] == subject1.name
        assert response.body.subjects.subject_uuid[0] == subject1.uuid.toString()
        assert response.body.subjects.organization_uuid[0] == school.uuid.toString()
        assert response.body.subjects.default_subject[0] == false
        assert response.body.subjects.disabled[0] == true

    }

    def "GET subjects endpoint will return default subject"(){
        given:
        DefaultSubject defaultSubject = defaultSubjectRepo.save(new DefaultSubject(name: 'Default Subject', createdAt: new Date(), updatedAt: new Date()))

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=2", HttpMethod.GET, req, Object)

        then:
        assert response.statusCode == HttpStatus.OK
        assert response.getHeaders().get('X-total-count')[0].toInteger() == 1
        assert response.getHeaders().get('Link')[0] != null

        assert response.body.subjects.name[0] == defaultSubject.name
        assert response.body.subjects.subject_uuid[0] == defaultSubject.uuid.toString()
        assert response.body.subjects.organization_uuid[0] == school.uuid.toString()
        assert response.body.subjects.default_subject[0] == true
        assert response.body.subjects.disabled[0] == false

    }

    def "GET subjects endpoint will return mix of subjects"(){
        given:
        DefaultSubject defaultSubject = defaultSubjectRepo.save(new DefaultSubject(name: 'Default Subject', createdAt: new Date(), updatedAt: new Date()))
        Subject subject1 = new Subject(name: 'Disabled Subject', organizationUuid: school.uuid, disabled: true, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject activeSubject = new Subject(name: 'Active Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(activeSubject)
        DisabledSubject disabledSubject = new DisabledSubject(uuid: subject1.uuid, organizationUuid: school.uuid, createdAt: new Date(), updatedAt: new Date())
        disabledSubjectRepo.save(disabledSubject)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=3", HttpMethod.GET, req, Object)
        def sortedResults = response.collect().sort{ it.name }

        then:
        assert response.statusCode == HttpStatus.OK

        assert sortedResults.body.subjects.name[0][0] == activeSubject.name
        assert sortedResults.body.subjects.subject_uuid[0][0] == activeSubject.uuid.toString()
        assert sortedResults.body.subjects.organization_uuid[0][0] == school.uuid.toString()
        assert sortedResults.body.subjects.default_subject[0][0] == false
        assert sortedResults.body.subjects.disabled[0][0] == false
        assert sortedResults.body.subjects.name[0][1] == defaultSubject.name
        assert sortedResults.body.subjects.subject_uuid[0][1] == defaultSubject.uuid.toString()
        assert sortedResults.body.subjects.organization_uuid[0][1] == school.uuid.toString()
        assert sortedResults.body.subjects.default_subject[0][1] == true
        assert sortedResults.body.subjects.disabled[0][1] == false
        assert sortedResults.body.subjects.name[0][2] == subject1.name
        assert sortedResults.body.subjects.subject_uuid[0][2] == disabledSubject.uuid.toString()
        assert sortedResults.body.subjects.organization_uuid[0][2] == school.uuid.toString()
        assert sortedResults.body.subjects.default_subject[0][2] == false
        assert sortedResults.body.subjects.disabled[0][2] == true
    }

    def "GET subjects endpoint sorts / filters correctly on default and disabled fields"(){
        given:
        DefaultSubject defaultSubject = new DefaultSubject(uuid: UUID.randomUUID(), name: 'Default Subject', createdAt: new Date(), updatedAt: new Date())
        defaultSubjectRepo.save(defaultSubject)
        Subject subject1 = new Subject(name: 'Disabled Subject', organizationUuid: school.uuid, disabled: true, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject activeSubject = new Subject(name: 'Active Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(activeSubject)
        DisabledSubject disabledSubject = new DisabledSubject(uuid: subject1.uuid, organizationUuid: school.uuid, createdAt: new Date(), updatedAt: new Date())
        disabledSubjectRepo.save(disabledSubject)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=1&sort="+sort+"&orderBy="+orderBy+"&filter="+filter, HttpMethod.GET, req, Object)

        then:
        assert response.statusCode == HttpStatus.OK
        assert response.body.subjects.name[0] == name

        where:
        sort                  | orderBy | filter                        || name
        "disabled"            | "desc"  | ""                            || 'Disabled Subject'
        "default_subject"     | "desc"  | ""                            || 'Default Subject'
        ""                    | ""      | "disabled='true'"             || 'Disabled Subject'
        ""                    | ""      | "default_subject='true'"      || 'Default Subject'

    }

    def "Response header for a GET call should return valid Link and total count values"(){
        given:
        Subject subject1 = new Subject(name: 'Advanced Placement', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject subject2 = new Subject(name: 'Blended', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject2)
        Subject subject3 = new Subject(name: 'Career and Technical Education    ', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject3)
        Subject subject4 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject4)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/subjects?limit=2", HttpMethod.GET, req, Object)

        then:
        assert response.statusCode == HttpStatus.OK
        assert response.getHeaders().get('X-total-count')[0].toInteger() == 4
        assert response.getHeaders().get('Link')[0] != null
    }

    @Unroll
    def "subject GET endpoint test with all possible inputs and return values"(){
        given:
        Subject subject1 = new Subject(name: 'Elective',  organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject subject2 = new Subject(name: 'Blended', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-1, updatedAt: new Date())
        subjectRepo.save(subject2)
        Subject subject3 = new Subject(name: 'Career and Technical Education', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-2, updatedAt: new Date())
        subjectRepo.save(subject3)
        Subject subject4 = new Subject(name: 'Advanced Placement', organizationUuid: school.uuid, disabled: false, createdAt: new Date()-3, updatedAt: new Date())
        subjectRepo.save(subject4)
        Subject subject5 = new Subject(name: 'Some other subject', organizationUuid: school2.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject5)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/subjects?limit="+limit+"&offset="+offset+"&orderBy="+orderBy+"&sort="+sortInput
        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        def results = response.getBody()
        def sortedList

        if(orderBy == "desc") {
            sortedList = subjectRepo.findAll().findAll{it.organizationUuid == school.uuid}.sort { a, b -> a.uuid.toString() <=> b.uuid.toString() }.reverse()
        }
        else{
            sortedList = subjectRepo.findAll().findAll{it.organizationUuid == school.uuid}.sort { a, b -> a.uuid.toString() <=> b.uuid.toString() }
        }


        then:
        assert response.statusCode == HttpStatus.OK
        assert results.total_pages == totalPages
        assert results.current_page == number
        assert results.page_size == numberOfElements

        if(orderBy){
            assert results.subjects[0].subject_uuid == sortedList[offset ? offset * limit : 0].uuid.toString()
        }
        else {
            assert results.subjects[0].name == orderByString
        }

        where:
        limit  | offset | orderBy     | sortInput      || totalPages | number | numberOfElements | orderByString
        ""     | ""     | ""          | ""             || 1          | 1      | 4                | 'Advanced Placement'
        2      | ""     | ""          | ""             || 2          | 1      | 2                | 'Advanced Placement'
        2      | 2      | ""          | ""             || 2          | 2      | 2                | 'Career and Technical Education'
        ""     | ""     | "desc"      | "subject_uuid" || 1          | 1      | 4                | ''
        2      | ""     | "desc"      | "subject_uuid" || 2          | 1      | 2                | ''
        1      | 1      | "desc"      | "subject_uuid" || 4          | 2      | 1                | ''
        ""     | ""     | "asc"       | "subject_uuid" || 1          | 1      | 4                | ''
        2      | ""     | "asc"       | "subject_uuid" || 2          | 1      | 2                | ''
        1      | 1      | "asc"       | "subject_uuid" || 4          | 2      | 1                | ''

    }

    def "subject GET endpoint test with multiple column sort"(){
        given:

        Subject subject1 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)

        Subject subject2 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject2)

        Subject subject3 = new Subject(name: 'Career and Technical Education', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject3)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when: "multiple columns sorting order with ['DESC,ASC']"


        def url = "/subjects?orderBy=desc,asc&sort=name,subject_uuid"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        def results = response.getBody()


        then:
        assert response.statusCode == HttpStatus.OK
        assert results.subjects[0].name == 'Elective'
        assert results.subjects[1].name == 'Elective'
        assert results.subjects[0].subject_uuid < results.subjects[1].subject_uuid

        when: "multiple columns sorting order with ['DESC,DESC']"

        url = "/subjects?orderBy=desc,desc&sort=name,subject_uuid"

        response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        results = response.getBody()

        then:
        assert response.statusCode == HttpStatus.OK
        assert results.subjects[0].name == 'Elective'
        assert results.subjects[1].name == 'Elective'
        assert results.subjects[0].subject_uuid > results.subjects[1].subject_uuid

    }


    def "subject GET endpoint test for error status code"(){
        given:

        Subject subject1 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)

        Subject subject2 = new Subject(name: 'Elective', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject2)

        Subject subject3 = new Subject(name: 'Career and Technical Education', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject3)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when: "adding invalid operator for filter"

        def url = "/subjects?filter=name;'Blended'"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)


        then:
        assert response.statusCode == HttpStatus.BAD_REQUEST

        when: "adding 'null' string to filter field"
        url = "/subjects?filter=organization_id='null'"

        response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)


        then:
        assert response.statusCode == HttpStatus.BAD_REQUEST

    }

    @Unroll
    def "subject GET endpoint pagination tests"(){
        given:

        def subjects = (1..10).collect {
            subjectRepo.save(new Subject(name: "subj"+it, organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        }

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/subjects?limit=${limit}&offset=${offset}"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        Links links = new Links(response.getHeaders().get("Link")[0])

        then:

        assert first.on == links.links.containsKey("first")
        assert previous.on == links.links.containsKey("previous")
        assert next.on == links.links.containsKey("next")
        assert last.on == links.links.containsKey("last")

        if(first.on){
            assert links.links.get("first").limit == first.l
            assert links.links.get("first").offset == first.o
        }

        if(previous.on){
            assert links.links.get("previous").limit == previous.l
            assert links.links.get("previous").offset == previous.o
        }

        if(next.on){
            assert links.links.get("next").limit == next.l
            assert links.links.get("next").offset == next.o
        }

        if(last.on){
            assert links.links.get("last").limit == last.l
            assert links.links.get("last").offset == last.o
        }

        where:
        limit  | offset || first                   | previous                | next                   | last
        10     | 0      || [on: false]             | [on: false]             | [on: false]            | [on: false]
        10     | 5      || [on: true, l: 10, o: 0] | [on: true, l: 10, o: 0] | [on: false]            | [on: false]
        5      | 0      || [on: false]             | [on: false]             | [on: true, l: 5, o: 5] | [on: true, l: 5, o: 5]
        4      | 4      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
        4      | 6      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 2]  | [on: false]            | [on: false]
        2      | 2      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 4] | [on: true, l: 2, o: 8]
        4      | 5      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 1]  | [on: true, l: 1, o: 9] | [on: true, l: 1, o: 9]
        2      | 5      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 3]  | [on: true, l: 2, o: 7] | [on: true, l: 2, o: 8]

        // TODO: consider revisiting and making prev/first [on: true, l: 3, o: 0] for this case
        5      | 3      || [on: true, l: 5, o: 0]  | [on: true, l: 5, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
    }

    @Unroll
    def "Admin should be able to create custom subjects"() {
        given:
        def body = [
                "name"             : "Test Subject",
                "organization_uuid": school.uuid,
                "disabled"         : disabledStatus
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert subjectsViewRepo.findAll().size() == 1
        SubjectsView actual = subjectsViewRepo.findByOrganizationUuid(school.uuid)
        assert actual.organizationUuid == school.uuid
        assert actual.disabled == disabledStatus
        assert actual.defaultSubject == false

        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.subject_uuid == actual.uuid.toString()
        assert resp.body.organization_uuid == school.uuid.toString()
        assert resp.body.name == actual.name
        assert resp.body.default_subject == false
        assert resp.body.disabled == disabledStatus

        where:
        disabledStatus << [true, false]
    }

    @Unroll
    def "should not be able to create subjects in a different org"() {
        given:
        def body = [
                "name"             : "Test Subject",
                "organization_uuid": school2.uuid,
                "disabled"         : disabledStatus
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED

        where:
        disabledStatus << [true, false]
    }

    def "Teacher and student can not create custom subjects"() {
        given:
        def body = [
                "name"             : "Test Subject",
                "organization_uuid": school.uuid,
                "disabled"         : false
        ]
        String token
        if(user == 'TEACHER') {
            token = createToken(teacher, school.uuid)
        } else if (user == 'STUDENT') {
            token = createToken(student, school.uuid)
        }
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert subjectsViewRepo.findAll().size() == 0

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field == "role_in_issuer"
        assert resp.body.errors.message == "User is not authorized to create subjects"

        where:
        user << ['TEACHER', 'STUDENT']
    }

    def "Verify POST subject with field errors"() {
        given:
        def body = [
                "name"             : "Test Subject",
                "organization_uuid": school.uuid,
                "disabled"         : false
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert subjectsViewRepo.findAll().size() == 0

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field[0] == missingField
        assert resp.body.errors.message[0] == "Missing required field " + missingField

        where:
        missingField << ["name", "disabled"]
    }

    def "Verify duplicate subject names can't be created"() {
        given:
        Subject subject1 = new Subject(name: 'Existing Subject', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)

        def body = [
                "name"             : "Existing Subject",
                "organization_uuid": school.uuid,
                "disabled"         : false
        ]


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert subjectsViewRepo.findAll().size() == 1

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "name", message: "This subject already exists. Please rename this custom subject."]]
    }

    def "Verify duplicate subject names are allowed on different orgs"() {
        given:
        Subject subject1 = new Subject(name: 'Existing Subject', organizationUuid: school2.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)

        def body = [
                "name"             : "Existing Subject",
                "organization_uuid": school.uuid,
                "disabled"         : false
        ]


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.POST, req, Map)

        then:
        assert subjectsViewRepo.findAll().size() == 2

        SubjectsView actual = subjectsViewRepo.findByOrganizationUuid(school.uuid)

        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.subject_uuid == actual.uuid.toString()
        assert resp.body.organization_uuid == school.uuid.toString()
        assert resp.body.default_subject == false
        assert resp.body.disabled == false
    }

    @Unroll
    def "should update subjects"(){
        given:
        Map<String, SubjectsView> subjectMap = setupSubjects()

        subjectMap.put("random", new SubjectsView(uuid:  UUID.randomUUID()))

        def body = [subjects: [
                [
                        "subject_uuid": subjectMap[subject].uuid.toString(),
                        "name": name,
                        "disabled": disabled
                ]
        ]]


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK

        if(expectedErrors){
            assert resp.body.failures.size == 1
            assert resp.body.failures == [
                    [
                            subject_uuid: subjectMap[subject].uuid.toString(),
                            errors: expectedErrors
                    ]
            ]
            if(subject != "random") {
                SubjectsView actual = subjectsViewRepo.findOne(new UuidOrgId((UUID) subjectMap[subject].uuid, school.uuid))
                assert actual.disabled == subjectMap[subject].disabled
                assert actual.name == subjectMap[subject].name
            }
        }
        else {
            assert resp.body.successes.size == 1

            def inputSubject = body.subjects[0]
            assert resp.body.successes.contains([subject_uuid: inputSubject.subject_uuid])

            SubjectsView actual = subjectsViewRepo.findOne(new UuidOrgId(UUID.fromString(inputSubject.subject_uuid), school.uuid))
            assert actual.disabled == inputSubject.disabled
            assert actual.name == inputSubject.name
        }

        assert subjectsViewRepo.findAll().size() == 6

        when:

        String token2 = createToken(admin, school2.uuid)
        headers.setAccept([Constants.SUBJECTS_VERSION_1_MT])
        headers.set("Authorization", "Bearer ${token2}")
        req = new HttpEntity(headers)

        HttpEntity resp2 = testRestTemplate.exchange("/subjects", HttpMethod.GET, req, Map)

        then:
        assert resp2.statusCode == HttpStatus.OK

        def subjects = resp2.body.subjects.findAll{it.organization_uuid == school2.uuid.toString()}
        assert subjects.size() == 2
        assert subjects.every{!it.disabled}

        where:

        subject    | name       | disabled || expectedErrors
        "disabled" | "newName1" | true     || []
        "disabled" | "newName2" | false    || []
        "active"   | "newName3" | true     || []
        "active"   | "newName4" | false    || []
        "default"  | "newName5" | true     || [[field: "name", message: "Default subject names are not editable"]]
        "default"  | "newName6" | false    || [[field: "name", message: "Default subject names are not editable"]]
        "default2" | "newName6" | true     || [[field: "name", message: "Default subject names are not editable"]]
        "default2" | "newName7" | false    || [[field: "name", message: "Default subject names are not editable"]]
        "default"  | "default"  | true     || []
        "default"  | "default"  | false    || []
        "default2" | "default2" | true     || []
        "default2" | "default2" | false    || []
        "disabled" | "active"   | false    || [[field: "name", message: "This subject already exists. Please rename this custom subject."]]
        "disabled" | "default"  | false    || [[field: "name", message: "This subject already exists. Please rename this custom subject."]]
        "random"   | "random"   | false    || [[field: "subject_uuid", message: "Failed to find existing subject"]]
        "disabled" | "newName1" | "yes"    || [[field: "disabled", message: "Invalid value for disabled yes"]]
    }

    @Unroll
    def "should test update subjects missing fields"(){
        Map<String, SubjectsView> subjectMap = setupSubjects()

        def body = [subjects: [
                [
                        "subject_uuid": subjectMap[subject].uuid.toString(),
                        "name": "newName",
                        "disabled": false
                ]
        ]]

        body.subjects[0].remove(missingField)


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK

        assert resp.body.failures.size == 1
        assert resp.body.failures == [
                [
                        subject_uuid: body.subjects[0].subject_uuid,
                        errors: expectedErrors
                ]
        ]
        SubjectsView actual = subjectsViewRepo.findOne(new UuidOrgId((UUID) subjectMap[subject].uuid, school.uuid))
        assert actual.disabled == subjectMap[subject].disabled
        assert actual.name == subjectMap[subject].name

        assert subjectsViewRepo.findAll().size() == 6

        where:

        subject  | missingField   || expectedErrors
        "active" | "subject_uuid" || [[field: "subject_uuid", message: "Failed to find existing subject"]]
        "active" | "name"         || [[field: "name", message: "Missing required field name"]]
        "active" | "disabled"     || [[field: "disabled", message: "Missing required field disabled"]]

    }

    @Unroll
    def "should test multiple subject update"() {
        given:
        Map<String, SubjectsView> subjectMap = setupSubjects()

        def body = [subjects: [
                [
                        "subject_uuid": subjectMap[subject1].uuid.toString(),
                        "name"        : name1,
                        "disabled"    : false
                ],
                [
                        "subject_uuid": subjectMap[subject2].uuid.toString(),
                        "name"        : name2,
                        "disabled"    : false
                ]
        ]]


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK

        assert resp.body.successes.size == success.size()
        if (success) {
            success.eachWithIndex { bodyIndex, respIndex ->
                assert resp.body.successes[respIndex].subject_uuid == body.subjects[bodyIndex].subject_uuid

                UUID uuid = UUID.fromString(resp.body.successes[respIndex].subject_uuid)

                SubjectsView actual = subjectsViewRepo.findOne(new UuidOrgId(uuid, school.uuid))
                assert actual.disabled == body.subjects[bodyIndex].disabled
                assert actual.name == body.subjects[bodyIndex].name
            }
        }

        assert resp.body.failures.size == failure.size()
        if (failure) {
            failure.eachWithIndex { bodyIndex, respIndex ->
                assert resp.body.failures[respIndex].subject_uuid == body.subjects[bodyIndex].subject_uuid
                assert resp.body.failures[respIndex].errors.size == expectedErrors[respIndex].size()
                expectedErrors[respIndex].each { error ->
                    assert resp.body.failures[respIndex].errors.contains(error)
                }
                UUID uuid = UUID.fromString(resp.body.failures[respIndex].subject_uuid)
                SubjectsView expected = subjectMap.find {
                    it.value.uuid == uuid
                }.value

                SubjectsView actual = subjectsViewRepo.findOne(new UuidOrgId(uuid, school.uuid))
                assert expected.name == actual.name
                assert expected.disabled == actual.disabled
            }
        }

        assert subjectsViewRepo.findAll().size() == 6


        where:
        subject1   | name1      | subject2  | name2      | success | failure | expectedErrors
        "disabled" | "newName"  | "active"  | "newName2" | [0,1]   | []      | []
        "disabled" | "newName"  | "active"  | "default"  | [0]     | [1]     | [[[field: "name", message: "This subject already exists. Please rename this custom subject."]]]
        "disabled" | "default"  | "active"  | "newName"  | [1]     | [0]     | [[[field: "name", message: "This subject already exists. Please rename this custom subject."]]]
        "disabled" | "default2" | "default" | "newName2" | []      | [0,1]   | [[[field: "name", message: "This subject already exists. Please rename this custom subject."]], [[field: "name", message: "Default subject names are not editable"]]]
    }

    def "should be able to update subject multiple times"() {
        given:
        Map<String, SubjectsView> subjectMap = setupSubjects()

        def body = [subjects: [
                [
                        "subject_uuid": subjectMap["active"].uuid.toString(),
                        "name": "new name 1",
                        "disabled": true
                ]
        ]]

        def body2 = [subjects: [
                [
                        "subject_uuid": subjectMap["active"].uuid.toString(),
                        "name": "new name 2",
                        "disabled": false
                ]
        ]]

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity req2 = new HttpEntity(body2, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.successes.size() == 1
        assert resp.body.failures.size() == 0

        when:
        HttpEntity resp2 = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req2, Map)

        then:
        assert resp2.statusCode == HttpStatus.OK
        assert resp2.body.successes.size() == 1
        assert resp2.body.failures.size() == 0
    }

    @Unroll
    def "should not be able to update subject in different org"(){
        Subject otherOrg = new Subject(name: 'otherOrg', organizationUuid: school2.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(otherOrg)

        def body = [subjects: [
                [
                        "subject_uuid": otherOrg.uuid.toString(),
                        "name": "newName",
                        "disabled": false
                ]
        ]]

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.SUBJECTS_VERSION_1_MT)
        headers.setAccept([Constants.SUBJECTS_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/subjects", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK

        assert resp.body.failures.size == 1
        assert resp.body.failures == [
                [
                        subject_uuid: body.subjects[0].subject_uuid,
                        errors: [[
                                field: "subject_uuid",
                                message: "Failed to find existing subject"
                        ]]
                ]
        ]
    }


    private Map<String, SubjectsView> setupSubjects(){
        DefaultSubject defaultSubject = new DefaultSubject(uuid: UUID.randomUUID(), name: 'default', createdAt: new Date(), updatedAt: new Date())
        defaultSubjectRepo.save(defaultSubject)
        DefaultSubject defaultDisabled = new DefaultSubject(uuid: UUID.randomUUID(), name: 'default2', createdAt: new Date(), updatedAt: new Date())
        defaultSubjectRepo.save(defaultDisabled)

        Subject subject1 = new Subject(name: 'disabled', organizationUuid: school.uuid, disabled: true, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(subject1)
        Subject activeSubject = new Subject(name: 'active', organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date())
        subjectRepo.save(activeSubject)

        DisabledSubject disabledSubject = new DisabledSubject(uuid: subject1.uuid, organizationUuid: school.uuid, createdAt: new Date(), updatedAt: new Date())
        disabledSubjectRepo.save(disabledSubject)
        DisabledSubject disabledDefaultSubject = new DisabledSubject(uuid: defaultDisabled.uuid, organizationUuid: school.uuid, createdAt: new Date(), updatedAt: new Date())
        disabledSubjectRepo.save(disabledDefaultSubject)

        return subjectsViewRepo.findAll().findAll(){it.organizationUuid == school.uuid}.collectEntries{[(it.name):it]}
    }
}
