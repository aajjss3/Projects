package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptSave
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.PageRepo
import com.glynlyon.kl.classroom.repo.SettingRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.embedded.LocalServerPort
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll
import java.text.SimpleDateFormat



class PageControllerIntegrationSpec extends BaseRestSpec {
	
    @LocalServerPort
    Integer port

    @Autowired
    ClassRepo classRepo

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    ClassGradeLevelRepo gradeLevelRepo

    @Autowired
    ClassGradeLevelService gradeLevelIdService

    @Autowired
    UserRepo userRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    PageRepo pageRepo

    @Autowired
    SettingRepo settingRepo

    @Autowired
    SubjectsService subjectsService

    @Value('${rostering.base.uri}')
    String rosteringBaseUri
	
	Date now = new Date()
	SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
	// convert a java date to a json iso formatted date
	String nowAsISODate = (new StringBuilder(dateFormatter.format(now)).insert( dateFormatter.format(now).length()-2, ':')).toString()



    User admin, teacher, teacher2, student, student2, unenrolledStudent, bran, sansa, arya
    Organization school, school2, campus1, campus2

    def setup(){
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        campus1 = organizationRepo.save(new Organization(name: 'campus1', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))
        campus2 = organizationRepo.save(new Organization(name: 'campus2', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))

        bran = userRepo.save(new User(firstName: 'bran', lastName: 'stark', userName: 'bstark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        sansa = userRepo.save(new User(firstName: 'sansa', lastName: 'stark', userName: 'sstark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        arya = userRepo.save(new User(firstName: 'arya', lastName: 'stark', userName: 'astark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))

        teacher = userRepo.save(new User(firstName: 'some', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))
        teacher2 = userRepo.save(new User(firstName: 'another', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus1]))

        student = userRepo.save(new User(firstName: 'some', lastName: 's', userName: 'studnet', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus2]))
        student2 = userRepo.save(new User(firstName: 'another', lastName: 'student', userName: 'stud net 2', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus2]))
        unenrolledStudent = userRepo.save(new User(firstName: 'unenrolled', lastName: 'student', userName: 'unenS', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus2]))

        def schoolSettingValue = [admin: [override: true], classroom: [lessons: [threshold: 70, attempts: 2],	projects: [threshold: 70, attempts: 2],grade_display: [percentage: true, letter: false], grade_scale: [A:90,B:80,C:70,D:60]]]
        settingRepo.save(new Setting(sourceUUID: null, value: schoolSettingValue, type: SettingType.GLOBAL, version: 0) )

        PageObj.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return pageRepo.save(delegate)
        }
    }

    @Unroll
    def "test get pages by user"(){
        given:
        ClassObj classObj1 = setupValidClass(admin, campus1)
        ClassObj classObj2 = setupValidClass(admin, campus2)
        Map<String, PageObj> pages = [page1: setupValidPageWithDueDate("Page 1", classObj1, now), page2: setupValidPageWithDueDate("Page 2", classObj2, now)]
        PageAssignment page1Assignment1 = setupValidPageAssignment("page1Assignment1",pages.page1,1,null)
        PageAssignment page1Assignment2 = setupValidPageAssignment("page1Assignment2",pages.page1,2,null)
        PageAssignment page1Assignment3 = setupValidPageAssignment("page1Assignment3",pages.page1,3,null)
        Map<String,List<PageAssignment>> expectedPageAssignments = [(pages.page1.name):[page1Assignment1,page1Assignment2,page1Assignment3] as List]
        Map<String, User> users = [admin: admin, teacher: teacher, student: student]

        if(enroll) {
            if(user == "teacher"){
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj1, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
            }
            else {
                enrollmentRepo.save(new Enrollment(user: users[user], classObj: classObj2, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            }
        }

        String token = createToken(users[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedPages.collect{pages[it].uuid.toString()}
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.pages.size == expectedUuids.size()
        if(expectedPages) {
            resp.body.pages.each { p ->
                assert expectedUuids.contains(p.page_uuid)
            }

            expectedPages.collect { pages[it] }.each { page ->
                def responseClass = resp.body.pages.find { it.page_uuid == page.uuid.toString() }
                def expectedClass = [
                        "class_uuid": page.classObj.uuid.toString(),
                        "name"      : page.classObj.name,
                        "_links"    : [
                                "self": ["href": "http://localhost:" + port + "/classes/" + page.classObj.uuid.toString()]
                        ]
                ]
				
				assert resp.body.pages[0].due_date == nowAsISODate
                assert page.name == responseClass.name
                assert page.sequence == responseClass.sequence
                assert page.type == responseClass.type
                assert page.status == responseClass.status as PageState
                assert expectedClass == responseClass.class
                if(expectedPageAssignments.get(page.name)) {
                    assert responseClass.page_assignments*.page_assignment_uuid == expectedPageAssignments.get(page.name)?.sort{it.sequence}?.uuid*.toString()
                } else {
                    assert responseClass.page_assignments == []
                }

            }
        }

        where:
        user      | enroll || expectedPages
        "admin"   | false  || ["page1", "page2"]
        "teacher" | false  || []
        "teacher" | true   || ["page1"]
        "student" | false  || []
        "student" | true   || ["page2"]


    }

    def "test user can not access pages from a different org"(){
        given:
        Organization school2 = new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date())
        organizationRepo.save(school2)

        def classObj = setupValidClass("Class 1")
        def classObj2 = setupValidClass("Class 2", [Grade.FOUR, Grade.THREE, Grade.EIGHT], school2)

        def page1 = setupValidPage("Page 1 Class 1", classObj)
        def page2 = setupValidPage("Page 1 Class 2", classObj2)


        String token = createToken(admin, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = [page2.uuid].collect{it.toString()}
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.pages.size == expectedUuids.size()
        resp.body.pages.each { p ->
            assert expectedUuids.contains(p.page_uuid)
        }

        def responseClass = resp.body.pages.find { it.page_uuid == page2.uuid.toString() }
        def expectedClass = [
                "class_uuid" : page2.classObj.uuid.toString(),
                "name" : page2.classObj.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/classes/"+page2.classObj.uuid.toString()]
                ]
        ]
        def expectedPageAssignments = []
        assert page2.name == responseClass.name
        assert page2.sequence == responseClass.sequence
        assert page2.type == responseClass.type
        assert page2.status == responseClass.status as PageState
        assert expectedClass == responseClass.class
        assert expectedPageAssignments == responseClass.page_assignments
    }

    def "test get pages with sorting"(){
        given:
        ClassObj classObj = setupValidClass("classTest")
        List<PageObj> pages = setupPagesForSorting(sort, classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == pages.size()

        PageObj expectedFirstPage = pages.find { it.name == expectedFirstPageName}

        def responseClass = resp.body.pages[0]

        assert responseClass.name == expectedFirstPage.name

        where:

        sort                                     | dir              || expectedFirstPageName
        "name"                                   | "asc"            || "a page name"
        "name"                                   | "desc"           || "z page name"
        "sequence"                               | "asc"            || "sequenceFirst"
        "sequence"                               | "desc"           || "sequenceSecond"
        "status"                                 | "asc"            || "stateFirst"
        "status"                                 | "desc"           || "stateLast"
        "type"                                   | "asc"            || "typeFirst"
        "type"                                   | "desc"           || "typeLast"
        "class.name"                             | "asc"            || "classFirst"
        "class.name"                             | "desc"           || "classLast"
        "class.class_uuid"                       | "asc"            || "classFirst"
        "class.class_uuid"                       | "desc"           || "classLast"

    }

    def "test get pages with sorting failures"(){
        given:
        ClassObj classObj = setupValidClass("classTest")
        List<PageObj> pages = setupPagesForSorting(sort, classObj)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == 1

        def responseError = resp.body.errors

        assert responseError.field[0] == 'sort'
        assert responseError.message[0] == expectedError

        where:

        sort                                     | dir              || expectedError
        "badfield"                               | "asc"            || "invalid sort field 'badfield'"
        "class.test"                             | "desc"           || "invalid sort field 'class.test'"
    }

	@Unroll
    def "test get pages with filtering"(){
        given:
        ClassObj classObj = setupValidClass("classTest")
        List<PageObj> pageList = setupPagesForSorting(field, classObj)
        Map<String, PageObj> pages = pageList.collectEntries{[(it.name):it]}

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        UUID tempUuid = UUID.randomUUID()

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        List<String> expectedUuids = expectedNames.collect{pages[it].uuid.toString()}
        checkPageResponse(resp, expectedUuids, pages)

        where:
        field                                    | filter                                                   | expectedNames
		"name"                                   | "name='z page name'"                                     | ['z page name']
		"name"                                   | "namecontains'name'"                                     | ['z page name', 'a page name']
		"name"                                   | "name='z page name' OR name='a page name'"               | ['a page name', 'z page name']
        "sequence"                               | "sequence='2'"                                           | ['sequenceSecond']
        "sequence"                               | "sequence='2' AND class.name='classTest'"              | ['sequenceSecond']
        "status"                                 | "status='INACTIVE'"                                      | ['stateLast']
        "type"                                   | "type='CONCEPT'"                                         | ['typeFirst']
        "class.name"                             | "class.name='class2'"                                 | ['classLast']

    }


    def "test get pages with filtering failures"(){
        given:
        ClassObj classObj = setupValidClass("classTest")

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == 1

        def responseError = resp.body.errors

        assert responseError.field[0] == "filter - ${filter}"
        assert responseError.message[0] == expectedError

        where:

        filter                                          || expectedError
        "badfilter"                                     || "Invalid filter badfilter"
        "class.test"                                    || "Invalid filter class.test"
    }

    def "should create a page using required fields"() {
        def classObj = setupValidClass()

        def body = [
                "class_uuid"             : classObj.uuid.toString(),
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
                "sequence"               : 1
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))

        checkCreateUpdateResponse(uuid, resp, body, 1)
    }
	
	def "should create a page with a due date"() {
		def classObj = setupValidClass()
		String dueDate = "2016-10-17T17:00:00-07:00"

		def body = [
				"class_uuid"             : classObj.uuid.toString(),
				"name"                   : "Test Page",
				"status"                 : "ACTIVE",
				"sequence"               : 1,
				"due_date"				 : dueDate
		]
		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setContentType(Constants.PAGES_VERSION_1_MT)
		headers.setAccept([Constants.PAGES_VERSION_1_MT])
		HttpEntity req = new HttpEntity(body, headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

		then:

		assert resp.statusCode == HttpStatus.CREATED
		assert resp.body.due_date == dueDate
	}

    def "should create a page and sequence correctly when user inputs high sequence number"() {
        def classObj = setupValidClass()
        PageObj existingPage1 = new PageObj(classObj: classObj, sequence: 1, name: "Page 1", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date(), updatedAt: new Date())
        PageObj existingPage2 = new PageObj(classObj: classObj, sequence: 2, name: "Page 2", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date(), updatedAt: new Date())
        pageRepo.save(existingPage1)
        pageRepo.save(existingPage2)

        def body = [
                "class_uuid"             : classObj.uuid.toString(),
                "name"                   : "Test Page 500",
                "status"                 : "ACTIVE",
                "sequence"               : 500
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        checkCreateUpdateResponse(uuid, resp, body, 3)
    }

    def "Sequences should be updated when user inputs a sequence number before other numbers"() {
        def classObj = setupValidClass()
        PageObj existingPage = new PageObj(classObj: classObj, sequence: 1, name: "Old Page 1", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date(), updatedAt: new Date())
        pageRepo.save(existingPage)

        def body = [
                "class_uuid"             : classObj.uuid.toString(),
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
                "sequence"               : 1
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        PageObj actual = pageRepo.findByUuid(uuid)

        // Assert the new page is Sequence 1
        assert actual != null
        assert actual.sequence == body.sequence
        assert resp.body.sequence == body.sequence

        //Assert the old page is now Sequence 2
        PageObj oldPage = pageRepo.findByUuid(existingPage.uuid)
        assert oldPage.sequence == 2
    }

    def "Pages should be sequenced correctly when a new page is inserted in the middle"() {
        def classObj = setupValidClass()
        PageObj existingPage1 = new PageObj(classObj: classObj, sequence: 1, name: "Page 1", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date(), updatedAt: new Date())
        PageObj existingPage2 = new PageObj(classObj: classObj, sequence: 2, name: "Old Page 2", type: 'CONCEPT', status: PageState.ACTIVE, createdAt: new Date(), updatedAt: new Date())
        pageRepo.save(existingPage1)
        pageRepo.save(existingPage2)

        def body = [
                "class_uuid"             : classObj.uuid.toString(),
                "name"                   : "New Page 2",
                "status"                 : "ACTIVE",
                "sequence"               : 2
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.CREATED
        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        PageObj actual = pageRepo.findByUuid(uuid)

        // Assert the new page is Sequence 1
        assert actual != null
        assert actual.sequence == body.sequence
        assert resp.body.sequence == body.sequence

        //Assert page 1 has not changed
        PageObj oldPage = pageRepo.findByUuid(existingPage1.uuid)
        assert oldPage.sequence == 1

        //Assert Page 2 is now page 3
        PageObj oldPage2 = pageRepo.findByUuid(existingPage2.uuid)
        assert oldPage2.sequence == 3
    }

    def "should fail to create a page without required fields"() {
        def classObj = setupValidClass()

        def body = [
                "class_uuid"             : classObj.uuid.toString(),
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
                "sequence"               : 1
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:missingField,message: expectedMessage]]]
        assert expected == resp.body

        where:
        missingField            | expectedMessage
        "class_uuid"            | "Missing required field class_uuid"
        "status"                | "Missing required field status"
        "sequence"              | "Invalid or missing field sequence number."
    }

    def "should fail to create a page with an invalid class ID"() {
        def classObj = setupValidClass()
        String randomUUID = UUID.randomUUID().toString()

        def body = [
                "class_uuid"             : randomUUID,
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
                "sequence"               : 1
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages", HttpMethod.POST, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field: 'class_uuid' ,message: "Could not find class with uuid ${randomUUID}"]]]
        assert expected == resp.body

    }

    def "should update page"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj existing = setupValidPage("some page", classObj)

        def body = [
                "name"                   : "Test Page",
                "status"                 : "INACTIVE"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${existing.uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        assert pageRepo.findAll().size() == 1

        checkCreateUpdateResponse(existing.uuid, resp, body, 1, existing)
    }

    @Unroll
    def "should fail to update a page without required fields"() {
        ClassObj classObj = setupValidClass(admin, school)
        PageObj existing = setupValidPage("some page", classObj)

        def body = [
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${existing.uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:missingField,message: expectedMessage]]]
        assert expected == resp.body

        where:
        missingField            | expectedMessage
        "status"                | "Missing required field status"
    }

    @Unroll
    def "should fail to update a page in different org"() {
        ClassObj classObj = setupValidClass(admin, school)
        PageObj existing = setupValidPage("some page", classObj)

        def body = [
                "name"                   : "Test Page",
                "status"                 : "ACTIVE",
        ]

        String token = createToken(admin, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${existing.uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [errors:[[field:"sub / school_uuid",message: "Could not find page " + existing.uuid.toString() + " in organization " + school2.uuid.toString()]]]
        assert expected == resp.body
    }

    @Unroll
    def "should update a page without optional field"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj existing = setupValidPage("some page", classObj)

        def body = [
                "name"                   : nameValue,
                "status"                 : "INACTIVE"
        ]

        if(nameValue == "missing"){
            body.remove("name")
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${existing.uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        pageRepo.findAll().size() == 1

        PageObj actual = pageRepo.findAll().first()

        assert resp.body.name == expectedName
        assert actual.name == expectedName

        where:
        nameValue | expectedName
        "missing" | null
        null      | null
        ""        | null
        " "       | null
    }

    @Unroll
    def "should complete a page"() {
        given:
        ClassObj class1 = setupValidClass(admin, school)

        [sansa, arya, bran].each {
            createEnrollment(class1, it, Role.STUDENT)
        }

        PageObj page1 = setupValidPage("page1", class1, 1)
        PageObj page2 = setupValidPage("page2", class1, 2)

        PageAssignment p1pa1 = setupValidPageAssignment("p1pa1", page1, 1)
        PageAssignment p1pa2 = setupValidPageAssignment("p1pa2", page1, 2)
        PageAssignment p1pa3 = setupValidPageAssignment("p1pa3", page1, 3)
        PageAssignment p1pa4 = setupValidPageAssignment("p1pa4", page1, 4)
        PageAssignment p1pa5 = setupValidPageAssignment("p1pa5", page1, 5)
        PageAssignment p1pa6 = setupValidPageAssignment("p1pa6", page1, 6)
        PageAssignment p2pa1 = setupValidPageAssignment("p2pa1", page2, 1)
        PageAssignment p2pa2 = setupValidPageAssignment("p2pa2", page2, 2)

        PlannerEntry peA1 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa1, arya)
        PlannerEntry peA2 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa2, arya)
        PlannerEntry peA3 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa3, arya)
        PlannerEntry peA4 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa4, arya)
        PlannerEntry peA5 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa5, arya)
        PlannerEntry peA6 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa6, arya)
        PlannerEntry peA21 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa1, arya)
        PlannerEntry peA22 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa2, arya)
        
        PlannerEntry peB1 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa1, bran)
        PlannerEntry peB2 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa2, bran)
        PlannerEntry peB3 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa3, bran)
        PlannerEntry peB4 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa4, bran)
        PlannerEntry peB5 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa5, bran)
        PlannerEntry peB6 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa6, bran)
        PlannerEntry peB21 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa1, bran)
        PlannerEntry peB22 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa2, bran)

        PlannerEntry peS1 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa1, sansa)
        PlannerEntry peS2 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa2, sansa)
        PlannerEntry peS3 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa3, sansa)
        PlannerEntry peS4 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa4, sansa)
        PlannerEntry peS5 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa5, sansa)
        PlannerEntry peS6 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa6, sansa)
        PlannerEntry peS21 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa1, sansa)
        PlannerEntry peS22 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa2, sansa)

        def peMap = [
                peA1: peA1,
                peA2: peA2,
                peA3: peA3,
                peA4: peA4,
                peA5: peA5,
                peA6: peA6,
                peA21: peA21,
                peA22: peA22,
                peB1: peB1,
                peB2: peB2,
                peB3: peB3,
                peB4: peB4,
                peB5: peB5,
                peB6: peB6,
                peB21: peB21,
                peB22: peB22,
                peS1: peS1,
                peS2: peS2,
                peS3: peS3,
                peS4: peS4,
                peS5: peS5,
                peS6: peS6,
                peS21: peS21,
                peS22: peS22,
        ]
        
        Attempt a1 = setupAttemptByDate(peA1, arya, cdate(0), AttemptState.FAILED, 0.1, null, null, false) //will be latest, pe->GRADED
        Attempt a2 = setupAttemptByDate(peA1, arya, cdate(1), AttemptState.IN_PROGRESS, null, null, null, true) //will be deleted
        Attempt a3 = setupAttemptByDate(peA2, arya, cdate(2), AttemptState.PASSED, 0.9, null, null, false) //will be latest, pe->GRADED
        Attempt a4 = setupAttemptByDate(peA2, arya, cdate(3), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt a5 = setupAttemptByDate(peA3, arya, cdate(4), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a6 = setupAttemptByDate(peA3, arya, cdate(5), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt a7 = setupAttemptByDate(peA4, arya, cdate(6), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a8 = setupAttemptByDate(peA4, arya, cdate(7), AttemptState.PASSED, 1.0, null, null, true) //will be latest, pe->GRADED
        Attempt a9 = setupAttemptByDate(peA5, arya, cdate(8), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a10 = setupAttemptByDate(peA5, arya, cdate(9), AttemptState.FAILED, 0.2, null, null, true) //will be latest, pe->GRADED
        Attempt a21 = setupAttemptByDate(peA21, arya, cdate(10), AttemptState.FAILED, 0.2, null, null, true) //will be latest, pe->GRADED
        Attempt a22 = setupAttemptByDate(peA22, arya, cdate(11), AttemptState.FAILED, 0.4, null, null, true) //will be latest, pe->GRADED

        
        Attempt b1 = setupAttemptByDate(peB1, bran, cdate(12), AttemptState.IN_PROGRESS, null, null, null, false) //will be deleted
        Attempt b2 = setupAttemptByDate(peB1, bran, cdate(13), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b3 = setupAttemptByDate(peB2, bran, cdate(14), AttemptState.SAVED, null, null, null, false) //will be deleted
        Attempt b4 = setupAttemptByDate(peB2, bran, cdate(15), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b5 = setupAttemptByDate(peB3, bran, cdate(16), AttemptState.SUBMITTED, null, null, null, false)
        Attempt b6 = setupAttemptByDate(peB3, bran, cdate(17), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b7 = setupAttemptByDate(peB4, bran, cdate(18), AttemptState.PASSED, 0.9, null, null, false)
        Attempt b8 = setupAttemptByDate(peB4, bran, cdate(19), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b9 = setupAttemptByDate(peB5, bran, cdate(20), AttemptState.SUBMITTED, null, null, null, false) //will be latest, pe->COMPLETED
        Attempt b10 = setupAttemptByDate(peB5, bran, cdate(21), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt b21 = setupAttemptByDate(peB21, bran, cdate(22), AttemptState.PASSED, 0.8, null, null, true) //will be latest, pe->GRADED
        Attempt b22 = setupAttemptByDate(peB22, bran, cdate(23), AttemptState.IN_PROGRESS, null, null, null, true) //will be deleted

        //every status
        Attempt s1 = setupAttemptByDate(peS1, sansa, cdate(24), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt s2 = setupAttemptByDate(peS2, sansa, cdate(25), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt s3 = setupAttemptByDate(peS3, sansa, cdate(26), AttemptState.FAILED, 0.4, null, null, true) //will be latest, pe->GRADED
        Attempt s4 = setupAttemptByDate(peS4, sansa, cdate(27), AttemptState.PASSED, 0.8, null, null, true) //will be latest, pe->GRADED
        Attempt s5 = setupAttemptByDate(peS5, sansa, cdate(28), AttemptState.IN_PROGRESS, null, null, null, true) //will be deleted
        Attempt s21 = setupAttemptByDate(peS21, sansa, cdate(29), AttemptState.PASSED, 0.75, null, null, true) //will be latest, pe->GRADED
        Attempt s22 = setupAttemptByDate(peS22, sansa, cdate(30), AttemptState.FAILED, 0.25, null, null, true) //will be latest, pe->GRADED

        def attemptMap = [
                a1 : a1,
                a2 : a2,
                a3 : a3,
                a4 : a4,
                a5 : a5,
                a6 : a6,
                a7 : a7,
                a8 : a8,
                a9 : a9,
                a10: a10,
                a21: a21,
                a22: a22,
                b1 : b1,
                b2 : b2,
                b3 : b3,
                b4 : b4,
                b5 : b5,
                b6 : b6,
                b7 : b7,
                b8 : b8,
                b9 : b9,
                b10: b10,
                b21: b21,
                b22: b22,
                s1 : s1,
                s2 : s2,
                s3 : s3,
                s4 : s4,
                s5 : s5,
                s21: s21,
                s22: s22,
        ]

        attemptMap.values().each {
            attemptSaveRepo.save(
                    new AttemptSave(
                            attempt: it,
                            sequence: 1,
                            sectionsViewed: ["1", "2"],
                            questionsViewed: ["1", "3", "4"],
                            timeOnTaskSeconds: 54,
                            createdAt: new Date(),
                            createdBy: it.user.uuid
                    )
            )
        }

        def pageMap = [
                page1: page1,
                page2: page2
        ]


        def body = [
                "name"  : pageMap[pageId].name,
                "status": "COMPLETED"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageMap[pageId].uuid}", HttpMethod.PUT, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.name == pageMap[pageId].name
        assert resp.body.status == "COMPLETED"
        assert resp.body.completed_date != null
        assert pageRepo.findAll().size() == 2

        List<Attempt> attempts = attemptRepo.findAll().asList()
        def expectedAttempts = attemptMap.keySet() - deletedAttempts

        assert attempts.size() == expectedAttempts.size()
        expectedAttempts.each {
            assert attempts.uuid.contains(attemptMap[it].uuid)
        }

        List<PlannerEntry> pes = plannerEntryRepo.findAll().asList()
        def regPe = peMap.keySet() - gradedPe - completedPe - deletedPe
        regPe.each { peId ->
            assert pes.uuid.contains(peMap[peId].uuid)
            assert pes.find{it.uuid == peMap[peId].uuid}.status == PlannerEntryState.IN_PROGRESS
        }

        if(gradedPe) {
            gradedPe.each { peId ->
                assert pes.uuid.contains(peMap[peId].uuid)
                assert pes.find { it.uuid == peMap[peId].uuid }.status == PlannerEntryState.GRADED
            }
        }

        if(completedPe) {
            completedPe.each { peId ->
                assert pes.uuid.contains(peMap[peId].uuid)
                assert pes.find { it.uuid == peMap[peId].uuid }.status == PlannerEntryState.COMPLETED
            }
        }

        if(deletedPe) {
            deletedPe.each { peId ->
                assert pes.every { it.uuid != peMap[peId].uuid }
            }
        }

        attemptRepo.findAll().groupBy {it.plannerEntry}.each { group ->
            def latest = group.value.max{it.createdAt}
            group.value.each { attempt ->
                if(attempt.uuid == latest.uuid){
                    assert attempt.creditBearing
                }
                else {
                    assert !attempt.creditBearing
                }
            }
        }

        where:
        pageId  | deletedAttempts                             | gradedPe                                         | completedPe                                              | deletedPe
        'page1' | ['a2', 'a4', 'b1', 'b3', 'b10', 's1', 's5'] | ['peA1', 'peA2', 'peA4', 'peA5', 'peS3', 'peS4'] | ['peA3', 'peB1', 'peB2', 'peB3', 'peB4', 'peB5', 'peS2'] | ['peA6', 'peB6', 'peS1', 'peS5', 'peS6']
        'page2' | ['b22']                                     | ['peA21', 'peA22', 'peB21', 'peS21', 'peS22']    | []                                                       | ['peB22']
    }

    @Unroll
    def "should get attempts by page uuid"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)

        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student2, classObj: classObj, role: Role.STUDENT, status: Status.ACTIVE))

        PageObj pageObj = setupValidPage("some page", classObj)
        PageAssignment pageAssignment1 = setupValidPageAssignment("pa 1", pageObj, 1)
        PageAssignment pageAssignment2 = setupValidPageAssignment("pa 2", pageObj, 2)

        PlannerEntry planner1s1 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment1, student)
        PlannerEntry planner2s1 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment2, student)
        PlannerEntry planner1s2 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment1, student2)
        PlannerEntry planner2s2 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment2, student2)
        PlannerEntry plannerU = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment2, unenrolledStudent)

        Map<String, List> attemptMap = [
                attempt1 : [setupAttemptByDate(planner1s1, student, cdate(0), AttemptState.FAILED), 1],
                attempt2 : [setupAttemptByDate(planner1s1, student, cdate(1), AttemptState.SUBMITTED), 2],
                attempt3 : [setupAttemptByDate(planner2s1, student, cdate(2), AttemptState.PASSED), 1],
                attempt4 : [setupAttemptByDate(planner1s2, student2, cdate(3), AttemptState.FAILED), 1],
                attempt5 : [setupAttemptByDate(planner2s2, student2, cdate(4), AttemptState.FAILED), 1],
                attempt6 : [setupAttemptByDate(planner2s2, student2, cdate(5), AttemptState.IN_PROGRESS), 2],
                attempt7 : [setupAttemptByDate(plannerU, unenrolledStudent, cdate(6), AttemptState.PASSED), 1]
        ]

        Map<String, User> userMap = [
                student: student,
                enrolledTeacher: teacher,
                someOtherTeacher: teacher2,
                admin: admin
        ]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ATTEMPTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/attempts?latest_attempt=${latest}", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.OK) {
            assert resp.body.attempts.size == expectedResults.size()

            DateFormat dateFormat = new DateFormat()

            def expectedAttempts = expectedResults.withIndex().collect { key, index ->
                Attempt a = attemptMap[key][0]
                Integer num = attemptMap[key][1]
                return [
                        user_uuid : a.user.uuid.toString(),
                        page_assignment_uuid : a.activityId.toString(),
                        planner_entry_uuid : a.plannerEntry.uuid.toString(),
                        planner_entry_status : a.plannerEntry.status.toString(),
                        attempt_uuid : a.uuid.toString(),
                        state : a.state.toString(),
                        status : a.state.toString(),
                        assessment_score : a.assessmentScore,
                        earned_score : [value:a.assessmentScore],
                        completed_at : dateFormat.format(a.completedAt),
                        attempt_number : num
                ]
            }

            assert resp.body.attempts.containsAll(expectedAttempts)
        }

        where:
        user               | latest || expectedStatus          | expectedResults
        'admin'            | true   || HttpStatus.OK           | ["attempt2", "attempt3", "attempt4", "attempt6"]
        'admin'            | false  || HttpStatus.OK           | ["attempt1", "attempt2", "attempt3", "attempt4", "attempt5", "attempt6"]
        'enrolledTeacher'  | true   || HttpStatus.OK           | ["attempt2", "attempt3", "attempt4", "attempt6"]
        'enrolledTeacher'  | false  || HttpStatus.OK           | ["attempt1", "attempt2", "attempt3", "attempt4", "attempt5", "attempt6"]
        'someOtherTeacher' | true   || HttpStatus.NOT_FOUND    | []
        'someOtherTeacher' | false  || HttpStatus.NOT_FOUND    | []
        'student'          | true   || HttpStatus.FORBIDDEN    | []
        'student'          | false  || HttpStatus.FORBIDDEN    | []
    }

    @Unroll
    def "should get attempts by page uuid with correct earned scores"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        settingRepo.save(new Setting(sourceUUID: classObj.uuid, value: [admin: [override: true],
             classroom: [lessons: [threshold: 50, attempts: 50],	projects: [threshold: 50, attempts: 50],
             grade_display: gradeDisplay, grade_scale: [A:90,B:80,C:70,D:60]]], type: SettingType.CLASS, version: 0) )

        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, role: Role.STUDENT, status: Status.ACTIVE))

        PageObj pageObj = setupValidPage("some page", classObj)
        PageAssignment pageAssignment1 = setupValidPageAssignment("pa 1", pageObj, 1)

        PlannerEntry planner1s1 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment1, student)

        Map<String, List> attemptMap = [
                attempt1 : [setupAttemptByDate(planner1s1, student, cdate(0), AttemptState.PASSED, attemptScore)],
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ATTEMPTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/attempts?latest_attempt=true", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        assert resp?.body?.attempts[0]?.earned_score == expectedEarnedScore


        where:
        gradeDisplay                      | attemptScore  |  expectedEarnedScore
        [letter: true, percentage: true]  | 1             | [grade:'A', value:1.0]
        [letter: true, percentage: true]  | 0.88          | [grade:'B', value:0.88]
        [letter: true, percentage: true]  | 0.75          | [grade:'C', value:0.75]
        [letter: true, percentage: true]  | 0.63          | [grade:'D', value:0.63]
        [letter: true, percentage: true]  | 0.5           | [grade:null, value:0.5]
        [letter: true, percentage: true]  | 0.0           | [grade:null, value:0.0]
        [letter: true, percentage: false] | 0.94          | [grade:'A']
        [letter: true, percentage: false] | null          | null
        [letter: false, percentage: true] | null          | null
    }

    @Unroll
    def "should filter attempts by page uuid"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        //enroll the kids in the class
        enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student2, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        PageObj pageObj = setupValidPage("some page", classObj)
        PageAssignment pageAssignment1 = setupValidPageAssignment("pa 1", pageObj, 1)
        PageAssignment pageAssignment2 = setupValidPageAssignment("pa 2", pageObj, 2)
        PageAssignment pageAssignment3 = setupValidPageAssignment("pa 3", pageObj, 3)

        PlannerEntry planner1s1 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment1, student)
        PlannerEntry planner2s1 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment2, student)
        PlannerEntry planner1s2 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment1, student2)
        PlannerEntry planner2s2 = setupPlannerEntry(0, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment2, student2)
        PlannerEntry planner3s2 = setupPlannerEntry(0, PlannerEntryState.OBE, classObj, pageObj, pageAssignment3, student2)

        PlannerEntry plannerDeletedPageAssignment = setupPlannerEntryWithoutPA(0, PlannerEntryState.GRADED, classObj, pageObj,student2)

        Map<String, Attempt> attemptMap = [
                attempt1 : setupAttemptByDate(planner1s1, student, cdate(0), AttemptState.FAILED, 0),
                attempt2 : setupAttemptByDate(planner1s1, student, cdate(1), AttemptState.SUBMITTED, null),
                attempt3 : setupAttemptByDate(planner2s1, student, cdate(2), AttemptState.PASSED, 1),
                attempt4 : setupAttemptByDate(planner1s2, student2, cdate(3), AttemptState.FAILED, 0),
                attempt5 : setupAttemptByDate(planner2s2, student2, cdate(4), AttemptState.FAILED, 0),
                attempt6 : setupAttemptByDate(planner2s2, student2, cdate(5), AttemptState.IN_PROGRESS, null),
                attempt7 : setupAttemptByDate(planner3s2, student2, cdate(6), AttemptState.IN_PROGRESS, null),
                attempt8 : setupAttemptByDate(plannerDeletedPageAssignment, student2, cdate(7), AttemptState.FAILED, 0),
        ]

        filter = filter.replace("STUDENT_UUID", student.uuid.toString())
        filter = filter.replace("PA1_UUID", pageAssignment1.uuid.toString())
        filter = filter.replace("PE1_UUID", planner1s1.uuid.toString())
        filter = filter.replace("ATTEMPT1_UUID", attemptMap["attempt1"].uuid.toString())

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGE_ATTEMPTS_VERSION_1_MT)
        headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        String queryString = "?filter=${filter}&latest_attempt=${latest}"
        if(includeOBE){
            queryString = queryString + "&include_obe=true"
        }

        when:
        HttpEntity resp = testRestTemplate.exchange("/pages/${pageObj.uuid}/attempts${queryString}", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.attempts.size == expectedResults.size()

        if(expectedResults) {
            expectedResults.each {
                assert resp.body.attempts.attempt_uuid.contains(attemptMap[it].uuid.toString())
            }
        }

        where:
        latest   | filter                                       | includeOBE | expectedResults
        false    | "user_uuid='STUDENT_UUID'"                   | false      | ["attempt1", "attempt2", "attempt3"]
        true     | "user_uuid='STUDENT_UUID'"                   | false      | ["attempt2", "attempt3"]
        false    | "page_assignment_uuid='PA1_UUID'"            | false      | ["attempt1", "attempt2", "attempt4"]
        true     | "page_assignment_uuid='PA1_UUID'"            | false      | ["attempt2", "attempt4"]
        false    | "planner_entry_uuid='PE1_UUID'"              | false      | ["attempt1", "attempt2"]
        true     | "planner_entry_uuid='PE1_UUID'"              | false      | ["attempt2"]
        false    | "attempt_uuid='ATTEMPT1_UUID'"               | false      | ["attempt1"]
        true     | "attempt_uuid='ATTEMPT1_UUID'"               | false      | []
        false    | "state='FAILED'"                             | false      | ["attempt1", "attempt4", "attempt5"]
        false    | "status='FAILED'"                            | false      | ["attempt1", "attempt4", "attempt5"]
        true     | "state='FAILED'"                             | false      | ["attempt4"]
        true     | "status='FAILED'"                            | false      | ["attempt4"]
        false    | "assessment_score='1'"                       | false      | ["attempt3"]
        false    | "state='IN_PROGRESS'"                        | true       | ["attempt6", "attempt7"]
        false    | "status='IN_PROGRESS'"                       | true       | ["attempt6", "attempt7"]
        false    | "status='PASSED' OR state='FAILED'"          | false      | ["attempt1", "attempt3", "attempt4","attempt5"]
    }

    @Unroll
    def "should update pages by class"(){
        given:
        ClassObj class1 = setupValidClass(admin, campus1)
        ClassObj class2 = setupValidClass(admin, campus1)

        [class1, class2].each {
            createEnrollment(it, teacher, Role.TEACHER)
            createEnrollment(it, arya, Role.STUDENT)
            createEnrollment(it, bran, Role.STUDENT)
        }

        PageObj page1 = setupValidPage("class 1 page 1", class1, 1)
        PageObj page2 = setupValidPage("class 1 page 2", class1, 2)
        PageObj page3 = setupValidPage("class 2 page 2", class2, 1)

        PageAssignment p1pa1 = setupValidPageAssignment("p1pa1", page1, 1)
        PageAssignment p1pa2 = setupValidPageAssignment("p1pa2", page1, 2)
        PageAssignment p1pa3 = setupValidPageAssignment("p1pa3", page1, 3)
        PageAssignment p2pa1 = setupValidPageAssignment("p2pa1", page2, 1)
        PageAssignment p2pa2 = setupValidPageAssignment("p2pa2", page2, 2)
        PageAssignment p2pa3 = setupValidPageAssignment("p2pa3", page2, 3)
        PageAssignment p3pa1 = setupValidPageAssignment("p3pa1", page3, 1)
        PageAssignment p3pa2 = setupValidPageAssignment("p3pa2", page3, 2)
        PageAssignment p3pa3 = setupValidPageAssignment("p3pa3", page3, 3)

        PlannerEntry peA1 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa1, arya)
        PlannerEntry peA2 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa2, arya)
        PlannerEntry peA3 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa3, arya)
        PlannerEntry peA4 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa1, arya)
        PlannerEntry peA5 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa2, arya)
        PlannerEntry peA6 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa3, arya)
        PlannerEntry peA7 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa1, arya)
        PlannerEntry peA8 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa2, arya)
        PlannerEntry peA9 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa3, arya)

        PlannerEntry peB1 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa1, bran)
        PlannerEntry peB2 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa2, bran)
        PlannerEntry peB3 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page1, p1pa3, bran)
        PlannerEntry peB4 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa1, bran)
        PlannerEntry peB5 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa2, bran)
        PlannerEntry peB6 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class1, page2, p2pa3, bran)
        PlannerEntry peB7 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa1, bran)
        PlannerEntry peB8 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa2, bran)
        PlannerEntry peB9 = setupPlannerEntry(-1, PlannerEntryState.IN_PROGRESS, class2, page3, p3pa3, bran)

        def peMap = [
                peA1: peA1,
                peA2: peA2,
                peA3: peA3,
                peA4: peA4,
                peA5: peA5,
                peA6: peA6,
                peA7: peA7,
                peA8: peA8,
                peA9: peA9,
                peB1: peB1,
                peB2: peB2,
                peB3: peB3,
                peB4: peB4,
                peB5: peB5,
                peB6: peB6,
                peB7: peB7,
                peB8: peB8,
                peB9: peB9,
        ]

        Attempt a1 = setupAttemptByDate(peA1, arya, cdate(0), AttemptState.FAILED, 0.1, null, null, false) //will be latest, pe->GRADED
        Attempt a2 = setupAttemptByDate(peA1, arya, cdate(1), AttemptState.IN_PROGRESS, null, null, null, true) //will be deleted
        Attempt a3 = setupAttemptByDate(peA2, arya, cdate(2), AttemptState.PASSED, 0.9, null, null, false) //will be latest, pe->GRADED
        Attempt a4 = setupAttemptByDate(peA2, arya, cdate(3), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt a5 = setupAttemptByDate(peA3, arya, cdate(4), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a6 = setupAttemptByDate(peA3, arya, cdate(5), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt a7 = setupAttemptByDate(peA4, arya, cdate(6), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a8 = setupAttemptByDate(peA4, arya, cdate(7), AttemptState.PASSED, 1.0, null, null, true) //will be latest, pe->GRADED
        Attempt a9 = setupAttemptByDate(peA5, arya, cdate(8), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a10 = setupAttemptByDate(peA5, arya, cdate(9), AttemptState.FAILED, 0.2, null, null, true) //will be latest, pe->GRADED
        Attempt a11 = setupAttemptByDate(peA7, arya, cdate(10), AttemptState.PASSED, 0.9, null, null, false) //will be latest, pe->GRADED
        Attempt a12 = setupAttemptByDate(peA7, arya, cdate(11), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt a13 = setupAttemptByDate(peA8, arya, cdate(12), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a14 = setupAttemptByDate(peA8, arya, cdate(13), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt a15 = setupAttemptByDate(peA9, arya, cdate(14), AttemptState.FAILED, 0.1, null, null, false)
        Attempt a16 = setupAttemptByDate(peA9, arya, cdate(15), AttemptState.PASSED, 1.0, null, null, true) //will be latest, pe->GRADED

        Attempt b1 = setupAttemptByDate(peB1, bran, cdate(16), AttemptState.IN_PROGRESS, null, null, null, false) //will be deleted
        Attempt b2 = setupAttemptByDate(peB1, bran, cdate(17), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b3 = setupAttemptByDate(peB2, bran, cdate(18), AttemptState.SAVED, null, null, null, false) //will be deleted
        Attempt b4 = setupAttemptByDate(peB2, bran, cdate(19), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b5 = setupAttemptByDate(peB3, bran, cdate(20), AttemptState.SUBMITTED, null, null, null, false)
        Attempt b6 = setupAttemptByDate(peB3, bran, cdate(21), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b7 = setupAttemptByDate(peB4, bran, cdate(22), AttemptState.PASSED, 0.9, null, null, false)
        Attempt b8 = setupAttemptByDate(peB4, bran, cdate(23), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b9 = setupAttemptByDate(peB5, bran, cdate(24), AttemptState.SUBMITTED, null, null, null, false) //will be latest, pe->COMPLETED
        Attempt b10 = setupAttemptByDate(peB5, bran, cdate(25), AttemptState.SAVED, null, null, null, true) //will be deleted
        Attempt b11 = setupAttemptByDate(peB7, bran, cdate(26), AttemptState.SAVED, null, null, null, false) //will be deleted
        Attempt b12 = setupAttemptByDate(peB7, bran, cdate(27), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b13 = setupAttemptByDate(peB8, bran, cdate(28), AttemptState.SUBMITTED, null, null, null, false)
        Attempt b14 = setupAttemptByDate(peB8, bran, cdate(29), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED
        Attempt b15 = setupAttemptByDate(peB9, bran, cdate(30), AttemptState.PASSED, 0.9, null, null, false)
        Attempt b16 = setupAttemptByDate(peB9, bran, cdate(31), AttemptState.SUBMITTED, null, null, null, true) //will be latest, pe->COMPLETED

        def attemptMap = [
                a1 : a1,
                a2 : a2,
                a3 : a3,
                a4 : a4,
                a5 : a5,
                a6 : a6,
                a7 : a7,
                a8 : a8,
                a9 : a9,
                a10: a10,
                a11 : a11,
                a12 : a12,
                a13 : a13,
                a14 : a14,
                a15 : a15,
                a16 : a16,
                b1 : b1,
                b2 : b2,
                b3 : b3,
                b4 : b4,
                b5 : b5,
                b6 : b6,
                b7 : b7,
                b8 : b8,
                b9 : b9,
                b10: b10,
                b11 : b11,
                b12 : b12,
                b13 : b13,
                b14 : b14,
                b15 : b15,
                b16 : b16,
        ]

        attemptMap.values().each {
            attemptSaveRepo.save(
                    new AttemptSave(
                            attempt: it,
                            sequence: 1,
                            sectionsViewed: ["1", "2"],
                            questionsViewed: ["1", "3", "4"],
                            timeOnTaskSeconds: 54,
                            createdAt: new Date(),
                            createdBy: it.user.uuid
                    )
            )
        }

        def classMap = [
                class1: class1,
                class2: class2
        ]

        def body = [
                status: newStatus
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PAGES_VERSION_1_MT)
        headers.setAccept([Constants.PAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classMap[classId].uuid}/pages", HttpMethod.PATCH, req, Map)

        then:

        assert resp.statusCode == HttpStatus.NO_CONTENT

        assert pageRepo.findAllByClassObjUuid(classMap[classId].uuid).every {
            it.status == PageState.valueOf(newStatus)
        }

        List<Attempt> attempts = attemptRepo.findAll().asList()
        def expectedAttempts = attemptMap.keySet() - deletedAttempts

        assert attempts.size() == expectedAttempts.size()
        expectedAttempts.each {
            assert attempts.uuid.contains(attemptMap[it].uuid)
        }

        List<PlannerEntry> pes = plannerEntryRepo.findAll().asList()
        def regPe = peMap.keySet() - gradedPe - completedPe - deletedPe
        regPe.each { peId ->
            assert pes.uuid.contains(peMap[peId].uuid)
            assert pes.find { it.uuid == peMap[peId].uuid }.status == PlannerEntryState.IN_PROGRESS
        }

        if (gradedPe) {
            gradedPe.each { peId ->
                assert pes.uuid.contains(peMap[peId].uuid)
                assert pes.find { it.uuid == peMap[peId].uuid }.status == PlannerEntryState.GRADED
            }
        }

        if (completedPe) {
            completedPe.each { peId ->
                assert pes.uuid.contains(peMap[peId].uuid)
                assert pes.find { it.uuid == peMap[peId].uuid }.status == PlannerEntryState.COMPLETED
            }
        }

        if (deletedPe) {
            deletedPe.each { peId ->
                assert pes.every { it.uuid != peMap[peId].uuid }
            }
        }

        attemptRepo.findAll().groupBy { it.plannerEntry }.each { group ->
            def latest = group.value.max { it.createdAt }
            group.value.each { attempt ->
                if (attempt.uuid == latest.uuid) {
                    assert attempt.creditBearing
                }
                else {
                    assert !attempt.creditBearing
                }
            }
        }


        where:
        newStatus   | classId  | deletedAttempts                 | gradedPe                         | completedPe                                      | deletedPe
        'COMPLETED' | 'class1' | ['a2', 'a4', 'b1', 'b3', 'b10'] | ['peA1', 'peA2', 'peA4', 'peA5'] | ['peA3', 'peB1', 'peB2', 'peB3', 'peB4', 'peB5'] | ['peA6', 'peB6']
        'COMPLETED' | 'class2' | ['a12', 'b11']                  | ['peA7', 'peA9']                 | ['peA8', 'peB7', 'peB8', 'peB9']                 | []
        'ACTIVE'    | 'class1' | []                              | []                               | []                                               | []
    }

    private ClassObj setupValidClass(String name = "test name", List<Grade> grades = [Grade.FOUR, Grade.THREE, Grade.EIGHT], Organization schoolOrg = school)
    {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid:school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: name,
                subject: subjectsService.findOne(subject.uuid, school.uuid),
                organization: schoolOrg,
                creatorUuid: admin.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date()
        )
        classObj = classRepo.save(classObj)
        gradeLevelIdService.save(classObj.uuid, grades)
        return classObj
    }

	private void checkCreateUpdateResponse(UUID uuid, HttpEntity resp, Map body, Integer expectedSeq, PageObj existing = null) {
	
        PageObj actual = pageRepo.findByUuid(uuid)
		
        assert actual != null
        assert actual.name == body.name
        assert actual.status == body.status as PageState
        assert actual.sequence == expectedSeq
        if(body.class_uuid) {
            assert actual.classObj.uuid.toString() == body.class_uuid
        }
        else if(existing){
            assert actual.classObj.uuid == existing.classObj.uuid
            assert actual.createdAt == existing.createdAt
            assert actual.updatedAt > existing.updatedAt
        }

        def expectedClass = [
                "class_uuid" : actual.classObj.uuid.toString(),
                "name" : actual.classObj.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/classes/" + actual.classObj.uuid.toString()]
                ]
        ]
        def expectedAssignments = []
        assert resp.body.name == body.name
        assert resp.body.status == body.status
        assert resp.body.sequence == expectedSeq
        assert resp.body.page_uuid == actual.uuid.toString()
        assert resp.body.class == expectedClass
        assert resp.body.page_assignments == expectedAssignments
    }

    private void checkPageResponse(HttpEntity resp, List<String> expectedUuids, Map<String, PageObj> pages){
        PageObj page1 = pages.values().find { it.uuid.toString() == expectedUuids.first()}
        assert resp.statusCode == HttpStatus.OK
        assert resp.body.pages.size == expectedUuids.size()
        resp.body.pages.each { p ->
            assert expectedUuids.contains(p.page_uuid)
        }
        def responseClass = resp.body.pages.find { it.page_uuid == expectedUuids.first() }
        def expectedClass = [
                "class_uuid" : page1.classObj.uuid.toString(),
                "name" : page1.classObj.name,
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/classes/"+page1.classObj.uuid.toString()]
                ]
        ]
        def expectedPageAssignments = []
        assert page1.name == responseClass.name
        assert page1.sequence == responseClass.sequence
        assert page1.type == responseClass.type
        assert page1.status == responseClass.status as PageState
        assert expectedClass == responseClass.class
        assert expectedPageAssignments == responseClass.page_assignments
    }

    private List<PageObj> setupPagesForSorting(String field, ClassObj classObj){
        List<PageObj> pages = []
        switch (field){
            case "name":
                pages.add(setupValidPage("a page name", classObj))
                pages.add(setupValidPage("z page name", classObj))
                break
            case "status":
                pages.add(setupValidPage("stateFirst", classObj, PageState.ACTIVE))
                pages.add(setupValidPage("stateLast", classObj, PageState.INACTIVE))
                break
            case "type":
                pages.add(setupValidPage("typeFirst", classObj, "CONCEPT"))
                pages.add(setupValidPage("typeLast", classObj, "ZONCEPT"))
                break
            case "sequence":
                pages.add(setupValidPage("sequenceFirst", classObj, 1))
                pages.add(setupValidPage("sequenceSecond", classObj, 2))
                break
            case "class.name":
                ClassObj class1 = setupValidClass("class1")
                ClassObj class2 = setupValidClass("class2")
                pages.add(setupValidPage("classFirst", class1))
                pages.add(setupValidPage("classLast", class2))
                break
            case "class.class_uuid":
                ClassObj class1 = setupValidClass("class1")
                ClassObj class2 = setupValidClass("class2")

                def temp = [class1, class2].sort(false) { a, b ->
                    a.uuid.toString() <=> b.uuid.toString()
                }
                pages.add(setupValidPage("classFirst", temp[0]))
                pages.add(setupValidPage("classLast", temp[1]))
                break
        }
        return pages
    }
}
