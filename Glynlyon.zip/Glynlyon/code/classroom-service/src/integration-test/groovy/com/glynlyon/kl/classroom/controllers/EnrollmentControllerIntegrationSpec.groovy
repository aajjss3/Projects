package com.glynlyon.kl.classroom.controllers

import java.util.Date
import java.util.HashMap
import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.EnrollmentRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.repo.UserRepo
import com.glynlyon.kl.classroom.service.JwtService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll
import com.glynlyon.kl.classroom.model.PageState



class EnrollmentControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    EnrollmentRepo enrollmentRepo

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    ClassRepo classRepo

    @Autowired
    UserRepo userRepo

    @Autowired
    OrganizationRepo organizationRepo

    @Autowired
    SubjectsService subjectsService

    @Autowired
    JwtService jwtService

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    User teacher
    User teacher2
    User teacher3
    User admin
    User student
    List<User> students = []
    Organization campus1
    Organization campus2
    Organization school
    Organization school2

    def setup(){
        teacher = new User(userName:'teacher',firstName: "test", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1',lastLoggedInAt: new Date().minus(1) )
        teacher2 = new User(userName:'teacher2',firstName: "test", lastName: "teacher2", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1',lastLoggedInAt: new Date().minus(2))
        teacher3 = new User(userName:'teacher3',firstName: "test", lastName: "teacher3", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1',lastLoggedInAt: new Date().minus(3))
        admin = new User(userName:'admin',firstName: "test", lastName: "admin", type: AppUserType.ADMIN,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1',lastLoggedInAt: new Date().minus(4))
        student = new User(userName:'student',firstName: "test", lastName: "student", type: AppUserType.STUDENT,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1',lastLoggedInAt: new Date().minus(5))

        userRepo.save(teacher)
        userRepo.save(teacher2)
        userRepo.save(teacher3)
        userRepo.save(admin)
        userRepo.save(student)
        Random random = new Random()
        def pool = ['a'..'z'].flatten()
        (1..5).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            students.add(new User(userName:"student${it}",firstName: randomName, lastName: "student${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),lastLoggedInAt: new Date()))
        }

        students.each {
            userRepo.save(it)
        }


        school = new Organization(type: OrganizationType.SCHOOL,name: 'Humboldt',created: new Date(),updated: new Date(),originationId: 'shard1')
        school2 = new Organization(type: OrganizationType.SCHOOL,name: 'Sacramento',created: new Date(),updated: new Date(),originationId: 'shard1')


        organizationRepo.save(school)
        organizationRepo.save(school2)
        campus1 = new Organization(type: OrganizationType.CAMPUS,name:'Bakersfield',created: new Date(),updated: new Date(),originationId: 'shard1',parent: school,users: [teacher,teacher2])
        campus2 = new Organization(type:OrganizationType.CAMPUS,name: 'Fresno',created: new Date(), updated: new Date(),originationId: 'shard1',parent:school2)

        campus2.setUsers([teacher3,admin,student].toSet())

        organizationRepo.save(campus1)
        organizationRepo.save(campus2)





        ClassObj.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return classRepo.save(delegate)
        }
    }

    def cleanup() {

    }

    @Unroll
    def "should test enrollment creation"(){
        given:
        User invalid = new User(uuid:UUID.fromString('1f235d3a-2fb6-46ff-aa0a-22a43a545b9e'),type: AppUserType.STUDENT,created: new Date(),updated: new Date(),firstName: "invalid",lastName: "teacher",userName: "invTeacher",status:AppUserStatus.ACTIVE,originationId:'shard1')
        def userMap = [student: student, teacher: teacher, admin: admin,invalid: invalid]


        ClassObj classObj = setupValidClass()

        def body = [enrollments: [[
                            "class_uuid": classUuid == "valid" ? classObj.uuid : classUuid,
                            "user_uuid": userMap[user].uuid,
                            "role": role,
                            "primary_role": pRole,
                            "status": status
                    ]]]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:
        if(expectedErrors) {
            assert resp.body.successes.size == 0
            assert resp.body.failures.size == 1
            assert resp.body.failures[0].user_uuid == userMap[user].uuid.toString()
            assert resp.body.failures[0].class_uuid == (classUuid == "valid" ? classObj.uuid.toString() : classUuid)
            assert resp.body.failures[0].errors.size == expectedErrors.size()
            expectedErrors.each { error ->
                assert resp.body.failures[0].errors.contains(error)
            }
        }
        else{
            assert resp.body.successes.size == 1
            assert enrollmentRepo.findAll().size() == 1
            assert resp.body.failures.size == 0
            verifyEnrollments(resp, body.enrollments)
        }

        where:
        user      | role            | pRole | classUuid                              | status     || expectedErrors
        "student" | "STUDENT"       | true  | "valid"                                | "ACTIVE"   || [[field: "primary_role", message: "only teachers and administrators are allowed to be enrolled as primary"]]
        "teacher" | "TEACHER"       | true  | "valid"                                | "ACTIVE"   || []
        "admin"   | "ADMINISTRATOR" | true  | "valid"                                | "ACTIVE"   || []

        "student" | "STUDENT"       | false | "valid"                                | "ACTIVE"   || []
        "student" | "TEACHER"       | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]
        "student" | "ADMINISTRATOR" | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]

        "teacher" | "STUDENT"       | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]
        "teacher" | "TEACHER"       | false | "valid"                                | "ACTIVE"   || []
        "teacher" | "ADMINISTRATOR" | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]

        "admin"   | "STUDENT"       | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]
        "admin"   | "TEACHER"       | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "can only enroll users as their existing system role"]]
        "admin"   | "ADMINISTRATOR" | false | "valid"                                | "ACTIVE"   || []
        "admin"   | "ADMINISTRATOR" | false | "valid"                                | "INACTIVE" || []

        "student" | "STUDENT"       | false | "cb6460fc-9f68-45c7-ac72-c427887da76c" | "ACTIVE"   || [[field: "class_uuid", message: "Could not find class with uuid cb6460fc-9f68-45c7-ac72-c427887da76c"]]
        "invalid" | "STUDENT"       | false | "valid"                                | "ACTIVE"   || [[field: "user_uuid", message: "Could not find user with uuid 1f235d3a-2fb6-46ff-aa0a-22a43a545b9e"]]
        "student" | "STUDENT1"      | false | "valid"                                | "ACTIVE"   || [[field: "role", message: "Invalid value for role STUDENT1"]]
        "student" | "STUDENT"       | "7"   | "valid"                                | "ACTIVE"   || [[field: "primary_role", message: "Invalid value for primary_role 7"]]
        "student" | "STUDENT"       | false | "valid"                                | "ACTIVE1"  || [[field: "status", message: "Invalid value for status ACTIVE1"]]
        "student" | "STUDENT"       | "7"   | "valid"                                | "ACTIVE1"  || [[field: "primary_role", message: "Invalid value for primary_role 7"], [field: "status", message: "Invalid value for status ACTIVE1"]]

    }

    @Unroll
    def "should test enrollment missing field errors"(){
        ClassObj classObj = setupValidClass()

        def body = [enrollments: [[
                            "class_uuid": classObj.uuid,
                            "user_uuid": admin.uuid,
                            "role": "ADMINISTRATOR",
                            "primary_role": false,
                            "status": "ACTIVE"
                    ]]]
        body.enrollments[0].remove(missingField)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:

        assert resp.body.successes.size == 0
        assert resp.body.failures.size == 1
        assert resp.body.failures[0].user_uuid == (missingField == "user_uuid" ? null : admin.uuid.toString())
        assert resp.body.failures[0].class_uuid == (missingField == "class_uuid" ? null : classObj.uuid.toString())
        assert resp.body.failures[0].errors.size == expectedErrors.size()
        expectedErrors.each { error ->
            assert resp.body.failures[0].errors.contains(error)
        }

        where:
        missingField || expectedErrors
        "class_uuid" || [["field": "class_uuid", "message": "Missing required field class_uuid"]]
        "user_uuid"  || [["field": "user_uuid", "message": "Missing required field user_uuid"]]
        "role"       || [["field": "role", "message": "Missing required field role"]]
        "status"     || [["field": "status", "message": "Missing required field status"]]

    }

    @Unroll
    def "should test multiple enrollment creation"(){
        def userMap = [student: student, teacher: teacher, admin: admin]

        ClassObj classObj = setupValidClass()
        def role1 = rolePicker(user1)
        def role2 = rolePicker(user2)
        def body =[enrollments: [
                [
                        "class_uuid": classObj.uuid,
                        "user_uuid": userMap[user1].uuid,
                        "role": role1,
                        "primary_role": pRole1,
                        "status": "ACTIVE"
                ],
                [
                        "class_uuid": classObj.uuid,
                        "user_uuid": userMap[user2].uuid,
                        "role": role2,
                        "primary_role": pRole2,
                        "status": "ACTIVE"
                ]
        ]]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:
        assert resp.body.successes.size == success.size()
        assert enrollmentRepo.findAll().size() == success.size()
        assert resp.body.failures.size == failure.size()
        verifyEnrollments(resp, body.enrollments, success, failure, expectedErrors)

        where:
        user1     | pRole1 | user2     | pRole2 | success | failure | expectedErrors
        "student" | false  | "teacher" | false  | [0,1]   | []      | []
        "admin"   | true   | "teacher" | true   | [0,1]   | []      | []
        "student" | true   | "teacher" | false  | [1]     | [0]     | [[[field: "primary_role", message: "only teachers and administrators are allowed to be enrolled as primary"]]]
        "teacher" | false  | "student" | true   | [0]     | [1]     | [[[field: "primary_role", message: "only teachers and administrators are allowed to be enrolled as primary"]]]
        "student" | true   | "teacher" | "8"    | []      | [0,1]   | [[[field: "primary_role", message: "only teachers and administrators are allowed to be enrolled as primary"]], [[field: "primary_role", message: "Invalid value for primary_role 8"]]]
        "student" | false  | "student" | false  | [0]     | [1]     | [[[field: "user_uuid", message: "cannot enroll user multiple times into the same class"]]]

    }

    @Unroll
    def "should test user org restrictions"(){

        def userMap = [student: student, teacher: teacher, admin: admin]
        def orgMap = [campus1: campus1, campus2: campus2, school: school]
        ClassObj classObj = setupValidClass().updateField("organization", orgMap[org])

        def body = [enrollments: [[
                            "class_uuid": classObj.uuid,
                            "user_uuid": userMap[user].uuid,
                            "role": rolePicker(user),
                            "primary_role": false,
                            "status": "ACTIVE"
                    ]]]
        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:
        def errors = [[[field: "class_uuid", message: "Could not find class with uuid " + classObj.uuid]]]
        verifyEnrollments(resp, body.enrollments, [], [0], errors)

        where:
        user      | org
        "teacher" | "campus2"
        "teacher" | "school"
        "admin"   | "campus2"
    }

    @Unroll
    def "should test teacher restrictions"(){

        ClassObj classObj = setupValidClass()

        def body = [enrollments: [[
                            "class_uuid": classObj.uuid,
                            "user_uuid": student.uuid,
                            "role": "STUDENT",
                            "primary_role": false,
                            "status": "ACTIVE"
                    ]]]
        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:
        def errors = [[[field: "user_uuid", message: "teachers cannot make enrollments for classes into which they are not enrolled"]]]
        assert resp.body.successes.size == 0
        assert resp.body.failures.size == 1
        verifyEnrollments(resp, body.enrollments, [], [0], errors)

        when:
        enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
        resp = testRestTemplate.exchange("/enrollments", HttpMethod.POST, req, Map)

        then:
        assert resp.body.successes.size == 1
        assert resp.body.failures.size == 0
        verifyEnrollments(resp, body.enrollments)
    }

    @Unroll
    def "should test get enrollments for various users"(){

        def enrollments = setupEnrollments()
		
		//assign 2 attempts to 'c1Admin' enrollment to test enrollments time_on_task_seconds for an admin
		int totalTimeOnTaskAdmin = assignAttemptsToEnrollment(enrollments.get("c1Admin"), 2)
		//assign 3 attempts to 'c1Student1' enrollment to test enrollments time_on_task_seconds for a student
		int totalTimeOnTaskStudent = assignAttemptsToEnrollment(enrollments.get("c1Student1"), 3)
		
        def userMap = [student: students[2],student1: students[1], teacher: teacher, teacher2: teacher2, teacher3: teacher3, admin: admin]

        def orgMap = [school: school.uuid, school2: school2.uuid, unknown: UUID.randomUUID()]

        String token = createToken(userMap[user], orgMap[org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.GET, req, Map)

        then:
        if(expectedErrors) {
            assert resp.body.errors.size() == expectedErrors.size()
            expectedErrors.each {
                if(it.message == "orgMessage"){
                    it.message = "no organizations found for user " + userMap[user].uuid + " in school " + orgMap[org]
                }
                assert resp.body.errors.contains(it)
            }
        }
        else {
            assert resp.body.enrollments.size() == results.size()
            if(results.size()) {
                List<String> expectedUuids = results.collect { enrollments[it].uuid.toString() }
                checkEnrollmentResponse(resp, expectedUuids, enrollments)
            }
			// assert enrollment.time_on_task_seconds
			def clAdminResponse = resp.body.enrollments.find { it.enrollment_uuid == enrollments.get("c1Admin").uuid.toString() }
			def c1Student1Response = resp.body.enrollments.find { it.enrollment_uuid == enrollments.get("c1Student1").uuid.toString() }
			if( clAdminResponse ){
				assert clAdminResponse.time_on_task_seconds == totalTimeOnTaskAdmin
			}
			if( c1Student1Response ){
				assert c1Student1Response.time_on_task_seconds == totalTimeOnTaskStudent
			}
			def noAttemptResponse = resp.body.enrollments.findAll { it.enrollment_uuid != enrollments.get("c1Student1").uuid.toString() && it.enrollment_uuid != enrollments.get("c1Admin").uuid.toString() }
			noAttemptResponse.each { e ->
				assert e.time_on_task_seconds == 0
         }
        }

        where:
        user       | org       | results                                                                                    | expectedErrors
        "student"  | "school"  | ["c1Student3"]                                                                             | []
        "student1" | "school2" | ["c1Student2","c2Student2","c2aStudent2"]                                                  | []
        "teacher"  | "school"  | ["c1Admin", "c1Student1", "c1Student2", "c1Student3", "c1Teacher"]                         | []
        "teacher2" | "school"  | ["c1Admin", "c1Student1", "c1Student2", "c1Student3", "c1Teacher"]                         | []
        "teacher3" | "school2" | ["c2Admin", "c2Student1", "c2Student2", "c2aStudent1", "c2aStudent2", "c2Teacher"]         | []
        "admin"    | "school"  | ["c1Admin", "c1Student1", "c1Student2", "c1Student3", "c1Teacher", "s1Admin", "s1Student"] | []
        "admin"    | "school2" | ["c2Admin", "c2Student1", "c2Student2", "c2aStudent1", "c2aStudent2", "c2Teacher"]         | []
        "admin"    | "unknown" | []                                                                                         | [[field: "sub / school_uuid", message: "orgMessage"]]
    }

	@Unroll
	def "should test enrollment sorting"(){
		given:
		def enrollments = setupEnrollmentsForSorting(sort)

		String token = createToken(admin, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
		HttpEntity req = new HttpEntity(headers)

		when:
		HttpEntity resp = testRestTemplate.exchange("/enrollments?sort=${sort}&orderBy=${dir}", HttpMethod.GET, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		assert resp.body.current_page == 1
		assert resp.body.total_pages == 1
		assert resp.body.page_size == enrollments.size()

		def responseEnrollment = resp.body.enrollments[0]
		def expected = []
		if(sort == "enrollment_uuid") {
			expected = enrollmentRepo.findAll().sort(false) { a, b ->
				a.uuid.toString() <=> b.uuid.toString()
			}
		}
		else if(sort == "role" | sort == "status"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a."${sort}".toString() <=> b."${sort}".toString()
			}
		}
		else if(sort == "class_uuid"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a.classObj.uuid.toString() <=> b.classObj.uuid.toString()
			}
		}
		else if(sort == "primary_role"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a.primaryRole <=> b.primaryRole
			}
		}
		else if(sort == "user.first_name"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a.user.firstName <=> b.user.firstName
			}
		}
		else if(sort == "user.last_name"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a.user.lastName <=> b.user.lastName
			}
		}
		else if(sort == "user.user_uuid"){
			expected = enrollmentRepo.findAll().sort(false){ a, b ->
				a.user.uuid.toString() <=> b.user.uuid.toString()
			}
		}
		if(dir == "desc"){
			expected = expected.reverse()
		}

		assert expected[0].uuid.toString() == responseEnrollment.enrollment_uuid

		where:
		sort                    | dir
		"role"                  | "asc"
		"role"                  | "desc"
		"status"                | "asc"
		"status"                | "desc"
		"enrollment_uuid"       | "asc"
		"enrollment_uuid"       | "desc"
		"class_uuid"            | "asc"
		"class_uuid"            | "desc"
		"primary_role"          | "asc"
		"primary_role"          | "desc"
		"user.first_name"       | "asc"
		"user.first_name"       | "desc"
		"user.last_name"        | "asc"
		"user.last_name"        | "desc"
		"user.user_uuid"        | "asc"
		"user.user_uuid"        | "desc"
	}
	
    @Unroll
    def "test get enrollments sorting errors"() {
        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments?sort=${sort}", HttpMethod.GET, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        def expected = [[field:"sort",message: "invalid sort field '${sort}'"]]
        assert expected == resp.body.errors

        where:
        sort << ["foo"]
    }

    @Unroll
    def "should test enrollment filtering"(){
        given:
        def enrollments = setupEnrollments()

        def orgMap = [school: school, school2: school2]

        if(filter == "enrollment"){
            filter = "enrollment_uuid='${enrollments.c1Teacher.uuid.toString()}'"
        }
        else if(filter == "class2"){
            filter = "class_uuid='${enrollments.c2Admin.classObj.uuid.toString()}'"
        }
        else if(filter == "class3"){
            filter = "class_uuid='${enrollments.c2aStudent1.classObj.uuid.toString()}'"
        }
        else if(filter == "student1"){
            filter = "user.user_uuid='${enrollments.c2aStudent1.user.uuid.toString()}'"
        }
        else if(filter == "student2"){
            filter = "user.user_uuid='${enrollments.c2aStudent2.user.uuid.toString()}'"
        }
        else if(filter == "combo1"){
            filter = "user.user_uuid='${enrollments.c2aStudent2.user.uuid.toString()}' or enrollment_uuid='${enrollments.c2Student1.uuid.toString()}'"
        }

        String token = createToken(admin, orgMap[org].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        if(expectedErrors) {
            assert resp.body.errors.size() == expectedErrors.size()
            expectedErrors.each {
                assert resp.body.errors.contains(it)
            }
        }
        else {
            assert resp.body.enrollments.size() == expectedResults.size()
            if (expectedResults.size()) {
                List<String> expectedUuids = expectedResults.collect { enrollments[it].uuid.toString() }
                checkEnrollmentResponse(resp, expectedUuids, enrollments)
            }
        }

        where:
        filter                                 | org       | expectedResults                                                         | expectedErrors
        "user.last_name='admin'"               | "school"  | ["c1Admin", "s1Admin"]                                                  | []
        "role='STUDENT'"                       | "school"  | ["c1Student1", "c1Student2", "c1Student3", "s1Student"]                 | []
        "role='STUDENT'"                       | "school2" | ["c2Student1", "c2Student2", "c2aStudent1", "c2aStudent2"]              | []
        "status='INACTIVE'"                    | "school"  | ["c1Admin", "c1Student2", "c1Student3"]                                 | []
        "role='STUDENT' AND status='INACTIVE'" | "school"  | ["c1Student2", "c1Student3"]                                            | []
        "status='ACTIVE'"                      | "school2" | ["c2Admin", "c2aStudent1", "c2aStudent2"]                               | []
        "enrollment"                           | "school"  | ["c1Teacher"]                                                           | []
        "class2"                               | "school"  | []                                                                      | []
        "class2"                               | "school2" | ["c2Admin", "c2Student1", "c2Student2", "c2Teacher"]                    | []
        "class3"                               | "school2" | ["c2aStudent1", "c2aStudent2"]                                          | []
        "student1"                             | "school2" | ["c2Student1", "c2aStudent1"]                                           | []
        "student2"                             | "school2" | ["c2Student2", "c2aStudent2"]                                           | []
        "primary_role='true'"                  | "school"  | ["c1Teacher", "s1Admin"]                                                | []
        "primary_role='false'"                 | "school2" | ["c2Teacher", "c2Student1", "c2Student2", "c2aStudent1", "c2aStudent2"] | []
        "combo1"                               | "school2" | ["c2Student2", "c2aStudent2", "c2Student1"]                             | []
        "blah='foo'"                           | "school"  | []                                                                      | [[field: "filter - blah='foo'", message: "Unavailable filter path"]]
        "role='ADMIN' AND foo='bar"            | "school"  | []                                                                      | [[field: "filter - role='ADMIN' AND foo='bar", message: "Invalid filter expression  AND foo='bar"]]
        "primary_role='tru'"                   | "school"  | []                                                                      | [[field: "filter - primary_role='tru'", message: "tru is not a boolean value"]]
        "primary_role='true"                   | "school"  | []                                                                      | [[field: "filter - primary_role='true", message: "Invalid filter primary_role='true"]]
    }

    @Unroll
    def "should test get single enrollment"(){
        def enrollments = setupEnrollments()

        def userMap = [teacher: teacher, admin: admin, student: student]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK){
            checkSingleEnrollmentResponse(resp, enrollments[enrollment])
        }

        where:
        user      | enrollment | result
        "admin"   | "c1Admin"  | HttpStatus.OK
        "teacher" | "c1Admin"  | HttpStatus.OK
        "student" | "c1Admin"  | HttpStatus.BAD_REQUEST
        "admin"   | "s1Admin"  | HttpStatus.OK
        "teacher" | "s1Admin"  | HttpStatus.NOT_FOUND
    }

    @Unroll
    def "should test put single enrollment"(){
        def enrollments = setupEnrollments()
        def counter = 0
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]

        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)
        
        then:
        assert resp.statusCode == result

        if(result == HttpStatus.OK) {
            checkSingleEnrollmentResponse(resp, enrollments[enrollment])
        } else {
            assert resp.body.errors.size == expectedResponseErrorsSize
            assert resp.body.errors[0].field == "class_uuid"
            assert resp.body.errors[0].message == "Could not find class with uuid " + enrollments[enrollment].classObj.uuid.toString()
            assert resp.body.errors[1].field == "uuid"
            assert resp.body.errors[1].message == "Invalid enrollment uuid " + enrollments[enrollment].uuid.toString() +"."
        }

        where:
        enrollment      |   result                     |  expectedResponseErrorsSize
        "c1Admin"       |   HttpStatus.OK              |  0
        "c1Student1"    |   HttpStatus.OK              |  0
        "c1Student2"    |   HttpStatus.OK              |  0
        "c1Student3"    |   HttpStatus.OK              |  0
        "c1Teacher"     |   HttpStatus.OK              |  0
        "c2Admin"       |   HttpStatus.BAD_REQUEST     |  2
        "c2Student1"    |   HttpStatus.BAD_REQUEST     |  2
        "c2Student2"    |   HttpStatus.BAD_REQUEST     |  2
        "c2Teacher"     |   HttpStatus.BAD_REQUEST     |  2
        "c2aStudent1"   |   HttpStatus.BAD_REQUEST     |  2
        "c2aStudent2"   |   HttpStatus.BAD_REQUEST     |  2
        "s1Admin"       |   HttpStatus.OK              |  0
        "s1Student"     |   HttpStatus.OK              |  0
    }

    @Unroll
    def "should test put single enrollment primary_role and status"(){
        def enrollments = setupEnrollments()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": primary_role,
                "status": status
        ]
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK){
            if (primary_role != null) {
                enrollments[enrollment].primaryRole = primary_role
            }
            enrollments[enrollment].status = status
            checkSingleEnrollmentResponse(resp, enrollments[enrollment])
        }else{
            assert resp.body.toString() == expectedErrorMessage
        }

        where:
        enrollment      |   primary_role    |   status      |   result                  | expectedErrorMessage
        "c1Admin"       |   true            |   "ACTIVE"    |   HttpStatus.OK           | ""
        "c1Admin"       |   null            |   "ACTIVE"    |   HttpStatus.OK           | ""
        "c1Admin"       |   false           |   "ACTIVE"    |   HttpStatus.OK           | ""
        "c1Admin"       |   true            |   "INACTIVE"  |   HttpStatus.OK           | ""
        "c1Admin"       |   true            |   "BAD_VALUE" |   HttpStatus.BAD_REQUEST  | "[errors:[[field:status, message:Invalid value for status BAD_VALUE]]]"
        "c1Admin"       |   "bad"           |   "ACTIVE"    |   HttpStatus.BAD_REQUEST  | "[errors:[[field:primary_role, message:Invalid value for primary_role bad]]]"
    }

    @Unroll
    def "should test put single enrollment Accept and Content-Type headers"(){
        def enrollments = setupEnrollments()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([accept_header])
        headers.setContentType(content_type)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result

        where:
        enrollment      |   accept_header                       |   content_type                        |   result
        "c1Admin"       |   Constants.SUBJECTS_VERSION_1_MT     |   Constants.ENROLLMENT_VERSION_1_MT   |  HttpStatus.NOT_ACCEPTABLE
        "c1Admin"       |   Constants.ENROLLMENT_VERSION_1_MT   |   Constants.SUBJECTS_VERSION_1_MT     |  HttpStatus.UNSUPPORTED_MEDIA_TYPE
        "c1Admin"       |   Constants.ENROLLMENT_VERSION_1_MT   |   Constants.ENROLLMENT_VERSION_1_MT   |  HttpStatus.OK

    }

    @Unroll
    def "should test put single enrollment uuid"(){
        ClassObj classC1 = setupValidClass().updateField("organization", campus1)
        Enrollment c1Admin = enrollmentRepo.save(new Enrollment(user: admin, classObj: classC1, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.INACTIVE))
        Enrollment c2Admin = new Enrollment(user: admin, classObj: classC1, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.INACTIVE)
        c2Admin.uuid = UUID.randomUUID() //this enrollment wont be saved.
        def enrollments = [c1Admin: c1Admin, c2Admin: c2Admin]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT ])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK) {
            checkSingleEnrollmentResponse(resp, enrollments[enrollment])
        } else {
            assert resp.body.errors[0].field == "uuid"
            assert resp.body.errors[0].message == "Invalid enrollment uuid " + enrollments[enrollment].uuid.toString() +"."
        }

        where:
        enrollment      |   result
        "c1Admin"       |   HttpStatus.OK
        "c2Admin"       |   HttpStatus.BAD_REQUEST
    }

    @Unroll
    def "should test put single enrollment teacher restrictions"(){
        def enrollments = setupEnrollments()
        def teachers = ["teacher":teacher, "teacher2": teacher2]

        String token = createToken(teachers[teacherEnrolled], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT ])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result
        if(result != HttpStatus.OK) {
            assert resp.body.toString() == expectedErrorMessage
        }

        where:
        enrollment         |   teacherEnrolled        |     result                   |  expectedErrorMessage
        "c1Student1"       |   "teacher"              |     HttpStatus.OK            |  ""
        "c1Student1"       |   "teacher2"             |     HttpStatus.BAD_REQUEST   |  "[errors:[[field:user_uuid, message:teachers cannot update enrollments for classes into which they are not enrolled]]]"
    }

    @Unroll
    def "should test put single enrollment invalid user uuid"(){

        User invalid = userRepo.save(new User(userName:'bobby',firstName: "bob", lastName: "boberson", type: AppUserType.STUDENT,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'test'))

        def enrollments = setupEnrollments()
        def userUuids = ["valid":enrollments[enrollment].user.uuid, "invalid": invalid.uuid]

        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT ])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def body = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": userUuids[testUserUuid],
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result
        if(result != HttpStatus.OK) {
            assert resp.body.toString() == expectedErrorMessage
        }

        where:
        enrollment         |     testUserUuid             |     result                   |  expectedErrorMessage
        "c1Student1"       |     "valid"                  |     HttpStatus.OK            |  ""
        "c1Student1"       |     "invalid"                |     HttpStatus.BAD_REQUEST   |  "[errors:[[field:user_uuid, message:User not yet enrolled in this class.  Not able to update enrollment.]]]"
    }

    @Unroll
    def "should test put enrollment missing fields"(){
        ClassObj classC1 = setupValidClass().updateField("organization", campus1)
        Enrollment c1Admin = enrollmentRepo.save(new Enrollment(user: admin, classObj: classC1, primaryRole: true, role: Role.ADMINISTRATOR, status: Status.INACTIVE))
        def enrollments = [c1Admin: c1Admin]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setAccept([Constants.ENROLLMENT_VERSION_1_MT ])
        headers.setContentType(Constants.ENROLLMENT_VERSION_1_MT)

        def bodySuccess = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]

        def bodyMissingClassUuid = [
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]

        def bodyMissingUserUuid = [
                "class_uuid": enrollments[enrollment].classObj.uuid, 
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole,
                "status": enrollments[enrollment].status
        ]

        def bodyMissingRole = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "primary_role": false,
                "status": enrollments[enrollment].status
        ]

        def bodyMissingStatus = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role,
                "primary_role": enrollments[enrollment].primaryRole
        ]

        def bodyMissingPrimaryRole = [
                "class_uuid": enrollments[enrollment].classObj.uuid,
                "user_uuid": enrollments[enrollment].user.uuid,
                "role": enrollments[enrollment].role, 
                "status": enrollments[enrollment].status
        ]

        def requestBodies = [
                "bodySuccess": bodySuccess,
                "bodyMissingClassUuid": bodyMissingClassUuid,
                "bodyMissingUserUuid": bodyMissingUserUuid, 
                "bodyMissingRole": bodyMissingRole,
                "bodyMissingStatus": bodyMissingStatus,
                "bodyMissingPrimaryRole": bodyMissingPrimaryRole
        ]
        HttpEntity req = new HttpEntity(requestBodies[body], headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments/${enrollments[enrollment].uuid.toString()}", HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == result
        if(result == HttpStatus.OK) {
            checkSingleEnrollmentResponse(resp, enrollments[enrollment])
        } else {
            assert resp.body.toString() == expectedErrorMessage
        }

        where:
        enrollment      |  body                     |   result                  | expectedErrorMessage
        "c1Admin"       |  "bodySuccess"            |   HttpStatus.OK           | ""
        "c1Admin"       |  "bodyMissingClassUuid"   |   HttpStatus.BAD_REQUEST  | "[errors:[[field:class_uuid, message:Missing required field class_uuid]]]"
        "c1Admin"       |  "bodyMissingUserUuid"    |   HttpStatus.BAD_REQUEST  | "[errors:[[field:user_uuid, message:User not yet enrolled in this class.  Not able to update enrollment.]]]"
        "c1Admin"       |  "bodyMissingRole"        |   HttpStatus.BAD_REQUEST  | "[errors:[[field:role, message:Missing required field role]]]"
        "c1Admin"       |  "bodyMissingStatus"      |   HttpStatus.BAD_REQUEST  | "[errors:[[field:status, message:Missing required field status]]]"
        "c1Admin"       |  "bodyMissingPrimaryRole" |   HttpStatus.OK           | ""
    }

    /**
     *
     * delete enrollment collections test suite covers these tests:
     * 0.  Happy path of an admin delete enrollments for students enrolled in same school
     *      a.  Any planner entries with state = NOT_STARTED should be deleted
     *      b.  Any planner entries with state = IN_PROGRESS will be set to state = OBE and slot = -1
     *      c.  Any attempts with state in(OBE, SUBMITTED, PASSED or FAILED will remain untouched
     *      d.  All Enrollments will be deleted
     *      e.  This test is covered by test (0) in the spock table far below (the test rows are numbered beginning with 0)
     * 1.  Happy path of a teacher deleting enrollments for students enrolled in his / her class
     *      a.  similar rules as [a..d] above
     *      b.  This test is covered by test (1) in the spock table far below (the test rows are numbered beginning with 0)
     * 2.  Teacher with no enrollments tries to delete enrollments in another class
     *      a.  expected HttpStatus.UNAUTHORIZED
     *      b.  This test is covered by test (2) in the spock table far below (the test rows are numbered beginning with 0)
     * 3.  Teacher from campus 1 tries to delete enrollments from a campus 2 class in which he/she is not enrolled
     *      a.  This one will return all of the enrollments submitted HttpStatus.OK; but each one shows up in the resp.body.failure collection
     *      b.  This test is covered by test (3) in the spock table far below (the test rows are numbered beginning with 0)
     * 4.  Admin 2 is from school 2 trying to delete enrollments from school 1.
     *      a.  This one will return all of the enrollments submitted HttpStatus.OK; but each one shows up in the resp.body.failure collection
     *      b.  This test is covered by test (4) in the spock table far below (the test rows are numbered beginning with 0)
     * 5.  A student should never be able to delete and enrollment
     *      a.  expected HttpStatus.UNAUTHORIZED
     *      b.  This test is covered by test (5) in the spock table far below (the test rows are numbered beginning with 0)
     * 6.  test null enrollment uuid
     *      a.  This one will return all of the enrollments submitted HttpStatus.OK; but each one shows up in the resp.body.failure collection
     *      b.  This test is covered by test (6) in the spock table far below (the test rows are numbered beginning with 0)
     * 7.  test not found enrollment uuid
     *      a.  This one will return all of the enrollments submitted HttpStatus.OK; but each one shows up in the resp.body.failure collection
     *      b.  This test is covered by test (7) in the spock table far below (the test rows are numbered beginning with 0)
     * 8.  test invalid enrollment uuid
     *      a.  This one will return all of the enrollments submitted HttpStatus.OK; but each one shows up in the resp.body.failure collection
     *      b.  This test is covered by test (7) in the spock table far below (the test rows are numbered beginning with 0)
     * 9.  test invalid header
     *      a.  expected HttpStatus.NOT_ACCEPTABLE
     *      b.  This test is covered by test (9) in the spock table far below (the test rows are numbered beginning with 0)
     *
     * In all tests, we make sure classD1 enrollments were not deleted - see listOfEnrollmentsNOTDeleted assert
     * see http://confluence.owteam.com/display/KL/Drop+Enrollment
     */
    @Unroll
    def "delete enrollment collections"(){
        given:

        //lists that track expected results
        List<PlannerEntry> plannerEntriesDeleted = []
        List<PlannerEntry> plannerEntriesOBE = []
        List<PlannerEntry> plannerEntriesNotTouched = []

        List<Attempt> attemptsOBE = []
        List<Attempt> attemptsNotTouched = []

        //Delete Enrollment Test Data
        //Basic idea is to setup a school with two campuses.  Class ONE and Class TWO only exist in School One
        //We fundamentally test against Class TWO
        User teacherSchoolD1CampusD1
        User teacherSchoolD1CampusD2
        User teacherSchoolD1CampusD2b
        User adminSchoolD1
        User adminSchoolD2
        List<User> studentsSchoolD1CampusD1 = []
        List<User> studentsSchoolD1CampusD2 = []
        Organization campusD1
        Organization campusD2
        Organization schoolD1

        schoolD1 = new Organization(type: OrganizationType.SCHOOL, name: 'SchoolD1', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(schoolD1)

        campusD1 = new Organization(type: OrganizationType.CAMPUS, name: 'CampusD1', created: new Date(), updated: new Date(), originationId: 'shard1', parent: schoolD1)
        organizationRepo.save(campusD1)

        campusD2 = new Organization(type: OrganizationType.CAMPUS, name: 'CampusD2', created: new Date(), updated: new Date(), originationId: 'shard1', parent: schoolD1)
        organizationRepo.save(campusD2)

        teacherSchoolD1CampusD1 = new User(userName:'teacherD1',firstName: "Dee1", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacherSchoolD1CampusD1.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save(teacherSchoolD1CampusD1)
        teacherSchoolD1CampusD2b = new User(userName:'noEnrollments',firstName: "Dee1b", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacherSchoolD1CampusD2b.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save( teacherSchoolD1CampusD2b)
        teacherSchoolD1CampusD2 = new User(userName:'teacherD1',firstName: "Dee2", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        userRepo.save(teacherSchoolD1CampusD2)
        teacherSchoolD1CampusD2.setOrganizations([schoolD1].asList() + [campusD2].asList())

        adminSchoolD1 = new User(userName:'admin',firstName: "Dee1", lastName: "admin", type: AppUserType.ADMIN,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        adminSchoolD1.setOrganizations([schoolD1].asList())
        userRepo.save(adminSchoolD1)
        adminSchoolD2 = new User(userName:'admin',firstName: "Dee2", lastName: "admin", type: AppUserType.ADMIN,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        adminSchoolD2.setOrganizations([school2].asList())
        userRepo.save(adminSchoolD2)

        Random random = new Random()
        def pool = ['a'..'z'].flatten()
        (1..15).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            studentsSchoolD1CampusD1.add(new User(userName:"studentD1${it}",firstName: randomName, lastName: "studentD1${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date()))
        }

        studentsSchoolD1CampusD1.each {
            it.setOrganizations([schoolD1].asList() + [campusD1].asList())
            userRepo.save(it)
        }

        (1..15).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            studentsSchoolD1CampusD2.add(new User(userName:"studentD2${it}",firstName: randomName, lastName: "studentD2${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date()))
        }

        studentsSchoolD1CampusD2.each {
            it.setOrganizations([schoolD1].asList() + [campusD2].asList())
            userRepo.save(it)
        }

        schoolD1.setUsers(studentsSchoolD1CampusD1.toSet() + studentsSchoolD1CampusD2.toSet() + [adminSchoolD1].toSet() + [teacherSchoolD1CampusD1].toSet() + [teacherSchoolD1CampusD2].toSet())
        organizationRepo.save(schoolD1)

        campusD1.setUsers(studentsSchoolD1CampusD1.toSet() + [adminSchoolD1].toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(campusD1)

        campusD2.setUsers(studentsSchoolD1CampusD2.toSet() + [adminSchoolD1].toSet() + [teacherSchoolD1CampusD2].toSet())
        organizationRepo.save(campusD2)

        //CLASS ONE
        ClassObj classD1 = setupValidClass().updateField("organization", campusD1)
        def classD1Enrollments = []

        PageObj page = setupValidPage(classD1)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment", page, 1)

        enrollmentRepo.save(new Enrollment(user: teacherSchoolD1CampusD1, classObj: classD1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        studentsSchoolD1CampusD1.each {
            Enrollment enrollment = enrollmentRepo.save(new Enrollment(user: it, classObj: classD1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            classD1Enrollments.add(["enrollment_uuid":enrollment.uuid, "user_uuid":enrollment.user.uuid])
        }
        //these 0..2 students had nothing started
        (0..2).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
        }

        //these students are IN_PROGRESS
        (3..5).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt)
        }

        //these students are manually graded - pe.COMPLETED  a.SUBMITTED
        (6..8).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.SUBMITTED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt)
        }

        //these students are manually graded - pe.GRADED  a.FAILED so NOT TOUCHED  the other attempt is IN_PROGRESS so that one is OBE
        (9..11).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.FAILED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt)
            Attempt attempt2 = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt2)
        }

        //these students are manually graded - pe.GRADED  a.PASSED so NOT TOUCHED
        (12..14).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt)
        }

        //CLASS TWO
        ClassObj classD2 = setupValidClass().updateField("organization", campusD2)
        def classD2Enrollments = []

        PageObj page2 = setupValidPage(classD2)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment", page2, 1)

        enrollmentRepo.save(new Enrollment(user: teacherSchoolD1CampusD2, classObj: classD2, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        studentsSchoolD1CampusD2.each {
            Enrollment enrollment = enrollmentRepo.save(new Enrollment(user: it, classObj: classD2, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            classD2Enrollments.add(["enrollment_uuid":enrollment.uuid, "user_uuid":enrollment.user.uuid])
        }

        //these 0..2 students had nothing started and should be deleted
        (0..2).each {
            plannerEntriesDeleted.add(setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it]))
        }

        //these students are IN_PROGRESS and so should be OBE
        (3..5).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it])
            plannerEntriesOBE.add(plannerEntry)
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD2[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptsOBE.add(attempt)
            attemptRepo.save(attempt)
        }

        //these students are manually graded - pe.COMPLETED  a.SUBMITTED  so NOT TOUCHED
        (6..8).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it])
            plannerEntriesNotTouched.add(plannerEntry)
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD2[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.SUBMITTED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptsNotTouched.add(attempt)
            attemptRepo.save(attempt)
        }

        //these students are manually graded - pe.GRADED  a.FAILED  so NOT TOUCHED - combined with another attempt IN_PROGRESS
        (9..11).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it])
            plannerEntriesNotTouched.add(plannerEntry)
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD2[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.FAILED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptsNotTouched.add(attempt)
            attemptRepo.save(attempt)
            PlannerEntry plannerEntry2 = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it])
            plannerEntriesNotTouched.add(plannerEntry2)
            Attempt attempt2 = new Attempt(plannerEntry: plannerEntry2, user: studentsSchoolD1CampusD2[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.SUBMITTED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptsNotTouched.add(attempt2)
            attemptRepo.save(attempt2)
        }

        //these students are manually graded - pe.GRADED  a.PASSED so NOT TOUCHED
        (12..14).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classD2, page, pageAssignment2,studentsSchoolD1CampusD2[it])
            plannerEntriesNotTouched.add(plannerEntry)
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD2[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.PASSED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptsNotTouched.add(attempt)
            attemptRepo.save(attempt)
        }

        //setup invalid Enrollment UUIDS
        def nullEnrollment = []
        def notFoundEnrollment = []
        def invalidEnrollment = []
        nullEnrollment.add(["enrollment_uuid": null])
        notFoundEnrollment.add(["enrollment_uuid": UUID.randomUUID()])
        invalidEnrollment.add(["enrollment_uuid": "12345"])

        def userMap = [student1: studentsSchoolD1CampusD2[0],
                       teacher1: teacherSchoolD1CampusD1,
                       teacherNoEnrollments: teacherSchoolD1CampusD2b,
                       teacher2: teacherSchoolD1CampusD2,
                       admin1: adminSchoolD1,
                       admin2: adminSchoolD2,
                       invalid: 12345]

        def enrollmentsMap = [classD1Enrollments: classD1Enrollments,
                              classD2Enrollments: classD2Enrollments,
                              null: nullEnrollment,
                              notFound: notFoundEnrollment,
                              invalid: invalidEnrollment]
        def classMap = [classD1: classD1, classD2: classD2]
        def body = [enrollments: enrollmentsMap[enrollments]]

        String token = createToken(userMap[userMakingRequest], userMap[userMakingRequest].organizations[0].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_PARAMS_VERSION_1_MT)
        headers.setAccept([testHeaders])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedReturnCode
        if (resp.body.sucessess != null){
            assert resp.body.successes.size() == enrollmentsMap[expectedSuccess].size()
        }

        if(expectedErrors.size()>0) {
            if (resp.statusCode ==  HttpStatus.UNAUTHORIZED) {
                assert resp.body.errors.size() == 1
                resp.body.errors.each { e ->
                    assert e.message.contains(expectedMessage)
                }
            } else if (resp.statusCode ==  HttpStatus.NOT_ACCEPTABLE) {
                assert resp.body.message.contains(expectedMessage)
            } else {
                assert resp.body.failures.size() == enrollmentsMap[expectedErrors].size()
                List<String> expectedUuids = enrollmentsMap[expectedErrors].collect { it.enrollment_uuid.toString() }
                resp.body.failures.each { e ->
                    if (e.enrollment_uuid){
                        assert expectedUuids.contains(e.enrollment_uuid)
                    }
                    assert e.errors.message.contains(expectedMessage)
                }
            }
        }

        if (expectedSuccess.size()>0) {
            def expectedEnrollments = enrollmentsMap[expectedSuccess]
            resp.body.successes.each { e ->
                def expected = expectedEnrollments.find{e.enrollment_uuid == it.enrollment_uuid.toString()}
                assert e.user_uuid == expected.user_uuid.toString()
            }
            //all of these enrollments should have been deleted
            List<Enrollment> listOfEnrollmentsDeleted = enrollmentRepo.findAll(enrollmentsMap[enrollments].enrollment_uuid)
            assert listOfEnrollmentsDeleted.size() == 0

            //all of these enrollments should NOT have been deleted - this is class ONE
            List<Enrollment> listOfEnrollmentsNOTDeleted = enrollmentRepo.findAllByClassObjUuid(classMap["classD1"].uuid)
            assert listOfEnrollmentsNOTDeleted.size() == 16

            //these plannerEntries should have been deleted
            List<PlannerEntry> listOfPlannerEntriesDeleted = plannerEntryRepo.findAll(plannerEntriesDeleted.uuid)
            assert listOfPlannerEntriesDeleted.size() == 0

            //these plannerEntries should not have been touched
            List<PlannerEntry> listOfPlannerEntriesNotTouched = plannerEntryRepo.findAll(plannerEntriesNotTouched.uuid)
            assert listOfPlannerEntriesNotTouched.size() == plannerEntriesNotTouched.size()
            plannerEntriesNotTouched.each { pe ->
                PlannerEntry plannerEntry1 = listOfPlannerEntriesNotTouched.find {
                    it.uuid == pe.uuid
                }
                assert plannerEntry1.status == pe.status
            }

            //these plannerEntries should have been switched to OBE and slot = -1
            List<PlannerEntry> listOfPlannerEntriesOBE = plannerEntryRepo.findAll(plannerEntriesOBE.uuid)
            assert listOfPlannerEntriesOBE.size() == plannerEntriesOBE.size()
            plannerEntriesOBE.each { pe ->
                PlannerEntry plannerEntry1 = listOfPlannerEntriesOBE.find {
                    it.uuid == pe.uuid
                }
                assert plannerEntry1.status == PlannerEntryState.OBE
                assert plannerEntry1.slot == -1
            }

            //these Attempts should have been switched to OBE
            List<Attempt> listOfAttemptsOBE = attemptRepo.findAll(attemptsOBE.uuid)
            assert listOfAttemptsOBE.size() == attemptsOBE.size()
            attemptsOBE.each { a ->
                Attempt attempt1 = listOfAttemptsOBE.find {
                    it.uuid == a.uuid
                }
                assert attempt1.state == AttemptState.OBE
            }

            //these attempts should not have been touched
            List<Attempt> listOfAttemptsNotTouched = attemptRepo.findAll(attemptsNotTouched.uuid)
            assert listOfAttemptsNotTouched.size() == attemptsNotTouched.size()
            attemptsNotTouched.each { a ->
                Attempt attempt1 = listOfAttemptsNotTouched.find {
                    it.uuid == a.uuid
                }
                assert attempt1.state == a.state
            }
        }

        where:
        enrollments          | userMakingRequest      | testHeaders                                | expectedReturnCode            | expectedSuccess       | expectedErrors       |  expectedMessage
        "classD2Enrollments" | "admin1"               | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | "classD2Enrollments"  | ""                   |  ""
        "classD2Enrollments" | "teacher2"             | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | "classD2Enrollments"  | ""                   |  "Your role is teacher but you do not have any classes assigned to you so you can not drop any enrollments"
        "classD2Enrollments" | "teacherNoEnrollments" | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.UNAUTHORIZED       | ""                    | "classD2Enrollments" |  ""
        "classD2Enrollments" | "teacher1"             | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | ""                    | "classD2Enrollments" |  "The teacher is not authorized to drop this enrollment"
        "classD2Enrollments" | "admin2"               | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | ""                    | "classD2Enrollments" |  "The admin is not authorized to drop this enrollment"
        "classD2Enrollments" | "student1"             | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.UNAUTHORIZED       | ""                    | ""                   |  "Only a teacher or admin can drop an enrollment"
        "null"               | "admin1"               | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | ""                    | "null"               |  "unable to construct a UUID from the enrollment_uuid"
        "notFound"           | "admin1"               | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | ""                    | "notFound"           |  "unable to find an enrollment record"
        "invalid"            | "admin1"               | Constants.ENROLLMENT_MESSAGES_VERSION_1_MT | HttpStatus.OK                 | ""                    | "invalid"            |  "unable to construct a UUID from the enrollment_uuid"
        "classD2Enrollments" | "admin1"               | Constants.CLASSES_VERSION_1_MT             | HttpStatus.NOT_ACCEPTABLE     | ""                    | "classD2Enrollments" |  "Could not find acceptable representation"
    }

    @Unroll
    def "test rollback of two constraint violation enrollments in the delete enrollment collection"(){
        given:

        //Delete Enrollment Test Data
        User teacherSchoolD1CampusD1
        List<User> studentsSchoolD1CampusD1 = []
        def expectedSuccesses = []
        def expectedFailures = []
        Organization campusD1
        Organization schoolD1

        schoolD1 = new Organization(type: OrganizationType.SCHOOL, name: 'SchoolD1', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(schoolD1)

        campusD1 = new Organization(type: OrganizationType.CAMPUS, name: 'CampusD1', created: new Date(), updated: new Date(), originationId: 'shard1', parent: schoolD1)
        organizationRepo.save(campusD1)

        teacherSchoolD1CampusD1 = new User(userName:'teacherD1',firstName: "Dee1", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacherSchoolD1CampusD1.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save(teacherSchoolD1CampusD1)

        Random random = new Random()
        def pool = ['a'..'z'].flatten()
        (1..15).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            studentsSchoolD1CampusD1.add(new User(userName:"studentD1${it}",firstName: randomName, lastName: "studentD1${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date()))
        }

        studentsSchoolD1CampusD1.each {
            it.setOrganizations([schoolD1].asList() + [campusD1].asList())
            userRepo.save(it)
        }

        schoolD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(schoolD1)

        campusD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(campusD1)

        //CLASS ONE
        ClassObj classD1 = setupValidClass().updateField("organization", campusD1)
        List<Enrollment> classD1Enrollments = []

        PageObj page = setupValidPage(classD1)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment", page, 1)

        enrollmentRepo.save(new Enrollment(user: teacherSchoolD1CampusD1, classObj: classD1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        studentsSchoolD1CampusD1.each {
            Enrollment enrollment = enrollmentRepo.save(new Enrollment(user: it, classObj: classD1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            classD1Enrollments.add("enrollment_uuid": enrollment.uuid)
        }

        (0..10).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
            expectedSuccesses.add(classD1Enrollments[it])
        }

        //these two will throw a contraint violation  - enrollmentService will try to delete plannerEntry without having
        //deleting the attempts first
        (11..12).each {
            PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            Attempt attempt = new Attempt(plannerEntry: plannerEntry, user: studentsSchoolD1CampusD1[it], activityId: plannerEntry.activityId, sectionCount: 66, sectionTotalCount: 1, questionCount: 1, questionsAttemptedCount: 1, questionsCorrectCount: 1, questionsIncorrectCount: 1, questionsNotScoredCount: 1, state: AttemptState.IN_PROGRESS, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: null, responseOverrides: null, includedManualGraded: true, completedAt: new Date(), createdAt: new Date(), updatedAt: new Date(), creditBearing: true)
            attemptRepo.save(attempt)
            expectedFailures.add(classD1Enrollments[it])
        }

        (13..14).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
            expectedSuccesses.add(classD1Enrollments[it])
        }

        def enrollmentsMap = [classD1Enrollments: classD1Enrollments, expectedSuccesses: expectedSuccesses, expectedFailures: expectedFailures]
        def body = [enrollments: enrollmentsMap[enrollments]]

        String token = createToken(teacherSchoolD1CampusD1, teacherSchoolD1CampusD1.organizations[0].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_PARAMS_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedReturnCode
        assert resp.body.successes.size() == enrollmentsMap[expectedSuccess].size()
        assert resp.body.failures.size() == enrollmentsMap[expectedErrors].size()

        List<String> expectedSuccessUuids = enrollmentsMap[expectedSuccess].collect { it.enrollment_uuid.toString() }
        resp.body.successes.each { e ->
            assert expectedSuccessUuids.contains(e.enrollment_uuid)
        }

        List<String> expectedFailureUuids = enrollmentsMap[expectedErrors].collect { it.enrollment_uuid.toString() }
        resp.body.failures.each { e ->
            assert expectedFailureUuids.contains(e.enrollment_uuid)
        }

        where:
        enrollments          | expectedReturnCode   | expectedSuccess      | expectedErrors        |  expectedMessage
        "classD1Enrollments" | HttpStatus.OK        | "expectedSuccesses"  | "expectedFailures"    |  ""

    }

    @Unroll
    def "test subset of enrollments in the sample data set"(){
        given:

        //Delete Enrollment Test Data
        User teacherSchoolD1CampusD1
        List<User> studentsSchoolD1CampusD1 = []
        def expectedSuccesses = []
        Organization campusD1
        Organization schoolD1

        schoolD1 = new Organization(type: OrganizationType.SCHOOL, name: 'SchoolD1', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(schoolD1)

        campusD1 = new Organization(type: OrganizationType.CAMPUS, name: 'CampusD1', created: new Date(), updated: new Date(), originationId: 'shard1', parent: schoolD1)
        organizationRepo.save(campusD1)

        teacherSchoolD1CampusD1 = new User(userName:'teacherD1',firstName: "Dee1", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacherSchoolD1CampusD1.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save(teacherSchoolD1CampusD1)

        Random random = new Random()
        def pool = ['a'..'z'].flatten()
        (1..15).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            studentsSchoolD1CampusD1.add(new User(userName:"studentD1${it}",firstName: randomName, lastName: "studentD1${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date()))
        }

        studentsSchoolD1CampusD1.each {
            it.setOrganizations([schoolD1].asList() + [campusD1].asList())
            userRepo.save(it)
        }

        schoolD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(schoolD1)

        campusD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(campusD1)

        //CLASS ONE
        ClassObj classD1 = setupValidClass().updateField("organization", campusD1)
        List<Enrollment> classD1Enrollments = []

        PageObj page = setupValidPage(classD1)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment", page, 1)

        enrollmentRepo.save(new Enrollment(user: teacherSchoolD1CampusD1, classObj: classD1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))

        studentsSchoolD1CampusD1.each {
            Enrollment enrollment = enrollmentRepo.save(new Enrollment(user: it, classObj: classD1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
            classD1Enrollments.add("enrollment_uuid": enrollment.uuid)
        }

        (0..10).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
        }

        (11..12).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
            expectedSuccesses.add(classD1Enrollments[it])
        }

        (13..14).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
        }

        def enrollmentsMap = [classD1Enrollments: classD1Enrollments, expectedSuccesses: expectedSuccesses]
        def body = [enrollments: enrollmentsMap[enrollments]]

        String token = createToken(teacherSchoolD1CampusD1, teacherSchoolD1CampusD1.organizations[0].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_PARAMS_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedReturnCode
        assert resp.body.successes.size() == enrollmentsMap[expectedSuccess].size()
        assert resp.body.failures.size() == 0

        List<String> expectedSuccessUuids = enrollmentsMap[expectedSuccess].collect { it.enrollment_uuid.toString() }
        resp.body.successes.each { e ->
            assert expectedSuccessUuids.contains(e.enrollment_uuid)
        }

        List<Enrollment> listOfEnrollmentsNOTDeleted = enrollmentRepo.findAllByClassObjUuid(classD1.uuid)
        assert listOfEnrollmentsNOTDeleted.size() == 14 //13 students plus the teacher

        where:
        enrollments         | expectedReturnCode   | expectedSuccess
        "expectedSuccesses" | HttpStatus.OK        | "expectedSuccesses"
    }

    @Unroll
    def "test teacher delete enrollments in the sample data set"(){
        given:

        //Delete Enrollment Test Data
        User adminSchoolD1
        User teacherSchoolD1CampusD1
        User teacher2SchoolD1CampusD1
        List<User> studentsSchoolD1CampusD1 = []

        def expectedSuccesses = []

        Organization campusD1
        Organization schoolD1

        schoolD1 = new Organization(type: OrganizationType.SCHOOL, name: 'SchoolD1', created: new Date(), updated: new Date(), originationId: 'shard1')
        organizationRepo.save(schoolD1)

        campusD1 = new Organization(type: OrganizationType.CAMPUS, name: 'CampusD1', created: new Date(), updated: new Date(), originationId: 'shard1', parent: schoolD1)
        organizationRepo.save(campusD1)

        adminSchoolD1 = new User(userName:'admin',firstName: "Dee1", lastName: "admin", type: AppUserType.ADMIN,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        adminSchoolD1.setOrganizations([schoolD1].asList())
        userRepo.save(adminSchoolD1)

        teacherSchoolD1CampusD1 = new User(userName:'teacherD1',firstName: "Dee1", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacherSchoolD1CampusD1.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save(teacherSchoolD1CampusD1)

        teacher2SchoolD1CampusD1 = new User(userName:'teacherD2',firstName: "Dee1", lastName: "teacher", type: AppUserType.TEACHER,status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date(),originationId: 'shard1')
        teacher2SchoolD1CampusD1.setOrganizations([schoolD1].asList() + [campusD1].asList())
        userRepo.save(teacher2SchoolD1CampusD1)

        Random random = new Random()
        def pool = ['a'..'z'].flatten()
        (1..15).each {
            String randomName = (0..10).collect { pool[random.nextInt(pool.size())] }
            studentsSchoolD1CampusD1.add(new User(userName:"studentD1${it}",firstName: randomName, lastName: "studentD1${it}", type: AppUserType.STUDENT,originationId: 'shard1',status: AppUserStatus.ACTIVE,created: new Date(),updated: new Date()))
        }

        studentsSchoolD1CampusD1.each {
            it.setOrganizations([schoolD1].asList() + [campusD1].asList())
            userRepo.save(it)
        }

        schoolD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(schoolD1)

        campusD1.setUsers(studentsSchoolD1CampusD1.toSet() + [teacherSchoolD1CampusD1].toSet())
        organizationRepo.save(campusD1)

        //CLASS ONE
        ClassObj classD1 = setupValidClass().updateField("organization", campusD1)
        List<Enrollment> classD1Enrollments = []
        def studentEnrollments = []

        PageObj page = setupValidPage(classD1)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment", page, 1)

        Enrollment enrollment = new Enrollment(user: teacherSchoolD1CampusD1, classObj: classD1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE)
        enrollmentRepo.save(enrollment)
        classD1Enrollments.add("enrollment_uuid": enrollment.uuid)
        expectedSuccesses.add(classD1Enrollments[0])

        studentsSchoolD1CampusD1.each {
            Enrollment enrollment1 = new Enrollment(user: it, classObj: classD1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)
            enrollmentRepo.save(enrollment1)
            studentEnrollments.add("enrollment_uuid": enrollment1.uuid)
        }

        (0..10).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
        }

        (11..12).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1,studentsSchoolD1CampusD1[it])
        }

        (13..14).each {
            setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classD1, page, pageAssignment1, studentsSchoolD1CampusD1[it])
        }

        def userMap = [teacher1: teacherSchoolD1CampusD1,
                       teacher2: teacher2SchoolD1CampusD1,
                       admin1: adminSchoolD1]

        def enrollmentsMap = [classD1Enrollments: classD1Enrollments, expectedSuccesses: expectedSuccesses, studentEnrollments:  studentEnrollments]
        def body = [enrollments: enrollmentsMap[enrollments]]

        String token = createToken(userMap[userMakingRequest], teacherSchoolD1CampusD1.organizations[0].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ENROLLMENT_PARAMS_VERSION_1_MT)
        headers.setAccept([Constants.ENROLLMENT_MESSAGES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/enrollments", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedReturnCode

        if (resp.statusCode == HttpStatus.OK){
            assert resp.body.successes.size() == enrollmentsMap[expectedSuccess].size()
            List<String> expectedSuccessUuids = enrollmentsMap[expectedSuccess].collect { it.enrollment_uuid.toString() }
            resp.body.successes.each { e ->
                assert expectedSuccessUuids.contains(e.enrollment_uuid)
            }
        } else if (resp.statusCode ==  HttpStatus.UNAUTHORIZED) {
            assert resp.body.errors.size() == 1
            resp.body.errors.each { e ->
                assert e.message.contains(expectedMessage)
            }
        }

        //all of these enrollments should NOT have been deleted - this is class ONE
        List<Enrollment> listOfEnrollmentsNOTDeleted = enrollmentRepo.findAll(enrollmentsMap[enrollmentsNOTDeleted].enrollment_uuid)
        assert listOfEnrollmentsNOTDeleted.size() == studentsSchoolD1CampusD1.size()

        where:
        //teacher1 deletes teacher1
        //teacher2 deletes teacher1  - not Authorized
        //admin1 deletes teacher1
        enrollments          | userMakingRequest  || expectedReturnCode        | expectedSuccess     | enrollmentsNOTDeleted | expectedMessage
        "classD1Enrollments" | "teacher1"         || HttpStatus.OK             | "expectedSuccesses" | "studentEnrollments"  | ""
        "classD1Enrollments" | "teacher2"         || HttpStatus.UNAUTHORIZED   | ""                  | "studentEnrollments"  | "Your role is teacher but you do not have any classes assigned to you so you can not drop any enrollments"
        "classD1Enrollments" | "admin1"           || HttpStatus.OK             | "expectedSuccesses" | "studentEnrollments"  | ""
    }

    private void checkSingleEnrollmentResponse(HttpEntity resp, Enrollment expectedEnrollment){
        def expectedUser = [
                "user_uuid": expectedEnrollment.user.uuid.toString(),
                "first_name": expectedEnrollment.user.firstName,
                "last_name": expectedEnrollment.user.lastName,
                "last_logged_in_at": new DateFormat().format(expectedEnrollment.user.lastLoggedInAt),
                "_links": [
                        "self": ["href": "${rosteringBaseUri}" + "/users/" + expectedEnrollment.user.uuid.toString()]
                ]
        ]

        def responseEnrollment = resp.body

        assert expectedEnrollment.role == responseEnrollment.role as Role
        assert expectedEnrollment.status == responseEnrollment.status as Status
        assert expectedEnrollment.classObj.uuid.toString() == responseEnrollment.class_uuid
        assert expectedUser == responseEnrollment.user
        assert expectedEnrollment.primaryRole == responseEnrollment.primary_role
    }

    private void checkEnrollmentResponse(HttpEntity resp, List<String> expectedUuids, Map<String, Enrollment> enrollments){
        Enrollment enrollment1 = enrollments.values().find { it.uuid.toString() == expectedUuids.first()}

        assert resp.statusCode == HttpStatus.OK
        assert resp.body.current_page == 1
        assert resp.body.total_pages == 1
        assert resp.body.page_size == expectedUuids.size()

        assert resp.body.enrollments.size == expectedUuids.size()
        resp.body.enrollments.each { e ->
            assert expectedUuids.contains(e.enrollment_uuid)
            expectedUuids.remove(e.enrollment_uuid)
        }

        def expectedUser = [
                "user_uuid": enrollment1.user.uuid.toString(),
                "first_name": enrollment1.user.firstName,
                "last_name": enrollment1.user.lastName,
                "last_logged_in_at":new DateFormat().format(enrollment1.user.lastLoggedInAt),
                "_links": [
                        "self": ["href": "${rosteringBaseUri}" + "/users/" + enrollment1.user.uuid.toString()]
                ]
        ]

        def responseEnrollment = resp.body.enrollments.find { it.enrollment_uuid == enrollment1.uuid.toString() }

        assert enrollment1.role == responseEnrollment.role as Role
        assert enrollment1.status == responseEnrollment.status as Status
        assert enrollment1.classObj.uuid.toString() == responseEnrollment.class_uuid
        assert expectedUser == responseEnrollment.user
        assert enrollment1.primaryRole == responseEnrollment.primary_role

    }
	
	private int assignAttemptsToEnrollment(Enrollment enrollment, int numberAttempts){
		for( int inx = 1; inx <= numberAttempts; inx++){
			PageObj page = setupValidPage(enrollment.classObj, PageState.ACTIVE)
			Assignment assignment = setupValidAssignment("tester")
			PageAssignment pageAssignment = setupValidPageAssignment("test", page, 1, assignment.uuid)
			PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, enrollment.classObj, page, pageAssignment, enrollment.user)
			Attempt attempt = setupAttempt(plannerEntry, enrollment.user, AttemptState.SUBMITTED,  1, null, new Date(), true)
		}
		return numberAttempts * ATTEMPT_TIME_ON_TASK
	}

    private Map<String, Enrollment> setupEnrollments(){

        ClassObj classC1 = setupValidClass().updateField("organization", campus1)
        ClassObj classC2 = setupValidClass().updateField("organization", campus2)
        ClassObj classC2a = setupValidClass().updateField("organization", campus2)
        ClassObj classS1 = setupValidClass().updateField("organization", school)

        Enrollment c1Admin = enrollmentRepo.save(new Enrollment(user: admin, classObj: classC1, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.INACTIVE))
        List<Enrollment> c1Students = students.take(1).collect {
            return enrollmentRepo.save(new Enrollment(user: it, classObj: classC1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        }
        c1Students.addAll(students.takeRight(4).take(2).collect {
            return enrollmentRepo.save(new Enrollment(user: it, classObj: classC1, primaryRole: false, role: Role.STUDENT, status: Status.INACTIVE))
        })

        Enrollment c1Teacher = enrollmentRepo.save(new Enrollment(user: teacher, classObj: classC1, primaryRole: true, role: Role.TEACHER, status: Status.ACTIVE))


        Enrollment c2Admin = enrollmentRepo.save(new Enrollment(user: admin, classObj: classC2, primaryRole: true, role: Role.ADMINISTRATOR, status: Status.ACTIVE))
        List<Enrollment> c2Students = students.take(2).collect {
            return enrollmentRepo.save(new Enrollment(user: it, classObj: classC2, primaryRole: false, role: Role.STUDENT, status: Status.INACTIVE))
        }
        List<Enrollment> c2aStudents = students.take(2).collect {
            return enrollmentRepo.save(new Enrollment(user: it, classObj: classC2a, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        }
        Enrollment c2Teacher = enrollmentRepo.save(new Enrollment(user: teacher3, classObj: classC2, primaryRole: false, role: Role.TEACHER, status: Status.INACTIVE))

        Enrollment s1Admin = enrollmentRepo.save(new Enrollment(user: admin, classObj: classS1, primaryRole: true, role: Role.ADMINISTRATOR, status: Status.ACTIVE))
        Enrollment s1Student = enrollmentRepo.save(new Enrollment(user: students[0], classObj: classS1, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
		
        return [
                c1Admin: c1Admin,
                c1Student1 : c1Students[0],
                c1Student2 : c1Students[1],
                c1Student3 : c1Students[2],
                c1Teacher : c1Teacher,
                c2Admin : c2Admin,
                c2Student1 : c2Students[0],
                c2Student2 : c2Students[1],
                c2Teacher : c2Teacher,
                c2aStudent1 : c2aStudents[0],
                c2aStudent2 : c2aStudents[1],
                s1Admin : s1Admin,
                s1Student : s1Student
        ]
    }

    private List<Enrollment> setupEnrollmentsForSorting(String field){
        List<Enrollment> enrollments = []
        ClassObj classObj = setupValidClass()
        switch (field){
            case "role":
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)))
                break
            case "status":
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.INACTIVE)))
                break
            case "enrollment_uuid":
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                break
            case "class_uuid":
                ClassObj classObj2 = setupValidClass()
                ClassObj classObj3 = setupValidClass()
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj2, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj3, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                break
            case "primary_role":
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: false, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                enrollments.add(enrollmentRepo.save(new Enrollment(user: admin, classObj: classObj, primaryRole: true, role: Role.ADMINISTRATOR, status: Status.ACTIVE)))
                break
            case "user.first_name":
            case "user.last_name":
            case "user.user_uuid":
                students.each {
                    enrollments.add(enrollmentRepo.save(new Enrollment(user: it, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE)))
                }
                break
        }
        return enrollments
    }

    private setupValidClass(){
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: "test class name",
                subject: subjectsService.findOne(subject.uuid, school.uuid),
                organization: campus1,
                creatorUuid: teacher.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                done: false
        )
        classObj = classRepo.save(classObj)
        return classObj
    }

    private void verifyEnrollments(resp, body, success = (0..body.size-1).collect{it}, failure = [], expectedErrors = []) {
        assert resp.statusCode == HttpStatus.OK
        success.eachWithIndex { bodyIndex, respIndex ->
            assert resp.body.successes[respIndex].user_uuid == body[bodyIndex].user_uuid.toString()
            assert resp.body.successes[respIndex].class_uuid == body[bodyIndex].class_uuid.toString()

            Enrollment actual = enrollmentRepo.findOne(UUID.fromString(resp.body.successes[respIndex].enrollment_uuid))

            assert actual != null
            assert actual.classObj.uuid == body[bodyIndex].class_uuid
            assert actual.user.uuid == body[bodyIndex].user_uuid
            assert actual.role == body[bodyIndex].role as Role
            assert actual.primaryRole == body[bodyIndex].primary_role
            assert actual.status == body[bodyIndex].status as Status
        }
        failure.eachWithIndex { bodyIndex, respIndex ->
            assert resp.body.failures[respIndex].user_uuid == body[bodyIndex].user_uuid.toString()
            assert resp.body.failures[respIndex].class_uuid == body[bodyIndex].class_uuid.toString()
            assert resp.body.failures[respIndex].errors.size == expectedErrors[respIndex].size()
            expectedErrors[respIndex].each { error ->
                assert resp.body.failures[respIndex].errors.contains(error)
            }
        }
    }

    private static String rolePicker(user){
        switch(user){
            case "student":
                return Role.STUDENT.toString()
            case "teacher":
                return Role.TEACHER.toString()
            case "admin":
                return Role.ADMINISTRATOR.toString()
            default:
                return ""
        }
    }
}
