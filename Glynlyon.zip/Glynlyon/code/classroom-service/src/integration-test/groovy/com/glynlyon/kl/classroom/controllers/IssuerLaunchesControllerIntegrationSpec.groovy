package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.IssuerLaunch
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.IssuerLaunchRepo
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.apache.http.NameValuePair
import org.apache.http.client.utils.URLEncodedUtils
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

import java.nio.charset.StandardCharsets

class IssuerLaunchesControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    IssuerLaunchesController controller

    @Autowired
    IssuerLaunchRepo issuerLaunchRepo

    String issuerBaseUrl = "https://hogwarts.edu"

    Organization school
    User admin

    def setup(){
        admin = new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        school = new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date(), children: [])
    }

    @Unroll
    def "A GET request will mark a token as launched"(){
        given:
        def token = createToken()

        IssuerLaunch existingJwt = new IssuerLaunch(token)
        existingJwt.launched = tokenUsed
        issuerLaunchRepo.save(existingJwt)

        if(expectedStatus == HttpStatus.NOT_FOUND) {
            existingJwt.uuid = UUID.randomUUID()
        }

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/issuerlaunches/${existingJwt.uuid}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.OK) {
            assert resp.body.jwt == existingJwt.jwt
        }
        else if(expectedStatus == HttpStatus.NOT_FOUND) {
            assert resp.body == [errors : [[message : "Could not find issuer launch with uuid " + existingJwt.uuid]]]
        }

        where:
        tokenUsed | expectedStatus
        false     | HttpStatus.OK
        false     | HttpStatus.NOT_FOUND
        true      | HttpStatus.GONE
    }

    @Unroll
    def "should create IssuerLaunch and associated jwt with random uuid"(){
        given:
        def body = [
                action: action
        ]

        def glCustomInfo = [
                "sub_display_name" : admin.lastName + ", " + admin.firstName,
                "role_in_issuer"  : admin.type,
                "school_uuid": school.uuid,
                "datasource" : "test",
                "issuer_base_url" : issuerBaseUrl
        ]

        def token = Jwts.builder().setExpiration(new Date().plus(1)).setIssuer(iss).setSubject(admin.uuid.toString()).claim("gl_custom", glCustomInfo).signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8)).compact()


        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/issuerlaunches", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == expectedStatus
        if(expectedStatus == HttpStatus.CREATED) {
            URI location = resp.headers.getLocation()
            List<NameValuePair> nameValuePairs = URLEncodedUtils.parse(location, StandardCharsets.UTF_8.name())
            UUID uuid = UUID.fromString(nameValuePairs.find{it.name == "launchId"}.value)
            IssuerLaunch actual = issuerLaunchRepo.findOne(uuid)
            assert actual.jwt == token
            assert actual.date_launched == null
            assert !actual.launched
            assert location.toString().contains(issuerBaseUrl)
            assert nameValuePairs.find{it.name == "action"}.value == action
        }

        where:
        action    | iss       | expectedStatus
        "home"    | "ow-v2"   | HttpStatus.CREATED
        "unknown" | "ow-v2"   | HttpStatus.BAD_REQUEST
        "home"    | "unknown" | HttpStatus.BAD_REQUEST
        null      | "unknown" | HttpStatus.BAD_REQUEST
    }

    def "should reject post without token"(){
        given:
        def body = [
                action: "home"
        ]

        HttpHeaders headers = new HttpHeaders()
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/issuerlaunches", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED
    }
}