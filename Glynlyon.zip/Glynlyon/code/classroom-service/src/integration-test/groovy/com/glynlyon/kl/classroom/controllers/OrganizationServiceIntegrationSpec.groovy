package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassGradeLevel
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.ClassObjSubtype
import com.glynlyon.kl.classroom.model.ClassObjType
import com.glynlyon.kl.classroom.model.Grade
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Subject
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.ClassGradeLevelRepo
import com.glynlyon.kl.classroom.repo.ClassRepo
import com.glynlyon.kl.classroom.repo.SubjectRepo
import com.glynlyon.kl.classroom.service.ClassGradeLevelService
import com.glynlyon.kl.classroom.service.SubjectsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.embedded.LocalServerPort
import org.springframework.boot.web.client.RestTemplateBuilder
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.web.client.RestClientException
import org.springframework.web.client.RestTemplate
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes

class OrganizationServiceIntegrationSpec extends BaseRestSpec {

    @LocalServerPort
    Integer port

    @Autowired
    ClassRepo classRepo

    @Autowired
    SubjectRepo subjectRepo

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    ClassGradeLevelRepo gradeLevelRepo

    @Autowired
    ClassGradeLevelService gradeLevelIdService

    @Autowired
    SubjectsService subjectsService

    @Autowired
    RestTemplateBuilder restTemplateBuilder

    @Value('${rostering.base.uri}')
    String rosteringBaseUri

    User teacher
    User admin
    User teacher2
    User teacher3
    Organization school
    Organization campus1
    Organization campus2

    def setup(){
        teacher = new User(firstName: 'testTeacher1', lastName: 'teacherLast', userName: 'testTeacher1', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        teacher2 = new User(firstName: 'testTeacher2', lastName: 'teacherLast', userName: 'testTeacher2', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        teacher3 = new User(firstName: 'testTeacher3', lastName: 'teacherLast', userName: 'testTeacher3', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        admin = new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())

        school = new Organization(name: 'Campus 3', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date(), children: [campus1])
        organizationRepo.save(school)

        campus1 = new Organization(name: 'Campus 1', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school)
        campus2 = new Organization(name: 'Campus 2', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date())
        organizationRepo.save(campus1)
        organizationRepo.save(campus2)

        admin.organizations = [school]
        userRepo.save(teacher)
        userRepo.save(teacher2)
        userRepo.save(teacher3)
        userRepo.save(admin)

        RestTemplate restTemplate = new RestTemplate() {
            @Override
            public <T> ResponseEntity<T> exchange(String url, HttpMethod method,
                                                  HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables) throws RestClientException {

                return new ResponseEntity([[orgs: [[sourcedId: school.uuid.toString(), name: 'school', type: 'school']] ,
                                                  page_count: 1]], HttpStatus.OK)
            }
        }

        RestTemplateBuilder.metaClass.build = {
            return restTemplate
        }



        ClassObj.metaClass.updateField { String field, Object value ->
            delegate."${field}" = value
            return classRepo.save(delegate)
        }
    }


    def "Teacher can not create a class with school as org"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "state"                 : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : school.uuid.toString(),
                "creator_uuid"          : teacher.uuid.toString(),
        ]
        String token = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)


        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field[0] == "organization_uuid"
        assert resp.body.errors.message[0] == "TEACHER can not create classes using school UUID " + school.uuid.toString()
    }

    def "Admin can create a class with school as org"() {
        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))

        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "state"                 : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : subject.uuid.toString(),
                "organization_uuid"     : school.uuid.toString(),
                "creator_uuid"          : teacher.uuid.toString(),
        ]
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.CREATED

        URI location = resp.headers.getLocation()
        UUID uuid = UUID.fromString(location.path.substring(location.path.lastIndexOf("/") + 1))
        ClassObj actual = classRepo.findByUuid(uuid)

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.state as ClassObjState
        assert actual.creatorUuid == teacher.uuid
        assert actual.organization.uuid == school.uuid
        assert actual.subject.uuid == subject.uuid
    }

    def "Admin should be able to update a class with school org"(){
        given:
        String token = createToken(admin, school.uuid)
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer ${token}")
        request.setContentType(Constants.CLASSES_VERSION_1_MT.toString())
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        def classObj = setupValidClass()

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "state"                 : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : classObj.subject.uuid.toString(),
                "organization_uuid"     : classObj.organization.uuid.toString(),
                "creator_uuid"          : classObj.creatorUuid.toString(),
                "class_id"              : "ID",
                "grade_level"           : ["4", "5"],
                "notes"                 : "NOTE",
                "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                "access_date"           : "2016-08-13T09:31:00-07:00",
                "stop_date"             : "2018-08-14T09:31:00-07:00"
        ]

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        ClassObj actual = classRepo.findByUuid(classObj.uuid)
        List<ClassGradeLevel> grades = gradeLevelRepo.findAllByClassUuid(classObj.uuid)

        def dateFormat = new DateFormat()

        assert actual != null
        assert actual.type == body.type as ClassObjType
        assert actual.subtype == body.sub_type as ClassObjSubtype
        assert actual.name == body.name
        assert actual.state == body.state as ClassObjState
        assert actual.creatorUuid == classObj.creatorUuid
        assert actual.organization.uuid == classObj.organization.uuid
        assert actual.subject.uuid == classObj.subject.uuid
        assert actual.classId == body.class_id
        assert actual.notes == body.notes
        assert actual.academicSession.uuid == classObj.academicSession.uuid
        assert dateFormat.format(actual.accessDate) == body.access_date
        assert dateFormat.format(actual.stopDate) == body.stop_date

        assert grades.size() == body.grade_level.size()
        grades.each {
            assert body.grade_level.contains(it.grade.type)
        }
    }
//
    def "Teacher should not be able to update a class with school org"(){
        given:
        String token = createToken(admin, school.uuid)
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer ${token}")
        request.setContentType(Constants.CLASSES_VERSION_1_MT.toString())
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        def classObj = setupValidClass()

        def body = [
                "type"                  : "CLASS",
                "sub_type"              : "STANDARD",
                "state"                 : "BUILDING",
                "name"                  : "Biology Period 1",
                "subject_uuid"          : classObj.subject.uuid.toString(),
                "organization_uuid"     : classObj.organization.uuid.toString(),
                "creator_uuid"          : classObj.creatorUuid.toString(),
                "class_id"              : "ID",
                "grade_level"           : ["4", "5"],
                "notes"                 : "NOTE",
                "academic_session_uuid" : classObj.academicSession.uuid.toString(),
                "access_date"           : "2016-08-13T09:31:00-07:00",
                "stop_date"             : "2018-08-14T09:31:00-07:00"
        ]

        String teacherToken = createToken(teacher, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${teacherToken}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/"+classObj.uuid, HttpMethod.PUT, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
    }


    def "test get classes for admin"(){
        given:
        String token = createToken(admin, school.uuid)
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer ${token}")
        request.setContentType(Constants.CLASSES_VERSION_1_MT.toString())
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        ClassObj classObj1 = setupValidClass().updateField("organization", school)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        resp.body.classes[0] != null
    }

    def "test teacher can not get classes where org is school"(){
        given:
        String token = createToken(admin, school.uuid)
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer ${token}")
        request.setContentType(Constants.CLASSES_VERSION_1_MT.toString())
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        ClassObj classObj1 = setupValidClass().updateField("organization", school)

        HttpHeaders headers = new HttpHeaders()
        String teacherToken = createToken(teacher, school.uuid)
        headers.set("Authorization", "Bearer ${teacherToken}")
        headers.setContentType(Constants.CLASSES_VERSION_1_MT)
        headers.setAccept([Constants.CLASSES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        resp.body.classes[0] == null
    }

    private ClassObj setupValidClass(String name = "test name")
    {

        Subject subject = subjectRepo.save(new Subject(name: "test subj", organizationUuid: school.uuid, disabled: false, createdAt: new Date(), updatedAt: new Date()))
        AcademicSession academicSession = academicSessionRepo.save(new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date()))

        ClassObj classObj = new ClassObj(
                type: ClassObjType.ILP,
                subtype: ClassObjSubtype.INDEPENDENT_STUDY,
                state: ClassObjState.READY,
                name: name,
                subject: subjectsService.findOne(subject.uuid, school.uuid),
                organization: school,
                creatorUuid: teacher.uuid,
                classId: "test classId",
                notes: "some notes",
                academicSession: academicSession,
                accessDate: new Date()-1,
                stopDate: new Date()+1,
                created: new Date(),
                updated: new Date(),
                done: false
        )
        classObj = classRepo.save(classObj)
        gradeLevelIdService.save(classObj.uuid, [Grade.FOUR, Grade.THREE, Grade.EIGHT])
        return classObj
    }
}
