package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class ScoreControllerIntegrationSpec extends BaseRestSpec {

    User admin, enrolledTeacher, otherTeacher, student
    Organization school, school2, campus1, campus2
    ClassObj class1

    Map<String, User> userMap
    Map<String, Organization> orgMap

    def setup() {
        school = organizationRepo.save(new Organization(name: 'School 1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        campus1 = organizationRepo.save(new Organization(name: 'campus1', type: OrganizationType.CAMPUS, parent: school, originationId: 'test', created: new Date(), updated: new Date()))
        campus2 = organizationRepo.save(new Organization(name: 'campus2', type: OrganizationType.CAMPUS, parent: school2, originationId: 'test', created: new Date(), updated: new Date()))

        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        enrolledTeacher = userRepo.save(new User(firstName: 'enrolled', lastName: 'teacher', userName: 'et', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(),  organizations: [campus1]))
        otherTeacher = userRepo.save(new User(firstName: 'other', lastName: 'teacher', userName: 'ot', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(),  organizations: [campus1]))
        student = userRepo.save(new User(firstName: 'student', lastName: 'lsat', userName: 'student', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(),  organizations: [campus1]))

        class1 = setupValidClass(admin, campus1)

        createEnrollment(class1, enrolledTeacher, Role.TEACHER)
        createEnrollment(class1, student, Role.STUDENT)

        userMap = [
                otherTeacher: otherTeacher,
                enrolledTeacher: enrolledTeacher,
                student: student,
                admin: admin,
        ]

        orgMap = [
                school: school,
                school2: school2
        ]

    }

    @Unroll
    def "test validations for scores endpoints"(){
        given:
        PageObj page = setupValidPage("Page 1", class1)

        String token = createToken(userMap[user], orgMap[org].uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.set("x-client-domain", "localhost")

        when:
        headers.setAccept([Constants.PAGES_ASSIGNMENTS_SCORES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        HttpEntity resp = testRestTemplate.exchange("/pages/${page.uuid}/assignments/scores", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == status

        when:
        headers.setAccept([Constants.STUDENTS_SCORES_VERSION_1_MT])
        req = new HttpEntity(headers)
        resp = testRestTemplate.exchange("/pages/${page.uuid}/students/scores", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == status

        when:
        headers.setAccept([Constants.STUDENTS_SCORES_VERSION_1_MT])
        req = new HttpEntity(headers)
        resp = testRestTemplate.exchange("/classes/${class1.uuid}/students/scores", HttpMethod.GET, req, Map)

        then:
        resp.statusCode == status

        where:
        user           | org       | status
        "otherTeacher" | "school"  | HttpStatus.NOT_FOUND
        "student"      | "school"  | HttpStatus.FORBIDDEN
        "admin"        | "school2" | HttpStatus.NOT_FOUND

    }

}
