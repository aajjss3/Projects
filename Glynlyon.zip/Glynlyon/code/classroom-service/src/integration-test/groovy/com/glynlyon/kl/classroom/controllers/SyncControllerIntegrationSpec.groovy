package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Sync
import com.glynlyon.kl.classroom.model.SyncStatus
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.service.SyncService
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Unroll

class SyncControllerIntegrationSpec extends BaseRestSpec {

    @Autowired
    SyncService syncService

    User support
    Organization school

    def setup() {
        support =  new User(firstName: 'support', lastName: 'support', userName: 'support', type: AppUserType.SUPPORT_ADMINISTRATOR, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        school = new Organization(name: 'School', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
    }

    def "should save data to Organization and User and Sync"(){
        given:
        String token = createToken(support, null)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        syncService.metaClass.getRosterOrgs = { String orgType, String dateFilter, Integer offset, HttpEntity entity ->
            if(orgType == "campus") {
                return [
                        "orgs": [
                                [
										"name": "campus A",
                                        "identifier": "campus A",
                                        "type": "campus",
                                        "status": "active",
                                        "sourcedId": "bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                        "dateLastModified": "2016-08-13T21:24:00-07:00",
                                        "parent": [
                                                "href": "http://localhost:8080/orgs/3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "type": "org"
                                        ],
                                        "metadata": [
                                                "default": false
                                        ]
                                ],
                                [
                                        "name": "campus B",
                                        "identifier": "campus B",
                                        "type": "campus",
                                        "status": "active",
                                        "sourcedId": "7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                        "dateLastModified": "2016-08-13T21:24:00-07:00",
                                        "parent": [
                                                "href": "http://localhost:8080/orgs/3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "type": "org"
                                        ],
                                        "metadata": [
                                                "default": false
                                        ]
                                ],
                        ]
                ]
            }
            else if(orgType == "school"){
                return  [
                        "orgs": [
                                [
                                        "name": "test school",
                                        "identifier": "test school",
                                        "type": "school",
                                        "status": "active",
                                        "children": [
                                                [
													    "href": "http://localhost:8080/orgs/bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                        "sourcedId": "bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                        "type": "org"
                                                ],
                                                [
                                                        "href": "http://localhost:8080/orgs/7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                        "sourcedId": "7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                        "type": "org"
                                                ]
                                        ],
                                        "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                        "dateLastModified": "2015-01-01T09:05:16-07:00",
                                        "metadata": [
                                                "default": false
                                        ]
                                ]
                        ]
                ]
            }
        }

        syncService.metaClass.getRosterUsers = { String dateFilter, Integer offset, HttpEntity entity ->
            return [
                    "users": [
                            [
									"sourcedId": "5c73613c-8193-4c0c-a417-41087747971f",
                                    "username": "jkholin1",
                                    "givenName": "Jasnah",
                                    "familyName": "Kholin",
                                    "role": "STUDENT",
                                    "status": "active",
                                    "userId" : "jkholin@email.gov",
                                    "dateLastModified": "2016-09-07T10:20:39-07:00",
                                    "orgs": [
                                            [
                                                    "href": "http://localhost:8080/orgs/addecb72-437f-4100-98d2-4befa72754be",
                                                    "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                    "type": "school"
                                            ],
                                            [
                                                    "href": "http://localhost:8080/orgs/bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                    "sourcedId": "bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                    "type": "campus"
                                            ],
                                    ]
                            ],
                            [
                                    "sourcedId": "b4113c6e-2d5c-41c9-bde8-3def1cc56ac8",
                                    "username": "kstormblessed",
                                    "givenName": "Kaladin",
                                    "familyName": "Stormblessed",
                                    "identifier": "kstormblessed123",
                                    "role": "STUDENT",
                                    "status": "tobedeleted",
                                    "dateLastModified": "2016-07-27T08:21:22-07:00",
                                    "orgs": [
                                            [
													"href": "http://localhost:8080/orgs/addecb72-437f-4100-98d2-4befa72754be",
                                                    "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                    "type": "school"
                                            ],
                                            [
                                                    "href": "http://localhost:8080/orgs/7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                    "sourcedId": "7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                    "type": "campus"
                                            ]
                                    ]
                            ],
                            [
									"sourcedId": "6794c74e-b86e-4da8-9052-652f58296f0e",
                                    "username": "szethTeacher",
                                    "givenName": "Szeth",
                                    "familyName": "son-son-Vallano",
                                    "identifier": "qwerty",
                                    "role": "TEACHER",
                                    "status": "inactive",
                                    "dateLastModified": "2016-10-25T09:13:14-07:00",
                                    "orgs": [
                                            [
													"href": "http://localhost:8080/orgs/addecb72-437f-4100-98d2-4befa72754be",
                                                    "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                    "type": "school"
                                            ],
                                            [
													"href": "http://localhost:8080/orgs/bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                    "sourcedId": "bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                                    "type": "campus"
                                            ],
                                            [
                                                    "href": "http://localhost:8080/orgs/7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                    "sourcedId": "7cd5d777-ecb4-41be-9eb4-82509dd13b01",
                                                    "type": "campus"
                                            ]
                                    ],
                                    "metadata": [
                                            "studentAssessmentId": "bingo"
                                    ]
                            ]
                    ]
            ]
        }

        when:
        HttpEntity resp = testRestTemplate.exchange("/sync", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert syncRepo.findAll().size() == 1
        Sync sync = syncRepo.findAll().first()
        assert sync.status == SyncStatus.SUCCESS

        assert organizationRepo.findAll().size() == 3

        Organization school = organizationRepo.findOne(UUID.fromString("3d71c3ea-7439-4073-8b48-497d6142375a"))
        assert school.created
        assert school.updated
        assert school.name == "test school"
        assert school.type == OrganizationType.SCHOOL
        assert school.parent == null
        assert school.originationId == "test"

        Organization campusA = organizationRepo.findOne(UUID.fromString("bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075"))
        assert campusA.created
        assert campusA.updated
        assert campusA.name == "campus A"
        assert campusA.type == OrganizationType.CAMPUS
        assert campusA.parent.uuid == school.uuid
        assert campusA.originationId == "test"

        Organization campusB = organizationRepo.findOne(UUID.fromString("7cd5d777-ecb4-41be-9eb4-82509dd13b01"))
        assert campusB.created
        assert campusB.updated
        assert campusB.name == "campus B"
        assert campusB.type == OrganizationType.CAMPUS
        assert campusB.parent.uuid == school.uuid
        assert campusB.originationId == "test"


        User jasnah = userRepo.findOne(UUID.fromString("5c73613c-8193-4c0c-a417-41087747971f"))
        assert jasnah.firstName == "Jasnah"
        assert jasnah.lastName == "Kholin"
        assert jasnah.userName == "jkholin1"
        assert jasnah.ssoId == "jkholin@email.gov"
        assert jasnah.type == AppUserType.STUDENT
        assert jasnah.status == AppUserStatus.ACTIVE
        assert jasnah.updated
        assert jasnah.created
        assert jasnah.originationId == "test"

        User kaladin = userRepo.findOne(UUID.fromString("b4113c6e-2d5c-41c9-bde8-3def1cc56ac8"))
        assert kaladin.firstName == "Kaladin"
        assert kaladin.lastName == "Stormblessed"
        assert kaladin.userName == "kstormblessed"
        assert kaladin.ssoId == null
        assert kaladin.type == AppUserType.STUDENT
        assert kaladin.status == AppUserStatus.PENDING_ARCHIVE
        assert kaladin.updated
        assert kaladin.created
        assert kaladin.originationId == "test"

        User szeth = userRepo.findOne(UUID.fromString("6794c74e-b86e-4da8-9052-652f58296f0e"))
        assert szeth.firstName == "Szeth"
        assert szeth.lastName == "son-son-Vallano"
        assert szeth.userName == "szethTeacher"
        assert szeth.ssoId == null
        assert szeth.type == AppUserType.TEACHER
        assert szeth.status == AppUserStatus.ON_HOLD
        assert szeth.updated
        assert szeth.created
        assert szeth.originationId == "test"

        cleanup:
        syncService.metaClass.getRosterOrgs = null
        syncService.metaClass.getRosterUsers = null

    }

    def "should save error to sync table"() {
        given:
        String token = createToken(support, null)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        syncService.metaClass.getRosterOrgs = { String orgType, String dateFilter, Integer offset, HttpEntity entity ->
            if (orgType == "campus") {
                return [
                        "orgs": [
                                [
										"name"            : "campus A",
                                        "identifier"      : "campus A",
                                        "type"            : "unknown",
                                        "status"          : "active",
                                        "sourcedId"       : "bbfa923c-ba1b-4bca-9f2c-9aefa5a1d075",
                                        "dateLastModified": "2016-08-13T21:24:00-07:00",
                                        "parent"          : [
                                                "href"     : "http://localhost:8080/orgs/3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "sourcedId": "3d71c3ea-7439-4073-8b48-497d6142375a",
                                                "type"     : "org"
                                        ],
                                        "metadata"        : [
                                                "default": false
                                        ]
                                ]
                        ]
                ]
            }
            else if (orgType == "school") {
                return ["orgs": []]
            }
        }
        syncService.metaClass.getRosterUsers = { String dateFilter, Integer offset, HttpEntity entity ->
            return ["users": []]
        }

        when:
        HttpEntity resp = testRestTemplate.exchange("/sync", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        assert syncRepo.findAll().size() == 1
        Sync sync = syncRepo.findAll().first()
        assert sync.status == SyncStatus.ERROR

    }

    def "shouldTestDateFilter"(){
        given:
        DateFormat dateFormat = new DateFormat()

        when:
        Date now = new Date()
        Sync sync = syncRepo.save(new Sync(originationId: "test", serverName: "blah",  startedAt: now, endedAt: now+1, status: SyncStatus.ERROR))

        then:
        assert syncService.getFilterDate("test") == ""

        when:
        Date later = new Date() + 2
        Sync sync2 = syncRepo.save(new Sync(originationId: "test", serverName: "blah", startedAt: later, endedAt: later+1, status: SyncStatus.SUCCESS))

        then:
        assert syncService.getFilterDate("test") == dateFormat.format(later)

        when:
        Date latest = new Date()
        Sync sync3 = syncRepo.save(new Sync(originationId: "test", serverName: "blah",  startedAt: latest, endedAt: latest+1, status: SyncStatus.ERROR))

        then:
        assert syncService.getFilterDate("test") == dateFormat.format(later)
    }
		
	// the only app user type that has rights to sync is the SUPPORT_ADMINISTRATOR
	@Unroll
	def "unauthorized role to sync"(){
		given:
			support.type = role
			String token = createToken(support, null)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			HttpEntity req = new HttpEntity(headers)
				
		when:
			ResponseEntity<LinkedHashMap> resp = testRestTemplate.exchange( "/sync", HttpMethod.POST, req, Map )
		
		then:
			assert resp.statusCode == expectedStatusCode
			assert resp.body.message.contains(expectedMessage)
			
		where:	
			role							|	expectedStatusCode		|	expectedMessage
			AppUserType.ADMIN       		|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.PARENT      		|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.STUDENT      		|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.SUPPORT_CEM      	|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.SUPPORT_LICENSING	|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.SUPPORT_USER		|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
			AppUserType.TEACHER				|	HttpStatus.BAD_REQUEST	|	'SUPPORT_ADMINISTRATOR'
	 
	}

    @Unroll
    def "should get syncs"(){
        given:
        Date now = new Date()
        Sync sync1 = syncRepo.save(new Sync(originationId: "test", serverName: "foo",  startedAt: now-1, endedAt: now+1, status: SyncStatus.SUCCESS))
        Sync sync2 = syncRepo.save(new Sync(originationId: "test", serverName: "bar",  startedAt: now+1, endedAt: now+3, status: SyncStatus.ERROR))
        Sync sync3 = syncRepo.save(new Sync(originationId: "other", serverName: "baz",  startedAt: now, endedAt: now+2, status: SyncStatus.ERROR))

        Map<String, Sync> syncMap = [
                sync1 : sync1,
                sync2 : sync2,
                sync3 : sync3,
        ]

        DateFormat dateFormat = new DateFormat()

        String token = createToken(support, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/sync?filter=${filter}", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK

        def expectedSyncs = expectedResults.withIndex().collect { key, index ->
            Sync s = syncMap[key]
            return [
                    "uuid": s.uuid.toString(),
                    "status": s.status.toString(),
                    "origination_id": s.originationId,
                    "server_name": s.serverName,
                    "started_at": dateFormat.format(s.startedAt),
                    "ended_at": dateFormat.format(s.endedAt)
            ]
        }

        assert resp.body.syncs == expectedSyncs

        where:
        filter                   || expectedResults
        ""                       || ["sync2", "sync3", "sync1"]
        "origination_id='test'"  || ["sync2", "sync1"]
        "origination_id='other'" || ["sync3"]
        "status='ERROR'"         || ["sync2", "sync3"]
    }

}
