package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptOverridesHistory
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AttemptOverridesHistoryRepo
import com.glynlyon.kl.classroom.util.Constants
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class AttemptOverridesHistoryControllerIntegrationSpec  extends BaseRestSpec{
	
	@Autowired
	AttemptOverridesHistoryRepo attemptOverridesHistoryRepo
	
	Organization school, school2
	User admin, teacher, student
	
	UUID responseUUID1, pageAssignmentUUID1, userUUID
	AttemptOverridesHistory history1, history2, history3, history4, history5, history6
	Attempt attempt1, attempt2
	Assignment assignment
	PlannerEntry plannerEntry, plannerEntry2
	
	// default sort order is by date_overridden.
	Date dateOverridden1 = new Date(1483254000000)
	Date dateOverridden2 = new Date(1483255000000)
	Date dateOverridden3 = new Date(1483256000000)
	Date dateOverridden4 = new Date(1483257000000)
	Date dateOverridden5 = new Date(1483258000000)
	
	def setup(){
		school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		school2 = organizationRepo.save(new Organization(name: 'xxxx', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		teacher = userRepo.save(new User(firstName: 'teacher', lastName: 'teacher', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		student = userRepo.save(new User(firstName: 'student', lastName: 'student', userName: 'student', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		
		ClassObj classObj = setupValidClass(teacher, school)
		ClassObj classObj2 = setupValidClass(teacher, school2)
		PageObj pageObj = setupValidPage("Page 1", classObj, 1)
		assignment = setupValidAssignment("Assignment 1")

		plannerEntry = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, pageObj, assignment, student)
		plannerEntry2 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj2, pageObj, assignment, student)
		attempt1 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: null, state: AttemptState.PASSED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: ["abc", "def"], sectionsViewed: ["1", "2"], includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))
		attempt2 = attemptRepo.save(new Attempt(plannerEntry: plannerEntry2, user: student, activityId: plannerEntry.activityId, sectionCount: 1, sectionTotalCount: 1, questionCount: null, state: AttemptState.PASSED, timeOnTaskSeconds: 250, assessmentScore: 40, sectionItems: ["abc", "def"], sectionsViewed: ["1", "2"], includedManualGraded: true, createdAt: new Date(), updatedAt: new Date(), creditBearing: true))
		
		responseUUID1 = UUID.fromString('48b26738-6387-43f3-8605-cc4f36693252')
		pageAssignmentUUID1 = UUID.fromString('5bd35ac3-512c-4c81-8823-cab704345b37')
		userUUID = UUID.fromString('d0e9fd50-d4a0-4dcf-894c-fe9e8467dacb')
		// assigned to attempt 1
		history1 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'c', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: dateOverridden1, userUUID: userUUID) )
		history2 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '1', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: false, dateOverridden: dateOverridden2, userUUID: userUUID) )
		history3 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '2', lastName: 'd', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: dateOverridden3, userUUID: userUUID) )
		history4 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '3', lastName: 'e', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: false, dateOverridden: dateOverridden4, userUUID: userUUID) )
		history5 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '4', lastName: 'b', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: dateOverridden5, userUUID: userUUID) )
		// assigned to attempt 2
		history6 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '5', lastName: 'f', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt2.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
	}
	
	
	@Unroll
	def "GET AttemptOverridesHistory for attempt1 - fail due to invalid role"(){
		given:
			admin.type = role
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntryUUID}/attempts/${attemptUUID}/reviews/histories", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == expectedStatusCode
			
		where:
			role								|	expectedStatusCode			| attemptUUID								| plannerEntryUUID
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.FORBIDDEN		| 'ec14020c-71e2-4ef1-80b4-005a020ea82d'	| '87845656-b0fc-41b2-a4a7-02a5394d42c5'
			AppUserType.PARENT					|	HttpStatus.FORBIDDEN		| 'ec14020c-71e2-4ef1-80b4-005a020ea82d'	| '87845656-b0fc-41b2-a4a7-02a5394d42c5'
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.FORBIDDEN		| 'ec14020c-71e2-4ef1-80b4-005a020ea82d'	| '87845656-b0fc-41b2-a4a7-02a5394d42c5'
			AppUserType.SUPPORT_USER			|	HttpStatus.FORBIDDEN		| 'ec14020c-71e2-4ef1-80b4-005a020ea82d'	| '87845656-b0fc-41b2-a4a7-02a5394d42c5'
			AppUserType.SUPPORT_CEM				|	HttpStatus.FORBIDDEN		| 'ec14020c-71e2-4ef1-80b4-005a020ea82d'	| '87845656-b0fc-41b2-a4a7-02a5394d42c5'
	}
	
	@Unroll
	def "GET AttemptOverridesHistory for attempt1 -admin doesnt belong to organization or teacher doesnt belong to class"(){
		given:
			admin.type = role
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry2.uuid.toString()+"/attempts/"+attempt2.uuid.toString()+"/reviews/histories", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == expectedStatusCode
			if( role == AppUserType.ADMIN){
				assert resp.body.errors[0].message == env.getProperty("admin.organization.not.valid")
			}
			if( role == AppUserType.TEACHER){
				assert resp.body.errors[0].message == env.getProperty("teacher.class.not.valid")
			}
			
		where:
			role								|	expectedStatusCode	
			AppUserType.ADMIN					|	HttpStatus.UNAUTHORIZED	
			AppUserType.TEACHER					|	HttpStatus.UNAUTHORIZED	
	}
	

	def "GET AttemptOverridesHistory for attempt1 - fail due to invalid attempt"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/a3d05e9e-3344-4fc7-aa94-7b85f8377f4f/reviews/histories", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			assert resp.body.errors[0].message == env.getProperty("plannerentry.attempt.not.valid")
	}
	
	def "GET AttemptOverridesHistory for attempt1 - fail due to invalid planner entry"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/84f613f2-b2e1-40b2-b5c9-5f9e9294bfce/attempts/"+attempt1.uuid.toString()+"/reviews/histories", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			assert resp.body.errors[0].message == env.getProperty("plannerentry.attempt.not.valid")
	}
	
	def "GET AttemptOverridesHistory for attempt1 - fail due to attempt2 not assigned to planner entry"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/"+attempt2.uuid.toString()+"/reviews/histories", HttpMethod.GET, req, Map)

		then:
			assert resp.statusCode == HttpStatus.NOT_FOUND
			assert resp.body.errors[0].message == env.getProperty("plannerentry.attempt.not.valid")
	}
	
	
	def "GET AttemptOverridesHistory for attempt1 - success"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/"+attempt1.uuid.toString()+"/reviews/histories", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.response_overrides.size() == 5
			assert resp.body.current_page == 1
			assert resp.body.page_size == 5
			assert resp.body.total_pages == 1
			for( int inx=0; inx < 5; inx++){
				assert resp.body.response_overrides[inx].response_id == responseUUID1.toString()
				assert resp.body.response_overrides[inx].attempt_uuid == attempt1.uuid.toString()
				assert resp.body.response_overrides[inx].page_assignment_uuid == pageAssignmentUUID1.toString()
				assert resp.body.response_overrides[inx].assignment_uuid == assignment.uuid.toString()
				assert resp.body.response_overrides[inx].user_uuid == userUUID.toString()
				assert resp.body.response_overrides[inx].first_name == Integer.toString(inx)
			}
			assert resp.body.response_overrides[0].last_name == 'c'
			assert resp.body.response_overrides[0].credit == true
			assert resp.body.response_overrides[1].last_name == 'a'
			assert resp.body.response_overrides[1].credit == false
			assert resp.body.response_overrides[2].last_name == 'd'
			assert resp.body.response_overrides[2].credit == true
			assert resp.body.response_overrides[3].last_name == 'e'
			assert resp.body.response_overrides[3].credit == false
			assert resp.body.response_overrides[4].last_name == 'b'
			assert resp.body.response_overrides[4].credit == true
	}
	
	
	def "GET AttemptOverridesHistory for attempt1 - success filtering"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/"+attempt1.uuid.toString()+"/reviews/histories?filter=credit='false'", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.response_overrides.size() == 2
			assert resp.body.current_page == 01
			assert resp.body.page_size == 2
			assert resp.body.total_pages == 1
			for( int inx=0; inx < 2; inx++){
				assert resp.body.response_overrides[inx].credit == false
			}
	}
	
	def "GET AttemptOverridesHistory for attempt1 - success sorting"(){
		given:
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/"+attempt1.uuid.toString()+"/reviews/histories?sort=last_name", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.response_overrides.size() == 5
			assert resp.body.current_page == 1
			assert resp.body.page_size == 5
			assert resp.body.total_pages == 1
			assert resp.body.response_overrides[0].first_name == '1'
			assert resp.body.response_overrides[0].last_name == 'a'
			assert resp.body.response_overrides[1].first_name == '4'
			assert resp.body.response_overrides[1].last_name == 'b'
			assert resp.body.response_overrides[2].first_name == '0'
			assert resp.body.response_overrides[2].last_name == 'c'
			assert resp.body.response_overrides[3].first_name == '2'
			assert resp.body.response_overrides[3].last_name == 'd'
			assert resp.body.response_overrides[4].first_name == '3'
			assert resp.body.response_overrides[4].last_name == 'e'
	}
	
	def "GET AttemptOverridesHistory for attempt1 - success pagination and http headers"(){
		given:
			// create 11 AttemptOverridesHistory records assigned to attempt1. pagination will return the first 10
			AttemptOverridesHistory history7 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
			AttemptOverridesHistory history8 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
			AttemptOverridesHistory history9 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
			AttemptOverridesHistory history10 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
			AttemptOverridesHistory history11 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
			AttemptOverridesHistory history12 = attemptOverridesHistoryRepo.save(new AttemptOverridesHistory(firstName: '0', lastName: 'a', createdBy: UUID.fromString('5405965f-e3af-49b0-9165-836de1f32b1b'), createdAt: new Date(), attemptUUID: attempt1.uuid, responseID:responseUUID1, pageAssignmentUUID: pageAssignmentUUID1, assignmentUUID: assignment.uuid, credit: true, dateOverridden: new Date(), userUUID: userUUID) )
						
			String token = createToken(admin, school.uuid)
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${token}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.ACCEPT_OVERRIDES_HISTORY_CONTENT_TYPE_VERSION_1)
			HttpEntity req = new HttpEntity(headers)
			
		when:
			HttpEntity resp = testRestTemplate.exchange("/plannerentries/"+plannerEntry.uuid.toString()+"/attempts/"+attempt1.uuid.toString()+"/reviews/histories", HttpMethod.GET, req, Map)
			
		then:
			assert resp.statusCode == HttpStatus.OK
			assert resp.body.response_overrides.size() == 10
			assert resp.body.current_page == 1
			assert resp.body.page_size == 10
			assert resp.body.total_pages == 2
			HttpHeaders responseHeaders = resp.getHeaders()
			assert responseHeaders.get('X-Total-Count').contains('11')
			assert responseHeaders.get('Access-Control-Expose-Headers').contains('X-Total-Count') 
	}
	
	
	
	private setupPlannerEntry(Integer slot, PlannerEntryState state, ClassObj classObj, PageObj pageObj, Assignment assignment,User user) {
		PlannerEntry plannerEntry = new PlannerEntry(
				slot: slot,
				status: state,
				classObj: classObj,
				pageObj: pageObj,
				activityId: assignment.uuid,
				assignment: assignment,
				user:user)
		plannerEntryRepo.save(plannerEntry)
		return plannerEntry
	}

}
