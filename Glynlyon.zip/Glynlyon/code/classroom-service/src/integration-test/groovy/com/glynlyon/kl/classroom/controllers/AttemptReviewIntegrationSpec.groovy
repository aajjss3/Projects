package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.dto.LearnosityJobStatusJmsDTO
import com.glynlyon.kl.classroom.dto.grade.GpaScoresInput
import com.glynlyon.kl.classroom.dto.grade.OutcomeResponse
import com.glynlyon.kl.classroom.dto.grade.OutcomeStatus
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.AttemptOverridesHistory
import com.glynlyon.kl.classroom.model.AttemptState
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Lock
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.ResourceType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.SettingRepo
import com.glynlyon.kl.classroom.service.GpaService
import com.glynlyon.kl.classroom.service.LearnosityDataService
import com.glynlyon.kl.classroom.service.LearnosityJobStatusJmsService
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import com.glynlyon.learnosity.client.LearnosityDataClient
import com.glynlyon.learnosity.exception.LearnosityUpdateScoreException
import com.glynlyon.learnosity.model.LearnosityGetAllSessionsResponse
import com.glynlyon.learnosity.model.LearnosityResponse
import com.glynlyon.learnosity.model.LearnosityUpdateSessionResponse
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class AttemptReviewIntegrationSpec extends BaseRestSpec{
	User admin, admin2, student, student1, student2, student3, studentOther, teacher, teacher1

	Organization school, campus, school1
	Setting school1Setting

	Map<String, User> userMap
	Map<String, Organization> orgMap

	public static final String DOMAIN_HEADER = "X-CLIENT-DOMAIN"

	@Autowired
	LearnosityDataService learnosityDataService

	@Autowired
	LearnosityJobStatusJmsService learnosityJobStatusJmsService

	@Autowired
	SettingRepo settingRepo

	@Autowired
	GpaService gpaService

	def setup() {
		school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		school1 = organizationRepo.save(new Organization(name: 'Thrones1', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
		campus = organizationRepo.save(new Organization(name: 'Winterfell', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))

		admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		admin2 = userRepo.save(new User(firstName: 'Admin 2', lastName: 'teacher2', userName: 'Test Admin 2', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		student = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'testing', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		student1 = userRepo.save(new User(firstName: 'John', lastName: 'Snow', userName: 'jSnow', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		student2 = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		student3 = userRepo.save(new User(firstName: 'Mega', lastName: 'Man', userName: 'mMan', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		studentOther = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		teacher = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))
		teacher1 = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, school]))


		userMap = [
		        admin: admin,
				admin2: admin2,
				student: student,
				student1: student,
				student2: student,
				student3: student,
				studentOther: student,
				teacher: teacher,
				teacher1: teacher1
		]

		orgMap = [
		        school: school,
				school1: school1,
				campus: campus
		]

		def schoolSettingValue = [admin: [override: true], classroom: [lessons: [threshold: 70, attempts: 2],	projects: [threshold: 70, attempts: 2],grade_display: [percentage: true, letter: false], grade_scale: [A:90,B:80,C:70,D:60]]]
		school1Setting = settingRepo.save(new Setting(sourceUUID: null, value: schoolSettingValue, type: SettingType.GLOBAL, version: 0) )

		learnosityJobStatusJmsService.metaClass.create = {LearnosityJobStatusJmsDTO jmsDTO -> }

	}


	def cleanup(){
		settingRepo.deleteAll()
	}

	@Unroll
	def "should test a bunch of error cases for teacher override"(){
		given:
		ClassObj classObj = setupValidClass(admin, school)
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("page name", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa name", pageObj)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classObj, pageObj, pageAssignment, student)

		def plannerMap = [
		        planner: plannerEntry,
				random: [uuid: UUID.randomUUID()]
		]

		Attempt attempt = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, ["key1": null], null)
		Attempt attempt2 = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, null, null)
		def attemptMap = [
				attempt: attempt,
				attempt2: attempt2,
				random: [uuid: UUID.randomUUID()]
		]

		message = message.replaceAll("ATTEMPT2_UUID", attempt2.uuid.toString())

		if(user != 'admin2') {
			lockRepo.save(new Lock(lockedByUser: userMap[user], lockedAt: new Date(), resourceType: ResourceType.ATTEMPT, resourceUuid: attemptMap[attemptKey].uuid))
		}

		String token = createToken(userMap[user], orgMap[org].uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set(DOMAIN_HEADER, "localhost")
		headers.setContentType(Constants.REVIEWS_OVERRIDES_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"response_overrides": [
						[
								"response_id"      : respId,
								"credit"           : true,
								"type"             : "a string"
						]
				]
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerMap[plannerKey].uuid}/attempts/${attemptMap[attemptKey].uuid}/reviews", HttpMethod.PUT, req, Map)

		then:
		assert resp.statusCode == expectedStatus
		assert resp.body.errors.size == 1

		if(message) {
			assert resp.body.errors[0].message.contains(message)
		}

		where:
		user       | org       | attemptKey | plannerKey | respId || expectedStatus         | message
		"admin"    | "school1" | "attempt"  | "planner"  | "key1" || HttpStatus.FORBIDDEN   | "Admin does not have access to this organization"
		"student"  | "school"  | "attempt"  | "planner"  | "key1" || HttpStatus.FORBIDDEN   | "Only ADMINS and TEACHERS are authorized to use this service"
		"teacher1" | "school"  | "attempt"  | "planner"  | "key1" || HttpStatus.FORBIDDEN   | "Teacher must be enrolled to modify responses"
		"admin"    | "school"  | "random"   | "planner"  | "key1" || HttpStatus.NOT_FOUND   | ""
		"admin"    | "school"  | "random"   | "random"   | "key1" || HttpStatus.NOT_FOUND   | ""
		"admin"    | "school"  | "attempt2" | "planner"  | "key1" || HttpStatus.BAD_REQUEST | "Attempt ATTEMPT2_UUID does not have existing responses to override"
		"admin"    | "school"  | "attempt"  | "planner"  | "key2" || HttpStatus.BAD_REQUEST | "Response ids [key2] were not found in the original attempt responses"
		"admin2"   | "school"  | "attempt"  | "planner"  | "key2" || HttpStatus.FORBIDDEN   | "User does not have a valid lock on the attempt"
	}

	@Unroll
	def "should test successful teacher override"() {
		ClassObj classObj = setupValidClass(admin, school)
		settingRepo.save(new Setting(sourceUUID: classObj.uuid, value: [admin: [override: true],
				classroom: [lessons: [threshold: 50, attempts: 50],	projects: [threshold: 50, attempts: 50],
				grade_display: gradeDisplay, grade_scale: [A:90,B:80,C:70,D:60]]], type: SettingType.CLASS, version: 0) )

		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("page name", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa name", pageObj)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classObj, pageObj, pageAssignment, student)

		Map originalResponse = ["key1": null, "key2": null, "key3": null]
		Attempt attempt = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, originalResponse , new Date())

		lockRepo.save(new Lock(lockedByUser: teacher, lockedAt: new Date(), resourceType: ResourceType.ATTEMPT, resourceUuid: attempt.uuid))

		learnosityDataService.metaClass.getClient = {String domain ->
			return createMockLearnosity(plannerEntry, existingScores)
		}

		gpaService.metaClass.calculateScores = { GpaScoresInput input ->
			Double score = ((input.questions.score.findAll().sum() ?: 0.0 as Double) / (input.questions.max_score.findAll().sum() ?: 0.0 as Double))
			OutcomeStatus status = OutcomeStatus.FAILED
			if(score * 100 >= input.settings.threshold){
				status = OutcomeStatus.PASSED
			}
			return new OutcomeResponse(score: score, status: status)
		}

		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set(DOMAIN_HEADER, "localhost")
		headers.setContentType(Constants.REVIEWS_OVERRIDES_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"response_overrides": [
						[
								"response_id"      : "key1",
								"credit"           : true,
								"type"             : "a string"
						],
						[
								"response_id"      : "key3",
								"credit"           : false,
								"type"             : "a string"
						]
				]
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.PUT, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK

		PlannerEntry actualPE = plannerEntryRepo.findOne(plannerEntry.uuid)
		assert actualPE.status == expectedPEState

		Attempt actual = attemptRepo.findOne(attempt.uuid)
		assert actual.assessmentScore == expectedScore as Double
		assert actual.state == expectedState
		assert actual.responseOverrides.keySet() == originalResponse.keySet()  // original responseIds should be preserved
		body.response_overrides.each { //check if values got overriden
			assert actual.responseOverrides[it.response_id] == it.credit
		}

		DateFormat dateFormat = new DateFormat()

		def expectedBody = [
				"user_uuid": student.uuid.toString(),
				"page_assignment_uuid": pageAssignment.uuid.toString(),
				"planner_entry_uuid": plannerEntry.uuid.toString(),
				"attempt_uuid": attempt.uuid.toString(),
				"state": expectedState.toString(),
				"status":expectedState.toString(),
				"assessment_score": expectedScore,
				"earned_score": earnedScore,
				"completed_at": dateFormat.format(attempt.completedAt),
				"planner_entry_status" : expectedPEState.toString()
		]

		assert resp.body == expectedBody

		where:
		existingScores                                                     || expectedPEState             | expectedState          | expectedScore | earnedScore                | gradeDisplay
		[key1: (Float)1.0, key2: null, key3: null, key4: (Float)0.0]       || PlannerEntryState.COMPLETED | AttemptState.SUBMITTED | null          | null                       | [letter: false, percentage: true]
		[key1: (Float)0.0, key2: null, key3: null, key4: (Float)0.0]       || PlannerEntryState.COMPLETED | AttemptState.SUBMITTED | null          | null                       | [letter: false, percentage: true]
		[key1: null, key2: null, key3: null, key4: (Float)0.0]             || PlannerEntryState.COMPLETED | AttemptState.SUBMITTED | null          | null                       | [letter: false, percentage: true]
		[key1: (Float)0.0, key2: (Float)0.0, key3: null, key4: (Float)0.0] || PlannerEntryState.GRADED    | AttemptState.FAILED    | 0.25          | [value: 0.25]              | [letter: false, percentage: true]
		[key1: (Float)0.0, key2: (Float)1.0, key3: null, key4: (Float)1.0] || PlannerEntryState.GRADED    | AttemptState.PASSED    | 0.75          | [value: 0.75]              | [letter: false, percentage: true]
		[key1: (Float)1.0, key2: (Float)1.0, key3: null, key4: (Float)1.0] || PlannerEntryState.GRADED    | AttemptState.PASSED    | 0.75          | [grade:'C', value: 0.75]   | [letter: true, percentage: true]
		[key1: (Float)1.0, key2: (Float)1.0, key3: null, key4: (Float)1.0] || PlannerEntryState.GRADED    | AttemptState.PASSED    | 0.75          | [grade:'C']                | [letter: true, percentage: false]	}

	def "should allow all no credit overrides"() {
		ClassObj classObj = setupValidClass(admin, school)
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("page name", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa name", pageObj)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classObj, pageObj, pageAssignment, student)

		Map originalResponse = ["key1": null, "key2": null, "key3": null]
		Attempt attempt = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, originalResponse , new Date())

		lockRepo.save(new Lock(lockedByUser: teacher, lockedAt: new Date(), resourceType: ResourceType.ATTEMPT, resourceUuid: attempt.uuid))

		learnosityDataService.metaClass.getClient = {String domain ->
			return createMockLearnosity(plannerEntry, [key1: (Float)1.0, key2: null, key3: (Float)0.0])
		}


		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set(DOMAIN_HEADER, "localhost")
		headers.setContentType(Constants.REVIEWS_OVERRIDES_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"response_overrides": [
						[
								"response_id"      : "key1",
								"credit"           : false,
								"type"             : "a string"
						],
						[
								"response_id"      : "key2",
								"credit"           : false,
								"type"             : "a string"
						],
						[
								"response_id"      : "key3",
								"credit"           : false,
								"type"             : "a string"
						]
				]
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.PUT, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK

		PlannerEntry actualPE = plannerEntryRepo.findOne(plannerEntry.uuid)
		assert actualPE.status == PlannerEntryState.GRADED

		Attempt actual = attemptRepo.findOne(attempt.uuid)
		assert actual.assessmentScore == 0.0 as Double
		assert actual.state == AttemptState.FAILED
		assert actual.responseOverrides.keySet() == originalResponse.keySet()  // original responseIds should be preserved
		body.response_overrides.each { //check if values got overriden
			assert actual.responseOverrides[it.response_id] == it.credit
		}

		DateFormat dateFormat = new DateFormat()

		def expectedBody = [
				"user_uuid": student.uuid.toString(),
				"page_assignment_uuid": pageAssignment.uuid.toString(),
				"planner_entry_uuid": plannerEntry.uuid.toString(),
				"attempt_uuid": attempt.uuid.toString(),
				"state": AttemptState.FAILED.toString(),
				"status": AttemptState.FAILED.toString(),
				"assessment_score": 0.0,
				"earned_score": [value: 0],
				"completed_at": dateFormat.format(attempt.completedAt),
				"planner_entry_status" : PlannerEntryState.GRADED.toString()
		]

		assert resp.body == expectedBody
	}

	@Unroll
	def "should test simulated learnosity errors"() {
		ClassObj classObj = setupValidClass(admin, school)
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
		enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("page name", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa name", pageObj)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classObj, pageObj, pageAssignment, student)

		Attempt attempt = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, ["key1": null, "key2": null, "key3": null], new Date())

		lockRepo.save(new Lock(lockedByUser: teacher, lockedAt: new Date(), resourceType: ResourceType.ATTEMPT, resourceUuid: attempt.uuid))

		learnosityDataService.metaClass.getClient = {String domain ->
			return createMockLearnosity(plannerEntry, [key1: null], updateError, emptyResponse)
		}


		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set(DOMAIN_HEADER, "localhost")
		headers.setContentType(Constants.REVIEWS_OVERRIDES_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])

		when:

		def body = [
				"response_overrides": [
						[
								"response_id"      : "key1",
								"credit"           : true,
								"type"             : "a string"
						]
				]
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.PUT, req, Map)

		then:
		assert resp.statusCode == expectedStatus
		assert resp.body.errors.size == 1

		if(message) {
			assert resp.body.errors[0].message.contains(message)
		}

		where:
		emptyResponse | updateError  || expectedStatus         | message
		true          | false        || HttpStatus.BAD_REQUEST | "Empty result from learnosity, possible unknown sessionId"
		false         | true         || HttpStatus.BAD_REQUEST | "Learnosity error: [message:error, code:12345]"

	}
	
	
	def "test inserting records into AttemptOverridesHistory table"() {
		ClassObj classObj = setupValidClass(admin, school)
		enrollmentRepo.save(new Enrollment(user: teacher, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))
		//enrollmentRepo.save(new Enrollment(user: student, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

		PageObj pageObj = setupValidPage("page name", classObj, 1)
		PageAssignment pageAssignment = setupValidPageAssignment("pa name", pageObj)
		PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.COMPLETED, classObj, pageObj, pageAssignment, student)

		Map originalResponse = ["key1": null, "key2": false, "key3": true, "key4": true]
		Attempt attempt = setupAttempt(plannerEntry, student, AttemptState.SUBMITTED, null, originalResponse , new Date())

		lockRepo.save(new Lock(lockedByUser: teacher, lockedAt: new Date(), resourceType: ResourceType.ATTEMPT, resourceUuid: attempt.uuid))
		
		def existingScores = [key1: (Float)1.0, key2: null, key3: null, key4: (Float)0.0]
		learnosityDataService.metaClass.getClient = {String domain ->
			return createMockLearnosity(plannerEntry, existingScores)
		}

		gpaService.metaClass.calculateScores = { GpaScoresInput input ->
			Double score = ((input.questions.score.findAll().sum() ?: 0.0 as Double) / (input.questions.max_score.findAll().sum() ?: 0.0 as Double))
			OutcomeStatus status = OutcomeStatus.FAILED
			if(score * 100 >= input.settings.threshold){
				status = OutcomeStatus.PASSED
			}
			return new OutcomeResponse(score: score, status: status)
		}

		String token = createToken(teacher, school.uuid)
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${token}")
		headers.set(DOMAIN_HEADER, "localhost")
		headers.setContentType(Constants.REVIEWS_OVERRIDES_VERSION_1_MT)
		headers.setAccept([Constants.PAGE_ATTEMPTS_VERSION_1_MT])

		when:
		def body = [
				"response_overrides": [
						[
								"response_id"      : "key1",
								"credit"           : true,
								"type"             : "a string"
						],
						[
								"response_id"      : "key2",
								"credit"           : true,
								"type"             : "a string"
						],
						[
								"response_id"      : "key3",
								"credit"           : false,
								"type"             : "a string"
						],						[
								"response_id"      : "key4",
								"credit"           : true,
								"type"             : "a string"
						]
				]
		]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity resp = testRestTemplate.exchange("/plannerentries/${plannerEntry.uuid}/attempts/${attempt.uuid}/reviews", HttpMethod.PUT, req, Map)

		then:
		assert resp.statusCode == HttpStatus.OK
		Iterable<AttemptOverridesHistory> histories = attemptOverridesHistoryRepo.findAll()
		assert histories.size() == 3
		for(AttemptOverridesHistory history : histories){
			assert history.attemptUUID == attempt.uuid
			assert history.pageAssignmentUUID == pageAssignment.uuid
			assert history.userUUID == teacher.uuid
			assert history.firstName == teacher.firstName
			assert history.lastName == teacher.lastName
			assert history.assignmentUUID == plannerEntry.assignment.uuid
			if( history.responseID == "key1"){
				assert history.credit == true
			}
			if( history.responseID == "key2"){
				assert history.credit == true
			}
			if( history.responseID == "key3"){
				assert history.credit == false
			}
			if( history.responseID == "key4"){
				assert false
			}
		}

	}


	private LearnosityDataClient createMockLearnosity(PlannerEntry plannerEntry, Map<String, Float> existingScores, Boolean updateError = false, Boolean emptyResponse = false) {
		return new LearnosityDataClient("", "", "") {
			@Override
			Map<String, LearnosityGetAllSessionsResponse> getAllSessionsResponsesBySessions(List<String> sessionIds) {
				if(emptyResponse){
					return [:]
				}

				Float maxScore = existingScores.values().size()
				Float score = (Float)existingScores.values().findAll().sum()

				return sessionIds.collectEntries {
					[(it): new LearnosityGetAllSessionsResponse(
							userId: student.uuid.toString(),
							activityId: plannerEntry.activityId.toString(),
							sessionId: it,
							numAttempted: 2,
							numQuestions: 4,
							score: score,
							maxScore: maxScore,
							status: "DONE",
							responses: existingScores.collect { key, value ->
								new LearnosityResponse(
										responseId: key,
										score: value,
										maxScore: 1.0
								)
							}
					)]
				}
			}

			@Override
			LearnosityUpdateSessionResponse updateSessionResponsesWithScore(String userId, String sessionId, List<LearnosityResponse> responses) throws LearnosityUpdateScoreException {
				if(updateError){
					throw new LearnosityUpdateScoreException(12345, "error")
				}
				return new LearnosityUpdateSessionResponse(
						status: true,
						timestamp: new Date().getTime(),
						jobReferenceID: UUID.randomUUID().toString()
				)
			}
		}
	}

}
