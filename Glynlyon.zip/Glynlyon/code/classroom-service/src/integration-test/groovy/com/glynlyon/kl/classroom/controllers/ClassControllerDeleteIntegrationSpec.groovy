package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Attempt
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.User
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class ClassControllerDeleteIntegrationSpec extends BaseRestSpec {
    User admin, student1, student2, teacher, teacher1, teacher2

    Organization school, school2, campus, campus2

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        school2 = organizationRepo.save(new Organization(name: 'Hogwarts', type: OrganizationType.SCHOOL, originationId: 'test', created: new Date(), updated: new Date()))
        campus = organizationRepo.save(new Organization(name: 'Winterfell', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))
        campus2 = organizationRepo.save(new Organization(name: 'Narnia', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school2))

        student1 = userRepo.save(new User(firstName: 'John', lastName: 'Snow', userName: 'jSnow', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))
        student2 = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))

        teacher1 = userRepo.save(new User(firstName: 'Jasnah', lastName: 'Kholin', userName: 'jkholin', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))
        teacher2 = userRepo.save(new User(firstName: 'Kaladin', lastName: 'Stormblessed', userName: 'kstormblessed', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))
        teacher = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))

    }

    @Unroll
    def "should delete a class by role"(){
        given:

        Map<String, User> userMap = [
                admin: admin,
                enrolledTeacher : teacher1,
                otherTeacher : teacher2,
                student : student1
        ]
        Map<String, Organization> orgMap = [
                campus: campus,
                campus2: campus2
        ]

        ClassObj classObj = setupValidClass(admin, orgMap[campusName])

        createEnrollment(classObj, teacher1, Role.TEACHER)

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedResponse
        if(expectedResponse == HttpStatus.NO_CONTENT) {
            assert classRepo.findAll().size() == 0
            assert enrollmentRepo.findAll().size() == 0
            assert plannerEntryRepo.findAll().size() == 0
            assert pageAssignmentRepo.findAll().size() == 0
            assert pageRepo.findAll().size() == 0
        }

        where:
        user              | campusName | expectedResponse
        "admin"           | "campus"   | HttpStatus.NO_CONTENT
        "admin"           | "campus2"  | HttpStatus.NOT_FOUND
        "enrolledTeacher" | "campus"   | HttpStatus.NO_CONTENT
        "otherTeacher"    | "campus"   | HttpStatus.NOT_FOUND
        "student"         | "campus"   | HttpStatus.FORBIDDEN
    }

    def "should not delete a class with associcated attempts"(){
        ClassObj classObj = setupValidClass(admin, school)
        PageObj pageObj = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("pa", pageObj)
        PlannerEntry plannerEntry = setupPlannerEntry(1, PlannerEntryState.GRADED, classObj, pageObj, pageAssignment, student1)
        Attempt attempt = setupAttempt(plannerEntry, student1)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/classes/${classObj.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == 1
        assert resp.body.errors[0].message == "Cannot delete a class that has associated attempts"
        assert classRepo.findAll().size() == 1
    }
}
