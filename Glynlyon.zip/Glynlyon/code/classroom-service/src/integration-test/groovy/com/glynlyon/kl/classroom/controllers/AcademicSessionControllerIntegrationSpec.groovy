package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.Configuration
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import com.glynlyon.kl.classroom.util.Links
import com.glynlyon.kl.classroom.util.MessagesUtil
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll

class AcademicSessionControllerIntegrationSpec extends BaseRestSpec{

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    MessagesUtil messagesUtil

    User teacher
    User admin, admin2
    User student
    Organization school, school2, campus

    def setup() {
        school = new Organization(name: 'School', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
        school2 = new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
        campus = new Organization(name: 'Campus', type: OrganizationType.CAMPUS, originationId: 'Shard Test', created: new Date(), updated: new Date(), parent: school)

        organizationRepo.save(school)
        organizationRepo.save(school2)
        organizationRepo.save(campus)

        teacher =  new User(firstName: 'testTeacher1', lastName: 'teacherLast', userName: 'testTeacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())
        admin =  new User(firstName: 'testAdmin1', lastName: 'adminLast', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, organizations: [school], originationId: 'SHARD 1', updated: new Date(), created: new Date())
        admin2 =  new User(firstName: 'testAdmin2', lastName: 'adminLast', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, organizations: [school2], originationId: 'SHARD 1', updated: new Date(), created: new Date())

        student =  new User(firstName: 'testStudent1', lastName: 'studentLast', userName: 'testStudent', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())

        userRepo.save(admin)
        userRepo.save(admin2)

        configurationRepo.save(new Configuration(key: Constants.CLASS_DELETE_GRACE_PERIOD_HOURS_KEY, value: 24, description: "test hours"))
    }

    def "GET academicsessions endpoint returns all expected fields and return valid Link and total count values"(){
        given:

        AcademicSession academicSession1 = new AcademicSession(name: 'session1', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession1)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def response = testRestTemplate.exchange("/academicsessions?limit=2", HttpMethod.GET, req, Object)

        then:

        def dateFormat = new DateFormat()

        assert response.statusCode == HttpStatus.OK
        assert response.getHeaders().get('X-total-count')[0].toInteger() == academicSessionRepo.findAll().size()
        assert response.getHeaders().get('Link')[0] != null

        assert response.body.academic_sessions[0].name == academicSession1.name
        assert response.body.academic_sessions[0].type == academicSession1.type.toString()
        assert response.body.academic_sessions[0].organization_uuid == school.uuid.toString()
        assert response.body.academic_sessions[0].start_date == dateFormat.format(academicSession1.startDate)
        assert response.body.academic_sessions[0].end_date == dateFormat.format(academicSession1.endDate)
        assert response.body.academic_sessions[0].parent_uuid == academicSession1.parentUuid
    }


    @Unroll
    def "academicsessions GET endpoint test with all possible inputs and return values"(){
        given:

        AcademicSession academicSession1 = new AcademicSession(name: 'session1', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession1)
        AcademicSession academicSession2 = new AcademicSession(name: 'session2', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession2)
        AcademicSession academicSession3 = new AcademicSession(name: 'session3', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)
        AcademicSession academicSession4 = new AcademicSession(name: 'session4', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession4)
        AcademicSession academicSession5 = new AcademicSession(name: 'session5', type: AcademicSessionType.TERM, organizationUuid: school2.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession5)

        def orgUuidMap = [org1: school.uuid,org2: school2.uuid]

        String token = createToken(admin, orgUuidMap[jwt_org])
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def filter = orgUuidMap[filter_org] ? "&filter=organization_uuid='"+orgUuidMap[filter_org]+"'" : ""
        def url = "/academicsessions?limit="+limit+"&offset="+offset+"&orderBy="+orderBy+"&sort="+sortInput+filter
        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        def results = response.getBody()
        def sortedList

        if(orderBy == "desc") {
            sortedList = academicSessionRepo.findAllByOrganizationUuid(orgUuidMap[jwt_org]).sort { a, b -> a.name.toString() <=> b.name.toString() }.reverse()
        }
        else{
            sortedList = academicSessionRepo.findAllByOrganizationUuid(orgUuidMap[jwt_org]).sort { a, b -> a.name.toString() <=> b.name.toString() }
        }


        then:
        assert response.statusCode == HttpStatus.OK
        assert results.total_pages == totalPages
        assert results.current_page == number
        assert results.page_size == numberOfElements

        if (results.academic_sessions) {
            if( orderBy ){
                assert results.academic_sessions[0].name == sortedList[offset ? offset * limit : 0].name.toString()
            }
            else {
                assert results.academic_sessions[0].name == orderByString
            }
        }

        where:
        jwt_org | filter_org | limit  | offset | orderBy     | sortInput      || totalPages | number | numberOfElements | orderByString 
        'org1'  |   ""       | ""     | ""     | ""          | ""             || 1          | 1      | 4                | 'session4'
        'org1'  |   ""       | 2      | ""     | ""          | ""             || 2          | 1      | 2                | 'session4'
        'org1'  |   ""       | 2      | 2      | ""          | ""             || 2          | 2      | 2                | 'session2'
        'org1'  |   ""       | ""     | ""     | "desc"      | "name"         || 1          | 1      | 4                | ''
        'org1'  |   ""       | 2      | ""     | "desc"      | "name"         || 2          | 1      | 2                | ''
        'org1'  |   ""       | 1      | 1      | "desc"      | "name"         || 4          | 2      | 1                | ''
        'org1'  |   ""       | ""     | ""     | "asc"       | "name"         || 1          | 1      | 4                | ''
        'org1'  |   ""       | 2      | ""     | "asc"       | "name"         || 2          | 1      | 2                | ''
        'org1'  |   ""       | 1      | 1      | "asc"       | "name"         || 4          | 2      | 1                | ''
        'org1'  |   'org1'   | ""     | ""     | ""          | ""             || 1          | 1      | 4                | 'session4'
        'org1'  |   'org1'   | 2      | ""     | ""          | ""             || 2          | 1      | 2                | 'session4'
        'org2'  |   ""       | ""      | ""     | ""          | ""            || 1          | 1      | 1                | 'session5'

    }

    def "academicsessions GET endpoint test with multiple column sort"(){
        given:

        AcademicSession academicSession1 = new AcademicSession(name: 'session1', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSession1.startDate.setTime((new Date()).getTime() - 2 * 24 * 60 * 60 * 1000);
        academicSessionRepo.save(academicSession1)

        AcademicSession academicSession2 = new AcademicSession(name: 'session3', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSession2.startDate.setTime((new Date()).getTime() - 1 * 24 * 60 * 60 * 1000);
        academicSessionRepo.save(academicSession2)

        AcademicSession academicSession3 = new AcademicSession(name: 'session3', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when: "multiple columns sorting order with ['DESC,ASC']"

        def url = "/academicsessions?orderBy=desc,asc&sort=name,start_date"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        def results = response.getBody()

        then:
        assert response.statusCode == HttpStatus.OK
        assert results.academic_sessions[0].name == 'session3'
        assert results.academic_sessions[1].name == 'session3'
        assert results.academic_sessions[0].start_date < results.academic_sessions[1].start_date

        when: "multiple columns sorting order with ['DESC,DESC']"

        url = "/academicsessions?orderBy=desc,desc&sort=name,start_date"

        response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        results = response.getBody()

        then:
        assert response.statusCode == HttpStatus.OK
        assert results.academic_sessions[0].name == 'session3'
        assert results.academic_sessions[1].name == 'session3'
        assert results.academic_sessions[0].start_date > results.academic_sessions[1].start_date

    }


    def "academicsessions GET endpoint test for error status code and error message"(){
        given:

        AcademicSession academicSession1 = new AcademicSession(name: 'session1', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSession1.startDate.setTime((new Date()).getTime() - 2 * 24 * 60 * 60 * 1000);
        academicSessionRepo.save(academicSession1)

        AcademicSession academicSession2 = new AcademicSession(name: 'session3', type: AcademicSessionType.TERM, organizationUuid: school2.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSession2.startDate.setTime((new Date()).getTime() - 1 * 24 * 60 * 60 * 1000);
        academicSessionRepo.save(academicSession2)

        AcademicSession academicSession3 = new AcademicSession(name: 'session3', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when: "adding invalid operator for filter"

        def url = "/academicsessions?filter=name;'session1'"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)


        then:
        assert response.statusCode == HttpStatus.BAD_REQUEST
        assert response.body.errors.message[0] == "Invalid filter name;'session1'"

        when: "adding 'null' string to filter field"
        url = "/academicsessions?filter=organization_id='null'"

        response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)


        then:
        assert response.statusCode == HttpStatus.BAD_REQUEST
        assert response.body.errors.message[0] == "Unavailable filter path"

    }

    @Unroll
    def "academicsessions GET endpoint pagination tests"(){

        def academicSessions = (1..10).collect {

        AcademicSession academicSession = new AcademicSession(name: 'session'+it, type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession)
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        def url = "/academicsessions?limit=${limit}&offset=${offset}"

        def response = testRestTemplate.exchange(url, HttpMethod.GET, req, Object)
        Links links = new Links(response.getHeaders().get("Link")[0])

        then:

        assert first.on == links.links.containsKey("first")
        assert previous.on == links.links.containsKey("previous")
        assert next.on == links.links.containsKey("next")
        assert last.on == links.links.containsKey("last")

        if(first.on){
            assert links.links.get("first").limit == first.l
            assert links.links.get("first").offset == first.o
        }

        if(previous.on){
            assert links.links.get("previous").limit == previous.l
            assert links.links.get("previous").offset == previous.o
        }

        if(next.on){
            assert links.links.get("next").limit == next.l
            assert links.links.get("next").offset == next.o
        }

        if(last.on){
            assert links.links.get("last").limit == last.l
            assert links.links.get("last").offset == last.o
        }

        where:
        limit  | offset || first                   | previous                | next                   | last
        10     | 0      || [on: false]             | [on: false]             | [on: false]            | [on: false]
        10     | 5      || [on: true, l: 10, o: 0] | [on: true, l: 10, o: 0] | [on: false]            | [on: false]
        5      | 0      || [on: false]             | [on: false]             | [on: true, l: 5, o: 5] | [on: true, l: 5, o: 5]
        4      | 4      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
        4      | 6      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 2]  | [on: false]            | [on: false]
        2      | 2      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 4] | [on: true, l: 2, o: 8]
        4      | 5      || [on: true, l: 4, o: 0]  | [on: true, l: 4, o: 1]  | [on: true, l: 1, o: 9] | [on: true, l: 1, o: 9]
        2      | 5      || [on: true, l: 2, o: 0]  | [on: true, l: 2, o: 3]  | [on: true, l: 2, o: 7] | [on: true, l: 2, o: 8]

        // TODO: consider revisiting and making prev/first [on: true, l: 3, o: 0] for this case
        5      | 3      || [on: true, l: 5, o: 0]  | [on: true, l: 5, o: 0]  | [on: true, l: 2, o: 8] | [on: true, l: 2, o: 8]
    }

    def "Admin should be able to create academic session without optional field"() {
        given:

        def body = [
                "name"             : "Test Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:

        def dateFormat = new DateFormat()

        assert academicSessionRepo.findAll().size() == 1
        AcademicSession actual = academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuid("Test Session",school.uuid)
        assert actual.organizationUuid == school.uuid
        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.academic_session_uuid == actual.uuid.toString()
        assert resp.body.name == actual.name
        assert resp.body.type == actual.type.toString()
        assert resp.body.start_date == dateFormat.format(actual.startDate)
        assert resp.body.end_date == dateFormat.format(actual.endDate)

    }

    def "Admin should be able to create academic session with optional field"() {
        given:

        AcademicSession academicSession = new AcademicSession(name: 'session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        def returnedAcademicSession = academicSessionRepo.save(academicSession)

        def body = [
                "name"             : "Test Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00",
                "parent_uuid"      : returnedAcademicSession.uuid
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:

        def dateFormat = new DateFormat()

        assert academicSessionRepo.findAll().size() == 2
        AcademicSession actual = academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuid("Test Session",school.uuid)
        assert actual.organizationUuid == school.uuid
        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.academic_session_uuid == actual.uuid.toString()
        assert resp.body.organization_uuid == school.uuid.toString()
        assert resp.body.name == actual.name
        assert resp.body.type == actual.type.toString()
        assert resp.body.parent_uuid == actual.parentUuid.toString()
        assert resp.body.start_date == dateFormat.format(actual.startDate)
        assert resp.body.end_date == dateFormat.format(actual.endDate)
        //avoid delete all fail from self-constraint
        academicSessionRepo.delete(actual.uuid)

    }

    def "Admin should be able to create academic session for a campus in their school"() {
        given:

        def body = [
                "name"             : "Test Session",
                "organization_uuid": campus.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:

        def dateFormat = new DateFormat()

        assert academicSessionRepo.findAll().size() == 1
        AcademicSession actual = academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuid("Test Session",campus.uuid)
        assert actual.organizationUuid == campus.uuid
        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.academic_session_uuid == actual.uuid.toString()
        assert resp.body.name == actual.name
        assert resp.body.type == actual.type.toString()
        assert resp.body.start_date == dateFormat.format(actual.startDate)
        assert resp.body.end_date == dateFormat.format(actual.endDate)

    }

    def "Admin should not be able to create academic session for a different org"() {
        given:

        def body = [
                "name"             : "Different Org Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin2, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:

        def dateFormat = new DateFormat()

        assert academicSessionRepo.findAll().size() == 0
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field[0] == "organization"
        assert resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."


    }


    def "Teacher and student can not create academic session"() {
        given:

        def body = [
                "name"             : "Test Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token
        if(user == 'TEACHER') {
            token = createToken(teacher, school.uuid)
        } else if (user == 'STUDENT') {
            token = createToken(student, school.uuid)
        }

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 0

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field == "role_in_issuer"
        assert resp.body.errors.message == "User is not authorized to create academic session"

        where:
        user << ['TEACHER', 'STUDENT']
    }

    def "Verify POST academic session with field errors"() {
        given:
        def body = [
                "name"             : "Test Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        body.remove(missingField)

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 0

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        if(missingField == "organization_uuid") {
            assert resp.body.errors.field[0] == missingField
            assert resp.body.errors.message[0] == "Organization does not exist."
        } else {
            assert resp.body.errors.field[0] == missingField
            assert resp.body.errors.message[0] == "Missing required field " + missingField
        }

        where:
        missingField << ["name", "organization_uuid", "type","start_date","end_date"]
    }


    def "Verify duplicate academic session names can't be created"() {
        given:

        AcademicSession academicSession3 = new AcademicSession(name: 'Session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)

        def body = [
                "name"             : "session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 1

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "name", message: messagesUtil.get("academicSession.error.existing")]]
    }

    def "Verify duplicate academic session names are allowed on different orgs"() {
        given:

        AcademicSession academicSession3 = new AcademicSession(name: 'Session', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)

        def body = [
                "name"             : "session",
                "organization_uuid": school2.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin2, school2.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 2

        AcademicSession actual = academicSessionRepo.findByNameIgnoreCaseAndOrganizationUuid("session",school2.uuid)

        assert resp.statusCode == HttpStatus.CREATED
        assert resp.body.academic_session_uuid == actual.uuid.toString()
        assert resp.body.organization_uuid == school2.uuid.toString()
    }

    def "Verify academic session start date before end date"() {
        given:

        def body = [
                "name"             : "session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2018-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions", HttpMethod.POST, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 0

        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "start_date", message: messagesUtil.get("academicSession.error.startDateb4endDate")]]
    }

    @Unroll
    def "Admin should be able to update academic session"() {
        given:
        AcademicSession existing = createSession()
        AcademicSession otherOrg = createSession("new sess", school2.uuid)

        if(body.organization_uuid){
            body.organization_uuid = body.organization_uuid.replace("CAMPUS_UUID", campus.uuid.toString())
        }

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:

        assert resp.statusCode == HttpStatus.OK

        AcademicSession actual = academicSessionRepo.findOne(existing.uuid)
        DateFormat dateFormat = new DateFormat()

        assert actual.name == (body.containsKey("name") ? body.name : existing.name)
        assert actual.organizationUuid == (body.containsKey("organization_uuid") ? UUID.fromString(body.organization_uuid) : existing.organizationUuid)
        assert actual.type == (body.containsKey("type") ? body.type as AcademicSessionType : existing.type)
        assert dateFormat.format(actual.startDate) == (body.containsKey("start_date") ? body.start_date : dateFormat.format(existing.startDate))
        assert dateFormat.format(actual.endDate) == (body.containsKey("end_date") ? body.end_date : dateFormat.format(existing.endDate))

        where:
        body << [
                [name: "new sess"],
                [organization_uuid: "CAMPUS_UUID"],
                [type: "SEMESTER", name: "session 2"],
                [start_date: "2016-10-17T17:00:00-07:00", end_date: "2017-11-13T17:00:00-07:00"],
                [name: "session",organization_uuid: "CAMPUS_UUID",type: "GRADING_PERIOD",start_date: "2017-10-17T17:00:00-07:00",end_date: "2017-11-13T17:00:00-07:00"]
        ]

    }

    def "Admin should not be able to update academic session to a different org"() {
        given:

        AcademicSession existing = createSession()

        def body = [
                "name"             : "Different Org Session",
                "organization_uuid": school2.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:

        assert academicSessionRepo.findAll().size() == 1
        assert academicSessionRepo.findAll().first().name == "session"
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field[0] == "organization"
        assert resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."
    }

    def "Admin should not be able to update academic session in a different org"() {
        given:

        AcademicSession existing = createSession()

        def body = [
                "name"             : "Different Org Session",
                "organization_uuid": school2.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin2, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:

        assert academicSessionRepo.findAll().size() == 1
        assert academicSessionRepo.findAll().first().name == "session"
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.field[0] == "organization"
        assert resp.body.errors.message[0] == "The user is an 'Admin' but the admin does not have access to the organization."
    }

    def "Teacher and student can not update academic session"() {
        given:
        AcademicSession existing = createSession()
        def body = [
                "name"             : "Test Session",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token
        if(user == 'TEACHER') {
            token = createToken(teacher, school.uuid)
        } else {
            token = createToken(student, school.uuid)
        }

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:
        assert academicSessionRepo.findAll().size() == 1
        assert academicSessionRepo.findAll().first().name == "session"
        assert resp.statusCode == HttpStatus.FORBIDDEN
        assert resp.body.errors.field == "role_in_issuer"
        assert resp.body.errors.message == "User is not authorized to update academic session"

        where:
        user << ['TEACHER', 'STUDENT']
    }

    def "Verify update academic session duplicate name error"() {
        given:
        AcademicSession academicSession1 = createSession("sess 1")
        AcademicSession academicSession2 = createSession("sess 2")

        def body = [
                "name"             : "sess 2",
                "organization_uuid": school.uuid,
                "type"             : "TERM",
                "start_date"       : "2016-10-17T17:00:00-07:00",
                "end_date"         : "2017-11-13T17:00:00-07:00"
        ]

        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${academicSession1.uuid}", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "name", message: messagesUtil.get("academicSession.error.existing")]]
    }

    @Unroll
    def "Verify update academic session date error"() {
        given:
        Date start = new Date().parse('yyyy/MM/dd', '2017/10/17')
        Date end = new Date().parse('yyyy/MM/dd', '2017/10/18')
        AcademicSession academicSession1 = createSession("sess 1", school.uuid, start, end)

        def body = [:]
        if(start_date) {
            body."start_date" = start_date
        }

        if(end_date) {
            body."end_date" = end_date
        }


        String token = createToken(admin, school.uuid)

        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.ACADEMICSESSIONS_VERSION_1_MT)
        headers.setAccept([Constants.ACADEMICSESSIONS_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${academicSession1.uuid}", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[field: "start_date", message: messagesUtil.get("academicSession.error.startDateb4endDate")]]

        where:
        start_date                   | end_date
        "2018-10-17T17:00:00-07:00"  | null
        null                         | "2016-10-17T17:00:00-07:00"
        "2018-10-17T17:00:00-07:00"  | "2018-10-16T17:00:00-07:00"
    }

    @Unroll
    def "should validate roles for delete academic session"(){
        given:
        AcademicSession existing = createSession()
        User user = userRepo.save(new User(firstName: 'test', lastName: 'user', userName: 'uname', type: role, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date(), organizations: [school]))

        String token = createToken(user, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.FORBIDDEN

        where:
        role << AppUserType.values().findAll{it != AppUserType.ADMIN}
    }

    def "admin should be able to delete academic session"(){
        given:
        AcademicSession existing = createSession()

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT
        assert academicSessionRepo.findAll().size() == 0
    }

    def "admin should not be able to delete other school's academic session"(){
        given:
        AcademicSession existing = createSession()

        String token = createToken(admin2, school2.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.UNAUTHORIZED
        assert academicSessionRepo.findAll().size() == 1
    }


    def "admin should be able to delete academic session used by soft deleted class"(){
        given:
        AcademicSession existing = createSession()
        AcademicSession existing2 = createSession()

        ClassObj classObj = setupSoftDeletedClass(admin, campus, existing)
        ClassObj classObj2 = setupSoftDeletedClass(admin, campus, existing)

        ClassObj classObj3 = setupValidClass(admin, campus, existing2)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT
        assert academicSessionRepo.findAll().size() == 1
        assert classRepo.findOne(classObj.uuid).academicSession == null
        assert classRepo.findOne(classObj2.uuid).academicSession == null
        assert classRepo.findOne(classObj3.uuid).academicSession != null
    }

    def "admin should not be able to delete academic session used by a normal class"(){
        given:
        AcademicSession existing = createSession()

        ClassObj classObj = setupValidClass(admin, campus, existing)
        ClassObj classObj2 = setupValidClass(admin, campus, existing)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert (resp.body.errors == [[message:  messagesUtil.get("academicSession.error.inUse", ["{${classObj.uuid}, ${classObj.name}}", "{${classObj2.uuid}, ${classObj2.name}}"])]]) ||
                (resp.body.errors == [[message:  messagesUtil.get("academicSession.error.inUse", ["{${classObj2.uuid}, ${classObj2.name}}", "{${classObj.uuid}, ${classObj.name}}"])]])
        assert academicSessionRepo.findAll().size() == 1
        assert classRepo.findOne(classObj.uuid).academicSession != null
        assert classRepo.findOne(classObj2.uuid).academicSession != null
    }

    def "admin should not be able to delete academic session used by both normal and soft deleted class"(){
        given:
        AcademicSession existing = createSession()

        ClassObj classObj = setupValidClass(admin, campus, existing)
        ClassObj classObj2 = setupSoftDeletedClass(admin, campus, existing)

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${existing.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors == [[message:  messagesUtil.get("academicSession.error.inUse", ["{${classObj.uuid}, ${classObj.name}}"])]]
        assert academicSessionRepo.findAll().size() == 1
        assert classRepo.findOne(classObj.uuid).academicSession != null
        assert classRepo.findOne(classObj2.uuid).academicSession != null
    }

    def "should get 404 for unknown academic session"(){
        given:
        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/academicsessions/${UUID.randomUUID()}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NOT_FOUND
    }


    private AcademicSession createSession(String name = "session", UUID orgUuid = school.uuid, Date startDate= new Date(), Date endDate = new Date()+1){
        return academicSessionRepo.save(new AcademicSession(name: name, type: AcademicSessionType.TERM, organizationUuid:orgUuid, startDate: startDate, endDate: endDate, created: new Date(), updated: new Date()))
    }
}
