package com.glynlyon.kl.classroom.controllers

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Assignment
import com.glynlyon.kl.classroom.model.AssignmentType
import com.glynlyon.kl.classroom.model.ClassObj
import com.glynlyon.kl.classroom.model.ClassObjState
import com.glynlyon.kl.classroom.model.Enrollment
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.PageAssignment
import com.glynlyon.kl.classroom.model.PageObj
import com.glynlyon.kl.classroom.model.PageState
import com.glynlyon.kl.classroom.model.PlannerEntry
import com.glynlyon.kl.classroom.model.PlannerEntryState
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.Setting
import com.glynlyon.kl.classroom.model.SettingType
import com.glynlyon.kl.classroom.model.Status
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.util.Constants
import com.glynlyon.kl.classroom.util.DateFormat
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.embedded.LocalServerPort
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Unroll

class PlannerEntryIntegrationSpec extends BaseRestSpec{
    User admin, student1, student2, teacher, teacher1, teacher2

    Organization school, campus, campus2

    @Value('${cltSearch.base.uri}')
    String cltBaseUri

    @LocalServerPort
    Integer port

    def setup() {
        admin = userRepo.save(new User(firstName: 'Admin', lastName: 'teacher Last', userName: 'Test Admin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date()))
        school = organizationRepo.save(new Organization(name: 'Thrones', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date()))
        campus = organizationRepo.save(new Organization(name: 'Winterfell', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))
        campus2 = organizationRepo.save(new Organization(name: 'The Reach', type: OrganizationType.CAMPUS, originationId: 'test', created: new Date(), updated: new Date(),parent: school))

        student1 = userRepo.save(new User(firstName: 'John', lastName: 'Snow', userName: 'jSnow', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus]))
        student2 = userRepo.save(new User(firstName: 'Arya', lastName: 'Stark', userName: 'aStark', type: AppUserType.STUDENT, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, campus2]))

        teacher1 = userRepo.save(new User(firstName: 'Jasnah', lastName: 'Kholin', userName: 'jkholin', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, campus2]))
        teacher2 = userRepo.save(new User(firstName: 'Kaladin', lastName: 'Stormblessed', userName: 'kstormblessed', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, campus2]))
        teacher = userRepo.save(new User(firstName: 'teacher', lastName: 't', userName: 'teacher', type: AppUserType.TEACHER, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [campus, campus2]))

        def globalSettingValue = [admin: [override: true], classroom: [lessons: [threshold: 70, attempts: 2],	projects: [threshold: 70, attempts: 2],grade_display: [percentage: true, letter: false], grade_scale: [A:90,B:80,C:70,D:60]]]
        settingRepo.save(new Setting(sourceUUID: null, value: globalSettingValue, type: SettingType.GLOBAL, version: 0) )
    }

    def "test post planner endpoint"(){
        given:
        ClassObj classObj = setupValidClass(admin, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])

        when:
        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)


        then:
        resp.statusCode == HttpStatus.CREATED
        assert plannerEntryRepo.findAll().size() == 1
        List<PlannerEntry> actual = plannerEntryRepo.findAll()
        assert actual[0].user.uuid == body.user_uuid
        assert actual[0].pageObj.uuid == body.page_uuid
        assert actual[0].classObj.uuid == body.class_uuid
        assert actual[0].assignment.uuid == body.assignment_uuid
        assert actual[0].status == body.status as PlannerEntryState
        assert actual[0].slot == body.slot
        assert actual[0].activityId == assignment.uuid
		assert actual[0].updatedBy == student1.uuid

        resp.body.user_uuid == actual[0].user.uuid.toString()

        def expectedPage = [ page_uuid: pageObj.uuid.toString(),
                             name: pageObj.name,
                             status: pageObj.status.toString(),
                             "_links"    : [
                                     "self": ["href":"http://localhost:" + port + "/pages?filter=page_uuid='"+pageObj.uuid.toString()+"'"]
                             ]
        ]

        resp.body.page == expectedPage
        resp.body.activity_id == actual[0].activityId.toString()

        def expectedAssignment = [ assignment_uuid: assignment.assignment.uuid.toString(),
                                   assignment_title: assignment.assignment.title,
                                   assignment_type: assignment.assignment.type.toString(),
                                   "_links"    : [
                                           "self": ["href": cltBaseUri + "/nodes/"+ assignment.assignment.uuid.toString()]
                                   ]
        ]

        resp.body.assignment == expectedAssignment
        resp.body.status == actual[0].status.toString()
        resp.body.slot == actual[0].slot

    }

    def "test no campus restriction for students"() {
        given:
        ClassObj classObj = setupValidClass(admin, campus2)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1", pageObj, 1)
        createEnrollment(classObj, student1, Role.STUDENT)

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])

        when:
        def body = [
                "user_uuid"      : student1.uuid,
                "page_uuid"      : pageObj.uuid,
                "class_uuid"     : classObj.uuid,
                "assignment_uuid": assignment.assignment.uuid,
                "status"         : PlannerEntryState.NOT_STARTED.toString(),
                "slot"           : 1
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.CREATED
    }

    def "test post planner endpoint role restriction"(){
        given:
        ClassObj classObj = setupValidClass(teacher, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        Assignment a = assignmentRepo.save(
                new Assignment(
                        uuid: UUID.randomUUID(),
                        title: "Assignment 1",
                        type: AssignmentType.LESSON
                )
        )

        PageAssignment assignment = pageAssignmentRepo.save(new PageAssignment(pageObj: pageObj, assignment: a, sequence: 1, createdAt: new Date(), updatedAt: new Date()))
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]

        String token = createToken(teacher, campus.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0


        resp.body.errors.field[0] == "role_in_issuer"
        resp.body.errors.message[0] == "Only STUDENT role is allowed to add planner entries."
    }

    def "test post planner endpoint will not allow student to make an entry for another student"(){
        given:
        ClassObj classObj = setupValidClass(teacher, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        Assignment a = assignmentRepo.save(
                new Assignment(
                        uuid: UUID.randomUUID(),
                        title: "Assignment 1",
                        type: AssignmentType.LESSON
                )
        )

        PageAssignment assignment = pageAssignmentRepo.save(new PageAssignment(pageObj: pageObj, assignment: a, sequence: 1, createdAt: new Date(), updatedAt: new Date()))
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student2, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        def body = [
                "user_uuid"             : student2.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]

        String token = createToken(student1, campus.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0


        resp.body.errors.field[0] == "user_uuid"
        resp.body.errors.message[0] == "STUDENT can only create a planner entry for themselves."
    }

    def "test planner entry can not occupy the same sequence"(){
        given:
        ClassObj classObj = setupValidClass(teacher, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)

        Assignment a = assignmentRepo.save(
                new Assignment(
                        uuid: UUID.randomUUID(),
                        title: "Assignment 1",
                        type: AssignmentType.LESSON
                )
        )

        PageAssignment assignment = pageAssignmentRepo.save(new PageAssignment(pageObj: pageObj, assignment: a, sequence: 1, createdAt: new Date(), updatedAt: new Date()))
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        plannerEntryRepo.save(new PlannerEntry(user: student1, pageObj: pageObj, classObj: classObj, assignment: a, activityId: UUID.randomUUID(), status: PlannerEntryState.NOT_STARTED, slot: 1, created: new Date(), updated: new Date()))

        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]

        String token = createToken(student1, campus.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 1


        resp.body.errors.field[0] == "slot"
        resp.body.errors.message[0] == "The selected slot is already in use."
    }

    def "test planner entry can not have sequence less than 1"(){
        given:
        ClassObj classObj = setupValidClass(teacher, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        Assignment a = assignmentRepo.save(
                new Assignment(
                        uuid: UUID.randomUUID(),
                        title: "Assignment 1",
                        type: AssignmentType.LESSON
                )
        )

        PageAssignment assignment = pageAssignmentRepo.save(new PageAssignment(pageObj: pageObj, assignment: a, sequence: 1, createdAt: new Date(), updatedAt: new Date()))
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 0
        ]

        String token = createToken(student1, campus.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0


        resp.body.errors.field[0] == "slot"
        resp.body.errors.message[0] == "Slot must be a number greater than 0."
    }

    def "should not allow creation of planner entry with missing page_assignment or inactive page"(){
        given:
        ClassObj classObj = setupValidClass(teacher, campus)
        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        pageRepo.save(pageObj.with {
            it.status = PageState.INACTIVE
            it
        })
        Assignment a = assignmentRepo.save(
                new Assignment(
                        uuid: UUID.randomUUID(),
                        title: "Assignment 1",
                        type: AssignmentType.LESSON
                )
        )
        PageAssignment pageAssignment = pageAssignmentRepo.save(new PageAssignment(pageObj: pageObj, assignment: a, sequence: 1, createdAt: new Date(), updatedAt: new Date()))

        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : pageAssignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 2
        ]

        String token = createToken(student1, campus.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0
        assert resp.body.errors.size() == 1
        assert resp.body.errors.field[0] == "page_uuid"
        assert resp.body.errors.message[0] == "Cannot create planner entries referencing an INACTIVE or COMPLETED page."


        when:
        pageObj = pageRepo.findOne(pageObj.uuid)
        pageRepo.save(
                pageObj.with {
                    status = PageState.COMPLETED
                    it
                }
        )
        resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0
        assert resp.body.errors.size() == 1
        assert resp.body.errors.field[0] == "page_uuid"
        assert resp.body.errors.message[0] == "Cannot create planner entries referencing an INACTIVE or COMPLETED page."


        when:
        pageAssignmentRepo.delete(pageAssignment.uuid)
		pageObj = pageRepo.findOne(pageObj.uuid)
        pageRepo.save(
                pageObj.with {
                    status = PageState.ACTIVE
                    it
                }
        )
        resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 0
        assert resp.body.errors.size() == 1
        assert resp.body.errors.field[0] == "assignment_uuid"
        assert resp.body.errors.message[0] == "Could not find assignment with uuid " + body.assignment_uuid
    }

    def "should not create planner entry if target class is COMPLETED"() {
        ClassObj classObj = setupValidClass(teacher, campus)
        classObj.state = ClassObjState.COMPLETED
        classRepo.save(classObj)

        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])

        when:
        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == 1
        assert resp.body.errors[0] == [field: "class_uuid", message: messagesUtil.get("plannerEntry.create.class.completed.invalid")]

    }

    def "should not create planner entry if student NOT enrolled"() {

        ClassObj classObj = setupValidClass(teacher, campus)
        classObj.state = ClassObjState.STARTED
        classRepo.save(classObj)

        //do NOT enroll kid in class

        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])

        when:
        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == 1
        assert resp.body.errors[0].field == "class_uuid"
        assert resp.body.errors[0].message == "Could not find class with uuid ${classObj.uuid}"
    }

    def "should not update planner entry from slot -1 to another slot if target class is COMPLETED"() {
        ClassObj classObj = setupValidClass(teacher, campus)
        classObj.state = ClassObjState.COMPLETED
        classRepo.save(classObj)

        PageObj pageObj = setupValidPage("Page 1", classObj, 1)
        PageAssignment assignment = setupValidPageAssignment("Assignment 1",pageObj,1)
        //enroll the kid in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])

        when:
        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : pageObj.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : assignment.assignment.uuid,
                "status"                : PlannerEntryState.NOT_STARTED.toString(),
                "slot"                  : 1
        ]
        HttpEntity req = new HttpEntity(body, headers)
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == 1
        assert resp.body.errors[0] == [field: "class_uuid", message: messagesUtil.get("plannerEntry.create.class.completed.invalid")]

    }

    @Unroll
    def "should test reassign state student create restrictions"(){
        given:
        ClassObj classObj = setupValidClass(admin, campus)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        def body = [
                "user_uuid"             : student1.uuid,
                "page_uuid"             : page.uuid,
                "class_uuid"            : classObj.uuid,
                "assignment_uuid"       : pageAssignment.assignment.uuid,
                "status"                : status.toString(),
                "slot"                  : 1
        ]
        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.POST, req, Map)

        then:
        assert resp.statusCode == expectedStatus
		if(expectedStatus == HttpStatus.FORBIDDEN){
			assert resp.body.errors[0].message == env.getProperty("student.plannerentry.status.invalid")
		}

        where:
        status                                   | expectedStatus
        PlannerEntryState.NOT_STARTED            | HttpStatus.CREATED
        PlannerEntryState.IN_PROGRESS            | HttpStatus.CREATED
		PlannerEntryState.OBE                    | HttpStatus.FORBIDDEN
        PlannerEntryState.GRADED                 | HttpStatus.CREATED
        PlannerEntryState.COMPLETED              | HttpStatus.CREATED
        PlannerEntryState.REASSIGNED             | HttpStatus.BAD_REQUEST
        PlannerEntryState.REASSIGNED_IN_PROGRESS | HttpStatus.BAD_REQUEST

    }

    def "validate output of a GET planner"() {
        given:"setup class1 with page and an assignment"
        ClassObj class1 = setupValidClass(admin, campus)
        PageObj page1 = setupValidPage("Class1Page1", class1,1)
        PageAssignment page1Assignment1 = setupValidPageAssignment("Page1_Assignment1", page1,1)

        and: "one planner entry"
        PlannerEntry class1Page1Assign1PE = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, class1, page1, page1Assignment1, student1)
        setupAttempt(class1Page1Assign1PE, student1)
        setupAttempt(class1Page1Assign1PE, student1)

        when: "student1 tries to GET their planner"
        HttpHeaders headers = new HttpHeaders()
        String token = createToken(student1, school.uuid)

        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)


        HttpEntity resp = testRestTemplate.exchange("/plannerentries?filter=planner_entry_uuid='${class1Page1Assign1PE.uuid}'", HttpMethod.GET, req, Map)

        then:

        def dateFormat = new DateFormat()

        assert attemptRepo.findAll().size() == 2
        def expectedAttempts = attemptRepo.findAll().collect {
            return [
                    "attempt_uuid" : it.uuid.toString(),
                    "planner_entry_uuid": it.plannerEntry.uuid.toString(),
                    "user_uuid": it.user.uuid.toString(),
                    "activity_id": it.activityId.toString(),
                    "section_count": it.sectionCount,
                    "section_total_count": it.sectionTotalCount,
                    "question_count": it.questionCount,
                    "questions_attempted_count": it.questionsAttemptedCount,
                    "questions_correct_count": it.questionsCorrectCount,
                    "questions_incorrect_count": it.questionsIncorrectCount,
                    "questions_not_scored_count": it.questionsNotScoredCount,
                    "state": it.state.toString(),
                    "time_on_task_seconds": it.timeOnTaskSeconds,
                    "assessment_score": it.assessmentScore,
                    "created_at": dateFormat.format(it.createdAt),
                    "last_modified": dateFormat.format(it.updatedAt),
                    "section_items": it.sectionItems,
                    "sections_viewed": it.sectionsViewed,
                    "included_manual_graded": it.includedManualGraded,
                    "completed_at": dateFormat.format(it.completedAt),
					"response_overrides": it.responseOverrides,
                    "saves": [],
                    "questions_viewed": it.questionsViewed
            ]
        }

        def plannerEntry = resp.body.planner_entries.first()
        assert plannerEntry.planner_entry_uuid          == class1Page1Assign1PE.uuid.toString()
        assert plannerEntry.user_uuid                   == student1.uuid.toString()
        assert plannerEntry.class_uuid                  == class1.uuid.toString()
        assert plannerEntry.activity_id                 == page1Assignment1.uuid.toString()
        assert plannerEntry.status                      == class1Page1Assign1PE.status.toString()
        assert plannerEntry.slot                        == class1Page1Assign1PE.slot
        assert plannerEntry.assignment.assignment_uuid  == page1Assignment1.assignment.uuid.toString()
        assert plannerEntry.assignment.assignment_title == page1Assignment1.assignment.title.toString()
        assert plannerEntry.assignment.assignment_type  == page1Assignment1.assignment.type.toString()
        assert plannerEntry.page.page_uuid              == page1.uuid.toString()
        assert plannerEntry.page.name                   == page1.name
    }

    def "validate that GET planner is only allowed for students"() {
        given:
        HttpHeaders headers = new HttpHeaders()
        String token = createToken(admin, school.uuid)

        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when: "admin tries to fetch planner entries"

        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.GET, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.field == 'role_in_issuer'
        assert resp.body.message == "Planner entry can only be accessed by STUDENT."
    }

    @Unroll
    def "test GET Planner Entries with filtering"(){
        given:"setup class1 with 2 page, each with 2 assignment"
        ClassObj class1 = setupValidClass(admin, campus)
        PageObj page1 = setupValidPage("Class1Page1", class1,1)
        PageObj page2 = setupValidPage("Class1Page2", class1,2)
        PageAssignment page1Assignment1 = setupValidPageAssignment("Page1_Assignment1", page1,1)
        PageAssignment page1Assignment2 = setupValidPageAssignment("Page1_Assignment2", page1,2)
        PageAssignment page2Assignment1 = setupValidPageAssignment("Page2_Assignment1", page2,1)
        PageAssignment page2Assignment2 = setupValidPageAssignment("Page2_Assignment2", page2,2)

        and: "setup class2 with 1 page and 1 assignment"
        ClassObj class2 = setupValidClass(admin, campus)
        PageObj class2Page = setupValidPage("page1", class2,1)
        PageAssignment class2Assignment = setupValidPageAssignment("Page1_Assignment1", class2Page,1)


        and: "student has planner entries from class 1 and 2"
        PlannerEntry class1Page1Assign1PE = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, class1, page1, page1Assignment1, student1)
        PlannerEntry class1Page1Assign2PE = setupPlannerEntry(-1, PlannerEntryState.COMPLETED,  class1, page1, page1Assignment2, student1)
        PlannerEntry class1Page2Assign1PE = setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, class1, page2, page2Assignment1, student1)
        PlannerEntry class1Page2Assign2PE = setupPlannerEntry(-1, PlannerEntryState.GRADED,  class1, page2, page2Assignment2, student1)
        PlannerEntry class2Page1Assign1PE = setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, class2, class2Page, class2Assignment, student1)

        and: "student2 has planner entries"
        PlannerEntry student2PlannerEntry = setupPlannerEntry(1,PlannerEntryState.IN_PROGRESS,class1, page1,page1Assignment1,student2)


        when: "student1 tries to planner"
        HttpHeaders headers = new HttpHeaders()
        String token = createToken(student1, school.uuid)

        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        if(field == 'class_uuid'){
            criteria = criteria.replace("REPLACE_ME", class1.uuid.toString())
        } else if (field == 'page_uuid'){
            criteria = criteria.replace("REPLACE_ME", page1.uuid.toString())
        } else if (field == 'user_uuid') {
            criteria = criteria.replace("REPLACE_ME", student1.uuid.toString())
        }else if (field == 'activity_id') {
            criteria = criteria.replace("REPLACE_ME", page1Assignment1.uuid.toString())
        }else if (field == "assignment_uuid"){
            criteria = criteria.replace("REPLACE_ME", page1Assignment1.assignment.uuid.toString())
        }
        HttpEntity resp = testRestTemplate.exchange("/plannerentries?${criteria}", HttpMethod.GET, req, Map)

        then:
        switch(expectedOutput){
            case "onlyStudent1PEs": //based on student's JWT token (or) filter on user_uuid
                assert resp.body.planner_entries.planner_entry_uuid.sort()==[class1Page1Assign1PE,class1Page1Assign2PE,class1Page2Assign1PE,class1Page2Assign2PE,class2Page1Assign1PE].uuid*.toString().sort()
                break
            case "only4PEsOnDeck": //filter on slot > 0
                assert resp.body.planner_entries.planner_entry_uuid == [class1Page1Assign1PE,class1Page2Assign1PE,class2Page1Assign1PE].uuid*.toString()
                break
            case "onlyClass1PEs": //filter on class_uuid. Note default sort is on slot
                assert resp.body.planner_entries.planner_entry_uuid == [class1Page1Assign2PE,class1Page2Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE].uuid*.toString()
                break
            case "onlyPage1PEs": //filter on page.name or page.uuid. Note default sort is on slot.
                assert resp.body.planner_entries.planner_entry_uuid == [class1Page1Assign2PE,class1Page1Assign1PE].uuid*.toString()
                break
            case "onlyCompleted": //filter on status
                assert resp.body.planner_entries.planner_entry_uuid == [class1Page1Assign2PE.uuid.toString()]
                break
            case "page1Assignment1": //filter on activity_id = page1assignment1
                assert resp.body.planner_entries.planner_entry_uuid == [class1Page1Assign1PE.uuid.toString()]
                break
            case "fieldNotSupported":
                assert resp.body.errors.first().message == 'Unavailable filter path'
        }
        where:
        field               | criteria                                         || expectedOutput
        ''                  |""                                                || "onlyStudent1PEs"
        ''                  |"filter=slot>'0'"                                 || "only4PEsOnDeck"
        ''                  |"filter=page.name='Class1Page1'"                  || "onlyPage1PEs"
        'page_uuid'         |"filter=page.page_uuid='REPLACE_ME'"              || "onlyPage1PEs"
        ''                  |"filter=status='COMPLETED'"                       || "onlyCompleted"
        'class_uuid'        |"filter=class_uuid='REPLACE_ME'"                  || "onlyClass1PEs"
        'user_uuid'         |"filter=user_uuid='REPLACE_ME'"                   || "onlyStudent1PEs"
        'activity_id'       |"filter=activity_id='REPLACE_ME'"                 || "page1Assignment1"
        'assignment_uuid'   |"filter=assignment.assignment_uuid='REPLACE_ME'"  || "page1Assignment1"
    }

    @Unroll
    def "test GET Planner Enteries with sorting"(){
        given:"setup class1 with 2 page, each with 2 assignment"
        ClassObj class1 = setupValidClass(admin, campus)
        PageObj page1 = setupValidPage("Class1Page1", class1,1)
        PageObj page2 = setupValidPage("Class1Page2", class1,2)

        PageAssignment page1Assignment1 = setupValidPageAssignment("Page1_Assignment1", page1,1)
        PageAssignment page1Assignment2 = setupValidPageAssignment("Page1_Assignment2", page1,2)
        PageAssignment page2Assignment1 = setupValidPageAssignment("Page2_Assignment1", page2,1)
        PageAssignment page2Assignment2 = setupValidPageAssignment("Page2_Assignment2", page2,2)



        and: "student has planner entries from class 1 and 2"
        PlannerEntry class1Page1Assign1PE = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, class1, page1, page1Assignment1, student1)
        PlannerEntry class1Page1Assign2PE = setupPlannerEntry(2, PlannerEntryState.COMPLETED,  class1, page1, page1Assignment2, student1)
        PlannerEntry class1Page2Assign1PE = setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, class1, page2, page2Assignment1, student1)
        PlannerEntry class1Page2Assign2PE = setupPlannerEntry(-1, PlannerEntryState.GRADED,  class1, page2, page2Assignment2, student1)


        when: "student tries to fetch planner"
        HttpHeaders headers = new HttpHeaders()
        String token = createToken(student1, school.uuid)

        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        HttpEntity resp = testRestTemplate.exchange("/plannerentries?sort=${sort}&orderBy=${direction}", HttpMethod.GET, req, Map)

        then:
        switch(expectedOutput){
            case "defaultSort":
                assert resp.body.planner_entries.slot ==[class1Page2Assign2PE,class1Page1Assign1PE,class1Page1Assign2PE,class1Page2Assign1PE].slot
                break
            case "sortBySlotDesc": //filter on slot > 0
                assert resp.body.planner_entries.slot == [class1Page2Assign1PE,class1Page1Assign2PE,class1Page1Assign1PE,class1Page2Assign2PE].slot
                break
            case "sortByPageAsc": //Sort by page_uuid
                assert resp.body.planner_entries.planner_entry_uuid ==
                        [class1Page1Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE,class1Page2Assign2PE].sort{a,b ->
                            a.pageObj.uuid.toString() <=> b.pageObj.uuid.toString() ?: a.slot <=> b.slot}.uuid*.toString()
                break
            case "sortByPageDesc":
                assert resp.body.planner_entries.planner_entry_uuid ==
                        [class1Page1Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE,class1Page2Assign2PE].sort{a,b ->
                            b.pageObj.uuid.toString() <=> a.pageObj.uuid.toString() ?: b.slot <=> a.slot}.uuid*.toString()
                break
            case "sortByStatusAsc":
                assert resp.body.planner_entries.status == [class1Page1Assign2PE,class1Page2Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE].status*.toString()
                break
            case "sortByActivityAsc":
                assert resp.body.planner_entries.activity_id ==
                        [class1Page1Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE,class1Page2Assign2PE].activityId*.toString().sort()
                break
            case "sortByAssignmentTitle":
                assert resp.body.planner_entries.assignment.assignment_title ==
                        [class1Page1Assign2PE,class1Page1Assign1PE,class1Page2Assign1PE,class1Page2Assign2PE].assignment.title*.toString().sort()
                break
        }
        where:
        sort                          | direction                                 || expectedOutput
        ''                            |''                                         || "defaultSort"
        'slot'                        |"asc"                                      || "defaultSort"
        'slot'                        |"desc"                                     || "sortBySlotDesc"
        'page.page_uuid,slot'         |"asc,asc"                                  || "sortByPageAsc"
        'page.page_uuid,slot'         |"desc,desc"                                || "sortByPageDesc"
        'status'                      |"asc"                                      || "sortByStatusAsc"
        'activity_id'                 |"asc"                                      || "sortByActivityAsc"
        'assignment.assignment_title' |"asc"                                      || "sortByAssignmentTitle"

    }

    /**
     * SAT-1846
     *  Kid clicks the Remove button to take the NOT_STARTED card off the canvas.  DELETE /plannerentries
     *  The endpoint will validate that kid is still enrolled and class not COMPLETED.  When fails, will return HttpStatus.RESET_CONTENT
     *  - but the planner entry will be deleted
     *  If kid is enrolled and class ACTIVE - will return NO_CONTENT
     */
    def "should be able to delete planner NOT_STARTED entry"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment2", page, 6)

        if (enrolledFlag == true) {
            enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, role: Role.STUDENT, status: Status.ACTIVE))
        }
        classObj.state = classState
        classRepo.save(classObj)

        PlannerEntry entry = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        PlannerEntry entry2 = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment2.assignment,
                activityId: pageAssignment2.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 2
        ))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${entry.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedStatus

        List<PlannerEntry> actual = plannerEntryRepo.findAll().asList()
        assert actual.size() == 1
        assert actual.uuid.containsAll(entry2.uuid)

        where:
        enrolledFlag                | classState                | expectedStatus
        true                        | ClassObjState.STARTED     | HttpStatus.NO_CONTENT
        false                       | ClassObjState.STARTED     | HttpStatus.RESET_CONTENT
        true                        | ClassObjState.COMPLETED   | HttpStatus.RESET_CONTENT
    }

    @Unroll
    def "should validate planner entry delete by role"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)

        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, role: Role.STUDENT, status: Status.ACTIVE))

        Map userMap = [
                student1: student1,
                student2: student2,
                admin: admin,
                enrolledTeacher: teacher1,
                someOtherTeacher: teacher2
        ]

        PlannerEntry entry = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${entry.uuid}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == expectedStatus
        assert plannerEntryRepo.findAll().size() == (expectedStatus == HttpStatus.BAD_REQUEST ? 1 : 0)

        where:
        user               || expectedStatus
        'student1'         || HttpStatus.NO_CONTENT
        'student2'         || HttpStatus.BAD_REQUEST
        'admin'            || HttpStatus.NO_CONTENT
        'enrolledTeacher'  || HttpStatus.NO_CONTENT
        'someOtherTeacher' || HttpStatus.BAD_REQUEST
    }

    def "should get error when deleting unknown planner entry"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)

        PlannerEntry entry = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${UUID.randomUUID()}", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 1
    }

    @Unroll
    def "should delete by page uuid and assignment uuid"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))

        PageObj page1 = setupValidPage(classObj)
        PageObj page2 = setupValidPage(classObj)

        Map pageMap = [page1: page1, page2: page2]

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment 1", page1, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page1, 6)
        PageAssignment pageAssignment3 = setupValidPageAssignment("page assignment 3", page2, 1)
        PageAssignment pageAssignment4 = setupValidPageAssignment("page assignment 4", page2, 8, pageAssignment1.assignment.uuid)

        Map assignmentMap = [pageAssignment1: pageAssignment1, pageAssignment2: pageAssignment2, pageAssignment3: pageAssignment3, pageAssignment4: pageAssignment4]


        Map<String, PlannerEntry> plannerMap = [
                p1 : setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment1, student1),
                p2 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student1),
                p3 : setupPlannerEntry(3, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment3, student1),
                p4 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student1),
                p5 : setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment1, student2),
                p6 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student2),
                p7 : setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, classObj, page2, pageAssignment3, student2),
                p8 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student2)
        ]
        
        Map userMap = [
                student1: student1,
                student2: student2,
                admin: admin,
                enrolledTeacher: teacher1,
                someOtherTeacher: teacher2
        ]


        def body = [
                filter: [
                        status: status,
                        page_uuid: pageMap[pageName].uuid,
                        assignment_uuid: pageAssignmentName ? assignmentMap[pageAssignmentName].assignment.uuid : null,
                        class_uuid: pageMap[pageName].classObj.uuid
                ]
        ]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        assert plannerEntryRepo.findAll().size() == (plannerMap.size() - deleted.size())

        List<PlannerEntry> unchanged = plannerMap.findAll{!deleted.contains(it.key)}.collect {plannerEntryRepo.findOne(it.value.uuid)}
        assert unchanged.size() == plannerMap.size() - deleted.size()

        where:
        user               | pageName | pageAssignmentName | status        || deleted
        'enrolledTeacher'  | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' || ['p1']
        'enrolledTeacher'  | 'page1'  | 'pageAssignment2'  | 'NOT_STARTED' || ['p2', 'p6']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment3'  | 'NOT_STARTED' || ['p7']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment4'  | 'NOT_STARTED' || []
        'admin'            | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' || ['p1']
        'admin'            | 'page1'  | 'pageAssignment2'  | 'NOT_STARTED' || ['p2', 'p6']
        'admin'            | 'page2'  | 'pageAssignment3'  | 'NOT_STARTED' || ['p7']
        'admin'            | 'page2'  | 'pageAssignment4'  | 'NOT_STARTED' || []
        'someOtherTeacher' | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' || []
        'enrolledTeacher'  | 'page1'  | ''                 | 'NOT_STARTED' || ['p1','p2','p6']
        'enrolledTeacher'  | 'page2'  | ''                 | 'NOT_STARTED' || ['p7']
        
        'enrolledTeacher'  | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' || ['p5']
        'enrolledTeacher'  | 'page1'  | 'pageAssignment2'  | 'IN_PROGRESS' || []
        'enrolledTeacher'  | 'page2'  | 'pageAssignment3'  | 'IN_PROGRESS' || ['p3']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment4'  | 'IN_PROGRESS' || ['p4', 'p8']
        'admin'            | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' || ['p5']
        'admin'            | 'page1'  | 'pageAssignment2'  | 'IN_PROGRESS' || []
        'admin'            | 'page2'  | 'pageAssignment3'  | 'IN_PROGRESS' || ['p3']
        'admin'            | 'page2'  | 'pageAssignment4'  | 'IN_PROGRESS' || ['p4', 'p8']
        'someOtherTeacher' | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' || []
        'enrolledTeacher'  | 'page1'  | ''                 | 'IN_PROGRESS' || ['p5']
        'enrolledTeacher'  | 'page2'  | ''                 | 'IN_PROGRESS' || ['p3', 'p4', 'p8']

    }

    @Unroll
    def "should delete by class_uuid"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        ClassObj classObj2 = setupValidClass(admin, school)
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj2, role: Role.TEACHER, status: Status.ACTIVE))

        PageObj page1 = setupValidPage(classObj)
        PageObj page2 = setupValidPage(classObj)
        PageObj page3 = setupValidPage(classObj2)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment 1", page1, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page1, 6)
        PageAssignment pageAssignment3 = setupValidPageAssignment("page assignment 3", page2, 1)
        PageAssignment pageAssignment4 = setupValidPageAssignment("page assignment 4", page2, 8, pageAssignment1.assignment.uuid)
        PageAssignment pageAssignment5 = setupValidPageAssignment("page assignment 5", page3, 3)

        Map<String, PlannerEntry> plannerMap = [
                p1 : setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment1, student1),
                p2 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student1),
                p3 : setupPlannerEntry(3, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment3, student1),
                p4 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student1),
                p5 : setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment1, student2),
                p6 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student2),
                p7 : setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, classObj, page2, pageAssignment3, student2),
                p8 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj2, page3, pageAssignment5, student2),
        ]

        Map userMap = [
                student1: student1,
                student2: student2,
                admin: admin,
                enrolledTeacher: teacher1,
                someOtherTeacher: teacher2
        ]

        Map classMap = [classObj: classObj, classObj2: classObj2]

        def body = [
                filter: [
                        status: status,
                        class_uuid: classMap[className].uuid
                ]
        ]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.DELETE, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        assert plannerEntryRepo.findAll().size() == (plannerMap.size() - deleted.size())

        List<PlannerEntry> unchanged = plannerMap.findAll{!deleted.contains(it.key)}.collect {plannerEntryRepo.findOne(it.value.uuid)}
        assert unchanged.size() == plannerMap.size() - deleted.size()

        where:
        user               | className   | status        || deleted
        'enrolledTeacher'  | 'classObj'  | 'NOT_STARTED' || ['p1', 'p2', 'p6', 'p7']
        'enrolledTeacher'  | 'classObj'  | 'IN_PROGRESS' || ['p3', 'p4', 'p5']
        'enrolledTeacher'  | 'classObj2' | 'NOT_STARTED' || []
        'enrolledTeacher'  | 'classObj2' | 'IN_PROGRESS' || ['p8']
    }

    @Unroll
    def "should update by class_uuid"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        ClassObj classObj2 = setupValidClass(admin, school)
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj2, role: Role.TEACHER, status: Status.ACTIVE))

        PageObj page1 = setupValidPage(classObj)
        PageObj page2 = setupValidPage(classObj)
        PageObj page3 = setupValidPage(classObj2)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment 1", page1, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page1, 6)
        PageAssignment pageAssignment3 = setupValidPageAssignment("page assignment 3", page2, 1)
        PageAssignment pageAssignment4 = setupValidPageAssignment("page assignment 4", page2, 8, pageAssignment1.assignment.uuid)
        PageAssignment pageAssignment5 = setupValidPageAssignment("page assignment 5", page3, 3)

        Map<String, PlannerEntry> plannerMap = [
                p1 : setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment1, student1),
                p2 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student1),
                p3 : setupPlannerEntry(3, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment3, student1),
                p4 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student1),
                p5 : setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment1, student2),
                p6 : setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student2),
                p7 : setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, classObj, page2, pageAssignment3, student2),
                p8 : setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj2, page3, pageAssignment5, student2),
        ]

        Map userMap = [
                student1: student1,
                student2: student2,
                admin: admin,
                enrolledTeacher: teacher1,
                someOtherTeacher: teacher2
        ]

        Map classMap = [classObj: classObj, classObj2: classObj2]

        def body = [
                filter: [
                        status: status,
                        class_uuid: classMap[className].uuid
                ],
                planner_entry: [
                        status: new_status,
                        slot: new_slot
                ]
        ]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT
        List<PlannerEntry> updatedEntries = plannerMap.findAll { updated.contains(it.key) }.collect {
            plannerEntryRepo.findOne(it.value.uuid)
        }
        List<PlannerEntry> unchanged = plannerMap.findAll { !updated.contains(it.key) }.collect { it.value }

        if(new_status) {
            assert updatedEntries.every { it.status == new_status as PlannerEntryState }
			assert updatedEntries.every { it.updatedBy == userMap[user].uuid }
            assert unchanged.every { it.status == plannerEntryRepo.findOne(it.uuid).status }
        }
        if(new_slot){
            assert updatedEntries.every { it.slot == new_slot }
			assert updatedEntries.every { it.updatedBy == userMap[user].uuid }
            assert unchanged.every { it.slot == plannerEntryRepo.findOne(it.uuid).slot }
        }
		
        where:
        user               | className   | status        | new_status | new_slot || updated
        'enrolledTeacher'  | 'classObj'  | 'NOT_STARTED' | "OBE"      | null     || ['p1', 'p2', 'p6', 'p7']
        'enrolledTeacher'  | 'classObj'  | 'IN_PROGRESS' | "OBE"      | null     || ['p3', 'p4', 'p5']
        'enrolledTeacher'  | 'classObj2' | 'NOT_STARTED' | "OBE"      | null     || []
        'enrolledTeacher'  | 'classObj2' | 'IN_PROGRESS' | "OBE"      | null     || ['p8']
        'enrolledTeacher'  | 'classObj'  | null          | null       | -1       || ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']
        'enrolledTeacher'  | 'classObj'  | null          | "GRADED"   | -1       || ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']
        'enrolledTeacher'  | 'classObj2' | null          | null       | -1       || ['p8']
    }


    @Unroll
    def "should not allow STUDENT to call update or delete collection"(){
        given:

        def body = [
                filter: [
                        status: "NOT_STARTED",
                        page_uuid: "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902",
                        assignment_uuid: "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902",
                        class_uuid: "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902"
                ]
        ]

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", method, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body == [errors:[["field":"role_in_issuer", "message":"Planner entry can only be accessed by Admins and Teachers"]]]

        where:
        method << [HttpMethod.DELETE, HttpMethod.PATCH]
    }

    @Unroll
    def "should validate params input"(){
        given:

        def body = [
                filter: [
                        status: status,
                        page_uuid: page_uuid,
                        class_uuid: class_uuid
                ],
                planner_entry: [
                        status: new_status,
                        slot: new_slot
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:

        HttpEntity resp = testRestTemplate.exchange("/plannerentries", method, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert resp.body.errors.size() == errors.size()
        errors.each {
            assert resp.body.errors.contains(it)
        }

        where:
        method            | status           | page_uuid                              | class_uuid                             | new_status | new_slot || errors
        HttpMethod.DELETE | "IN_PROGRESS"    | "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902" | null                                   | null       | null     || [[field: "class_uuid", message: "Missing required field class_uuid"]]
        HttpMethod.PATCH  | "IN_PROGRESS"    | "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902" | null                                   | null       | null     || [[field: "class_uuid", message: "Missing required field class_uuid"]]
        HttpMethod.PATCH  | "IN_PROGRESS"    | "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902" | "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902" | "BLAH"     | null     || [[field: "planner_entry.status", message: "Invalid value for planner_entry.status BLAH"]]
        HttpMethod.PATCH  | null             | null                                   | "e0f38c75-9b01-4a5d-8a2b-3b4b9d45a902" | null       | 1        || [[field: "slot", message: "Cannot bulk update planner entries to any slot other than -1."]]
    }

    @Unroll
    def "should update by page uuid and assignment uuid"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))

        PageObj page1 = setupValidPage(classObj)
        PageObj page2 = setupValidPage(classObj)

        Map pageMap = [page1: page1, page2: page2]

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment 1", page1, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page1, 6)
        PageAssignment pageAssignment3 = setupValidPageAssignment("page assignment 3", page2, 1)
        PageAssignment pageAssignment4 = setupValidPageAssignment("page assignment 4", page2, 8, pageAssignment1.assignment.uuid)

        Map assignmentMap = [pageAssignment1: pageAssignment1, pageAssignment2: pageAssignment2, pageAssignment3: pageAssignment3, pageAssignment4: pageAssignment4]


        Map<String, PlannerEntry> plannerMap = [
                p1: setupPlannerEntry(1, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment1, student1),
                p2: setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student1),
                p3: setupPlannerEntry(3, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment3, student1),
                p4: setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student1),
                p5: setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment1, student2),
                p6: setupPlannerEntry(2, PlannerEntryState.NOT_STARTED, classObj, page1, pageAssignment2, student2),
                p7: setupPlannerEntry(3, PlannerEntryState.NOT_STARTED, classObj, page2, pageAssignment3, student2),
                p8: setupPlannerEntry(4, PlannerEntryState.IN_PROGRESS, classObj, page2, pageAssignment4, student2)
        ]

        Map userMap = [
                student1        : student1,
                student2        : student2,
                admin           : admin,
                enrolledTeacher : teacher1,
                someOtherTeacher: teacher2
        ]

        def body = [
                filter: [
                        status         : status,
                        page_uuid      : pageMap[pageName].uuid,
                        assignment_uuid: pageAssignmentName ? assignmentMap[pageAssignmentName].assignment.uuid : null,
                        class_uuid     : pageMap[pageName].classObj.uuid
                ],
                planner_entry: [
                        status: new_status
                ]
        ]

        String token = createToken(userMap[user], school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        List<PlannerEntry> unchanged = plannerMap.findAll{updated.contains(it.key)}.collect{plannerEntryRepo.findOne(it.value.uuid)}
        assert unchanged.every{it.status == new_status as PlannerEntryState}

        where:
        user               | pageName | pageAssignmentName | status        | new_status || updated
        'enrolledTeacher'  | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' | "OBE"      || ['p1']
        'enrolledTeacher'  | 'page1'  | 'pageAssignment2'  | 'NOT_STARTED' | "OBE"      || ['p2', 'p6']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment3'  | 'NOT_STARTED' | "OBE"      || ['p7']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment4'  | 'NOT_STARTED' | "OBE"      || []
        'admin'            | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' | "OBE"      || ['p1']
        'admin'            | 'page1'  | 'pageAssignment2'  | 'NOT_STARTED' | "OBE"      || ['p2', 'p6']
        'admin'            | 'page2'  | 'pageAssignment3'  | 'NOT_STARTED' | "OBE"      || ['p7']
        'admin'            | 'page2'  | 'pageAssignment4'  | 'NOT_STARTED' | "OBE"      || []
        'someOtherTeacher' | 'page1'  | 'pageAssignment1'  | 'NOT_STARTED' | "OBE"      || []
        'enrolledTeacher'  | 'page1'  | ''                 | 'NOT_STARTED' | "OBE"      || ['p1','p2','p6']
        'enrolledTeacher'  | 'page2'  | ''                 | 'NOT_STARTED' | "OBE"      || ['p7']

        'enrolledTeacher'  | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' | "OBE"      || ['p5']
        'enrolledTeacher'  | 'page1'  | 'pageAssignment2'  | 'IN_PROGRESS' | "OBE"      || []
        'enrolledTeacher'  | 'page2'  | 'pageAssignment3'  | 'IN_PROGRESS' | "OBE"      || ['p3']
        'enrolledTeacher'  | 'page2'  | 'pageAssignment4'  | 'IN_PROGRESS' | "OBE"      || ['p4', 'p8']
        'admin'            | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' | "OBE"      || ['p5']
        'admin'            | 'page1'  | 'pageAssignment2'  | 'IN_PROGRESS' | "OBE"      || []
        'admin'            | 'page2'  | 'pageAssignment3'  | 'IN_PROGRESS' | "OBE"      || ['p3']
        'admin'            | 'page2'  | 'pageAssignment4'  | 'IN_PROGRESS' | "OBE"      || ['p4', 'p8']
        'someOtherTeacher' | 'page1'  | 'pageAssignment1'  | 'IN_PROGRESS' | "OBE"      || []
        'enrolledTeacher'  | 'page1'  | ''                 | 'IN_PROGRESS' | "OBE"      || ['p5']
        'enrolledTeacher'  | 'page2'  | ''                 | 'IN_PROGRESS' | "OBE"      || ['p3', 'p4', 'p8']

    }

    def "should set OBE slots to -1 in a batch update"() {
        given:
        ClassObj classObj = setupValidClass(admin, school)
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, role: Role.TEACHER, status: Status.ACTIVE))

        PageObj page1 = setupValidPage(classObj)

        PageAssignment pageAssignment1 = setupValidPageAssignment("page assignment 1", page1, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page1, 6)

        PlannerEntry pe1 = setupPlannerEntry(1, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment1, student1)
        PlannerEntry pe2 = setupPlannerEntry(2, PlannerEntryState.IN_PROGRESS, classObj, page1, pageAssignment2, student1)

        def body = [
                filter: [
                        status         : PlannerEntryState.IN_PROGRESS.toString(),
                        page_uuid      : page1.uuid.toString(),
                        class_uuid     : classObj.uuid.toString()
                ],
                planner_entry: [
                        status: PlannerEntryState.OBE.toString()
                ]
        ]

        String token = createToken(admin, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRY_PARAMS_VERSION_1_MT)
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.NO_CONTENT

        PlannerEntry editedPe = plannerEntryRepo.findByUuid(pe1.uuid)
        assert editedPe.status == PlannerEntryState.OBE
        assert editedPe.slot == -1
    }


    @Unroll
    def "should update planner entry"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        PageAssignment pageAssignment2 = setupValidPageAssignment("page assignment 2", page, 6)
        PageAssignment pageAssignment3 = setupValidPageAssignment("page assignment 2", page, 9)

        //enroll the kids in the class
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: student2, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))

        PlannerEntry existing = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        PlannerEntry existing2 = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment2.assignment,
                activityId: pageAssignment2.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 2
        ))

        PlannerEntry existing3 = plannerEntryRepo.save(new PlannerEntry(
                user: student2,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 3
        ))

        PlannerEntry existing4 = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment3.assignment,
                activityId: pageAssignment3.uuid,
                status: PlannerEntryState.COMPLETED,
                slot: -1
        ))
        Map<Integer, PlannerEntry> peMap = [1: existing, 2: existing2, 3: existing3, 4: existing4]
        UUID targetUuid = peMap[targetPe].uuid

        def body = [:]
        PlannerEntryState expectedPeState = peMap[targetPe].status
        Integer expectedSlot = peMap[targetPe].slot
        if(status != null) {
            body.status = status
            expectedPeState = status
        }
        if(slot != null) {
            body.slot = slot
            expectedSlot = slot
        }

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${targetUuid}", HttpMethod.PATCH, req, Map)

        then:

        assert resp.statusCode == expectedStatus

		if(expectedStatus == HttpStatus.FORBIDDEN){
			assert resp.body.errors[0].message == env.getProperty("student.plannerentry.status.invalid")
		}
		else if(errors.size()){
			assert resp.body.errors.size() == errors.size()
			errors.each {
				assert resp.body.errors.contains(it)
			}
		}
		else {
			checkCreateUpdateResponse(peMap[targetPe], resp, expectedSlot, expectedPeState, student1.uuid)
		}

		where:
		targetPe | status                        | slot || expectedStatus         | errors
		1        | PlannerEntryState.COMPLETED   | -1   || HttpStatus.OK          | []
		1        | PlannerEntryState.GRADED      | -1   || HttpStatus.OK          | []
		1        | PlannerEntryState.IN_PROGRESS | -1   || HttpStatus.OK          | []
		1        | PlannerEntryState.NOT_STARTED | -1   || HttpStatus.BAD_REQUEST | [[field: "slot / status", message: "Cannot have planner entry with status NOT_STARTED and slot -1."]]
		1        | PlannerEntryState.OBE         | -1   || HttpStatus.FORBIDDEN   | []
		1        | PlannerEntryState.COMPLETED   | 3    || HttpStatus.OK          | []
		1        | PlannerEntryState.GRADED      | 3    || HttpStatus.OK          | []
		1        | PlannerEntryState.IN_PROGRESS | 3    || HttpStatus.OK          | []
		1        | PlannerEntryState.NOT_STARTED | 3    || HttpStatus.OK          | []
		1        | PlannerEntryState.OBE         | -1   || HttpStatus.FORBIDDEN   | []
		1        | PlannerEntryState.NOT_STARTED | 2    || HttpStatus.BAD_REQUEST | [[field: "slot", message: "Slot 2 is already in use."]]
		1        | PlannerEntryState.IN_PROGRESS | 1    || HttpStatus.OK          | []
		1        | null                          | null || HttpStatus.BAD_REQUEST | [[field: "slot / status", message: "One of slot or status is required for planner entry update"]]
		1        | null                          | -1   || HttpStatus.BAD_REQUEST | [[field: "slot / status", message: "Cannot have planner entry with status NOT_STARTED and slot -1."]]
		4        | PlannerEntryState.NOT_STARTED | null || HttpStatus.BAD_REQUEST | [[field: "slot / status", message: "Cannot have planner entry with status NOT_STARTED and slot -1."]]
		1        | PlannerEntryState.COMPLETED   | null || HttpStatus.OK          | []
		1        | PlannerEntryState.GRADED      | null || HttpStatus.OK          | []
		1        | PlannerEntryState.IN_PROGRESS | null || HttpStatus.OK          | []
		1        | PlannerEntryState.NOT_STARTED | null || HttpStatus.OK          | []
		1        | PlannerEntryState.OBE         | -1   || HttpStatus.FORBIDDEN   | []
		4        | null                          | 2    || HttpStatus.BAD_REQUEST | [[field: "slot", message: "Slot 2 is already in use."]]
		4        | null                          | 3    || HttpStatus.OK          | []
		1        | null                          | 3    || HttpStatus.OK          | []

    }

    @Unroll
    def "should test reassign state update restrictions"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        enrollmentRepo.save(new Enrollment(user: student1, classObj: classObj, primaryRole: false, role: Role.STUDENT, status: Status.ACTIVE))
        enrollmentRepo.save(new Enrollment(user: teacher1, classObj: classObj, primaryRole: false, role: Role.TEACHER, status: Status.ACTIVE))

        PlannerEntry existing = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: startStatus,
                slot: 1
        ))

        PlannerEntry existing2 = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: startStatus,
                slot: 2
        ))

        PlannerEntry existing3 = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: startStatus,
                slot: 3
        ))

        def body = [
                status: targetStatus
        ]

        def validate = { Integer scenario, ResponseEntity r ->
			if(scenario == 1){
                assert r.statusCode == HttpStatus.OK
            }
            else if(scenario == 2 || scenario == 3){
                def errors = [[field: "status", message: "Students cannot set planner entries to be REASSIGNED unless current state is REASSIGNED_IN_PROGRESS"]]
                if(scenario == 3){
                    errors = [[field: "status", message: "Students cannot set planner entries to be REASSIGNED_IN_PROGRESS unless current state is REASSIGNED"]]
                }
                assert r.statusCode == HttpStatus.BAD_REQUEST
                assert r.body.errors.size() == errors.size()
                errors.each {
                    assert r.body.errors.contains(it)
                }
            }
			else if(scenario == 4 ){
				assert r.statusCode == HttpStatus.FORBIDDEN
				assert r.body.errors[0].message == env.getProperty("student.plannerentry.status.invalid")
			}
            else {
                assert false
            }
            return true
        }

        def makeRequest = { User user ->
            String token = createToken(user, school.uuid)
            HttpHeaders headers = new HttpHeaders()
            headers.set("Authorization", "Bearer ${token}")
            headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
            headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
            HttpEntity req = new HttpEntity(body, headers)
            return testRestTemplate.exchange("/plannerentries/${existing.uuid}", HttpMethod.PATCH, req, Map)
        }

        HttpEntity resp

        when:
        resp = makeRequest(student1)

        then:
        validate(s, resp)

        when:
        resp = makeRequest(teacher1)

        then:
        validate(eT, resp)

        when:
        resp = makeRequest(admin)

        then:
        validate(a, resp)

        where:
        startStatus                              | targetStatus                             | s | eT | a
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
		PlannerEntryState.NOT_STARTED            | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.REASSIGNED             | 2 | 1  | 1
        PlannerEntryState.NOT_STARTED            | PlannerEntryState.REASSIGNED_IN_PROGRESS | 3 | 1  | 1

        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.IN_PROGRESS            | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.REASSIGNED             | 2 | 1  | 1
        PlannerEntryState.IN_PROGRESS            | PlannerEntryState.REASSIGNED_IN_PROGRESS | 3 | 1  | 1

        PlannerEntryState.OBE                    | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.OBE                    | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.OBE                    | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.OBE                    | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.OBE                    | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.OBE                    | PlannerEntryState.REASSIGNED             | 2 | 1  | 1
        PlannerEntryState.OBE                    | PlannerEntryState.REASSIGNED_IN_PROGRESS | 3 | 1  | 1

        PlannerEntryState.GRADED                 | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.GRADED                 | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.GRADED                 | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.GRADED                 | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.GRADED                 | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.GRADED                 | PlannerEntryState.REASSIGNED             | 2 | 1  | 1
        PlannerEntryState.GRADED                 | PlannerEntryState.REASSIGNED_IN_PROGRESS | 3 | 1  | 1

        PlannerEntryState.COMPLETED              | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.COMPLETED              | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.COMPLETED              | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.COMPLETED              | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.COMPLETED              | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.COMPLETED              | PlannerEntryState.REASSIGNED             | 2 | 1  | 1
        PlannerEntryState.COMPLETED              | PlannerEntryState.REASSIGNED_IN_PROGRESS | 3 | 1  | 1

        PlannerEntryState.REASSIGNED             | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.REASSIGNED             | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.REASSIGNED             | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.REASSIGNED             | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.REASSIGNED             | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.REASSIGNED             | PlannerEntryState.REASSIGNED             | 1 | 1  | 1
        PlannerEntryState.REASSIGNED             | PlannerEntryState.REASSIGNED_IN_PROGRESS | 1 | 1  | 1

        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.NOT_STARTED            | 1 | 1  | 1
        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.IN_PROGRESS            | 1 | 1  | 1
		PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.OBE                    | 4 | 1  | 1
        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.GRADED                 | 1 | 1  | 1
        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.COMPLETED              | 1 | 1  | 1
        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.REASSIGNED             | 1 | 1  | 1
        PlannerEntryState.REASSIGNED_IN_PROGRESS | PlannerEntryState.REASSIGNED_IN_PROGRESS | 1 | 1  | 1
    }

    /**
     * SAT-1846
     * Kid drags assignment from Awaiting Grading or Completed list onto the canvas  - PUT /plannerentries slot from -1 to another slot.
     * The endpoint will validate that kid is still enrolled and class not COMPLETED.  When fails, will return HttpStatus.BAD_REQUEST
     * The student must be enrolled in the class to update a planner entry.
     * -OR-
     * Cannot update planner entries referencing a COMPLETED class.
     */
    @Unroll
    def "should NOT update planner entry when kid not enrolled or class COMPLETED"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)

        PlannerEntry existing = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: status,
                slot: -1
        ))

        def body = [
                "status" : status,
                "slot" : slot
        ]

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:
		assert resp.statusCode == expectedStatus
		if(resp.statusCode == HttpStatus.FORBIDDEN ){
			assert resp.body.errors[0].message == env.getProperty("student.plannerentry.status.invalid")
		}
		else if (resp.statusCode != HttpStatus.OK) {
			def expected = [errors:[[field: "class_uuid", message: "The student must be enrolled in the class to update a planner entry."]]]
			assert expected == resp.body
		}

		where:
		status                        | slot  | expectedStatus
		PlannerEntryState.COMPLETED   | 3     | HttpStatus.BAD_REQUEST
		PlannerEntryState.GRADED      | 3     | HttpStatus.BAD_REQUEST
		PlannerEntryState.IN_PROGRESS | 3     | HttpStatus.BAD_REQUEST
		PlannerEntryState.NOT_STARTED | 4     | HttpStatus.BAD_REQUEST
		PlannerEntryState.OBE         | 3     | HttpStatus.FORBIDDEN
		PlannerEntryState.NOT_STARTED | 2     | HttpStatus.BAD_REQUEST
		PlannerEntryState.IN_PROGRESS | 1      | HttpStatus.BAD_REQUEST

    }

    @Unroll
    def "should fail to update a planner entry if not the owner"() {
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)

        PlannerEntry existing = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        def body = [
                "status" : PlannerEntryState.GRADED.toString(),
                "slot" : 3
        ]

        String token = createToken(student2, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${existing.uuid}", HttpMethod.PATCH, req, Map)

        then:

        assert resp.statusCode == HttpStatus.BAD_REQUEST
    }


    def "should ignore extraneous fields when updating planner entry"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)
        createEnrollment(classObj, student1, Role.STUDENT)

        PlannerEntry entry = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        def body = [
                "status" : PlannerEntryState.GRADED.toString(),
                "slot" : 3,
                "user_uuid" : UUID.randomUUID()
        ]

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(body, headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${entry.uuid}", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.OK
        checkCreateUpdateResponse(entry, resp, 3, PlannerEntryState.GRADED, student1.uuid)
    }

    def "should get error when updating unknown planner entry"(){
        given:
        ClassObj classObj = setupValidClass(admin, school)
        PageObj page = setupValidPage(classObj)
        PageAssignment pageAssignment = setupValidPageAssignment("page assignment", page, 3)

        PlannerEntry entry = plannerEntryRepo.save(new PlannerEntry(
                user: student1,
                pageObj: page,
                classObj: classObj,
                assignment: pageAssignment.assignment,
                activityId: pageAssignment.uuid,
                status: PlannerEntryState.NOT_STARTED,
                slot: 1
        ))

        String token = createToken(student1, school.uuid)
        HttpHeaders headers = new HttpHeaders()
        headers.set("Authorization", "Bearer ${token}")
        headers.setContentType(Constants.PLANNER_ENTRIES_VERSION_1_MT)
        headers.setAccept([Constants.PLANNER_ENTRIES_VERSION_1_MT])
        HttpEntity req = new HttpEntity(headers)

        when:
        HttpEntity resp = testRestTemplate.exchange("/plannerentries/${UUID.randomUUID()}", HttpMethod.PATCH, req, Map)

        then:
        assert resp.statusCode == HttpStatus.BAD_REQUEST
        assert plannerEntryRepo.findAll().size() == 1
    }


    private void checkCreateUpdateResponse(PlannerEntry existing, HttpEntity resp, Integer expectedSlot, PlannerEntryState expectedState, UUID updatedByUUID) {
        PlannerEntry actual = plannerEntryRepo.findByUuid(existing.uuid)
        PageAssignment pageAssignment = pageAssignmentRepo.findByUuid(existing.activityId)
        assert actual != null
        assert actual.slot == expectedSlot
        assert actual.status == expectedState
        assert actual.user.uuid == existing.user.uuid
        assert actual.assignment.uuid == existing.assignment.uuid
        assert actual.classObj.uuid == existing.classObj.uuid
        assert actual.activityId == existing.activityId
        assert actual.pageObj.uuid == existing.pageObj.uuid
		assert actual.updatedBy == updatedByUUID
        def expectedPage = [
                "page_uuid" : actual.pageObj.uuid.toString(),
                "name" : actual.pageObj.name,
                "status" : actual.pageObj.status.toString(),
                "_links" : [
                        "self": ["href": "http://localhost:" + port + "/pages?filter=page_uuid='" + actual.pageObj.uuid.toString() + "'"]
                ]
        ]

        def expectedAssignment = [
                "assignment_uuid" : actual.assignment.uuid.toString(),
                "assignment_title" : pageAssignment.assignment.title,
                "assignment_type" : pageAssignment.assignment.type.toString(),
                "_links" : [
                        "self": ["href": cltBaseUri + "/nodes/" + pageAssignment.assignment.uuid.toString()]
                ]
        ]

        assert resp.body.planner_entry_uuid == actual.uuid.toString()
        assert resp.body.user_uuid == actual.user.uuid.toString()
        assert resp.body.page == expectedPage
        assert resp.body.class_uuid == actual.classObj.uuid.toString()
        assert resp.body.activity_id == actual.activityId.toString()
        assert resp.body.assignment == expectedAssignment
        assert resp.body.status == expectedState.toString()
        assert resp.body.slot == expectedSlot

    }
}
