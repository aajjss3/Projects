package com.glynlyon.kl.classroom.service

import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.AcademicSession
import com.glynlyon.kl.classroom.model.AcademicSessionType
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.repo.AcademicSessionRepo
import com.glynlyon.kl.classroom.repo.OrganizationRepo
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable

class AcademicSessionServiceIntegrationSpec extends BaseRestSpec{

    @Autowired
    AcademicSessionService academicSessionService

    @Autowired
    AcademicSessionRepo academicSessionRepo

    @Autowired
    OrganizationRepo organizationRepo

    Organization school, school2

    String token

    def setup() {
        school = new Organization(name: 'School', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())
        school2 = new Organization(name: 'School 2', type: OrganizationType.SCHOOL, originationId: 'Shard Test', created: new Date(), updated: new Date())

        organizationRepo.save(school)
        organizationRepo.save(school2)

        User admin =  new User(firstName: 'testAdmin1', lastName: 'adminLast', userName: 'testAdmin', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'SHARD 1', updated: new Date(), created: new Date())

        token = createToken(admin, school.uuid)
    }

    def "find() should return proper results for given params"() {
        given:
        AcademicSession academicSession1 = new AcademicSession(name: 'session1', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession1)
        AcademicSession academicSession2 = new AcademicSession(name: 'session2', type: AcademicSessionType.TERM, organizationUuid: school.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession2)
        AcademicSession academicSession3 = new AcademicSession(name: 'session2', type: AcademicSessionType.TERM, organizationUuid: school2.uuid, startDate: new Date(), endDate: new Date(), created: new Date(), updated: new Date())
        academicSessionRepo.save(academicSession3)

        Pageable pageable = new PageRequest(0, 10)
        Page<AcademicSession> academicSessions
        List<AcademicSession> results

        when: "organization_uuid exists"
        
        academicSessions = academicSessionService.findByOrganizationUuid(pageable, school.getUuid())
        results = academicSessions.getContent()

        then:
        assert results.size() == 2
        assert results[0].organizationUuid == school.getUuid()
        assert results[1].organizationUuid == school.getUuid()


        when: "no organization_uuid exists"
        academicSessions = academicSessionService.find(pageable, null, token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 2
        def sortedResults = results.collect().sort{ it.name }
        assert sortedResults[0].organizationUuid == school.uuid
        assert sortedResults[1].organizationUuid == school.uuid


        when: "filter test with =(Equals) operator"
        academicSessions = academicSessionService.find(pageable, "name='session1'", token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'session1'
        assert results[0].uuid == academicSession1.uuid


        when: "filter test with !=(Not Equals) operator"
        academicSessions = academicSessionService.find(pageable, "name!='session1'", token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 1
        assert results[0].uuid != academicSession3.uuid
        assert results[0].name != 'session1'


        when: "filter test with contains operators"
        academicSessions = academicSessionService.find(pageable, "namecontains'session2'", token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'session2'
        assert results[0].organizationUuid == school.uuid


        when: "filter test with AND operators"
        academicSessions = academicSessionService.find(pageable, "name='session2' AND organization_uuid='${school.uuid}'", token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'session2'
        assert results[0].organizationUuid == school.uuid


        when: "filter test with OR operators"
        academicSessions = academicSessionService.find(pageable, "filter=name='session1' OR name='session2'", token)
        results = academicSessions.getContent()
        sortedResults = results.collect().sort{ it.name }

        then:
        assert results.size() == 2
        assert sortedResults[0].name == 'session1'
        assert sortedResults[1].name == 'session2'


        when: "filter test with UUID"
        academicSessions = academicSessionService.find(pageable, "academic_session_uuid='${academicSession1.uuid}'", token)
        results = academicSessions.getContent()

        then:
        assert results.size() == 1
        assert results[0].name == 'session1'
        assert results[0].uuid == academicSession1.uuid        

    }
}
