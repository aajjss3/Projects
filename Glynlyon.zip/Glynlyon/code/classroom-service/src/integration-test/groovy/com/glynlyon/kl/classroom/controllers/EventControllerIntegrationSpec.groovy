package com.glynlyon.kl.classroom.controllers

import java.text.SimpleDateFormat
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import spock.lang.Unroll
import com.glynlyon.kl.classroom.BaseRestSpec
import com.glynlyon.kl.classroom.model.EventLoginLogout
import com.glynlyon.kl.classroom.model.Organization
import com.glynlyon.kl.classroom.model.User
import com.glynlyon.kl.classroom.model.OrganizationType
import com.glynlyon.kl.classroom.model.Role
import com.glynlyon.kl.classroom.model.AppUserStatus
import com.glynlyon.kl.classroom.model.AppUserType
import com.glynlyon.kl.classroom.util.Constants



class EventControllerIntegrationSpec extends BaseRestSpec{
	
	User user1, user2
	Organization school

	// user1
	public static GregorianCalendar loginTimeUser1 = new GregorianCalendar(2018, GregorianCalendar.JANUARY, 1, 1, 1, 1)
	public static GregorianCalendar logoutTimeUser1 = new GregorianCalendar(2018, GregorianCalendar.JANUARY, 1, 1, 2, 1)
	// user 1 a second time
	public static GregorianCalendar loginTimeUser1Again= new GregorianCalendar(2018, GregorianCalendar.JANUARY, 1, 2, 1, 1)
	public static GregorianCalendar logoutTimeUser1Again = new GregorianCalendar(2018, GregorianCalendar.JANUARY, 1, 3, 1, 1)
	// user2
	public static GregorianCalendar loginTimeUser2 = new GregorianCalendar(2018, GregorianCalendar.JANUARY, 2, 1, 1, 1)
	public static GregorianCalendar logoutTimeUser2 = new GregorianCalendar(2018, GregorianCalendar.JANUARY, 2, 1, 2, 1)
	
	def setup() {
		school = organizationRepo.save(new Organization(name: 'School', type: OrganizationType.SCHOOL, originationId: 'school1', created: new Date(), updated: new Date()))
		user1 = userRepo.save(new User(firstName: 'test', lastName: 'test', userName: 'test', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
		user2 = userRepo.save(new User(firstName: 'test2', lastName: 'test2', userName: 'test2', type: AppUserType.ADMIN, status: AppUserStatus.ACTIVE, originationId: 'test', updated: new Date(), created: new Date(), organizations: [school]))
	}
	
	@Unroll
	def "failed - input validation"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
			def body =  ["event": value, "time": new Date()]
			HttpEntity req = new HttpEntity(body, headers)
		
		when:
			HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)

		then:
			assert response.statusCode == expectedResponse
			assert response.body.errors[0].message == message

		where:
			value  	| expectedResponse			| 	message
			null   	| HttpStatus.BAD_REQUEST	|	"Not a valid type."
			"xxx"   | HttpStatus.BAD_REQUEST	|	"invalid input xxx"
	}
	
	@Unroll
	def "success and failure - valid and invalid time formats"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
			def body =  ["event": "loggedin", "time": value]
			HttpEntity req = new HttpEntity(body, headers)
		
		when:
			HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)

		then:
			assert response.statusCode == expectedResponse

		where:
			value  								| expectedResponse			
			"2016-10-17T17:00:00-07:00"   		| HttpStatus.OK	
			"2016xxx-10-17T17:00:00-07:00"   	| HttpStatus.BAD_REQUEST	
	}
	
	
	def "successful - login and logout by same user"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
		
		when:
			def body =  ["event": "loggedin", "time": loginTimeUser1]
			HttpEntity req = new HttpEntity(body, headers)
			HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)
			UUID eventID = UUID.fromString(response.body.event_id)
			EventLoginLogout event = eventRepo.findByUuid(eventID)

		then:
			assert response.statusCode == HttpStatus.OK
			assert event.loggedin == loginTimeUser1.getTime()
			assert event.loggedout == null
			assert event.userUUID == user1.uuid
			assert event.updatedAt == null
			assert event.updatedBy == null
			assert event.createdAt != null
			assert event.createdBy == user1.uuid
		
		when:
			body =  ["event": "loggedout", "time": logoutTimeUser1]
			req = new HttpEntity(body, headers)
			response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)
			UUID eventID2 = UUID.fromString(response.body.event_id)
			EventLoginLogout event2 = eventRepo.findByUuid(eventID2)

		then:
			assert response.statusCode == HttpStatus.OK
			assert event2.loggedout == logoutTimeUser1.getTime()
			assert event2.userUUID == user1.uuid
			assert event2.loggedin == loginTimeUser1.getTime()
			assert event2.updatedAt != null
			assert event2.updatedBy == user1.uuid
			assert event2.createdAt != null
			assert event2.createdBy == user1.uuid
			assert event2.uuid == event.uuid

	}
	
	
	def "successful - default to current time if no value for time passed in"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
			def body =  ["event": "loggedin", "time": null]
			HttpEntity req = new HttpEntity(body, headers)
		
		when:
			HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)
			UUID eventID = UUID.fromString(response.body.event_id)
			EventLoginLogout event = eventRepo.findByUuid(eventID)

		then:
			assert response.statusCode == HttpStatus.OK
			assert event.loggedin != null && event.loggedin <= new Date()

	}
	
	
	/**
	 * If a user logs out and the system cannot find a corresponding login record then create a new record for logout and only set the logout time.
	 */
	def "successful - create new logout record if no login record exists"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
			def body =  ["event": "loggedout", "time": logoutTimeUser1]
			HttpEntity req = new HttpEntity(body, headers)
		
		when:
			HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)
			UUID eventID = UUID.fromString(response.body.event_id)
			EventLoginLogout event = eventRepo.findByUuid(eventID)

		then:
			assert response.statusCode == HttpStatus.OK
			assert event.loggedout == logoutTimeUser1.getTime()
			assert event.userUUID == user1.uuid
			assert event.loggedin == null
			assert event.updatedAt == null
			assert event.updatedBy == null
			assert event.createdAt != null
			assert event.createdBy == user1.uuid
			assert event.uuid == event.uuid

	}
	
	
	/**
	 * user 1 logs in. user 2 logs in. user 2 logs out, then user 1 logs out. 
	 * There should be 2 records, each record with a value for login time and logout time.
	 */
	def "successful - logins and logouts by multiple users"(){
		
		given:
			// user1 
			HttpHeaders headers1 = new HttpHeaders()
			headers1.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers1.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers1.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
			
			// user2
			HttpHeaders headers2 = new HttpHeaders()
			headers2.set("Authorization", "Bearer ${createToken(user2, school.uuid)}")
			headers2.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers2.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
		
		when:
			// user1 logs in
			def body1 =  ["event": "loggedin", "time": loginTimeUser1]
			HttpEntity req1 = new HttpEntity(body1, headers1)
			HttpEntity response1 = testRestTemplate.exchange("/events", HttpMethod.POST, req1, Map)
			EventLoginLogout loginEvent1 = eventRepo.findByUuid(UUID.fromString(response1.body.event_id))
			
			// user2 logs in
			def body2 =  ["event": "loggedin", "time": loginTimeUser2]
			HttpEntity req2 = new HttpEntity(body2, headers2)
			HttpEntity response2 = testRestTemplate.exchange("/events", HttpMethod.POST, req2, Map)
			EventLoginLogout loginEvent2 = eventRepo.findByUuid(UUID.fromString(response2.body.event_id))

		then:
			assert response1.statusCode == HttpStatus.OK
			assert response2.statusCode == HttpStatus.OK
			assert loginEvent1.userUUID == user1.uuid
			assert loginEvent1.loggedin == loginTimeUser1.getTime()
			assert loginEvent2.userUUID == user2.uuid
			assert loginEvent2.loggedin == loginTimeUser2.getTime()
		
		when:
			// user2 - logs out (first before user1)
			body2 =  ["event": "loggedout", "time": logoutTimeUser2]
			req2 = new HttpEntity(body2, headers2)
			response2 = testRestTemplate.exchange("/events", HttpMethod.POST, req2, Map)
			EventLoginLogout logoutEvent2 = eventRepo.findByUuid(UUID.fromString(response2.body.event_id))
			
			// user1 logs out
			body1 =  ["event": "loggedout", "time": logoutTimeUser1]
			req1 = new HttpEntity(body1, headers1)
			response1 = testRestTemplate.exchange("/events", HttpMethod.POST, req1, Map)
			EventLoginLogout logoutEvent1 = eventRepo.findByUuid(UUID.fromString(response1.body.event_id))
			List events = eventRepo.findAll()
						
		then:
			assert events.size() == 2
			assert response1.statusCode == HttpStatus.OK
			assert response2.statusCode == HttpStatus.OK
			assert logoutEvent1.loggedout == logoutTimeUser1.getTime()
			assert logoutEvent1.userUUID == user1.uuid
			assert logoutEvent2.loggedout == logoutTimeUser2.getTime()
			assert logoutEvent2.userUUID == user2.uuid
			
	}
	

	/**
	 * The user logs in (does not log out) and then logs in again, and then logs out. 
	 * There should be 2 records inserted. the first record will have a login time but null for logout time.
	 * The secord record will have a login time and a logout time.
	 */
	def "successful - a user logs in, logs in again, and then logs out"(){
		
		given:
			HttpHeaders headers = new HttpHeaders()
			headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
			headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
			headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)
		
		when:
			def bodyLogin =  ["event": "loggedin", "time": loginTimeUser1]
			HttpEntity reqLogin = new HttpEntity(bodyLogin, headers)
			HttpEntity responseLogin = testRestTemplate.exchange("/events", HttpMethod.POST, reqLogin, Map)
			EventLoginLogout eventLogin = eventRepo.findByUuid(UUID.fromString(responseLogin.body.event_id))

		then:
			assert responseLogin.statusCode == HttpStatus.OK

		when:
			def bodyLoginAgain =  ["event": "loggedin", "time": loginTimeUser1Again]
			HttpEntity reqLoginAgain = new HttpEntity(bodyLoginAgain, headers)
			HttpEntity responseLoginAgain = testRestTemplate.exchange("/events", HttpMethod.POST, reqLoginAgain, Map)
			EventLoginLogout eventLoginAgain = eventRepo.findByUuid(UUID.fromString(responseLoginAgain.body.event_id))

		then:
			assert responseLoginAgain.statusCode == HttpStatus.OK
			
		when:
			def bodyLogout =  ["event": "loggedout", "time": logoutTimeUser1Again]
			HttpEntity reqLogout = new HttpEntity(bodyLogout, headers)
			HttpEntity responseLogout = testRestTemplate.exchange("/events", HttpMethod.POST, reqLogout, Map)
			EventLoginLogout eventLogout = eventRepo.findByUuid(UUID.fromString(responseLogout.body.event_id))

		then:
			assert responseLogout.statusCode == HttpStatus.OK
			assert eventLogout.loggedout == logoutTimeUser1Again.getTime()
			assert eventLogout.loggedin == loginTimeUser1Again.getTime()
			assert eventLogout.uuid == eventLoginAgain.uuid
			assert eventLogin.loggedin == loginTimeUser1.getTime()
			assert eventLogin.loggedout == null

	}

	def "when loggedin event is called then user last_logged_in_at is also updated"() {
		given:
		HttpHeaders headers = new HttpHeaders()
		headers.set("Authorization", "Bearer ${createToken(user1, school.uuid)}")
		headers.add(HttpHeaders.CONTENT_TYPE, Constants.EVENT_CONTENT_TYPE)
		headers.add(HttpHeaders.ACCEPT, Constants.EVENT_ACCEPT)

		when:
		def body = ["event": "loggedin", "time": loginTimeUser1]
		HttpEntity req = new HttpEntity(body, headers)
		HttpEntity response = testRestTemplate.exchange("/events", HttpMethod.POST, req, Map)
		UUID eventID = UUID.fromString(response.body.event_id)
		EventLoginLogout event = eventRepo.findByUuid(eventID)

		then:
		assert response.statusCode == HttpStatus.OK
		assert event.loggedin == loginTimeUser1.getTime()
		assert event.userUUID == user1.uuid
		assert userRepo.findByUuid(user1.uuid)?.lastLoggedInAt == loginTimeUser1.getTime()

	}

}
