package com.glynlyon.kl.classroom.util

import groovy.transform.ToString

/**
 * Created by etatarzycki on 3/8/17.
 */
@ToString
class ParsedLink {
    String rel=""
    int offset=0
    int limit=0

    public ParsedLink(String header){
        try {
            def parts = header.split(';')
            limit = Integer.parseInt(parts[0].split("limit=")[1].split("&")[0])
            offset = Integer.parseInt(parts[0].split("offset=")[1].split(">")[0])

            rel = parts[1].split('rel="')[1].split('"')[0]
        }catch(Throwable t){}
    }
}
