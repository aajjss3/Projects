package com.glynlyon.kl.gpa

import com.glynlyon.kl.gpa.util.enums.AppUserType
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import java.nio.charset.StandardCharsets
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.context.MessageSource
import org.springframework.core.env.Environment
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import java.util.UUID
import spock.lang.Specification
import org.springframework.http.MediaType
import com.glynlyon.kl.gpa.util.Constant


@SpringBootTest(classes = Application, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(["classpath:application-integration-test.properties", "classpath:ValidationMessages.properties", "classpath:messages.properties"])
@ContextConfiguration
abstract class BaseIntegretionTest extends Specification {

    @Autowired
    TestRestTemplate template
	
	@Autowired
	Environment env
	

    private String createToken(UUID userUUID, UUID orgUUID, AppUserType userType){
		String secretKey = env.getRequiredProperty("jwt.secret.key").trim()
        def glCustomInfo = [
                "sub_display_name" :"test, test",
                "role_in_issuer"  : userType,
                "school_uuid": orgUUID,
                "datasource" : "test"
        ]
        return Jwts.builder().setExpiration(new Date().plus(1)).setSubject(userUUID.toString()).claim("gl_custom", glCustomInfo).signWith(SignatureAlgorithm.HS256, secretKey.getBytes(StandardCharsets.UTF_8)).compact()
    }
	
	
	protected HttpEntity createHttpEntity(UUID userUUID, UUID orgUUID, AppUserType role, Map body, String contentType, String accept){
		String token = createToken(userUUID, orgUUID, role)
		HttpHeaders headers = new HttpHeaders()
		headers.set(Constant.AUTHORIZATION, "Bearer " + token)
		if( accept ){
			headers.setAccept( [new MediaType(accept.split("/")[0], accept.split("/")[1])] )
		}
		if( contentType ){	
			headers.setContentType( new MediaType(contentType.split("/")[0], contentType.split("/")[1]) )
		}	
		HttpEntity request = (body) ? new HttpEntity(body, headers) : new HttpEntity(headers)
		return request
	}
	
	protected HttpEntity createHttpEntity(UUID userUUID, UUID orgUUID, AppUserType role, String contentType, String accept){
		return createHttpEntity(userUUID, orgUUID, role, null, contentType, accept)
	}

}
