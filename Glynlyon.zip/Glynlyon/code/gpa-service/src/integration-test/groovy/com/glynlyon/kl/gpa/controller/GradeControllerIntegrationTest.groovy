package com.glynlyon.kl.gpa.controller

import com.glynlyon.kl.gpa.BaseIntegretionTest
import com.glynlyon.kl.gpa.util.Constant
import com.glynlyon.kl.gpa.util.enums.AppUserType
import org.springframework.http.HttpEntity
import org.springframework.http.HttpMethod
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import spock.lang.Unroll

class GradeControllerIntegrationTest extends BaseIntegretionTest{
	
	private static Map requestBody, requestBodyForPass, requestBodyForFail, requestAssignmentsBody
	
	def setup() {
		
		requestBody = [
			"questions": [ [ "id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 1, "max_score": 5, "type": "mcq" ] ],
			"settings": [ "threshold": 70 ],
			"learnosity": [  "session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41",  "client_domain": "localhost" ],
			"user_id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31"
		]
		
		requestBodyForPass = [
			"questions": [ [ "id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 4.2, "max_score": 5, "type": "mcq" ], [ "id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 3, "max_score": 5, "type": "mcq" ] ],
			"settings": [ "threshold": 70 ],
			"learnosity": [  "session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41",  "client_domain": "localhost" ],
			"user_id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31"
		]
		
		requestBodyForFail = [
			"questions": [ [ "id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 41, "max_score": 50, "type": "mcq" ], [ "id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 9, "max_score": 30, "type": "mcq" ] ],
			"settings": [ "threshold": 70 ],
			"learnosity": [  "session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41",  "client_domain": "localhost" ],
			"user_id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31"
		]
		
		requestAssignmentsBody = ["assignments":[["id": "1","students":[["score": 1, "max_score": 1],["score": 5,	"max_score": 6],["score": 3,"max_score": 7.5]]]]]
		
		
		
	}
	
	@Unroll
	def "PUT SCORE - validate all roles"(){
		given:
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), role, requestBody, Constant.SCORE_CONTENT_TYPE, Constant.SCORE_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == statusCode
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.BAD_REQUEST
			AppUserType.PARENT      			|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_CEM      		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_USER			|	HttpStatus.BAD_REQUEST
			AppUserType.STUDENT      			|	HttpStatus.OK
			AppUserType.TEACHER					|	HttpStatus.OK
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
	
	@Unroll
	def "PUT SCORE - validate pass and fail"(){
		given:
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, body, Constant.SCORE_CONTENT_TYPE, Constant.SCORE_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			assert response.body.score as Double == value
			assert response.body.state == status
			
		where:
			body			    |	status		| value
			requestBodyForPass	|	"PASSED"	| 0.72
			requestBodyForFail	|	"FAILED"	| 0.625
	}
	
	
	@Unroll
	def "PUT SCORE - input validation"() {
        Map requestBodyForValiation = [
                "questions" : questionValue,
                "settings"  : settingValue,
                "learnosity": learnosityValue,
                "user_id"   : "6FAB76CA-C78C-47B2-8ECF-1E376105AC31"
        ]
        HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, requestBodyForValiation, Constant.SCORE_CONTENT_TYPE, Constant.SCORE_ACCEPT)

        when:
        ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)

        then:
        assert response.statusCode == status
        if (errors) {
            assert response.body.errors.size() == errors.size()
            assert response.body.errors.containsAll(errors)
        }


        where:
        questionValue                                                                                   | settingValue        | learnosityValue                                                                      | status                 | errors
        null                                                                                            | null                | ["session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41", "client_domain": "localhost"] | HttpStatus.BAD_REQUEST | [[field: "questions", message: "Missing input field."], [field: "questions", message: "Missing input field."]]
        [["id": null, "score": null, "max_score": null, "type": null]]                                  | ["threshold": null] | ["session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41", "client_domain": "localhost"] | HttpStatus.BAD_REQUEST | [[field: "questions[1].id", message: "Missing input field."], [field: "questions[1].score", message: "Missing input field."], [field: "questions[1].max_score", message: "Missing input field."], [field: "settings.threshold", message: "Missing input field."]]
        [["id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 0, "max_score": 5, "type": "mcq"]]     | ["threshold": 70]   | null                                                                                 | HttpStatus.OK          | null
        [["id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 1, "max_score": 5, "type": "mcq"]]     | ["threshold": 70]   | ["session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41", "client_domain": null]        | HttpStatus.BAD_REQUEST | [[field: "learnosity.client_domain", message: "Missing input field."]]
        [["id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 1, "max_score": 5, "type": "mcq"]]     | ["threshold": 70]   | ["session_id": null, "client_domain": "localhost"]                                   | HttpStatus.BAD_REQUEST | [[field: "learnosity.session_id", message: "Missing input field."]]
        [["id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": "x", "max_score": "y", "type": "mcq"]] | ["threshold": "z"]  | ["session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41", "client_domain": "localhost"] | HttpStatus.BAD_REQUEST | [[field: "questions[1].score", message: "This field needs to be a number greater than or equal to zero."], [field: "questions[1].score", message: "This field needs to be a number greater than or equal to zero."], [field: "questions[1].score", message: "This field needs to be a number greater than or equal to zero."]]
        [["id": "6FAB76CA-C78C-47B2-8ECF-1E376105AC31", "score": 1, "max_score": 5, "type": "xxxx"]]    | ["threshold": 70]   | ["session_id": "A24E8516-97AD-4890-8BDA-F1C82850BD41", "client_domain": "localhost"] | HttpStatus.BAD_REQUEST | [[field: "questions[1].type", message: "Not a valid type."]]
    }
	
	
	@Unroll
	def "PUT ASSIGNMENT AVERAGE SCORE - validate all roles"(){
		given:
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), role, requestAssignmentsBody, Constant.ASSIGNMENT_CONTENT_TYPE, Constant.ASSIGNMENT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == statusCode
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.BAD_REQUEST
			AppUserType.PARENT      			|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_CEM      		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_USER			|	HttpStatus.BAD_REQUEST
			AppUserType.STUDENT      			|	HttpStatus.OK
			AppUserType.TEACHER					|	HttpStatus.OK
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
		
	@Unroll
	def "PUT ASSIGNMENT AVERAGE SCORE - successes and failures"(){
		given:
			requestAssignmentsBody = ["assignments":[ ["id": idValue,"students":[studentsValue] ],  ["id": "2","students":[["score": 1.5, "max_score": 3],["score": 1.5, "max_score": 3] ]] ] ]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, requestAssignmentsBody, Constant.ASSIGNMENT_CONTENT_TYPE, Constant.ASSIGNMENT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == status
			if( idValue ){
				assert response.body.assignments[0].id == "2"
				assert response.body.assignments[0].average_score == 0.5
				assert response.body.assignments[0].total_students == 2
			}
			if( field ){
				for( int inx = 0; inx < field.size(); inx++ ){
					assert field.contains(response.body.failures[inx].field)
					assert response.body.failures[inx].message == message
					if( idValue ){
						assert response.body.failures[inx].id == "1"
					}
				}
			}	
		where:
			test	|	idValue		|			studentsValue								|		field											|	 message															| status
				1	|	null		|	["score": 0, "max_score": null]						|	["id", "students[1].max_score"]						| "Missing input field."												|HttpStatus.OK
				2	|	"1"			|	["score": -1, "max_score": -1]						|	["students[1].score", "students[1].max_score"]		| "This field needs to be a number greater than or equal to zero."		|HttpStatus.OK
				3	|	"1"			|	["score": "xxx", "max_score": "xxx"]				|	["students[1].score", "students[1].max_score"]		| "This field needs to be a number greater than or equal to zero."		|HttpStatus.OK
				4	|	"1"			|	["score": 1, "max_score": 0]						|	null												| "The score is greater than zero but the max score is zero."			|HttpStatus.OK
	}
	
	
	@Unroll
	def "PUT ASSIGNMENT AVERAGE SCORE - validate decimal calculation with and without null value for score"(){
		given:
			requestAssignmentsBody = ["assignments":[ ["id": "1","students":[["score": scoreAssignment1, "max_score": maxScoreAssignment1],["score": 3,	"max_score": 6]]],  ["id": "2","students":[["score": scoreAssignment2, "max_score": maxScoreAssignment2],["score": 3,	"max_score": 6] ]] ]]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, requestAssignmentsBody, Constant.ASSIGNMENT_CONTENT_TYPE, Constant.ASSIGNMENT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			for( int inx= 0; inx < 2; inx++ ){
				if( response.body.assignments[inx].id == "1" ){
					assert response.body.assignments[inx].average_score == avgScoreAssignment1
					assert response.body.assignments[inx].total_students == numberStudentsAssignment1
					assert response.body.failures.size() == 0
				} 
				else if( response.body.assignments[inx].id == "2" ){
					assert response.body.assignments[inx].average_score == avgScoreAssignment2
					assert response.body.assignments[inx].total_students == numberStudentsAssignment2
					assert response.body.failures.size() == 0
				}
				else{
					assert false
				}
			}
		where:
			scoreAssignment1	| maxScoreAssignment1	| scoreAssignment2	| maxScoreAssignment2	| numberStudentsAssignment1	|	numberStudentsAssignment2	|	avgScoreAssignment1		| avgScoreAssignment2	
			    2				|		2				|	1.5				|	6.5					|		2					|		2						|	0.625					|	0.36
				null			|		2				|	null			|	6.5					|		1					|		1						|	0.5						|	0.5
	}
	
	
	@Unroll
	def "PUT STUDENT ASSIGNMENT SCORE - validate all roles"(){
		given:
		Map body = ["students": [["id": "student_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]]]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), role, body, Constant.STUDENT_CONTENT_TYPE, Constant.STUDENT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == statusCode
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.BAD_REQUEST
			AppUserType.PARENT      			|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_CEM      		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_USER			|	HttpStatus.BAD_REQUEST
			AppUserType.STUDENT      			|	HttpStatus.OK
			AppUserType.TEACHER					|	HttpStatus.OK
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
	
	@Unroll
	def "PUT STUDENT ASSIGNMENT SCORE - successes and failures"(){
		given:
			Map requestStudentsBody =[
				"students": [[	"id": "student_1","assignments": [[	"score": student_1_score_1,"max_score": student_1_max_score_1,"type": type],[	"score": student_1_score_2,"max_score": student_1_max_score_2,"type": "LESSON"],["score": 90,"max_score": 90,	"type": "PROJECT"],	["score": 50,"max_score": 75,"type": "PROJECT"	]
				],	"weights": student_1_WEIGHT],["id": "student_2","assignments": [["score": 30,"max_score": 80,"type": "LESSON"],	["score": student_2_score_1,"max_score": 70,"type": "LESSON"],[	"score": 50,"max_score": 100,"type": "PROJECT"],["score": 50,
				"max_score": 50,"type": "PROJECT"]],"weights": student_2_WEIGHT	]]]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, requestStudentsBody, Constant.STUDENT_CONTENT_TYPE, Constant.STUDENT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			switch (test) {
				// successful calculations that are weighted - non-null values for scores
				case 1:
				// successful calculations that are not weighted - non-null values for scores
				case 2:
				//  successful calculations that are weighted - null values for some score
				case 3:
				//  successful calculations that are not weighted - null values some for score
				case 4:
				// successful calculations. student_1 - max score of zero and score > max score. student_2 - weights of 0 and 100
				case 8:
				// successful calculations with non-integer scores
				case 5:
				// successful calculations - there are weight types that do not have a score associated with them. 
				case 10:
					assert response.body.students.size() == 2
					assert response.body.failures.size() == 0
					for(int inx=0; inx< 2; inx++){
						if( response.body.students[inx].id == "student_1"){
							assert response.body.students[inx].score_earned == student_1_score_earned
							assert response.body.students[inx].score_to_date == student_1_score_to_date
						}
						else if( response.body.students[inx].id == "student_2"){
							assert response.body.students[inx].score_earned == student_2_score_earned
							assert response.body.students[inx].score_to_date == student_2_score_to_date
						}
						else{
							assert false
						}
	
					}
					break
				// student_1 has failed input data validation and student_2 has successful calculations
				case 6:
					// successful calculations
					assert response.body.students.size() == 1
					assert response.body.students[0].id == "student_2"
					assert response.body.students[0].score_earned == student_2_score_earned
					assert response.body.students[0].score_to_date == student_2_score_to_date
					// data validation failures
					assert response.body.failures.size() == 3
					int numberErrors = 0
					for(int inx=0; inx< 3; inx++){
						assert response.body.failures[inx].id == "student_1"
						if( response.body.failures[inx].field.contains( "score" ) || response.body.failures[inx].field.contains( "max_score" ) ){
							numberErrors++
							assert response.body.failures[inx].message == "This field needs to be a number greater than or equal to zero."
						}
						if( response.body.failures[inx].field.contains( "type" )){
							numberErrors++
							assert response.body.failures[inx].message == "'XXX' is not a valid weight type."
						}
					}
					assert numberErrors == 3
					break	
					// failed input data validation
				case 7:
					assert response.body.students.size() == 0
					assert response.body.failures.size() == 3
					for(int inx=0; inx< 3; inx++){
						if( response.body.failures[inx].id == "student_1"){
							assert response.body.failures[inx].field == "weights"
							assert response.body.failures[inx].message == "The total entered (110.0) does not add up to 100"
						}
						else if( response.body.failures[inx].id == "student_2"){
							assert response.body.failures[inx].field == "weights"
							assert response.body.failures[inx].message =="The value (null) is not a valid number greater than zero." || response.body.failures[inx].message == "The total entered (0.0) does not add up to 100"
						}
						else{
							assert false
						}
					}
					break
				// failed input data validation negative value for weight	
				case 9:
					assert response.body.students.size() == 1
					assert response.body.students[0].id == "student_2"
					assert response.body.students[0].score_earned == student_2_score_earned
					assert response.body.students[0].score_to_date == student_2_score_to_date
					assert response.body.failures.size() == 1
					assert response.body.failures[0].id == "student_1"
					assert response.body.failures[0].message == "The value (-50) is not a valid number greater than zero."
					assert response.body.failures[0].field == "weights"
					break
			}		
		where:
			test	|	student_1_score_1	|	student_1_max_score_1	|	student_1_score_2		|	student_1_max_score_2	|	student_2_score_1	|	student_1_WEIGHT						| 	student_2_WEIGHT						|	type		|		student_1_score_earned		|	 student_1_score_to_date	|	student_2_score_earned		| student_2_score_to_date
			1		|60						|75							|60							|65							|0						|["LESSON": 40,"PROJECT": 60]				|["LESSON": 30,"PROJECT": 70]				|"LESSON"		|0.85194805194					|0.85194805194				|0.52666666669				|0.52666666669
			2		|60						|75							|60							|65							|0						|null										|null										|"LESSON"		|0.8524590164					|0.8524590164			|0.4333333333			|0.4333333333	
			3		|null					|75							|null						|65							|null					|["LESSON": 40,"PROJECT": 60]				|["LESSON": 40,"PROJECT": 60]				|"LESSON"		|0.8484848485					|0.5090909091				|0.55000000002							|0.48000000002
			4		|null					|75							|null						|65							|null					|null										|null										|"LESSON"		|0.8484848485					|0.4590163934			|0.5652173913				|0.4333333333
			5		|50.5					|75							|25.6						|65							|60.7					|["LESSON": 30,"PROJECT": 70]				|["LESSON": 30,"PROJECT": 70]				|"LESSON"		|0.7570108225214285					|0.7570108225214285				|0.6480666666899999				|0.6480666666899999
			6		|-60					|-75						|60							|65							|0						|["LESSON": 40,"PROJECT": 60]				|null										|"XXX"			|null								|null							|0.4333333333			|0.4333333333
			7		|60						|75							|60							|65							|0						|["LESSON": 40,"PROJECT": 70]				|["LESSON": null,"PROJECT": null]			|"LESSON"		|null								|null							|null							|null
			8		|60						|0							|60							|65							|0						|["LESSON": 30,"PROJECT": 70]				|["LESSON": 0,"PROJECT": 100]				|"LESSON"		|1.1477855478099999					|1.1477855478099999				|0.6666666667				|0.6666666667
			9		|60						|75							|60							|65							|0						|["LESSON": -50,"PROJECT": 150]				|null										|"LESSON"		|1.1477855478099999					|1.1477855478099999				|0.4333333333			|0.4333333333
			10		|30						|120						|70							|80							|60						|["LESSON": 35, "PROJECT": 44, "QUIZ": 21]	|["LESSON": 33, "PROJECT": 33, "QUIZ": 34]  |"LESSON"		|0.6940928270126583					|0.6940928270126583				|0.6333333333500001				|0.6333333333500001
	}

	
	@Unroll
	def "PUT UNIT ASSIGNMENT SCORE - validate all roles"(){
		given:
		Map body = ["units": [["id": "unit_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]]]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), role, body, Constant.UNIT_CONTENT_TYPE, Constant.UNIT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == statusCode
		where:
			role								| statusCode
			AppUserType.SUPPORT_ADMINISTRATOR	|	HttpStatus.BAD_REQUEST
			AppUserType.PARENT      			|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_CEM      		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_LICENSING		|	HttpStatus.BAD_REQUEST
			AppUserType.SUPPORT_USER			|	HttpStatus.BAD_REQUEST
			AppUserType.STUDENT      			|	HttpStatus.OK
			AppUserType.TEACHER					|	HttpStatus.OK
			AppUserType.ADMIN					|	HttpStatus.OK
	}
	
	
	@Unroll
	def "PUT UNIT ASSIGNMENT SCORE - successes and failures"(){
		given:
			Map requestStudentsBody =[
				"units": [[	"id": "unit_1","assignments": [[	"score": unit_1_score_1,"max_score": unit_1_max_score_1,"type": type],[	"score": unit_1_score_2,"max_score": unit_1_max_score_2,"type": "LESSON"],["score": 90,"max_score": 90,	"type": "PROJECT"],	["score": 50,"max_score": 75,"type": "PROJECT"	]
				],	"weights": unit_1_WEIGHT],["id": "unit_2","assignments": [["score": 30,"max_score": 80,"type": "LESSON"],	["score": unit_2_score_1,"max_score": 70,"type": "LESSON"],[	"score": 50,"max_score": 100,"type": "PROJECT"],["score": 50,
				"max_score": 50,"type": "PROJECT"]],"weights": unit_2_WEIGHT	]]]
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, requestStudentsBody, Constant.UNIT_CONTENT_TYPE, Constant.UNIT_ACCEPT)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == HttpStatus.OK
			switch (test) {
				// successful calculations that are weighted - non-null values for scores
				case 1:
				// successful calculations that are not weighted - non-null values for scores
				case 2:
				//  successful calculations that are weighted - null values for some score
				case 3:
				//  successful calculations that are not weighted - null values some for score
				case 4:
				// successful calculations. student_1 - max score of zero and score > max score. student_2 - weights of 0 and 100
				case 8:
				// successful calculations with non-integer scores
				case 5:
				// successful calculations - there are weight types that do not have a score associated with them.
				case 10:
					assert response.body.units.size() == 2
					assert response.body.failures.size() == 0
					for(int inx=0; inx< 2; inx++){
						if( response.body.units[inx].id == "unit_1"){
							assert response.body.units[inx].score_earned == unit_1_score_earned
							assert response.body.units[inx].score_to_date == unit_1_score_to_date
						}
						else if( response.body.units[inx].id == "unit_2"){
							assert response.body.units[inx].score_earned == unit_2_score_earned
							assert response.body.units[inx].score_to_date == unit_2_score_to_date
						}
						else{
							assert false
						}
	
					}
					break
				// student_1 has failed input data validation and student_2 has successful calculations
				case 6:
					// successful calculations
					assert response.body.units.size() == 1
					assert response.body.units[0].id == "unit_2"
					assert response.body.units[0].score_earned == unit_2_score_earned
					assert response.body.units[0].score_to_date == unit_2_score_to_date
					// data validation failures
					assert response.body.failures.size() == 3
					int numberErrors = 0
					for(int inx=0; inx< 3; inx++){
						assert response.body.failures[inx].id == "unit_1"
						if( response.body.failures[inx].field.contains( "score" ) || response.body.failures[inx].field.contains( "max_score" ) ){
							numberErrors++
							assert response.body.failures[inx].message == "This field needs to be a number greater than or equal to zero."
						}
						if( response.body.failures[inx].field.contains( "type" ) ){
							numberErrors++
							assert response.body.failures[inx].message == "'XXX' is not a valid weight type."
						}
					}
					assert numberErrors == 3
					break
					// failed input data validation
				case 7:
					assert response.body.units.size() == 0
					assert response.body.failures.size() == 3
					for(int inx=0; inx< 3; inx++){
						if( response.body.failures[inx].id == "unit_1"){
							assert response.body.failures[inx].field == "weights"
							assert response.body.failures[inx].message == "The total entered (110.0) does not add up to 100"
						}
						else if( response.body.failures[inx].id == "unit_2"){
							assert response.body.failures[inx].field == "weights"
							assert response.body.failures[inx].message =="The value (null) is not a valid number greater than zero." || response.body.failures[inx].message == "The total entered (0.0) does not add up to 100"
						}
						else{
							assert false
						}
					}
					break
				// failed input data validation negative value for weight
				case 9:
					assert response.body.units.size() == 1
					assert response.body.units[0].id == "unit_2"
					assert response.body.units[0].score_earned == unit_2_score_earned
					assert response.body.units[0].score_to_date == unit_2_score_to_date
					assert response.body.failures.size() == 1
					assert response.body.failures[0].id == "unit_1"
					assert response.body.failures[0].message == "The value (-50) is not a valid number greater than zero."
					assert response.body.failures[0].field == "weights"
					break
			}
		where:
			test	|	unit_1_score_1	|	unit_1_max_score_1	|	unit_1_score_2		|	unit_1_max_score_2	|	unit_2_score_1	|	unit_1_WEIGHT						| 	unit_2_WEIGHT						|	type		|		unit_1_score_earned		|	 unit_1_score_to_date	|	unit_2_score_earned		| unit_2_score_to_date
			1		|60						|75							|60							|65							|0						|["LESSON": 40,"PROJECT": 60]				|["LESSON": 30,"PROJECT": 70]				|"LESSON"		|0.85194805194					|0.85194805194				| 0.52666666669				| 0.52666666669
			2		|60						|75							|60							|65							|0						|null										|null										|"LESSON"		|0.8524590164				|0.8524590164			|0.4333333333			|0.4333333333
			3		|null					|75							|null						|65							|null					|["LESSON": 40,"PROJECT": 60]				|["LESSON": 40,"PROJECT": 60]				|"LESSON"		|0.8484848485					|0.5090909091				|0.55000000002							|0.48000000002
			4		|null					|75							|null						|65							|null					|null										|null										|"LESSON"		|0.8484848485					|0.4590163934			|0.5652173913				|0.4333333333
			5		|50.5					|75							|25.6						|65							|60.7					|["LESSON": 30,"PROJECT": 70]				|["LESSON": 30,"PROJECT": 70]				|"LESSON"		|0.7570108225214285					|0.7570108225214285				|0.6480666666899999				|0.6480666666899999
			6		|-60					|-75						|60							|65							|0						|["LESSON": 40,"PROJECT": 60]				|null										|"XXX"			|null								|null							|0.4333333333			|0.4333333333
			7		|60						|75							|60							|65							|0						|["LESSON": 40,"PROJECT": 70]				|["LESSON": null,"PROJECT": null]			|"LESSON"		|null								|null							|null							|null
			8		|60						|0							|60							|65							|0						|["LESSON": 30,"PROJECT": 70]				|["LESSON": 0,"PROJECT": 100]				|"LESSON"		|1.1477855478099999					|1.1477855478099999				|0.6666666667				|0.6666666667
			9		|60						|75							|60							|65							|0						|["LESSON": -50,"PROJECT": 150]				|null										|"LESSON"		|1.1477855478099999					|1.1477855478099999				|0.4333333333			|0.4333333333
			10		|30						|120						|70							|80							|60						|["LESSON": 35, "PROJECT": 44, "QUIZ": 21]	|["LESSON": 33, "PROJECT": 33, "QUIZ": 34]  |"LESSON"		|0.6940928270126583					|0.6940928270126583				|0.6333333333500001				|0.6333333333500001
	}
	
	@Unroll
	def "PUT UNIT and STUDENT ASSIGNMENT SCORE - validate the content type matches payload"(){
		given:
		Map body = input
			HttpEntity request = createHttpEntity(UUID.randomUUID(), UUID.randomUUID(), AppUserType.ADMIN, body, content, accept)
		when:
			ResponseEntity response = template.exchange("/scores", HttpMethod.PUT, request, Map)
		then:
			assert response.statusCode == statusCode
		where:
			input																																																|	content							|		accept					| statusCode
			["units": [["id": "unit_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]], "students": [["id": "student_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]]]	|	Constant.UNIT_CONTENT_TYPE		|	Constant.UNIT_ACCEPT		|	HttpStatus.BAD_REQUEST
			[ "students": [["id": "student_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]]]																								|	Constant.UNIT_CONTENT_TYPE		|	Constant.UNIT_ACCEPT		|	HttpStatus.NOT_ACCEPTABLE
			["units": [["id": "unit_1","assignments": [["score": 60,"max_score": 75,"type": "LESSON"]]]]]																										|	Constant.STUDENT_CONTENT_TYPE	|	Constant.STUDENT_ACCEPT		|	HttpStatus.NOT_ACCEPTABLE
	}
	
}
