package com.glynlyon.kl.gpa.service

import com.glynlyon.kl.gpa.dto.AssignmentDTO
import com.glynlyon.kl.gpa.dto.AssignmentScoreDTO
import com.glynlyon.kl.gpa.dto.AssignmentScoreWrapperDTO
import com.glynlyon.kl.gpa.dto.AssignmentWrapperDTO
import com.glynlyon.kl.gpa.dto.ErrorDTO
import com.glynlyon.kl.gpa.dto.FailureDTO
import com.glynlyon.kl.gpa.dto.GradeDTO
import com.glynlyon.kl.gpa.dto.QuestionDTO
import com.glynlyon.kl.gpa.dto.ScoreAndStateResultDTO
import com.glynlyon.kl.gpa.dto.ScoreDTO
import com.glynlyon.kl.gpa.dto.StudentUnitDTO
import com.glynlyon.kl.gpa.dto.StudentUnitScoreDTO
import com.glynlyon.kl.gpa.dto.StudentUnitScoreWrapperDTO
import com.glynlyon.kl.gpa.dto.StudentUnitWrapperDTO
import com.glynlyon.kl.gpa.dto.WeightedScoreDTO
import com.glynlyon.kl.gpa.util.enums.StatusType
import org.springframework.stereotype.Service
import com.glynlyon.kl.gpa.exception.BadRequestException
import com.glynlyon.kl.gpa.exception.NotAcceptableException


@Service
class GradingService extends AbstractService{
	

	/**
	 * Calculate an overall score
	 *
	 * @param gradeDTO
	 * @return ScoreDTO
	 */
	public static ScoreAndStateResultDTO calculateScore(GradeDTO gradeDTO) {
        BigDecimal maxScore = (BigDecimal) gradeDTO.questions.sum { QuestionDTO it -> it.maxScoreAsBigDecimal }
        BigDecimal score = (BigDecimal) gradeDTO.questions.sum { QuestionDTO it -> it.scoreAsBigDecimal }

        BigDecimal avgScore = 0.0
        if (maxScore > 0) {
            avgScore = (score / maxScore)
        }
        StatusType status = (avgScore * 100 >= gradeDTO.setting.thresholdAsInteger) ? StatusType.PASSED : StatusType.FAILED

        return new ScoreAndStateResultDTO(score: avgScore, state: status)
    }
	
	/**
	 * Calculate the average score for all students per assignment.
	 * This will aggregate and return all successful calculations and failed calculations due to failed input data validation.
	 * 
	 * @param assignment - AssignmentWrapperDTO
	 * @return AssignmentScoreWrapperDTO
	 */
	public AssignmentScoreWrapperDTO calculateAssignmentScore(AssignmentWrapperDTO assignmentWrapperDTO){

		AssignmentScoreWrapperDTO assignmentScoreWrapperDTO = new AssignmentScoreWrapperDTO()
		List<AssignmentScoreDTO> assignmentScoreDTOs = new ArrayList<AssignmentScoreDTO>()
		assignmentScoreWrapperDTO.setAssignments(assignmentScoreDTOs)
		List<FailureDTO> failureDTOs = new ArrayList<FailureDTO>()
		assignmentScoreWrapperDTO.setFailures( failureDTOs )

		List<AssignmentDTO> assignments = assignmentWrapperDTO.assignments

		for( AssignmentDTO assignment : assignments ){
			// data validation failures
			List<ErrorDTO> errors = validate( assignment )
			if( errors ){
				for( ErrorDTO error : errors ){
					failureDTOs.add( new FailureDTO(assignment.id, error.field, error.message) )
				}	
			}
			// no data validation failures
			else{
				BigDecimal score = 0.0
				BigDecimal maxScore = 0.0
				int numberStudents = 0
				for(ScoreDTO student : assignment.students){
					if (student.score){
						score = score + student.scoreAsDouble
						maxScore = maxScore + student.maxScoreAsDouble
						numberStudents++
					}
				}
				if( score > 0.0 && maxScore == 0.0 ){
					failureDTOs.add( new FailureDTO(assignment.id, "The score is greater than zero but the max score is zero.") )
				}
				else{
					AssignmentScoreDTO assignmentScoreDTO = new AssignmentScoreDTO()
					BigDecimal avgScore = (score == 0 && maxScore == 0 ) ? 0D : score/maxScore
					assignmentScoreDTO.setAverageScore( avgScore )
					assignmentScoreDTO.setTotalStudents( numberStudents )
					assignmentScoreDTO.setId( assignment.id )
					assignmentScoreDTOs.add( assignmentScoreDTO )
				}	
			}	
			
		}
		
		return assignmentScoreWrapperDTO
	}
	
	
	/**
	 * For either students or units...
	 * Calculate an aggregate assignment earned score and an aggregate assignment score to date.
	 * Calculate these aggregate scores for each student or unit passed in. 
	 * 
	 * @param studentUnitWrapperDTO - StudentUnitWrapperDTO - contains a collection of students or units. each student/unit contains a collection of assignment scores.
	 * @param isStudent - boolean indicating if the calculations are for students
	 * @param isUnit - boolean indication if the calculation are for units
	 * @return StudentUnitScoreWrapperDTO
	 */
	public StudentUnitScoreWrapperDTO calculateStudentOrUnitScore( StudentUnitWrapperDTO studentUnitWrapperDTO, boolean isStudent, boolean isUnit){
		
		StudentUnitScoreWrapperDTO studentUnitScoreWrapperDTO = new StudentUnitScoreWrapperDTO()
		List<FailureDTO> failureDTOs = new ArrayList<FailureDTO>()
		studentUnitScoreWrapperDTO.setFailures( failureDTOs )
		List<StudentUnitScoreDTO> scores = new ArrayList<StudentUnitScoreDTO>()
		
		List<StudentUnitDTO> students = studentUnitWrapperDTO.getStudents()
		List<StudentUnitDTO> units = studentUnitWrapperDTO.getUnits()
		
		if( units && students ){
			throw new BadRequestException("The request should not contain both students and units.")
		}
		else if ( ( isStudent && units ) || ( isUnit && students ) ){
			throw new NotAcceptableException("The content-type does not match the payload.")
		}
		else if ( isStudent && students ){
			studentUnitScoreWrapperDTO.students = scores
			for( StudentUnitDTO student : students ){
				calculate( failureDTOs, scores, student )
			}
		}
		else if ( isUnit && units ){
			studentUnitScoreWrapperDTO.units = scores
			for( StudentUnitDTO unit : units ){
				calculate( failureDTOs, scores, unit )
			}
		}
					
		return studentUnitScoreWrapperDTO
		
	}	
	
	
	/**
	 * calculate the max score and score to date for the student/unit passed in. 
	 * the score to date assumes that if a score isn't answered (ie null), its calculated as if the score was 0.
	 * the earned score assumes that if a score isn't answered (ie null), then the score (and its corresponding max score) is removed and not considered from its calculation.
	 * 
	 * @param failureDTOs
	 * @param scores
	 * @param studentUnitDTO
	 */
	private void calculate( List<FailureDTO> failureDTOs, List<StudentUnitScoreDTO> scores, StudentUnitDTO studentUnitDTO ){

		// get all the failed data validation errors
		List<FailureDTO> errors = validateWithID( studentUnitDTO )
		if( errors ){
			failureDTOs.addAll( errors )
		}
		
		// if there are no failed data validations then calculate the earned score and score to date for the student/unit
		else{
			
			Map<String, Double> weights = studentUnitDTO.getWeightsAsDouble()
			List<WeightedScoreDTO> assignments = studentUnitDTO.assignments
			
			boolean calculatable = true
			BigDecimal scoreEarned = 0.0
			BigDecimal scoreToDate = 0.0
			
			// if the scores are weighted
			if( weights && !weights.isEmpty() ){

				// create a map to hold the weight type, score, max earned score, and max score to date. 
				// the key to the map is the weight type. the maps value is a AggregateScore object (which holds an aggregate of values for this weight type
				Map<String, AggregateScore> calculations = new HashMap<String, AggregateScore>()
				
				// the total weight to use for all weighted calculations. this will be the aggregate of all weight types that have a score associated with them. 
				BigDecimal totalWeight = 0
				
				for(WeightedScoreDTO assignment : assignments){
					String weightType = assignment.type
					AggregateScore aggregateScore = calculations.get(weightType)
					if( aggregateScore ){
						// if at least one score is entered for a given weight type, then set aggregateScore.scoreEntered to true
						if( assignment.score ){
							aggregateScore.scoreEntered = true
						}
						
						aggregateScore.score = (assignment.score) ? aggregateScore.score + assignment.scoreAsDouble : aggregateScore.score
						// NOTE: the aggregate maxEarnedScore depends on whether the 'score' is null
						aggregateScore.maxEarnedScore =  (assignment.score) ? aggregateScore.maxEarnedScore + assignment.maxScoreAsDouble : aggregateScore.maxEarnedScore
						aggregateScore.maxScoreToDate += assignment.maxScoreAsDouble
					}
					else{
						aggregateScore = new AggregateScore()
						// if at least one score is entered for a given weight type, then set aggregateScore.scoreEntered to true
						if( assignment.score ){
							aggregateScore.scoreEntered = true
						}
						// since this weight type has not been encountered up to now, add it to the totalWeight variable. 
						totalWeight += weights.get(assignment.type)
						aggregateScore.score = (assignment.score) ? assignment.scoreAsDouble : 0
						// NOTE: the aggregate maxEarnedScore depends on whether the 'score' is null
						aggregateScore.maxEarnedScore =  (assignment.score) ? assignment.maxScoreAsDouble : 0
						aggregateScore.maxScoreToDate = assignment.maxScoreAsDouble
						calculations.put(weightType, aggregateScore)
					}
				}
								
				BigDecimal adjustedTotalWeight = totalWeight 
				// calculate the ratio of score to max score for each weight type
				calculations.each{ k, v ->
					if( v.score > 0.0 && ( v.maxEarnedScore == 0.0 || v.maxScoreToDate == 0.0 ) ){
						calculatable = false
						failureDTOs.add( new FailureDTO(studentUnitDTO.id, "The score is greater than zero but the max score is zero.") )
					}
					else{
						// if no score is entered for a weight type (i.e. all scores are null for a given weight type) then do not include that weight type in the overall calculation of 'earned score' by excluding it from the total weight.
						if( !v.scoreEntered ){
							adjustedTotalWeight -= weights.get(k)
						}
						
						// calculate score earned.
						if(v.maxEarnedScore > 0.0){
							scoreEarned += (v.score/v.maxEarnedScore)*weights.get(k)
						}
						
						// calculate score to date
						if(v.maxScoreToDate > 0.0){
							scoreToDate += (v.score/v.maxScoreToDate)*weights.get(k)
						}	
					}	
				}
				
				if( calculatable ){
					scoreEarned = (scoreEarned == 0.0 || Double.valueOf(scoreEarned.doubleValue()).isNaN()) ?  0.0 : scoreEarned/adjustedTotalWeight
					scoreToDate = (scoreToDate == 0.0 || Double.valueOf(scoreToDate.doubleValue()).isNaN()) ?  0.0 : scoreToDate/totalWeight
				}
			}
			
			// if the scores are not weighted, do a straight average of scores/maxScores
			else{
				
				BigDecimal score = 0.0
				for(WeightedScoreDTO assignment : assignments){
					scoreToDate += assignment.maxScoreAsDouble
					if( assignment.score ){
						score += assignment.scoreAsDouble
						scoreEarned += assignment.maxScoreAsDouble
					}
				}
				
				if( score > 0.0 && ( scoreToDate == 0.0 || scoreEarned == 0.0 ) ){
					calculatable = false
					failureDTOs.add( new FailureDTO(studentUnitDTO.id, "The score is greater than zero but the max score is zero.") )
				}
				
				if( calculatable ){
					
					scoreEarned = (score != 0.0) ? score/scoreEarned : 0.0
					scoreToDate = (score != 0.0) ? score/scoreToDate : 0.0
				}
				
			}
			
			// if no failures, then calculate the earned score and score to date and add to a dto of successful calculations.
			if( calculatable ){
				StudentUnitScoreDTO studentUnitScoreDTO = new StudentUnitScoreDTO()
				studentUnitScoreDTO.id = studentUnitDTO.id
				studentUnitScoreDTO.scoreEarned = scoreEarned
				studentUnitScoreDTO.scoreToDate = scoreToDate
				scores.add( studentUnitScoreDTO )
			}
			
		}
	
	}	
		
}


/**
 * Bucked that contains an aggregate of: score, max earned score, max score to date, and whether a score was entered. This is used to keep a running total of these values per weight type. 
 * The 'scoreEntered' variable is used to determine if at least one score exists for a given weight type (i.e. if at least one score exists that isn't null for a given weight type) 
 * If the scores are weighted, then the score earned calculation depends on whether or not all scores are null for a particular weight type, but the score to date does not depend on it.  
 * 
 */
class AggregateScore{
	public boolean scoreEntered
	public BigDecimal score
	public BigDecimal maxEarnedScore
	public BigDecimal maxScoreToDate
}

