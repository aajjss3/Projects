package com.glynlyon.kl.gpa.validator

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target

import javax.validation.Constraint
import javax.validation.Payload

import com.glynlyon.kl.gpa.validator.constraint.CustomEnumValidator


/**
 * only allow a value if its a valid custom enum (ex. QuestionType.class).
 * The enum type/class is stored in the variable enumType.
 *
 */
@Target([ElementType.FIELD, ElementType.TYPE, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CustomEnumValidator.class)
@Documented
@Inherited
public @interface CustomEnum {
	Class enumType()  // custom variable that contains the enum class
	String message() default "not a valid role"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
