package com.glynlyon.kl.gpa.dto

import java.util.List

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.annotation.JsonInclude.Include

public class StudentUnitScoreWrapperDTO  extends AbstractFailureDTO{
	
	@JsonInclude(Include.NON_NULL)
	List<StudentUnitScoreDTO> units
	
	@JsonInclude(Include.NON_NULL)
	List<StudentUnitScoreDTO> students

	public List<StudentUnitScoreDTO> getUnits() {
		return units;
	}
	public void setUnits(List<StudentUnitScoreDTO> units) {
		this.units = units;
	}
	public List<StudentUnitScoreDTO> getStudents() {
		return students;
	}
	public void setStudents(List<StudentUnitScoreDTO> students) {
		this.students = students;
	}
	
}


class StudentUnitScoreDTO{
	String id
	
	@JsonProperty(value="score_earned")
	Double scoreEarned
	
	@JsonProperty(value="score_to_date")
	Double scoreToDate

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Double getScoreEarned() {
		return scoreEarned;
	}
	public void setScoreEarned(Double scoreEarned) {
		this.scoreEarned = scoreEarned;
	}
	public Double getScoreToDate() {
		return scoreToDate;
	}
	public void setScoreToDate(Double scoreToDate) {
		this.scoreToDate = scoreToDate;
	}
		
}



