package com.glynlyon.kl.gpa.util

import org.springframework.validation.FieldError
import java.lang.reflect.Field
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Type
//import java.lang.reflect.TypeVariable
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.gpa.dto.ErrorDTO


/**
 * Utility class that uses Java Reflection to obtain class, method and field information.
 *
 */
class JSONFieldNameUtil {
	
	
	/**
	 * Populate a collection of ErrorDTO objects with errors that are found in the 'fieldErrors' collection passed in. each ErrorDTO has a field and message. 
	 * The message is obtained from the 'fieldErrors' object.
	 * The field is obtained using java reflection, and is the value used in the field's json annotation ( @JsonProperty ). 
	 * If the field does not have a json annotation, or the field type cannot be determined, then set the field as the dto field name (which is stored in the 'fieldErrors' object).  
	 * 
	 * @param fieldErrors - collection of errors
	 * @param rootClass - the root or parent class of all errors. 
	 * @return List<ErrorDTO> 
	 */
	public static List<ErrorDTO> setErrorsWithJsonName(List<FieldError> fieldErrors, Class rootClass){
		
		List<ErrorDTO> errors = new ArrayList<ErrorDTO>()
		
		for( FieldError fieldError : fieldErrors ){
			
			String fieldName =  fieldError.getField()
			String[] parts = fieldName.split("\\.")
			String errorFieldName = parts[parts.length-1] // the name of the dto field that errored-out
			String fieldNameToDisplay = errorFieldName // the name of the field to display to the caller. default to errorFieldName
			
			switch(parts.length){
				case 1: // field that errored out is at the top level
					// since this field is at the top level, there is no parent field and therefore no path
					Field field = retrieveFieldOnClass(rootClass, fieldName)
					if( field ){
						JsonProperty jsonProperty = field.getDeclaredAnnotation(JsonProperty.class)
						fieldNameToDisplay = ( jsonProperty ) ? jsonProperty.value() : fieldName
					}
					else{
						fieldNameToDisplay = fieldName
					}	
					break
				case 2: // field that errored out is nested 1 level deep
					String nestedFieldName = ( parts[0].contains("[") ) ? parts[0].split("\\[")[0] : parts[0]
					Field nestedField = retrieveFieldOnClass(rootClass, nestedFieldName)
					String nestedFieldToDisplay = JSONFieldNameUtil.retrieveJsonName(nestedField, errorFieldName)	
					
					//if the field is part of a collection get the array index
					String index = retrieveIndexFromFieldName(parts[0])
					
					// since the errored out field is one level deep, the parent is at the root level (ie the path is one level deep).
					// determine the path and field to display
					fieldNameToDisplay = retriveJsonNameOfPath(nestedFieldName, nestedField, null, index) + "." + nestedFieldToDisplay
					break
				default: // field that errored out is nested 2 or more levels deep
					Class parentClass = rootClass

					// traverse the nested object graph to get the Field for the error.
					String path // holds the complete path/context of the field excluding the field name
					for( int inx = 0; inx < parts.length; inx++ ){
						String nestedFieldName = ( parts[inx].contains("[") ) ? parts[inx].split("\\[")[0] : parts[inx]
						Field nestedField = retrieveFieldOnClass(parentClass, nestedFieldName)
						// if the field is part of a collection get the array index
						String index = retrieveIndexFromFieldName(parts[inx])

						// if reached the direct parent to the field then at the end of the chain
						if( inx == parts.length-2 ){
							// determine the field at the end of the chain
							String field = JSONFieldNameUtil.retrieveJsonName(nestedField, errorFieldName)
							// determine the path to the field
							path = retriveJsonNameOfPath(nestedFieldName, nestedField, path, index)
							fieldNameToDisplay = path + "." + field
							break
						}
						else{
							// determine the grandparent path
							path = retriveJsonNameOfPath(nestedFieldName, nestedField, path, index)
						}
						
						// if the field in the nested chain is a collection declared with generics
						if( nestedField.getGenericType() instanceof ParameterizedType ){
							ParameterizedType type = nestedField.getGenericType()
							parentClass = type.getActualTypeArguments()[0]
						}

						// if the field in the nested chain is a collection NOT declared with generics then cannot use reflection to determine the field class type
						else if( Collection.class.isAssignableFrom(nestedField.getType()) || Map.class.isAssignableFrom(nestedField.getType())){
							fieldNameToDisplay = errorFieldName // set display name to be the dto field name
							break
						}

						// if the field in the nested chain is a plain object.
						else{
							parentClass = nestedField.getType()
						}
					}
					break
			}
						
			ErrorDTO errorDTO = new ErrorDTO( fieldNameToDisplay, fieldError.getDefaultMessage() )
			errors.add(errorDTO)
	
		}
		
		return errors
		
	}	
	
	
	/**
	 * determine if the field is part of a collection and if so, return the collection array index as '[#]'. otherwise return null
	 * the index is incremented by 1 so that the initial index starts at 1 instead of 0
	 * @param fieldName
	 * @return
	 */
	private static String retrieveIndexFromFieldName(String fieldName){
		if(fieldName.contains("[") && fieldName.contains("]")){
			try{
				return "[" + (Integer.valueOf(fieldName.substring(fieldName.indexOf("[") + 1, fieldName.indexOf("]"))) + 1).toString() + "]"
			}
			catch(Exception e){
				return "[unknown]"
			}
		}
		else{
			return null
		}
	}
	
	
	/**
	 * Determine the json property name of the field passed in and append it to the currentPath that is also passed in.
	 * @param name - field name as string 
	 * @param field - field as Field object
	 * @param currentPath - current parent path as string
	 * @param index - if the field is part of a collection then this is the array index, otherwise its null
	 * @return
	 */
	private static String retriveJsonNameOfPath(String name, Field field, String currentPath, String index){
		JsonProperty jsonPropertyOfParentField = field.getDeclaredAnnotation(JsonProperty.class)
		String path = ( jsonPropertyOfParentField ) ? jsonPropertyOfParentField.value() : name
		path = index ? path + index : path
		return currentPath ? currentPath + "." + path : path
	}
	
		
	/**
	 * Retrieve and return the json properties value for the field passed in. 
	 * 
	 * @param parent - Field. the parent containing the field that errored-out
	 * @param errorFieldName - String. the name of the field that errored-out. 
	 * @return
	 */
	private static String retrieveJsonName( Field parent, String errorFieldName ){
		
		String fieldNameToDisplay = errorFieldName // the name of the field to display to the caller. default to errorFieldName
		if( parent ){
			Class fieldType = parent.getType()
			Type genericType = parent.getGenericType()
			
			// if a collection declared with java generics, then use reflection to determine the fields annotation.
			if( genericType instanceof ParameterizedType ){
				ParameterizedType parametizedType = (ParameterizedType)genericType
				Type[] fieldArgTypes = parametizedType.getActualTypeArguments()
				for(Type fieldArgType : fieldArgTypes){
					Field errorField = JSONFieldNameUtil.retrieveFieldOnClass( (Class)fieldArgType, errorFieldName )
					if( errorField ){
						JsonProperty jsonProperty = errorField.getDeclaredAnnotation(JsonProperty.class)
						fieldNameToDisplay = ( jsonProperty ) ? jsonProperty.value() : errorFieldName
					}
					else{
						fieldNameToDisplay = errorFieldName
					}	
				}
			}
			
			// if a collection that is not declared with java generics then cannot use reflection to determine the fields annotation.
			else if( Collection.class.isAssignableFrom(fieldType) || Map.class.isAssignableFrom(fieldType) ){
				fieldNameToDisplay = errorFieldName
			}
			
			// if a single object or primitive (ex. String, Date, int, Integer, etc), then use reflection to determine the fields annotation
			else{
				//Field errorField = fieldType.getDeclaredField(errorFieldName)
				Field errorField = retrieveFieldOnClass(fieldType, errorFieldName)
				if( errorField ){
					JsonProperty jsonProperty = errorField.getDeclaredAnnotation(JsonProperty.class)
					fieldNameToDisplay = ( jsonProperty ) ? jsonProperty.value() : errorFieldName
				}
				else{
					fieldNameToDisplay = errorFieldName
				}	
			}
		}
		return fieldNameToDisplay
	}
	
	
	/**
	 * Retrieve the Field object for the class and field name passed in.
	 * if the field is not found on the class then check to see if the field is on its parent. (ex. Child extends Parent)
	 * 
	 * @param clazz - Class
	 * @param field - String the name of the field
	 * @return
	 */
	private static Field retrieveFieldOnClass(Class clazz, String field){
		if (clazz != null) {
			try{
				Field errorField = clazz.getDeclaredField(field)
				return errorField
			}
			catch(NoSuchFieldException nsfe){
				retrieveFieldOnClass(clazz.getSuperclass(), field)
			}
		}
		else{
			return null
		}
	}
	

}
