package com.glynlyon.kl.gpa.dto.mapper

import org.modelmapper.ModelMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.stereotype.Component

/**
 * Wrapper class for the ModelMapper API. 
 * As per the ModelMapper API Javadoc, the ModelMapper object is thread safe and therefore a single ModelMapper object can be used for mappings. 
 * NOTE: a field name is considered the same even if one field is camel case and the other has underscores
 *
 */
@Component
class BaseMapper {
	
	// ModelMapper that maps all fields independent of the source value
	@Autowired
	@Qualifier("map-all-fields")
	protected ModelMapper mapperAll
	
	// ModelMapper that only maps fields that have a source value that is not null
	@Autowired
	@Qualifier("map-non-null-fields")
	protected ModelMapper mapperNonNulls
	

	/**
	 * ModelMapper that maps all fields
	 * @param obj - the JavaBean that contains state. 
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a populated object of type clazz
	 */
	public Object mapIncludingNullValue(Object object, Class clazz){
		return mapperAll.map(object, clazz)
	}
	
	/**
	 * ModelMapper that maps all fields from source to destination.
	 * @param source - the source JavaBean object.
	 * @param destination - the destination JavaBean object.
	 */
	public void mapIncludingNullValue(Object source, Object destination){
		mapperAll.map(source, destination)
	}
		
	/**
	 * ModelMapper that only maps fields whose source value is not null.
	 * @param obj - the JavaBean that contains state. 
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a populated object of type clazz
	 */
	public Object mapExcludingNullValue(Object object, Class clazz){
		return mapperNonNulls.map(object, clazz)
	}
	
	/**
	 * ModelMapper that only maps fields whose source value is not null from source to destination
	 * @param source - the source JavaBean object.
	 * @param destination - the destination JavaBean object.
	 */
	public Object mapExcludingNullValue(Object source, Object destination){
		mapperNonNulls.map(source, destination)
	}
	

	/** 
	* ModelMapper that maps all fields.
	* Migrate data between a List of Entities to a List of DTOs (and visa versa) if ALL the field names and data types between the 2 objects are identical.
	* NOTE: a field name is considered the same even if one field is camel case and the other has underscores
	*
	* @param obj - a List of JavaBeans that contains state.
	* @param clazz - the JavaBean class that will be instantiated and populated and returned.
	* @return a List of populated object of type clazz
	*/
	public List mapListIncludingNullValue(List objects, Class clazz){
		List list = new ArrayList()
		for( Object object : objects ){
			list.add( mapIncludingNullValue(object, clazz) )
		}
		return list
	}
	
	
	/**
	 * ModelMapper that only maps fields whose source value is not null.
	 * Migrate data between a List of Entities to a List of DTOs (and visa versa) if ALL the field names and data types between the 2 objects are identical.
	 * NOTE: a field name is considered the same even if one field is camel case and the other has underscores
	 *
	 * @param obj - a List of JavaBeans that contains state.
	 * @param clazz - the JavaBean class that will be instantiated and populated and returned.
	 * @return a List of populated object of type clazz
	 */
	public List mapListExcludingNullValue(List objects, Class clazz){
		List list = new ArrayList()
		for( Object object : objects ){
			list.add( mapExcludingNullValue(object, clazz) )
		}
		return list
	}
		
}
