package com.glynlyon.kl.gpa.dto

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.gpa.util.Constant
import com.glynlyon.kl.gpa.util.enums.QuestionType
import com.glynlyon.kl.gpa.validator.CustomEnum
import org.hibernate.validator.constraints.NotBlank

import javax.validation.Valid
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern

public class GradeDTO {
	
	@NotNull(message = "{input.field.required}")
	@Valid
	List<QuestionDTO> questions
	
	@NotNull(message = "{input.field.required}")
	@JsonProperty(value="settings")
	@Valid
	SettingDTO setting
	
	@Valid
	LearnosityDTO learnosity
	
	@JsonProperty(value="user_id")
	String userId


	public List<QuestionDTO> getQuestions() {
		return questions;
	}
	public void setQuestions(List<QuestionDTO> questions) {
		this.questions = questions;
	}
	public SettingDTO getSetting() {
		return setting;
	}
	public void setSetting(SettingDTO setting) {
		this.setting = setting;
	}
	public LearnosityDTO getLearnosity() {
		return learnosity;
	}
	public void setLearnosity(LearnosityDTO learnosity) {
		this.learnosity = learnosity;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}


class QuestionDTO{
	
	@NotNull(message = "{input.field.required}")
	String id
	
	@NotBlank(message = "{input.field.required}")
	@Pattern(regexp=Constant.DOUBLE_ZERO_OR_POS, message = "{input.field.double}")
	String score
	
	@NotBlank(message = "{input.field.required}")
	@Pattern(regexp=Constant.DOUBLE_ZERO_OR_POS, message = "{input.field.double}")
	@JsonProperty(value="max_score")
	String maxScore
	
	@CustomEnum( enumType = QuestionType.class, message = "{input.field.type}" )
	String type
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(String maxScore) {
		this.maxScore = maxScore;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	// helper method that returns type as an enum
	@JsonIgnore
	public QuestionType getTypeAsQuestionType() {
		return QuestionType.valueOf(this.type);
	}
	// helper method that sets type based on an enum
	@JsonIgnore
	public void setTypeAsQuestionType(QuestionType questionType) {
		this.type = questionType.name();
	}
	// helper method that returns score as an BigDecimal
	@JsonIgnore
	public BigDecimal getScoreAsBigDecimal(){
		return new BigDecimal(this.score)
	}
	// helper method that sets score as an BigDecimal
	@JsonIgnore
	public void setScoreAsBigDecimal(BigDecimal score){
		this.score = score.toString()
	}
	// helper method that returns maxScore as an BigDecimal
	@JsonIgnore
	public BigDecimal getMaxScoreAsBigDecimal(){
		return new BigDecimal(this.maxScore)
	}
	// helper method that sets maxScore as an BigDecimal
	@JsonIgnore
	public void setMaxScoreAsBigDecimal(BigDecimal maxScore){
		this.maxScore = maxScore.toString()
	}
	
}


class SettingDTO{
	
	@NotBlank(message = "{input.field.required}")
	@Pattern(regexp=Constant.INTEGER_ZERO_OR_POS, message = "{input.field.integer}")
	String threshold

	
	public String getThreshold() {
		return threshold;
	}
	public void setThreshold(String threshold) {
		this.threshold = threshold;
	}
	
	@JsonIgnore
	public Integer getThresholdAsInteger(){
		return Integer.valueOf(this.threshold)
	}
	
	@JsonIgnore
	public void setThresholdAsInteger(Integer threshold){
		this.threshold = threshold.toString()
	}
		
}


class LearnosityDTO{
	
	@NotBlank(message = "{input.field.required}")
	@JsonProperty(value="session_id")
	String sessionID
	
	@NotBlank(message = "{input.field.required}")
	@JsonProperty(value="client_domain")
	String clientDomain


	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	public String getClientDomain() {
		return clientDomain;
	}
	public void setClientDomain(String clientDomain) {
		this.clientDomain = clientDomain;
	}
	
}