package com.glynlyon.kl.gpa.validator.constraint

import java.util.List

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

import com.glynlyon.kl.gpa.validator.WeightType
import com.glynlyon.kl.gpa.dto.StudentUnitDTO
import com.glynlyon.kl.gpa.dto.WeightedScoreDTO
import com.google.gson.internal.LinkedHashTreeMap.KeySet


/**
 * Class level validation. 
 * validate that the weight types contained in the 'assignments' collection matches one of the weights passed in (passed in as a key to a map). 
 * If the weights map is empty, then weights are not used and there is no need to validate and return 'true'
 * 
 * Override the default constraint message handling with a custom data validation error message.
 * 
 * @author asparago
 *
 */
class WeightTypeValidator implements ConstraintValidator<WeightType, StudentUnitDTO>{

	
	@Override
	public void initialize(WeightType constraintAnnotation) {
	}

	@Override
	public boolean isValid(StudentUnitDTO dto, ConstraintValidatorContext context) {
		
		boolean success = true
		Map<String, String> weights = dto.weights
		if( weights && !weights.isEmpty() ){
			List<WeightedScoreDTO> assignments = dto.assignments
			Set<String> weightNames = weights.keySet()
			for(WeightedScoreDTO assignment : assignments ){
				String weight = assignment.type
				if( !weightNames.contains( weight )){
					success = false
					//disable default constraint violation (which gets message from annotation's message field)
					context.disableDefaultConstraintViolation()
					//build new custom message and add it to constraint violation. also set the field name. (needs to be a valid dto field name)
					 context.buildConstraintViolationWithTemplate("'" + weight + "' is not a valid weight type.").addPropertyNode("assignments").addPropertyNode("type").inIterable().atIndex(0).addConstraintViolation()
				}
			}	
		}	
		return success

	}
	
}
