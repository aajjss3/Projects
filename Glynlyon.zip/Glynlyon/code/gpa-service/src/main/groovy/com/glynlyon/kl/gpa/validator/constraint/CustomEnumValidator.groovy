package com.glynlyon.kl.gpa.validator.constraint

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.gpa.validator.CustomEnum


/**
 * Field level validation. 
 * validate that a value is a valid custom enum (ex. QuestionType.class).
 * The enum type/class to compared to is stored in the variable 'enumType'.
 *
 */
class CustomEnumValidator implements ConstraintValidator<CustomEnum, String>{

	// variable that contains the custom enum class
	private Class enumType
	
	@Override
	public void initialize(CustomEnum constraintAnnotation) {
		this.enumType = constraintAnnotation.enumType()
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (!value){
			return true
		}
		Enum[] enumerations = enumType.getEnumConstants()
		for (Enum enumeration : enumerations) {
			if (enumeration.name().equals(value)) {
				return true
			}
		}
		return false
	}

	
}
