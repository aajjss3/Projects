package com.glynlyon.kl.gpa.service

import java.io.ObjectInputStream.GetField
import java.lang.reflect.Field
import java.util.List

import org.hibernate.validator.internal.util.privilegedactions.SetAccessibility
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.BindingResult
import org.springframework.validation.DataBinder
import org.springframework.validation.FieldError
import org.springframework.validation.Validator

import com.glynlyon.kl.gpa.dto.AssignmentWrapperDTO
import com.glynlyon.kl.gpa.dto.ErrorDTO
import com.glynlyon.kl.gpa.util.JSONFieldNameUtil
import com.glynlyon.kl.gpa.dto.FailureDTO



public abstract class AbstractService {
	
	@Autowired
	private Validator validator
	
	/**
	 * This method is generic enough to accept any Object for validation. It will validate all fields including any nested fields, no matter how deep the nesting goes. 
	 * It will validate based on the Bean Validation spec's (namely, any field that is annotated with Bean Validation Annotation)
	 * 
	 * @param dto - any object to validate. it will validate all fields, no matter how deeply nested they are, as long as they are annotated with Bean Validation Annotation.
	 * @param filters - zero or more groups used to filter validation
	 * @return List<ErrorDTO> - collection of fields that failed validation - containing a field name and an error message. 
	 */
	protected List<ErrorDTO> validate( Object dto, Class... filters){
		DataBinder binder = new DataBinder(dto)
		binder.setValidator(validator)
		binder.validate(filters)
		BindingResult results = binder.getBindingResult()
		List<FieldError> fieldErrors = results.getFieldErrors()
		return JSONFieldNameUtil.setErrorsWithJsonName( fieldErrors, dto.getClass() )
	}
	
	
	/**
	 * This method REQUIRES the object that is passed in to contain a field called 'id'. This field MUST be present on the object, otherwise use the validate() method in this class. 
	 * This method is generic enough to accept any Object for validation. It will validate all fields including any nested fields, no matter how deep the nesting goes. 
	 * It will validate based on the Bean Validation spec's (namely, any field that is annotated with Bean Validation Annotation)
	 * 
	 * @param dto - any object to validate. the object is required to contain a field called 'id'. it will validate all fields, no matter how deeply nested they are, as long as they are annotated with Bean Validation Annotation.
	 * @param filters - zero or more groups used to filter validation
	 * @return List<FailureDTO> - collection of fields that failed validation - containing an id, field name and an error message.
	 */
	protected List<FailureDTO> validateWithID( Object dto, Class... filters ){
		List<FailureDTO> failures = new ArrayList<FailureDTO>()
		List<ErrorDTO> errors = validate( dto, filters )
		// use reflection to get the value for the field called 'id' and set it on the FailureDTO.id object that is returned. 
		Field field = dto.getClass().getDeclaredField("id")
		field.setAccessible(true) // required, since the field is not declared as public. otherwise, cannot get the fields value
		for( ErrorDTO error : errors ){
			failures.add( new FailureDTO( field.get(dto), error.field, error.message ) )
		}
		return failures
	}
	
}
