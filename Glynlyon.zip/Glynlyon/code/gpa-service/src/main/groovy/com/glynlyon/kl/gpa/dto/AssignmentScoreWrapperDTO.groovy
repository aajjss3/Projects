package com.glynlyon.kl.gpa.dto

import com.fasterxml.jackson.annotation.JsonProperty



public class AssignmentScoreWrapperDTO extends AbstractFailureDTO{
	
	List<ScoreAndStateResultDTO> assignments

	public List<AssignmentScoreDTO> getAssignments() {
		return assignments;
	}
	public void setAssignments(List<ScoreAndStateResultDTO> assignments) {
		this.assignments = assignments;
	}

}


class AssignmentScoreDTO{
	
	String id
	
	@JsonProperty(value="average_score")
	Double averageScore
	
	@JsonProperty(value="total_students")
	Integer totalStudents

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Double getAverageScore() {
		return averageScore;
	}
	public void setAverageScore(Double averageScore) {
		this.averageScore = averageScore;
	}
	public Integer getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(Integer totalStudents) {
		this.totalStudents = totalStudents;
	}
}
