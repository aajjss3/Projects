package com.glynlyon.kl.gpa.util.token

import javax.annotation.PostConstruct
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.env.Environment
import org.springframework.stereotype.Component
import io.jsonwebtoken.Jwts
import java.nio.charset.StandardCharsets
import io.jsonwebtoken.Claims
import com.glynlyon.kl.gpa.util.enums.AppUserType
import com.glynlyon.kl.gpa.util.token.Token


@Component
class TokenParser {
	
	private static String secret
	private static final int JWT_STARTING_INDEX = 7
	
	@Autowired
	Environment env

	@PostConstruct
	public init() throws Exception{
		secret = env.getRequiredProperty("jwt.secret.key").trim()
	}
	
	public static Token parse(String auth){
		Claims claims = Jwts.parser().setSigningKey(secret.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(auth.substring(JWT_STARTING_INDEX)).getBody()
		UUID orgUUID = UUID.fromString(claims.getSubject())
		UUID userUUID = UUID.fromString(claims.get('gl_custom').school_uuid)
		AppUserType role = claims.get('gl_custom').role_in_issuer.toUpperCase() as AppUserType
		return new Token(userUUID: userUUID, schoolUUID: orgUUID, role: role)
	}
	
}
