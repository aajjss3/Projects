package com.glynlyon.kl.gpa.dto

import javax.validation.constraints.Pattern

import org.hibernate.validator.constraints.NotBlank

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.gpa.util.Constant

public class ScoreDTO{
	
	@Pattern(regexp=Constant.DOUBLE_ZERO_OR_POS, message = "{input.field.double}")
	String score
	
	@NotBlank(message = "{input.field.required}")
	@Pattern(regexp=Constant.DOUBLE_ZERO_OR_POS, message = "{input.field.double}")
	@JsonProperty(value="max_score")
	String maxScore

	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getMaxScore() {
		return maxScore;
	}
	public void setMaxScore(String maxScore) {
		this.maxScore = maxScore;
	}
	// helper method that returns score as a Double
	@JsonIgnore
	public Double getScoreAsDouble(){
		return Double.valueOf(this.score)
	}
	// helper method that sets score as a Double
	@JsonIgnore
	public void setScoreAsDouble(Double score){
		this.score = score.toString()
	}
	// helper method that returns maxScore as a Double
	@JsonIgnore
	public Double getMaxScoreAsDouble(){
		return Double.valueOf(this.maxScore)
	}
	// helper method that sets maxScore as a Double
	@JsonIgnore
	public void setMaxScoreAsDouble(Double maxScore){
		this.maxScore = maxScore.toString()
	}
}

