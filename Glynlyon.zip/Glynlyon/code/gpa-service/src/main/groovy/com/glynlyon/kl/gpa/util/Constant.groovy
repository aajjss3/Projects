package com.glynlyon.kl.gpa.util

class Constant {
	
	// HTTP Accept and Content Type constants
	public static final String AUTHORIZATION = "Authorization"
	public static final String SCORE_ACCEPT = "application/vnd.attempts.scores.states.v1+json"
	public static final String SCORE_CONTENT_TYPE = "application/vnd.attempts.v1+json"
	public static final String ASSIGNMENT_ACCEPT = "application/vnd.assignments.average_score.v1+json"
	public static final String ASSIGNMENT_CONTENT_TYPE = "application/vnd.assignments.students.scores.v1+json"
	public static final String STUDENT_ACCEPT = "application/vnd.students.scores.v1+json"
	public static final String STUDENT_CONTENT_TYPE = "application/vnd.students.assignments.scores.v1+json"
	public static final String UNIT_ACCEPT = "application/vnd.units.scores.v1+json"
	public static final String UNIT_CONTENT_TYPE = "application/vnd.units.assignments.scores.v1+json"
	
	
	// regular expression constants
	public static final String DOUBLE_ZERO_OR_POS = '(\\d+(?:\\.\\d+)?)'
	public static final String INTEGER_ZERO_OR_POS = '^[0-9]\\d*$'


}
