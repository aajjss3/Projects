package com.glynlyon.kl.gpa.exception

import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.http.HttpStatus
import org.apache.logging.log4j.Level

/**
 * Exception to throw when a Http Status NOT FOUND (404) is desired.
 * @see CustomException for furthur documentation
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
class NotFoundException extends CustomException{

	public NotFoundException(String message){
		super(message)
	}

	public NotFoundException(String message, String field){
		super(message, field)
	}
		
	public NotFoundException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public NotFoundException(String message, String field, Level logLevel){
		super(message, field, logLevel)
	}

	public NotFoundException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
	
	public NotFoundException(String message, String field, Level logLevel, Throwable rootCause){
		super(message, field, logLevel, rootCause)
	}

}