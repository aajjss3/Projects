package com.glynlyon.kl.gpa.dto

import java.util.List
import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonInclude.Include


public class FailureDTO {
	
	String id
	@JsonInclude(Include.NON_NULL)
	String field
	String message
	
	public FailureDTO(String id, String field, String message){
		this.id = id
		this.field = field
		this.message = message
	}
	public FailureDTO(String id, String message){
		this.id = id
		this.message = message
		this.field = null
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
		
}
