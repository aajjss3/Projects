package com.glynlyon.kl.gpa.config


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean


/**
 * NOTE: Hibernate Validator is expected to be present in the classpath and will be detected automatically
 * LocalValidatorFactoryBean implements both javax.validation.ValidatorFactory and javax.validation.Validator and Spring�s org.springframework.validation.Validator.
 * You may inject a reference to either of these interfaces into beans that need to invoke validation logic
 *
 */
@Configuration
class ValidationConfig {
	
	@Bean
	public javax.validation.Validator validator() {
		return new LocalValidatorFactoryBean();
	}
	

}
