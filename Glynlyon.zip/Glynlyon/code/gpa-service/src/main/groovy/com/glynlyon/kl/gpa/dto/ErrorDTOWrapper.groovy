package com.glynlyon.kl.gpa.dto

import java.util.List


public class ErrorDTOWrapper { 
	
	List<ErrorDTO> errors = new ArrayList<ErrorDTO>()
	
 	public ErrorDTOWrapper(List<ErrorDTO> errors){
		super()
		this.errors.addAll( errors )
	}
	public ErrorDTOWrapper(ErrorDTO error){
		super()
		this.errors.add( error )
	}
	public List<ErrorDTO> getErrors() {
		return errors;
	}
	public void setErrors(List<ErrorDTO> errors) {
		this.errors = errors;
	}
			
}


class ErrorDTO {
	
	String field
	String message
	
	public ErrorDTO(String field, String message){
		this.field = field
		this.message = message
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
			
}
