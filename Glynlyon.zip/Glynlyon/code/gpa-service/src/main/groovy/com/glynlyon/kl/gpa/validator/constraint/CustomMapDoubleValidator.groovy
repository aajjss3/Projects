package com.glynlyon.kl.gpa.validator.constraint

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.gpa.validator.CustomMapDouble



/**
 * This annotation validates a map field using the following rules:
 * 1) the maps value is a valid Double equal to or greater than zero.
 * 2) the summation of the maps value of all the map entries equals 100.
 * 
 * Override the default constraint message handling with custom data validation error messages.
 * 
 * @author asparago
 *
 */
class CustomMapDoubleValidator implements ConstraintValidator<CustomMapDouble, Map<String, String>>{

	
	@Override
	public void initialize(CustomMapDouble constraintAnnotation) {
	}

	@Override
	public boolean isValid(Map<String, String> weight, ConstraintValidatorContext context) {
		boolean success = true
		Double summation = 0D
		
		weight.each{ k, v -> 
			try{
				Double number = Double.valueOf(v)
				summation += number
				if (number < 0 ){
					throw new NumberFormatException()
				}	
			}
			catch(Exception e){
				success = false
				//disable default constraint violation (which gets message from annotation's message field)
				context.disableDefaultConstraintViolation()
				//build new custom message and add it to constraint violation. use the default field name
				context.buildConstraintViolationWithTemplate("The value (" + v + ") is not a valid number greater than zero.").addConstraintViolation()
			}	
		}
		
		// if weights are entered, then verify the total weight is 100 or that they are both null
		if( weight && !weight.isEmpty() && summation != 100D ){
			success = false
			//disable default constraint violation (which gets message from annotation's message field)
			context.disableDefaultConstraintViolation()
			//build new custom message and add it to constraint violation. use the default field name
			context.buildConstraintViolationWithTemplate("The total entered (" + summation.toString() + ") does not add up to 100").addConstraintViolation()
		}
		
		return success
	}
	
}
