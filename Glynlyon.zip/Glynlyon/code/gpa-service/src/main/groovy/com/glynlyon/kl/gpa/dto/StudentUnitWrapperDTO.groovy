package com.glynlyon.kl.gpa.dto

import javax.validation.Valid
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern
import org.hibernate.validator.constraints.NotBlank
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.gpa.util.enums.QuestionType
import com.glynlyon.kl.gpa.validator.CustomEnum
import com.glynlyon.kl.gpa.validator.CustomMapDouble
import com.glynlyon.kl.gpa.validator.WeightType
import com.glynlyon.kl.gpa.util.Constant


public class StudentUnitWrapperDTO {
	
	@Valid
	List<StudentUnitDTO> units
	
	@Valid
	List<StudentUnitDTO> students
	public List<StudentUnitDTO> getUnits() {
		return units;
	}
	public void setUnits(List<StudentUnitDTO> units) {
		this.units = units;
	}
	public List<StudentUnitDTO> getStudents() {
		return students;
	}
	public void setStudents(List<StudentUnitDTO> students) {
		this.students = students;
	}
	
}

@WeightType(message="{input.weight.invalid}")
class StudentUnitDTO{
	
	@NotNull(message = "{input.field.required}")
	String id
	
	@Valid
	List<WeightedScoreDTO> assignments
	
	@CustomMapDouble(message = "{input.map.invalid}")
	Map<String, String> weights

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<WeightedScoreDTO> getAssignments() {
		return assignments;
	}
	public void setAssignments(List<WeightedScoreDTO> assignments) {
		this.assignments = assignments;
	}
	public Map<String, String> getWeights() {
		return weights;
	}
	public void setWeights(Map<String, String> weights) {
		this.weights = weights;
	}
	public Map<String, Double> getWeightsAsDouble(){
		Map<String, Double> maps = new HashMap<String, Double>()
		weights.each{ k,v ->
			maps.put(k, Double.valueOf(v))
		}
		return maps
	}
		
}



