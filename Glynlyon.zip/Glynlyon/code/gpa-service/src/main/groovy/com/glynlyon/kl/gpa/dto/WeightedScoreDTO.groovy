package com.glynlyon.kl.gpa.dto

import javax.validation.constraints.Pattern

import org.hibernate.validator.constraints.NotBlank

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.glynlyon.kl.gpa.util.Constant
import com.glynlyon.kl.gpa.validator.CustomEnum

public class WeightedScoreDTO extends ScoreDTO{
	
	String type
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}


