package com.glynlyon.kl.gpa.util.enums

public enum  StatusType {
	
	PASSED, FAILED

}
