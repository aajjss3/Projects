package com.glynlyon.kl.gpa.util.token

import com.glynlyon.kl.gpa.util.enums.AppUserType

class Token {
	public UUID userUUID
	public UUID schoolUUID
	public AppUserType role}
