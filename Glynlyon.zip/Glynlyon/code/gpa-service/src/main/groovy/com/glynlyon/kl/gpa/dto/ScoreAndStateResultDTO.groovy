package com.glynlyon.kl.gpa.dto

import com.glynlyon.kl.gpa.util.enums.StatusType

public class ScoreAndStateResultDTO {
	
	StatusType state
    BigDecimal score


	public StatusType getState() {
		return state;
	}
	public void setState(StatusType state) {
		this.state = state;
	}
	public BigDecimal getScore() {
		return score;
	}
	public void setScore(BigDecimal score) {
		this.score = score;
	}

}
