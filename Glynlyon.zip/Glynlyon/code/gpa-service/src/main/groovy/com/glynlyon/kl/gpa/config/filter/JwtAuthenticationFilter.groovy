package com.glynlyon.kl.gpa.config.filter

import java.io.IOException

import javax.servlet.Filter
import javax.servlet.FilterChain
import javax.servlet.FilterConfig
import javax.servlet.ServletException
import javax.servlet.ServletRequest
import javax.servlet.ServletResponse
import javax.servlet.annotation.WebFilter
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Configuration
import org.springframework.core.env.Environment
import org.springframework.http.HttpStatus
import org.springframework.web.filter.GenericFilterBean

import java.nio.charset.StandardCharsets

import io.jsonwebtoken.Jwts



/**
 * This filter is registered by spring when the application starts up. 
 * It authenticates all requests by checking for a valid token in the request header.
 * 
 *
 */
public class JwtAuthenticationFilter  extends GenericFilterBean {
	
	
    String jwtSecretKey

    JwtAuthenticationFilter(String jwtSecretKey) {
        this.jwtSecretKey = jwtSecretKey
    }

    @Override
    void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest request = req as HttpServletRequest
        HttpServletResponse response = res as HttpServletResponse

        if (request.getMethod() == "OPTIONS") {
            //this path shouldn't be filtered because it's needed to get the jwt
            chain.doFilter(req, res)
        } else {
            String authHeader = request.getHeader('Authorization')
            if (authHeader == null || !authHeader.startsWith('Bearer ')) {
                response.sendError(HttpStatus.UNAUTHORIZED.value(), 'Authorization header is missing or invalid')
                return
            }

            // The part after "Bearer " is the jwt
            final String token = authHeader.substring(7)
            
            try {
                Jwts.parser().setSigningKey(jwtSecretKey.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(token)
            }
            catch (Exception ignore) {
                response.sendError(HttpStatus.UNAUTHORIZED.value(), 'Invalid token')
                return
            }
            chain.doFilter(req, res)
        }
    }

}
