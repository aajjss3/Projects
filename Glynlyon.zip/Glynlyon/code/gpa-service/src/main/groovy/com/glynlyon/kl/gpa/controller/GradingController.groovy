package com.glynlyon.kl.gpa.controller

import com.glynlyon.kl.gpa.dto.AssignmentScoreWrapperDTO
import com.glynlyon.kl.gpa.dto.AssignmentWrapperDTO
import com.glynlyon.kl.gpa.dto.GradeDTO
import com.glynlyon.kl.gpa.dto.ScoreAndStateResultDTO
import com.glynlyon.kl.gpa.dto.StudentUnitScoreDTO
import com.glynlyon.kl.gpa.dto.StudentUnitScoreWrapperDTO
import com.glynlyon.kl.gpa.dto.StudentUnitWrapperDTO
import com.glynlyon.kl.gpa.service.GradingService
import com.glynlyon.kl.gpa.validator.Role
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestHeader
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestController
import com.glynlyon.kl.gpa.util.Constant
import com.glynlyon.kl.gpa.util.token.TokenParser
import com.glynlyon.kl.gpa.util.enums.AppUserType

@RestController
@RequestMapping
@Validated
class GradingController{
	
	@Autowired
	GradingService gradingService
	
	
	/**
	 * calculate an overall score
	 * 
	 * @param gradeDTO
	 * @param auth
	 * @return ScoreDTO
	 */
	@PutMapping(value="/scores", consumes = Constant.SCORE_CONTENT_TYPE, produces = Constant.SCORE_ACCEPT)
	@ResponseStatus(HttpStatus.OK)
	public ScoreAndStateResultDTO calculateScore( 
			@Validated @RequestBody GradeDTO gradeDTO, 
			@Role(message="{input.role.notallowed.studentteacheradmin}", roles=[AppUserType.ADMIN, AppUserType.STUDENT, AppUserType.TEACHER]) @RequestHeader(name="authorization") String auth ){
		return gradingService.calculateScore( gradeDTO )
	}
	
	
	/**
	 * Calculate an average score for each assignment
	 * 
	 * @param assignmentDTO
	 * @param auth
	 * @return AssignmentScoreWrapperDTO
	 */
	@PutMapping(value="/scores", consumes = Constant.ASSIGNMENT_CONTENT_TYPE, produces = Constant.ASSIGNMENT_ACCEPT)
	@ResponseStatus(HttpStatus.OK)
	public AssignmentScoreWrapperDTO calculateAssignmentScore(  
			@RequestBody AssignmentWrapperDTO assignmentWrapperDTO,
			@Role(message="{input.role.notallowed.studentteacheradmin}", roles=[AppUserType.ADMIN, AppUserType.STUDENT, AppUserType.TEACHER]) @RequestHeader(name="authorization") String auth ){
		return gradingService.calculateAssignmentScore( assignmentWrapperDTO )
	}
	
	
	/**
	 * Calculate an earned score and a score to date for all assignments for each student passed in
	 * 
	 * @param studentUnitScoreDTO
	 * @param auth
	 * @return StudentUnitScoreWrapperDTO
	 */
	@PutMapping(value="/scores", consumes = [Constant.STUDENT_CONTENT_TYPE], produces = [Constant.STUDENT_ACCEPT])
	@ResponseStatus(HttpStatus.OK)
	public StudentUnitScoreWrapperDTO calculateStudenttScore(
			@RequestBody StudentUnitWrapperDTO studentUnitWrapperDTO,
			@Role(message="{input.role.notallowed.studentteacheradmin}", roles=[AppUserType.ADMIN, AppUserType.STUDENT, AppUserType.TEACHER]) @RequestHeader(name="authorization") String auth ){
		return gradingService.calculateStudentOrUnitScore(studentUnitWrapperDTO, true, false)
	}
	/**
	 * Calculate an earned score and a score to date for all assignments for each unit passed in
	 *
	 * @param studentUnitScoreDTO
	 * @param auth
	 * @return StudentUnitScoreWrapperDTO
	 */
	@PutMapping(value="/scores", consumes = [Constant.UNIT_CONTENT_TYPE], produces = [Constant.UNIT_ACCEPT])
	@ResponseStatus(HttpStatus.OK)
	public StudentUnitScoreWrapperDTO calculateUnitScore(
			@RequestBody StudentUnitWrapperDTO studentUnitWrapperDTO,
			@Role(message="{input.role.notallowed.studentteacheradmin}", roles=[AppUserType.ADMIN, AppUserType.STUDENT, AppUserType.TEACHER]) @RequestHeader(name="authorization") String auth ){
		return gradingService.calculateStudentOrUnitScore(studentUnitWrapperDTO, false, true)
	}
	
	

}
