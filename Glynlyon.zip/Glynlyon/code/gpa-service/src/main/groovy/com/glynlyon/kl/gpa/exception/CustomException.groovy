package com.glynlyon.kl.gpa.exception

import org.apache.logging.log4j.Level


/**
 * Base Exception class that all exceptions should extend from. 
 * if the field name is not passed in then a null value is returned for the field. 
 * 
 *
 */
public abstract class CustomException extends RuntimeException{
	
	
	public boolean isLoggable = false  // if the exception should be logged. default to no logging
	public Exception rootCause //the root exception if there is one
	public Level logLevel // the log level to use if the exception should be logged
	public String field // the field name
	
		
	
	/**
	 * call this constructor if no logging is desired
	 * 
	 * @param message - the message to send back to the client
	 */
	public CustomException(String message){
		super(message)
		this.field = null
		isLoggable = false

	}
	
	
	/**
	 * call this constructor if no logging is desired
	 * 
	 * @param field - the field name to send back to the client
	 * @param message - the message to send back to the client
	 */
	public CustomException(String message, String field){
		super(message)
		this.field = field
		isLoggable = false

	}
	
	
	/**
	 * call this constructor if logging is desired but there is no underlying exception to log and there is no field name to log. 
	 * 
	 * @param message - the message to log and to send back to the client
	 * @param logLevel  - the log level to use
	 */
	public CustomException(String message, Level logLevel){
		super(message)
		field = null
		this.isLoggable = true
		this.logLevel = logLevel
	}
	
	
	/**
	 * call this constructor if logging is desired but there is no underlying exception to log and there is a field name to log.
	 * 
	 * @param message - the message to log and to send back to the client
	 * @param field - the field name to log and to send back to the client
	 * @param logLevel  - the log level to use
	 */
	public CustomException(String message, String field, Level logLevel){
		super(message)
		this.field = field
		this.isLoggable = true
		this.logLevel = logLevel
	}
	
	
	/**
	 * call this constructor if logging is desired and you wish to log the underlying exception and there is no field name to log.
	 * 
	 * @param message - the message to log and to send back to the client
	 * @param logLevel - the log level to use
	 * @param rootCause - the underlying exception to log
	 */
	public CustomException(String message, Level logLevel, Exception rootCause){
		super(message)
		field = null
		this.isLoggable = true
		this.logLevel = logLevel
		this.rootCause = rootCause
	}
	
	
	/**
	 * call this constructor if logging is desired and you wish to log the underlying exception and there is a field name to log.
	 * 
	 * @param message - the message to log and to send back to the client
	 * @param field - the field name to log and to send back to the client
	 * @param logLevel - the log level to use
	 * @param rootCause - the underlying exception to log
	 */
	public CustomException(String message, String field, Level logLevel, Exception rootCause){
		super(message)
		this.field = field
		this.isLoggable = true
		this.logLevel = logLevel
		this.rootCause = rootCause
	}

}
