package com.glynlyon.kl.gpa.exception

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus
import org.apache.logging.log4j.Level


/**
 * Exception to throw when a Http Status INTERNAL_SERVER_ERROR (500) is desired.
 * @see CustomException for furthur documentation
 *
 */
@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
class InternalServerErrorException extends CustomException{
	
	public InternalServerErrorException(String message){
		super(message)
	}

	public InternalServerErrorException(String message, String field){
		super(message, field)
	}
		
	public InternalServerErrorException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public InternalServerErrorException(String message, String field, Level logLevel){
		super(message, field, logLevel)
	}

	public InternalServerErrorException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
	
	public InternalServerErrorException(String message, String field, Level logLevel, Throwable rootCause){
		super(message, field, logLevel, rootCause)
	}
	
}
