package com.glynlyon.kl.gpa.exception


import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ResponseStatus
import org.apache.logging.log4j.Level


/**
 * Exception to throw when a Http Status FORBIDDEN (403) is desired.
 * @see CustomException for furthur documentation
 *
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
class ForbiddenException extends CustomException{
	
	public ForbiddenException(String message){
		super(message)
	}

	public ForbiddenException(String message, String field){
		super(message, field)
	}
		
	public ForbiddenException(String message, Level logLevel){
		super(message, logLevel)
	}
	
	public ForbiddenException(String message, String field, Level logLevel){
		super(message, field, logLevel)
	}

	public ForbiddenException(String message, Level logLevel, Throwable rootCause){
		super(message, logLevel, rootCause)
	}
	
	public ForbiddenException(String message, String field, Level logLevel, Throwable rootCause){
		super(message, field, logLevel, rootCause)
	}
	
}
