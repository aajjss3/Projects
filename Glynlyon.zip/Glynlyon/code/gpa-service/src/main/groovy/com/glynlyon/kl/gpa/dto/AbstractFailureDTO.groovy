package com.glynlyon.kl.gpa.dto

import java.util.List

/**
 * Abstract DTO to extend from if the response will contain successes and failures
 * 
 *
 */
public abstract class AbstractFailureDTO {
	
	List<FailureDTO> failures
	
	public List<FailureDTO> getFailures() {
		return failures;
	}
	public void setFailures(List<FailureDTO> failures) {
		this.failures = failures;
	}

}
