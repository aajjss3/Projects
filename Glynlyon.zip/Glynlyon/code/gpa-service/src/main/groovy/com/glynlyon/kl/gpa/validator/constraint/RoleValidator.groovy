package com.glynlyon.kl.gpa.validator.constraint

import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext
import com.glynlyon.kl.gpa.util.token.TokenParser
import com.glynlyon.kl.gpa.util.enums.AppUserType
import com.glynlyon.kl.gpa.validator.Role


/**
 * Field level validation. 
 * Validate that the role contained in the token in the http header is a valid role.
 * The collection of valid roles is stored in the variable 'roles'.
 * @author asparago
 *
 */
class RoleValidator implements ConstraintValidator<Role, String>{

	private AppUserType[] roles
	
	@Override
	public void initialize(Role constraintAnnotation) {
		this.roles = constraintAnnotation.roles()
	}

	@Override
	public boolean isValid(String auth, ConstraintValidatorContext context) {
		boolean success = false
		roles.each {
			if( it == TokenParser.parse(auth).role ){
				success = true
			}
		}
		return success
	}

	
}
