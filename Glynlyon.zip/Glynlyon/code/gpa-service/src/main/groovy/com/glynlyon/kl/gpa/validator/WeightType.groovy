package com.glynlyon.kl.gpa.validator

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target
import javax.validation.Constraint
import javax.validation.Payload
import com.glynlyon.kl.gpa.validator.constraint.WeightTypeValidator


@Target([ElementType.TYPE, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = WeightTypeValidator.class)
@Documented
@Inherited
public @interface WeightType {
	String message() default "weight type is not valid"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
