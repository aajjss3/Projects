package com.glynlyon.kl.gpa.config;


import org.modelmapper.ModelMapper;
import org.modelmapper.Conditions;
import org.modelmapper.convention.NameTokenizers;
import org.modelmapper.convention.NamingConventions;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configure the ModelMapper API
 *
 */
@Configuration
class ModelMapperConfiguration {
	
	/**
	 * ModelMapper used to map all fields, no matter the source value
	 * @return
	 */
	@Bean
	@Qualifier("map-all-fields")
	public ModelMapper mapperAll() {
		ModelMapper mapperAll = new ModelMapper();
		customizeMapper(mapperAll);
		return mapperAll;
	}
	
	/**
	 * ModelMapper used to map only fields that contain a value (ie, are not null).
	 * Can be used for updates
	 * @return
	 */
	@Bean
	@Qualifier("map-non-null-fields")
	public ModelMapper mapperNonNulls() {
		ModelMapper mapperNonNulls = new ModelMapper();
		customizeMapper(mapperNonNulls);
		// globally set mapper to not map a field if the source value is null
		mapperNonNulls.getConfiguration().setPropertyCondition(Conditions.isNotNull());
		return mapperNonNulls;
	}
	
	private void customizeMapper( ModelMapper mapper ){
		mapper.getConfiguration().setFieldMatchingEnabled(true);
		mapper.getConfiguration().setSourceNamingConvention(NamingConventions.NONE);
		mapper.getConfiguration().setDestinationNamingConvention(NamingConventions.NONE);
		mapper.getConfiguration().setSourceNameTokenizer(NameTokenizers.UNDERSCORE);
		mapper.getConfiguration().setDestinationNameTokenizer(NameTokenizers.UNDERSCORE);	
	}
	

}
