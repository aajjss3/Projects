package com.glynlyon.kl.gpa.controller.advice

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.env.Environment
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.BindingResult
import org.springframework.validation.FieldError
import org.springframework.validation.ObjectError
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.MethodArgumentNotValidException
import org.springframework.http.converter.HttpMessageNotReadableException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.ResponseStatus
import static org.springframework.core.annotation.AnnotatedElementUtils.findMergedAnnotation
import com.fasterxml.jackson.databind.JsonMappingException
import com.fasterxml.jackson.databind.exc.InvalidFormatException
import com.glynlyon.kl.gpa.exception.CustomException
import com.glynlyon.kl.gpa.dto.ErrorDTO
import com.glynlyon.kl.gpa.dto.ErrorDTOWrapper
import com.glynlyon.kl.gpa.util.JSONFieldNameUtil
import javax.validation.ConstraintViolation
import javax.validation.ConstraintViolationException
import javax.validation.Path
import java.util.List
import org.apache.logging.log4j.Level
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import com.google.gson.Gson

/**
 * Override springs default handling when an exception is thrown by the application.
 *
 */
@ControllerAdvice
public class CustomExceptionHandler{
	
	@Autowired
	Environment env
	   
    
    @ExceptionHandler
    @ResponseBody
    ResponseEntity<ErrorDTOWrapper> handle(Exception exception) {
    	
    	ResponseEntity<ErrorDTOWrapper> response = null
		Logger logger = LogManager.getLogger(exception.getClass())
		
		// if CustomException or any of its subclasses are thrown
    	if( exception instanceof CustomException ){ 
			// log the exception if applicable.
			if( ((CustomException)exception).isLoggable ){
				if( ((CustomException)exception).rootCause != null ){
					logger.log( exception.logLevel, exception.getLocalizedMessage(), exception.rootCause )
				}
				else{
					logger.log( exception.logLevel, exception.getLocalizedMessage() )
				}
			}
			ErrorDTO errorDTO = new ErrorDTO( exception.field, exception.getLocalizedMessage() )
			ErrorDTOWrapper body = new ErrorDTOWrapper(errorDTO)
			// get the HTTP status code annotated on the CustomException, or if one isn't present, then set to HTTP status code to INTERNAL_SERVER_ERROR as default
			ResponseStatus annotation = findMergedAnnotation(exception.getClass(), ResponseStatus.class)
			HttpStatus responseStatus = ( annotation != null ) ?  annotation.value() : HttpStatus.INTERNAL_SERVER_ERROR 
			response = new ResponseEntity<ErrorDTOWrapper>(body, responseStatus)
    	}
		
		// if bean validation annotation fails on either @PathVariable or @RequestParam
    	else if( exception instanceof ConstraintViolationException ){ 
    		List<ErrorDTO> errors = new ArrayList<ErrorDTO>()
    		Set<ConstraintViolation<?>> violations = ((ConstraintViolationException)exception).getConstraintViolations()
    		for( ConstraintViolation violation : violations ){
    			Iterator nodes = violation.getPropertyPath().iterator()
    			String fieldName = null
    			while (nodes.hasNext() ){
    				fieldName = ((Path.Node)nodes.next()).getName()
    			}
    			ErrorDTO dto = new ErrorDTO(fieldName, violation.getMessage())
    			errors.add(dto)
    		}
    		ErrorDTOWrapper body = new ErrorDTOWrapper(errors)
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST)  
			String json = new Gson().toJson(body)
			logger.log( Level.WARN, "Input validation failed. JSON returned to the client is: " + json )
    	}
		
		// if @Validated or @Valid fails
    	else if( exception instanceof MethodArgumentNotValidException ){ 
			BindingResult bindingResult = ((MethodArgumentNotValidException)exception).getBindingResult()
			List<ErrorDTO> errors = new ArrayList<ErrorDTO>()
			
			// for field errors - depending on an external property, either get the field name from the fields json annotation or from the errors object (which is based on the dto).
			if( "true".equalsIgnoreCase( env.getProperty("on-error.fieldname.match.json") ) ){
				errors.addAll( JSONFieldNameUtil.setErrorsWithJsonName(bindingResult.getFieldErrors(), bindingResult.getTarget().getClass()) )
			}
			else{
	    		for (FieldError fieldError : bindingResult.getFieldErrors()) {
					ErrorDTO errorDTO = new ErrorDTO(fieldError.getField(), fieldError.getDefaultMessage())
					errors.add(errorDTO)
	    		}
			}	
			
			// for global errors
    		for (ObjectError globalError : bindingResult.getGlobalErrors()) {
    			ErrorDTO errorDTO = new ErrorDTO(globalError.getObjectName(), globalError.getDefaultMessage())
    			errors.add(errorDTO)
    		}
			
    		ErrorDTOWrapper body = new ErrorDTOWrapper(errors)
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST)    
			String json = new Gson().toJson(body)
			logger.log( Level.WARN, "Input validation failed. JSON returned to the client is: " + json )
    	}
		
		// if input json in request body is malformed or the json fields type does not match the dto type. 
    	else if( exception instanceof HttpMessageNotReadableException ){  
			String message
			String field
			Throwable rootCause = exception.rootCause
			if( rootCause instanceof JsonMappingException ){
				String pathReference = ((JsonMappingException)rootCause).getPathReference()
				if(pathReference){
					int end = pathReference.lastIndexOf("\"")
					int start = pathReference.lastIndexOf("\"", end-1)
					if( end > start){
						field = pathReference.substring(start+1, end)
					}	
				}	
				if( rootCause instanceof InvalidFormatException ){
					message = ((InvalidFormatException)rootCause).getValue() + " is either an incorrect type or value."
				}
				else{
					message = rootCause.getMessage()
				}	
			}
			else{
				field = null
	    		message = (exception.getCause() != null) ? exception.getCause().getMessage() : exception.getLocalizedMessage()
			}	
    		ErrorDTO error = new ErrorDTO(field, message)
    		ErrorDTOWrapper body = new ErrorDTOWrapper(error)
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.BAD_REQUEST) 
			logger.log( Level.WARN, "The input JSON in the requests body is malformed. " + message )
    	}
		
		// if any other exception not listed above is thrown
    	else{ 
    		String message = (exception.getCause() != null) ? exception.getCause().getMessage() : exception.getLocalizedMessage()
    		ErrorDTO error = new ErrorDTO(null, message)
    		ErrorDTOWrapper body = new ErrorDTOWrapper(error)
    		response = new ResponseEntity<ErrorDTOWrapper>(body, HttpStatus.INTERNAL_SERVER_ERROR)   
			logger.log( Level.ERROR, "Uncaught exception was thrown. ", exception )
    	}
    	
    	return response
    	
    }    
  
    

	

}
