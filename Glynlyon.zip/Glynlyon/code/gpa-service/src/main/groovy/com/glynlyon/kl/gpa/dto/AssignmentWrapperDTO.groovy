package com.glynlyon.kl.gpa.dto

import java.util.List

import javax.validation.Valid
import javax.validation.constraints.NotNull
import javax.validation.constraints.Pattern

import org.hibernate.validator.constraints.NotBlank

import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty

import com.glynlyon.kl.gpa.util.Constant

public class AssignmentWrapperDTO {
	
	@NotNull(message = "{input.field.required}")
	@Valid
	List<AssignmentDTO> assignments
	public List<AssignmentDTO> getAssignments() {
		return assignments;
	}
	public void setAssignments(List<AssignmentDTO> assignments) {
		this.assignments = assignments;
	}
}


class AssignmentDTO{
	
	@NotNull(message = "{input.field.required}")
	String id
	
	@NotNull(message = "{input.field.required}")
	@Valid
	List<ScoreDTO> students

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<ScoreDTO> getStudents() {
		return students;
	}
	public void setStudents(List<ScoreDTO> students) {
		this.students = students;
	}
}





