package com.glynlyon.kl.gpa.util.enums

public enum QuestionType {
	
	mcq, 
	msq, 
	plaintext, 
	longtext, 
	clozedropdown, 
	clozetext, 
	clozeformula, 
	classification, 
	association, 
	orderlist, 
	sortlist, 
	imageclozedropdown, 
	imageclozeassociation, 
	imageclozetext,	
	fileupload,	
	formulaessay, 
	graphplotting

}
