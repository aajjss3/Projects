package com.glynlyon.kl.gpa.validator

import java.lang.annotation.Documented
import java.lang.annotation.ElementType
import java.lang.annotation.Inherited
import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy
import java.lang.annotation.Target
import javax.validation.Constraint
import javax.validation.Payload
import com.glynlyon.kl.gpa.util.enums.AppUserType
import com.glynlyon.kl.gpa.validator.constraint.RoleValidator



@Target([ElementType.FIELD, ElementType.TYPE, ElementType.METHOD, ElementType.PARAMETER, ElementType.ANNOTATION_TYPE])
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = RoleValidator.class)
@Documented
@Inherited
public @interface Role {
	AppUserType[] roles()  // custom variable that contains a collection of AppUserType's
	String message() default "not a valid role"
	Class<?>[] groups() default []
	Class<? extends Payload>[] payload() default []
}
