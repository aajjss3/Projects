Purpose:
-------
This application is a web service/web application framework built on top of Spring Boot and uses Gradle as its build tool. 

It includes functionality for:
 
* JWT authentication - using io.jsonwebtoken
* Customized Exception handling 
* DTO mapping - using ModelMapper
* Website security - using jwt and spring security
* Integration test - using Spock
	 
This framework is not set up to work with a database. If a database is desired, please add the appropriate database dependencies to the gradle build script.

********************************

To Use:
-------
1. modify the gradle.properties file - set the parameters to the project's appropriate values
2. modify the log4j2.properties file. In particular the properties: appender.file.fileName, and appender.file.filePattern
3. modify the log4j2-logstash.properties file. In particular the properties: appender.file.fileName, and appender.file.filePattern