### Add JDBC drive to local machine
- [Specific version 12.2.0.1](http://www.oracle.com/technetwork/database/features/jdbc/jdbc-ucp-122-3110062.html)
- [Other versions](http://www.oracle.com/technetwork/database/application-development/jdbc/downloads/index.html)

1. [Download ojdbc8.jar](http://www.oracle.com/technetwork/database/features/jdbc/jdbc-ucp-122-3110062.html). You will need to create an account with Oracle
2. Run `mvn install:install-file -Dfile=[PATH OF THE OJDBC8.JAR FILE] -DgroupId=com.oracle -DartifactId=ojdbc8 -Dversion=12.2.0.1 -Dpackaging=jar`

### Add Safe validation JAR file

1. Run `mvn install:install-file -Dfile=lib/safe-auth-1.0.jar -DgroupId=com.fitlaw -Dversion=1.0.0 -Dpackaging=jar`

This jar file is used to validate the SAFE call back.

### Create JAR for deploying

1. Run `chmod 700 deploy.sh`
1. Run `./deploy.sh`

Will generate a .jar file in the `/target` folder

### Run Locally

Command prompt: 
```
FIT_DB_URL=  FIT_DB_PASSWORD= FIT_DB_USERNAME= FIT_JWT_SECRET= FIT_LOGFILE_LOCATION= FIT_REDIRECT_PROVIDER_URL= FIT_REDIRECT_TOKEN_URL= mvn spring-boot:run
```
Get the environment keys from the google drive `Fit Api Environment` file

You can now ping the server at `http://localhost:5000/`