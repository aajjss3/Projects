package com.fitlaw.service;


import java.io.BufferedInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.fitlaw.util.exception.InternalServerErrorException;
import com.fitlaw.util.exception.NotAcceptableException;
import com.fitlaw.util.log.BaseLogger;
import java.io.InputStream;


@Service
public class FileService {
	
	
	@Autowired
	Environment environment;
	
	private List<String> allowableFileExtensions = new ArrayList<String>(); // list of allowable file extensions.
	private String fileLocation;  // directory to store the file in
	
	
	@PostConstruct
	public void init(){
		List<Object> extensions = Arrays.asList( (environment.getProperty( "file.upload.allowable.ext" ).split(",") ) );
		extensions.forEach( extension -> { 
			if( extension != null ){
				allowableFileExtensions.add( ((String)extension).trim() );
			}
		});
		String location = environment.getProperty( "file.upload.location" );
		fileLocation = ( location.endsWith(File.separator) ) ?  location : location + File.separator;
	}
	
		
	/**
	 * Save a file and return its unique filename.
	 * No information is persisted to the database. 
	 * Only allow a file to be uploaded if it has an acceptable file extension 
	 * @param file - the contents of the file to save
	 * @return the name of the file
	 */
	public String saveFile( MultipartFile file ){
		
		String originalFilename = file.getOriginalFilename();
		
		if( originalFilename == null || originalFilename.equals("") || originalFilename.lastIndexOf(".") <= 1 ){
			throw new NotAcceptableException( "The file name is missing or does not have an extension." );
		}
		
		if( file.isEmpty() ){
			throw new NotAcceptableException( "The file is empty." );
		}
		
		String fileContentType = file.getContentType();
		//TODO check file content type for acceptable types
		
		String fileExtension = originalFilename.substring( originalFilename.lastIndexOf(".") + 1, originalFilename.length() );
		
		if( allowableFileExtensions.contains(fileExtension) ){
			String fileName = UUID.randomUUID().toString().replaceAll("-", "") + "." + fileExtension;	 // generate a unique filename	
			try( InputStream input = new BufferedInputStream( file.getInputStream() ) ){
				Files.copy( input, Paths.get(fileLocation + fileName) );
			}
			catch(Exception e ){
				throw new InternalServerErrorException("Unable to save the file.", BaseLogger.LogLevel.SEVERE, e);
			}
			return fileName;
		}
		else{
			throw new NotAcceptableException( "The file does not have a valid extension." );
		}
		
	}
	
	
	/**
	 * Retrieve a file. 
	 * No information is persisted to the database. 
	 * @param filename
	 * @return
	 */
	public Resource retrieveFile(String filename ){
		Resource resource = new FileSystemResource( fileLocation + filename );
		if( resource.exists() && resource.isFile() && resource.isReadable() ){
			return resource;
		}
		else{
			throw new InternalServerErrorException( "The file named: " + filename + ", either doesnt exist or is not readable" );
		}
	}
		

}
