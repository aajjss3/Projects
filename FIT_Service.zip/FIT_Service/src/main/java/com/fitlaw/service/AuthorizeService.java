package com.fitlaw.service;


import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.fitlaw.dto.AuthorizeDTO;
import com.fitlaw.model.ApplicationUser;
import com.fitlaw.repository.ApplicationUserRepository;
import com.fitlaw.util.exception.InternalServerErrorException;
import com.fitlaw.util.exception.UnauthorizedException;
import com.fitlaw.util.log.BaseLogger.LogLevel;
import com.thomson.sso.classes.TTCValidation;
import com.thomson.sso.classes.TTCVerifier;

/**
 * 
 * @author alan
 *
 */
@Service
public class AuthorizeService {
	
	String jwtSecretKey;
	String safeAuthenticationKey;
	boolean validationCredentials;
	int hours;
	
	@Autowired
	Environment environment;
	
	@Autowired
	ApplicationUserRepository applicationUserRepository;
	
	@PostConstruct
	public void init(){
		validationCredentials= Boolean.valueOf(environment.getProperty("validate.credentials"));
		jwtSecretKey = environment.getProperty("jwt.secret.key");
		safeAuthenticationKey = environment.getProperty("safe.authentication.key");
		hours = Integer.parseInt(environment.getProperty("jwt.token.expires.in.hours"));
	}
	
	
	/**
	 * validate the credentials: digest, uid and time. 
	 * The uid is a unique id assigned to the user. each user has their own unique id. any subsequent calls by the same user will result in the same uid being passed in.
	 * if the credentials are valid then either retrieve an existing Application User or create one if one does not exist, and then create and return a jwt token.
	 * @param AuthorizeDTO
	 * @return AuthenticateDTO
	 */
	public AuthorizeDTO createToken(AuthorizeDTO authorize){
		
		if( validationCredentials ) {
			if(authorize.getDigest() == null || authorize.getTime() == null || authorize.getUid() == null){
				throw new UnauthorizedException("Either the digest, time or uid is missing.", LogLevel.WARNING);
			}
			
			// validate the credentials: digest, uid, and time (these credentials are passed in from the authenticate service)
			String compiledDigestMD5 = (new TTCVerifier()).verify(new StringBuilder(authorize.getUid()).append(authorize.getTime()).append(safeAuthenticationKey).toString());
			if (!(new TTCValidation()).validateTime(authorize.getTime()) || !compiledDigestMD5.equals(authorize.getDigest())){
				throw new UnauthorizedException("The credentials are invalid.", LogLevel.WARNING);
			}
		}	
		
		// retrieve the ApplicationUser based on the email passed in
		ApplicationUser applicationUser = applicationUserRepository.findByAuthorizeId( authorize.getUid() );
		
		// if the ApplicationUser doesnt exist then create one
		if( applicationUser == null ){
			applicationUser = new ApplicationUser();
			applicationUser.setAuthorizeId(authorize.getUid());
			//applicationUser.setRole(role);
			try{
				applicationUserRepository.save(applicationUser);
			}	
			catch(Exception e){
				throw new InternalServerErrorException("Unable to create an application user", LogLevel.SEVERE, e);
			}
		}
		
		// create the jwt token. set the token to expire in x hours from the time it was created. (where x is located in the application.properties file)
		String token = Jwts.builder()
				.setSubject(applicationUser.getId().toString())
				.setIssuedAt(new Date())
				.setExpiration(Date.from(Instant.now().plus(hours, ChronoUnit.HOURS)))
				.claim("role", null)  // create a custom claim field to hold the users role
				.setHeaderParam("alg", "HS256")
				.setHeaderParam("typ", "JWT")
				.signWith(SignatureAlgorithm.HS256, jwtSecretKey.getBytes())
				.compact();
				
		return new AuthorizeDTO(token);			

	}

}
