package com.fitlaw.service;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fitlaw.dto.AccountFirmDTO;
import com.fitlaw.model.Account;
import com.fitlaw.model.ApplicationUser;
import com.fitlaw.repository.AccountRepository;
import com.fitlaw.util.exception.InternalServerErrorException;
import com.fitlaw.util.exception.NotFoundException;
import com.fitlaw.util.log.BaseLogger.LogLevel;
//import com.fitlaw.model.Contact;
//import com.fitlaw.model.Design;
//import com.fitlaw.model.DesignAndContent;
//import com.fitlaw.model.Firm;
//import com.fitlaw.model.Focus;
//import com.fitlaw.model.Logo;
//import com.fitlaw.model.PhysicalAddress;
//import com.fitlaw.model.WebAddress;



/**
 * 
 * @author alan
 *
 */
@Service
public class AccountService {
	
    @Autowired
    AccountRepository accountRepository;
    
	@Autowired
	MessageSource message;
    
    @Transactional(readOnly=true)
    public List<AccountFirmDTO> retrieveAccountFirms(){
    	return accountRepository.retrieveAccountFirms();
    }
    
    
//    @Transactional(readOnly=true)
//    public List<Account> retrieveAccounts(){
//    	List<Account> accounts = new ArrayList<Account>();
//    	Iterable<Account> its = accountRepository.findAll();
//    	its.forEach( it -> accounts.add(it) );
//    	return accounts;
//    }
    
         
    @Transactional
    public Account createAccount(Account account, ApplicationUser applicationUser){
    	account.setApplicationUser(applicationUser);
    	try{
    		return accountRepository.save(account);
    	}
    	catch(Exception e){
    		throw new InternalServerErrorException("Unable to create an account", LogLevel.SEVERE, e);
    	}    		
    }
        
    
    @Transactional
    public void deleteAccount(UUID id){
    	try{
    		accountRepository.deleteById(id); // will cascade delete.
    	}
    	catch(Exception e){
    		throw new InternalServerErrorException("Unable to delete the account with an id of:" + id.toString(), LogLevel.SEVERE, e);
    	}
    }
    
    @Transactional(readOnly=true)
    public Account retrieveAccount(UUID id){
    	Optional<Account> account = accountRepository.findById(id);
    	if( account.isPresent() ){
    		return account.get();
    	}
    	else{
    		throw new NotFoundException("Unable to find an account with an id of:" + id.toString(), LogLevel.SEVERE);
    	}
    }
    
    @Transactional(rollbackFor = Exception.class) // set to rollback if ANY Exception is thrown as a precaution since multiple db transactions are occurring (delete and insert)
    public Account updateAccount(Account account, UUID id, ApplicationUser applicationUser){
    	    	    	
		//		// Since the account object passed in is a new transient domain entity (and not a detached domain entity) then for a merge (update) to work, the account object passed in and all nested objects of the account must have a value for the id field (For nested collections its used to match the elements in the collection to the corresponding db row).
		//		// Also, need to set the version field on the account object passed in and the accounts nested objects - If there is a @Version field then JPA will use its value along with the @Id field's value to determine if the entity is new or not.
		//		// If just set the id field and not the version field, and the input version field is null or doesnt match the corresponding version field in the database, then either a Hibernate exception will be thrown or JPA will insert a new row instead of updating the existing, ignoring the value i set for id and instead generating a new id.
		//	    // Its not good practice to manually set the value for the Version field, it should only be set by the persistence provider. Also, this way of updating requires a code change if the object graph structure changes. So instead do one of the following 2 options:
		//      //  1) delete the current object from the database and persist this new transient object as a new object instead of updating. the drawback to this is that it will generate new values for all id fields that will be different from the current id values.
		//      //  2) use a DTO Mapper and treat the account object passed in as a DTO (not a domain entity) and map its fields to a persistent or detached account object.
		//    	Optional<Account> existingAccount = accountRepository.findById(id);
		//    	if( existingAccount.isPresent() ){
		//    		account.setId(id);
		//	    	account.setVersion(existingAccount.get().getVersion()); 
		//	    	account.setApplicationUser(applicationUser);
		//	    	//account.isNew = false;
		//	    	Firm existingFirm = existingAccount.get().getFirm();
		//	    	account.getFirm().setVersion(existingFirm.getVersion());
		//	    	DesignAndContent existingDesignAndContent = existingAccount.get().getDesignAndContent();
		//	    	account.getDesignAndContent().setVersion(existingDesignAndContent.getVersion());
		//	    	List<Contact> existingContacts = existingAccount.get().getContacts();
		//    		List<Contact> contacts = account.getContacts();
		//	    	for( Contact existingContact : existingContacts ){
		//	    		for( Contact contact : contacts ){
		//	    			if( contact.getId().toString().equals(existingContact.getId().toString()) ){
		//	    				contact.setVersion(existingContact.getVersion());
		//	    			}
		//	    		}
		//	    	}
		//	    	List<Focus> existingFocuses = existingFirm.getFocuses();
		//	    	List<Focus> focuses = account.getFirm().getFocuses();
		//	    	for( Focus existingFocus : existingFocuses ){
		//	    		for( Focus focus : focuses ){
		//	    			if( focus.getId().toString().equals(existingFocus.getId().toString()) ){
		//	    				focus.setVersion(existingFocus.getVersion());
		//	    			}
		//	    		}
		//	    	}	
		//	    	List<PhysicalAddress> existingPhysicalAddresses = existingFirm.getPhysicalAddresses();
		//	    	List<PhysicalAddress> physicalAddresses = account.getFirm().getPhysicalAddresses();
		//	    	for( PhysicalAddress existingPhysicalAddress : existingPhysicalAddresses ){
		//	    		for( PhysicalAddress physicalAddress : physicalAddresses ){
		//	    			if( physicalAddress.getId().toString().equals(existingPhysicalAddress.getId().toString()) ){
		//	    				physicalAddress.setVersion(existingPhysicalAddress.getVersion());
		//	    			}
		//	    		}
		//	    	}		    	
		//	    	List<WebAddress> existingWebAddresses = existingFirm.getWebAddresses();
		//	    	List<WebAddress> webAddresses = account.getFirm().getWebAddresses();
		//	    	for( WebAddress existingWebAddress : existingWebAddresses ){
		//	    		for( WebAddress webAddress : webAddresses ){
		//	    			if( webAddress.getId().toString().equals(existingWebAddress.getId().toString()) ){
		//	    				webAddress.setVersion(existingWebAddress.getVersion());
		//	    			}
		//	    		}
		//	    	}
		//	    	List<Logo> existingLogos = existingDesignAndContent.getLogos();
		//	    	List<Logo> logos = account.getDesignAndContent().getLogos();
		//	    	for( Logo existingLogo : existingLogos ){
		//	    		for( Logo logo : logos ){
		//	    			if( logo.getId().toString().equals(existingLogo.getId().toString()) ){
		//	    				logo.setVersion(existingLogo.getVersion());
		//	    			}
		//	    		}
		//	    	}
		//	    	List<Design> existingDesigns = existingDesignAndContent.getDesigns();
		//	    	List<Design> designs = account.getDesignAndContent().getDesigns();
		//	    	for( Design existingDesign : existingDesigns ){
		//	    		for( Design design : designs ){
		//	    			if( design.getId().toString().equals(existingDesign.getId().toString()) ){
		//	    				design.setVersion(existingDesign.getVersion());
		//	    			}
		//	    		}
		//	    	}	    			
		//	    	try{
		//	    		return accountRepository.save(account);
		//	    	}
		//	    	catch(Exception e){
		//	    		throw new InternalServerErrorException("Unable to update the account.", LogLevel.SEVERE, e);
		//	    	}
		//    	}
		//    	else{
		//    		throw new NotFoundException("Unable to find an account with an a ID of: " + id);
		//    	}
    	
    	
    	// since this is a delete and insert (instead of an update/merge), all rows (entities) will have a new value for their 'id' field.
    	Optional<Account> existingAccount = accountRepository.findById(id);
    	if( !existingAccount.isPresent() ){
    		throw new NotFoundException("Unable to find an account with an a ID of: " + id);
    	}
    	deleteAccount(id);
    	accountRepository.flush();
    	return createAccount(account, applicationUser);
    	
    }
         
    
}
