package com.fitlaw.filter;

import org.springframework.stereotype.Component;
import com.fitlaw.util.Constants;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.Filter;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import io.jsonwebtoken.Jwt;
import io.jsonwebtoken.Jwts;


/**
 * This filter runs for every request and determines if the request is authorized based on the jwt token passed in.
 * For a valid authorization...
 * -The request's HTTP Header must contain a JWT token. A JWT token must exist in one of two places..
 * 		1) A Header field called 'Authorization' that contains the word 'Bearer ' followed by the jwt token. 
 * 		2) An HTTP Cookie Header called 'fit-token' taht contains the token.
 * -The token must be encrypted (see www.jwt.io) with the value stored in the 'jwt.secret.key' field in the application.properties file.
 * -Not all endpoints require a JWT token (see bypass.jtw.authorization.url in the application-local.properties file)
 * @author alan
 *
 */
@Component
public class JwtAuthenticationFilter implements Filter{

	private String jwtSecretKey;
	private List<String> bypassUrls = new ArrayList<String>();
	
	
	@Autowired
	Environment environment;

	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		jwtSecretKey = environment.getProperty("jwt.secret.key");
		List<Object> urls = Arrays.asList( (environment.getProperty( "bypass.jtw.authorization.url" ).split(",") ) );
		urls.forEach( url -> { 
				bypassUrls.add( ((String)url).trim() );
		});
		
	}

	@Override
	public void destroy() {
	}

	
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

//System.out.println("debugging - 1" + (((HttpServletRequest)req).getRequestURI()) );  
		// determine if the endpoint requires a JWT token to be present in the request
    	boolean requiresJWT = false;
    	for(String bypassUrl : bypassUrls){
    		if( (((HttpServletRequest)req).getRequestURI()).endsWith(bypassUrl) ){
    			requiresJWT = true;
    		}
    	}

    	// the endpoint does not require a JWT token
    	if( requiresJWT || "OPTIONS".equals(((HttpServletRequest)req).getMethod()) ){
    		chain.doFilter(req, res);
    	}
    	// The endpoint requires a JWT token and the token must be valid.
    	else{
//System.out.println("debugging - 2" + (((HttpServletRequest)req).getRequestURI()) );    		
    		String token = null;
    		
    		// check for the token in an HTTP Header field called Authorization.
	        String authHeader = ((HttpServletRequest)req).getHeader("Authorization");
	        if (authHeader != null && authHeader.startsWith("Bearer")) {
//System.out.println("debugging - 3" + (((HttpServletRequest)req).getRequestURI()) ); 
	        	token = authHeader.replaceFirst("Bearer", "");
//System.out.println("debugging - 4" + (((HttpServletRequest)req).getRequestURI()) + "token is: " + token); 	        	
	        }
	        // check for the token in the HTTP Cookie Header
	        else{
//System.out.println("debugging - 5" + (((HttpServletRequest)req).getRequestURI()) ); 	        	
	        	List<Cookie> cookies = Arrays.asList( ((HttpServletRequest)req).getCookies() );
	        	for( Cookie cookie : cookies ){
//System.out.println("debugging - 6" + (((HttpServletRequest)req).getRequestURI()) + "cookie name is: " + cookie.getName()); 	        		
	        		if( cookie.getName().equalsIgnoreCase(Constants.FIT_TOKEN)){
	        			token = cookie.getValue();
//System.out.println("debugging - 7" + (((HttpServletRequest)req).getRequestURI()) + "token is: " + token); 	        			
	        		}
	        	}	        	
	        }	
	        
	        // if there is no token.
	        if( token == null ){
//System.out.println("debugging - 8" + (((HttpServletRequest)req).getRequestURI()) );	        	
	        	( (HttpServletResponse)res).sendError(HttpStatus.UNAUTHORIZED.value(), "Unable to retrieve a JWT token from the request." );
	        	return;
	        }
	        else{
		        try {
		        	// check for a valid token.
		            Jwt jwt = Jwts.parser().setSigningKey(jwtSecretKey.getBytes()).parse( token.trim() );
		        }
		        catch (Exception e) {
		        	( (HttpServletResponse)res).sendError(HttpStatus.UNAUTHORIZED.value(), "A JWT token exists but it is invalid." );
		            return;
		        }
	        }
	        
	        chain.doFilter(req, res);
    	}     

    }
	
}
