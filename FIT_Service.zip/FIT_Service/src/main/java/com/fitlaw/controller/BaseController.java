package com.fitlaw.controller;


import com.fitlaw.model.ApplicationUser;
import com.fitlaw.repository.ApplicationUserRepository;
import com.fitlaw.util.exception.BadRequestException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import java.util.UUID;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 * 
 * @author alan
 *
 */
@RequestMapping(path="/fit", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
public abstract class BaseController {
	
	String jwtSecretKey;
	
	@Autowired
	Environment environment;
	
	@Autowired
	ApplicationUserRepository applicationUserRepository;

	
	@PostConstruct
	public void init(){
		jwtSecretKey = environment.getProperty("jwt.secret.key");
	}
		
	protected ApplicationUser retrieveApplicationUser(String authHeader, String tokenCookie){
		String token = retrieveToken(authHeader, tokenCookie);
		Claims claim = (Claims)Jwts.parser().setSigningKey(jwtSecretKey.getBytes()).parse( token.trim() ).getBody();
		UUID appUserId = UUID.fromString(claim.getSubject());
    	return applicationUserRepository.getOne(appUserId);
	}
	
	// the token either exists in an HTTP Header field or in a Cookie
	private String retrieveToken(String authHeader, String tokenCookie){
		if( authHeader != null && !authHeader.equals("") ){
			return authHeader.replaceFirst("Bearer", "").trim();
		}
		else if( tokenCookie != null && !tokenCookie.equals("") ){
			return tokenCookie;
		}
		else{
			throw new BadRequestException("Unable to determine the JWT token");
		}
	}
	
}
