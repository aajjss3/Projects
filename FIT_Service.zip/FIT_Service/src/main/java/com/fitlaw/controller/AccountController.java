package com.fitlaw.controller;


import com.fitlaw.dto.AccountFirmDTO;
import com.fitlaw.model.Account;
import com.fitlaw.service.AccountService;
import com.fitlaw.service.AuthorizeService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import com.fitlaw.util.Constants;



/**
 * This controller performs basic CRUD operations on an account
 * @author alan
 *
 */
@RestController
@Validated
public class AccountController extends BaseController{
	
	   
	@Autowired
	AccountService accountService;
	
	@Autowired
	AuthorizeService authorizeService;

 
	/**
	 * Create an account. Assign the user located in the http header to the account.
	 * @param account
	 * @param authHeader - HTTP Header that might contain the JWT token
	 * @param fitToken - cookie that might contain the JWT token
	 * @return Account
	 */
	@PostMapping("/account")
	@ResponseStatus(HttpStatus.CREATED)
	public Account createAccount( @RequestBody Account account, @RequestHeader(name="Authorization", required=false) String authHeader, @CookieValue(name=Constants.FIT_TOKEN, required=false) String tokenCookie ) {
	    return accountService.createAccount( account, retrieveApplicationUser(authHeader, tokenCookie) );
	}
	
	  
	/**
	 * Retrieve a list of scaled down account data
	 * @return List<AccountFirmDTO>
	 */
	@GetMapping("/account")
	@ResponseStatus(HttpStatus.OK)
	public List<AccountFirmDTO> retrieveAccountFirms(){
	 return accountService.retrieveAccountFirms();
	}
	
	
	/**
	 * Delete an account. A user can delete any account, even if the account is assigned to another user (ie. not the user passed in the http header).
	 * @param id
	 * @return String
	 */
	@DeleteMapping("/account/{id}")
	@ResponseStatus(HttpStatus.OK)
	public String deleteAccount( @PathVariable("id") UUID id ){
		accountService.deleteAccount( id );
		return new Gson().toJson(Collections.singletonMap("isDeleted", true));
	}
	
	
	/**
	 * Retrieve an account. A use can retrieve any account, even if the account is assigned to another user (ie. not the user passed in the http header).
	 * @param id
	 * @return Account
	 */
	@GetMapping("/account/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Account retrieveAccount( @PathVariable("id") UUID id ){
		return accountService.retrieveAccount(id);
	}
	
		
	/**
	 * Endpoint used to check if the service is up and running.
	 * 
	 * @return
	 */
    @GetMapping("/ping")
    @ResponseStatus(HttpStatus.OK)    
    public String ping(){
    	return "{\"status\": \"up\"}";
    }
    
    
    /**
     * update an exising account
     * @param account
     * @param id
  	 * @param authHeader - HTTP Header that might contain the JWT token
	 * @param fitToken - cookie that might contain the JWT token
     * @return
     */
	@PutMapping("/account/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Account updateAccount( @RequestBody Account account,  @PathVariable("id") UUID id, @RequestHeader(name="Authorization", required=false) String authHeader, @CookieValue(name=Constants.FIT_TOKEN, required=false) String tokenCookie ) {
	    return accountService.updateAccount( account, id, retrieveApplicationUser(authHeader, tokenCookie) );
	}
    
        	
}
