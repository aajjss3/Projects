package com.fitlaw.controller;

import java.net.URI;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
//import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.fitlaw.dto.AuthorizeDTO;
import com.fitlaw.service.AuthorizeService;
import com.fitlaw.util.Constants;


/**
 * This controller is used for authorizing a user. 
 * First the /auth endpoint is called (which is part of this REST application). This just redirects to a login page. This login page is served by an authenticate server (which is a different web application and NOT part of this REST application or its client).
 * Once the user enters their credentials in the login page and submits it, the page posts back to the authenticate server which authenticates the user.
 * The authentication server then returns a digest, uid and time back to the login page and the login page then calls the /SAFElogin endpoint (which is part of this REST application) passing in these fields.  
 * The /SAFElogin endpoint returns a jwt token back to the login page as a cookie in the header and tells the login page to redirect to a web page which is part of this REST application's client (the first web page of this application). The login page also retrieves the token (passed in as a cookie) and passes it onto the redirected web page.
 * On all subsequent calls to all other endpoints, the REST client passes in the JWT token in the HTTP Header's 'Authorization' field.
 * @author alan
 *
 */
@Controller
@RequestMapping( path="/fit" )
public class AuthorizeController {
	
	@Autowired
	AuthorizeService authorizeService;
	
	@Autowired
	Environment environment;
	
	
	/**
	 * Do nothing except to redirect the reply to a location specified in the application.properties file
	 * To redirect, must set the redirect url in the 'Location' HTTP Header field.  
	 * @return
	 */
	@GetMapping( path="/auth",  produces = {MediaType.TEXT_HTML_VALUE} )
	public ResponseEntity<String> authorize(){
	    HttpHeaders headers = new HttpHeaders();
	    headers.setLocation( URI.create( environment.getProperty( "auth.redirect.provider.url") ) );
	    return new ResponseEntity<String>( headers, HttpStatus.TEMPORARY_REDIRECT );
	}
	
	
	/**
	 * Create a user record in the ApplicationUser table and create a JWT token. Return the JWT token as a Set-Cookie parameter in the HTTP Header
	 * This method is called as a POST since data is passed in the body of the request.
	 * This endpoint redirects its reply to a location specified in the application.properties file. (FYI... a redirect must be an HTTP GET, cannot redirect using an HTTP Post).
	 * Since the request is redirecting from a POST to a GET, must redirect using an HTTP Status code of 'Moved Permenently'. The HTTP specs do not allow an HTTP Status of 'Temporary Redirect' if redirecting from a request method of POST to a GET.
	 * To redirect, must set the redirect url in the 'Location' HTTP Header field. 
	 * @param authorizeDTO
	 * @return
	 */
	@PostMapping(path="/SAFElogin", produces = {MediaType.TEXT_HTML_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE})
	public ResponseEntity<String> createToken( AuthorizeDTO authorizeDTO, HttpServletResponse response ){
		
	    String token = (authorizeService.createToken(authorizeDTO)).getToken();
	    
		HttpHeaders headers = new HttpHeaders();
	    headers.setLocation( URI.create( environment.getProperty( "auth.redirect.token.url") ) );
		
	    // Add cookie information
	    Cookie cookie = new Cookie(Constants.FIT_TOKEN, token);
	    cookie.setPath("/");
	    cookie.setSecure(true);
	    cookie.setHttpOnly(true);
	    response.addCookie(cookie);

	    return new ResponseEntity<String>( headers, HttpStatus.MOVED_PERMANENTLY );
	}
	
}
