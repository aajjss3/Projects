package com.fitlaw.controller;


import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.fitlaw.service.FileService;
import com.google.gson.Gson;

/**
 * This controller is used to upload and download a single file.
 * Only one file at a time can be uploaded / downloaded.
 * 
 * @author alan
 *
 */
@Controller
@RequestMapping( path="/fit" )
public class FileController{
	
	@Autowired
	FileService fileService;
	
	/**
	 * Upload a single file.
	 * @param file
	 * @return
	 */
    @PostMapping("/file")
    @ResponseBody
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file/*, RedirectAttributes redirectAttributes*/) {
        //redirectAttributes.addFlashAttribute("name", fileService.saveFile( file ) );
        //redirectAttributes.addAttribute("name", fileService.saveFile( file ) );
        //return "redirect:/";
    	String reply =  new Gson().toJson(Collections.singletonMap("filename", fileService.saveFile( file )));
    	return new ResponseEntity<String>( reply, HttpStatus.OK );
    }
    
    /**
     * Download a single file. 
     * @param filename
     * @return
     */
    @GetMapping("/file/{filename}")
    @ResponseBody
    public ResponseEntity<Resource> downloadFile(@PathVariable String filename) {
        Resource file = fileService.retrieveFile(filename);
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"");
        return new ResponseEntity<Resource>(file, headers, HttpStatus.OK );
        //return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"").body(file);
    }
    
    
    // this endpoint is just for testing. calling this endpoint just displays the page test-page.html located in the default directory: resources/templates
    // NOTE: need thymeleaf dependency (in the pom) for this to work.
    // to test... 
    //	1) make sure the JwtAuthenticateFilter does not check for a JWT token for endpoints that end in /file, /test and /jpg (or whatever image file extension you are using to upload) - see application-local.properties
    //  2) enter the following url in a browser window -   http://localhost:8080/fit/test
    //  3) once the page returns and displays the filename, copy the filename and enter the following in a browser window - http://localhost:8080/fit/file/{filename}
    @GetMapping("test")
    public String test(){
    	return "test-page";
    }
     
 }
