package com.fitlaw.util.log;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URI;
import java.util.Date;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;


/**
 * Utility class for Logging. This class wraps the JDK logging functionality to allow for customized log formatting.
 * It's wired and initialized using spring.
 * Since this class is annotated with @Component it will be a singleton.
 * <p>
 * This class is thread safe.
 */
@Component
public class JDKLogger implements BaseLogger {

    @Autowired
    private Environment environment;
    private FileHandler errorHandler;
    private Logger errorLogger;

    public JDKLogger() {
    }

    @PostConstruct
    private void initialize() {

        // stored in a property file that is in the classpath
        String logDirectory = environment.getRequiredProperty("log.file.location").trim();

        // stored in a project property file located in a specific directory
        String logErrorLevel = environment.getRequiredProperty("log.error.level").trim();
        String logErrorLimit = environment.getRequiredProperty("log.error.limit").trim();
        String logErrorCount = environment.getRequiredProperty("log.error.count").trim();
        String logErrorContext = environment.getRequiredProperty("log.error.context").trim();
        String logErrorFilename = environment.getRequiredProperty("log.error.filename").trim();

        Level level = Level.WARNING;
        if (logErrorLevel != null) {
            if (logErrorLevel.equalsIgnoreCase("info")) {
                level = Level.INFO;
            } else if (logErrorLevel.equalsIgnoreCase("warning")) {
                level = Level.WARNING;
            } else if (logErrorLevel.equalsIgnoreCase("severe")) {
                level = Level.SEVERE;
            }
        }

        try {

            File directory = new File(new URI("file:" + logDirectory));

            errorLogger = Logger.getLogger(logErrorContext);
            errorLogger.setLevel(level);
            errorHandler = new FileHandler(directory.getPath() + File.separator + logErrorFilename + "-%g.log", Integer.valueOf(logErrorLimit), Integer.valueOf(logErrorCount), true);
            errorHandler.setFormatter(new LogErrorFormat());
            errorLogger.addHandler(errorHandler);

        } catch (Exception e) {
            System.out.println("Unable to initialize the Logger file. Root cause is... ");
            e.printStackTrace();
        }

    }

    @PreDestroy
    public void closeLogger() {
        errorHandler.flush();
        errorHandler.close();
    }


    public void info(String msg) {
        errorLogger.log(Level.INFO, msg);
        //errorHandler.flush();
    }

    public void warning(String transactionId, String msg, Throwable t) {
        errorLogger.log(Level.WARNING, "Transaction ID - " + transactionId + " : " + msg, t);
        //errorHandler.flush();
    }

    public void warning(String transactionId, String msg) {
        errorLogger.log(Level.WARNING, "Transaction ID - " + transactionId + " : " + msg);
        //errorHandler.flush();
    }

    public void warning(String msg, Throwable t) {
        errorLogger.log(Level.WARNING,  msg, t);
        //errorHandler.flush();    	
    }
    
    public void warning(String msg) {
        errorLogger.log(Level.WARNING, msg);
        //errorHandler.flush();    	
    }

    public void severe(String transactionId, String msg, Throwable t) {
        errorLogger.log(Level.SEVERE, "Transaction ID - " + transactionId + " : " + msg, t);
        //errorHandler.flush();
    }

    public void severe(String msg, Throwable t) {
        errorLogger.log(Level.SEVERE, msg, t);
        //errorHandler.flush();
    }
    
    public void severe(String msg) {
        errorLogger.log(Level.SEVERE, msg);
        //errorHandler.flush();
    }
    
    public void severe(String transactionId, String msg) {
        errorLogger.log(Level.SEVERE, "Transaction ID - " + transactionId + " : " + msg);
        //errorHandler.flush();
    }

    public void log(BaseLogger.LogLevel level, String transactionId, String msg, Throwable t) {
    	Level loggingLevel = getLogLevel(level);
        errorLogger.log(loggingLevel, "Transaction ID - " + transactionId + " : " + msg, t);
    }
    
    public void log(BaseLogger.LogLevel level, String transactionId, String msg) {
    	Level loggingLevel = getLogLevel(level);
        errorLogger.log(loggingLevel, "Transaction ID - " + transactionId + " : " + msg);
    }

    public void log(BaseLogger.LogLevel level, String msg, Throwable t) {
    	Level loggingLevel = getLogLevel(level);
        errorLogger.log(loggingLevel, msg, t);
    }
    
    public void log(BaseLogger.LogLevel level, String msg) {
        Level loggingLevel = getLogLevel(level);
        errorLogger.log(loggingLevel, msg);
    }
    
    private Level getLogLevel(BaseLogger.LogLevel level){
        Level loggingLevel;
        switch (level) {
            case INFO:
                loggingLevel = Level.INFO;
                break;
            case WARNING:
                loggingLevel = Level.WARNING;
                break;
            case SEVERE:
                loggingLevel = Level.SEVERE;
                break;
            default:
                loggingLevel = Level.SEVERE;
        }   	
    	return loggingLevel;
    }


}

class LogErrorFormat extends SimpleFormatter {

    /**
     * This method overrides the method in SimpleFormatter, to create a specific format for logged messages.
     * print out the date, level, message, and if it also contains an exception then print out the stacktrace.
     */
    public final String format(LogRecord record) {

        StringBuffer message = new StringBuffer();
        message.append((new Date()).toString());
        message.append("  : ");
        message.append(record.getLevel());
        message.append("  : ");
        message.append(record.getMessage());
        message.append(System.lineSeparator());

        Throwable throwable = record.getThrown();
        if (throwable != null) {
            Writer stringWriter = new StringWriter();
            throwable.printStackTrace(new PrintWriter(stringWriter));
            message.append(stringWriter.toString());
            message.append(System.lineSeparator());
        }

        return message.toString();

    }
    
}
