package com.fitlaw.util.log;


/**
 * Interace for logging
 * @author alan
 *
 */
public interface BaseLogger {

    public enum LogLevel {INFO, WARNING, SEVERE}

    public void info(String msg);

    public void warning(String transactionId, String msg, Throwable t);

    public void warning(String msg, Throwable t);
    
    public void warning(String msg);

    public void warning(String transactionId, String msg);

    public void severe(String transactionId, String msg, Throwable t);
    
    public void severe(String msg, Throwable t);
    
    public void severe(String msg);

    public void severe(String transactionId, String msg);

    public void log(BaseLogger.LogLevel level, String transactionId, String msg, Throwable t);

    public void log(BaseLogger.LogLevel level, String msg, Throwable t);
    
    public void log(BaseLogger.LogLevel level, String transactionId, String msg);
    
    public void log(BaseLogger.LogLevel level, String msg);

}
