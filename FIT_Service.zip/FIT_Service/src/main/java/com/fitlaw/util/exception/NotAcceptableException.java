package com.fitlaw.util.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.fitlaw.util.log.BaseLogger.LogLevel;


/**
 * Exception to throw when a Http Status NOT_ACCEPTABLE (406) is desired.
 * @see CustomException for furthur documentation
 * @author alan
 *
 */
@ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
public class NotAcceptableException extends CustomException{
	
	public NotAcceptableException(String message){
		super(message);
	}
	
	public NotAcceptableException(String message, LogLevel logLevel){
		super(message, logLevel);
	}
	
	public NotAcceptableException(String message, LogLevel logLevel, Exception rootCause){
		super(message, logLevel, rootCause);
	}
	
}
