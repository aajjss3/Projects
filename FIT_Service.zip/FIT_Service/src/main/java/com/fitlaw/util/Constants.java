package com.fitlaw.util;

public class Constants {
	
	public static final String FIT_TOKEN = "fit-token";

}
