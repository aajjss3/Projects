package com.fitlaw.util.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.fitlaw.util.log.BaseLogger.LogLevel;


/**
 * Exception to throw when a Http Status UNAUTHORIZED (401) is desired.
 * @see CustomException for furthur documentation
 * @author alan
 *
 */
@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class UnauthorizedException extends CustomException{

	public UnauthorizedException(String message){
		super(message);
	}
	
	public UnauthorizedException(String message, LogLevel logLevel){
		super(message, logLevel);
	}
	
	public UnauthorizedException(String message, LogLevel logLevel, Exception rootCause){
		super(message, logLevel, rootCause);
	}
	
}
