package com.fitlaw.util.enumeration;

/**
 * Contains the users role type. Currently, role is not being used. If it ever is, replace these enums with appropriate values.
 * @author alan
 *
 */
public enum RoleType {
	
	USER, MANAGER, ADMIN;

}
