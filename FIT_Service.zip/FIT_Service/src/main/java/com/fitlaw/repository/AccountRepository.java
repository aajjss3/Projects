package com.fitlaw.repository;

import com.fitlaw.dto.AccountFirmDTO;
import com.fitlaw.model.Account;
import java.util.UUID;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;


/**
 * 
 * @author alan
 *
 */
@Repository
public interface AccountRepository extends PagingAndSortingRepository<Account, UUID>, JpaRepository<Account, UUID> {
	
	// return a list of AccountFirmDTO objects. This can NOT be a native query it must be a JPA query - injecting a DTO (i.e. AccountFirmDTO) in sql does not work with native queries
	@Query(value = "select new com.fitlaw.dto.AccountFirmDTO( a.id, a.wldId, a.sapId, f.legalName, f.displayName, f.email, wa.url ) from Account a, Firm f, WebAddress wa where a.firm=f and f=wa.firm and wa.isPrimary = true")
	public List<AccountFirmDTO> retrieveAccountFirms();

}
