package com.fitlaw.repository;


import java.util.UUID;
import com.fitlaw.model.ApplicationUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 * 
 * @author alan
 *
 */
@Repository
public interface ApplicationUserRepository extends JpaRepository<ApplicationUser, UUID>{
	
	public ApplicationUser findByAuthorizeId(String authorizeId);

}
