package com.fitlaw.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class ErrorDTO {
	
	// do not include the field in the JSON response if the field is null
	@JsonInclude(Include.NON_NULL)
	private String field;
	private String message;
	
	public ErrorDTO(String field, String message) {
		this.field = field;
		this.message = message;
	}
	
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}	
