package com.fitlaw.dto;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


/**
 * uid, time, digest are passing in the request (input) but not passed out in the response (output) - (see placement of the @JsonIgnore and @JsonProperty annotations)
 * token is passed out in the response (output) but not passed in the request (input) - (see placement of the @JsonIgnore and @JsonProperty annotations)
 * NOTE: since only one field is returned (token) there is no need for a DTO, could just return that field. but this is done in case future requirements dictate the need for additional fields returned.
 * @author alan
 *
 */
public class AuthorizeDTO {
	
	@JsonIgnore
	private String token;  // returned from the endpoint
	@JsonIgnore
	private String uid;  // passed into the endpoint
	@JsonIgnore
	private String time;  // passed into the endpoint
	@JsonIgnore
	private String digest;  // passed into the endpoint

	
	public AuthorizeDTO(){
	}
	
	public AuthorizeDTO(String token){
		this.token=token;
	}
	
	@JsonIgnore
	public String getUid() {
		return uid;
	}
	@JsonProperty
	public void setUid(String uid) {
		this.uid = uid;
	}
	@JsonProperty	
	public String getToken() {
		return token;
	}
	@JsonIgnore
	public void setToken(String token) {
		this.token = token;
	}
	@JsonIgnore
	public String getTime() {
		return time;
	}
	@JsonProperty
	public void setTime(String time) {
		this.time = time;
	}
	@JsonIgnore
	public String getDigest() {
		return digest;
	}
	@JsonProperty
	public void setDigest(String digest) {
		this.digest = digest;
	}

}
