package com.fitlaw.dto;

import java.util.UUID;


/**
 * 
 * @author alan
 *
 */
public class AccountFirmDTO {
	
	private String accountId;
	private String sapId;
	private String wldId;
	private String firmLegalName;
	private String firmDisplayName;
	private String firmEmail;
	private String firmPrimaryWebAddress;
	
	// required for JPA queries -  see method AccountRepository.retrieveAccountFirms()
	public AccountFirmDTO( UUID id, String wldId, String sapId, String legalName, String displayName, String email, String url){
		this.accountId = id.toString();
		this.sapId=sapId;
		this.wldId=wldId;
		this.firmLegalName=legalName;
		this.firmDisplayName=displayName;
		this.firmEmail=email;
		this.firmPrimaryWebAddress=url;
	}
	
	public AccountFirmDTO(){
	}
	
	
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	public String getWldId() {
		return wldId;
	}
	public void setWldId(String wldId) {
		this.wldId = wldId;
	}
	public String getFirmLegalName() {
		return firmLegalName;
	}
	public void setFirmLegalName(String firmLegalName) {
		this.firmLegalName = firmLegalName;
	}
	public String getFirmDisplayName() {
		return firmDisplayName;
	}
	public void setFirmDisplayName(String firmDisplayName) {
		this.firmDisplayName = firmDisplayName;
	}
	public String getFirmEmail() {
		return firmEmail;
	}
	public void setFirmEmail(String firmEmail) {
		this.firmEmail = firmEmail;
	}
	public String getFirmPrimaryWebAddress() {
		return firmPrimaryWebAddress;
	}
	public void setFirmPrimaryWebAddress(String firmPrimaryWebAddress) {
		this.firmPrimaryWebAddress = firmPrimaryWebAddress;
	}
	

}
