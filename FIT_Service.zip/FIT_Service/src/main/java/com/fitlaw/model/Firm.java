package com.fitlaw.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(
	    indexes =  @Index(
	        name = "idx_firm_name_phone_email",
	        columnList = "legal_name, phone, email"
	    )
)
public class Firm extends BaseModel{
	
	@Column(name = "legal_name", length=127) private String legalName;
	@Column(length=127)	private String displayName;
	@Column(name="phone", length=15) private String phone;
	@Column(length=15) private String fax;
	@Column(name="email", length=63) private String email;
	
    //@OneToMany(mappedBy = "firm", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "firm_id", nullable = false, updatable = false)
    private List<Focus> focuses = new ArrayList<>();
    
    //@OneToMany(mappedBy = "firm", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "firm_id", nullable = false, updatable = false)
    private List<PhysicalAddress> physicalAddresses = new ArrayList<>();
    
    //@OneToMany(mappedBy = "firm", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "firm_id", nullable = false, updatable = false)
    private List<WebAddress> webAddresses = new ArrayList<>();
	
	public Firm(){}
	
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Focus> getFocuses() {
		return focuses;
	}
	public void setFocuses(List<Focus> focuses) {
		this.focuses = focuses;
	}
	public List<PhysicalAddress> getPhysicalAddresses() {
		return physicalAddresses;
	}
	public void setPhysicalAddresses(List<PhysicalAddress> physicalAddresses) {
		this.physicalAddresses = physicalAddresses;
	}
	public List<WebAddress> getWebAddresses() {
		return webAddresses;
	}
	public void setWebAddresses(List<WebAddress> webAddresses) {
		this.webAddresses = webAddresses;
	}
		
}
