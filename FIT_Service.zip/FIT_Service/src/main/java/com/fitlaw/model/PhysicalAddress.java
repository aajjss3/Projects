package com.fitlaw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class PhysicalAddress extends BaseModel{
	
	private Boolean isPrimary;
	private Boolean isSameAsMailing;
	@Column(length=127) private String line1;
	@Column(length=127) private String line2;
	@Column(length=127) private String city;
	@Column(length=127) private String state;
	@Column(length=127) private String zip;
	@Column(length=127) private String country;
	
	// bidirectional many-to-one
	@JsonIgnore // since this is a bidirectional relationship this is required otherwise get an infinite recursion when jackson serializes
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "firm_id", insertable = false, updatable = false, nullable=false)
	private Firm firm;
	
	public PhysicalAddress(){}
	
	
	public Boolean getIsPrimary() {
		return isPrimary;
	}
	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}
	public Boolean getIsSameAsMailing() {
		return isSameAsMailing;
	}
	public void setIsSameAsMailing(Boolean isSameAsMailing) {
		this.isSameAsMailing = isSameAsMailing;
	}
	public String getLine1() {
		return line1;
	}
	public void setLine1(String line1) {
		this.line1 = line1;
	}
	public String getLine2() {
		return line2;
	}
	public void setLine2(String line2) {
		this.line2 = line2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Firm getFirm() {
		return firm;
	}
	public void setFirm(Firm firm) {
		this.firm = firm;
	}
	
}
