package com.fitlaw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class WebAddress extends BaseModel{
	
	private String url;
	private Integer index;
	private Boolean isPrimary;
	@Column(length=255) private String description;
	
	// bidirectional many-to-one
	@JsonIgnore // since this is a bidirectional relationship this is required otherwise get an infinite recursion when jackson serializes
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "firm_id", insertable = false, updatable = false, nullable=false)
	private Firm firm;
	
	public WebAddress(){}
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Firm getFirm() {
		return firm;
	}
	public void setFirm(Firm firm) {
		this.firm = firm;
	}
	public Boolean getIsPrimary() {
		return isPrimary;
	}
	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}
	
}
