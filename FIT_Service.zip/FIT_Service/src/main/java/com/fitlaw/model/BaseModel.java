package com.fitlaw.model;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;
import org.hibernate.Session;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.GeneratorType;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.tuple.ValueGenerator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.Instant;
import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 * Contains common fields used by all entities.
 * @JsonIgnoreProperties and @JsonIgnore are only needed if the endpoints accept/return the domain entities.
 * @author alan
 *
 */
@MappedSuperclass
@JsonIgnoreProperties(ignoreUnknown=true, value={"hibernateLazyInitializer", "handler"})
public class BaseModel implements Serializable{
	
	@JsonIgnore
	@Version
	protected Integer version; // used by hibernate for optimistic locking
	
	@Id
    @GeneratedValue
    @Type(type = "org.hibernate.type.UUIDCharType") // store the UUID in the database as characters (default is binary)
	//@Type(type = "uuid-char")
    protected UUID id;
		
	@JsonIgnore
	@CreationTimestamp
	protected Instant created;
	
	@JsonIgnore
	@UpdateTimestamp
	protected Instant updated;
	
	@JsonIgnore
    @GeneratorType( type = LoggedUserGenerator.class, when = GenerationTime.INSERT)
    @Column(name="created_by", length=63)
    private String createdBy;

	@JsonIgnore
    @GeneratorType( type = LoggedUserGenerator.class, when = GenerationTime.ALWAYS)
    @Column(name="updated_by",length=63)
    private String updatedBy;
	
	
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public Instant getCreated() {
		return created;
	}
	public void setCreated(Instant created) {
		this.created = created;
	}
	public Instant getUpdated() {
		return updated;
	}
	public void setUpdated(Instant updated) {
		this.updated = updated;
	}
	public UUID getId() {
		return id;
	}
	public void setId(UUID id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public static class CurrentUser {

	    public static final CurrentUser INSTANCE = new CurrentUser();
	    private static final ThreadLocal<String> storage = new ThreadLocal<>();

	    public void logIn(String user) {
	        storage.set( user );
	    }
	    public void logOut() {
	        storage.remove();
	    }
	    public String get() {
	        return storage.get();
	    }
	}

	public static class LoggedUserGenerator implements ValueGenerator<String> {

	    @Override
	    public String generateValue(
	            Session session, Object owner) {
	        return CurrentUser.INSTANCE.get();
	    }
	}

}


