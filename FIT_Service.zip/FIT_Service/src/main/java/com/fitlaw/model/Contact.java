package com.fitlaw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(
	    indexes =  @Index(
	        name = "idx_contact_last_email_phone",
	        columnList = "last, email, phone"
	    )
)
public class Contact extends BaseModel{

	private Boolean isPrimary;
	@Column(length=63) private String first;
	@Column(name="last", length=63) private String last;
	@Column(name="email", length=63) private String email;
	@Column(name="phone", length=63) private String phone;
	
	// bidirectional many-to-one
	@JsonIgnore // since this is a bidirectional relationship this is required otherwise get an infinite recursion when jackson serializes
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "account_id", insertable = false, updatable = false, nullable=false)
	private Account account;
	
	
	public Contact(){}
	
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
	public String getLast() {
		return last;
	}
	public void setLast(String last) {
		this.last = last;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Boolean getIsPrimary() {
		return isPrimary;
	}
	public void setIsPrimary(Boolean isPrimary) {
		this.isPrimary = isPrimary;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
}
