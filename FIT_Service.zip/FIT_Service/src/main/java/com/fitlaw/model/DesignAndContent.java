package com.fitlaw.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;



@Entity
public class DesignAndContent extends BaseModel{
	
	private Boolean hasLogo;
	private Boolean hasSlogan;
	private Integer scale;
	@Column(length=255)	private String slogan;
	private Boolean isCustomerColor;
	@Column(length=4000) private String currentSiteReason; // currentSiteReason contains json
	@Column(length=255)	private String improvements;
	@Column(length=127)	private String font;
	@Column(length=4000) private String newSiteInclude;  	// newSiteInclude contains json
	@Column(length=4000) private String tone; 	// tone contains json
	@Column(length=127)	private String color;
	
    //@OneToMany(mappedBy = "designAndContent", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "design_and_content_id", nullable = false, updatable = false)
    private List<Design> designs = new ArrayList<>();
	
    //@OneToMany(mappedBy = "designAndContent", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "design_and_content_id", nullable = false, updatable = false)
    private List<Logo> logos = new ArrayList<>();
    
	public DesignAndContent(){}
	
	public Boolean getHasLogo() {
		return hasLogo;
	}
	public void setHasLogo(Boolean hasLogo) {
		this.hasLogo = hasLogo;
	}
	public Boolean getHasSlogan() {
		return hasSlogan;
	}
	public void setHasSlogan(Boolean hasSlogan) {
		this.hasSlogan = hasSlogan;
	}
	public String getSlogan() {
		return slogan;
	}
	public void setSlogan(String slogan) {
		this.slogan = slogan;
	}
	public String getCurrentSiteReason() {
		return currentSiteReason;
	}
	public void setCurrentSiteReason(String currentSiteReason) {
		this.currentSiteReason = currentSiteReason;
	}
	public Integer getScale() {
		return scale;
	}
	public void setScale(Integer scale) {
		this.scale = scale;
	}
	public String getImprovements() {
		return improvements;
	}
	public void setImprovements(String improvements) {
		this.improvements = improvements;
	}
	public String getFont() {
		return font;
	}
	public void setFont(String font) {
		this.font = font;
	}
	public Boolean getIsCustomerColor() {
		return isCustomerColor;
	}
	public void setIsCustomerColor(Boolean isCustomerColor) {
		this.isCustomerColor = isCustomerColor;
	}
	public String getNewSiteInclude() {
		return newSiteInclude;
	}
	public void setNewSiteInclude(String newSiteInclude) {
		this.newSiteInclude = newSiteInclude;
	}
	public String getTone() {
		return tone;
	}
	public void setTone(String tone) {
		this.tone = tone;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public List<Design> getDesigns() {
		return designs;
	}
	public void setDesigns(List<Design> designs) {
		this.designs = designs;
	}
	public List<Logo> getLogos() {
		return logos;
	}
	public void setLogos(List<Logo> logos) {
		this.logos = logos;
	}

}
