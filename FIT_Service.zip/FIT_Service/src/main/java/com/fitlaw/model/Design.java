package com.fitlaw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class Design extends BaseModel{
	
	private String url;
	private String fileLocation;
	private String fileName;
	@Column(length=4000) private String tags;
	
	// bidirectional many-to-one
	@JsonIgnore // since this is a bidirectional relationship this is required otherwise get an infinite recursion when jackson serializes
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "design_and_content_id", insertable = false, updatable = false, nullable=false)
	DesignAndContent designAndContent;
	
	public Design(){}
	

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getFileLocation() {
		return fileLocation;
	}
	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public DesignAndContent getDesignAndContent() {
		return designAndContent;
	}
	public void setDesignAndContent(DesignAndContent designAndContent) {
		this.designAndContent = designAndContent;
	}

}
