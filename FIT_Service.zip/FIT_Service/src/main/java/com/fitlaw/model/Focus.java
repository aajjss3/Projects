package com.fitlaw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Focus extends BaseModel{
	
	private Double amount;
	@Column(length=127) private String tag;
	@Column(length=127) private String description;
	
	// bidirectional many-to-one
	@JsonIgnore // since this is a bidirectional relationship this is required otherwise get an infinite recursion when jackson serializes
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "firm_id", insertable = false, updatable = false, nullable=false)
	private Firm firm;
	
	public Focus(){}
	
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Firm getFirm() {
		return firm;
	}
	public void setFirm(Firm firm) {
		this.firm = firm;
	}
	
}
