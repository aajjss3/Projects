package com.fitlaw.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fitlaw.util.enumeration.RoleType;


@Entity
@Table(
	    indexes =  @Index(
	        name = "idx_app_user_authorize",
	        columnList = "authorize_id"
	    )
)
public class ApplicationUser extends BaseModel{
	
	@Enumerated(EnumType.STRING)
	private RoleType role;
	@Column(name = "authorize_id", length=63)	private String authorizeId;
	
	@JsonIgnore
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "application_user_id", nullable = true, updatable = false)
	private List<Account> accounts = new ArrayList<>();
	
	public RoleType getRole() {
		return role;
	}
	public void setRole(RoleType role) {
		this.role = role;
	}
	public String getAuthorizeId() {
		return authorizeId;
	}
	public void setAuthorizeId(String authorizeId) {
		this.authorizeId = authorizeId;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	
}
