package com.fitlaw.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
//import java.util.UUID;
//import org.springframework.data.domain.Persistable;


@Entity
@Table(
	    indexes =  @Index(
	        name = "idx_account_wld_sap",
	        columnList = "wld_id, sap_id"
	    )
)
public class Account extends BaseModel/* implements Persistable<UUID>*/{
		
	//@Transient public boolean isNew;
	@Lob private String goal; // goal contains json (more than 4000 chars so set as CLOB)
	@Column(name = "wld_id", length=63)	private String wldId;
	@Column(name = "sap_id", length=63)	private String sapId;
	
	//public boolean isNew(){
	//	return this.isNew;
	//}
	
	// unidirectional one-to-one (lazy load with a bidirectional one-to-one is complicated to code and requires bytecode enhancement)
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "design_and_content_id", nullable=false)
	private DesignAndContent designAndContent;
    
	// unidirectional one-to-one 
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "firm_id", nullable=false)
	private Firm firm;
    
    //@OneToMany(mappedBy = "account", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    // bidirectional one-to-many
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "account_id", nullable = false, updatable = false)
    private List<Contact> contacts = new ArrayList<>();
	
	// bidirectional many-to-one
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "application_user_id", insertable = true, updatable = true, nullable=false)
	private ApplicationUser applicationUser;
	
	public Account(){}
 

	public String getWldId() {
		return wldId;
	}
	public void setWldId(String wldId) {
		this.wldId = wldId;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	public String getGoal() {
		return goal;
	}
	public void setGoal(String goal) {
		this.goal = goal;
	}
	public Firm getFirm() {
		return firm;
	}
	public void setFirm(Firm firm) {
		this.firm = firm;
	}
	public DesignAndContent getDesignAndContent() {
		return designAndContent;
	}
	public void setDesignAndContent(DesignAndContent designAndContent) {
		this.designAndContent = designAndContent;
	}
	public List<Contact> getContacts() {
		return contacts;
	}
	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}
	public ApplicationUser getApplicationUser() {
		return applicationUser;
	}
	public void setApplicationUser(ApplicationUser applicationUser) {
		this.applicationUser = applicationUser;
	}
 
}
